class ConfigReader(object):
    
    def __init__(self, config, file_name):
        self.__config = config
        self.__file_name = file_name
        
        
    def read_file(self):
        from copy import deepcopy
        
        lines = []
        with open(self.__file_name, 'r') as reader:
            for line in reader.readlines():
                
                config_copy = deepcopy(self.__config)
                for key, config in config_copy.items():
                    start, end = config['start_end']
                    config_copy[key]['value'] = line[start:end]
                lines.append(config_copy)
                
        return lines
