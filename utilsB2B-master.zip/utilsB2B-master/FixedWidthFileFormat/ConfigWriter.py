class ConfigWriter(object):
    
    def __init__(self, config, file_name, width):
        self.__config = config
        self.__file_name = file_name
        self.__width = width
        
    def write_line(self, value):
        line = list("".ljust(self.__width, " "))
        for key, config in value.items():
            start, end = config['start_end']
            value = config.get('value', '')
            counter = 0
            for i in range(start - 1, len(value) + start - 1):
                line[i] = value[counter]
                counter += 1
        
        return "".join(line)
            
            
    def write_file(self, values):
        from tempfile import NamedTemporaryFile
        temp_file = NamedTemporaryFile()
        
        with open(self.__file_name, mode='w') as temp:
            for value in values:
                temp.writelines([self.write_line(value), "\n"])
            