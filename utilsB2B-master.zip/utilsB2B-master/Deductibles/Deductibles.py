from datetime import datetime
from os import getenv
from uuid import uuid4

from couchbase.cluster import Cluster, PasswordAuthenticator
from couchbase.n1ql import N1QLQuery


class Deductibles(object):

    def __init__(self, job_id, deductible):
        self._deductible_document = deductible
        self._job_id = job_id
        self._cluster = Cluster(getenv('CB_HOST'))
        self._bucket_name = getenv('CB_BUCKET')
        self._authenticator = PasswordAuthenticator(getenv('CB_USER'), getenv('CB_PASSWORD'))
        try:
            self._cluster.authenticate(self._authenticator)
        except Exception as _:
            raise Exception("Could not authenticate with couchbase")
        self._cursor = self._cluster.open_bucket(self._bucket_name)

        self._flipt_person_ids = {
            'emp_flipt_person_id': '',
            'dep_flipt_person_id': ''
        }

    def _get_deductible(self, fields):
        query = N1QLQuery(
            f"SELECT * FROM `{self._bucket_name}` WHERE type='deductible' AND emp_flipt_person_id = '"
            f"{self._flipt_person_ids['emp_flipt_person_id']}' AND dep_flipt_person_id = '"
            f"{self._flipt_person_ids['dep_flipt_person_id']}'")

        result = self._cursor.n1ql_query(query).get_single_result()
        if not result:
            return result

        return self._cursor.n1ql_query(query).get_single_result()[self._bucket_name]

    def _update_history(self, deductible):
        deductible.update({
            'type': 'deductible_history',
            'updated_date': datetime.now().isoformat(),
            'job_id': self._job_id
        })
        self._cursor.upsert(uuid4().hex, deductible)

    def _stringified_key_values(self, fields):
        stringified_fields = ""

        for key, value in fields.items():
            stringified_fields += f"{key}='{value}',"

        return stringified_fields[:-1]

    def set_flipt_ids(self, flipt_ids):
        if not ('emp_flipt_person_id' and 'dep_flipt_person_id') in flipt_ids:
            raise Exception('Missing emp_flipt_person_id or dep_flipt_person_id')

        self._flipt_person_ids['emp_flipt_person_id'] = flipt_ids['emp_flipt_person_id']
        self._flipt_person_ids['dep_flipt_person_id'] = flipt_ids['dep_flipt_person_id']

    def update(self, fields):
        deductible = self._get_deductible(fields)

        if not deductible:
            self._cursor.upsert(uuid4().hex, self._deductible_document)
            return
        self._update_history(deductible)

        update_query = f"UPDATE `{self._bucket_name}` SET " \
                       f"{self._stringified_key_values(fields)} WHERE " \
                       f"type='deductible' AND emp_flipt_person_id='{self._flipt_person_ids['emp_flipt_person_id']}' " \
                       f"AND dep_flipt_person_id='{self._flipt_person_ids['dep_flipt_person_id']}'"

        query = N1QLQuery(update_query)

        return self._cursor.n1ql_query(query).execute()