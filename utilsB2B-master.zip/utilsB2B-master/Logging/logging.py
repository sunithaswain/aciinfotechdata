import logging


class Logger:

    def __init__(self):

        self.logger = logging.getLogger(__name__)
        logging.basicConfig(level=logging.DEBUG)
        self.custom_format_attributes = ["event_type", "start_time", "end_time", "resp_time", "source", "operation", "transaction_id", "transaction_type", "seq_num",
                                         "destination", "flow", "http_method", "http_status_code", "http_status_msg", "message", "backend_url", "auth_id", "domain", "reject_cd", "reject_msg"]
        self.log_info = ""

    def log(self, log_attributes):

        self.format_log(log_attributes, '=', ',')
        self.logger.debug(self.log_info)
        self.log_info = ""

    def format_log(self, log_attributes, key_value_separator, attribute_separator):

        for i in self.custom_format_attributes:
            value = log_attributes.get(i, "")
            self.log_info += "{} {} {} {}".format(
                i, key_value_separator, value, attribute_separator)

        self.log_info = self.log_info[:-1]