import paramiko
import sys
import traceback
import sendgrid
import os
import socket
from sendgrid.helpers.mail import Email, Content, Mail


class FastTransport(paramiko.Transport):
    def __init__(self, sock):
        super(FastTransport, self).__init__(sock)
        self.window_size = 2147483647
        self.packetizer.REKEY_BYTES = pow(2, 40)
        self.packetizer.REKEY_PACKETS = pow(2, 40)
    # end contructor
# end class


class AWS_SFTP(FastTransport):
    def __init__(self, domain, processfunc):
        self.sftp_file_list = []
        self.sftp_status = ''
        self.sftp_port = 22
        sftparchive_tag = f'SFTP_{processfunc}_ARCHIVE_FOLDER_'
        sftphost_tag = f"SFTP_{processfunc}_HOST_"
        sftpuser_tag = f"SFTP_{processfunc}_USER_"
        sftp_upfolder_tag = f"SFTP_{processfunc}_UPLOAD_FOLDER_"
        sftp_dnfolder_tag = f"SFTP_{processfunc}_DOWNLOAD_FOLDER_"
        sftppwd_tag = f"SFTP_{processfunc}_PASSWORD_"
        sg = sendgrid.SendGridAPIClient(
            apikey=os.environ.get('SENDGRID_API_KEY'))

        if domain in ('GWLABS001', 'FLIPT001'):
            domain = 'GWLABS001'

        self.sftp_host = os.environ[sftphost_tag + domain]
        self.sftp_user = os.environ[sftpuser_tag + domain]
        self.sftp_pwd = os.environ[sftppwd_tag + domain]
        self.sftp_home = f"/{os.environ[sftp_upfolder_tag + domain]}/"
        self.sftp_download = f"/{os.environ[sftp_dnfolder_tag + domain]}/"
        self.sftp_archive = f"/{os.environ[sftparchive_tag + domain]}/"

        self.transport = FastTransport((self.sftp_host, self.sftp_port))
        try:
            self.transport.connect(
                username=self.sftp_user, password=self.sftp_pwd)
        except Exception as e:
            type, value, etraceback = sys.exc_info()
            error = ""
            x = traceback.format_exception(type, value, etraceback)
            for i in x:
                error = error + i
            content_ = f'Dear Admin Team,\n We are not able to connect to the sftp server ({sftp_host}) for ' + \
                f'domain < {domain} > to perform an SFTP transfer. An exception ' + str(
                    error) + ' stops this process. Kindly look into this issue.\n \n Best regards,\n FLIPT Integration Team'
            content = Content("text/plain", content_)
            mail = Mail(Email('noreply@fliptrx.com'), 'ALERT: Formulary SFTP Connectivity Failure',
                        Email('SSubramani@GWLabs.com'), content)
            host = socket.gethostname()
            receiver2 = ['SPal@fliptrx.com', 'DWagle@fliptrx.com']
            hostnameprod = 'newprod-python-e1a'
            if host == hostnameprod:
                receiver2 = ['SPal@fliptrx.com',
                             'DWagle@fliptrx.com', 'hkumar@fliptrx.com']
            for i in receiver2:
                mail.personalizations[0].add_to(Email(i))
            response = sg.client.mail.send.post(request_body=mail.get())
            sys.exit()

        self.sftp = paramiko.SFTPClient.from_transport(self.transport)
    # end constructor

    def sftp_getfilelist(self, src):
        if len(self.sftp_file_list) == 0:
            self.sftp_file_list = self.sftp.listdir(path=src + '/')
    # end method

    def find_xferfile(self, searchstr, phrase=None):
        """
        returns the name if it is found in the sftp_file_list.  return None otherwise
        """
        if isinstance(searchstr, str):
            for fname in self.sftp_file_list:
                if searchstr in fname:
                    return fname
        else:
            if phrase == 'employee':
                loop_vals = searchstr.keys()
                for ftype in loop_vals:
                    fname = self.find_xferfile(ftype)
                    if fname is not None:
                        return fname
            else:
                loop_vals = searchstr.values()
                for ftype in loop_vals:
                    fname = self.find_xferfile(ftype)
                    if fname is not None:
                        return fname
        return None
    # end method

    def find_depfile(self, empfile, emp_dict):
        for keyphrs in emp_dict.keys():
            if keyphrs in empfile:
                depfile = empfile.replace(keyphrs, emp_dict[keyphrs])
                for fname in self.sftp_file_list:
                    if fname == depfile:
                        return fname
        return None
    # end function

    def sftptransfer(self, source, destination, mode, searchstr=None, phrase=None, searchdict=None, empfile=None, loghndl=None):
        fname = ''
        if mode == 'PUT':
            dest_file = os.path.basename(source)
            fname = dest_file

            if destination is None:
                destination = self.sftp_archive

            try:
                self.sftp.put(source, destination + dest_file)

                # print (fileatt)
                self.status = 'S'
                if loghndl is None:
                    print(f'Upload Successful for < {source} >.')
                else:
                    loghndl.info(f'Upload successful for < {source}')
            except IOError:
                self.status = 'E'
                if loghndl is None:
                    print('File not Found in Remote')
                else:
                    loghndl.error(f'File < {source} > not found in remote!!')

        elif mode == 'GET':
            self.sftp_getfilelist(self.sftp_home)
            if searchdict is not None:
                fname = self.find_xferfile(searchdict, phrase=phrase)
            else:
                if empfile is None:
                    fname = self.find_xferfile(searchstr)
                else:
                    fname = self.find_depfile(empfile, searchstr)

            if fname is None:
                if loghndl is None:
                    print("No file found or incorrect naming convention!!  If eligibility, must contain" +
                          "'[Emp|Dep]' in the name.")
                else:
                    loghndl.error("No file found or incorrect naming convention!! If eligibility, " +
                                  "must contain '[Emp|Dep] in the name.")
                self.status = 'E'
                return 'E', 'Error'

            fpath = self.sftp_home + f"{fname}"
            try:
                self.sftp.get(fpath, destination + fname)
                self.status = 'S'
                if loghndl is None:
                    print(f'{fname}: Download Successful...')
                else:
                    loghndl.info(f'Download successful for: {fname}')

            except IOError:
                self.status = 'E'
                if loghndl is None:
                    print(f'{fname}: File not transferred Successfully')
                else:
                    loghndl.error(f'File transfer unsuccessful for: {fname}')

        return self.status, fname
    # end function

    def sftpremove(self, source, loghndl=None):
        try:
            self.sftp.unlink(f'/{self.sftp_home}/{source}')
            self.status = 'S'
        except IOError:
            self.status = 'E'
            if loghndl is None:
                print(f"Delete of remote file: {source} failed!!")
            else:
                loghndl.error(f'Delete of remote file: {source} failed!!')

        return self.status, ''
    # end function

    def sftp_close(self):
        self.sftp.close()
        self.transport.close()
    # end function

# end class
