if __name__ == '__main__':
    import os
    import sys
    rootdir = os.path.dirname(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))))
    sys.path.append(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))))

from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Cluster
from couchbase.n1ql import N1QLQuery
from datetime import datetime
import sys
import os
import couchbase.subdocument as SD



class CouchbaseUtil:

    def __init__(self):

        cluster = Cluster(os.environ['CB_URL'])
        auth = PasswordAuthenticator(
            os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
        cluster.authenticate(auth)
        self.bucket_name = os.environ['CB_INSTANCE']
        self.cb = cluster.open_bucket(self.bucket_name)

    def getData(self, query):


        result = N1QLQuery(query)
        result.timeout = 7200
        return self.cb.n1ql_query(result)

    def partialUpdate(self, docid, data):

        for key, value in data.items():
            self.cb.mutate_in(docid, SD.upsert(
                key, str(value)))

    def upsertData(self, docid, data):

        response = self.cb.upsert(docid, data)
        return response

    def incrementCounter(self, countertype, delta_number):

        counter = self.cb.counter(countertype, delta=delta_number).value
        return counter

    def deleteData(self, docid):

        response = self.cb.remove(docid)
        return response
