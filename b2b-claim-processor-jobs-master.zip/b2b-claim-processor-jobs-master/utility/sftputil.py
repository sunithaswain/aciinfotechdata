import paramiko
import sys
import traceback
import os
import socket
from stat import *
from utility.emailutil import EmailUtil


class FastTransport(paramiko.Transport):
    def __init__(self, sock):
        super(FastTransport, self).__init__(sock)
        self.window_size = 2147483647
        self.packetizer.REKEY_BYTES = pow(2, 40)
        self.packetizer.REKEY_PACKETS = pow(2, 40)


class SFTP(FastTransport):
    def __init__(self, host, username, password):

        self.port = 22
        self.username = os.environ[username]
        self.host = os.environ[host]
        self.password = os.environ[password]

        try:

            self.transport = FastTransport((self.host, self.port))

            self.transport.connect(
                username=self.username, password=self.password)
            self.sftp = paramiko.SFTPClient.from_transport(self.transport)
        except Exception as e:
            type, value, etraceback = sys.exc_info()
            error = ""
            x = traceback.format_exception(type, value, etraceback)
            for i in x:
                error = error + i

            body = f'Dear Admin Team,\n We are not able to connect to the eRx sftp server to perform an SFTP transfer. An exception ' + str(
                error) + ' stops this process. Kindly look into this issue.\n \n Best regards,\n FLIPT Integration Team'
            subject = os.environ['INSTANCE_TYPE'] + \
                '-ALERT: eRx SFTP Connectivity Failure'
            receivers = ['fliptintegration@fliptrx.com']
            if os.environ['INSTANCE_TYPE'] == 'PROD':
                receivers.append('SPal@fliptrx.com')

            email = EmailUtil(body=body, subject=subject,
                              sender=None, receiver=receivers)
            email.sendEmail()
            sys.exit()

    def getContents(self, location):

        contents = self.sftp.listdir(path=location)
        return contents

    def isDirectory(self, path):

        if S_ISDIR(self.sftp.lstat(path).st_mode):
            return True

        return False

    def putSftp(self, source, destination):

        success = False

        try:
            self.sftp.put(source, destination)
            success = True
        except Exception as e:
            print(e)

        return success

    def getSftp(self, source, destination):

        success = False

        try:

            self.sftp.get(source, destination)
            success = True
        except Exception as e:
            print(e)

        return success

    def remove(self, path):

        self.sftp.remove(path)

    def sftpClose(self):
        self.sftp.close()
        self.transport.close()
    # end function

# end class
