from sendgrid.helpers.mail import Email, Content, Attachment, Mail, Personalization
import base64
import sendgrid
import os


class EmailUtil:

    def __init__(self, subject, body, sender, receiver):

        self.subject = subject
        self.body = body
        self.sender = sender
        self.receiver = receiver[0]
        self.cc = []
        if len(receiver) > 1:
            self.cc.extend(receiver[1:])
        self.sg = sendgrid.SendGridAPIClient(
            apikey=os.environ.get('SENDGRID_API_KEY'))

    def sendEmail(self):

        content = Content("text/plain", self.body)
        mail = Mail(Email('noreply@fliptrx.com'), self.subject,
                    Email(self.receiver), content)

        for i in self.cc:
            mail.personalizations[0].add_to(Email(i))
        response = self.sg.client.mail.send.post(request_body=mail.get())
