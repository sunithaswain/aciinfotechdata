#!/bin/sh

export DATE=`date +%F-%H%M`
DD=`date +%d-%b-%Y`
SCRIPT=`basename $0`
export LOGFILE=${LOGDIR}/${SCRIPT}-${DATE}.log

sh ${CRONDIR}/printheader.sh
${PYTHONBIN}  /home/fliptrxadmin/bin/PYTHON/b2b-claim-processor-jobs/reconciliation/nightlyreconciliation.py -m final  >> ${LOGFILE}
sh ${CRONDIR}/printfooter.sh
