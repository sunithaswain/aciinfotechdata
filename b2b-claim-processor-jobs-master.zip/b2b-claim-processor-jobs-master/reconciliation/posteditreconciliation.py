if __name__ == "__main__":
    import os
    import sys
    rootdir = os.path.dirname(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))))
    sys.path.append(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))))
from claimreversal import reverseIntent
from utility.couchbaseutil import CouchbaseUtil
from utility.sftputil import SFTP
from utility.loggingutil import logger
from datetime import datetime
import argparse
import pandas as pd



class eRxFrequentReconciliation:

    def __init__(self):
        self.dataprovider = CouchbaseUtil()

        self.sftp = SFTP('SFTP_ERX_HOST', 'SFTP_ERX_USERNAME',
                         'SFTP_ERX_PASSWORD')
        self.destination = os.environ['CB_DATA'] + \
            '//'+'claimprocessor//reconciliation//'
        source_folder = '\\'
        archive_folder = 'archive\\'
        if os.environ['INSTANCE_TYPE'] != 'PROD':
            source_folder = 'l_upload//'
        if os.environ['INSTANCE_TYPE'] != 'PROD':
            archive_folder = 'archive//'
        self.source = source_folder
        self.archive = self.source + archive_folder
        parser = argparse.ArgumentParser(
            description='commandline file processing...')
        parser.add_argument("-m", "--processing_type",
                            help="final/draft mode", required=True)
        args = vars(parser.parse_args())
        self.mode = str(args['processing_type'])
        self.logger = None

    def read_data(self):

        source_folder = self.source

        if os.environ['INSTANCE_TYPE'] != 'PROD':
            source_folder = 'l_upload'
        file_found = False

        filenames = self.sftp.getContents(source_folder)

        for i in filenames:
            if 'Frequent' not in i:
                continue
            print('processing file', i)
            timestamp = datetime.strftime(datetime.now(), '%Y%m%d_%H%M%S')
            self.logger = logger(self.destination +
                                 'log//'+i.replace('.csv', '')+'Log.txt')
            print('log file location', self.destination +
                  'log//'+i.replace('.csv', '')+'Log.txt')
            print('file transfer', self.source +
                  i, '-->', self.destination + i)
            success = self.sftp.getSftp(self.source + i, self.destination + i)
            if not success:
                self.logger.debug(f'File transfer failure {i} \r\n')
                continue
            self.logger.debug(f'Processing File {i} \r\n')
            file_found = True
            data = pd.read_csv(
                self.destination + i, converters={'SWITCH_TRANSACTION_NUMBER': lambda x: str(x)})
            self.rejection_update(data)

            if self.mode.lower() == 'final':
                self.sftp.putSftp(self.destination + i,
                                  self.archive+i)
                self.sftp.remove(self.source+i)
                #os.remove(self.destination + i)
        self.sftp.sftpClose()
        if not file_found:
            print('********No file found********')

    def rejection_update(self, data):

        data.fillna("", inplace=True)
        claimstatusmapping = {'B1': {'R': 'R', 'D': 'R'},
                              'B2': {'R': 'R', 'D': 'R'}}
        for _, r in data.iterrows():

            try:

                print('SWTICH TRANSACTION NUMBER: ',
                      r['SWITCH_TRANSACTION_NUMBER'])
                claim = {}
                result = self.dataprovider.getData(
                    "Select prescription_id,claim_response.transaction_response_status, claim_request.transaction_code,meta().id as docid from `" + self.dataprovider.bucket_name + "` where type='claim' and transactionId='{}' limit 1".format(str(r['SWITCH_TRANSACTION_NUMBER'])))
                
                for res in result:
                    claim.update(dict(res))

                if not claim:
                    self.logger.debug('Transaction ID {} not found \r\n'.format(
                        r['SWITCH_TRANSACTION_NUMBER']))
                    continue

                claim_status = ''
                try:
                    claim_status = claimstatusmapping[claim['transaction_code']
                                                      ][r['TRANSACTION_STATUS']]
                except:
                    self.logger.debug('Transaction ID {}, erx status {} is an invalid status \r\n'.format(
                        r['SWITCH_TRANSACTION_NUMBER'], r['TRANSACTION_STATUS']))
                    continue

                if not claim_status:
                    self.logger.debug('Transaction ID {}, erx status {} not updated \r\n'.format(
                        r['SWITCH_TRANSACTION_NUMBER'], r['TRANSACTION_STATUS']))
                    continue

                if self.mode.lower() == 'final':
                    self.dataprovider.partialUpdate(
                        claim['docid'], {'erx_status': r['TRANSACTION_STATUS'], 'claim_status': claim_status})
                    if claim['transaction_code'] == 'B1' and r['TRANSACTION_STATUS'] == 'R' and claim['transaction_response_status'] == 'P':
                        reverseIntent(claim)

                self.logger.debug('Transaction ID {}, erx status {} \r\n'.format(
                    r['SWITCH_TRANSACTION_NUMBER'], r['TRANSACTION_STATUS']))
            except Exception as e:
                print('Exception', e)
                self.logger.debug(str(r)+'\r\n')
                self.logger.debug('Exception'+str(e)+'\r\n')


if __name__ == "__main__":

    obj = eRxFrequentReconciliation()
    obj.read_data()

