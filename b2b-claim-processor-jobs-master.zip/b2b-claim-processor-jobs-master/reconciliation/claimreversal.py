if __name__ == "__main__":
    import os
    import sys
    rootdir = os.path.dirname(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))))
    sys.path.append(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))))
from utility.loggingutil import logger
from utility.sftputil import SFTP
from utility.couchbaseutil import CouchbaseUtil
from datetime import datetime

dataprovider = CouchbaseUtil()


def reverseIntent(claim):

    date = datetime.now().isoformat()

    dataprovider.partialUpdate(claim['prescription_id'], {
                               'available_fill_date': '', 'rx_status': 'Routed', 'routed_date': date, 'update_date': date})

