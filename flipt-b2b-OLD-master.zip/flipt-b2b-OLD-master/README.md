# flipt-b2b
Flipt - B2B Integrataion Tools for processing the data in flipt web and mobile application