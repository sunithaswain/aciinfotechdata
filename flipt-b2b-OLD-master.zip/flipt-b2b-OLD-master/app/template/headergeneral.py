########################################
# !/usr/bin/env python  
# title         : headergeneral.py
# description   : 
# author        : 
# date created  : YYYYMMDD HH:MM
# date last modified    : YYYYMMDD HH:MM
# version       : X.X
# maintainer    : 
# email         : aaaaaaa@fliptrx.com
# status        : Production
# Python Version: 3.5.X
# usage         : python headergeneral.py -m DRAFT
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#                          
# #######################################