########################################
# !/usr/bin/env python
# title         : programstandardprototype.py
# description   : Prototype program following python program standard. This program is created from termsconditionsupdate.py
# author        : Pal
# date created  : 20190112
# date last modified    : 20190116 20:00
# version       : 0.1
# maintainer    : Pal
# email         : pmuthanai@fliptrx.com
# status        : Development
# Python Version: 3.5.2
# usage         : python programstandardprototype.py -m DRAFT
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#
# #######################################

import os
import codecs
import sys
from datetime import datetime
import logging
# import pprint

import pandas as pd
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.n1ql import N1QLQuery
from couchbase import FMT_JSON


# Added to update the system path to refer our custom packages
if __name__ == '__main__':
    import os
    import sys
    rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.append(rootdir)

import app.common.commandline as commandline
from app.common.sendgridemail import email_log

domain = ''
filetype = ''
filename = ''
mode = ''
cb = None

logging.basicConfig(level=logging.DEBUG)
LOG = logging.getLogger('termsconditions')


def load_tandc():
    """
    read the input files and update the termsconditions document based on domains in file

    """

    tcexcel = pd.read_excel(os.environ['CB_DATA']+'//termsconditions//termsconditions.xlsx')
    LOG.info("No of records in File "+ str(tcexcel.shape[0]))
    domainlistfile = list(tcexcel["domain_name"].values)
    LOG.info("Available domains in File ..."+ ", ".join(domainlistfile))
    domainquery = N1QLQuery('Select domain_name from `'+os.environ['CB_INSTANCE']+'` where type="termsconditions"')
    missingdomainfile = []
    domaindb = []
    for domainrow in cb.n1ql_query(domainquery):
        domaindb.append(domainrow['domain_name'])
        if not domainrow['domain_name'] in domainlistfile:
            missingdomainfile.append(domainrow['domain_name'])
    LOG.info("Available domains in cb database: "+", ".join(domaindb))
    LOG.info("These domain entries are missing in the file "+", ".join(missingdomainfile))

    ftctxt = codecs.open(os.environ['CB_DATA']+'//termsconditions//termsandconditions.txt', 'r', 'utf-8', errors='replace')
    #print(tcexcel)
    termcond = ftctxt.read()
    fhippatxt = codecs.open(os.environ['CB_DATA']+'//termsconditions//hippa.txt', 'r', 'utf-8', errors='replace')
    hcompl = fhippatxt.read()
    # docid=[]
    for tcindex, tcrow in tcexcel.iterrows():
        query = N1QLQuery('Select meta().id as id from `'+os.environ['CB_INSTANCE']+'` where type = "termsconditions" and domain_name = $dn', dn=tcrow['domain_name'])
        domain_value = tcrow['domain_name']
        dtermshippa = dict()
        for excelcol in list(tcexcel):
            colnew = excelcol.replace(' ', '_').lower()
            dtermshippa[colnew] = str(tcrow[excelcol])
        dtermshippa['terms_conditions'] = termcond
        dtermshippa['hippa_compliance'] = hcompl
        present = False
        if mode.upper().strip() == 'FINAL':

            for dbrecord in cb.n1ql_query(query):
                LOG.info("This existing domain in database is updated "+domain_value)
                cb.upsert(dbrecord['id'], dtermshippa, format=FMT_JSON)
                present = True
            if not present:
                LOG.info("This new domain is created  in database "+domain_value)
                cb.upsert(str(cb.counter('docid', delta=1).value), dtermshippa, format=FMT_JSON)

def opencbbucket():
    """
    Coonect the couchbase bucket

    """
    LOG.info('Accessing couchbase database')
    try:
        cluster = Cluster(os.environ['CB_URL'])
        auth = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
        cluster.authenticate(auth)
        cbbucket = cluster.open_bucket(os.environ['CB_INSTANCE'])
        return cbbucket
    except:
        LOG.info('Exception in db access')
        raise RuntimeError("This is error message")
    finally:
        LOG.debug("Close all resources")

def main():
    """
    Read the mode , set the log

    """
    global domain
    global mode
    global cb
    global LOG
    domain, filetype, filename, mode = commandline.main(sys.argv[1:])

    fformat = logging.Formatter('%(name)s:%(levelname)s:%(message)s')
    logpath = os.environ['CB_DATA']+'//termsconditions//log//log'+datetime.now().strftime("%Y%m%d%H%M") +'.txt'
    handler = logging.FileHandler(logpath)
    handler.setFormatter(fformat)
    LOG.addHandler(handler)

    LOG.info("=========================================================")
    LOG.info("=============== Terms and Conditions Update Log ==============")
    try:
        cb = opencbbucket()
        load_tandc()
    except:
        return 1
    finally:
        LOG.info("=========================================================")
        email_log('DWagle@fliptrx.com', 'DWagle@fliptrx.com', 'deepthi.gollapudi@nttdata.com,ssubramani@fliptrx.com,PMuthanai@fliptrx.com', 'terms Conditions Update - Completed', ['Processing of Terms and Conditions update File '+logpath, 'Terms and Conditions update'], logpath, True)
    return 0

if __name__ == '__main__':
    """
       Entry to programs
    """
    sys.exit(main())
