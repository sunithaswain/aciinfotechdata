########################################
# !/usr/bin/env python  
# title         : sclaimpresciptionmo.py
# description   : Outbound file to ScriptClaim which gives out details of routed/cancelled prescription, it is run by every minute
# author        : Disha
# date created  : 20180101
# date last modified    : 20180924 10:47
# version       : 0.1
# maintainer    : Pal
# email         : pmuthanai@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage         : python sclaimpresciptionmo.py -d GWLABS001 -t scprescription -f ScriptClaimPrescription -m draft
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  
# #######################################

import os
import sys
import socket
import time
from datetime import datetime

import zipcode
import paramiko
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery

# Added to update the system path to refer our custom packages
if __name__ == '__main__':
    import os
    import sys
    rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.append(rootdir)

import app.common.commandline as commandline
from app.common.sendgridemail import email_log
from app.common.truevault import User_Class
from app.common.scriptclaimsftp import sftptransfer,getfilemodifiedtime

cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
path = os.environ['CB_DATA']
domain,file_type,file_name,mode = commandline.main(sys.argv[1:])
updatedate = str(datetime.now())
currentdate = datetime.now()
currentdate = currentdate.strftime("%m%d%y%H%M%S")
file_name = file_name+currentdate+'.txt'
first_name = ''
last_name = ''
subject = 'ScriptClaimPrescription File Transferred Successfully'
emp_flipt_id = ''
host = socket.gethostname()
Mailorder_flag = 'Y'
def scriptclaimpresciption():
	prescount = 0
	remotepath = '/ScriptClaimPrescription'+'/'+file_name
	textfile = path+'/'+domain+'/'+file_type+'/'+file_name
	log = path+'/'+domain+'/'+file_type+'/log/'+file_name
	print('Remote Path : '+remotepath)
	print('Local Path : '+textfile)
	print('Log Path : '+log)
	datafile = open(textfile, "w")
	logfile = open(log,"w")
	carrier = 'FLIPT'
	
	logfile.write("Pres ID	 Group          CardHolderID   RL Drug Name                     Qty       B/G        Cost    Claim Type"+"\r\n")
	logfile.write('================================================================================================================'+'\r\n')
	#pulling prescriptions with Routed status where sc_routed_date is not present
	routedtab = N1QLQuery('select flipt_person_id, drug, round(tonumber(rebate_amount),2) as rebate_amount,round(tonumber(drug_cost),2) as drug_cost, rx_status, gpi, tonumber(package_size)*tonumber(quantity) as quantity , rx_flipt_person_id, prescription_id, brand_generic, routed_date, mo_contact_email, mo_contact_phone, mo_shipto_location, bin, npi, payment_option, round(round(tonumber(drug_cost),2) - round(tonumber(employee_opc),2),2) as employer_cost, round(tonumber(employee_opc),2) as employee_opc from `'+os.environ['CB_INSTANCE']+'` t WHERE type = "prescription" and npi is not missing and bin = "018570" and rx_status = "Routed" and domain = $domain_name and (sc_routed_date is missing or sc_routed_date is null or sc_routed_date IS NOT VALUED) and t.flipt_person_id in (select raw dep_flipt_person_id from `'+os.environ['CB_INSTANCE']+'` where type = "flipt_person_hierarchy") order by prescription_id',domain_name = domain)
	routedtab.adhoc = False
	routedtab.timeout = 100
	for routerow in cb.n1ql_query(routedtab):
		prescount = prescount+1
		prescription_id = str(routerow['prescription_id'])
		flipt_id = str(routerow['flipt_person_id'])
		pres_id = str(routerow['prescription_id'])
		pres_id = pres_id[14:]
		gpi_code = str(routerow['gpi'])
		#gppc = str(routerow['gppc'])
		drug_name = str(routerow['drug'])
		pharmacy_npi = str(routerow['npi'])
		pay_option = str(routerow['payment_option'])
		bin = str(routerow['bin'])
		#if bin != '018750':
		#	continue		
		qty = float(routerow['quantity'])
		qty = '%.3f' % qty
		if len(str(qty)) > 10:
			qty = 'ERROR'		
		bg = str(routerow['brand_generic'])
		costthreshold=100
		
		try:
			if routerow['rebate_amount']>0:	costthreshold=costthreshold+routerow['rebate_amount']
		except Exception as e:
			costthreshold=100

		
		#deriving brand_generic according to logic 
		bgtab = N1QLQuery('select p.multiscourcecode,cp.pricetype  from `'+os.environ['CB_INSTANCE']+'` p unnest cp_price cp where p.type = "cp_drug_price" and p.gpi = $gpi and p.drug_name = $drug limit 1',gpi = gpi_code, drug = drug_name)
		bgtab.adhoc = False
		bgtab.timeout = 100
		for bgrow in cb.n1ql_query(bgtab):
			if bgrow['pricetype'].upper().strip()=='AWP' and bgrow['multiscourcecode'] in ["N","M","O"]:
				bg='B'
			else:
				bg='G'

		
		if pay_option == 'Pay via Payroll Deduction':
			patient_pay = '0'
			calc_cost = float(routerow['employer_cost'])
		else:
			patient_pay = routerow['employee_opc']
			calc_cost = float(routerow['employer_cost'])
		
		
		
		rx_flipt_person_id = str(routerow['rx_flipt_person_id'])
		claim_type = 'P'


		mo_shipto_location = ''
		mo_contact_phone = ''
		mo_contact_email = ''
		address1 = ''
		address2 = ''
		city = ''
		state = ''
		zip_code = ''
		zip2 = ''
		
		#try check if prescription filled for a mail order pharmacy
		try:
				
			if len(str(routerow['mo_shipto_location'])) > 0:
				mo_shipto_location = str(routerow['mo_shipto_location'])
				mo_contact_phone = str(routerow['mo_contact_phone'])
				chdict={'-':'','.':''}	
				for k,v in chdict.items():
					mo_contact_phone=mo_contact_phone.replace(k,v)				
				mo_contact_email = str(routerow['mo_contact_email'])

				obj=User_Class(None,None)
				search_option={'full_document':True,'filter':{'domain_name':{'type':'eq','value':domain,'case_sensitive':False},'flipt_person_id':{'type':'eq','value':flipt_id,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
				att,userid = obj.search_user(search_option)
				if att!=None:
					if mo_shipto_location == 'Home':
						address1 = str(att['home_address_1'])
						address2 = ''
						city = str(att['city'])
						state = str(att['state'])
						zip_code = str(att['zip'])
						zip2 = ''
					else:
						for loc in att['locations']:
							if loc['name'].strip().lower() == mo_shipto_location:
								address1 = str(loc['street_address'])
								address2 = ''
								city = str(loc['city'])
								zip_code = str(loc['zip_code'])
								my_zip = zipcode.isequal(zip_code)
								state = my_zip.state
								zip2 = ''
		
		except KeyError:
		
			Mailorder_flag = 'N'
		#derive employee and get attributes of patient based on flipt person id
		fhierarchytab = N1QLQuery('select distinct emp_flipt_person_id from `'+os.environ['CB_INSTANCE']+'` where  type = "flipt_person_hierarchy" and domain_name = $domain_name and (emp_flipt_person_id = $rxid or dep_flipt_person_id = $rxid)',domain_name = domain, rxid = rx_flipt_person_id)
		fhierarchytab.adhoc = False
		fhierarchytab.timeout = 100
		l_flipt_flag = 0
		for empfliptrow in cb.n1ql_query(fhierarchytab):
			l_flipt_flag = 1
			emp_flipt_id = str(empfliptrow['emp_flipt_person_id'])
			obj=User_Class(None,None)
			search_option={'full_document':True,'filter':{'domain_name':{'type':'eq','value':domain,'case_sensitive':False},'flipt_person_id':{'type':'eq','value':emp_flipt_id,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
			att,userid = obj.search_user(search_option)
			if att!=None and emp_flipt_id == rx_flipt_person_id:
				group = str(att['group'])
				first_name = str(att['first_name'])
				last_name = str(att['last_name'])
				card_holder_id = emp_flipt_id + att['person_code']
				person_code = att['person_code']
				
				if mode.upper() == 'FINAL':
					cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET sc_routed_date = $rdate WHERE type = "prescription" and prescription_id = $pid',rdate =updatedate,pid = prescription_id)).execute()			
			
				datafile.write(pres_id.ljust(9)+group.ljust(15)+card_holder_id.ljust(15)+person_code.ljust(3)+last_name.ljust(25)+first_name.ljust(15)+gpi_code.ljust(14)+drug_name.ljust(100)+qty.ljust(10)+bg.ljust(1)+str(patient_pay).ljust(10)+str(calc_cost).ljust(10)+claim_type.ljust(1)+pharmacy_npi.ljust(10)+mo_contact_phone.ljust(10)+address1.ljust(25)+address2.ljust(15)+city.ljust(20)+state.ljust(2)+zip_code.ljust(5)+zip2.ljust(4)+mo_contact_email.ljust(100)+str(costthreshold).ljust(10)+"\r\n")
				
				logfile.write(pres_id.ljust(9)+group.ljust(15)+card_holder_id.ljust(15)+person_code.ljust(3)+drug_name.ljust(30)+qty.ljust(10)+bg.ljust(1)+str(patient_pay).ljust(10)+str(calc_cost).ljust(10)+claim_type.ljust(1)+pharmacy_npi.ljust(10)+mo_contact_phone.ljust(10)+address1.ljust(25)+address2.ljust(15)+city.ljust(20)+state.ljust(2)+zip_code.ljust(5)+zip2.ljust(4)+mo_contact_email.ljust(100)+str(costthreshold).ljust(10)+"\r\n")	
				
			elif att!=None and emp_flipt_id != rx_flipt_person_id:
				group = str(att['group'])
				for dep in att['dependents']:
					dep_flipt_id = str(dep['flipt_person_id'])
					if dep_flipt_id == rx_flipt_person_id:
						first_name = str(dep['first_name'])
						last_name = str(dep['last_name'])
						card_holder_id = emp_flipt_id + dep['person_code']
						person_code = dep['person_code']			
							
						if mode.upper() == 'FINAL':
							cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET sc_routed_date = $rdate WHERE type = "prescription" and prescription_id = $pid',rdate =updatedate,pid = prescription_id)).execute()			
					
						datafile.write(pres_id.ljust(9)+group.ljust(15)+card_holder_id.ljust(15)+person_code.ljust(3)+last_name.ljust(25)+first_name.ljust(15)+gpi_code.ljust(14)+drug_name.ljust(100)+qty.ljust(10)+bg.ljust(1)+str(patient_pay).ljust(10)+str(calc_cost).ljust(10)+claim_type.ljust(1)+pharmacy_npi.ljust(10)+mo_contact_phone.ljust(10)+address1.ljust(25)+address2.ljust(15)+city.ljust(20)+state.ljust(2)+zip_code.ljust(5)+zip2.ljust(4)+mo_contact_email.ljust(100)+str(costthreshold).ljust(10)+"\r\n")
						
						logfile.write(pres_id.ljust(9)+group.ljust(15)+card_holder_id.ljust(15)+person_code.ljust(3)+drug_name.ljust(30)+qty.ljust(10)+bg.ljust(1)+str(patient_pay).ljust(10)+str(calc_cost).ljust(10)+claim_type.ljust(1)+pharmacy_npi.ljust(10)+mo_contact_phone.ljust(10)+address1.ljust(25)+address2.ljust(15)+city.ljust(20)+state.ljust(2)+zip_code.ljust(5)+zip2.ljust(4)+mo_contact_email.ljust(100)+str(costthreshold).ljust(10)+"\r\n")
			else:
				logfile.write('Attributes not found for Flipt Person ID : '+emp_flipt_id)
				continue
		if l_flipt_flag == 0:
			logfile.write('Employee Flipt Person ID not found in Employee Hierarchy for Prescription rx_flipt_person_id : '+rx_flipt_person_id+"\r\n")
	#print(prescount)
	#pull prescriptions with Cancelled status
	canceltab = N1QLQuery('select flipt_person_id, drug, round(tonumber(drug_cost),2) as drug_cost, rx_status, gpi,tonumber(package_size)*tonumber(quantity) as quantity , rx_flipt_person_id, prescription_id, brand_generic,cancelled_date, mo_contact_email, mo_contact_phone, mo_shipto_location,bin,npi,payment_option, round(round(tonumber(drug_cost),2) - round(tonumber(employee_opc),2),2) as employer_cost , round(tonumber(employee_opc),2) as employee_opc from `'+os.environ['CB_INSTANCE']+'` t WHERE type = "prescription" and rx_status = "Cancelled" and bin = "018570" and npi is not missing and domain = $domain_name and (sc_cancelled_date is missing or sc_cancelled_date is null or sc_cancelled_date IS NOT VALUED) and t.flipt_person_id in (select raw dep_flipt_person_id from `'+os.environ['CB_INSTANCE']+'` where type = "flipt_person_hierarchy") order by prescription_id',domain_name = domain )
	canceltab.adhoc = False
	canceltab.timeout = 100
	for cancelrow in cb.n1ql_query(canceltab):
		prescription_id = str(cancelrow['prescription_id'])	
		pres_id = str(cancelrow['prescription_id'])
		flipt_id = str(cancelrow['flipt_person_id'])
		pres_id = pres_id[14:]
		gpi_code = str(cancelrow['gpi'])
		drug_name = str(cancelrow['drug'])
		drug_name = drug_name[0:99]
		qty = float(cancelrow['quantity'])
		pharmacy_npi = str(cancelrow['npi'])
		pay_option = str(cancelrow['payment_option'])		
		bin = str(cancelrow['bin'])
		costthreshold=100
		try:
			if routerow['rebate_amount']>0:	costthreshold=costthreshold+routerow['rebate_amount']
		except Exception as e:
			costthreshold=100
		qty = '%.3f' % qty
		if len(str(qty)) > 10:
			qty = 'ERROR'
		bg = str(cancelrow['brand_generic'])
		#derive brand generic according to logic
		bgtab = N1QLQuery('select p.multiscourcecode,cp.pricetype  from `'+os.environ['CB_INSTANCE']+'` p unnest cp_price cp where p.type = "cp_drug_price" and p.gpi = $gpi and p.drug_name = $drug limit 1',gpi = gpi_code, drug = drug_name)
		bgtab.adhoc = False
		bgtab.timeout = 100
		for bgrow in cb.n1ql_query(bgtab):
			if bgrow['pricetype'].upper().strip()=='AWP' and bgrow['multiscourcecode'] in ["N","M","O"]:
				bg='B'
			else:
				bg='G'			
		if pay_option == 'Pay via Payroll Deduction':
			patient_pay = '0'
			calc_cost = float(cancelrow['employer_cost'])
		else:
			patient_pay = cancelrow['employee_opc']
			calc_cost = float(cancelrow['employer_cost'])
			
		rx_flipt_person_id = str(cancelrow['rx_flipt_person_id'])
		claim_type = 'X'

		mo_shipto_location	= ''
		mo_contact_phone = ''
		mo_contact_email = ''
		address1 = ''
		address2 = ''
		city = ''
		state = ''
		zip_code = ''
		zip2 = ''	
		#check if prescription was for mail order pharmacy
		try:
				
			if len(str(cancelrow['mo_shipto_location'])) > 0:
				mo_shipto_location = str(cancelrow['mo_shipto_location'])
				mo_contact_phone = str(cancelrow['mo_contact_phone'])
				chdict={'-':'','.':''}	
				for k,v in chdict.items():
					mo_contact_phone=mo_contact_phone.replace(k,v)				
				mo_contact_email = str(cancelrow['mo_contact_email'])

				obj=User_Class(None,None)
				search_option={'full_document':True,'filter':{'domain_name':{'type':'eq','value':domain,'case_sensitive':False},'flipt_person_id':{'type':'eq','value':flipt_id,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
				att,userid = obj.search_user(search_option)
				if att!=None:
					if mo_shipto_location == 'Home':
						address1 = str(att['home_address_1'])
						address2 = ''
						city = str(att['city'])
						state = str(att['state'])
						zip_code = str(att['zip'])
						zip2 = ''
					else:
						for loc in att['locations']:
							if loc['name'].strip().lower() == mo_shipto_location:
								address1 = str(loc['street_address'])
								address2 = ''
								city = str(loc['city'])
								zip_code = str(loc['zip_code'])
								my_zip = zipcode.isequal(zip_code)
								state = my_zip.state
								zip2 = ''
		
		except KeyError:
		
			Mailorder_flag = 'N'

		#derive employee and patient attributes based on flipt person id
		fhierarchytab = N1QLQuery('select distinct emp_flipt_person_id from `'+os.environ['CB_INSTANCE']+'` where  type = "flipt_person_hierarchy" and domain_name = $domain_name and (emp_flipt_person_id = $rxid or dep_flipt_person_id = $rxid)',domain_name = domain, rxid = rx_flipt_person_id)
		fhierarchytab.adhoc = False
		fhierarchytab.timeout = 100
		lc_flipt_flag = 0
		for empfliptrow in cb.n1ql_query(fhierarchytab):
			emp_flipt_id = str(empfliptrow['emp_flipt_person_id'])
			lc_flipt_flag = 1
			obj=User_Class(None,None)
			search_option={'full_document':True,'filter':{'domain_name':{'type':'eq','value':domain,'case_sensitive':False},'flipt_person_id':{'type':'eq','value':emp_flipt_id,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
			att,userid = obj.search_user(search_option)
			if att!=None and emp_flipt_id == rx_flipt_person_id:
				#group = 'GWALL'
				group = str(att['group'])
				first_name = str(att['first_name'])
				first_name = first_name[0:14]
				last_name = str(att['last_name'])
				last_name = last_name[0:24]
				card_holder_id = emp_flipt_id + att['person_code']
				person_code = att['person_code']
				
						
				if mode.upper() == 'FINAL':
					cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET sc_cancelled_date = $cdate WHERE type = "prescription" and prescription_id = $pid',cdate =updatedate,pid = prescription_id)).execute()	
				
				
				datafile.write(pres_id.ljust(9)+group.ljust(15)+card_holder_id.ljust(15)+person_code.ljust(3)+last_name.ljust(25)+first_name.ljust(15)+gpi_code.ljust(14)+drug_name.ljust(100)+qty.ljust(10)+bg.ljust(1)+str(patient_pay).ljust(10)+str(calc_cost).ljust(10)+claim_type.ljust(1)+pharmacy_npi.ljust(10)+mo_contact_phone.ljust(10)+address1.ljust(25)+address2.ljust(15)+city.ljust(20)+state.ljust(2)+zip_code.ljust(5)+zip2.ljust(4)+mo_contact_email.ljust(100)+str(costthreshold).ljust(10)+"\r\n")
				
				logfile.write(pres_id.ljust(9)+group.ljust(15)+card_holder_id.ljust(15)+person_code.ljust(3)+drug_name.ljust(30)+qty.ljust(10)+bg.ljust(1)+str(patient_pay).ljust(10)+str(calc_cost).ljust(10)+claim_type.ljust(1)+pharmacy_npi.ljust(10)+mo_contact_phone.ljust(10)+address1.ljust(25)+address2.ljust(15)+city.ljust(20)+state.ljust(2)+zip_code.ljust(5)+zip2.ljust(4)+mo_contact_email.ljust(100)+str(costthreshold).ljust(10)+"\r\n")
				
			elif att!=None and emp_flipt_id != rx_flipt_person_id:
				group = str(att['group'])
				for dep in att['dependents']:
					dep_flipt_id = str(dep['flipt_person_id'])
					if dep_flipt_id == rx_flipt_person_id:
						first_name = str(dep['first_name'])
						last_name = str(dep['last_name'])
						card_holder_id = emp_flipt_id + dep['person_code']
						person_code = dep['person_code']					

						if mode.upper() == 'FINAL':
							cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET sc_cancelled_date = $cdate WHERE type = "prescription" and prescription_id = $pid',cdate =updatedate,pid = prescription_id)).execute()	
						
						
						datafile.write(pres_id.ljust(9)+group.ljust(15)+card_holder_id.ljust(15)+person_code.ljust(3)+last_name.ljust(25)+first_name.ljust(15)+gpi_code.ljust(14)+drug_name.ljust(100)+qty.ljust(10)+bg.ljust(1)+str(patient_pay).ljust(10)+str(calc_cost).ljust(10)+claim_type.ljust(1)+pharmacy_npi.ljust(10)+mo_contact_phone.ljust(10)+address1.ljust(25)+address2.ljust(15)+city.ljust(20)+state.ljust(2)+zip_code.ljust(5)+zip2.ljust(4)+mo_contact_email.ljust(100)+str(costthreshold).ljust(10)+"\r\n")
						
						logfile.write(pres_id.ljust(9)+group.ljust(15)+card_holder_id.ljust(15)+person_code.ljust(3)+drug_name.ljust(30)+qty.ljust(10)+bg.ljust(1)+str(patient_pay).ljust(10)+str(calc_cost).ljust(10)+claim_type.ljust(1)+pharmacy_npi.ljust(10)+mo_contact_phone.ljust(10)+address1.ljust(25)+address2.ljust(15)+city.ljust(20)+state.ljust(2)+zip_code.ljust(5)+zip2.ljust(4)+mo_contact_email.ljust(100)+str(costthreshold).ljust(10)+"\r\n")
					
			else:
				logfile.write('Attributes not found for Flipt Person ID : '+emp_flipt_id)
				continue	
		if lc_flipt_flag == 0:
			logfile.write('Employee Flipt Person ID not found in Employee Hierarchy for Prescription rx_flipt_person_id : '+rx_flipt_person_id+"\r\n")
	datafile.close()
	
	# SFTP
	if mode.upper() == 'FINAL':
		filesize = os.path.getsize(textfile)
		print(filesize)
		getfilemodifiedtime('/'+remotepath.split('/')[1])
		
		if filesize > 0:
			status = sftptransfer(textfile,remotepath,'PUT')
			print(status)
			if status != 'S':
				logfile.write('File transfer failed !!! Please reprocess the File : '+file_name)
				logfile.close()
				subject = 'Script Claim Prescription File Transfer Failed - '+host
				email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','SSubramani@GWLabs.com',subject,['Processing of ScriptClaim Prescription File '+log,'ScriptClaim Prescription Exception'],log,True)
			else:
				os.remove(textfile)
				logfile.close()
				subject = 'Script Claim Prescription File Transferred Successfully'
				email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','SSubramani@GWLabs.com',subject,['Processing of ScriptClaim Prescription File '+log,'ScriptClaim Prescription Exception'],log,True)
		else:
			os.remove(textfile)
			logfile.close()
			os.remove(log)
			#subject = 'Script Claim Prescription - No Prescriptions found :'+host
			#email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','SSubramani@GWLabs.com',subject,['Processing of ScriptClaim Prescription File '+log,'ScriptClaim Prescription Exception'],log,True)
	else:
		logfile.write('Script Claim Prescription - Draft Mode :'+host+file_name)
		logfile.close()
		subject = 'Script Claim Prescription - Draft Mode :'+host
		email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','SSubramani@GWLabs.com',subject,['Processing of ScriptClaim Prescription File '+log,'ScriptClaim Prescription Exception'],log,True)
		
scriptclaimpresciption()			
