########################################
# !/usr/bin/env python 

# title : domainupdate.py
# description : Update domain data
# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  (dummy)python domainupdate.py -d GWLABS001 -t domainupdate -f appmessages.csv -m DRAFT
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(rootdir)
   
import pandas as pd
from couchbase.n1ql import N1QLQuery
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
import os
import sys
from datetime import datetime
from couchbase import FMT_JSON
import socket

from app.common.sendgridemail import email_log
import app.common.commandline as commandline

domain_name,file_type,file_name,mode=commandline.main(sys.argv[1:])
cluster=Cluster(os.environ['CB_URL']+'?operation_timeout=2700')
auth=PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(auth)
bucket_name=os.environ['CB_INSTANCE']
cb=cluster.open_bucket(bucket_name)


domain=pd.read_csv(os.environ['CB_DATA']+'//'+file_type+'//'+file_name,dtype=str)
domain['zip']=domain['zip'].apply(lambda x: str(x).zfill(5))
query=N1QLQuery('SELECT META().id as id,domain,create_date FROM `'+bucket_name+'` WHERE type="domain"')
query.timeout=7200
meta_ids=[]
domains=pd.DataFrame()
for r in cb.n1ql_query(query):
	meta_ids.append(r['id'])
	domains=domains.append({'domain':r['domain'],'create_date':r['create_date']},ignore_index=True)

# modified by Hari on 27/12/2018
path = os.environ['CB_DATA']
host = socket.gethostname()
currentdate = datetime.now()
currentdate = currentdate.strftime("%m%d%y%H%M%S")

if mode.strip().upper() == 'FINAL':
	ite=-1
	for i,r in domain.iterrows():
		ite=ite+1
		d={}
		d['type']='domain'
		for c in list(domain):
			d[c.lower().replace(' ','_')]=str(r[c])
		d['price_source']=d['price_source'].split(',')
		d['payment_options']=d['payment_options'].split(',')
		d['reward_options']=d['reward_options'].split(',')
		d['updated_by']='System'
		d['created_by']='System'
		if 'domain' in list(domains) and d['domain'] in list(domains['domain']):
			d['create_date']=domains[domains['domain']==d['domain']]['create_date'].values[0]  
		else: d['create_date']=str(datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())
		d['update_date']=str(datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())
		
		
		if ite<len(meta_ids):
			cb.upsert(str(meta_ids[ite]),d, format=FMT_JSON)
			
		else:
			cb.upsert(str(cb.counter('docid',delta=1).value),d, format=FMT_JSON)
	if ite+1<len(meta_ids):
		for h in range(ite+1,len(meta_ids)):
			cb.remove(meta_ids[h],quiet=True)

else:
	log = path+'/'+domain_name+'/'+file_type+'/log/'+"domainjson"+currentdate+'.txt'
	logfile = open(log,"w")
	logfile.write(' domain from json update - Draft Mode :'+host+file_name)
	print("File run on DRAFT mode")
	subject = 'domain from json update - Draft Mode :'+host
	logfile.close()
	email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','SSubramani@GWLabs.com',subject,['domain from json File '+log,'domain from json Exception'],log,True)
	
