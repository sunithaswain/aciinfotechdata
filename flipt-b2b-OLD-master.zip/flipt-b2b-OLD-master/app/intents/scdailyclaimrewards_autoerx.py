########################################
# !/usr/bin/env python 

# title : scdailyclaimrewards_autoerx.py
# description : "Inbound file from ScriptClaim getting details 
				# about status of a prescription transaction being
				# filled/reversed/rejected by a pharmacy and 
				# more such processing details."


# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  python scdailyclaimrewards_autoerx.py -d GWLABS001 -t scdailyclaim -f SCS -m DRAFT
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(rootdir)
   
import json
import base64
import pprint
import shutil
import os
import sys, traceback
import paramiko
import time
from datetime import timedelta
from datetime import datetime
import dateutil.parser as parser
import socket
import requests
from requests.auth import HTTPBasicAuth

from types import SimpleNamespace as Namespace
import pandas as pd
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from couchbase import FMT_JSON

import app.common.commandline as commandline
from app.common.sendgridemail import email_log,email_log_custom
from app.common.truevault import User_Class
from app.common.scriptclaimsftp import sftptransfer, fileexists, multiplefilesftptransfer
from app.common.autoerxcreation import create_erxcard
from app.common.twilioSendSMS import sendSMS
from app.drugprice.getdrugpricesV1 import get_drugprices

url = os.environ['GRAPHQL_URL']
host = socket.gethostname()
cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
path = os.environ['CB_DATA']
domain,file_type,file_name,mode = commandline.main(sys.argv[1:])
currentdate = datetime.now()
displaydatetime = currentdate.strftime("%Y%m%d%H%M")
currentdate = currentdate.isoformat()
remotepath = '/DailyClaimFile'
archivepath = '/DailyClaimFileArchive/'
localpath = path+'/'+domain+'/'+file_type+'/'
archivefile = path+'/'+domain+'/'+file_type+'/archive/'
transferstatus = ''
loadtype = 'I'
updatecount = 0
 
def scriptclaimdailyclaim():
	# FTP 
	files = []
	files,transferstatus = multiplefilesftptransfer(remotepath,localpath,'GET')
	print(transferstatus)
	
	if transferstatus == 'S':
		#email_log('DWagle@fliptrx.com','DWagle@fliptrx.com','SSubramani@fliptrx.com','Script Claim Daily Claim -Initiated',['Processing of Script Claim Daily Claim files '],None,False)
		for filename in files:
			filepath = localpath+filename
			claimnum=1
			#read file according to file format provided by script claim
			with open (filepath, 'rt') as in_file:
				
				for dcrow in in_file:
					try:
						archive_status = ''
						error_prescription = ''
						rec_status = 'INSERT'
						rewardsid = ''
						claim_status = ''
						rx_id = ''
						dcrecs = {}
						log = path+'/'+domain+'/'+file_type+'/log/'+filename+'_'+str(claimnum)+'.txt'
						claimnum=claimnum+1
						logfile = open(log,"w")
						logfile.write("=========================================================="+"\r\n")
						logfile.write("================== Daily Claim Report ===================="+"\r\n")		
						logfile.write("=========================================================="+"\r\n")
						prescription_status = ''
						prescount = 0
						rxcui = ''
						history_id = ''
						customercareactionmsg=set()
						claim_date = dcrow[0:20]
						if len(str(claim_date).strip()) == 0:
							continue
						auth_id = dcrow[20:40]
						claim_type = dcrow[40:41]
						rx_number = dcrow[41:53]
						bin = dcrow[53:59]
						pcn = dcrow[59:69]
						carrier = dcrow[69:78]
						account = dcrow[78:87]
						group = dcrow[87:102]
						member_id = dcrow[102:120]
						patient_first_name = dcrow[120:135]
						patient_last_name = dcrow[135:160]
						person_code = dcrow[160:163]
						rel_code = dcrow[163:164]
						date_of_service = dcrow[164:172]
						patient_age = dcrow[172:175]
						dob = dcrow[175:183]
						gender = dcrow[183:184]
						pharmacy_npi = dcrow[184:199]
						pharmacy_ncpdp = dcrow[199:206]
						pharmacy_name = dcrow[206:256]
						network_id = dcrow[256:265]
						ing_cost_paid = dcrow[265:273]
						disp_fee_paid = dcrow[273:281]
						amt_paid_to_pharmacy = dcrow[281:289]
						sales_tax_paid = dcrow[289:297]
						patient_paid = dcrow[297:305]
						client_ing_cost = dcrow[305:313]
						client_disp_fee = dcrow[313:321]
						client_due_amt = dcrow[321:329]
						client_mac_price = dcrow[329:341]
						pharmacy_mac_price = dcrow[341:353]
						fill_number = dcrow[353:355]
						formulary_status = dcrow[355:356]
						prescriber_npi = dcrow[356:371]
						prescriber_last_name = dcrow[371:396]
						prescriber_first_name = dcrow[396:411]
						product_name_full = dcrow[411:561]
						product_id_ndc = dcrow[561:572]
						gpi_code = dcrow[572:586]
						manuf_abr = dcrow[586:636]
						quantity_dispensed = dcrow[636:645]
						days_supply = dcrow[645:648]
						multisource_code = dcrow[648:649]
						otc_indicator = dcrow[649:650]
						awp_unit = dcrow[650:662]
						submitted_uc = dcrow[662:670]
						submitted_ing_cost = dcrow[670:678]
						submitted_disp_fee = dcrow[678:686]
						submitted_gross_due = dcrow[686:694]
						submitted_sales_tax = dcrow[694:702]
						transaction_id = dcrow[702:714]
						rejection_reason = dcrow[714:]
						claim_flipt_person_id = ''

						claim_date = parser.parse(claim_date)
						filled_dt = claim_date
						claim_date = claim_date.isoformat()
						dcrecs['claim_date'] = claim_date.strip()
						dcrecs['auth_id'] = auth_id.strip()
						dcrecs['claim_type'] = claim_type.strip()
						dcrecs['rx_number'] = rx_number.strip() 
						dcrecs['bin'] = bin.strip()
						dcrecs['pcn'] = pcn.strip()
						dcrecs['carrier'] = carrier.strip()
						dcrecs['account'] = account.strip()
						dcrecs['group'] = group.strip()
						dcrecs['member_id'] = member_id.strip()
						dcrecs['patient_first_name'] = patient_first_name.strip()
						dcrecs['patient_last_name'] = patient_last_name.strip()
						dcrecs['person_code'] = person_code.strip()
						dcrecs['rel_code'] = rel_code.strip()
						dcrecs['date_of_service'] = date_of_service.strip()
						dcrecs['patient_age'] = patient_age.strip()
						dcrecs['dob'] = dob.strip()
						dcrecs['gender'] = gender.strip()
						dcrecs['pharmacy_npi'] = pharmacy_npi.strip()
						dcrecs['pharmacy_ncpdp'] = pharmacy_ncpdp.strip()
						dcrecs['pharmacy_name'] = pharmacy_name.strip()
						dcrecs['network_id'] = network_id.strip()
						dcrecs['ing_cost_paid'] = ing_cost_paid.strip()
						dcrecs['disp_fee_paid'] = disp_fee_paid.strip()
						dcrecs['amt_paid_to_pharmacy'] = amt_paid_to_pharmacy.strip()
						dcrecs['sales_tax_paid'] = sales_tax_paid.strip()
						dcrecs['patient_paid'] = patient_paid.strip()
						dcrecs['client_ing_cost'] = client_ing_cost.strip()
						dcrecs['client_disp_fee'] = client_disp_fee.strip()
						dcrecs['client_due_amt'] = client_due_amt.strip()
						dcrecs['client_mac_price'] = client_mac_price.strip()
						dcrecs['pharmacy_mac_price'] = pharmacy_mac_price.strip()
						dcrecs['fill_number'] = fill_number.strip()
						dcrecs['formulary_status'] = formulary_status.strip()
						dcrecs['prescriber_npi'] = prescriber_npi.strip()
						dcrecs['prescriber_last_name'] = prescriber_last_name.strip()
						dcrecs['prescriber_first_name'] = prescriber_first_name.strip()
						dcrecs['product_name_full'] = product_name_full.strip()
						dcrecs['product_id_ndc'] = product_id_ndc.strip()
						dcrecs['gpi_code'] = gpi_code.strip()
						dcrecs['manuf_abr'] = manuf_abr.strip()
						dcrecs['quantity_dispensed'] = quantity_dispensed.strip()
						dcrecs['days_supply'] = days_supply.strip()
						dcrecs['multisource_code'] = multisource_code.strip()
						dcrecs['otc_indicator'] = otc_indicator.strip()
						dcrecs['awp_unit'] = awp_unit.strip()
						dcrecs['submitted_uc'] = submitted_uc.strip()
						dcrecs['submitted_ing_cost'] = submitted_ing_cost.strip()
						dcrecs['submitted_disp_fee'] = submitted_disp_fee.strip()
						dcrecs['submitted_gross_due'] = submitted_gross_due.strip()
						dcrecs['submitted_sales_tax'] = submitted_sales_tax.strip()
						dcrecs['pharmacy_rejection_reason'] = rejection_reason.strip()
						dcrecs['create_date'] = currentdate
						dcrecs['update_date'] = currentdate
						dcrecs['created_by'] = 'ScriptClaim'
						dcrecs['updated_by'] = 'ScriptClaim'
						dcrecs['transaction_id'] = "prescription::"+str(transaction_id).strip()
						prescription_id = dcrecs['transaction_id']
						dcrecs['type'] = 'scdailyclaim'
						dcrecs['status'] = 'NEW'
						dcrecs['message'] = "Imported Successfully"
						#logfile.write(dcrow+"\r\n")
						member_id = str(member_id).strip()
						e_flipt_person_id = member_id[0:7]
						#decode processing status for the prescription
						if str(claim_type).strip() == 'P':
							claim_status = 'Processed'
						elif str(claim_type).strip() == 'X':
							claim_status = 'Cancelled'
						elif str(claim_type).strip() == 'R':
							claim_status = 'Rejected'	
						print('claim type read:',claim_type)
						if str(transaction_id).strip() == "":
							logfile.write("Flipt Prescription ID        : No Transaction # Found"+"\r\n")
						else:
							logfile.write("Flipt Prescription ID        : "+str(transaction_id).strip()+"\r\n")
						
						logfile.write("Claim date                   : "+str(filled_dt).strip()+" EST"+"\r\n")
						logfile.write("Script Claim Authorization # : "+str(auth_id).strip()+"\r\n")
						logfile.write("Pharmacy Rx Number           : "+str(rx_number).strip()+"\r\n")
						logfile.write("Claim Status                 : "+str(claim_status).strip()+"\r\n")
						logfile.write("Rejection Reason Code        : "+str(rejection_reason).strip()+"\r\n")
						logfile.write("Member ID                    : "+str(member_id).strip()+"\r\n")
						if 'cost exceeds maximum' in rejection_reason.lower(): 
							customercareactionmsg.add("Drug cost exceeds tolerance limit. Contact pricing team to investigate and then call script claims with decision.")
						
						claimtype_p=False
						claim_cdate=''
						claimtab = N1QLQuery('select status, create_date from `'+os.environ['CB_INSTANCE']+'` Where type = "scdailyclaim" and trim(transaction_id) = $pres_id',pres_id = str(prescription_id).strip())
						claimtab.adhoc = False
						claimtab.timeout = 100
						for claimcountrow in cb.n1ql_query(claimtab):
							claimstatus = claimcountrow['status']
							claim_cdate = claimcountrow['create_date']
							if claimstatus == 'SUCCESS':
								claimtype_p=True
								
						if claimtype_p: logfile.write('Rx already Processed on      : ' + str(claim_cdate) + "\r\n")
						
						claim_Person_code = '01'
						if len(member_id)==9: claim_Person_code=member_id[-2:]
						elif person_code!='': claim_Person_code=person_code
						claim_flipt_person_id = e_flipt_person_id
						claim_status = ''				
						member_status = ''
						member_coverage_end_date = ''
						userid = ''
						found=True
						obj=User_Class(None,None)
						#domain=account.strip()
						search_option={'full_document':True,'filter':{'domain_name':{'type':'eq','value':account.strip(),'case_sensitive':False},'flipt_person_id':{'type':'eq','value':e_flipt_person_id,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
						att,userid=obj.search_user(search_option)
						if att!=None:
							
							searchsuccess=False
							if att['active']==True: member_status = 'Active'
							else: member_status = 'Inactive'
							#match based on name
							if patient_first_name.lower().strip()==att['first_name'].lower().strip() and patient_last_name.lower().strip()==att['last_name'].lower().strip():
								claim_flipt_person_id = att['flipt_person_id']
								member_coverage_end_date = att['coverage_termination_date']
								searchsuccess=True
							else:
								for dep in att['dependents']:
										if patient_first_name.lower().strip()==dep['first_name'].lower().strip() and patient_last_name.lower().strip()==dep['last_name'].lower().strip():
											claim_flipt_person_id = dep['flipt_person_id']
											member_coverage_end_date = dep['coverage_termination_date']
											searchsuccess=True
							#match based on person_code if name match was unsuccessful
							if searchsuccess==False:
								customercareactionmsg.add("Patient First Name/Last Name not found in employee's family")
								if claim_Person_code.strip() == att['person_code']:
									claim_flipt_person_id = att['flipt_person_id']
									member_coverage_end_date = att['coverage_termination_date']
									searchsuccess=True
								else:
									for dep in att['dependents']:
											if claim_Person_code.strip() == dep['person_code']:
												claim_flipt_person_id = dep['flipt_person_id']
												member_coverage_end_date = dep['coverage_termination_date']
												searchsuccess=True
			
							#logfile.write('Claim Flipt Person Id : '+ claim_flipt_person_id +' Update Successfully' + "\r\n")				
						else:
							logfile.write('Unable to Find Member Flipt Person Id : '+ e_flipt_person_id + "\r\n")	
						logfile.write("Member Status                : "+str(member_status).strip()+"\r\n")
						logfile.write("Coverage End Date            : "+str(member_coverage_end_date).strip()+"\r\n")
						logfile.write("Pharmacy                     : "+str(pharmacy_name).strip()+"\r\n")
						logfile.write("Pharmacy NPI                 : "+str(pharmacy_npi).strip()+"\r\n")
						logfile.write("Pharmacy Drug Name           : "+str(product_name_full).strip()+"\r\n")
						logfile.write("Pharmacy Quantity            : "+str(quantity_dispensed).strip()+"\r\n")
						logfile.write("Claim Processor              : Script Claim"+"\r\n")
						if member_status=='Inactive':
							print('Patient/Employee is inactive')
							logfile.close()
							customercareactionmsg.add('Member Not Covered')
							emailreport(pharmacy_npi,customercareactionmsg,claim_type,filepath,filename,log)
							continue
						#patient flipt person id in scdailyclaim
						dcrecs['rx_flipt_person_id']=claim_flipt_person_id
						autorecs = dict()
						auto_prescription_id = ""
						autoerx_status = ""
						f_id = ""
						rx_f_id = ""
						gpi=""
						if mode.upper() == 'FINAL':
							rv1=cb.counter('docid',delta=1)
							rx_id= 'scdailyclaim::'+str(rv1.value)					
							cb.upsert(rx_id,dcrecs)
							
							# Call Auto eRx Function to create an eRx when eRx not Found
							if str(transaction_id).strip() == "":
								
								pcounttab = N1QLQuery('select count(gpi) as prescription_count from `'+os.environ['CB_INSTANCE']+'` t where t.type = "prescription" and t.gpi = $gpi_c and ((t.rx_status="Routed")) and t.rx_flipt_person_id = $flipt_id and t.drug_name in (Select raw b.drug_name from `'+os.environ['CB_INSTANCE']+'` b where b.type = "cp_drug_price" and b.productnamefull = $drug_full and b.gpi = $gpi_c limit 1)',gpi_c = gpi_code.strip(),flipt_id = claim_flipt_person_id,drug_full = product_name_full.strip(),pnpi = int(pharmacy_npi.strip()))
								pcounttab.adhoc = False
								pcounttab.timeout = 100
								for pcountrow in cb.n1ql_query(pcounttab):
									prescription_count = pcountrow['prescription_count']
								
								if prescription_count == 0 and str(claim_type).strip() in ['R','P']:
									autoerx_status,auto_prescription_id,autorecs,f_id,rx_f_id,errormsg = create_erxcard(rx_id,claim_flipt_person_id)
									'''
									if autoerx_status == "Success":
										if len(errormsg)==0:
											logfile.write("AutoeRx created in Routed Status: "+str(auto_prescription_id).strip()+"\r\n")
											customercareactionmsg.add("AutoeRx created : "+str(auto_prescription_id).strip()+". Follow-up with member to pick up the rX at the pharmacy.")
										else:
											logfile.write("AutoeRx created in New Status: "+str(auto_prescription_id).strip()+"\r\n")
											customercareactionmsg.add("AutoeRx created : "+str(auto_prescription_id).strip()+". Follow-up with member to confirm pick up in the Flipt App.")

									else:
										customercareactionmsg.add("Unable to create AutoeRx : "+",".join(errormsg))
									'''
									if autoerx_status == "Success":
										if 'Script for Mail Order/Specialty in New Status' in errormsg:
											logfile.write("AutoeRx created in New Status: "+str(auto_prescription_id).strip()+"\r\n")
											customercareactionmsg.add('Mail/Specialty Auto eRx created in a basket. Follow-up with member ASAP to confirm shipping address, contact details and route it to '+autorecs['pharmacy'])
										else:
											logfile.write("AutoeRx created in Routed Status: "+str(auto_prescription_id).strip()+"\r\n")
											customercareactionmsg.add("AutoeRx created : "+str(auto_prescription_id).strip()+". Follow-up with member to pick up the rX at the pharmacy.")
									else:
										customercareactionmsg.add("Unable to create AutoeRx : "+",".join(errormsg))
										logfile.write("Unable to create AutoeRx : "+",".join(errormsg)+"\r\n")
											
									#print(autorecs['quantity'])
									#print(f_id)
									#print(rx_f_id)
									dcrecs['transaction_id'] = auto_prescription_id
									cb.upsert(rx_id,dcrecs)
									#logfile.write("Daily Claim Document upserted with Auto Prescription ID "+"\r\n")
								else:
									msgtab = N1QLQuery('select prescription_id, rx_status from `'+os.environ['CB_INSTANCE']+'` t where t.type = "prescription" and t.gpi = $gpi_c and t.rx_status="Routed" and t.rx_flipt_person_id = $flipt_id and t.drug_name in (Select raw b.drug_name from `'+os.environ['CB_INSTANCE']+'` b where b.type = "cp_drug_price" and b.productnamefull = $drug_full and b.gpi = $gpi_c limit 1) order by create_date desc limit 1',gpi_c = gpi_code.strip(),flipt_id = claim_flipt_person_id,drug_full = product_name_full.strip(), pnpi = int(pharmacy_npi.strip()))
									msgtab.adhoc = False
									msgtab.timeout = 100
									for msgrow in cb.n1ql_query(msgtab):
										auto_p_id = msgrow['prescription_id']
										auto_rx_status = msgrow['rx_status']												
										dcrecs['status'] = 'WARNING' 
										
										logfile.write("Claim Status                 : "+"WARNING"+ "\r\n")
										if auto_rx_status=='Routed':
											if str(claim_type).strip() == 'P':
												cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET rx_status = "Filled",auth_id = $last_auth_id,dispensed_qty = $dispensed_qty,patient_paid = $p_paid, filled_date = $filled_date, update_date = $update_date, updated_by = $updated_by,claim_status = "SUCCESS", claim_message = "Pharmacy Filled the eRx" WHERE type = "prescription" and prescription_id = $pres_id',p_paid = str(patient_paid),pres_id = str(auto_p_id).strip(),update_date = str(currentdate),updated_by = 'ScriptClaim',filled_date = str(claim_date),dispensed_qty = str(quantity_dispensed).strip(),last_auth_id = auth_id.strip())).execute()
												dcrecs['message'] = "Already Routed Auto erx# "+auto_p_id+" is used to fill the prescription."
												customercareactionmsg.add("Already Routed Auto erx# "+auto_p_id+" is used to fill the prescription.")
											else:
												customercareactionmsg.add("New eRx# "+auto_p_id+" already routed to script claims. Follow-up with script claims.")
												print('unsetting sc_routed_date')
												cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` UNSET sc_routed_date WHERE type = "prescription" and prescription_id = $pres_id and rx_status="Routed"',pres_id = str(auto_p_id).strip())).execute()
												
												dcrecs['message'] = "New eRx# "+auto_p_id+" already routed to script claims. Follow-up with script claims."
										'''
										else:
											if str(claim_type).strip() == 'P':
												dcrecs['message'] = "Auto erx# "+auto_p_id+" in New Status. Route this prescription and contact IT to fill the prescription."
												customercareactionmsg.add("Auto erx# "+auto_p_id+" in New Status. Route this prescription and contact IT to fill the prescription.")
											else:	
												customercareactionmsg.add("Auto eRx# "+auto_p_id+" awaiting in app for member to confirm pick up. Follow-up with member to confirm pickup in app.")
												dcrecs['message'] = "Auto eRx# "+auto_p_id+" awaiting in app for member to confirm pick up. Follow-up with member to confirm pickup in app."
										'''
									
								
							
						
						
						
						disp_qty = float(str(quantity_dispensed).strip())
						reward_amt = 0
						rx_flipt_person_id = ''
						prescription_status = ''
						prescription_quantity = 0
						updated_drug_penalty = 0
						original_rewards = ""
						original_daysofsupply = ""
						new_employee_opc = ""
						term = ""
						ndc= ""
						pda = "" 
						form = ""
						zip_code = ""
						pharmacy_npi = str(pharmacy_npi).strip()
						package_quantity = ""
						gppc = ""
						address = ""
						pda = ""
						dosage_image = ""
						equivalent_brand = ""
						daysofsupply = "0"
						original_employee_opc = ""
						original_drug_cost= "" 
						original_baseline_cost = "" 
						original_pbm_price = "" 
						original_package_qty = "" 
						original_package_quantity = "" 
						original_package_size = ""
						original_employer_cost = ""					
						f_auth_id = ""
						plocation = ""
						pharmacyname=""
						filled_date=""
						selectednpi=""
						newprescfound=False
						# Check if Prescriptions Exists or Not and get the original prescription details
						
						prescounttab = N1QLQuery('select npi,filled_date,pharmacy,location as pharmalocation,dosage_image,equivalent_brand,prescription_id,rx_status,tonumber(rewards) as rewards,flipt_person_id, rx_flipt_person_id, ddid, drug_name, gpi, brand_generic, dosage, to_number(quantity) as quantity, package_qty,drug_cost,pbm_price, employer_cost, package_quantity,to_number(package_size) as package_size, daysofsupply ,dosage_strength ,orig_rewards ,employee_opc ,deductible_remaining , drug_penalty, gppc,search_location as location, dpa, form, zipCode, orig_employee_opc, orig_drug_cost, baseline_cost, orig_baseline_cost , orig_pbm_price , orig_package_qty , orig_package_quantity , orig_package_size ,orig_employer_cost,auth_id,preselected_npi from `'+os.environ['CB_INSTANCE']+'` Where type = "prescription" and (prescription_id = $pres_id)',pres_id = str(prescription_id).strip())
						if prescription_id=="":
							prescounttab = N1QLQuery('select filled_date,pharmacy,location as pharmalocation, dosage_image,equivalent_brand,prescription_id,rx_status,tonumber(rewards) as rewards,flipt_person_id, rx_flipt_person_id, ddid, drug_name, gpi, brand_generic, dosage, to_number(quantity) as quantity, package_qty,drug_cost,pbm_price, employer_cost, package_quantity,to_number(package_size) as package_size, daysofsupply ,dosage_strength ,orig_rewards ,employee_opc ,deductible_remaining , drug_penalty, gppc,search_location as location, dpa, form, zipCode, orig_employee_opc, orig_drug_cost, baseline_cost, orig_baseline_cost , orig_pbm_price , orig_package_qty , orig_package_quantity , orig_package_size ,orig_employer_cost,auth_id,preselected_npi from `'+os.environ['CB_INSTANCE']+'` Where type = "prescription" and (auth_id=$authid)',authid = str(auth_id).strip())
							
						prescounttab.adhoc = False
						prescounttab.timeout = 100
						
						for prescountrow in cb.n1ql_query(prescounttab):
							print(prescountrow)
							#prescount = prescountrow['prescount']
							prescription_status = prescountrow['rx_status']
							if prescription_status.lower().strip()=='new':
								newprescfound=True
								'''
								if 'preselected_npi' in prescountrow:
									customercareactionmsg.add("Auto eRx# "+prescription_id+" awaiting in app for member to confirm pick up. Follow-up with member to confirm pickup in app.")
								else:
									customercareactionmsg.add("Saved eRx# "+prescription_id+" need to be routed to pharmacy. Follow-up with member.")
								logfile.write("Prescription Status          : New \r\n")
								'''
								print("Prescription not Routed. Skipping the record.")
								break
							if 'rewards' in prescountrow:
								reward_amt = prescountrow['rewards']
							if 'orig_rewards' in prescountrow:
								original_rewards = prescountrow['orig_rewards']
							if 'orig_employee_opc' in prescountrow:
								original_employee_opc = prescountrow['orig_employee_opc']
								
							if 'original_drug_cost' in prescountrow:
								original_drug_cost = prescountrow['original_drug_cost']
							if 'original_baseline_cost' in prescountrow:
								original_baseline_cost = prescountrow['original_baseline_cost']
							if 'original_pbm_price' in prescountrow:
								original_pbm_price = prescountrow['original_pbm_price']
							if 'original_package_qty' in prescountrow:
								original_package_qty = prescountrow['original_package_qty']
							if 'original_package_quantity' in prescountrow:
								original_package_quantity = prescountrow['original_package_quantity']
							if 'original_package_size' in prescountrow:
								original_package_size = prescountrow['original_package_size']
							if 'original_employer_cost' in prescountrow:
								original_employer_cost = prescountrow['original_employer_cost']
							if 'auth_id' in prescountrow:
								f_auth_id = prescountrow['auth_id']			
							if "filled_date" in prescountrow:
								filled_date = prescountrow['filled_date']
							rx_flipt_person_id = prescountrow['rx_flipt_person_id']
							ddid = prescountrow['ddid']
							drug_name = prescountrow['drug_name']
							gpi = prescountrow['gpi']
							brand_generic = prescountrow['brand_generic']
							dosage = prescountrow['dosage']
							drug_cost = prescountrow['drug_cost']
							if 'pbm_price' in prescountrow: pbm_price = prescountrow['pbm_price']
							quantity = prescountrow['quantity']
							package_qty = prescountrow['package_qty']
							package_size = prescountrow['package_size']
							daysofsupply = prescountrow['daysofsupply']
							dosage_strength = prescountrow['dosage_strength']
							flipt_person_id = prescountrow['flipt_person_id']
							employee_opc = prescountrow['employee_opc']
							employer_cost = prescountrow['employer_cost']
							baseline_cost = prescountrow['baseline_cost']
							package_quantity = prescountrow['package_quantity']
							gppc = prescountrow['gppc']
							address = prescountrow['location']
							pda = prescountrow['dpa']
							form = prescountrow['form']
							zip_code = prescountrow['zipCode']
							pharmacyname = prescountrow['pharmacy']
							plocation = prescountrow['location']
							selectednpi = prescountrow['npi']
							if 'dosage_image' in prescountrow:
								dosage_image = prescountrow['dosage_image']
							if 'equivalent_brand' in prescountrow:
								equivalent_brand = prescountrow['equivalent_brand']
							prescription_id=prescountrow['prescription_id']
							print('presc found',prescountrow['prescription_id'],prescription_status)
							
							prescription_quantity = package_size * quantity
							logfile.write("eRx Drug Name                : "+str(drug_name+" "+dosage+" "+dosage_strength)+"\r\n")
							logfile.write("eRx Quantity                 : "+str(float(package_size)*float(quantity))+"\r\n")
							logfile.write("Current Prescription Status  : "+prescription_status+ "\r\n")
						
						if newprescfound==True:
							print('New Status prescription')
							logfile.close()
							emailreport(pharmacy_npi,customercareactionmsg,claim_type,filepath,filename,log)
							continue
						print('Continuing Ahead')
						emp_flipt_person_id = ''
						emptab = N1QLQuery('select distinct emp_flipt_person_id from `'+os.environ['CB_INSTANCE']+'` Where type = "flipt_person_hierarchy" and dep_flipt_person_id = $person_id',person_id = str(rx_flipt_person_id).strip())
						emptab.adhoc = False
						emptab.timeout = 100
						for emprow in cb.n1ql_query(emptab):
							emp_flipt_person_id = emprow['emp_flipt_person_id']
							print('Employee Flipt Person ID',emp_flipt_person_id)
						if prescription_status != "":
							
							if emp_flipt_person_id != e_flipt_person_id:
								logfile.write("Claim Status                 : "+"ERROR"+ "\r\n")
								logfile.close()
								print("Employee Name doesn't match with Prescription Employee")
								customercareactionmsg.add("Employee Name doesn't match with Prescription Employee. Contact member.")
								emailreport(pharmacy_npi,customercareactionmsg,claim_type,filepath,filename,log)
								continue
								
							if gpi != str(gpi_code).strip():
								logfile.write("Claim Status                 : "+"ERROR"+ "\r\n")
								logfile.close()
								print("Drug Name Doesn't match with Prescription Drug Name.")
								customercareactionmsg.add("Drug Name Doesn't match with Prescription Drug Name. Contact ScriptClaim. ")
								emailreport(pharmacy_npi,customercareactionmsg,claim_type,filepath,filename,log)
								continue
						
						# Calculate Days of Supply based on Actual Days of Supply
						updated_days_of_supply = 0
						updated_employee_opc = 0
						if str(days_supply).strip() != daysofsupply.strip() and claim_type == 'P' and prescription_status != 'Filled':
							if float(str(days_supply).strip()) >= 0 and float(str(days_supply).strip()) <= 30:
								updated_days_of_supply = 30
							elif float(str(days_supply).strip()) >= 31 and float(str(days_supply).strip()) <= 60:
								updated_days_of_supply = 60
							elif float(str(days_supply).strip()) >= 61 and float(str(days_supply).strip()) <= 90:
								updated_days_of_supply = 90
							elif float(str(days_supply).strip()) >= 91:
								updated_days_of_supply = 90
							else:
								updated_days_of_supply = float(daysofsupply)
						else:
							updated_days_of_supply = float(daysofsupply)
						print('Updated Days of Supply',updated_days_of_supply)
						#logfile.write("Updated Days of Supply       : "+str(updated_days_of_supply)+ "\r\n")
						pharmacy_name = ""
						pharmacy_city = ""
						pharmacy_address = ""
						pharmacy_zip_code = ""
						drug_price = ""
						drug_baseline_price = ""
						deductible_remaining = ""
						drug_copay = ""
						drug_employer_cost = ""
						drug_out_of_pocket = ""
						drug_reward = ""
						drug_distance = ""
						drug_duration = ""
						provider_id = ""
						pbm_price = ""
						provider_name = ""
						out_of_pocket_remaining	= ""
						actual_package_qty = ""
						actual_package_quantity = ""
						actual_package_size = ""	
						actual_quantity = ""
						actual_custom_quantity = ""
						quantities = dict()
						l_update_flag = "N"
						
						if prescription_status != "": 
							#logfile.write('Prescription Found for : ' + str(prescription_id).strip() + ' with status :' + str(prescription_status) + "\r\n")			
							print('rx qty',prescription_quantity,'dispensed qty',disp_qty)
							if prescription_quantity != disp_qty and claim_type == 'P' and prescription_status != 'Filled':						
								#print('Quantity Mismatch')
								#print("Product Name Full : "+product_name_full.strip())
								# Call Quantities Function for Recalculating Quantities Based on Dispensed Quantity
								quantities = getquantity(gpi,product_name_full.strip(),disp_qty,product_id_ndc.strip())
								try:
									actual_package_qty = quantities['package_qty']
									actual_package_quantity = quantities['package_quantity']
									actual_package_size = str(quantities['package_size'])
									actual_quantity = quantities['quantity']
									actual_custom_quantity = quantities['custom_quantity']
								except Exception as e:
									print('cannot get quantity')
								'''
								print('***************')
								print('in the main function')
								print('values passed to graphql')
								print(address)
								print(brand_generic)
								print(updated_days_of_supply)
								print(dosage)
								print(dosage_strength)
								print(drug_name)
								print(claim_flipt_person_id)
								print(form)
								print(gpi)
								print(gppc)
								print(product_id_ndc.strip())
								print(quantities['package_qty'])
								print(quantities['package_quantity'])
								print(quantities['package_size'])
								print(pda)
								print(term)
								print(zip_code)
								print(userid)
								print('***************')
								print(pharmacy_npi)	
								'''
								userid = '"'+userid+'"'
								
								pharmacy_name,pharmacy_city,pharmacy_address,pharmacy_zip_code,drug_price,drug_baseline_price,deductible_remaining,drug_copay,drug_employer_cost,drug_out_of_pocket,drug_reward,drug_distance,drug_duration,provider_id,pbm_price,provider_name,pharmacy_npi,out_of_pocket_remaining,reward_share,retail_reward,total_payment,penalty_factor,pa_flag,pa_form,pa_reason = get_drugprices(term, product_id_ndc.strip(), address, pda, gpi, form, actual_package_size, actual_package_quantity, zip_code, brand_generic, updated_days_of_supply, dosage_strength, claim_flipt_person_id, drug_name, actual_package_qty, dosage, gppc,pharmacy_npi,userid,actual_custom_quantity,False)
								if drug_price!="":
									l_update_flag = "Y"
								 
								if drug_price == "":
									
									logfile.write("Price Recalculation Error !!!!!"+ "\r\n")
									logfile.write("Claim Status                 : "+"WARNING"+ "\r\n")
									customercareactionmsg.add("Pharmacy Qty and eRx Qty doesn't match - Unable to calculate price for pharmacy quantity. Contact IT.")
									dcrecs['status'] = 'WARNING'
									dcrecs['message'] = "WARNING : Price Recalculation Error !!!!!"							
									if mode.upper() == 'FINAL': 
										cb.upsert(rx_id,dcrecs)	
									email_log_custom('DWagle@fliptrx.com','SSubramani@fliptrx.com','DWagle@fliptrx.com,Deepthi.gollapudi@nttdata.com','Price Recalculation Error',["There was a price recalculation error for the prescription "+str(prescription_id).strip()+". Please look into the issue."],None,False)
								'''
								print('pharmacy name',pharmacy_name)
								print('city',pharmacy_city)
								print(pharmacy_address)
								print(pharmacy_zip_code)
								print(drug_price)
								print(drug_baseline_price)
								print(deductible_remaining)
								print(drug_copay)
								print(drug_employer_cost)
								print(drug_out_of_pocket)
								print('reward',drug_reward)
								print(drug_distance)
								print(drug_duration)
								print(provider_id)
								print(pbm_price)
								print(provider_name)
								print(pharmacy_npi)
								print('opc',out_of_pocket_remaining)
								
								print('"'+drug_reward+'"')
								'''
								
							if reward_amt > 0 and claim_type == 'P':
								rewrec=dict()
								rewcounttab = N1QLQuery('select count(prescription_id) as rewcount, id reward_id from `'+os.environ['CB_INSTANCE']+'` Where type = "rewardtransaction" and prescription_id = $pres_id group by id',pres_id = str(prescription_id).strip())
								rewcounttab.adhoc = False
								rewcounttab.timeout = 100
								for rewcountrow in cb.n1ql_query(rewcounttab):
									rewcount = rewcountrow['rewcount']
									reward_id = rewcountrow['reward_id']
									rec_status = 'UPDATE'
									
								if rec_status == 'UPDATE':
									rewardsid = reward_id
								else:	
									rewid = cb.counter('rewardtransaction_counter',delta=1).value
									rewardsid = 'rewardtransaction::'+str(rewid)
								
								# Calculating Rewards if Dispensed Quantity is not equals to eRx Quantity.
								
								updated_reward_amt = 0
								if prescription_quantity != disp_qty:
									try:
										updated_reward_amt = float(drug_reward)
									except Exception as e:
										try:
											updated_reward_amt = int(drug_reward)
										except Exception as e:
											updated_reward_amt = reward_amt
								else:
									updated_reward_amt = reward_amt
								
								rewrec['create_date'] = currentdate
								rewrec['created_by'] = rx_flipt_person_id
								rewrec['flipt_person_id'] = claim_flipt_person_id
								rewrec['prescription_id'] = str(prescription_id).strip()
								rewrec['id'] = rewardsid
								rewrec['type'] = 'rewardtransaction'
								rewrec['update_date'] = currentdate
								rewrec['updated_by'] = rx_flipt_person_id
								rewrec['domain'] = account.strip()
								rewrec['reward_amount'] = updated_reward_amt
								rewrec['reward_date'] = currentdate
								rewrec['drug_name'] = drug_name
								
								if mode == 'FINAL':
									cb.upsert(rewardsid, rewrec,format=FMT_JSON)
									logfile.write("Rewards Inserted             : Yes" + "\r\n")
									rewardsfound=False
									rewardscheck = N1QLQuery('Select tonumber(reward_amount) reward_amount, id from `'+os.environ['CB_INSTANCE']+'` where type="rewardtransaction" and prescription_id=$pid',pid=str(prescription_id).strip())
									for rewardscheckrow in cb.n1ql_query(rewardscheck):
										rewardsfound=False
										if rewardscheckrow['reward_amount']==0:
											rewrec['reward_amount']=reward_amt
											cb.upsert(rewardsid, rewrec,format=FMT_JSON)
									if not rewardsfound and updated_reward_amt>0: cb.upsert(rewardsid, rewrec,format=FMT_JSON)
									 
									# Updating "Prescription" Document with Updated Reward Amount and Orig Reward Amount 
									if prescription_quantity != disp_qty and l_update_flag == "Y":
										cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET rewards = $rewards WHERE type = "prescription" and prescription_id = $pres_id',rewards = str(updated_reward_amt),pres_id = str(prescription_id).strip())).execute()
										cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET orig_rewards = $orig_rewards WHERE type = "prescription" and prescription_id = $pres_id and orig_rewards is missing',orig_rewards = reward_amt,pres_id = str(prescription_id).strip())).execute()
										r_reward_amt = round(float(reward_amt))
										r_u_reward_amt = round(float(updated_reward_amt))
										logfile.write("Rewards Inserted             : Yes" + "\r\n")
										logfile.write("Rewards Recalculated         : from $"+str(r_reward_amt)+" to $"+str(r_u_reward_amt)+ "\r\n")
										
										
											
							#print('claim_type:',claim_type)
						
							if claim_type == 'P':							
								print(prescription_status)
								if prescription_status == "Cancelled":
									dcrecs['status'] = 'SUCCESS'
									dcrecs['message'] = "Previously Cancelled eRx Got Filled."
									logfile.write("New Prescription Status      : "+"Filled"+ "\r\n")
									logfile.write("Claim Status                 : "+"SUCCESS"+ "\r\n")
									logfile.write("Claim Message                : "+"Previously Cancelled eRx Got Filled."+ "\r\n")
									
									if mode.upper() == 'FINAL': 
										cb.upsert(rx_id,dcrecs)

										if claim_flipt_person_id == rx_flipt_person_id:
											cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET rx_status = "Filled",auth_id = $last_auth_id,dispensed_qty = $dispensed_qty , patient_paid = $p_paid, filled_date = $filled_date, update_date = $update_date, updated_by = $updated_by,claim_status = "SUCCESS", claim_message = "Previously Cancelled eRx Got Filled." WHERE type = "prescription" and prescription_id = $pres_id',p_paid = str(patient_paid),pres_id = str(prescription_id).strip(),update_date = str(currentdate),updated_by = 'ScriptClaim',filled_date = str(claim_date),dispensed_qty = str(disp_qty),last_auth_id = auth_id.strip())).execute()
										else:
											cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET rx_status = "Filled",auth_id = $last_auth_id,dispensed_qty = $dispensed_qty,patient_paid = $p_paid, filled_date = $filled_date, update_date = $update_date, updated_by = $updated_by,rx_flipt_person_id = $c_flipt_per_id,claim_status = "SUCCESS", claim_message = "Previously Cancelled eRx Got Filled." WHERE type = "prescription" and prescription_id = $pres_id',p_paid = str(patient_paid),pres_id = str(prescription_id).strip(),update_date = str(currentdate),updated_by = 'ScriptClaim',filled_date = str(claim_date), c_flipt_per_id = claim_flipt_person_id ,dispensed_qty = str(disp_qty),last_auth_id = auth_id.strip())).execute()
											rx_flipt_person_id = claim_flipt_person_id
											logfile.write("Updated RX Flipt Person Id   : "+claim_flipt_person_id+ "\r\n")
										
										if prescription_quantity != disp_qty and l_update_flag == "Y":
											cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET employee_opc = $emp_opc, drug_cost = $drug, baseline_cost = $base, pbm_price = $pbm, package_qty = $p_qty, package_quantity = $pack_qty, package_size = $p_size,employer_cost = $employer WHERE type = "prescription" and prescription_id = $pres_id',emp_opc = str(drug_out_of_pocket),drug= drug_price,base =drug_baseline_price, employer = drug_employer_cost,pbm = pbm_price,p_qty = actual_package_qty,pack_qty = actual_package_quantity,p_size = actual_package_size ,pres_id = str(prescription_id).strip())).execute()
																
											
											cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET orig_employee_opc = $orig_opc,orig_drug_cost = $drug, orig_baseline_cost = $base, orig_pbm_price = $pbm, orig_package_qty = $p_qty, orig_package_quantity = $pack_qty, orig_package_size = $p_size,orig_employer_cost = $employer WHERE type = "prescription" and prescription_id = $pres_id and orig_employee_opc is missing',orig_opc = employee_opc,drug= drug_cost,base =baseline_cost, employer = employer_cost,pbm = pbm_price,p_qty = package_qty,pack_qty = package_quantity,p_size = package_size,pres_id = str(prescription_id).strip())).execute()
											print('updating new prices')
											#send push notif, send sms when copay/rewards is recalculated
											try:
												if float(employee_opc)!=float(drug_out_of_pocket) or float(drug_reward)!=float(reward_amt):
													message="The quantity dispensed for "+drug_name+" is different than the quantity selected in your eRx. Your reward and co-pay has been adjusted accordingly. Your reward = $"+str(drug_reward)+", Your Co-Pay = $"+str(drug_out_of_pocket)
													send_notifications(account,message,e_flipt_person_id,rx_flipt_person_id,att)
											except Exception as e:
												pass
											
										if str(days_supply).strip() != daysofsupply.strip():
											cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET daysofsupply = $dos WHERE type = "prescription" and prescription_id = $pres_id',dos = str(updated_days_of_supply),pres_id = str(prescription_id).strip())).execute()
											
											cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET orig_daysofsupply = $orig_dos WHERE type = "prescription" and prescription_id = $pres_id and orig_daysofsupply is missing',orig_dos = daysofsupply,pres_id = str(prescription_id).strip())).execute()
											
								# if Prescription Status is Routed or Filled	
								else:

									dcrecs['status'] = 'SUCCESS'
									dcrecs['message'] = "Pharmacy Filled the eRx"
									logfile.write("New Prescription Status      : "+"Filled"+ "\r\n")
									logfile.write("Claim Status                 : "+"SUCCESS"+ "\r\n")
									logfile.write("Claim Message                : "+"Pharmacy Filled the eRx"+ "\r\n")
									
									if mode.upper() == 'FINAL':
										cb.upsert(rx_id,dcrecs)
										#logfile.write("New Prescription Status      : "+"Filled"+ "\r\n")
										
										
										if claim_flipt_person_id == rx_flipt_person_id:
											cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET rx_status = "Filled",auth_id = $last_auth_id,dispensed_qty = $dispensed_qty,patient_paid = $p_paid, filled_date = $filled_date, update_date = $update_date, updated_by = $updated_by,claim_status = "SUCCESS", claim_message = "Pharmacy Filled the eRx" WHERE type = "prescription" and prescription_id = $pres_id',p_paid = str(patient_paid),pres_id = str(prescription_id).strip(),update_date = str(currentdate),updated_by = 'ScriptClaim',filled_date = str(claim_date),dispensed_qty = str(disp_qty),last_auth_id = auth_id.strip())).execute()
										else:
											
											cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET rx_status = "Filled",auth_id = $last_auth_id,dispensed_qty = $dispensed_qty,patient_paid = $p_paid, filled_date = $filled_date, update_date = $update_date, updated_by = $updated_by,rx_flipt_person_id = $c_flipt_per_id,claim_status = "SUCCESS", claim_message = "Pharmacy Filled the eRx" WHERE type = "prescription" and prescription_id = $pres_id',p_paid = str(patient_paid),pres_id = str(prescription_id).strip(),update_date = str(currentdate),updated_by = 'ScriptClaim',filled_date = str(claim_date), c_flipt_per_id = claim_flipt_person_id,dispensed_qty = str(disp_qty),last_auth_id = auth_id.strip())).execute()
											rx_flipt_person_id = claim_flipt_person_id
											logfile.write("Updated RX Flipt Person Id   : "+claim_flipt_person_id+ "\r\n")
										
										if prescription_quantity != disp_qty and l_update_flag == "Y":
											cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET employee_opc = $emp_opc, drug_cost = $drug, baseline_cost = $base, pbm_price = $pbm, package_qty = $p_qty, package_quantity = $pack_qty, package_size = $p_size,employer_cost = $employer WHERE type = "prescription" and prescription_id = $pres_id',emp_opc = str(drug_out_of_pocket),drug= drug_price,base =drug_baseline_price, employer = drug_employer_cost,pbm = pbm_price,p_qty = actual_package_qty,pack_qty = actual_package_quantity,p_size = actual_package_size ,pres_id = str(prescription_id).strip())).execute()
																
											
											cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET orig_employee_opc = $orig_opc,orig_drug_cost = $drug, orig_baseline_cost = $base, orig_pbm_price = $pbm, orig_package_qty = $p_qty, orig_package_quantity = $pack_qty, orig_package_size = $p_size,orig_employer_cost = $employer WHERE type = "prescription" and prescription_id = $pres_id and orig_employee_opc is missing',orig_opc = employee_opc,drug= drug_cost,base =baseline_cost, employer = employer_cost,pbm = pbm_price,p_qty = package_qty,pack_qty = package_quantity,p_size = package_size,pres_id = str(prescription_id).strip())).execute()
											
											print('updating new prices')
											#send push notif, send sms when copay/rewards is recalculated
											try:
												print('recalculation sms',employee_opc,drug_out_of_pocket,drug_reward,reward_amt)
												if float(employee_opc)!=float(drug_out_of_pocket) or float(drug_reward)!=float(reward_amt):
													message="The quantity dispensed for "+drug_name+" is different than the quantity selected in your eRx. Your reward and co-pay has been adjusted accordingly. Your reward = $"+str(drug_reward)+", Your Co-Pay = $"+str(drug_out_of_pocket)
													send_notifications(account,message,e_flipt_person_id,rx_flipt_person_id,att)
											except Exception as e:
												print(e)
												pass
											
										if str(days_supply).strip() != daysofsupply.strip():
											cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET daysofsupply = $dos WHERE type = "prescription" and prescription_id = $pres_id',dos = str(updated_days_of_supply),pres_id = str(prescription_id).strip())).execute()
											
											cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET orig_daysofsupply = $orig_dos WHERE type = "prescription" and prescription_id = $pres_id and orig_daysofsupply is missing',orig_dos = daysofsupply,pres_id = str(prescription_id).strip())).execute()
											
											
								#send push notif, send sms when drug is filled
								if filled_date=="":
									message="Your prescription for "+drug_name+" is being processed at "+dcrecs['pharmacy_name']+". Your eRx card will move from Pending to Filled section."
									send_notifications(account,message,e_flipt_person_id,rx_flipt_person_id,att)
											
								# Code Added for Rx History
								
								if claim_type == 'P':
									rxcuitab = N1QLQuery('select rxcui from `'+os.environ['CB_INSTANCE']+'` Where type = "drug" and drug_name = $drug and brand_generic = $brand and gpi = $gpicode limit 1',drug = drug_name, brand = brand_generic, gpicode = gpi)
									rxcuitab.adhoc = False
									rxcuitab.timeout = 100
									for rxcuirow in cb.n1ql_query(rxcuitab):
										rxcui = rxcuirow['rxcui']
									
									rxrec = dict()
									load_type = 'insert'
									#historytab = N1QLQuery('select meta().id as history_id from `'+os.environ['CB_INSTANCE']+'` Where type = "rx_history" and drug_name = "ROSUVASTATIN CALCIUM" and gpi = "39400060100310" and flipt_person_id = "1000981"',drug = drug_name.strip(), gpicode = str(gpi).strip(), rx_flipt_id = str(claim_flipt_person_id).strip())
									historytab = N1QLQuery('select meta().id as history_id from `'+os.environ['CB_INSTANCE']+'` Where type = "rx_history" and drug_name = $drug and gpi = $gpicode and flipt_person_id = $rx_flipt_id',drug = drug_name, gpicode = gpi, rx_flipt_id = claim_flipt_person_id)
									historytab.adhoc = False
									historytab.timeout = 100
									
									for historyrow in cb.n1ql_query(historytab):
										print(historyrow)
										history_id = historyrow['history_id']								
										load_type = 'update'
									#print(load_type)
									
									
									
						
									if load_type == 'insert':
										rv1=cb.counter('docid',delta=1)
										rx_id= 'rx_history::'+str(rv1.value)
									else:
										rx_id = history_id	
									
									if prescription_quantity != disp_qty:
										rxrec['package_qty'] = actual_package_qty
										rxrec['package_size'] = actual_package_size
										rxrec['quantity'] = actual_quantity
									else:
										rxrec['package_qty'] = package_qty
										rxrec['package_size'] = package_size								
										rxrec['quantity'] = quantity
									
									rxrec['domain'] = account.strip()
									rxrec['rxcui'] = rxcui
									rxrec['type'] = 'rx_history'
									rxrec['flipt_person_id'] = claim_flipt_person_id
									rxrec['ddid'] = ddid
									rxrec['drug_name'] = drug_name
									rxrec['gpi'] = gpi
									rxrec['brandorgeneric'] = brand_generic
									rxrec['form'] = dosage
									rxrec['dosage_strength'] = dosage_strength
									rxrec['dosage_image'] = dosage_image
									rxrec['equivalent_brand'] = equivalent_brand
									rxrec['npi'] = str(pharmacy_npi).zfill(10)
									#rxrec['quantity'] = quantity
									#rxrec['package_qty'] = package_qty
									#rxrec['package_size'] = package_size
									rxrec['start_date'] = str(filled_dt.isoformat())
									rxrec['daysofsupply'] = days_supply								
									filled_dt = filled_dt + timedelta(days= int(days_supply))
									rxrec['estimated_stop_date'] = str(filled_dt.isoformat())
									rxrec['currently_taking_flag'] = 'Y'
									rxrec['pharmacy_name'] = pharmacyname
									rxrec['location'] = plocation
									rxrec['ready_to_refill'] = 'N'
									rxrec['created_date'] = currentdate
									rxrec['updated_date'] = currentdate
									rxrec['created_by'] = rx_flipt_person_id
									rxrec['last_udpated_by'] = rx_flipt_person_id

									if mode == 'FINAL':
										cb.upsert(rx_id, rxrec,format=FMT_JSON)
										if load_type=='insert':
											logfile.write("Rx History Inserted          : Yes"+"\r\n")
										else:
											logfile.write("Rx History Updated           : Yes"+"\r\n")
								
							elif claim_type == 'X':
								
								# Delete the Rewards , if Exists for the Prescription
								cb.n1ql_query(N1QLQuery('delete from `'+os.environ['CB_INSTANCE']+'` WHERE type = "rewardtransaction" and prescription_id = $pres_id',pres_id = str(prescription_id).strip())).execute()
								
								#print('X',prescription_status)
								if prescription_status == 'Filled': 
								
									#print('presc auth id:',f_auth_id)
									#print('claim auth id:',auth_id.strip())
									
									if f_auth_id == "" or f_auth_id == None:
										f_auth_id = auth_id.strip()
									
									if f_auth_id != auth_id.strip():
										logfile.write("Original Filled Authorization: "+f_auth_id+"\r\n")
										logfile.write("Authorization # and Prescription ID don't match. Prescription not CANCELLED."+"\r\n")
										dcrecs['status'] = 'WARNING'
										dcrecs['message'] = "Authorization # and Prescription ID don't match. Prescription not CANCELLED."
										cb.upsert(rx_id,dcrecs)
										#print('continue',auth_id,f_auth_id)
										custombody='Script Claim tried to cancel erx # '+prescription_id+' in filled status using authorization ID '+auth_id+' . The eRx was originally filled with authorization ID '+f_auth_id+'. Contact Script claims to resolve the issue.'
										#print(custombody)
										customercareactionmsg.add(custombody)
										email_log_custom('DWagle@fliptrx.com','SSubramani@fliptrx.com','DWagle@fliptrx.com,Deepthi.gollapudi@nttdata.com','Authorization Number and Prescription ID do not match',[custombody],None,False)
										logfile.close()
										emailreport(pharmacy_npi,customercareactionmsg,claim_type,filepath,filename,log)
										continue
										
									dcrecs['status'] = 'WARNING'
									dcrecs['message'] = "Pharmacy Reversed the eRx"
									logfile.write("New Prescription Status      : "+"Routed"+ "\r\n")
									logfile.write("Claim Status                 : "+"WARNING"+ "\r\n")
									logfile.write("Claim Message                : "+"Pharmacy Reversed the eRx"+ "\r\n")
									

									if mode.upper() == 'FINAL': 
										cb.upsert(rx_id,dcrecs)
										
										if claim_flipt_person_id == rx_flipt_person_id:
											cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET rx_status = "Routed" ,dispensed_qty = $dispensed_qty, patient_paid = "0",update_date = $update_date, updated_by = $updated_by,claim_status = "WARNING", claim_message = "Pharmacy Reversed the eRx!"  WHERE type = "prescription" and (prescription_id = $pres_id or auth_id=$authid)',p_paid = '0',pres_id = str(prescription_id).strip(),update_date = currentdate,updated_by = 'ScriptClaim',cancelled_date = str(claim_date),dispensed_qty = str(disp_qty),authid=str(auth_id).strip())).execute()
										else:
											cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET rx_status = "Routed" ,dispensed_qty = $dispensed_qty, patient_paid = "0",update_date = $update_date, updated_by = $updated_by,rx_flipt_person_id = $c_flipt_per_id,claim_status = "WARNING", claim_message = "Pharmacy Reversed the eRx!" WHERE type = "prescription" and (prescription_id = $pres_id or auth_id=$authid)',p_paid = '0',pres_id = str(prescription_id).strip(),c_flipt_per_id = claim_flipt_person_id,update_date = currentdate,updated_by = 'ScriptClaim',cancelled_date = str(claim_date),dispensed_qty = str(disp_qty),authid=str(auth_id).strip())).execute()								
											
										if original_rewards != "":
											cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET rewards = $orig_rewards WHERE type = "prescription" and prescription_id = $pres_id',pres_id = str(prescription_id).strip(), orig_rewards=original_rewards)).execute()
										'''
										if original_employee_opc != "":
											print('Original OPC : '+original_employee_opc)
											
											cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET employee_opc = orig_employee_opc, drug_cost = orig_drug_cost, baseline_cost = orig_baseline_cost, pbm_price = orig_pbm_price, package_qty = orig_package_qty, package_quantity = orig_package_quantity, package_size = orig_package_size,employer_cost = orig_employer_cost WHERE type = "prescription" and prescription_id = $pres_id',pres_id = str(prescription_id).strip())).execute()'''
								
								elif prescription_status == 'Cancelled': 
									dcrecs['status'] = 'SUCCESS'
									dcrecs['message'] = "Prescription was already Cancelled"
									logfile.write("Claim Status                 : "+"SUCCESS"+ "\r\n")
									logfile.write("Claim Message                : "+"Prescription was already Cancelled"+ "\r\n")
								
								# Else Condition for Routed Status
								else:
									dcrecs['status'] = 'SUCCESS'
									dcrecs['message'] = "Prescriptions Cancelled Successfully"
									logfile.write("New Prescription Status      : "+"Cancelled"+ "\r\n")	
									logfile.write("Claim Status                 : "+"SUCCESS"+ "\r\n")
									logfile.write("Claim Message                : "+"Prescription Cancelled"+ "\r\n")

									if mode.upper() == 'FINAL': 
										cb.upsert(rx_id,dcrecs)
										#logfile.write("New Prescription Status      : "+"Cancelled"+ "\r\n")
										
										if claim_flipt_person_id == rx_flipt_person_id:
											cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET rx_status = "Cancelled",dispensed_qty = $dispensed_qty,patient_paid = $p_paid,cancelled_date = $cancelled_date, update_date = $update_date, updated_by = $updated_by,claim_status = "SUCCESS", claim_message = "Prescriptions Cancelled Successfully"  WHERE type = "prescription" and prescription_id = $pres_id',p_paid = '0',pres_id = str(prescription_id).strip(),update_date = currentdate,updated_by = 'ScriptClaim',cancelled_date = str(claim_date),dispensed_qty = str(disp_qty))).execute()
										else:
											cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET rx_status = "Cancelled",dispensed_qty = $dispensed_qty,patient_paid = $p_paid,cancelled_date = $cancelled_date, update_date = $update_date, updated_by = $updated_by,rx_flipt_person_id = $c_flipt_per_id,claim_status = "SUCCESS", claim_message = "Prescriptions Cancelled" WHERE type = "prescription" and prescription_id = $pres_id',p_paid = '0',pres_id = str(prescription_id).strip(),c_flipt_per_id = claim_flipt_person_id,update_date = currentdate,updated_by = 'ScriptClaim',cancelled_date = str(claim_date),dispensed_qty = str(disp_qty))).execute()

									
							elif claim_type == 'R':
								rejection_reason = rejection_reason.strip()
								print(claim_type,'got in')
								if prescription_status in ['Filled','Cancelled']: 


									if mode.upper() == 'FINAL': 
										cb.upsert(rx_id,dcrecs)
										
										# Call Auto eRx Function to create an eRx when eRx not Found
										if auto_prescription_id == "":
											#print(product_name_full.strip())
											#print(pharmacy_npi.strip())
											#print(gpi_code.strip())
											#print(e_flipt_person_id)
											pcounttab = N1QLQuery('select count(gpi) as prescription_count from `'+os.environ['CB_INSTANCE']+'` t where t.type = "prescription" and t.gpi = $gpi_c and ((t.rx_status="Routed")) and t.rx_flipt_person_id = $flipt_id and t.drug_name in (Select raw b.drug_name from `'+os.environ['CB_INSTANCE']+'` b where b.type = "cp_drug_price" and b.productnamefull = $drug_full and b.gpi = $gpi_c limit 1)',gpi_c = gpi_code.strip(),flipt_id = claim_flipt_person_id,drug_full = product_name_full.strip(), pnpi = int(pharmacy_npi.strip()))
											pcounttab.adhoc = False
											pcounttab.timeout = 100
											for pcountrow in cb.n1ql_query(pcounttab):
												prescription_count = pcountrow['prescription_count']
												print('count : '+str(prescription_count))
												if prescription_count == 0:									
													print(rx_id,'rxid')
													autoerx_status,auto_prescription_id,autorecs,f_id,rx_f_id,errormsg = create_erxcard(rx_id,claim_flipt_person_id)
													#print(autoerx_status)
													#print(auto_prescription_id)
													'''
													if autoerx_status == "Success":
														if len(errormsg)==0:
															logfile.write("AutoeRx created in Routed Status: "+str(auto_prescription_id).strip()+"\r\n")
															customercareactionmsg.add("AutoeRx created : "+str(auto_prescription_id).strip()+". Follow-up with member to pick up the rX at the pharmacy.")
														else:
															logfile.write("AutoeRx created in New Status: "+str(auto_prescription_id).strip()+"\r\n")
															customercareactionmsg.add("AutoeRx created in New Status: "+str(auto_prescription_id).strip()+". Follow-up with member to confirm pick up.")
													else:
														customercareactionmsg.add("Unable to create AutoeRx : "+",".join(errormsg))
													'''
													if autoerx_status == "Success":
														if 'Script for Mail Order/Specialty in New Status' in errormsg:
															logfile.write("AutoeRx created in New Status: "+str(auto_prescription_id).strip()+"\r\n")
															customercareactionmsg.add('Mail/Specialty Auto eRx created in a basket. Follow-up with member ASAP to confirm shipping address, contact details and route it to '+autorecs['pharmacy'])
														else:
															logfile.write("AutoeRx created in Routed Status: "+str(auto_prescription_id).strip()+"\r\n")
															customercareactionmsg.add("AutoeRx created : "+str(auto_prescription_id).strip()+". Follow-up with member to pick up the rX at the pharmacy.")
													else:
														customercareactionmsg.add("Unable to create AutoeRx : "+",".join(errormsg))
														logfile.write("Unable to create AutoeRx : "+",".join(errormsg)+"\r\n")
														dcrecs['transaction_id'] = auto_prescription_id
														cb.upsert(rx_id,dcrecs)
													
													#logfile.write("Daily Claim Document upserted with Auto Prescription ID "+"\r\n")
												else:
													msgtab = N1QLQuery('select prescription_id, rx_status from `'+os.environ['CB_INSTANCE']+'` t where t.type = "prescription" and t.gpi = $gpi_c and t.rx_status="Routed" and t.rx_flipt_person_id = $flipt_id and t.drug_name in (Select raw b.drug_name from `'+os.environ['CB_INSTANCE']+'` b where b.type = "cp_drug_price" and b.productnamefull = $drug_full and b.gpi = $gpi_c limit 1) order by create_date desc limit 1',gpi_c = gpi_code.strip(),flipt_id = claim_flipt_person_id,drug_full = product_name_full.strip(), pnpi = int(pharmacy_npi.strip()))
													msgtab.adhoc = False
													msgtab.timeout = 100
													for msgrow in cb.n1ql_query(msgtab):
														auto_p_id = msgrow['prescription_id']
														auto_rx_status = msgrow['rx_status']												
														dcrecs['status'] = 'WARNING'
														dcrecs['message'] = "WARNING : Script claims is using an already filled/cancelled eRx #’. Correct eRx # is" + auto_p_id + " in "+auto_rx_status+" status"
														logfile.write("Claim Status                 : "+"WARNING"+ "\r\n")
														
														if auto_rx_status=='Routed':
															customercareactionmsg.add("Script claims is using an already filled/cancelled eRx #. New eRx# "+auto_p_id+" already routed to script claims. Follow-up with script claims.")
															print('unsetting sc_routed_date')
															cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` UNSET sc_routed_date WHERE type = "prescription" and prescription_id = $pres_id and rx_status="Routed"',pres_id = str(auto_p_id).strip())).execute()
														'''
														else:
															customercareactionmsg.add("Script claims is using an already filled/cancelled eRx #. Auto eRx# "+auto_p_id+" awaiting in app for member to confirm pick up. Follow-up with member to confirm pickup in app.")
														'''
										cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET pharmacy_rejection_reason = $reason,update_date = $update_date, updated_by = $updated_by,claim_status = "WARNING : Pharmacy tried to refill or reprocess an already Filled/Cancelled eRx. Auto eRx created!" WHERE type = "prescription" and prescription_id = $pres_id',reason = rejection_reason,pres_id = str(prescription_id).strip(),update_date = currentdate,updated_by = 'ScriptClaim')).execute()
										
								# If Prescription Status is Routed
								elif prescription_status == 'Routed':
									dcrecs['status'] = 'WARNING'
									dcrecs['message'] = "eRx# "+prescription_id+" already routed to script claims."
									logfile.write("Claim Status                 : "+"WARNING"+ "\r\n")
									
									#customercareactionmsg.add("eRx# "+prescription_id+" already routed to script claims. Follow-up with script claims.")
									
									if mode.upper() == 'FINAL': 
										cb.upsert(rx_id,dcrecs)								
										cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET pharmacy_rejection_reason = $reason,update_date = $update_date, updated_by = $updated_by,claim_status = "WARNING", claim_message = "Pharmacy Rejected the eRx. Please Investigate" WHERE type = "prescription" and prescription_id = $pres_id',reason = rejection_reason,pres_id = str(prescription_id).strip(),update_date = currentdate,updated_by = 'ScriptClaim')).execute()
										
								'''
								# If Prescription Status is Cancelled		
								else:
									dcrecs['status'] = 'SUCCESS'
									dcrecs['message'] = "Pharmacy Rejected an already Cancelled eRx"
									logfile.write("Claim Status                 : "+"SUCCESS"+ "\r\n")
									logfile.write("Claim Message                : "+"Pharmacy Rejected an already Cancelled eRx"+ "\r\n")
									if mode.upper() == 'FINAL': 
										cb.upsert(rx_id,dcrecs)								
										cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET pharmacy_rejection_reason = $reason,update_date = $update_date, updated_by = $updated_by,claim_status = "SUCCESS", claim_message = "Pharmacy Rejected an already Cancelled eRx" WHERE type = "prescription" and prescription_id = $pres_id',reason = rejection_reason,pres_id = str(prescription_id).strip(),update_date = currentdate,updated_by = 'ScriptClaim')).execute()	
								'''		
															
							else:
								dcrecs['status'] = 'ERROR'
								dcrecs['message'] = "Invalid Claim Type"
								logfile.write("Claim Status   			    : "+"ERROR"+ "\r\n")
								logfile.write("Claim Message                : "+"Invalid Claim Type"+ "\r\n")							
								if mode.upper() == 'FINAL': 
									cb.upsert(rx_id,dcrecs)						
									#logfile.write("Invalid Claim Type           : "+claim_type+ "\r\n")							
						
						else:
							dcrecs['status'] = 'ERROR'
							dcrecs['message'] = "No Prescriptions Found"
							logfile.write("Claim Status                 : "+"ERROR"+ "\r\n")
							logfile.write("Claim Message                : "+"No eRx card Found"+ "\r\n")						
							if mode.upper() == 'FINAL':
								cb.upsert(rx_id,dcrecs)
								# Call Auto eRx Function to create an eRx when eRx not Found
								if auto_prescription_id == "":
									pcounttab = N1QLQuery('select count(gpi) as prescription_count from `'+os.environ['CB_INSTANCE']+'` t where t.type = "prescription" and t.gpi = $gpi_c and ((t.rx_status="Routed")) and t.rx_flipt_person_id = $flipt_id and t.drug_name in (Select raw b.drug_name from `'+os.environ['CB_INSTANCE']+'` b where b.type = "cp_drug_price" and b.productnamefull = $drug_full and b.gpi = $gpi_c limit 1)',gpi_c = gpi_code.strip(),flipt_id = claim_flipt_person_id,drug_full = product_name_full.strip(),pnpi = int(pharmacy_npi.strip()))
									pcounttab.adhoc = False
									pcounttab.timeout = 100
									for pcountrow in cb.n1ql_query(pcounttab):
										prescription_count = pcountrow['prescription_count']
										if prescription_count == 0:							
											#print(rx_id)
											autoerx_status,auto_prescription_id,autorecs,f_id,rx_f_id,errormsg = create_erxcard(rx_id,claim_flipt_person_id)
											#print(autoerx_status)
											#print(auto_prescription_id)
											'''
											if autoerx_status == "Success":
												if len(errormsg)==0:
													logfile.write("AutoeRx created in Routed Status: "+str(auto_prescription_id).strip()+"\r\n")
													customercareactionmsg.add("AutoeRx created : "+str(auto_prescription_id).strip()+". Follow-up with member to pick up the rX at the pharmacy.")
												else:
													logfile.write("AutoeRx created in Routed Status: "+str(auto_prescription_id).strip()+"\r\n")
													customercareactionmsg.add("AutoeRx created in New Status: "+str(auto_prescription_id).strip()+". Follow-up with member to confirm pick up.")
												else:
												customercareactionmsg.add("Unable to create AutoeRx : "+",".join(errormsg))
											'''
											if autoerx_status == "Success":
												if 'Script for Mail Order/Specialty in New Status' in errormsg:
													logfile.write("AutoeRx created in New Status: "+str(auto_prescription_id).strip()+"\r\n")
													customercareactionmsg.add('Mail/Specialty Auto eRx created in a basket. Follow-up with member ASAP to confirm shipping address, contact details and route it to '+autorecs['pharmacy'])
												else:
													logfile.write("AutoeRx created in Routed Status: "+str(auto_prescription_id).strip()+"\r\n")
													customercareactionmsg.add("AutoeRx created : "+str(auto_prescription_id).strip()+". Follow-up with member to pick up the rX at the pharmacy.")
											else:
												customercareactionmsg.add("Unable to create AutoeRx : "+",".join(errormsg))
												logfile.write("Unable to create AutoeRx : "+",".join(errormsg)+"\r\n")
												dcrecs['transaction_id'] = auto_prescription_id
												cb.upsert(rx_id,dcrecs)
											
											#logfile.write("Daily Claim Document upserted with Auto Prescription ID "+"\r\n")
										else:
											msgtab = N1QLQuery('select prescription_id, rx_status from `'+os.environ['CB_INSTANCE']+'` t where t.type = "prescription" and t.gpi = $gpi_c and t.rx_status="Routed" and t.rx_flipt_person_id = $flipt_id and t.drug_name in (Select raw b.drug_name from `'+os.environ['CB_INSTANCE']+'` b where b.type = "cp_drug_price" and b.productnamefull = $drug_full and b.gpi = $gpi_c limit 1) order by create_date desc limit 1',gpi_c = gpi_code.strip(),flipt_id = claim_flipt_person_id,drug_full = product_name_full.strip(), pnpi = int(pharmacy_npi.strip()))
											msgtab.adhoc = False
											msgtab.timeout = 100
											for msgrow in cb.n1ql_query(msgtab):
												auto_p_id = msgrow['prescription_id']
												auto_rx_status = msgrow['rx_status']												
												dcrecs['status'] = 'WARNING'
												#auto_p_id + " in "+auto_rx_status+" status"
												logfile.write("Claim Status                 : "+"WARNING"+ "\r\n")
												if auto_rx_status=='Routed':
													customercareactionmsg.add("New eRx# "+auto_p_id+" already routed to script claims. Follow-up with script claims.")
													print('unsetting sc_routed_date')
													cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` UNSET sc_routed_date WHERE type = "prescription" and prescription_id = $pres_id and rx_status="Routed"',pres_id = str(auto_p_id).strip())).execute()
													dcrecs['message'] = "New eRx# "+auto_p_id+" already routed to script claims. Follow-up with script claims."
												'''
												else:
													customercareactionmsg.add("Auto eRx# "+auto_p_id+" awaiting in app for member to confirm pick up. Follow-up with member to confirm pickup in app.")
													dcrecs['message'] = "Auto eRx# "+auto_p_id+" awaiting in app for member to confirm pick up. Follow-up with member to confirm pickup in app."
												'''
						if dcrecs['status'] != 'SUCCESS':
							error_prescription = error_prescription +' , '+str(prescription_id).strip()
						
						if dcrecs['status'] == 'ERROR':
							archive_status = 'ERROR'
						
						
						print('going to the next record',auth_id,f_auth_id)
						logfile.close()
						emailreport(pharmacy_npi,customercareactionmsg,claim_type,filepath,filename,log)
			
			
					
					except Exception as e:
						type, value, etraceback = sys.exc_info()
						error=dcrow+'\r\n\r\n\r\n'
						x=traceback.format_exception(type, value, etraceback)
						for i in x:
							error=error+i
						email_log_custom('noreply@fliptrx.com','dwagle@fliptrx.com','ssubramani@fliptrx.com,Deepthi.gollapudi@nttdata.com','Daily Claim Processing Error',[error],None,False)
						print(error)
			shutil.move(filepath,archivefile+filename+'.txt')
	else:
		sys.exit()	
		
def emailreport(pharmacy_npi,customercareactionmsg,claim_type,filepath,filename,log):

	logfile= open(log,"a+")
	print(log)
	logfile.write("Pharmacy Address and Phone Number : "+"https://npiregistry.cms.hhs.gov/api?number="+str(pharmacy_npi).lstrip('0').strip()+"&pretty=true"+"\r\n")
	
	errormessage=''
	status=''
	archive_status=''
	if claim_type=='P': status="Filled :"
	if claim_type=='X': status="Reversed :"
	if claim_type=='R': status="Rejected :"
	if len(customercareactionmsg)>0:
		logfile.write("**************CUSTOMER CONCIERGE ACTION ITEM**************"+"\r\n")
		for i in customercareactionmsg:
			logfile.write('• '+i+"\r\n")
			if 'Drug cost exceeds tolerance limit' in i: 
				errormessage='Error: Exceeds price tolerance'
				archive_status = 'ERROR'
			if "Employee Name doesn't match with Prescription Employee" in i: 
				errormessage="Error: Employee Name Doesn't match"
				archive_status = 'ERROR'
				status=''
			if "Drug Name Doesn't match with Prescription Drug Name" in i: 
				errormessage="Error: Drug name doesn't match"
				archive_status = 'ERROR'
				status=''
			if "Pharmacy Qty and eRx Qty doesn't match" in i: 
				errormessage="Error: Price Recalculation Error due to Qty Difference"
				archive_status = 'ERROR'
				status=''
			if "Script claims is using an already filled/canceled eRx #" in i: 
				errormessage="Error: ScriptClaim using Old Transaction ID"
				archive_status = 'ERROR'
				status=''
			if "Script Claim tried to cancel erx # " in i: 
				errormessage="Error: ScriptClaim using different Auth ID to Reverse"
				archive_status = 'ERROR'
				status=''
			if 'Unable to create AutoeRx' in i:
				errormessage="Error: Unable to Create Auto eRx"
				archive_status = 'ERROR'
				status=''
			if 'AutoeRx created :' in i or 'Already Routed' in i or 'New eRx#' in i: errormessage='AutoeRx created'
			if 'Mail/Specialty Auto eRx created in a basket' in i: errormessage='Mail/Specialty Auto eRx created'
	
	prescounttab = N1QLQuery('select x.heading, x.prescount from (select "1. Total no of Prescriptions Filled from Day 1" as heading, COUNT(prescription_id) as prescount from `'+os.environ['CB_INSTANCE']+'` t where t.type = "prescription" and t.rx_status = "Filled" and t.flipt_person_id in (select raw dep_flipt_person_id from `'+os.environ['CB_INSTANCE']+'` where type = "flipt_person_hierarchy") union select "2. Rx transactions Received from Script Claims Today" as heading, COUNT(transaction_id) as prescount from `'+os.environ['CB_INSTANCE']+'` t where t.type = "scdailyclaim" and claim_date >= DATE_TRUNC_STR(CLOCK_LOCAL(), "day")  and claim_date <= CLOCK_LOCAL("1111-11-11")||"T23:59:59" union select "3. Rx Transactions Filled by Pharmacy Today" as heading, COUNT(transaction_id) as prescount from `'+os.environ['CB_INSTANCE']+'` t where t.type = "scdailyclaim" and claim_date >= DATE_TRUNC_STR(CLOCK_LOCAL(), "day") and claim_date <= CLOCK_LOCAL("1111-11-11")||"T23:59:59" and claim_type = "P" union select "4. Rx Transactions Reversed  by Pharmacy Today" as heading, COUNT(transaction_id) as prescount from `'+os.environ['CB_INSTANCE']+'` t where t.type = "scdailyclaim" and claim_date >= DATE_TRUNC_STR(CLOCK_LOCAL(), "day") and claim_date <= CLOCK_LOCAL("1111-11-11")||"T23:59:59" and claim_type = "X" union select "Rejected Due to - "||pharmacy_rejection_reason as heading, COUNT(transaction_id) as prescount from `'+os.environ['CB_INSTANCE']+'` t where t.type = "scdailyclaim" and pharmacy_rejection_reason is not missing and claim_date >= DATE_TRUNC_STR(CLOCK_LOCAL(), "day") and claim_date <= CLOCK_LOCAL("1111-11-11")||"T23:59:59" and claim_type = "R" group by pharmacy_rejection_reason) x order by  x.heading asc')
	prescounttab.adhoc = False
	prescounttab.timeout = 100
	logfile.write("=========================================================="+"\r\n")
	logfile.write("==================== Rx statistics ======================="+"\r\n")
	logfile.write("=========================================================="+"\r\n")
	for prescountrow in cb.n1ql_query(prescounttab):
		prescount = prescountrow['prescount']
		heading = prescountrow['heading']
		logfile.write(str(heading).ljust(54)+":"+str(prescount)+ "\r\n")
	logfile.write("=========================================================="+"\r\n")
	subject = status+' Rx Claim Status Report '+ errormessage
	if archive_status != 'ERROR':
		#shutil.move(filepath,archivefile+filename+'.txt')
		logfile.write('Archived File                : '+ archivefile+filename+'.txt' + "\r\n")
		logfile.close()
		
		if os.environ['INSTANCE_TYPE'] != 'PROD':
			email_log('DWagle@fliptrx.com','DWagle@fliptrx.com','SSubramani@fliptrx.com,Deepthi.gollapudi@nttdata.com',subject,['Processing of Daily Claim File '+file_name+str(currentdate),'Daily Claim Exception'],log,True)
		elif os.environ['INSTANCE_TYPE'] == 'PROD':
			email_log('DWagle@fliptrx.com','reports@fliptrx.com',None,subject,['Processing of Daily Claim File '+file_name+str(currentdate),'Daily Claim Exception'],log,True)
			send_to = 'SPAL@fliptrx.com,DWagle@fliptrx.com,Deepthi.gollapudi@nttdata.com'
			email_log('DWagle@fliptrx.com','ssubramani@fliptrx.com',send_to,subject,['Processing of Daily Claim File '+file_name+str(currentdate),'Daily Claim Exception'],log,True)
		else:
			email_log('DWagle@fliptrx.com','DWagle@fliptrx.com','SSubramani@fliptrx.com',subject,['Processing of Daily Claim File '+file_name+str(currentdate),'Daily Claim Exception'],log,True)				
	else:
		#.write('Failed to Process Prescriptions : ' + error_prescription + "\r\n")
		logfile.close()
		
		if os.environ['INSTANCE_TYPE'] != 'PROD':
			email_log('DWagle@fliptrx.com','DWagle@fliptrx.com','SSubramani@fliptrx.com,Deepthi.gollapudi@nttdata.com',subject,['Processing of Daily Claim File '+file_name+str(currentdate),'Daily Claim Exception'],log,True)
		elif os.environ['INSTANCE_TYPE'] == 'PROD':
			email_log('DWagle@fliptrx.com','reports@fliptrx.com',None,subject,['Processing of Daily Claim File '+file_name+str(currentdate),'Daily Claim Exception'],log,True)
			send_to = 'SPAL@fliptrx.com,DWagle@fliptrx.com,Deepthi.gollapudi@nttdata.com'
			email_log('DWagle@fliptrx.com','ssubramani@fliptrx.com',send_to,subject,['Processing of Daily Claim File '+file_name+str(currentdate),'Daily Claim Exception'],log,True)						
		else:
			email_log('DWagle@fliptrx.com','DWagle@fliptrx.com','SSubramani@fliptrx.com,Deepthi.gollapudi@nttdata.com',subject,['Processing of Daily Claim File '+file_name+str(currentdate),'Daily Claim Exception'],log,True)	

def getquantity(gpi,drugfullname,dispensedquantity,ndc):

	#global errorlog
	
	result={}
	gppcfound=False
	rowindex=0
	#get drug details based on NDC
	result['gppc']=''
	query=N1QLQuery('Select gppc from `'+os.environ['CB_INSTANCE']+'` where type="ndc_drugs" and ndc=$drugndc',drugndc=ndc)
	query.adhoc=False
	for res in cb.n1ql_query(query):
		result['gppc']=res['gppc']
	#print(result)
	quantitydf=None
	
	#get drug details based on gpi and full drug name 
	
	query=N1QLQuery('Select * from `'+os.environ['CB_INSTANCE']+'` where type="drug" and gpi=$gpicode and drug_name in (Select raw b.drug_name from `'+os.environ['CB_INSTANCE']+'` b where b.type="cp_drug_price" and b.productnamefull=$drugfullname and gpi=$gpicode limit 1)',gpicode=gpi,drugfullname=drugfullname)
	result['lm_ndc']=''
	gppcfound=False
	gppcindex=-1
	drugfound=False
	for res in cb.n1ql_query(query):
		drugfound=True
		if len(res[os.environ['CB_INSTANCE']]['lm_ndc'])!=0: result['lm_ndc']=res[os.environ['CB_INSTANCE']]['lm_ndc'][0]
		result['dpa']=res[os.environ['CB_INSTANCE']]['pda']
		result['ddn_form']=res[os.environ['CB_INSTANCE']]['ddn_form']
		result['ddn_name']=res[os.environ['CB_INSTANCE']]['ddn_name']
		result['ddn_strength']=res[os.environ['CB_INSTANCE']]['ddn_strength']
		result['strengths']='nan'
		result['lm_strength']=res[os.environ['CB_INSTANCE']]['lm_strength']
		result['lm_form']=res[os.environ['CB_INSTANCE']]['lm_form']
		result['lm_name']=res[os.environ['CB_INSTANCE']]['lm_name']
		result['drug_type']=res[os.environ['CB_INSTANCE']]['drugtype']
		result['rxcui']=res[os.environ['CB_INSTANCE']]['rxcui']
		quantitydf=pd.DataFrame(data=res[os.environ['CB_INSTANCE']]['quantity'])
		result['ddid']=res[os.environ['CB_INSTANCE']]['ddid']
		result['dosage']=res[os.environ['CB_INSTANCE']]['dosage']
		result['brand_generic']=res[os.environ['CB_INSTANCE']]['brand_generic']
		result['drug_name']=res[os.environ['CB_INSTANCE']]['drug_name']
		result['specialty_flag']=res[os.environ['CB_INSTANCE']]['specialty_flag']
		
	if len(result)==0 or not drugfound:
		#errorlog=errorlog.append({'Drug Full Name':drugfullname,'GPI':gpi,'Pharmacy NPI':'','Dispensed Quantity':dispensedquantity,'MemberID':'','Error':'Drug Not Found in Drug Database'},ignore_index=True)
		return result
	
	if result['gppc'] in list(quantitydf['gppc']):
		gppcfound=True
		gppcindex=quantitydf[quantitydf['gppc']==result['gppc']].index[0]
		result['custom_qty']=quantitydf.loc[gppcindex,'custom_qty']
	else:
		result['custom_qty']=quantitydf.loc[rowindex,'custom_qty']
		
	
	quantitydf['package_size']=quantitydf['package_size'].apply(lambda x:float(x))
	result['custom_quantity']=False
	
	#get quantity details based on dispensed quantity 
	
	
	if result['custom_qty']=='package_quantity':
		if float(dispensedquantity) in list(quantitydf['package_size']):
			if gppcfound and quantitydf.loc[gppcindex,'package_size']==float(dispensedquantity):
				rowindex=gppcindex
			else:
				rowindex=quantitydf[quantitydf['package_size']==float(dispensedquantity)].index[0]
			[result['dosage_strength'],result['gppc'],result['package_desc'],result['package_qty'],result['package_quantity'],result['package_size'],result['pkg_desc_cd'],result['pkg_uom'],result['quantity_type']]=quantitydf.loc[rowindex,['dosage_strength','gppc','package_desc','package_qty','package_quantity','package_size','pkg_desc_cd','pkg_uom','quantity_type']]
			result['quantity']="1"
		else:
			#calculating new package_qty based on custom dispensed quantity
			psizefound=False
			if gppcfound:
				[result['dosage_strength'],result['gppc'],result['package_desc'],result['package_qty'],result['package_quantity'],result['package_size'],result['pkg_desc_cd'],result['pkg_uom'],result['quantity_type']]=quantitydf.loc[gppcindex,['dosage_strength','gppc','package_desc','package_qty','package_quantity','package_size','pkg_desc_cd','pkg_uom','quantity_type']]
				result['package_quantity']=str(float(dispensedquantity)/quantitydf.loc[gppcindex,'package_size'])
				result['package_qty']=str(result['package_quantity'])+" "+result['quantity_type']
				result['quantity']=result['package_quantity']
				psizefound=True
			else:
				quantitydf.sort_values(by=['package_size'],ascending=[False],inplace=True)
				for ind,row in quantitydf.iterrows():
					if float(dispensedquantity)>=row['package_size']:
						psizefound=True
						[result['dosage_strength'],result['package_desc'],result['package_quantity'],result['package_size'],result['pkg_desc_cd'],result['pkg_uom'],result['quantity_type']]=[row['dosage_strength'],row['package_desc'],str(float(dispensedquantity)/row['package_size']),row['package_size'],row['pkg_desc_cd'],row['pkg_uom'],row['quantity_type']]
						result['package_qty']=str(result['package_quantity'])+" "+result['quantity_type']
						result['quantity']=result['package_quantity']
						psizefound=True
						break
			
				
			result['custom_quantity']=True
		
	if result['custom_qty']=='package_size':
		
		if float(dispensedquantity) in list(quantitydf['package_size']):
			if gppcfound and quantitydf.loc[gppcindex,'package_size']==float(dispensedquantity):
				rowindex=gppcindex
			else:
				rowindex=quantitydf[quantitydf['package_size']==float(dispensedquantity)].index[0]
			[result['dosage_strength'],result['package_desc'],result['package_qty'],result['package_quantity'],result['package_size'],result['pkg_desc_cd'],result['pkg_uom'],result['quantity_type'],result['gppc']]=quantitydf.loc[rowindex,['dosage_strength','package_desc','package_qty','package_quantity','package_size','pkg_desc_cd','pkg_uom','quantity_type','gppc']]
			result['quantity']="1"
			
		else:
			if gppcfound:
				rowindex=gppcindex
			else:
				rowindex=0
			#updating new package_size based on custom dispensed quantity 
			[result['dosage_strength'],result['package_desc'],result['package_quantity'],result['pkg_desc_cd'],result['pkg_uom'],result['quantity_type'],result['gppc']]=quantitydf.loc[rowindex,['dosage_strength','package_desc','package_quantity','pkg_desc_cd','pkg_uom','quantity_type','gppc']]
			result['package_size']=str(float(dispensedquantity))
			result['package_qty']=str(result['package_size'])+" "+result['quantity_type']
			result['quantity']="1"
			result['custom_quantity']=True
	
	return result

	
def send_notifications(domain,message,flipt_person_id,rx_flipt_person_id,employeeatt):

	phonenumbers=[]
	flipt_id=''
	if flipt_person_id!=rx_flipt_person_id:
		obj=User_Class(None,None)
		search_option={'full_document':True,'filter':{'flipt_person_id':{'type':'eq','value':rx_flipt_person_id,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
		att,userid = obj.search_user(search_option)
		if att!=None:
			flipt_id=rx_flipt_person_id
			if "communication_option_phone" in att:
				phonenumbers.append(att['communication_option_phone'])
			if "personal_phone" in att:
				if isinstance(att['personal_phone'],list): phonenumbers.extend(att['personal_phone'])
				if isinstance(att['personal_phone'],str): phonenumbers.append(att['personal_phone'])
	elif flipt_person_id==rx_flipt_person_id or len(phonenumbers)==0:
		if "communication_option_phone" in employeeatt:
			phonenumbers.append(employeeatt['communication_option_phone'])
		if "personal_phone" in employeeatt:
			if isinstance(employeeatt['personal_phone'],list): phonenumbers.extend(employeeatt['personal_phone'])
			if isinstance(employeeatt['personal_phone'],str): phonenumbers.append(employeeatt['personal_phone'])
	sendresult=False
	#send Twilio sms
	for pn in phonenumbers:
		result,info=sendSMS(flipt_person_id,rx_flipt_person_id, pn, message)
		if result.lower()=='success': 
			sendresult=True
			break
	#if Twilio sms failure, insert message in message center
	messagecenter={}
	action={}
	if not sendresult:
		messageid=str(cb.counter('docid',delta=1).value)
		action['notification_id']=messageid
		action['sub_title']=message
		action['title']=""
		action['type']='message'
		messagecenter['action']=action
		messagecenter['create_date']=str(datetime.now().isoformat())
		messagecenter['created_by']="System"
		messagecenter['domain']=domain
		if flipt_id!='': messagecenter['flipt_person_id']=rx_flipt_person_id
		else: messagecenter['flipt_person_id']=flipt_person_id
		messagecenter['message']=""
		messagecenter['message_id']=messageid
		messagecenter['message_method']="in-app"
		messagecenter['status']="New"
		messagecenter['sub_message']=message
		messagecenter['type']="message_center"
		cb.upsert(messagecenter['message_id'],messagecenter)
		
	
		

	
scriptclaimdailyclaim()
