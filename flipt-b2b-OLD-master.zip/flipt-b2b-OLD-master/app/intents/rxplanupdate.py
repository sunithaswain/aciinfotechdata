########################################
# !/usr/bin/env python  
# title         : rxplanupdate.py
# description   : Update rxplan document from file data
# author        : Disha
# date created  : 20180101
# date last modified    : 20180720 12:16
# version       : 0.1
# maintainer    : Pal
# email         : pmuthanai@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage         : python rxplanupdate.py -d GWLABS001 -t rxplan_master -f rxplan_master01022018.xlsx -m DRAFT
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  1.1            Pal         20181212    Added mode support logic to load the data in database
#  
# #######################################

import os
import sys
from datetime import datetime

import pandas as pd
import pprint
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.n1ql import N1QLQuery
import codecs
from couchbase import FMT_JSON


# Added to update the system path to refer our custom packages
if __name__ == '__main__':
    import os
    import sys
    rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.append(rootdir)

import app.common.commandline as commandline

domain,filetype,filename,mode=commandline.main(sys.argv[1:])
cluster=Cluster(os.environ['CB_URL'])
auth=PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(auth)
cb=cluster.open_bucket(os.environ['CB_INSTANCE'])

# add log file
logpath=os.environ['CB_DATA']+'//'+domain+'//'+filetype+'//log//log'+datetime.now().strftime("%Y%m%d%H%M")+'.txt'
logfile = open(logpath,"w")
logfile.write("=============================================================="+"\r\n")
logfile.write("=============== rxplan document Update Log ================="+"\r\n")		
logfile.write("Start time is "+ str(datetime.now()) +"\r\n")

def rxplan():
        
        df=pd.DataFrame()
        rx=pd.read_excel(os.environ['CB_DATA']+'/'+domain+'/'+filetype+'/'+filename)
        logfile.write("No of records in File "+ str(rx.shape[0]) +"\r\n")
        print("No if records in file "+ str(rx.shape[0]))
        for i,r in rx.iterrows():
                d=dict()
                for c in list(rx):
                        cnew=c.replace(' ','_').lower()
                        d[cnew]=str(r[c]).encode('utf-8').decode('utf-8')

                d['type']='rxplan_master'
                print(d)
                if mode.upper().strip()=='FINAL':
                        cb.upsert(str(cb.counter('docid',delta=1).value),d, format=FMT_JSON)
rxplan()
logfile.write("End time is "+ str(datetime.now()) +"\r\n")

logfile.write("=============================================================="+"\r\n")
logfile.close()
# email_log('DWagle@fliptrx.com','DWagle@fliptrx.com','deepthi.gollapudi@nttdata.com,ssubramani@fliptrx.com,PMuthanai@fliptrx.com','rxplan Update - Completed',['Processing of rxplan update File '+logpath,'rxplan update'],logpath,True)
