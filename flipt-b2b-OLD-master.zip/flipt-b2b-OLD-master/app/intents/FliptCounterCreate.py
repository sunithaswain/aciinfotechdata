########################################
# !/usr/bin/env python 

# title : FliptCounterCreate.py
# description : Program to create incremental doc counter in couchbase

# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  python FliptCounterCreate.py 
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(rootdir)
   
import os
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
bucket_name=os.environ['CB_INSTANCE']
cb = cluster.open_bucket(bucket_name)
#cb.remove('counterid',quiet=True)
#rv=cb.counter('counterid',delta=1,initial=100000000)
cb.remove('invoicecounter',quiet=True)
rv=cb.counter('invoicecounter',delta=1,initial=1)
