########################################
# !/usr/bin/env python  
# title         : ndcdrugs.py
# description   :Update NDC drugs report
# author        : Disha
# date created  : 20180101
# date last modified    : 20181012 15:06
# version       : 0.1
# maintainer    : Pal
# email         : pmuthanai@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage         : python ndcdrugs.py -d GWLABS001 -t ndc_drugs -f ndc_drugs10122018.xlsx -m DRAFT
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  
# #######################################


# import json
import pandas as pd
import os
import sys
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
# from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from datetime import datetime

# Added to update the system path to refer our custom packages
if __name__ == '__main__':
    import os
    import sys
    rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.append(rootdir)

import app.common.commandline as commandline

cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
path = os.environ['CB_DATA']
domain,file_type,file_name,mode = commandline.main(sys.argv[1:])

# Added for log file
logpath=os.environ['CB_DATA']+'//'+domain+'//'+file_type+'//log//log'+datetime.now().strftime("%Y%m%d%H%M")+'.txt'
logfile = open(logpath,"w")
logfile.write("=============================================================="+"\r\n")
logfile.write("=============== NDC drugs Report Log ================="+"\r\n")		
logfile.write("Start time is "+ str(datetime.now()) +"\r\n")

def DisplayndcReport():

	ndcfile=pd.read_excel(path+'/'+domain+'/'+file_type+'/'+file_name,converters={'GPI':str,'NDC':str,'GPPC':str})
	logfile.write("No of records in File "+ str(ndcfile.shape[0]) +"\r\n")

	ndcfile.fillna("",inplace=True)
	ndcfile['NDC']=ndcfile['NDC'].apply(lambda x: str(int(x)).zfill(11) if x!="" else x)
	ndcfile['GPI']=ndcfile['GPI'].apply(lambda x: str(x).zfill(14) if x!="" else x)
	ndcfile['GPPC']=ndcfile['GPPC'].apply(lambda x: str(x).zfill(8) if x!="" else x)
	ndccols=list(ndcfile)
	print('file read start')
	
	for index,val in ndcfile.iterrows():
		rev=dict()
		query=N1QLQuery('Select meta().id as id from `'+os.environ['CB_INSTANCE']+'` where type="ndc_drugs" and ndc=$drugndc',drugndc=val['NDC'])
		query.adhoc=False
		for res in cb.n1ql_query(query):
			docid=res['id']
			rev['ndc_id']=docid
		for v in ndccols:
			rev[v.lower().strip()]=str(val[v])
		rev['type']='ndc_drugs'
		if 'ndc_id' not in rev:
			if mode.upper() == 'FINAL':
				rv1=cb.counter('docid',delta=1)
				rev['ndc_id']=str(rv1.value)

		if mode.upper() == 'FINAL':
			cb.upsert(rev['ndc_id'],rev)
	print('file read end and update ndc drugs update')

DisplayndcReport()
# Added for log file
logfile.write("End time is "+ str(datetime.now()) +"\r\n")

logfile.write("=============================================================="+"\r\n")
logfile.close()
