########################################
# !/usr/bin/env python 

# title : updatedrugdisplayrank.py
# description : Update display ranks of GPI according to most prescribed drugs
# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  python updatedrugdisplayrank.py -d GWLABS001 -t DRUG_DATABASE -f Medispan20181212.csv -m DRAFT

# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(rootdir)
   
import os
import sys
from datetime import datetime
import socket

import pandas as pd
from couchbase.n1ql import N1QLQuery
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase import FMT_JSON
import couchbase.subdocument as SD

from app.common.sendgridemail import email_log
import app.common.commandline as commandline

dn,file_type,filename,mode=commandline.main(sys.argv[1:])
cluster=Cluster(os.environ['CB_URL']+'?operation_timeout=2700')
auth=PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(auth)
bucket_name=os.environ['CB_INSTANCE']
cb=cluster.open_bucket(bucket_name)
missingquantities=pd.DataFrame()

# modified by Hari on 27/12/2018
path = os.environ['CB_DATA']
host = socket.gethostname()
currentdate = datetime.now()
currentdate = currentdate.strftime("%m%d%y%H%M%S")
log = os.environ['CB_DATA']+'//'+file_type+'/log/'+"updatedrugdisplayrank"+currentdate+'.txt'
logfile = open(log,"w")

df=pd.DataFrame()
ite=0
rxhistoryquery=N1QLQuery('SELECT count(*) cnt,units_dispensed_qty,tonumber(ndc_code) ndc_code FROM `'+bucket_name+'` WHERE type="rx_claim_history" group by units_dispensed_qty,tonumber(ndc_code) order by count(*) desc')
rxhistoryquery.timeout=120
for rxhistrow in cb.n1ql_query(rxhistoryquery):
	#print(ite)
	ite=ite+1
	ndcquery=N1QLQuery('SELECT custom_qty,drug_name,gpi,package_qty,tonumber(package_size) package_size,CASE WHEN custom_qty="package_size" THEN dosage ELSE package_desc END quantity_type FROM `'+bucket_name+'` WHERE type="ndc_drugs" and ndc=$ndc',ndc=str(rxhistrow['ndc_code']).zfill(11))
	ndcquery.timeout=120
	for ndcrow in cb.n1ql_query(ndcquery):
		d=dict(ndcrow)
		d['cnt']=rxhistrow['cnt']
		d['units_dispensed_qty']=rxhistrow['units_dispensed_qty']
		if ndcrow['custom_qty']=='package_quantity':
			d['package_size']=str(float(ndcrow['package_size']))
			d['package_qty']=ndcrow['package_qty']
		else:
			#print(ndcrow)
			d['package_size']=str(float(rxhistrow['units_dispensed_qty']))
			d['package_qty']=str(int(float(rxhistrow['units_dispensed_qty'])))+" "+ndcrow['quantity_type']
		df=df.append(d,ignore_index=True)
print('rxhistory done')
#print(list(df))
df.drop(['units_dispensed_qty','custom_qty','quantity_type'],axis=1,inplace=True)
prescquery=N1QLQuery("SELECT count(*) cnt,package_qty,gpi,drug_name,tonumber(package_size) package_size	from `"+bucket_name+"` where type='prescription' and drug_name is valued and gpi is valued and rx_status='Filled' group by package_qty,gpi,drug_name,tonumber(package_size)")
prescquery.timeout=120
for prescrow in cb.n1ql_query(prescquery):
	temp=dict(prescrow)
	temp['package_size']=str(float(temp['package_size']))
	df=df.append(temp,ignore_index=True)
finallist=pd.DataFrame()
print('presc done')
print(len(df))
df['cnt']=df['cnt'].apply(lambda x: float(x))
#df.to_csv('fulllist.csv',index=False)

for key,grp in df.groupby(['drug_name']):
	displayrank=0
	grp['displayrank']=0
	grp['orig_displayrank']=0
	gpiquant=dict()
	drugquery=N1QLQuery('SELECT quantity,gpi,meta().id id from `'+bucket_name+'` where type="drug" and drug_name=$dn',dn=key)
	drugfound=False
	drugquery.timeout=120
	for drugrow in cb.n1ql_query(drugquery):
		drugfound=True
		tdf=pd.DataFrame(data=drugrow['quantity'])
		tdf['package_size']=tdf['package_size'].apply(lambda x : str(float(x)))
		tdf['display_rank']=tdf['display_rank'].apply(lambda x : str("999"))
		gpiquant[drugrow['gpi']]=tdf
		gpiquant[drugrow['gpi']+'id']=drugrow['id']
		
	if not drugfound: continue
	grp.set_index(['drug_name','gpi','package_qty','package_size'],inplace=True)
	grp=grp.groupby(grp.index).sum()
	grp.sort_values(by=['cnt'],ascending=[False],inplace=True)
	#quantities=None
	
	for i,r in grp.iterrows():
		#print(i)
		#print(quantitylist['package_qty'],quantitylist['package_size'])
		
		
		try:
			#print('----------------------')
			quantitylist=gpiquant[i[1]]
			
			#odr=quantitylist.loc[(quantitylist['package_qty']==i[2]) & (quantitylist['package_size']==i[3]),'display_rank'].values[0]
			#grp.loc[i,'orig_displayrank']=odr
			displayrank=displayrank+1
			#grp.loc[i,'displayrank']=displayrank
			gppc=quantitylist.loc[(quantitylist['package_qty']==i[2]) & (quantitylist['package_size']==i[3]),'gppc'].values[0]
			quantitylist.loc[(quantitylist['package_qty']==i[2]) & (quantitylist['package_size']==i[3]) & (quantitylist['gppc']==gppc),'display_rank']=str(displayrank)
			#gpiquant[i[1]].loc[(gpiquant[i[1]]['package_qty']==i[2]) & (gpiquant[i[1]]['package_size']==i[3]),'display_rank']=str(display_rank)
			#print(gpiquant[i[1]])
			gpiquant[i[1]+'id']=gpiquant[i[1]+'id']+'xxx'
			
				
			'''
			fl=dict(r)
			fl['drug']=i[0]
			fl['gpi']=i[1]
			fl['package_qty']=i[2]
			fl['package_size']=i[3]
			fl['displayrank']=displayrank
			fl['orig_displayrank']=quantitylist.loc[(quantitylist['package_qty']==i[2]) & (quantitylist['package_size']==i[3]),'display_rank'].values[0]
			finallist=finallist.append(fl,ignore_index=True)
			'''
		except Exception as e:
			#print(i,quantitylist,e)
			fl=dict(r)
			fl['drug']=i[0]
			fl['gpi']=i[1]
			fl['package_qty']=i[2]
			fl['package_size']=i[3]
			missingquantities=missingquantities.append(fl,ignore_index=True)
	for gpis,dfs in gpiquant.items():
		if 'id' not in gpis:
			if 'xxx' in gpiquant[gpis+'id']:
				#print(gpis,key,dfs)
				qli=dfs.to_dict('records')
				print(gpis,key,gpiquant[gpis+'id'].replace('xxx',''))
				if mode.upper().strip()=='FINAL':
					cb.mutate_in(gpiquant[gpis+'id'].replace('xxx',''),SD.upsert('quantity',qli))
				else:
					logfile.write(str(qli))
					
if mode.upper().strip()=='FINAL':
	query=N1QLQuery("update `"+os.environ['CB_INSTANCE']+"` b set b.gpi_display_rank=ARRAY_MIN(ARRAY tonumber(q.display_rank) for q in b.quantity END) where b.type='drug'")
	cb.n1ql_query(query).execute()
	query=N1QLQuery("update `"+os.environ['CB_INSTANCE']+"` set i.display_rank='999' for i in ARRAY_FLATTEN(quantity,1) WHEN i.display_rank='nan' END where type='drug'")
	cb.n1ql_query(query).execute()
	query=N1QLQuery('update `'+os.environ['CB_INSTANCE']+'` set gpi_display_rank=1000 where type="drug" and drug_name||gpi||replace(replace(replace(brand_generic,"G","Generic"),"B","Brand"),"T","Brand") not in (select raw b.drug_name||b.gpi||b.brandorgeneric from `'+os.environ['CB_INSTANCE']+'` b where b.type="cp_drug_price")')
	cb.n1ql_query(query).execute()
else:
	print("Run in draft mode")

logfile.close()
receiver=['DWagle@fliptrx.com','SSubramani@fliptrx.com']
subject='DrugDatabase Display Rank Updated - Completed'
body=['Processing of DrugDatabase display rank','‘DrugDatabase (ScriptClaim) Exception’']
email_log('dwagle@fliptrx.com',receiver[0],receiver[1],subject,body,None,False)			