########################################
# !/usr/bin/env python 

# title : drugdbupdates.py
# description : On-demand updates to drug database
# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  python drugdbupdates.py -d GWLABS001 -t DRUG_DATABASE -f drugdb.csv -m draft
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


# #######################################
# -*- coding: utf-8 -*-

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(rootdir)

import os
import time
import sys
import json
import socket
from datetime import datetime
import urllib.request as urllib2
import urllib.error

import pandas as pd
from couchbase.n1ql import N1QLQuery
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase import FMT_JSON
import couchbase.subdocument as SD

from app.common.sendgridemail import email_log
import app.common.commandline as commandline


domain,file_type,file_name,mode=commandline.main(sys.argv[1:])
cluster=Cluster(os.environ['CB_URL']+'?operation_timeout=2700')
auth=PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(auth)
bucket_name=os.environ['CB_INSTANCE']
cb=cluster.open_bucket(bucket_name)
#email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','SSubramani@GWLabs.com','Deductible Updated - Initiated',['Processing of Deductible file '+file_name],None,False)

errors=pd.DataFrame()
rxids=pd.DataFrame()
dd=pd.read_excel(os.environ['CB_DATA']+'/'+file_type+'/'+file_name)
#rx=pd.read_csv(os.environ['CB_DATA']+'/'+filetype+'/rxcui.csv')

# modified by Hari on 27/12/2018
path = os.environ['CB_DATA']
host = socket.gethostname()
currentdate = datetime.now()
currentdate = currentdate.strftime("%m%d%y%H%M%S")
log = path+'/'+domain+'/'+file_type+'/log/'+"drugdbupdates"+currentdate+'.txt'

newcols={}
for c in list(dd):
    newcols[c]=c.replace(' ','_').lower()
dd.rename(columns=newcols,inplace=True)
dd['gpicode']=dd['gpicode'].apply(lambda x: str(x).zfill(14))
dd.drop_duplicates(inplace=True)

for i,r in dd.iterrows():
	query=N1QLQuery('Select meta().id as id from `'+os.environ['CB_INSTANCE']+'` where type="drug" and gpi=$gpi and drug_name=$dn',gpi=r['gpicode'],dn=r['productnameabr'].upper().strip())
	if mode.upper().strip()=='FINAL':
		for qres in cb.n1ql_query(query):
			cb.mutate_in(qres['id'],SD.upsert('specialty_flag','Y')) 
# added by Hari on 27/12/2018
if mode.strip().upper() == 'DRAFT':
	logfile = open(log,"w")
	logfile.write(' drug db update - Draft Mode :'+host+file_name)
	print("File run on DRAFT mode")
	subject = 'drug db update - Draft Mode :'+host
	email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','SSubramani@GWLabs.com',subject,['drug db File '+log,'drug db Exception'],log,True)
	logfile.close()	
#writer=pd.ExcelWriter(os.environ['CB_DATA']+'/'+domain_name+'/'+file_type+'/log/'+errlog)