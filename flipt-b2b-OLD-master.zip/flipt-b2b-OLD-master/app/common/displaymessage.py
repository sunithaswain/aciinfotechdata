########################################
# !/usr/bin/env python 

# title : displaymessage.py
# description : Update displaymessages data
# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  python displaymessage.py -d GWLABS001 -t displaymessage -f message07102018.xlsx -m DRAFT
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(rootdir)
   

import json
import os
import socket
import sys
from datetime import datetime

import pandas as pd
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery

import commandline
from sendgridemail import email_log

# cluster = Cluster(os.environ['CB_URL'])
# authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
# cluster.authenticate(authenticator)


cluster=Cluster(os.environ['CB_URL']+'?operation_timeout=2700')
auth=PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(auth)
bucket_name=os.environ['CB_INSTANCE']

cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
domain,file_type,file_name,mode = commandline.main(sys.argv[1:])

# modified by Hari on 27/12/2018
path = os.environ['CB_DATA']
host = socket.gethostname()
currentdate = datetime.now()
currentdate = currentdate.strftime("%m%d%y%H%M%S")
log = path+'/'+domain+'/'+file_type+'/log/'+"displaymessage"+currentdate+'.txt'

def DisplayMessageReport():

	messagefile=pd.read_excel(path+'/'+domain+'/'+file_type+'/'+file_name)
	messagefile.fillna("",inplace=True)
	messagecols=list(messagefile)
	logfile = open(log,"w")

	for index,val in messagefile.iterrows():
		rev=dict()
		query=N1QLQuery('Select meta().id,created_at from `'+os.environ['CB_INSTANCE']+'` where type="displaymessage" and message_type=$mt and language=$lang',mt=val['message_type'],lang=val['language'])
		query.adhoc=False
		newrec=True
		for qres in cb.n1ql_query(query):
			docid=qres['id']
			rev['message_id']=docid
			rev['created_at']=qres['created_at']
			rev['updated_at']=str(datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())
			newrec=False
		if newrec:
			rv1=cb.counter('docid',delta=1)
			rev['message_id']=str(rv1.value)
			rev['created_at']=str(datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())
			rev['updated_at']=str(datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())
		for v in messagecols:
			rev[v]=str(val[v])
		rev['type']='displaymessage'

		if mode.strip().upper() == 'FINAL':
			cb.upsert(rev['message_id'],rev)
		else:
			logfile.write(str(rev))


	# added by Hari on 27/12/2018
	if mode.strip().upper() == 'DRAFT':
		logfile.write(' display message update - Draft Mode :'+host+file_name)
		print("File run on DRAFT mode")
		subject = 'display message update - Draft Mode :'+host
		logfile.close()
		email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','SSubramani@GWLabs.com',subject,['display  message File '+log,'display message Exception'],log,True)
	else:
		logfile.close()
DisplayMessageReport()