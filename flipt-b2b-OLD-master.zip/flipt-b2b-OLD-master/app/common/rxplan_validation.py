########################################
# !/usr/bin/env python  
# title         : rxplan_validation.py
# description   : Get list of plans and plan availability
# author        : Disha
# date created  : 20180101
# date last modified    : 20180720 12:16
# version       : 0.1
# maintainer    : Pal
# email         : pmuthanai@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage         : 
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  
# #######################################

import pandas as pd
from couchbase.n1ql import N1QLQuery
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
import os
from datetime import datetime

# Added to update the system path to refer our custom packages
if __name__ == '__main__':
    import os
    import sys
    rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.append(rootdir)

cluster=Cluster(os.environ['CB_URL'])
auth=PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(auth)
bucket_name=os.environ['CB_INSTANCE']
cb=cluster.open_bucket(bucket_name)

#get list of plans according to domain (dn) and plan year (yr)
def getplans(dn,yr):

        df=pd.DataFrame()
        query=N1QLQuery('SELECT plan_name FROM `'+bucket_name+'` WHERE type="rxplan_master" and domain_name in $domain and plan_year=$year',domain=dn,year=yr)
        query.adhoc=False
        #query.timeout=7200
        i=0
        
        for r in cb.n1ql_query(query): 		
            df=df.append(r,ignore_index=True)
        
        return df

#check if parameter "plan" is present in the list of plans "records"
def validate(records,plan):

	pn=None
	plan=plan.upper()
	
	for i,r in records.iterrows():
		
		if plan.strip() in r['plan_name'].upper().strip() or r['plan_name'].upper().strip() in plan.strip():
			if pn==None:
				pn=r['plan_name']
	if pn==None:
		return 'Error'
	
	return pn		 

