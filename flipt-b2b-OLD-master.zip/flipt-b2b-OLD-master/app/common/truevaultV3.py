
# title : truevaultV3.py
# description : Common program used by interfaces to search TrueVault user/read user/update user, etc
# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  used in other programs as follows
                # from truevaultV3 import User_Class
                # obj=User_Class()
                # att,userid = obj.search_user(search_option)

# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(rootdir)
   
import requests
from requests.auth import HTTPBasicAuth
import json
import base64
import pprint
import pandas as pd
from couchbase.cluster import Cluster 
from couchbase.cluster import PasswordAuthenticator
from couchbase.n1ql import N1QLQuery
import sendgrid
import os
from sendgrid.helpers.mail import *
from datetime import datetime
from couchbase import FMT_JSON

api_key=os.environ['TV_API_KEY']

current_time=datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat()


class User_Class(object):

    #initialize User_Class object with username,password,attributes,group and status;initialization is optional
    def __init__(self,username=None,password=None,attributes=None,group_ids=None,status=None):
        self.username=username
        self.password=password
        self.attributes=attributes
        self.group_ids=group_ids
        self.status=status
    
    #create a user using initialized username,password,attributes,etc in func __init__	
    def create_user(self):
        self.password=str(self.attributes['zip'])+str(self.attributes['employee_ssn'])[-4:]
        self.attributes['active']=False
        self.attributes['tmp_password']=self.password
        attributes=base64.b64encode(str.encode(json.dumps(self.attributes)))
        data={'username':self.username, 'password':self.password,'attributes':attributes,'group_ids':self.group_ids}
        r=requests.post('https://api.truevault.com/v1/users',auth=HTTPBasicAuth(api_key, ''),data=data)
        if r.status_code==400 or r.status_code==404: return
        response=r.json()
        userid=response['user']['user_id']
        
        
    # using userid, read the user attributes
    def read_user(self,userid):
    
        data={'full':True}
        r=requests.get('https://api.truevault.com/v2/users/%s' % str(userid),auth=HTTPBasicAuth(api_key, ''),data=data)
        return r.json()		
		
    #using search option provided (values used to search user), one user is returned fromm the result
    def search_user(self,search_option):
                 
        
        search_opt=base64.b64encode(str.encode(json.dumps(search_option)))
        data={'search_option':search_opt}
        r=requests.post('https://api.truevault.com/v1/users/search',auth=HTTPBasicAuth(api_key, ''),data=data)
        response=r.json()
        #print(response)
        if 'data' not in response: return None,None
        if len(response['data']['documents'])==0 and r.status_code==200: return None,None
        att=json.loads(str(base64.b64decode(response['data']['documents'][0]['attributes']),'utf-8'))
        userid=response['data']['documents'][0]['user_id']
        return att,userid

    #using search option provided (values used to search user), all users are returned
    def search_user_id(self,search_option):


        search_opt=base64.b64encode(str.encode(json.dumps(search_option)))
        data={'search_option':search_opt}
        r=requests.post('https://api.truevault.com/v1/users/search',auth=HTTPBasicAuth(api_key, ''),data=data)
        response=r.json()
        attlist=[]
        useridlist=[]
        if 'data' not in response: return [],[]
        if len(response['data']['documents'])==0 and r.status_code==200: return [],[]
        for i in range(0,len(response['data']['documents'])):
            attlist.append(json.loads(str(base64.b64decode(response['data']['documents'][i]['attributes']),'utf-8')))
            useridlist.append(response['data']['documents'][i]['user_id'])
        return attlist,useridlist


    #update user attributes; used during employee-dependent update
    def update_user(self):


        cluster=Cluster(os.environ['CB_URL'])
        auth=PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
        cluster.authenticate(auth)
        cb=cluster.open_bucket(os.environ['CB_INSTANCE'])
        errlog=pd.DataFrame()
        #search a user to check if present or not
        search_option={'full_document':True,'filter':{'$tv.username':{'type':'eq','value':self.attributes['work_email'],'case_sensitive':False},'domain_name':{'type':'eq','value':self.attributes['domain_name'],'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
        att,userid=self.search_user(search_option)			
        if userid==None:
            #user was not found, hence creating a new user and inserting record into flipt_person_hierarchy document type
            rec={}
            rv=cb.counter('counterid',delta=1)
            self.attributes['flipt_person_id']=str(rv.value)
            self.attributes['created_at']=current_time
            self.attributes['updated_at']=current_time
            
            recs=[]
            testacc=False
            if 'TEST' in self.attributes['employee_id'].upper():
                testacc=True
            rec={}
            rec['emp_flipt_person_id']=str(rv.value)
            rec['dep_flipt_person_id']=str(rv.value)
            rec['domain_name']=self.attributes['domain_name']
            rec['created_at']=current_time
            rec['updated_at']=current_time
            rec['sc_extracted_date']=''
            rec['type']='flipt_person_hierarchy'
            recs.append(rec)
            for i in range(len(self.attributes['dependents'])):
                rec={}
                rec['emp_flipt_person_id']=str(rv.value)
                inc=cb.counter('counterid',delta=1)
                self.attributes['dependents'][i]['flipt_person_id']=str(inc.value)
                self.attributes['dependents'][i]['created_at']=current_time
                self.attributes['dependents'][i]['updated_at']=current_time
                rec['dep_flipt_person_id']=str(inc.value)
                rec['domain_name']=self.attributes['domain_name']
                rec['created_at']=current_time
                rec['updated_at']=current_time
                rec['sc_extracted_date']=''
                rec['type']='flipt_person_hierarchy'
                recs.append(rec)
            #insert into flipt_person_hierarchy
            if testacc == False:
                for r in recs:
                   cb.upsert(str(cb.counter('docid',delta=1).value),r, format=FMT_JSON)
            self.username=self.attributes['work_email'].lower()
            #create user in Truevault
            self.create_user()
            
            return
        
        new_dependents=False
        dep_id=[]
        updatedependent=pd.DataFrame()
        testacc = False
        #check if it is a test account
        if 'TEST' in self.attributes['employee_id'].upper():
            testacc = True
        # check if user is registered
        if 'claimed' not in att: 
            self.attributes['active']=False
        self.attributes['updated_at']=datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat()
        
        #go through current user attributes and assign them to Truevault's user attributes
        #in case of extra attributes in Truevault, the extra ones are maintained while only updating the information which is received in the employee dependent file
        for v in list(self.attributes.keys()):
            #checks if user is registered, then does not update the default options
            if 'claimed' in att and v in ['reward_option','payment_option','communication_option']: continue
            #checks if attribute is dependents
            if v=='dependents':
                #check if currently no dependent and new file has no dependent either
                if len(self.attributes[v])==0 and len(att[v])==0: continue
                #check if currently no dependent but new file has a new dependent 
                elif len(att[v])==0 and len(self.attributes[v])>0:
                    for dep in self.attributes[v]:
                        att[v].append(dep)
                        dep['flipt_person_id']=str(cb.counter('counterid',delta=1).value)
                        dep['created_at']=current_time
                        dep['updated_at']=current_time
                        new_dependents=True
                        dep_id.append(dep['flipt_person_id']) 
                    continue
                #update dependent attributes
                else:
                    deps_info=pd.DataFrame()
                    currentdeps=pd.DataFrame()
                    for dep in self.attributes[v]:
                        currentdeps=currentdeps.append({'first_name':dep['first_name'],'last_name':dep['last_name']},ignore_index=True)
                    for i in range(len(att[v])):
                        dep=att[v][i]
                        deps_info=deps_info.append({'index_no':i,'fname':dep['first_name'],'lname':dep['last_name'],'dob':dep['date_of_birth'],'person_code':int(dep['person_code'])},ignore_index=True)
                        if att['employment_status'].lower().strip() in ['terminated','cobra'] and 'user_id' in dep:
                            updatedependent=updatedependent.append({'domain_name':att['domain_name'],'email':dep['email'],'flipt_person_id':dep['flipt_person_id'],'tdate':att['coverage_termination_date'],'emp_status':att['employment_status']},ignore_index=True)
                            errlog=errlog.append({'Domain Name':att['domain_name'],'Employee ID':att['employee_id'],'First Name':dep['first_name'],'Last Name':dep['last_name'],'Coverage Tier Name':'','Dependent-Relationship':'','Plan Name':att['benefit_plan_name'],'Record Message':'Dependent Coverage Termination Date Updated (Employee terminated)'},ignore_index=True)
                        #if a dependent is no more present in the new dependent file, update dependent's coverage termination date to current date
                        if currentdeps.empty or (dep['first_name'] not in list(currentdeps['first_name'])) and (dep['last_name'] not in list(currentdeps['last_name'])):
                            if att[v][i]['coverage_termination_date']>datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat():			
                                att[v][i]['coverage_termination_date']=	datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat()			
                                errlog=errlog.append({'Domain Name':att['domain_name'],'Employee ID':att['employee_id'],'First Name':dep['first_name'],'Last Name':dep['last_name'],'Coverage Tier Name':'','Dependent-Relationship':'','Plan Name':att['benefit_plan_name'],'Record Message':'Dependent not found in Latest File, Coverage Termination Date Updated'},ignore_index=True)
                    
                    
                    inc=1
                    for dep in self.attributes[v]:
                        if ((deps_info['fname']==dep['first_name'])&(deps_info['lname']==dep['last_name'])&(deps_info['dob']==dep['date_of_birth'])).any():
                            index=int(deps_info[(deps_info['fname']==dep['first_name'])&(deps_info['lname']==dep['last_name'])&(deps_info['dob']==dep['date_of_birth'])]['index_no'].values[0])
                            
                            for dep_v in dep:
                                att[v][index][dep_v]=str(dep[dep_v])
                            att[v][index]['updated_at']=datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat()

                        else:
                            pc=max(list(deps_info['person_code']))+inc
                            dep['person_code']=str(int(pc)).zfill(2)
                            inc=inc+1
                            att[v].append(dep)
                            dep['flipt_person_id']=str(cb.counter('counterid',delta=1).value)
                            dep['created_at']=current_time
                            dep['updated_at']=current_time
                            new_dependents=True
                            dep_id.append(dep['flipt_person_id'])
                        continue
                continue
                        
            att[v]=self.attributes[v]
        new_att=base64.b64encode(str.encode(json.dumps(att)))
        
        data={'attributes':new_att}
        #update user attributes to truevault
        r=requests.put('https://api.truevault.com/v1/users/%s' % str(userid),auth=HTTPBasicAuth(api_key, ''),data=data)
		
        #insert record into flipt_person_hierarchy for a new dependent
        if new_dependents==True and testacc == False:
            flipt_ids={}
            for dep in dep_id:
                x={}
                x['emp_flipt_person_id']=att['flipt_person_id']
                x['dep_flipt_person_id']=dep
                x['domain_name']=att['domain_name']
                x['created_at']=current_time
                x['updated_at']=current_time
                x['sc_extracted_date']=''
                x['type']='flipt_person_hierarchy'
                cb.upsert(str(cb.counter('docid',delta=1).value),x, format=FMT_JSON)
				
        # update independent registered dependent accounts with coverage termination date 		
        if not updatedependent.empty:
            for i,r in updatedependent.iterrows():
                search_option={'full_document':True,'filter':{'$tv.username':{'type':'eq','value':r['email'],'case_sensitive':False},'domain_name':{'type':'eq','value':r['domain_name'],'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
                att,userid=self.search_user(search_option)
                att['coverage_termination_date']=r['tdate']
                if r['emp_status'].lower().strip()=='cobra' and r['tdate']>datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat(): 
                    att['active']=True				
                new_att=base64.b64encode(str.encode(json.dumps(att)))
                data={'attributes':new_att}
                response=requests.put('https://api.truevault.com/v1/users/%s' % str(userid),auth=HTTPBasicAuth(api_key, ''),data=data)
        return errlog
        
    #updates active status on terminated employee and returns entire list of users in truevault with their attributes
    def update_active_status(self):
        
        '''	
        search_option={'full_document':True,'filter':{'coverage_termination_date':{'type':'range','value':{'lt':str(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))}},'$tv.status':{'type':'eq','value':'ACTIVATED'},'active':{'type':'eq','value':True}},'filter_type':'and'}
        
        attlist,useridlist=self.search_user_id(search_option)
        
        for i in range(len(useridlist)):
            attlist[i]['active']=False
            new_att=base64.b64encode(str.encode(json.dumps(attlist[i])))
            data={'attributes':new_att}
            r=requests.put('https://api.truevault.com/v1/users/%s' % str(useridlist[i]),auth=HTTPBasicAuth(api_key, ''),data=data)
        '''
        r=requests.get('https://api.truevault.com/v1/users',auth=HTTPBasicAuth(api_key,''))
        df=pd.DataFrame()
        response=r.json()
        for i in response['users']:
            search_option={'full_document':True,'filter':{'$tv.username':{'type':'eq','value':i['username'],'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
            att,uid=self.search_user(search_option)
            if att!=None:  
                if 'coverage_termination_date' in att:
                    if att['coverage_termination_date']<datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat():
                        print(att['coverage_termination_date'])
                        att['active']=False
                        data={'attributes':att}
                        r=requests.put('https://api.truevault.com/v1/users/%s' % str(uid),auth=HTTPBasicAuth(api_key, ''),data=data)
                    else:
                        att['active']=True
                        data={'attributes':att}
                        r=requests.put('https://api.truevault.com/v1/users/%s' % str(uid),auth=HTTPBasicAuth(api_key, ''),data=data)
                ud=''
                if 'updated_at' in att: ud=att['updated_at']
                df=df.append({'Username':i['username'],'Attributes':att,'Update Date':ud},ignore_index=True)
        df.sort_values(by=['Update Date'],inplace=True)
        return df

    def send_email(self,userid):
        
        user_id=userid
        headers = {'Content-Type': 'application/json'}
        data={
         "provider": "SENDGRID",
         "auth": {"sendgrid_api_key": os.environ['SENDGRID_API_KEY']},
         "template_id": "f21152e7-3b48-4e76-8173-beb033e14f54",
         "from_email_address": {"literal_value": "care@fliptrx.com"},
         "to_email_address": {"user_attribute": "work_email"},
         "substitutions": {
            ":username":{"user_attribute":"first_name"},
            ":password": {"literal_value": self.password},
         }
    }
        r=requests.post('https://api.truevault.com/v1/users/%s/message/email'%user_id,headers=headers,auth=HTTPBasicAuth(api_key, ''),data=json.dumps(data))
        #print(r.status_code)
        return r.status_code
    
    def create_user_schema(self):
        userschema={"name": "userschema",
                     "fields": [
                      {
                      "name": "domain_name",
                      "index": True,
                      "type": "string"
                      },
                      {
                      "name": "first_name",
                      "index": True,
                      "type": "string"
                      },
                      {
                      "name": "last_name",
                      "index": True,
                      "type": "string"
                      },
                      {
                      "name": "date_of_birth",
                      "index": True,
                      "type": "string"
                      },
                      {
                      "name": "employee_id",
                      "index": True,
                      "type": "string"
                      },
                      {
                      "name": "employee_ssn",
                      "index": True,
                      "type": "string"
                      },
                      {
                      "name": "dependents.dependent_ssn",
                      "index": True,
                      "type": "string"
                      },
                      {
                      "name": "dependents.first_name",
                      "index": True,
                      "type": "string"
                      },
                      {
                      "name": "dependents.last_name",
                      "index": True,
                      "type": "string"
                      },
                       {
                      "name": "flipt_person_id",
                      "index": True,
                      "type": "string"
                      },
                      {
                      "name": "coverage_termination_date",
                      "index":True,
                      "type":"string"
                      },
                      {
                      "name": "active",
                      "index":True,
                      "type":"boolean"
                      }
                      ]
                      }

        uschema=base64.b64encode(str.encode(json.dumps(userschema)))
        data={'schema':uschema}
        acc_id='98a031fd-049e-4388-831a-982cf1838d1f'
        r=requests.put('https://api.truevault.com/v1/accounts/%s/user_schema' % acc_id,auth=HTTPBasicAuth(api_key, ''),data=data)
                       
   
    def delete_user(self):
        df=pd.DataFrame()
        r=requests.get('https://api.truevault.com/v1/users',auth=HTTPBasicAuth(api_key,''))
        response=r.json()
        for i in response['users']:
            if i['user_id']=='f6a6144c-1552-4849-b99d-afe4175ec6f8':
                print(i['username'])
              
