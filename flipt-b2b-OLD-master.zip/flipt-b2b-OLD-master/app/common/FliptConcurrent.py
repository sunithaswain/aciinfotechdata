########################################
# !/usr/bin/env python 

# title : FliptConcurrent.py
# description : common program used by all interfaces to capture the starttime, end time,
# 				logs of the interface and the record processed by that interface 

# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  used in other programs as follows
					# from FliptConcurrent import concurrent
					# req=concurrent(sys.argv[0],sys.argv[1:])
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(rootdir)
   
import sys
import os
import traceback

import json
import pandas as pd

from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from couchbase import FMT_JSON

import dateutil.parser as parser
import app.common.commandline as commandline
from collections import defaultdict
import app.common.opccmdline as opccmdline

from datetime import datetime
import shutil
from pathlib import Path
from app.common.sendgridemail import email_log
#,email_log_custombody
#from rxplan_validation import getplans,validate
#from awssftpfileops import downloadfile,listbucketcontents


#To initiate the Couch base connection
cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
path = os.environ['CB_DATA']

'''
########################################################################################
 Class Name 			: 		concurrent

 Following code will be part of calling scheduled python script
 --------------------------------------------------------------
 In the beginning:
 
	from FliptConcurrent import concurrent
	request=concurrent(sys.argv[0],sys.argv[1:])
 
 To capture following information. Relavent parameter is used in the object
 
	 No of records received: 		no_rec_received 
	 No of records Processed: 		no_rec_processed 
	 No of records Errored: 		no_rec_errored
	 No of old unresolved errors: 	no_old_unres_err 
	 Notes:							concurrent_notes
	 Error Message:					error_message
	 
		Ex: request.no_rec_received=100
 
 In the end:

	request.close()
 
Following function will be used to write a text in log file
	
	request.writelog('test log from calling function')

Program Logic
-------------
python script name will be considered as program name

For each program a entry will made in table flipt_concurrent_programs, if the entry is not available. ID will be script name.ex:"empinterface" 
	
For programs, each day one entry will be made in table flipt_concurrent_requests, if the entry is not available. 
	ID will be script_name+date in format(dd_mm_rrrr) ex:"empinterface_07_17_2018

For each run one request_id will be created, and it will be maintained as subset in flipt_concurrent_requests 	
	
########################################################################################
'''

class concurrent:
	scriptname, file_type, domain, file_name, mode = '','','','',''
	parameters=''
	starttime,completiontime='',''
	program_date=''
	request_id=''
	request_key=''
	logfilepath=''
	log_file_name=''
	log=''
	no_of_calls=0
	program_id, program_name, program_type, run_history, send_mail,logfile='','','','','',''
	no_rec_received, no_rec_processed, no_rec_errored, no_old_unres_err, concurrent_notes, error_message=0,0,0,0,'','N'
	
	'''
	get the calling script file details 	
	'''
	def __init__(self,scriptname,parameters,commandtype=1):
		
		try:
			#To get the script file name and parameters
			self.scriptname=scriptname
			self.program_id='flipt_concurrent_programs::'+scriptname[:-3]
			self.request_id=''
			self.parameters=' '.join(parameters)
			self.no_of_calls=0
			#commandline.main(sys.argv[1:])
			if commandtype==1:
				self.domain,self.file_type,self.file_name,self.mode = commandline.main(parameters)
			elif commandtype==2:
				self.domain,self.file_type,self.file_name,self.mode,strt,end = opccmdline.main(parameters)
			if self.domain==None: self.domain=''
			if self.file_type==None: self.file_type=''
			if self.file_name==None: self.file_name=''
			if self.mode==None: self.mode=''
			#domain,file_type,file_name,mode = commandline.main(sys.argv[1:])
			
					
			self.findprogram()
			self.requestid()			
					
			if self.logfile=='Y':
				#Create Log file path
				self.logfilepath=os.environ['CB_DATA']+'/'+self.domain+'/flipt_concurrent_programs/log'
					
				#print(self.logfilepath)		
						
				#write parameters in log file
				#self.log_file_name=self.file_name[:-3]+'_'+self.request_id
				#print 
				self.log_file_name=scriptname[:-3]+'_'+self.request_id
				self.log=logfile(self.logfilepath,self.log_file_name,self.send_mail)
				self.log.writeline('Arguments		')
				self.log.writeline('****************************************************************')
				self.log.writeline('Request ID	:	'+self.request_id)
				self.log.writeline('ScriptName	:	'+self.scriptname)
				self.log.writeline('Domain		:	'+self.domain)
				self.log.writeline('File Type	:	'+self.file_type)
				self.log.writeline('File Name	:	'+self.file_name)
				self.log.writeline('Mode		:	'+self.mode)
				self.log.writeline('File Path	:	'+self.logfilepath)
				self.log.writeline('File Name	:	'+self.log_file_name+'_log.txt'	)
				
				self.log.writeline('Line')
				self.log.writeline('Log File Content')
				self.log.writeline('****************************************************************')
				
				self.log.subject='Concurrent - Log '+ self.file_type +' - '+self.mode +' '+self.request_id
				self.log.body='Concurrent - Log for '+ self.file_type +' - '+self.mode +' '+self.request_id
			
			self.find_request()
		except Exception as e:
			print('Error in __init__ in Concurrent program Call'+str(e))
			print(traceback.format_exc())
	#-----------------------------------------------------------------------
	#Function To write text in log file; will be called from called function
	#-----------------------------------------------------------------------
	def writelog(self,text):
		try:
			if self.logfile=='Y':
				self.log.writeline(text)
		except Exception as e:
			print('Error in writelog in Concurrent program Call'+str(e))
			print(traceback.format_exc())
	
	#-----------------------------------------------------------------------
	#To Close the text in log file; will be called from called function
	#-----------------------------------------------------------------------
	#def __del__(self):
	def close(self):
		try:
			self.findprogram()
			self.requestid()
			self.find_request()
			if self.logfile=='Y':
				self.log.writeline('Line')
				self.log.writeline('No of records received		:	'+str(self.no_rec_received))
				self.log.writeline('No of records Processed		:	'+str(self.no_rec_processed))
				self.log.writeline('No of records Errored		:	'+str(self.no_rec_errored))
				self.log.writeline('No of old unresolved errors	:	'+str(self.no_old_unres_err))
				self.log.writeline('Notes						:	'+self.concurrent_notes)
				self.log.writeline('Error Message				:	'+self.error_message)
				self.log.close()				
		except Exception as e:
			print('Error in close in Concurrent program Call'+str(e))
			print(traceback.format_exc())
		
	def find_request(self):
		
		self.no_of_calls=self.no_of_calls+1
		dt=datetime.now()#.isoformat()
		self.program_date=dt.strftime('%m_%d_%Y')
		
		if self.run_history=='Y':
			self.request_key='flipt_concurrent_requests::'+self.program_name[:-3]+'_'+self.program_date			
		else:
			self.request_key='flipt_concurrent_requests::'+self.program_name[:-3]+'_No_History'			
		#print(self.request_key)
		
		program = N1QLQuery('select count(*) as programct from `'+os.environ['CB_INSTANCE']+'` where type="flipt_concurrent_requests" and meta().id ="'+self.request_key+'"',domain_name = self.domain)
		program.adhoc = False
		program.timeout = 100
				
		for pcountrow in cb.n1ql_query(program):
			programct = pcountrow['programct']			
							
		if programct == 0:
			self.create_request()			
		else:
			self.update_request()			
		
	
	def create_request(self):		
		
		#print('In create Requests')
		concurrentrecs = {}
		concurrentrecs['program_name']=self.program_name
		
		concurrentrecs['program_date']=self.program_date
		concurrentrecs['program_file_name']=self.program_name
		concurrentrecs['send_mail']=self.send_mail
		concurrentrecs['logfile']=self.logfile
		concurrentrecs['run_history']=self.run_history
		concurrentrecs['type']='flipt_concurrent_requests'
		concurrentrecs['request_details']=[]
		
		requestsrecs = {}
		self.starttime=str(datetime.now())
		requestsrecs['request_id']=self.request_id
		requestsrecs['parameters']=self.parameters
		requestsrecs['request_start_time']=self.starttime
		requestsrecs['request_end_time']=self.completiontime
		requestsrecs['phase']='S'
		requestsrecs['status']='S'
		requestsrecs['log_file_dir']=self.logfilepath
		requestsrecs['error_message']=self.error_message
		
		requestsrecs['no_rec_received']=self.no_rec_received 
		requestsrecs['no_rec_processed']=self.no_rec_processed 
		requestsrecs['no_rec_errored']=self.no_rec_errored 
		requestsrecs['no_old_unres_err']=self.no_old_unres_err 
		requestsrecs['notes']=self.concurrent_notes
		
		concurrentrecs['request_details'].append(requestsrecs)		
		
		cb.upsert(self.request_key,concurrentrecs)
		
	
	def update_request(self):	
		
		program = N1QLQuery('select a.* from `'+os.environ['CB_INSTANCE']+'` a where type="flipt_concurrent_requests" and meta().id ="'+self.request_key+'"',domain_name = self.domain)
		
		program.adhoc = False
		program.timeout = 100
		#print(program)
		allrecs = {}
		concurrentrecs = {}
		
		#for programrow in cb.n1ql_query(program):
		#	allrecs=programrow
		#for tab, rec in allrecs.items(): #to get only record; and exclude data base name
		#	concurrentrecs=rec
		
		for programrow in cb.n1ql_query(program):
			concurrentrecs=programrow			
		
		concurrentrecstemp=[]
		
		#if concurrentrecs['request_details'] in programrow:
		concurrentrecstemp=concurrentrecs['request_details']
		concurrentrecs['request_details']=[]
		
		requestrec ={}
		ct=0
		for rec in concurrentrecstemp:
			requestrec=rec;
			if requestrec['request_id']==self.request_id:
				requestrec['request_end_time']=str(datetime.now())
				requestrec['no_rec_received']=self.no_rec_received 
				requestrec['no_rec_processed']=self.no_rec_processed 
				requestrec['no_rec_errored']=self.no_rec_errored 
				requestrec['no_old_unres_err']=self.no_old_unres_err 
				requestrec['notes']=self.concurrent_notes
				requestrec['error_message']=self.error_message
				ct=ct+1
				if self.run_history=='N' and self.no_of_calls==1:
					self.starttime=str(datetime.now())
					requestrec['request_start_time']=self.starttime
			concurrentrecs['request_details'].append(requestrec)	
		
		if ct==0:
			requestsrecs = {}
			self.starttime=str(datetime.now())
			requestsrecs['request_id']=self.request_id
			requestsrecs['parameters']=self.parameters
			requestsrecs['request_start_time']=self.starttime
			#requestsrecs['request_end_time']=self.completiontime
			requestsrecs['phase']='S'
			requestsrecs['status']='S'
			requestsrecs['log_file_dir']=self.logfilepath
			requestsrecs['error_message']=self.error_message
			requestsrecs['request_end_time']=str(datetime.now())
			requestsrecs['no_rec_received']=self.no_rec_received 
			requestsrecs['no_rec_processed']=self.no_rec_processed 
			requestsrecs['no_rec_errored']=self.no_rec_errored 
			requestsrecs['no_old_unres_err']=self.no_old_unres_err 
			requestsrecs['notes']=self.concurrent_notes	
			concurrentrecs['request_details'].append(requestsrecs)	
		
		if self.run_history=='N' and self.no_of_calls==1:
			concurrentrecs['program_date']=self.program_date			
		
		cb.upsert(self.request_key,concurrentrecs)
		
	
	def requestid(self):
		if self.run_history=='N':
			self.request_id='1'
		else:
			if self.request_id=='':
				#self.request_id='1000';
				rv=cb.counter('docid',delta=1)
				self.request_id=str(rv.value)
	
	
	def findprogram(self):
		#select * from `FLIPT-DEV` where type='flipt_concurrent_programs' and program_file_name='aetnadeductibleupdate.py'		
		
		program = N1QLQuery('select count(program_name) as programct from`'+os.environ['CB_INSTANCE']+'` t where type="flipt_concurrent_programs" and meta().id="'+self.program_id+'"',domain_name = self.domain)
		program.adhoc = False
		program.timeout = 100
		
		
		for pcountrow in cb.n1ql_query(program):
			programct = pcountrow['programct']
		
		#self.createprogram()
		if programct == 0:
			self.createprogram()
		else:
			program = N1QLQuery('select program_name,program_type,run_history,logfile, send_mail from`'+os.environ['CB_INSTANCE']+'` t where type="flipt_concurrent_programs" and meta().id="'+self.program_id+'"',domain_name = self.domain)
			program.adhoc = False
			program.timeout = 100
			for programrow in cb.n1ql_query(program):
				#self.program_id = str(programrow['program_id'])
				self.program_name = str(programrow['program_name'])
				self.program_type = str(programrow['program_type'])	
			
				if 'run_history' in programrow:
					self.run_history = str(programrow['run_history'])
				else:
					self.run_history='N'
				
				if 'send_mail' in programrow:
					self.send_mail = str(programrow['send_mail'])
				else:
					self.send_mail='N'
				
				if 'logfile' in programrow:
					self.logfile = str(programrow['logfile'])
				else:
					self.logfile='Y' #need to default to N -senthil
				
				if (self.run_history=='N' or self.run_history==''):
					self.send_mail='N'
					self.logfile='N'
				
				#print(self.program_type)
			
	def createprogram(self):
		#print('In Create'+self.program_id)
		concurrentrecs = {}
		concurrentrecs['program_name']=self.scriptname
		concurrentrecs['program_type']='Not Defined'
		concurrentrecs['run_history']='Y'
		concurrentrecs['send_mail']='Y'
		concurrentrecs['logfile']='Y'
		concurrentrecs['type']='flipt_concurrent_programs'
		cb.upsert(self.program_id,concurrentrecs)
		self.program_name=self.scriptname
		self.program_type='Not Defined'
		self.run_history='Y'
		self.send_mail='Y'
		self.logfile='Y'
	
'''
########################################################################################
Class Name 			: 		logfile

To create log file and given directory
filename need to provided in input; File name will be padded with _log.txt
Email will be send to distribution list based parameter 
########################################################################################
'''
	
class logfile:
	fullfilename=''
	sender='noreply@fliptrx.com'
	receiver=['fliptintegration@fliptrx.com']
	#receiver=['srajamanickam@gwlabs.com']
	subject='Concurrent - Log' #program name / host_name / 
	body='Concurrent Log File '
	file=''
	emailflag='N'
	
	def writeline(self,text):
		#file.write('------------------------------------------------------------------\n\r')
		if text == 'Line':
			self.file.write('----------------------------------------------------------------------------------------\r\n')
		elif text == 'time':
			self.file.write(str(datetime.now())+'\r\n')
		else:
			self.file.write(text+'\r\n')
	
	def __init__(self,filepath,filename,emailflag):
		self.fullfilename=filepath+'/'+filename+'_log.txt'
		os.makedirs(os.path.dirname(self.fullfilename), exist_ok=True)	
		self.emailflag=emailflag
		#self.emailflag='Y'
		#print(self.fullfilename)
		self.open()
		
	def open(self):
		self.file=open(self.fullfilename,'w')
		self.writeline('Line')
		self.writeline('File Path	:	'+self.fullfilename)
		self.writeline('time')
		self.writeline('Line')
		self.writeline('Log File Header')
		self.writeline('Line')	
	
	#def __del__(self):	 # Since __del__ can not controll programattically new procedure is created 
	def close(self):
		self.writeline('Line')
		self.writeline('time')
		self.writeline('Line')
		if(self.emailflag=='Y'):
			self.writeline('Log file sent via Email to:'+self.receiver[0])
		self.file.close();
		if(self.emailflag=='Y'):
			self.email();
	
	def email(self):
		email_log(self.sender,self.receiver[0],None,self.subject,self.body,self.fullfilename,True)
		#email_log(,,,subject,['Processing of Script Claim Drug Pricing File '+file_name+str(currentdate),'Script Claim Drug Pricing Exception'],err,True)