########################################

# !/usr/bin/env python 

# title : twilioSendSMS.py
# description : send SMS notification by twilio api
# author : Hari
# date created : -
# last  modified : 
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  call in another program
#                   import twilioSendSMS 
#                   status, msg = twilioSendSMS.sendSMS('', '', +13648889940', "Flipt Test SMS 2nd test.")
#                   print(status, msg)

# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------

# #######################################
from twilio.rest import Client
import os, re
from truevaultV3 import User_Class
import traceback

def sendSMS(flipt_person_id,rx_flipt_person_id, toPhNumber, msgBody):
    try:
        # Account Sid and Auth Token from twilio.com/console
        account_sid = os.environ['TWILIO_SID']
        auth_token = os.environ['TWILIO_AUTH_TOKEN']
        client = Client(account_sid, auth_token)
        '''
        # Get  phone number by flipt_person_id
        if not toPhNumber or toPhNumber == '':
            obj=User_Class(None,None)
            search_option={'full_document':True,'filter':{'flipt_person_id':{'type':'eq','value':flipt_person_id,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
            att,userid = obj.search_user(search_option)
            if att and att['communication_option_phone']:
                toPhNumber = att['communication_option_phone']
            # toPhNumber = '+1'+att['communication_option_phone']

        # Get  phone number by rx_flipt_person_id
        if not toPhNumber or toPhNumber == '':
            obj=User_Class(None,None)
            search_option={'full_document':True,'filter':{'flipt_person_id':{'type':'eq','value':rx_flipt_person_id,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
            att,userid = obj.search_user(search_option)
            if att and att['communication_option_phone']:
                toPhNumber = att['communication_option_phone']
        '''
        # if no phone number
        if not toPhNumber or toPhNumber == '':
            return 'failed', 'Destination phone number not identified'

        toPhNumber = re.sub('[^0-9]', '', toPhNumber)[-10:]
        if len(toPhNumber) != 10:
            return 'failed', 'Destination phone number is incorrect'
        toPhNumber = '+1'+toPhNumber
        
        message = client.messages.create(body=msgBody,from_='+12018905255',to= toPhNumber)
        # print(message.status)
        return 'success', message.sid
    except Exception as e:
        #traceback.print_exc()
        print(e)
        return 'failed', str(e)
    



# this is only for testing
# if __name__ == "__main__":
#     status, msg = sendSMS('0024344','','', "Flipt Test SMS 3rd disha test.")
#     status, msg = sendSMS('+13648889940', "Flipt Test SMS 2nd test.")
#     print(status, msg)


