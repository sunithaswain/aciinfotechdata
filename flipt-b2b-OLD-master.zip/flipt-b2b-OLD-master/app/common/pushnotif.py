########################################
# !/usr/bin/env python 

# title : pushnotif.py
# description : Sends push notifications to users

# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  used in other programs as follows
                    # from pushnotif import send_push_message
                    # send_push_message('sample message here')
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(rootdir)
   
from exponent_server_sdk import DeviceNotRegisteredError
from exponent_server_sdk import PushClient
from exponent_server_sdk import PushMessage
from exponent_server_sdk import PushResponseError
from exponent_server_sdk import PushServerError
from requests.exceptions import ConnectionError
from requests.exceptions import HTTPError
import rollbar

# Basic arguments. You should extend this function with the push features you
# want to use, or simply pass in a `PushMessage` object.
def send_push_message(token, message, extra, heading=None):
    success=True
    try:
        if heading is not None:
            response = PushClient().publish(
                PushMessage(to=token,
                            body=message,
                            data=extra,
                            title=heading))
        else:
            response = PushClient().publish(
                PushMessage(to=token,
                            body=message,
                            data=extra))
        
    except PushServerError as exc:
        success=False
        # Encountered some likely formatting/validation error.
        rollbar.report_exc_info(
            extra_data={
                'token': token,
                'message': message,
                'extra': extra,
                'errors': exc.errors,
                'response_data': exc.response_data,
            })
        return success
        #raise
    except (ConnectionError, HTTPError) as exc:
        success=False
        # Encountered some Connection or HTTP error - retry a few times in
        # case it is transient.
        rollbar.report_exc_info(
            extra_data={'token': token, 'message': message, 'extra': extra})
        raise self.retry(exc=exc)
        return success
    except Exception as e:
        success=False
        return success
    try:
        # We got a response back, but we don't know whether it's an error yet.
        # This call raises errors so we can handle them with normal exception
        # flows.
        response.validate_response()
    except DeviceNotRegisteredError:
        # Mark the push token as inactive
        success=False
        #exit()
        return success
        from notifications.models import PushToken
        PushToken.objects.filter(token=token).update(active=False)
    except PushResponseError as exc:
        # Encountered some other per-notification error.
        success=False
        rollbar.report_exc_info(
            extra_data={
                'token': token,
                'message': message,
                'extra': extra,
                'push_response': exc.push_response._asdict(),
            })
        raise self.retry(exc=exc)
        return success
    return success
#ExponentPushToken[Ao6dXmEIM8Ly6AWesMBbeY]
#send_push_message('ExponentPushToken[oHzgnZISX0uvsrA3S2T2]','Just got a token !!!!',{'message':'Just got a token'})
