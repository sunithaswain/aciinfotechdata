########################################
# !/usr/bin/env python 

# title : awssftpfileops.py
# description : Amazon SFTP Gateway with S3 Integration
# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  It will called from other programs
					# listbucketcontents('aetnaintegration/uploads/GWLABS001/deductible')
					#downloadfile('gwhrintegration/uploads','GWLABS001','employee','Emp_Load_12142018.xlsx','draft')
					#uploadfile('GWLABS001','employee','Emp_Load_11012018.xlsx','gwhrintegration/uploads')
					#deletefile('aetnaintegration/uploads/GWLABS001/deductible','GW_LABORATORIES 06-15-2018.xlsx')
					#copyfile('aetnaintegration/uploads/GWLABS001/deductible','GW_LABORATORIES 06-15-2018.xlsx','aetnaintegration/uploads/GWLABS001/deductible/archive')
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(rootdir)
   
import os
import io
import errno
import socket
import sendgrid
import base64
import json
import codecs
import sys, traceback
from datetime import datetime
import urllib.request as urllib

import boto3
import botocore

from sendgrid.helpers.mail import Email, Content,Attachment, Substitution, Mail 

#define log file
logfilename='SFTPFileOpsLog'+str(datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())+'.txt'
log = os.environ['CB_DATA']+'/GWLABS001/Aetna/log/'+logfilename

logfile = open(log,"w")
#connect to the server using access keys
access_key = os.environ['AWS_ACCESS_KEY_ID']
secret_key = os.environ['AWS_SECRET_ACCESS_KEY']
session_token = ''

logfile.write('***Connecting to the SFTP server at '+str(datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())+'***\r\n\r\n')
logfile.close()
my_client = boto3.client(
    's3',
    aws_access_key_id = access_key,
    aws_secret_access_key = secret_key
)
my_resource = boto3.resource('s3')
bucketname = my_resource.Bucket(os.environ['AMAZON_SFTP_BUCKET'])
client = my_client
bucket = bucketname.name

'''
func uploadfile() uploads file "filename" from local directory "domain/filetype" to sftp server directory "destination"  
'''
def uploadfile(domain,filetype,filename,destination):

	global log
	#upload the file
	logfile = open(log,"w")
	
	try:
		#uploading file and logging it
		logfile.write('Uploading file to the SFTP server at '+str(datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())+'\r\n\r\n')
		my_resource.Bucket(bucketname.name).upload_file(os.environ['CB_DATA']+'/'+domain+'/'+filetype+'/'+filename,destination+'/'+filename)
		logfile.write('File Upload Successful at '+str(datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())+'\r\n\r\n')
		logfile.close()
		sendemail('File Upload Success',log,'File '+filename+' was successfully uploaded to '+destination+'.',logfilename)
		
	except Exception as e:
		#record exception/error while uploading the file
		logfile.write('An Exception Occurred while uploading file to the SFTP server at '+str(datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())+'\r\n\r\n')
		type, value, etraceback = sys.exc_info()
		error=""
		x=traceback.format_exception(type, value, etraceback)
		for i in x:
			error=error+i
		logfile.write(error)
		logfile.close()
		sendemail('File Upload Error',log,'An error was encountered while uploading the File: '+filename+', to '+destination+'. Please check the logfile to review the error details.',logfilename)
		
	return destination+'/'+filename

'''
func deletefile() deletes file "filename" from sftp server directory "destination"
'''
def deletefile(destination,filename):
	#file deletion
	
	global log
	logfile = open(log,"w")
	try:
		#delete the given file from the given destination on the server
		logfile.write('Deleting file from the SFTP server at '+str(datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())+'\r\n\r\n')
		response=bucketname.delete_objects(Delete={
				'Objects': [
					{
						'Key': destination+'/'+filename,
					},
				],
				'Quiet': False
			},
		)
		#print(response)
		#print(response['ResponseMetadata']['HTTPStatusCode'])
		logfile.write('File Deletion Successful at '+str(datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())+'\r\n\r\n')
		logfile.close()
		
	except Exception as e:
		#record exception/error while deleting the file
		logfile.write('An Exception Occurred while uploading file to the SFTP server at '+str(datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())+'\r\n\r\n')
		type, value, etraceback = sys.exc_info()
		error=""
		x=traceback.format_exception(type, value, etraceback)
		for i in x:
			error=error+i
		logfile.write(error)
		logfile.close()
		sendemail('File Deletion Error',log,'An error was encountered while deleting the File: '+filename+', to '+destination+'. Please check the logfile to review the error details.',logfilename)
	return destination+'/'+filename

'''
func listbucketcontents() lists all the contents of the current bucket
'''
def listbucketcontents(directory):
	#list objects in bucket
	#print(bucketname)
	objlist=[]
	#print(bucketname.objects.all())
	for obj in bucketname.objects.all():
		if directory in obj.key: objlist.append(obj.key)
		print(obj.key)
	return objlist

'''
func readfile() reads the file having "filename" in "directory"
'''
def readfile(directory,filename):
	#list bucket content and compare with desired directory and filename
	
	for obj in bucketname.objects.all():
		
		if directory+filename in obj.key:
			return io.BytesIO(obj.get()['Body'].read())
	return None	
	
'''
func copyfile() copies file "filename" from sftp server directory "source" to sftp server directory "destination"  
'''
def copyfile(source,filename,destination):
	#copy file from one folder to another
	
	global log
	logfile=open(log,'w')
	try:
		logfile.write('Copying file at '+str(datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())+'\r\n\r\n')
		copy_source = {
			'Bucket': bucket,
			'Key': source+'/'+filename
		}
		my_resource.meta.client.copy(copy_source, bucket, destination+'/'+filename)
		logfile.write('File Copy Successful at '+str(datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())+'\r\n\r\n')
		logfile.close()
		
	except Exception as e:
		#record exception/error while deleting the file
		logfile.write('An Exception Occurred while copying file at '+str(datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())+'\r\n\r\n')
		type, value, etraceback = sys.exc_info()
		error=""
		x=traceback.format_exception(type, value, etraceback)
		for i in x:
			error=error+i
		logfile.write(error)
		logfile.close()
		sendemail('File Copying Error',log,'An error was encountered while copying the File: '+filename+', to '+destination+'. Please check the logfile to review the error details.',logfilename)

	
'''
func downloadfile() downloads file "filename" from sftp server directory "source" to local directory "domain/type"; 
archiving the file if function called in the final mode
'''

def downloadfile(source,domain,filetype,filename,mode):

	#download a file
	
	global log
	logfile = open(log,"w")
	
	try:
		logfile.write('Downloading file from the SFTP server at '+str(datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())+'\r\n\r\n')
		my_resource.Bucket(bucketname.name).download_file(source+'/'+filename, os.environ['CB_DATA']+'/'+domain+'/'+filetype+'/'+filename)
		logfile.write('File Download Successful at '+str(datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())+'\r\n\r\n')
		logfile.close()
		sendemail('File Download Success',log,'File '+filename+' was successfully downloaded to '+os.environ['CB_DATA']+'/'+domain+'/'+filetype+'.',logfilename)
	except Exception as e:
		
		type, value, etraceback = sys.exc_info()
		error=""
		x=traceback.format_exception(type, value, etraceback)
		for i in x:
			error=error+i
		
		logfile.write(str(error))
		logfile.close()
		sendemail('File Download Error',log,'An error was encountered while downloading the File: '+filename+', from '+source+'. Please check the logfile to review the error details.',logfilename)
	if mode.upper().strip()=='FINAL':
		copyfile(source,filename,source+'/archive')
		deletefile(source,filename)
		logfile = open(log,"w")
		logfile.write('Archiving the file at '+str(datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())+'\r\n\r\n')
	logfile.close()
	return os.environ['CB_DATA']+'/'+domain+'/'+filetype+'/'+filename
	
'''
func sendemail() sends email
'''

def sendemail(subject,filepath,body,filename):
	sender='noreply@fliptrx.com'
	receiver1='DWagle@GWLabs.com'
	receivers=['SSubramani@GWLabs.com']
	host = socket.gethostname()
	sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))
	from_email = Email(sender)
	to_email = Email(receiver1)
	subject = host+': '+subject
	filepath= filepath
	content = Content("text/plain", body)
	mail = Mail(from_email, subject, to_email, content)
	if filepath!=None:
		with open(filepath,'rb') as f:
			data=f.read()
			f.close()
		encoded=base64.b64encode(data).decode()
		attachment=Attachment()
		attachment.content = encoded
		attachment.type = "application/pdf"
		attachment.filename = filename
		attachment.disposition = "attachment"
		attachment.content_id = "Example Content ID"
		mail.add_attachment(attachment)
	for ids in receivers:
		mail.personalizations[0].add_to(Email(ids))	
	response = sg.client.mail.send.post(request_body=mail.get())

#downloadfile('aetnaintegration/downloads/deductible','GWLABS001','Aetna','GW_LABORATORIES_12012018.xlsx','draft')
#uploadfile('GWLABS001','deductible','G&W_LABORATORIES_62918.xlsx','aetnaintegration/uploads/GWLABS001/deductible')
listbucketcontents('aetnaintegration/uploads/GWLABS001/deductible')
#downloadfile('gwhrintegration/uploads','GWLABS001','employee','Emp_Load_12142018.xlsx','draft')
#uploadfile('GWLABS001','employee','Emp_Load_11012018.xlsx','gwhrintegration/uploads')
#deletefile('aetnaintegration/uploads/GWLABS001/deductible','GW_LABORATORIES 06-15-2018.xlsx')
#copyfile('aetnaintegration/uploads/GWLABS001/deductible','GW_LABORATORIES 06-15-2018.xlsx','aetnaintegration/uploads/GWLABS001/deductible/archive')

