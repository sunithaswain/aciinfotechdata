########################################

# !/usr/bin/env python 

# title : humanapricing.py
# description : Update coverage tier mapping update
# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Deepthi
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  python humanapricing.py -d GWLABS001 -t cp_drug_price -f FLIPT_HUMANA_TRAD_MAIL_PRICE_LIST_20181218_V3_FINAL_AWP1.xlsx%%mailorder -m draft
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------
# 1.1 Hari 02012019 Added dfrat mode and log file to get update status

# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(rootdir)
   
import json
import pandas as pd
import base64
import pprint
import shutil
import os
import sys
import paramiko
import time
import socket
import csv, re
from datetime import datetime

from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from couchbase import FMT_JSON
import couchbase.subdocument as SD

from app.common.sendgridemail import email_log
import app.common.commandline as commandline
from app.common.truevault import User_Class
from app.common.scriptclaimsftp import sftptransfer, fileexists

# domain,file_type,file_name,mode = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
domain,file_type,file_name,mode = commandline.main(sys.argv[1:])
cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
path = os.environ['CB_DATA']

def priceupdate(domain,file_type,common_file_name):

	# Hari Modified, common_file_name should be seperated with %%, eg: file_name%%maclist
	# ------------------------------------------------
	currdate=datetime.strftime(datetime.now(),'%m%d%Y')
	lstFileName = common_file_name.split('%%')
	print('common_file_name %s'%(lstFileName))
	print(lstFileName)
	file_name, maclist = lstFileName[0], lstFileName[1]
	claim_processor=''
	if maclist=='specialty':
		maclistID='HPSPECLMAC'
		claim_processor='sc_humanas'
	else:
		maclistID='HPTRADMAC'
		claim_processor='sc_humanam'
	# -------------------------------------------------

	df=pd.read_excel(os.environ['CB_DATA']+'/'+domain+'/'+file_type+'/'+file_name)
	#humanapricingfile= open(os.environ['CB_DATA']+'/'+domain+'/'+file_type+'/humanapricing'+,"w")
	hpfmac=pd.DataFrame()
	hpfmac_unload=pd.DataFrame()
	log = os.environ['CB_DATA']+'/'+domain+'/'+file_type+'/log/humanapricing'+str(currdate)+'.txt'
	logfile = open(log,"w")
	host = socket.gethostname()
	
	df['GPI']=df['GPI'].apply(lambda x: str(x).zfill(14))   #make zeros in front, if GPI less than 14 characters
	#print(df.head())
	loaded_count = 0
	unloaded_count = 0
	MACcount = 0
	AWPcount = 0
	# myfile = open(os.environ['CB_DATA']+'/'+domain+'/'+file_type+'/HumanaMACPrice'+str(currdate)+'_test.csv', 'w', newline='') 
	update_status_list=[]
	for i,r in df.iterrows():
		
		borg=r['BRAND_GENERIC'].replace('G','Generic').replace('B','Brand').replace('T','Brand')
		query=N1QLQuery("Select cp_price,meta().id id,drug_descriptor_identifier,productnamefull from `"+os.environ['CB_INSTANCE']+"` where type='cp_drug_price' and gpi=$g and brandorgeneric=$bg and drug_name=$dn",g=r['GPI'].strip(),bg=borg,dn=r['DRUG_NAME'].strip())
		# print(query)
		li=[]
		docid=''
		ddid=''
		scborg=''
		
		output= maclistID+'|'+r['GPI'].strip()+'||'     # Hari Modified maclistID
		for rec in cb.n1ql_query(query):
			li.extend(rec['cp_price'])
			docid=rec['id']
			output=output+rec['productnamefull']
			ddid=rec['drug_descriptor_identifier']

		# print('li values %s'%str(li))
		
		addedrec={}
		# print('docid values %s'%str(docid))
		if len(li)>0:

			if li[0]['pricetype']=='MAC':
				# Here code changed for Jira ID B2B-167
				if maclistID == 'HPTRADMAC': continue

				addedrec['maclistid']= maclistID   # Hari Modified maclistID
				addedrec['rebate_factor']=''
				addedrec['unitprice']="{0:.5f}".format(r['MAC_UNIT_PRICE'])
				addedrec['pricetype']='MAC'
				addedrec['unit_price_before_rebate']="{0:.5f}".format(r['MAC_UNIT_PRICE'])
				addedrec['claim_processor']=claim_processor
				addedrec['sc_brandorgeneric']=borg
				MACcount += 1
			else:
				#for including rebate factor
				'''
				try:
					rebate_factor=float(li[0]['rebate_factor'])
					addedrec['unitprice']="{0:.5f}".format(float(r['MAC_UNIT_PRICE'])*rebate_factor)
				except Exception as e:
					addedrec['unitprice']="{0:.5f}".format(r['MAC_UNIT_PRICE'])
				'''
				addedrec['maclistid']=''
				addedrec['rebate_factor']=''
				addedrec['unitprice']="{0:.5f}".format(r['MAC_UNIT_PRICE'])
				addedrec['pricetype']='AWP'
				addedrec['unit_price_before_rebate']="{0:.5f}".format(r['MAC_UNIT_PRICE'])
				addedrec['claim_processor']=claim_processor
				addedrec['sc_brandorgeneric']=borg
				AWPcount += 1
		if 'unitprice' not in addedrec:
			print(r['GPI'],r['DRUG_NAME'])
			unloaded_count += 1
			r['BRAND_GENERIC'] = r['BRAND_GENERIC'].replace('G','Generic').replace('B','Brand').replace('T','Brand')
			# logfile.write("unit price is not availale for : "+str(r.to_dict())+'\n')

			r['Result'] = 'unit price is not available'
			hpfmac_unload = hpfmac_unload.append(r.to_dict(),ignore_index=True)
			# update_status_list.append(r.to_dict())
			continue
		update=False
		for ite in range(len(li)):
			
			if li[ite]['claim_processor']!=claim_processor: scborg=li[ite]['sc_brandorgeneric']
			if li[ite]['claim_processor']==claim_processor :
				update=True
				li[ite]['unitprice']=addedrec['unitprice']
				li[ite]['unit_price_before_rebate']=addedrec['unit_price_before_rebate']
		if not update:
			li.append(addedrec)
		output=output+'|'+addedrec['unitprice']+'|'+r['DRUG_NAME'].strip()+'|'+addedrec['pricetype'].strip()+'|'
		if scborg=='Brand':
			drugquery=N1QLQuery("Select brand_generic from `"+os.environ['CB_INSTANCE']+"` where type='drug' and gpi=$g and drug_name=$dn",g=r['GPI'].strip(),bg=borg,dn=r['DRUG_NAME'].strip())
			for drugrec in cb.n1ql_query(drugquery):
				output=output+drugrec['brand_generic']+'|Brand|'
		else:
			output=output+'G|Generic|'

		

		output=output+ddid

					
		#print(li)
		if docid=='':
			print(r['GPI'],r['DRUG_NAME'])
		if addedrec['pricetype']=='MAC':
			outrecord={'MacListID|GPICode|GPPC|GenericName|UnitPrice|ProductNameAbr|BrandNameCode|BrandorGeneric|DDID':output}
			hpfmac=hpfmac.append(outrecord,ignore_index=True)
		if docid!='':
			# print('docid values %s'%str(docid))
			# print(li)
			loaded_count += 1
			try:
				if mode.upper().strip() == 'FINAL':
					cb.mutate_in(str(docid),SD.upsert('cp_price',li))
					# Here code changed for Jira ID B2B-167
					# ---------------------------------------
					if maclist=='specialty':
						drugquery2=N1QLQuery("update `"+os.environ['CB_INSTANCE']+"` set specialty_flag = 'Y' where specialty_flag = 'N' and type='drug' and gpi=$g and drug_name=$dn",g=r['GPI'].strip(),bg=borg,dn=r['DRUG_NAME'].strip())
						cb.n1ql_query(drugquery2).execute()
					# -----------------------------------------------------
			except:
				logfile.write("Upsert failed ")

			r['BRAND_GENERIC'] = r['BRAND_GENERIC'].replace('G','Generic').replace('B','Brand').replace('T','Brand')
			r['Result'] = 'Upsert Successful'
			hpfmac_unload = hpfmac_unload.append(r.to_dict(),ignore_index=True)
			# update_status_list.append(r.to_dict())
			# logfile.write("Upsert Successful for : "+str(r.to_dict())+'\n')
			
	# myfile.close()
	logfile.write('Total_count %s'%(len(df))+'\n')
	logfile.write('loaded_count %s'%(loaded_count)+'\n')
	logfile.write('unloaded_count %s'%(unloaded_count)+'\n')
	logfile.write('MACcount %s'%(MACcount)+'\n')
	logfile.write('AWPcount %s'%(AWPcount)+'\n')
	print('Total_count %s'%(len(df)))
	print('loaded_count %s'%(loaded_count))
	print('unloaded_count %s'%(unloaded_count))
	print('MACcount %s'%(MACcount))
	print('AWPcount %s'%(AWPcount))
	hpfmac.to_csv(os.environ['CB_DATA']+'/'+domain+'/'+file_type+'/HumanaMACPrice'+str(currdate)+'.csv',index=False)
	hpfmac_unload.to_csv(os.environ['CB_DATA']+'/'+domain+'/'+file_type+'/log/humanapricing'+str(currdate)+'.csv',index=False)
	if mode.strip().upper() == 'DRAFT':
		logfile.write('Humana price update - Draft Mode :'+host+file_name)
		subject = 'Humana price update - Draft Mode :'+host
		logfile.close()		
		email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','SSubramani@GWLabs.com,hrajendran@fliptrx.com',subject,['Humana price update File '+log,'Humana price update Exception'],log,True)
	else:
		logfile.close()		

			
priceupdate(domain,file_type,file_name)
