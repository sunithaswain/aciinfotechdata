########################################
# !/usr/bin/env python  
# title         : scriptclaimpricingvalV3.py
# description   : Script Claim AWP/MAC  prices upload
# author        : Disha
# date created  : 20180101
# date last modified    : 20181030 16:28
# version       : 0.1
# maintainer    : Pal
# email         : pmuthanai@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage 1         : python scriptclaimpricingvalV3.py -d GWLABS001 -t cp_drug_price -f cp_awp_price2018-02-22 -m DRAFT
# usage 2         : nohup python scriptclaimpricingvalV3.py -d GWLABS001 -t cp_drug_price -f cp_awp_price2018-02-22 -m FINAL > cp_awp_price2018-02-22.log 2> cp_awp_price2018-02-22.err < /dev/null &
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  
# #######################################

# import json

# import base64
# import pprint
import shutil
import os
import sys
# import time
from datetime import datetime

import pandas as pd
# import paramiko
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
# from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from couchbase import FMT_JSON
import couchbase.subdocument as SD

# Added to update the system path to refer our custom packages
if __name__ == '__main__':
    import os
    import sys
    rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.append(rootdir)

import app.common.commandline as commandline
from app.common.sendgridemail import email_log
# from app.common.truevault import User_Class
#from scriptclaimsftp import sftptransfer
#from scriptclaimsftp import fileexists



cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
path = os.environ['CB_DATA']
domain,file_type,file_name,mode = commandline.main(sys.argv[1:])
currentdate = datetime.now()
currentdate = currentdate.isoformat()
# remotepath = '/cp_drug_price/'+file_name+'.csv'
localpath = path+'/'+domain+'/'+file_type+'/'+file_name+'.csv'
#log = path+'/'+domain+'/'+file_type+'/log/'+file_name+str(currentdate)+'.txt'
err = path+'/'+domain+'/'+file_type+'/log/'+file_name+str(currentdate)+'Log.xlsx'
archivefile = path+'/'+domain+'/'+file_type+'/archive/'+file_name+str(currentdate)+'.csv'
writer=pd.ExcelWriter(err,engine='xlsxwriter')

transferstatus = ''
# loadtype = 'I'
# updatecount = 0
def scriptclaimpricing():
	
	error=pd.DataFrame()
	# FTP 
	'''
	filestatus =fileexists(remotepath)
	if filestatus == 'S':
		logfile.write("Script Claim Drug File Exists in Remote Directory "+"\r\n")
		transferstatus = sftptransfer(remotepath,localpath,'GET')
		if transferstatus != 'S':
			logfile.write("Script Claim Drug File Transfer Failed "+"\r\n")
			logfile.close()
			sys.exit()
			
		else:
			logfile.write("Script Claim Drug File was successfully transferred "+"\r\n")
			filesize = os.path.getsize(localpath)
			if filesize > 0:
				logfile.write("Script Claim Drug File size is greater than 0 "+"\r\n")
			else:
				logfile.write("Script Claim Drug File is 0 "+"\r\n")
				logfile.close()
				sys.exit()
				
	else:
		logfile.write("Script Claim Drug File does not Exist in Remote Directory "+"\r\n")
		logfile.close()
		sys.exit()
	'''
	transferstatus = 'S'
	print(transferstatus)
	
	if transferstatus == 'S' and 'cp_awp_price' in file_name:
		#email_log('DWagle@fliptrx.com','DWagle@fliptrx.com','SSubramani@fliptrx.com','Script Claim Drug Price -Initiated',['Processing of Script Claim Drug Price files '],None,False)
		drugfile=pd.read_csv(localpath, sep='|', index_col=False, names=["GPICode", "MultiSourceCode","UnitPrice" , "ProductNameAbr", "ProductNameFull", "ProductStrength", "DosageFormID", "UnitOfMeasure", "PriceType", "BrandOrGeneric", "PackSize", "PackUOM", "UnitDose", "GPPC","Package_Quantity","DispensingText","Package_Description_Code","OTCIndicator","Drug_Descriptor_Identifier","Brand_Name_Code","Item_Status_Flag"],skiprows = 1,dtype={'UnitPrice':str})
		drugfile.fillna("",inplace=True)
		drugfile.drop_duplicates(inplace=True)

		drug_cols = {"GPICode":"gpi", "MultiSourceCode":"multiscourcecode","UnitPrice":"unitprice" , "ProductNameAbr":"drug_name", "ProductNameFull":"productnamefull", "ProductStrength":"productstrength", "DosageFormID":"dosageformid", "UnitOfMeasure":"unitofmeasure","PriceType":"pricetype", "BrandOrGeneric":"borg","PackSize":"packsize", "PackUOM":"packuom", "UnitDose":"unitdose","GPPC":"gppc", "Package_Quantity":"package_quantity","DispensingText":"dispensingtext","Package_Description_Code":"package_description_code","OTCIndicator":"otcindicator","Drug_Descriptor_Identifier":"drug_descriptor_identifier","Brand_Name_Code":"brandorgeneric","Item_Status_Flag":"item_status_flag"}
		drugfile.rename(columns=drug_cols,inplace=True)
		drug_cols=list(drugfile)
		drugfile=drugfile[drugfile['pricetype']=='AWP']
		if drugfile.empty:
			print('NO AWP Records Found')
		print(list(drugfile))
		unitp = ''
		ite=0
		for index,dprow in drugfile.groupby(['gpi','drug_name','brandorgeneric','gppc']):
			dprow.reset_index(drop= True,inplace = True)
			errort=False
			dprecs = {}
			for dpcols in drug_cols:
				if dpcols == 'unitprice':
					try:
						print(dprow.loc[0,'unitprice'])
						unitp = float(str(dprow.loc[0,'unitprice']).strip())
					except Exception as e:
						errort=True
				if dpcols not in ['unitprice','pricetype','borg']:
					dprecs[dpcols] = str(dprow.loc[0,dpcols]).strip()
			dprecs['gpi'] = str(dprecs['gpi']).replace('.0','').rjust(14,'0')
			
			if errort: 
				print(index)
				continue
			#Update Logic
			otc = str(dprecs['otcindicator']).strip()
			if otc not in ['S','R',] or ('I' not in list(dprow['item_status_flag']) and 'A' not in list(dprow['item_status_flag'])):			continue
			gpi_code = str(dprecs['gpi']).rjust(14,'0')
			gppc_code = str(dprecs['gppc']).rjust(8,'0')
			drug_name = str(dprecs['drug_name']).strip()
			sc_brand_generic = str(dprecs['brandorgeneric']).strip()
			dprecs['brandorgeneric']=''
			if str(sc_brand_generic).strip() == 'G':
				sc_brand_generic = 'Generic'
			else:
				sc_brand_generic = 'Brand'				
			
			drugcount = 0
			drugcounttab = N1QLQuery('select distinct brand_generic from `'+os.environ['CB_INSTANCE']+'` WHERE type = "drug" and gpi = $gpi and drug_name = $drug',gpi = gpi_code, drug = drug_name)
			drugcounttab.adhoc = False
			drugcounttab.timeout = 100
			b_g=''
			for drugcountrow in cb.n1ql_query(drugcounttab):			
				b_g = drugcountrow['brand_generic']
				if b_g=='G':
					dprecs['brandorgeneric']='Generic'
				else:
					dprecs['brandorgeneric']='Brand'
					
			rebfactor=''
			rebcp=[]
			#print('b or g')
			brebate = N1QLQuery('Select rebate_factor,claim_processor from `'+os.environ['CB_INSTANCE']+'` where type="brand_rebate" and brand_generic=$bg and drug_name=$dn and gpi=$gpi',bg=b_g,dn=drug_name,gpi=gpi_code)
			brebate.adhoc = False
			brebate.timeout = 100
			for rebrow in cb.n1ql_query(brebate):
				rebfactor=rebrow['rebate_factor']
				rebcp.extend(rebrow['claim_processor'])

			#print('rebate')
			updatetab = N1QLQuery('select  count(*) rec_count, c.unitprice from `'+os.environ['CB_INSTANCE']+'` t UNNEST cp_price c WHERE t.type = "cp_drug_price" and c.pricetype = "AWP" and t.gpi = $gpi_u and t.drug_name = $drug and t.gppc = $p_gppc group by t.drug_price_id, c.unitprice',gpi_u = gpi_code, drug = drug_name,p_gppc = gppc_code)
			updatetab.adhoc = False
			updatetab.timeout = 100
			unit_price=''
			for updaterow in cb.n1ql_query(updatetab):
				unit_price = updaterow['unitprice']
									

			
			dprecs['cp_price']=[]
			claim_processors=['scriptclaim','sc_walmart']
			for cp in claim_processors:
				pricerecs = {}
				pricerecs['claim_processor'] = cp
				pricerecs['rebate_factor']=rebfactor
				pricerecs['unit_price_before_rebate']=str(max(list(dprow['unitprice'])))
				active=dprow[dprow['item_status_flag']=='A']['unitprice'].values
				if(len(active)>0):
					activedict={}
					for i in active:
						activedict[float(i)] = i
					pricerecs['unit_price_before_rebate']=activedict[max(activedict.keys())]
					pricerecs['unitprice']=pricerecs['unit_price_before_rebate']
					if rebfactor!='' and cp in rebcp: pricerecs['unitprice']="{0:.5f}".format(float(pricerecs['unitprice'])*float(rebfactor))
				else:
					inactive=dprow[dprow['item_status_flag']=='I']['unitprice'].values
					inactivedict={}
					for i in inactive:
						inactivedict[float(i)]=i
					pricerecs['unit_price_before_rebate']=inactivedict[max(inactivedict.keys())]
					pricerecs['unitprice']=pricerecs['unit_price_before_rebate']
					if rebfactor!='' and cp in rebcp: pricerecs['unitprice']="{0:.5f}".format(float(pricerecs['unitprice'])*float(rebfactor))
				pricerecs['pricetype'] = str(dprow.loc[0,'pricetype'])
				pricerecs['maclistid'] = ''
				pricerecs['sc_brandorgeneric']=sc_brand_generic
				dprecs['cp_price'].append(pricerecs)
			error=error.append({'gpi':gpi_code.ljust(20),'gppc':gppc_code.ljust(10),'drug_name':drug_name,'brand_generic':sc_brand_generic,'Medispan brand_generic':'','old unit_price':unit_price,'new unit_price':pricerecs['unitprice'],'Status':'','Message':'AWP Unit Price Change'},ignore_index=True)
			    
			#print('unit prices')
				
			dprecs['create_date'] = currentdate
			dprecs['update_date'] = currentdate
			dprecs['created_by'] = 'ScriptClaim'
			dprecs['updated_by'] = 'ScriptClaim'			
			dprecs['type'] = 'cp_drug_price_stg'
			dprecs['file_name']=file_name
			#print(dprecs)
			if len(dprow)>1:
				error=error.append({'gpi':gpi_code.ljust(20),'gppc':gppc_code.ljust(10),'drug_name':drug_name,'brand_generic':sc_brand_generic,'Medispan brand_generic':'','old unit_price':'','new unit_price':'','Status':'','Message':'Multiple AWP Prices Found'},ignore_index=True)
			if mode.upper() == 'FINAL':
				rv1=cb.counter('docid',delta=1)
				dprecs['drug_price_id']=str(rv1.value)
				cb.upsert(str(dprecs['drug_price_id']),dprecs,format=FMT_JSON)
			error=error.append({'gpi':gpi_code.ljust(20),'gppc':gppc_code.ljust(10),'drug_name':drug_name,'brand_generic':sc_brand_generic,'Medispan brand_generic':b_g,'old unit_price':'','new unit_price':'','Status':'Success','Message':''},ignore_index=True)
			print(ite)
			ite=ite+1
		error.drop_duplicates(inplace=True)
		error.to_excel(writer,index=False)
		writer.save()
		subject = 'Script Claim Drug Pricing File Processed'
		email_log('DWagle@fliptrx.com','DWagle@fliptrx.com','SSubramani@fliptrx.com',subject,['Processing of Script Claim Drug Pricing File '+file_name+str(currentdate),'Script Claim Drug Pricing Exception'],err,True)
		#if mode.upper()=='FINAL': shutil.move(localpath, archivefile)
		
	elif transferstatus == 'S' and ('cp_mac_price' in file_name):
	
		email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','SSubramani@GWLabs.com','Script Claim Drug Price -Initiated',['Processing of Script Claim Drug Price files '],None,False)
		macfile=pd.read_csv(localpath, sep='|', index_col=False, names=["MacListID", "GPICode", "GPPC" ,"GenericName", "UnitPrice", "ProductNameAbr", "BrandNameCode", "BrandorGeneric", "DDID"],skiprows = 1,dtype={'UnitPrice':str,'DDID':str,'GPPC':str})
		macfile.fillna("",inplace=True)
		macfile.drop_duplicates(inplace=True)
		mac_cols = {"MacListID":"maclistid", "GPICode":"gpi", "GPPC":"gppc","GenericName":"productnamefull","UnitPrice":"unitprice" , "ProductNameAbr":"drug_name", "BrandNameCode":"brandorgeneric","BrandorGeneric":"borg","DDID":"drug_descriptor_identifier"}
		macfile.rename(columns=mac_cols,inplace=True)
		mac_cols=list(macfile)
		
		ite=0
		macfile['maclistid']=macfile['maclistid'].apply(lambda x: str(x).strip().upper())
		#print(macfile.head())
		for index,macrow in macfile.groupby(['gpi','drug_name','brandorgeneric','productnamefull','gppc','drug_descriptor_identifier']):
			macrow.reset_index(drop= True,inplace = True)
			macrecs = {}
			for maccols in mac_cols:
				if maccols not in ['borg','unitprice','pricetype','maclistid']:
					macrecs[maccols] = str(macrow.loc[0,maccols]).strip()
			macrecs['gpi'] = str(macrecs['gpi']).rjust(14,'0')
			#Update Logic
			gpi_code = str(macrecs['gpi']).rjust(14,'0')
			gppc_code = str(macrecs['gppc']).rjust(8,'0')
			drug_name = str(macrecs['drug_name']).strip()
			sc_brand_generic = str(macrecs['brandorgeneric']).strip()
			#macrecs['drug_descriptor_identifier'] = str(macrecs['drug_descriptor_identifier']).strip()
			macrecs['brandorgeneric']=''
			if str(sc_brand_generic).strip() == 'G':
				sc_brand_generic = 'Generic'
			else:
				sc_brand_generic = 'Brand'	


			drugcount = 0
			b_g=''
			drugcounttab = N1QLQuery('select distinct brand_generic from `'+os.environ['CB_INSTANCE']+'` WHERE type = "drug" and gpi = $gpi and drug_name = $drug ',gpi = gpi_code, drug = drug_name)
			drugcounttab.adhoc = False
			drugcounttab.timeout = 100
			for drugcountrow in cb.n1ql_query(drugcounttab):			
				b_g = drugcountrow['brand_generic']
				if b_g=='G':
					macrecs['brandorgeneric']='Generic'
				else:
					macrecs['brandorgeneric']='Brand'
				if b_g=='T' and sc_brand_generic=='Generic':
					error=error.append({'gpi':gpi_code,'gppc':gppc_code,'drug_name':drug_name,'brand_generic':sc_brand_generic,'Medispan brand_generic':b_g,'Status':'Warning','Message':'Brand Drug in MAC List','MACListID':'','old unit_price':'','new unit_price':''},ignore_index=True)
			rebfactor=''
			rebcp=[]

			brebate = N1QLQuery('Select rebate_factor,claim_processor from `'+os.environ['CB_INSTANCE']+'` where type="brand_rebate" and brand_generic=$bg and drug_name=$dn and gpi=$gpi',bg=b_g,dn=drug_name,gpi=gpi_code)
			brebate.adhoc = False
			brebate.timeout = 100
			for rebrow in cb.n1ql_query(brebate):
				rebfactor=rebrow['rebate_factor']
				rebcp.extend(rebrow['claim_processor'])		
					
			updatetab = N1QLQuery('select d.drug_price_id,d.cp_price from `'+os.environ['CB_INSTANCE']+'` AS d UNNEST cp_price AS t WHERE d.type = "cp_drug_price_stg" and d.gpi = $gpi and d.drug_name = $drug and t.pricetype="AWP"',gpi = gpi_code, drug = drug_name)
			updatetab.adhoc = False
			updatetab.timeout = 100
			
			for updaterow in cb.n1ql_query(updatetab):
				drug_price_id = updaterow['drug_price_id']
				cp_price = updaterow['cp_price']
				error=error.append({'gpi':gpi_code,'gppc':gppc_code,'drug_name':drug_name,'brand_generic':sc_brand_generic,'Medispan brand_generic':'','Status':'','Message':'Drug Removed from Script Claim AWP List','MACListID':'','old unit_price':'','new unit_price':''},ignore_index=True)
				if mode.upper() == 'FINAL':
					for i in cp_price:
						if i['claim_processor']=='scriptclaim':
							cp_price.remove(i)
					cb.mutate_in(str(drug_price_id),SD.upsert('cp_price',cp_price)) 
							
						
						
					
			updatetab = N1QLQuery('select d.cp_price from `'+os.environ['CB_INSTANCE']+'` AS d UNNEST d.cp_price AS t WHERE d.type = "cp_drug_price" and d.gpi = $gpi and d.drug_name = $drug and t.pricetype="MAC"',gpi = gpi_code, drug = drug_name)
			updatetab.adhoc = False
			updatetab.timeout = 100
			oldprices=pd.DataFrame()
			for updaterow in cb.n1ql_query(updatetab):
				result=updaterow["cp_price"]
				for res in result:
					oldprices=oldprices.append(res,ignore_index=True)
				
			macrecs['cp_price']=[]
			try:
				allclaimmacprice=str(macrow[macrow['maclistid']=='ALLCLAIMMAC']['unitprice'].values[0])
			except Exception as e:
				print(index)
				continue
			if not oldprices.empty:
				oldallclaimmacprice=str(oldprices[oldprices['maclistid']=='ALLCLAIMMAC']['unitprice'].values[0])
				error=error.append({'gpi':gpi_code,'gppc':gppc_code,'drug_name':drug_name,'brand_generic':sc_brand_generic,'Medispan brand_generic':'','old unit_price':oldallclaimmacprice,'new unit_price':allclaimmacprice,'Status':'','Message':'MAC Unit Price Change','MACListID':'ALLCLAIMMAC'},ignore_index=True)
			walmartmacpresent=False
			for id,prow in macrow.iterrows():			
				macpricerecs = {}
				if str(macrow.loc[id,'unitprice']) == allclaimmacprice and str(macrow.loc[id,'maclistid']).strip().upper() not in ['ALLCLAIMMAC','WALMARTMAC']: continue
				if str(macrow.loc[id,'maclistid']).strip().upper()=='WALMARTMAC':
					macpricerecs['claim_processor'] = 'sc_walmart'
					macpricerecs['rebate_factor'] = rebfactor
					macpricerecs['unit_price_before_rebate'] = str(macrow.loc[id,'unitprice'])
					if rebfactor!='' and 'sc_walmart' in rebcp:
						macpricerecs['unitprice'] =  "{0:.5f}".format(float(macrow.loc[id,'unitprice'])*float(rebfactor))
					else:
						macpricerecs['unitprice'] =  str(macrow.loc[id,'unitprice'])
					
					macpricerecs['pricetype'] = 'MAC'
					macpricerecs['maclistid'] = prow['maclistid'].upper()	
					macpricerecs['sc_brandorgeneric']=sc_brand_generic
					macrecs['cp_price'].append(macpricerecs)
					walmartmacpresent=True
				else:
					macpricerecs['claim_processor'] = 'scriptclaim'
					macpricerecs['rebate_factor'] = rebfactor
					macpricerecs['unit_price_before_rebate'] = str(macrow.loc[id,'unitprice'])
					if rebfactor!='' and 'scriptclaim' in rebcp:
						macpricerecs['unitprice'] =  "{0:.5f}".format(float(macrow.loc[id,'unitprice'])*float(rebfactor))
					else:
						macpricerecs['unitprice'] =  str(macrow.loc[id,'unitprice'])
					
					macpricerecs['pricetype'] = 'MAC'
					macpricerecs['maclistid'] = prow['maclistid'].upper()	
					macpricerecs['sc_brandorgeneric']=sc_brand_generic
					macrecs['cp_price'].append(macpricerecs)
				if not oldprices.empty:
					oldunitp=oldallclaimmacprice
					if macpricerecs['maclistid'] in list(oldprices['maclistid']):
						oldunitp=str(oldprices[oldprices['maclistid']==macpricerecs['maclistid']]['unitprice'].values[0])
					error=error.append({'gpi':gpi_code,'gppc':gppc_code,'drug_name':drug_name,'brand_generic':sc_brand_generic,'Medispan brand_generic':'','Status':'','Message':'MAC Unit Price Change','MACListID':macpricerecs['maclistid'],'old unit_price':oldunitp,'new unit_price':macpricerecs['unitprice']},ignore_index=True)
					
			if walmartmacpresent:
				updatetab = N1QLQuery('select d.drug_price_id,d.cp_price from `'+os.environ['CB_INSTANCE']+'` AS d UNNEST cp_price AS t WHERE d.type = "cp_drug_price_stg" and d.gpi = $gpi and d.drug_name = $drug and t.pricetype="AWP"',gpi = gpi_code, drug = drug_name)
				updatetab.adhoc = False
				updatetab.timeout = 100
				
				for updaterow in cb.n1ql_query(updatetab):
					drug_price_id = updaterow['drug_price_id']
					cp_price = updaterow['cp_price']
					error=error.append({'gpi':gpi_code,'gppc':gppc_code,'drug_name':drug_name,'brand_generic':sc_brand_generic,'Medispan brand_generic':'','Status':'','Message':'Drug Removed from Walmart AWP List','MACListID':'','old unit_price':'','new unit_price':''},ignore_index=True)
					if mode.upper() == 'FINAL':
						for i in cp_price:
							if i['claim_processor']=='sc_walmart':
								cp_price.remove(i)
						if len(cp_price)==0: 
							cb.remove(str(drug_price_id),quiet=True)
						else:
							cb.mutate_in(str(drug_price_id),SD.upsert('cp_price',cp_price)) 
					
			macrecs['create_date'] = currentdate
			macrecs['update_date'] = currentdate
			macrecs['created_by'] = 'ScriptClaim'
			macrecs['updated_by'] = 'ScriptClaim'			
			macrecs['type'] = 'cp_drug_price_stg'
			macrecs['file_name']=file_name

			
			
			if mode.upper() == 'FINAL':
				rv1=cb.counter('docid',delta=1)
				macrecs['drug_price_id']=str(rv1.value)
				cb.upsert(str(macrecs['drug_price_id']),macrecs)
			error=error.append({'gpi':gpi_code,'gppc':gppc_code,'drug_name':drug_name,'brand_generic':sc_brand_generic,'Medispan brand_generic':'','old unit_price':'','new unit_price':'','Status':'Success','Message':'','MACListID':''},ignore_index=True)
			#print(ite)
			ite=ite+1
		error.drop_duplicates(inplace=True)
		error.to_excel(writer,index=False)
		writer.save()
		subject = 'Script Claim Mac Drug Pricing File Processed'
		email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','SSubramani@GWLabs.com',subject,['Processing of Script Claim Mac Drug Pricing File '+file_name+str(currentdate),'Script Claim Mac Drug Pricing Exception'],err,True)
		if mode.upper() == 'FINAL': shutil.move(localpath, archivefile)
			
scriptclaimpricing()