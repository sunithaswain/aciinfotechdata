########################################

# !/usr/bin/env python 

# title : cppharmacy.py
# description : ScriptClaim Pharmacy details to update
# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  python cppharmacy.py -d GWLABS001 -t cp_pharmacy -f coverage_tier.xlsx -m DRAFT
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(rootdir)

import os
from datetime import datetime
import sys
import pprint
import socket

import pandas as pd
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
import couchbase.subdocument as SD

import app.common.commandline as commandline
from app.common.sendgridemail import email_log

domain_name,file_type,file_name,mode=commandline.main(sys.argv[1:])
cluster = Cluster(os.environ['CB_URL'])
bucket_name=os.environ['CB_INSTANCE']
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(bucket_name)

# modified by Hari on 27/12/2018
path = os.environ['CB_DATA']
host = socket.gethostname()
currentdate = datetime.now()
currentdate = currentdate.strftime("%m%d%y%H%M%S")
log = os.environ['CB_DATA']+'/'+file_type+'/log/'+"cppharmacy"+currentdate+'.txt'
logfile = open(log,"w")

def load():
	pdir=pd.read_csv(os.environ['CB_DATA']+'/'+file_type+'/'+file_name)
	pdir.fillna('',inplace=True)
	#maclist=pd.read_excel(os.environ['CB_DATA']+'/'+file_type+'/MacListChainCodeKey.xlsx',dtype='str')
	
		
	pdir['PharmacyNPI']=pdir['PharmacyNPI'].apply(lambda x: str(x).zfill(10))
	pdir['PharmacyZip1']=pdir['PharmacyZip1'].apply(lambda x: str(x).zfill(9) if len(str(x))>5 else str(x).zfill(5))
	outer_cols=[]
	inner_cols=[]
	for c in list(pdir):
		if 'Price' not in c: outer_cols.append(c)
	outer_cols.remove('PharmacyID')
	outer_cols.append('PharmPrice')
	
	for c in list(pdir):
		if 'Price' in c: inner_cols.append(c)
	inner_cols.remove('PharmPrice')
	inner_cols.append('PharmacyID')
	
	ite=0
	for k,g in pdir.groupby(['PharmacyNPI']):
		ite=ite+1
		g.reset_index(drop=True,inplace=True)
		d=dict()
		for c in outer_cols:
			d[c.lower().replace(' ','_')]=str(g.loc[0,c]).strip()
		
		d['cp_pharmacy_info']=[]
		d['pharmacytype']='RETAIL'
		#if d['pharmacytype']=='RETAIL' and d['geo_lat']=='': continue
		for i,r in g.iterrows():
			d_inner=dict()
			for c in inner_cols:
				d_inner[c.lower().replace(' ','_')]=str(r[c]).strip()
			d_inner['claim_processor']='scriptclaim'
			d_inner['cp_status']='active'
			d['cp_pharmacy_info'].append(d_inner)
		d['updated_at']=datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat()
		d['updated_by']='System'		
		d['created_at']=datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat()
		d['npi_status']='active'
		d['type']='cp_pharmacy'
		cb.upsert(str(cb.counter('docid',delta=1).value),d)
		#pprint.pprint(d)

def partialupdate():

	#maclist=pd.read_excel(os.environ['CB_DATA']+'/'+file_type+'/MacListChainCodeKey.xlsx',dtype='str')
	ite=0	
	query=N1QLQuery('Select meta().id as id,cp_pharmacy_info from `'+os.environ['CB_INSTANCE']+'` where type="cp_pharmacy" and pharmacystate="NJ"')
	df=pd.DataFrame()
	for r in cb.n1ql_query(query):
		df=df.append(r,ignore_index=True)
		'''
		maclistname='nan'
		#for i,r in df.iterrows():
		if r['chaincode'] in list(maclist['ChainCode']): 
			maclistname=str(maclist[maclist['ChainCode']==r['chaincode']]['MacListID'].values[0]).strip().upper()
		
		for i in r['cp_pharmacy_info']:
			i['sc_pharmbrandpriceamt']=str(i['pharmbrandpriceamt'])
			i['sc_pharmbrandpriceamtmo']=str(i['pharmbrandpriceamtmo'])
			try: i['pharmbrandpriceamt']=str(float(i['pharmbrandpriceamt'])-5.0)
			except ValueError: _=1
			try: i['pharmbrandpriceamtmo']=str(float(i['pharmbrandpriceamtmo'])-5.0)
			except ValueError: _=1
		
		cb.mutate_in(str(r['id']),SD.upsert('maclistid',str(maclistname)))
		cb.mutate_in(str(r['id']),SD.upsert('cp_pharmacy_info',r['cp_pharmacy_info']))
		ite=ite+1   
		'''
		li=[]
		li.extend(r['cp_pharmacy_info'])
		added={}
		for key,value in li[0].items():
			added[key]=value
		added['claim_processor']='demo'
		li.append(added)
		#print(li)
		if mode.upper().strip()=='FINAL':
			cb.mutate_in(str(r['id']),SD.upsert('cp_pharmacy_info',li))
		else:
			logfile.write(str(li))
	if mode.upper().strip()=='DRAFT':
		print("Run in draft mode")
	
	logfile.close()
	receiver=['DWagle@fliptrx.com','SSubramani@fliptrx.com']
	subject='DrugDatabase Display Rank Updated - Completed'
	body=['Processing of DrugDatabase display rank','‘DrugDatabase (ScriptClaim) Exception’']
	email_log('dwagle@fliptrx.com',receiver[0],receiver[1],subject,body,None,False)	

partialupdate() 	
