########################################
# !/usr/bin/env python  
# title         : PharmacyDirectoryMTH.py
# description   : monthyly update of pharmacy directory
# author        : Disha
# date created  : 20180101
# date last modified    : 20180720 12:16
# version       : 0.1
# maintainer    : Pal
# email         : pmuthanai@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage1         : python PharmacyDirectoryMTH.py -d GWLABS001 -t cp_pharmacy -f FliptPharmacyNetwork10242018.xlsx -m DRAFT
# usage2         : nohub python PharmacyDirectoryMTH.py -d GWLABS001 -t cp_pharmacy -f FliptPharmacyNetwork10242018.xlsx -m FINAL > FliptPharmacyNetwork10242018.log 2> FliptPharmacyNetwork10242018.err < /dev/null &
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  
# #######################################

from difflib import SequenceMatcher
import urllib
import re
from datetime import datetime
import os
import sys
import time
# import zipfile

import requests
from bs4 import BeautifulSoup
import geocoder
from couchbase.cluster import Cluster 
from couchbase.cluster import PasswordAuthenticator
from couchbase.n1ql import N1QLQuery
from couchbase import FMT_JSON
import pandas as pd


# Added to update the system path to refer our custom packages
if __name__ == '__main__':
    import os
    import sys
    rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.append(rootdir)

import app.common.commandline as commandline

class MonthlyUpdate(object):

    def __init__(self,location):
        self.cluster=Cluster(location)
        self.auth=PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
        self.cluster.authenticate(self.auth)
        self.cb=self.cluster.open_bucket(os.environ['CB_INSTANCE'])
    
    def replace_all(self,txt):
        chdict={"-":"","'s":"s",".":"",'WAL MART':'WALMART','HY VEE':'HYVEE','WINNDIXIE':'WINN DIXIE',}
        for k,v in chdict.items():
            txt=txt.replace(k,v)
        return txt
  
    def replace_wl(self,txt):
        
        if txt=='Giant Eagle': return txt
        
        chdict={"'s":'s','-':'','Giant':'Giant Pharmacy','Martins':'Martins Pharmacy','&':'and','H.E. Butt (HEB)':'Heb Grocery','WinnDixie':'Winn Dixie'}
        for k,v in chdict.items():
            txt=txt.replace(k,v)
        return txt
    
    def geocodeAddress(self,pharma_dir):
        
        header_list = ['npi', 'prov_practice_addr_1', 'prov_practice_addr_2', 'prov_practice_city', 'prov_practice_zip', 'prov_practice_state', 'prov_practice_country']
        address=pd.DataFrame(columns=header_list)    
        for i, p in pharma_dir.iterrows():
            if (p['whitelisted']=='Y') and (p['practice_address_country_code'] == 'US') and (p['geo_lat']==''):
                line_dict = {}
                line_dict['npi'] = str(p['npi']).strip()
                line_dict['prov_practice_addr_1'] = str(p['first_line_practice_address']).strip()
                line_dict['prov_practice_addr_2'] = str(p['second_line_practice_address']).strip()
                line_dict['prov_practice_city'] = p['practice_address_city_name'].strip()
                zip_code = str(p['practice_address_postal_code'])[:5]
                if len(zip_code) > 5:
                    zip_code += '-' + zip_code[5:]
                line_dict['prov_practice_zip'] = zip_code
                line_dict['prov_practice_state'] = p['practice_address_state_name'].strip()
                line_dict['prov_practice_country'] = 'United States'
                address=address.append(line_dict,ignore_index=True)
        geocodes=self.getGeoCodes(address)
        print('geocoded')
        geocodes[geocodes['geo_lat']==''].to_csv(os.environ['CB_DATA']+'//'+filetype+'//log//nongeocodedpharmacies'+str(datetime.now())+'.csv',index=False)
        if geocodes.empty or '' not in list(geocodes['geo_lat']): return geocodes
        return geocodes
        
    
    def parse_google_fields(self,g, google_fields):
        res = {}
        for f in google_fields.keys():
            gf_type = google_fields[f]['field_type']
            gf_name = google_fields[f]['field_name']
            
            if gf_type == 'property':
                d = g.json
            elif gf_type == 'raw':
                d = g.raw
            
            if d is not None and gf_name in d.keys():
                res[f] = d[gf_name]
            else:
                res[f] = ''
        return res
    
    def split_address(self,addr):
        street_number = ''
        street_name = addr
        
        flds = addr.split(' ')
        for i, f in enumerate(flds):
            if f.isdigit():
                street_number = f
                street_name = ' '.join(flds[i+1:])
                break
        return [street_number, street_name]
    
    def check_addresses(self,i_addr, o_addr, fields=['street_number', 'street', 'city', 'state', 'postal_code', 'country']):
        for f in fields:
            if type(o_addr[f]) == dict and ('short_name' in o_addr[f].keys() or 'long_name' in o_addr[f].keys()):
                if not i_addr[f].upper().replace('.', '') == o_addr[f]['short_name'].upper().replace('.', '') and not i_addr[f].upper().replace('.', '') == o_addr[f]['long_name'].upper().replace('.', ''):
                    return False
            elif type(o_addr[f]) == str and not i_addr[f].upper() == o_addr[f].upper():
                return False
    
        return True
    
    def geocode_data_frame(self,df, new_fields,google_fields, key=None, max_tries=3,geocode_missing=True):
        g_res = {}
        new_cols=[x for x in new_fields]
        new_cols.append('npi')
        geo_df=pd.DataFrame(columns=new_cols)
        geo_errors=pd.DataFrame(columns=new_cols)
    
        for f in new_fields:
            g_res[f] = []
        
        with requests.Session() as session:
            for i, p in df.iterrows():
                geo_ok = False
                address    = p['prov_practice_addr_1'].strip()
                i_city    = p['prov_practice_city'].strip()
                i_state   = p['prov_practice_state'].strip()
                i_postal  = str(p['prov_practice_zip'])
                i_country = p['prov_practice_country'].strip()
    
                geocoded = {}
                for f in new_fields:
                    geocoded[f] = ''
                
                addr = address
                addr += ',' + i_city
                addr += ',' + i_state
                addr += ',' + i_postal
                addr += ',' + i_country
    
                i_addr = {}
                i_addr['address'] = addr
                i_addr['formatted_address'] = addr
                i_addr['street_number'], i_addr['street'] = self.split_address(address)
                i_addr['city'] = i_city
                i_addr['state'] = i_state
                i_addr['postal_code'] = i_postal[:5]
                if len(i_postal) > 5:
                    i_addr['postal_code_suffix'] = i_postal[5:]
                else:
                    i_addr['postal_code_suffix'] = ''
                i_addr['country'] = i_country
                i_addr['npi']=p['npi']
    
                if geocode_missing:
                    
                    # use geocoder to get data
                    g = geocoder.google(addr, key=key, session=session)
    
                    if not g.ok:
                        ntries = 0
                        while ntries < max_tries:
                            ntries += 1
                            g = geocoder.google(addr, key=key)
                            time.sleep(2)
                            if g.ok:
                                geo_ok = True
                                break
    
                    if g.ok:
                        geocoded = self.parse_google_fields(g, google_fields)
    
                        geocoded['is_same_address'] = 'Y' if self.check_addresses(i_addr, geocoded) else 'N'
    
                        # save results to json file, in json_path if variable set
                        for f in geocoded.keys():
                            if type(geocoded[f]) == dict and 'short_name' in geocoded[f].keys():
                                i_addr['geo_' + f] = geocoded[f]['short_name']
                            else:
                                i_addr['geo_' + f] = geocoded[f]
    
                            geo_df=geo_df.append(i_addr,ignore_index=True)
                            if p['npi'] in list(geo_errors['npi']):
                                geo_errors=geo_errors[geo_errors['npi']!=p['npi']]
                        geo_ok = True
    
                if geo_ok:
                    # add fields to structure
                    for f in new_fields:
                        l = g_res[f]
                        if type(geocoded[f]) == dict and 'short_name' in geocoded[f].keys():
                            l.append(geocoded[f]['short_name'])
                        else:
                            l.append(geocoded[f])
                        g_res[f] = l
                    
                else:
                    # save results to json file, in json_path if variable set
                    for f in new_fields:
                        i_addr['geo_' + f] = ''
    
                    geo_errors=geo_errors.append(i_addr,ignore_index=True)
                        
                    # add fields to structure
                    for f in new_fields:
                        l = g_res[f]
                        l.append('')
                        g_res[f] = l
    
        for f in new_fields:
            df['geo_' + f] = g_res[f]
            
        return df

    
    def getGeoCodes(self,address):
        #API_KEY=None
        API_KEY='AIzaSyB_zk3jM6lIpradGijn551UIzzrjv1iwEg'

        google_fields = {'address' : {'field_type': 'property', 'field_name': 'address'},
                         'formatted_address' : {'field_type': 'raw', 'field_name': 'formatted_address'},
                         'street_number' : {'field_type': 'raw', 'field_name': 'street_number'},
                         'street' : {'field_type': 'raw', 'field_name': 'route'},
                         'city' : {'field_type': 'raw', 'field_name': 'locality'},
                         'state' : {'field_type': 'raw', 'field_name': 'administrative_area_level_1'},
                         'county' : {'field_type': 'raw', 'field_name': 'administrative_area_level_2'},
                         'postal_code' : {'field_type': 'raw', 'field_name': 'postal_code'},
                         'postal_code_suffix' : {'field_type': 'raw', 'field_name': 'postal_code_suffix'},
                         'country' : {'field_type': 'raw', 'field_name': 'country'},
                         'lat' : {'field_type': 'property', 'field_name': 'lat'},
                         'lng' : {'field_type': 'property', 'field_name': 'lng'},
                         'confidence' : {'field_type': 'property', 'field_name': 'confidence'},
                         'status' : {'field_type': 'property', 'field_name': 'status'}}
        
        new_fields = ['formatted_address', 'street_number', 'street', 'city', 'state', 'county', 'postal_code',
                      'postal_code_suffix', 'country', 'lat', 'lng', 'confidence', 'status', 'is_same_address']
        geocodes = self.geocode_data_frame(address, new_fields, google_fields,key=API_KEY,geocode_missing=True)
        
        return geocodes



    
    def downloadMonthly(self):
        root="http://download.cms.gov/nppes/"
        html_pg=urllib.request.urlopen(root+"NPI_Files.html")
        soup=BeautifulSoup(html_pg,"html.parser")
        '''
        monthly=soup.find("a",attrs={"href":re.compile(datetime.now().replace(month=4).strftime("%B"))})
        if monthly is None: return None
        if monthly is not None:
            monthly=monthly.get("href").replace("./",root)
            file_name=os.environ['CB_DATA']+"//"+filetype+"//npi-monthly.zip"
            if file_name in os.listdir(os.environ['CB_DATA']+"//"+filetype):
                os.unlink(file_name)
            urllib.request.urlretrieve(monthly,file_name)
            z=zipfile.ZipFile(os.environ['CB_DATA']+"//"+filetype+"//npi-monthly.zip",'r')
            for name in z.namelist():
                if "csv" in name and "FileHeader" not in name:
                    filename=name
                    fn=z.open(filename)
                    return fn
		'''
        return os.environ['CB_DATA']+"//"+filetype+"//npi-monthly//npidata_pfile_20050523-20180408.csv"
        
    def filterMonthly(self):
        fn=self.downloadMonthly()
        print('downloaded')
        if fn==None: return None,0
        whitelist=pd.DataFrame()
        rows=self.cb.n1ql_query(N1QLQuery('SELECT * FROM `'+os.environ['CB_INSTANCE']+'` WHERE type=$t',t='whitelisted_pharmacy'))
        for r in rows:
            xele=r[os.environ['CB_INSTANCE']].pop('type','whitelisted_pharmacy')
            whitelist=whitelist.append(r[os.environ['CB_INSTANCE']],ignore_index=True)
            
        whitelist['replaced_name']=[self.replace_all(str(x)).upper() for x in whitelist['name']]
       
        dfcols = ['NPI','Entity Type Code','Provider Organization Name (Legal Business Name)','Provider Other Organization Name','Parent Organization LBN','Provider First Line Business Mailing Address','Provider Second Line Business Mailing Address','Provider Business Mailing Address City Name','Provider Business Mailing Address State Name','Provider Business Mailing Address Postal Code','Provider Business Mailing Address Country Code (If outside U.S.)','Provider Business Mailing Address Telephone Number','Provider Business Mailing Address Fax Number','Provider First Line Business Practice Location Address','Provider Second Line Business Practice Location Address','Provider Business Practice Location Address City Name','Provider Business Practice Location Address State Name','Provider Business Practice Location Address Postal Code','Provider Business Practice Location Address Country Code (If outside U.S.)','Provider Business Practice Location Address Telephone Number','Provider Business Practice Location Address Fax Number','Provider Enumeration Date','Last Update Date','NPI Deactivation Date','NPI Reactivation Date','Healthcare Provider Taxonomy Code_1','Healthcare Provider Taxonomy Code_2','Healthcare Provider Taxonomy Code_3','Healthcare Provider Taxonomy Code_4','Healthcare Provider Taxonomy Code_5','Healthcare Provider Taxonomy Code_6','Healthcare Provider Taxonomy Code_7']
        cols=[]
        cols.extend(dfcols)
        for i in range(len(cols)):
            cols[i]=cols[i].replace('Provider ','')
            cols[i]=cols[i].replace('Business ','')
            cols[i]=cols[i].replace('Location ','')
            cols[i]=re.sub("[\(\[].*?[\)\]]", "", cols[i])
            cols[i]=cols[i].strip()
        chunk=pd.read_csv(fn,chunksize=10000,low_memory=False)
        final_df=pd.DataFrame()
        for df_sample in chunk:
            df_sample.fillna("",inplace=True)
            df_sample=df_sample[(df_sample['Healthcare Provider Taxonomy Code_1'].str.startswith('3336')) | ((df_sample['Healthcare Provider Taxonomy Code_2'].str.startswith('3336'))) | (df_sample['Healthcare Provider Taxonomy Code_3'].str.startswith('3336')) | (df_sample['Healthcare Provider Taxonomy Code_4'].str.startswith('3336')) | (df_sample['Healthcare Provider Taxonomy Code_5'].str.startswith('3336')) | (df_sample['Healthcare Provider Taxonomy Code_6'].str.startswith('3336')) | (df_sample['Healthcare Provider Taxonomy Code_7'].str.startswith('3336'))]
            filtered=df_sample.loc[:,dfcols]
            filtered.columns=cols
            filtered['Organization Name']=[self.replace_all(str(x)) for x in filtered['Organization Name']]
            filtered['Other Organization Name']=[self.replace_all(str(x)) for x in filtered['Other Organization Name']]
            filtered['Parent Organization LBN']=[self.replace_all(str(x)) for x in filtered['Parent Organization LBN']]
            filtered=filtered.reset_index(drop=True)
            filtered['Whitelisted']='N'
            filtered['WL_Name']=""
                        
            for i in range(len(filtered)):
                for j,r in whitelist.iterrows():
                    if (r['replaced_name'] in filtered['Organization Name'][i]) or (r['replaced_name'] in filtered['Other Organization Name'][i]) or (r['replaced_name'] in filtered['Parent Organization LBN'][i]):
                        filtered.loc[i,'Whitelisted']='Y'
                        filtered.loc[i,'WL_Name']=r['name'].upper()
            final_df=pd.concat([final_df,filtered],ignore_index=True)
        os.remove(fn)         
        return final_df[final_df['Whitelisted']=='Y'],1
    
    def updateMonthly(self):
        
        filtered,num=self.filterMonthly()
        if num==0: return filtered,False
        print('filtered')
        filtered['load_date']=''
        filtered['update_date']=datetime.now().strftime("%m/%d/%Y")
        filtered['updated_by']=''
        filtered['geo_lat']=''
        filtered['geo_lng']=''
              
        colsdict={}
        for c in list(filtered):
            colsdict[c]=c.lower().replace(' ','_')
        filtered.rename(columns=colsdict,inplace=True)			
        filtered['npi']=filtered['npi'].apply(lambda x: str(x).zfill(10))  
        for i,r in filtered.iterrows():
            query=N1QLQuery('SELECT * FROM `'+os.environ['CB_INSTANCE']+'` WHERE type="pharmacy" and npi=$npi',npi=r['npi'])
            present=False
            for row in self.cb.n1ql_query(query):
				
                pdir=dict(row[os.environ['CB_INSTANCE']])
                
                present=True
                print(str(r['npi']))		
                print()				
                if pdir['updated_by']=='Manual':
                    filtered.loc[i,['first_line_practice_address','practice_address_city_name','practice_address_country_code','practice_address_postal_code','practice_address_state_name','second_line_practice_address','geo_lat','geo_lng','updated_by','load_date']]=[pdir['first_line_practice_address'],pdir['practice_address_city_name'],pdir['practice_address_country_code'],pdir['practice_address_postal_code'],pdir['practice_address_state_name'],pdir['second_line_practice_address'],pdir['geo_lat'],pdir['geo_lng'],pdir['updated_by'],pdir['load_date']]				 
                    
                    continue
                elif pdir['updated_by']=='System':
                    if SequenceMatcher(None,str(r['first_line_practice_address']).upper().strip(),str(pdir['first_line_practice_address']).upper().strip()).ratio()>=0.95:
                        filtered.loc[i,['geo_lat','geo_lng','updated_by','load_date']]=[pdir['geo_lat'],pdir['geo_lng'],pdir['updated_by'],pdir['load_date']]
            if not present:
                filtered.loc[i,'load_date']=datetime.now().strftime("%m/%d/%Y")
        
        geocodes=self.geocodeAddress(filtered)
        if geocodes.empty==False:
            for i,r in geocodes.iterrows():
                filtered.loc[filtered['npi']==str(r['npi']),['geo_lat','geo_lng','updated_by']]=[r['geo_lat'],r['geo_lng'],'System']
        #filtered=filtered[filtered['geo_lat']!='']
        pdir1=pd.DataFrame()
        filtered['geo_lat']=[str(x) for x in filtered['geo_lat']]
        filtered['geo_lng']=[str(x) for x in filtered['geo_lng']]
        for k,g in filtered.groupby(['geo_lat','geo_lng']):
            
            if len(g)==1:
                pdir1=pdir1.append(g.loc[:,:],ignore_index=True)
                continue
            elif len(g)>1:
                latest_date='01/01/1800'
                irow=0
                for i,r in g.iterrows():
                    if datetime.strptime(r['enumeration_date'],'%m/%d/%Y')>datetime.strptime(latest_date,'%m/%d/%Y'):
                        latest_date=r['enumeration_date']
                        irow=i
                if latest_date!='01/01/1800':
                    pdir1=pdir1.append(g.loc[irow,:],ignore_index=True)
        print('process complete')
        return pdir1,True
      
    
    def output(self,pdir):

        d=dict()
        docid=[]
        doc_id=self.cb.n1ql_query(N1QLQuery('SELECT META().id FROM `'+os.environ['CB_INSTANCE']+'` where type="pharmacy"'))
        for did in doc_id:
            docid.append(did['id'])
        pdir.drop_duplicates(inplace=True)
        x=-1
        for i,r in pdir.iterrows():
            for c in list(pdir):
                d[c.lower().replace(' ','_')]=str(r[c])
            d['type']='pharmacy'
            x=x+1
            if x<len(docid): 
                self.cb.upsert(docid[x],d,format=FMT_JSON)
                continue
            else: 
                self.cb.upsert(str(self.cb.counter('docid',delta=1).value),d,format=FMT_JSON)
        if x+1<len(docid):
            for h in range(x+1,len(docid)):
                self.cb.remove(docid[h],quiet=True) 
       
                    
domain,filetype,filename,mode=commandline.main(sys.argv[1:])
#email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','SSubramani@GWLabs.com','Pharmacy Directory Update - Initiated',['Monthly Pharmacy Directory Update'],None,False)
f=open(os.environ['CB_DATA']+'/'+filetype+'/log/log.txt','w')
f.write('---Pharmacy Directory Monthly Update---\r\n'+str(datetime.now())+'\r\n') 
location=os.environ['CB_URL']      
ob=MonthlyUpdate(location)
pdir,flag=ob.updateMonthly()
if flag==True and mode.lower().strip()=='final': ob.output(pdir)
pdir.to_csv(os.environ['CB_DATA']+'/'+filetype+'/log/pdir.csv',index=False)
f.write('---Pharmacy Directory Monthly Update Done---\r\n'+str(datetime.now())+'\r\n')
f.close()
#email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','SSubramani@GWLabs.com','Pharmacy Directory Update - Completed',['Monthly Pharmacy Directory Update','‘Pharmacy Directory Exception’'],os.environ['CB_DATA']+'/'+filetype+'/log/log.txt')
