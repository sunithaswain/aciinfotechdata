########################################
# !/usr/bin/env python  
# title         : termsconditionsupdate.py
# description   : Updates terms and conditions and hippa complaince details from input files into termsconditions documents in database
# author        : Disha
# date created  : 20180101
# date last modified    : 20180720 12:16
# version       : 0.1
# maintainer    : Pal
# email         : pmuthanai@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage         : python termsconditionsupdate.py -m DRAFT
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  
# #######################################

import os
import codecs
import sys
from datetime import datetime
# import pprint

from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.n1ql import N1QLQuery
from couchbase import FMT_JSON
import pandas as pd


# Added to update the system path to refer our custom packages
if __name__ == '__main__':
    import os
    import sys
    rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.append(rootdir)

import app.common.commandline as commandline
from app.common.sendgridemail import email_log


domain,filetype,filename,mode=commandline.main(sys.argv[1:])
cluster=Cluster(os.environ['CB_URL'])
auth=PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(auth)
cb=cluster.open_bucket(os.environ['CB_INSTANCE'])
#cnt=cb.counter('docid',delta=1,initial=0)

# Add log file
logpath=os.environ['CB_DATA']+'//termsconditions//log//log'+datetime.now().strftime("%Y%m%d%H%M")+'.txt'
logfile = open(logpath,"w")
logfile.write("=============================================================="+"\r\n")
logfile.write("=============== Terms and Conditions Update Log ================="+"\r\n")		
logfile.write("Start time is "+ str(datetime.now()) +"\r\n")

def load_tandc():
        tc=pd.read_excel(os.environ['CB_DATA']+'//termsconditions//termsconditions.xlsx')
        logfile.write("No of records in File "+ str(tc.shape[0]) +"\r\n")
        print("No of records in File "+ str(tc.shape[0]))
        domainlistfile = list(tc["domain_name"].values)
        print("Available domains in File ..."+ ", ".join(domainlistfile))
        domainquery = N1QLQuery('Select domain_name from `'+os.environ['CB_INSTANCE']+'` where type="termsconditions"')
        missingdomainfile = []
        print("Available domains in database:")
        for domainrow in cb.n1ql_query(domainquery):
                print(domainrow['domain_name'])
                if not domainrow['domain_name'] in domainlistfile:
                	missingdomainfile.append(domainrow['domain_name'])
        print("These domain entries are missing in the file ",", ".join(missingdomainfile))
        
        f=codecs.open(os.environ['CB_DATA']+'//termsconditions//termsandconditions.txt','r','utf-8',errors='replace')
        #print(tc)
        st=f.read()
        f1=codecs.open(os.environ['CB_DATA']+'//termsconditions//hippa.txt','r','utf-8',errors='replace')
        hc=f1.read()
        docid=[]
        for i,r in tc.iterrows():
                query=N1QLQuery('Select meta().id as id from `'+os.environ['CB_INSTANCE']+'` where type="termsconditions" and domain_name=$dn',dn=r['domain_name'])
                domain_value = r['domain_name']                       
                d=dict()
                for c in list(tc):
                        cnew=c.replace(' ','_').lower()
                        d[cnew]=str(r[c])
                d['terms_conditions']=st
                d['hippa_compliance']=hc
                present=False
                if mode.upper().strip()=='FINAL':
                       # print('Final mode')
                        for r in cb.n1ql_query(query):
                                print("This existing domain in database is updated "+domain_value)
                                cb.upsert(r['id'],d, format=FMT_JSON)
                                present=True
                        if not present:
                                print("This new domain is created  in database "+domain_value)
                                cb.upsert(str(cb.counter('docid',delta=1).value),d, format=FMT_JSON)
                # else:
                #        print("Draft mode")
load_tandc()
logfile.write("End time is "+ str(datetime.now()) +"\r\n")

logfile.write("=============================================================="+"\r\n")
logfile.close()
# email_log('DWagle@fliptrx.com','DWagle@fliptrx.com','deepthi.gollapudi@nttdata.com,ssubramani@fliptrx.com,PMuthanai@fliptrx.com','Formulary Update - Completed',['Processing of Terms and Conditions update File '+logpath,'Terms and Conditions update'],logpath,True)
