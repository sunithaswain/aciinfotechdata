########################################

# !/usr/bin/env python 

# title : aetnamemberidupdate.py
# description : Update member details(member ID,relationship code) of employees/dependents for their corresponding Aetna accounts
# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         : With Filename: python aetnamemberidupdate.py -d FLIPT001 -t Aetna -f Aetnamembers10032018_FLIPT001.xlsx -m DRAFT
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(rootdir)

import json
import base64
import pprint
import os
import sys
import shutil
import socket
import requests
from pathlib import Path
from datetime import datetime
from requests.auth import HTTPBasicAuth

import pandas as pd
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
import couchbase.subdocument as SD
from couchbase import FMT_JSON

import app.common.commandline as commandline
from app.common.sendgridemail import email_log
from app.common.FliptConcurrent import concurrent
from app.common.truevaultV3 import User_Class

domain_name,file_type,file_name,mode=commandline.main(sys.argv[1:])
req=concurrent(sys.argv[0],sys.argv[1:])
domainlist=[domain_name]

# modified by Hari on 27/12/2018
host = socket.gethostname()
currentdate = datetime.now()
currentdate = currentdate.strftime("%m%d%y%H%M%S")
log = os.environ['CB_DATA']+'/'+domain_name+'/'+file_type+'/log/'+"Aetna_memberID_update"+currentdate+'.txt'

if 'GWLABS001' in domainlist: domainlist.append('FLIPT001')
#email_log('DWagle@fliptrx.com','DWagle@fliptrx.com','SSubramani@fliptrx.com','Flipt Person Hierarchy Update - Initiated',['Processing of Aetna Member file '+file_name],None,False)
df=pd.read_excel(os.environ['CB_DATA']+'/'+domain_name+'/'+file_type+'/'+file_name)
cluster = Cluster(os.environ['CB_URL'])
bucket_name=os.environ['CB_INSTANCE']
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(bucket_name)
api_key=os.environ['TV_API_KEY']
errorlog=pd.DataFrame()
numberofmembers=0
cols={"Enrollee Social Security Number":"ee_ssn","First Name":"first_name","Last Name":"last_name","Birth Date":"birth_date","Employee CUMB ID":"cumbid","Sequence":"sequence","Relationship Code":"relationship","Original Effective Date":"orig_eff_date","Dependent CUMB ID":"dep_cumbid","Home Phone Number":"home_phone","Work Phone Number":"work_phone","Gender Code":"gender"}

df.rename(columns=cols,inplace=True)
current_time=datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat()
df=df.loc[:,['ee_ssn','first_name','last_name','birth_date','cumbid','sequence','relationship','orig_eff_date','dep_cumbid','home_phone','work_phone','gender']]
#df['ee_ssn']=df['ee_ssn'].apply(lambda x: 'xxx-xx-'+str(x)[-4:])
df['orig_eff_date']=df['orig_eff_date'].apply(lambda x:  datetime.strptime(str(x), '%Y-%m-%d 00:00:00'))
df['cumbid']=df['cumbid'].apply(lambda x: x.replace('W',''))
df['dep_cumbid']=df['dep_cumbid'].apply(lambda x: str(int(x)) if pd.isnull(x)==False else '')
df['sequence']=df['sequence'].apply(lambda x: str(x).zfill(2))
df['home_phone']=df['home_phone'].apply(lambda x: str(int(x)) if pd.isnull(x)==False else '')
df['work_phone']=df['work_phone'].apply(lambda x: str(int(x)) if pd.isnull(x)==False else '')
df['birth_date']=df['birth_date'].apply(lambda x: datetime.strftime(datetime.strptime(str(x),'%Y-%m-%d 00:00:00'),'%Y-%m-%d 00:00:00'))
df.fillna('',inplace=True)
df.drop_duplicates(inplace=True)

logfile = open(log,"w")
running_count = 0
for key,group1 in df.groupby(['ee_ssn']):
	
	group=pd.DataFrame()
	for seq in set(list(group1['sequence'])):
		maxdate=max(list(group1[group1['sequence']==seq]['orig_eff_date']))
		group=group.append(group1.loc[(group1['sequence']==seq) & (group1['orig_eff_date']==maxdate),:],ignore_index=True)
	group.reset_index(drop=True,inplace=True)
	g=group.loc[group['sequence']=='01',['birth_date','ee_ssn','first_name','last_name','sequence','cumbid','orig_eff_date']]
	g.reset_index(drop=True,inplace=True)
	searched=False
	attlist=[]
	useridlist=[]
	attindex=0
	employeefound=False
	for i,r in group.iterrows():
		#print(r)
		
		
		if not searched:
			
			obj=User_Class(None,None)
			for ind,row in g.iterrows():
				for dmn in domainlist:
					search_option={'full_document':True,'filter':{'employee_ssn':{'type':'eq','value':'xxx-xx-'+str(key)[-4:],'case_sensitive':False},'domain_name':{'type':'eq','value':dmn,'case_sensitive':False},'date_of_birth':{'type':'eq','value':str(row['birth_date']),'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
					attlist1,userid=obj.search_user_id(search_option)
					if len(attlist1)!=0: break
				attlist.extend(attlist1)
				useridlist.extend(userid)
				if len(attlist)!=0:
					searched=True
					break
			if searched==False: break
		
		if r['sequence']=='01':
			
			if employeefound: continue
			for att in attlist:
				if (r['first_name']==att['first_name'] and r['last_name']==att['last_name']) or (r['birth_date']==att['date_of_birth']):
					employeefound=True
					#print('employee')
					#print(r)
					emp_flipt_person_id=att['flipt_person_id']
					carrier=[{'ins_carrier_name':'Aetna','ins_carrier_member_id':str(r['cumbid']),'ins_relationship_code':str(r['sequence']),'coverage_tier_name':str(att['coverage_tier_name']),'benefit_plan_name':str(att['benefit_plan_name']), 'updated_at':current_time}]
					phonelist=[]
					
					if r['home_phone'].isdigit() and int(r['home_phone'])!=0:
						phonelist.append(r['home_phone'])
					if r['work_phone'].isdigit() and (r['home_phone']!=r['work_phone'] or int(r['work_phone'])!=0):
						phonelist.append(r['work_phone'])
					
					att['carrier_phonenumbers']=phonelist
				
					query=N1QLQuery('Select meta().id,dep_flipt_person_id from `'+bucket_name+'`where type="flipt_person_hierarchy_test" and dep_flipt_person_id=$fid',fid=str(emp_flipt_person_id))
						
					for qres in cb.n1ql_query(query):
						if mode.upper().strip()=='FINAL':
							cb.mutate_in(qres['id'],SD.upsert('ins_carrier',carrier))
							# cb.mutate_in(qres['id'],SD.upsert('updated_at',current_time))
						else:
							logfile.write(str(carrier)+'\n')
					running_count += 1
					break
				attindex=attindex+1
				
		else:
			dependentfound=False
			nameError=False
			gr=pd.DataFrame()
			for att in attlist:
				depindex=0
				for dep in att['dependents']:
					
					if r['birth_date']==dep['date_of_birth']:
						depdict=dict(dep)
						depdict['depindex']=int(depindex)
						gr=gr.append(depdict,ignore_index=True)
					depindex=depindex+1
				fid=''
				gr.reset_index(drop=True,inplace=True)
				if len(gr)==1: 
					dependentfound = True
					fid=gr.loc[0,'flipt_person_id']
					
					att['dependents'][int(gr.loc[0,'depindex'])]['gender']=r['gender']
				if len(gr)>1:
					for ind,row in gr.iterrows():
						if row['first_name']==r['first_name'].strip() and row['last_name']==r['last_name'].strip():
							dependentfound=True
							fid=row['flipt_person_id']
							att['dependents'][int(row['depindex'])]['gender']=r['gender']
							break
					if not dependentfound:
						errorlog=errorlog.append({'Aetna First Name':r['first_name'],'Aetna Last Name':r['last_name'],'TV First Name':'','TV Last Name':'','Aetna Member ID':r['dep_cumbid'],'Error':'Dependent Name Not Matching Truevault'},ignore_index=True)
						nameError=True
				if dependentfound:
					
					carrier=[{'ins_carrier_name':'Aetna','ins_carrier_member_id':str(r['dep_cumbid']),'ins_relationship_code':str(r['sequence']),'coverage_tier_name':str(att['coverage_tier_name']),'benefit_plan_name':str(att['benefit_plan_name']), 'updated_at':current_time}]
					#print(carrier)
					query=N1QLQuery('Select meta().id as id,dep_flipt_person_id from `'+bucket_name+'`where type="flipt_person_hierarchy_test" and dep_flipt_person_id=$fliptid',fliptid=fid)
					
					for qres in cb.n1ql_query(query):
						if mode.upper().strip()=='FINAL':
							cb.mutate_in(qres['id'],SD.upsert('ins_carrier',carrier))
							# cb.mutate_in(qres['id'],SD.upsert('updated_at',current_time))
						else:
							logfile.write(str(carrier)+'\n')
						running_count += 1
					break
				elif (not dependentfound and not nameError) or len(gr)==0:
					errorlog=errorlog.append({'Aetna First Name':r['first_name'],'Aetna Last Name':r['last_name'],'TV First Name':'','TV Last Name':'','Aetna Member ID':r['dep_cumbid'],'Error':'Dependent Not Found'},ignore_index=True)
	#pprint.pprint(attlist[attindex])
	if employeefound:
		updatedatt=attlist[attindex]
		updateuserid=useridlist[attindex]
		new_att=base64.b64encode(str.encode(json.dumps(updatedatt)))
		data={'attributes':new_att}
		numberofmembers=numberofmembers+1
		
	if mode.upper().strip()=='FINAL' and employeefound and os.environ['INSTANCE_TYPE']=='PROD':
		r=requests.put('https://api.truevault.com/v1/users/%s' % str(updateuserid),auth=HTTPBasicAuth(api_key, ''),data=data)
	if not employeefound:
		fn=g['first_name'][0]
		ln=g['last_name'][0]
		if len(attlist)==0:
			errorlog=errorlog.append({'Aetna First Name':fn,'Aetna Last Name':ln,'TV First Name':'','TV Last Name':'','Aetna Member ID':g['cumbid'][0],'Error':'Employee Not Found in Truevault'},ignore_index=True)
			continue
		else:
			errorlog=errorlog.append({'Aetna First Name':fn,'Aetna Last Name':ln,'TV First Name':attlist[0]['first_name'],'TV Last Name':attlist[0]['last_name'],'Aetna Member ID':g['cumbid'][0],'Error':'Employee Not Matching with Truevault Attributes'},ignore_index=True)

logfile.close()
print('%s records are to be update in DB'%running_count)
errlog='Errorlog'+str(datetime.now())+'.xlsx'                       
writer=pd.ExcelWriter(os.environ['CB_DATA']+'/'+domain_name+'/'+file_type+'/log/'+errlog)
errorlog.to_excel(writer,index=False)
writer.save()       
sender='DWagle@fliptrx.com'
receiver=['DWagle@fliptrx.com','SSubramani@fliptrx.com']
subject='Flipt Person Hierarchy Updated - Completed'
body=['Processing of Aetna Members file '+file_name,'Flipt Person Hierarchy Exception’']
email_log(sender,receiver[0],receiver[1],subject,body,os.environ['CB_DATA']+'/'+domain_name+'/'+file_type+'/log/'+errlog)
req.no_rec_received=numberofmembers
req.close()
	
	
