
########################################

# !/usr/bin/env python 

# title : aetnadeductibleupdate.py
# description : Processes current deductible/out-of-pocket costs for users sent by Aetna.
# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         : With Filename: python aetnadeductibleupdate.py -d GWLABS001 -t deductible -f GW_LABORATORIES_12012018.xlsx -m DRAFT -s 01-DEC-2018
#				  Without Filename: python aetnadeductibleupdate.py -d GWLABS001 -t deductible -m DRAFT -s 01-DEC-2018
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(rootdir)


import json
import sys
import os
import shutil
import dateutil.parser as parser
from datetime import datetime
from pathlib import Path

import pandas as pd
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from couchbase import FMT_JSON

from app.common.awssftpfileops import downloadfile,listbucketcontents
from app.common.sendgridemail import email_log,email_log_custombody
from app.common.rxplan_validation import getplans,validate
import app.common.opccmdline as opccmdline
from app.common.FliptConcurrent import concurrent

 
'''
This interface will update the deductible details of G&W and Flipt employees,received from Aetna in  Deductible Type.
Command to run the script:
With Filename: python aetnadeductibleupdate.py -d GWLABS001 -t deductible -f GW_LABORATORIES_12012018.xlsx -m DRAFT -s 01-DEC-2018
Without Filename: python aetnadeductibleupdate.py -d GWLABS001 -t deductible -m DRAFT -s 01-DEC-2018


'''
domain_name,file_type,file_name,mode,cutoffdate,dt=opccmdline.main(sys.argv[1:])
#if file
#fn=str(file_name)
#email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','SSubramani@GWLabs.com','Deductible Updated - Initiated',['Processing of Deductible file '+file_name],None,False)

req=concurrent(sys.argv[0],sys.argv[1:],2)
f=open(os.environ['CB_DATA']+'/'+domain_name+'/'+file_type+'/log/log.txt','w')
f.write('----Deductible Update----\n')
f.write(str(datetime.now())+'\n')
sender='DWagle@fliptrx.com'
receiver=['DWagle@fliptrx.com']
body=['Processing of Deductible file ','‘Deductible Exception’']
subject='Aetna Deductible Updated - Completed'
#Validation for Filetype given in command prompt
if file_type.lower()!='deductible':
    f.write('\n-----File type Error------\n') 
    f.close()
    email_log(sender,receiver[0],'Deepthi.gollapudi@nttdata.com,ssubramani@fliptrx.com',subject,body,os.environ['CB_DATA']+'/'+domain_name+'/'+file_type+'/log/log.txt')
    sys.exit()
cluster = Cluster(os.environ['CB_URL'])
bucket_name=os.environ['CB_INSTANCE']
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(bucket_name)
ctdate=parser.parse(cutoffdate)
currentyear=str(ctdate.year)
cutoffdt=ctdate.isoformat()
api_key=os.environ['TV_API_KEY']
filepath=''
class Deductible(object):

	def __init__(self):
			global file_name,filepath
			if file_name is not None: 
				filepath=downloadfile('aetnaintegration/uploads/'+domain_name+'/deductible',domain_name,file_type,file_name,mode)
				print("Downloaded file location:",filepath)
			else:
				filelist=listbucketcontents('aetnaintegration/uploads/'+domain_name+'/deductible')
				for i in filelist:
					if 'aetnaintegration/uploads/'+domain_name+'/deductible/archive' in i: filelist.remove(i)
				file_name=filelist[0].replace('aetnaintegration/uploads/'+domain_name+'/deductible/','')
				filepath=downloadfile('aetnaintegration/uploads/'+domain_name+'/deductible',domain_name,file_type,file_name,mode)
				print("Downloaded file location:",filepath)
			
			#email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','SSubramani@GWLabs.com','Deductible Updated - Initiated',['Processing of Deductible file '+file_name],None,False)				
			file_=Path(filepath)
			print("Path object",file_)
			if not file_.is_file():
				f.write('\n----File Does Not Exist Error----\n')
				f.close()
				email_log(sender,receiver[0],'Deepthi.gollapudi@nttdata.com,ssubramani@fliptrx.com',subject,body,os.environ['CB_DATA']+'/'+domain_name+'/'+file_type+'/log/log.txt')
				sys.exit()
			print('Downloaded',file_name)
			
			self.ded=pd.read_excel(filepath)
			self.ded.fillna("",inplace=True)
			
			cols={'Medical Individual Deductible - Non Preferred - 001 ('+currentyear+')':'deductibleaccr1','Medical Individual Deductible - Preferred - 002 ('+currentyear+')':'deductibleaccr2','Medical Individual Coinsurance Max - Non Preferred - L01 ('+currentyear+')':'maxopc1','Medical Individual Coinsurance Max - Preferred - L03 ('+currentyear+')':'maxopc2','PQ-ID':'pqid','ID-NAME':'idname','In & Out of Network RX Paid Ded Dollars':'fliptaetnaded','In & Out of Network RX Paid Coinsurance Dollars':'fliptaetnaopc'}
			#Column Names are renamed
			self.ded.rename(columns=cols,inplace=True)				
			self.ded['idname']=self.ded['idname'].apply(lambda x: str(int(x)).zfill(2))
			self.ded=self.ded.loc[:,['pqid','idname','deductibleaccr1','deductibleaccr2','maxopc1','maxopc2','FIRST NAME','LAST NAME','fliptaetnaded','fliptaetnaopc']]
			
			self.cols=list(self.ded)	
			self.ded['domain_name']=domain_name.upper()
			self.ded['plan_name']=''
			#self.ded['plan_year']=str(datetime.now().year)
			self.ded['plan_year']=currentyear
			self.ded['coverage_tier']=''
			self.ded['deductible_accrued']=''
			self.ded['out_of_pocket_accrued']=''
			self.ded['data_extracted_date']=str(datetime.now())
			print('file read  ',str(datetime.now()))
			if domain_name.upper() not in list(self.ded['domain_name']):
				f.write('\n----Domain Error----\n')
				f.close()
				email_log(sender,receiver[0],'Deepthi.gollapudi@nttdata.com,ssubramani@fliptrx.com',subject,body,os.environ['CB_DATA']+'/'+domain_name+'/'+file_type+'/log/log.txt')
				sys.exit()
				
				
  

						
	def update(self):

		global filepath
		excludecols=['deductibleaccr1','deductibleaccr2','maxopc1','maxopc2','pqid','idname','FIRST NAME','LAST NAME','fliptaetnaded','fliptaetnaopc']
		errorlog=pd.DataFrame()
		domainlist=[domain_name]
		if domain_name.upper().strip()=='GWLABS001': domainlist.append('FLIPT001')
		for k,g in self.ded.groupby(['pqid']):
			g.reset_index(drop=True,inplace=True)
			rec=dict()
			#print('Groupby',g)
			
			for i,row in g.iterrows():
				
				dep_flipt_person_id=''	
				planname=''
				coveragetier,realdomain='',''					
				#Fetching all the aetna insurance details in flipt person hierarchy for the domains , ins membber id and relationship code given in the input file.  
				query=N1QLQuery('Select b.dep_flipt_person_id,b.emp_flipt_person_id,in1.coverage_tier_name,in1.benefit_plan_name,b.domain_name from `'+bucket_name+'` b unnest b.ins_carrier in1 where b.type="flipt_person_hierarchy" and b.domain_name in $dn and in1.ins_relationship_code=$irc and b.emp_flipt_person_id in (Select raw c.emp_flipt_person_id from `'+bucket_name+'` c unnest c.ins_carrier in2 where c.type="flipt_person_hierarchy" and c.domain_name in $dn and in2.ins_carrier_member_id=$icm)',icm=str(row['pqid']),irc=str(row['idname']),dn=domainlist)					
				print(query)
				for qresult in cb.n1ql_query(query):
					dep_flipt_person_id=qresult['dep_flipt_person_id']
					coveragetier=qresult['coverage_tier_name']	
					planname=qresult['benefit_plan_name']
					emp_flipt_person_id=qresult['emp_flipt_person_id']
					realdomain=qresult['domain_name']						
				if dep_flipt_person_id=='':
					errorlog=errorlog.append({'Domain_Name':row['domain_name'],'Ins_Carrier_Member_ID':row['pqid'],'Ins_Relationship_Code':row['idname'],'Record Message':'Person Not Found','First Name':row['FIRST NAME'],'Last Name':row['LAST NAME']},ignore_index=True)
					continue
				for c in self.cols:
					if c not in excludecols:
						rec[c.replace(' ','_').lower()]=str(row[c])
						#print(rec)
				rec['type']='deductible'
				rec['emp_flipt_person_id']=emp_flipt_person_id
				rec['dep_flipt_person_id']=dep_flipt_person_id 
				rec['coverage_tier']=coveragetier
				rec['plan_name']=planname
				rec['carrier_deductible_accrued']="{0:.2f}".format(float(row['deductibleaccr1'])+float(row['deductibleaccr2']))
				rec['carrier_out_of_pocket_accrued']="{0:.2f}".format(float(row['maxopc1']+float(row['maxopc2'])))
				rec['message']='Person Found Successfully'
				rec['status']='S'
				#rec['plan_year']=str(datetime.now().year)
				rec['plan_year']=currentyear
				rec['domain_name']=realdomain.upper().strip()
				rec['coverage_tier']=coveragetier
				amt=0
				rec['deductible_accrued']="{0:.2f}".format(float(row['deductibleaccr1'])+float(row['deductibleaccr2'])+float(amt))
				rec['out_of_pocket_accrued']="{0:.2f}".format(float(row['maxopc1'])+float(row['maxopc2'])+float(amt))
				rec['data_extracted_date']=str(cutoffdt)
				rec['flipt_aetna_deductible'] = "{0:.2f}".format(float(row['fliptaetnaded']))
				rec['flipt_aetna_out_of_pocket'] = "{0:.2f}".format(float(row['fliptaetnaopc']))
				#print("Records that are inserted in deductible type are as follows:",rec)
				if mode.lower().strip()=='final':
					oldrec={}
					present=False
					#query=N1QLQuery('Select created_date,META().id as id from `'+bucket_name+'`where type="deductible" and plan_year=$yr and domain_name in $dn and dep_flipt_person_id=$dep',yr=str(datetime.now().strftime('%Y')),dn=domainlist,dep=str(rec['dep_flipt_person_id']))
					query=N1QLQuery('Select created_date,META().id as id from `'+bucket_name+'`where type="deductible" and plan_year=$yr and domain_name in $dn and dep_flipt_person_id=$dep',yr=currentyear,dn=domainlist,dep=str(rec['dep_flipt_person_id']))
					for r in cb.n1ql_query(query):
						oldrec.update(r)
						present=True
					if present:          
						rec['created_date']=oldrec['created_date']
						rec['updated_date']=datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat()
						cb.upsert(str(oldrec['id']),rec,format=FMT_JSON)
						#print("In if condition after upsert")
						continue
					else:
						rec['created_date']=datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat()
						rec['updated_date']=datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat()
						cb.upsert(str(cb.counter('docid',delta=1).value),rec, format=FMT_JSON)
						#print("In else condition after upsert")
		if mode.lower().strip()=='final':
			body='Hi,\n Please find attached the latest deductible file received by us from Aetna. \n \n Best regards,\n FLIPT Integration Team'
			email_log_custombody(sender,'CNg@GWLabs.com',None,'Deductible File '+str(cutoffdt),body,filepath)
		global errlog
		writer=pd.ExcelWriter(os.environ['CB_DATA']+'/'+domain_name+'/'+file_type+'/log/'+errlog)
		errorlog.to_excel(writer,index=False)
		writer.save()       

                 

errlog='Errorlog'+str(datetime.now())+'.xlsx'                          
obj=Deductible()
obj.update()
f.write('\n---Deductible Update Done----\n')
f.write(str(datetime.now())+'\n')
f.close()
body=['Processing of Deductible file '+file_name,'‘Deductible Exception’']
email_log(sender,receiver[0],'Deepthi.gollapudi@nttdata.com,ssubramani@fliptrx.com,hrajendran@fliptrx.com',subject,body,os.environ['CB_DATA']+'/'+domain_name+'/'+file_type+'/log/'+errlog)

req.close()       