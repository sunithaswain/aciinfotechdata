

config - decide application running environment configuration
requirements.txt - dependency python package name list
readme - application description, meta information
gitignore - ignored file/folder list for git repository


Note: Folder structure may vary based on Python (web) framework
-/+ - Collapse/Expand