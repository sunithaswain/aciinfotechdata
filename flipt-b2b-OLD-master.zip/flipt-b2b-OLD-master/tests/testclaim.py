import unittest

class TestClaim(unittest.TestCase):

    def test_one(self):
        self.assertEqual(6, 6, "Should be 6")

    def test_two(self):
        self.assertEqual(60, 60, "Should be 60")

if __name__ == '__main__':
    unittest.main()