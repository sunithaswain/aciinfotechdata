All notable changes to this project will be documented in this file.

1.0.0 - 2018 - 11 - 30

Added
* function added



Changed
* function modified