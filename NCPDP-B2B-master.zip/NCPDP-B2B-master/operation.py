import json, os, pdb
import pandas as pd

class pharmacy_database():
    def __init__(self,f_path):
        # file path
        self.f_path = f_path
    # mtd for creating list object as per configs
    def create_ob(self,f_body,cnfg_struct):
        data_list = []
        for key in cnfg_struct.keys():
            try:
                data_list.append(f_body[(cnfg_struct[key][1][0])-1:(cnfg_struct[key][1][1])])
            except Exception as e:
                data_list.append(f_body[(cnfg_struct[key][1][0])-1])
        return data_list
    # main mtd for handling configs and read NCPDP data from text files
    def main_mtd(self,config_json):
        # read all text files from given directory
        for file in os.listdir(self.f_path):
            # read the config for respective
            for key in list(config_json.keys()):
                # strip '.txt' from text file name
                file_name = file.split('.')[0]
                if file_name in key:
                    file_config_json = config_json[key]
                    # read the text file content
                    f_content = open(self.f_path+'\\'+file, 'r').readlines()
                    # output file name
                    file_header_trailer = file_config_json['header_trailer']
                    file_detail_record = file_config_json['detail_record']
                    # created column headers including  meta data
                    file_header_cols = list(file_header_trailer.keys())
                    file_detail_record_cols = file_header_cols[:4]+list(file_detail_record.keys())
                    # prepare header
                    f_header = f_content[0]
                    # capture meta data from the header
                    header_lst = self.create_ob(f_header,file_header_trailer)[:4]
                    # prepare body
                    op_file_content = []
                    for i in range(1,(len(f_content)-1)):
                        op_file_content.append(header_lst+self.create_ob(f_content[i],file_detail_record))
                    content_dict = {k: [x[i] for x in op_file_content] for i, k in enumerate(file_detail_record_cols)}
                    # Create data frame for content
                    content_df = pd.DataFrame.from_dict(content_dict)
                    # create CSV to store content of pharmacy files including meta data
                    content_df.to_csv(file_name+'_data.csv',index=None, header=True)
                    # Create excel to store content of pharmacy files including meta data
                    wtr_obj = pd.ExcelWriter(file_name+'_data.xlsx')
                    content_df.to_excel(wtr_obj, sheet_name='NCPDP Data', header=True,index=False)
                    wtr_obj.save()
                    break

# Create object for pharmacy_database class and use NCPDP data file directory
path = r'..\NCPDP_v3.1_Monthly_Transaction_20200101'
obj = pharmacy_database(path)
# read json file
with open('config.json', 'r') as json_file:
    data = json_file.read()
# create json object from file
mas_coo_json = json.loads(data)
obj.main_mtd(mas_coo_json)