# NCPDP-B2B
1. Give input file directory where pharmacy text files are stored as path(at line no. 55). 
   eg: path = r'C:\Users\Vishal\Downloads\NCPDP_v3.1_Monthly_Transaction_20200101'
2. Have operation.py and config.json saved at same path
2. Run the operation.py code
3. Reports will be created in excel and csv formats(where code is available)
