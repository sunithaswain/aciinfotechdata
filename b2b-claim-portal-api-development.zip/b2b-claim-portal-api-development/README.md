# b2b-claim-portal-api
This is claim portal api

Installation:
1. Clone the repository 
2. run command "source setup.sh"

Run the REST API:
1. python app/index.py 
