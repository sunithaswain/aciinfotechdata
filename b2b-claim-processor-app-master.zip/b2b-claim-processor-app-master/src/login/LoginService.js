import api from 'utils/api'

class LoginService {
  async login (username, password) {
    const body = { 'username':username, 'password': password, 'isAccountID': 'N' }
    const data = await api.login(
      { body: JSON.stringify(body) })
    return data
  }
}
export default new LoginService()
