import React from 'react'
import PropTypes from 'prop-types'

class LoginView extends React.Component {
 constructor (props) {
    super(props)
    this.state = {
      username:'',
      password:''
    }
    this.handleInputChange = this.handleInputChange.bind(this)
   }

  componentDidMount () {
  }

  handleClick (event) {
      this.props.login(this.state.username, this.state.password)
  }

  handleInputChange (event) {
    const target = event.target
    const value = target.value
    const name = target.name

    this.setState({
      [name]: value
    })
  }
  render () {
      return (

        <div className='login-container'>
          <div className='log-in-form'>
            <div className='column row'>
              <lable>User Name</lable>
              <input type='text' name='username' value={this.state.username} onChange={this.handleInputChange} />
            </div>
            <div className='column row'>
              <lable>Password</lable>
              <input type='password' name='password' value={this.state.password} onChange={this.handleInputChange} />
            </div>
            <div className='column row'>
              <input type='button' className='button expanded button-login-cp' value='Login' onClick={(event) => this.handleClick(event)} />
            </div>
          </div>
        </div>
      )
  }
}
LoginView.propTypes = {
  login:PropTypes.func
}
export default LoginView
