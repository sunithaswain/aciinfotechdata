import LoginService from 'login/LoginService'
import { browserHistory } from 'react-router'
import Common from 'common/services/Common'

const SCREEN_LOADER = '@SCREEN_LOADER@'

export const login = (username, password) => {
   return async (dispatch) => {
    dispatch({
      type: SCREEN_LOADER,
      payload: { show: true }
    })
    try {
        const result = await LoginService.login(username, password)
        if (result) {
          if (result.access_token) {
            Common.setJwtToken(result.access_token)
            browserHistory.push('/claims/')
          } else if (result.message) {
            window.alert(result.message)
          } else {
            window.alert(result)
          }
        }
    } catch (e) {
          window.alert('ERROR: Invalid API Call')
          browserHistory.push('/error/')
    } finally {
        dispatch({
          type: SCREEN_LOADER,
          payload: { show: false }
        })
    }
   }
}
