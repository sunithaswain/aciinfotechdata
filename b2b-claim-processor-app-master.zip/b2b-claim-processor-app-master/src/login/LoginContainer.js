import { connect } from 'react-redux'
import LoginView from 'login/LoginView'
import { bindActionCreators } from 'redux'
import { login } from 'login/LoginActions'

const mapDispatchToProps = (dispatch) => {
  return {
        login:bindActionCreators(login, dispatch)
  }
}
const mapStateToProps = (state) => {
  return state
}

export default connect(mapStateToProps, mapDispatchToProps)(LoginView)
