import React from 'react'

import Search from '../search/SearchContainer'
import ClaimsTable from '../claimstable/ClaimstableContainer'
import BreadCrumView from 'common/components/breadcrums'
import ClaimsDetailsView from '../claimsdetails/ClaimsDetailsContainer'
import OverrideView from '../override/OverrideContainer'
import MemberView from '../member/MemberContainer'
import TransactionView from '../transaction/TransactionContainer'

class ClaimsView extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      currentHierarchy : { pageName : 'claim', primaryLevel : undefined, secondaryLevel : undefined },
      selectedAuthID : undefined,
      sequenceNumber : undefined,
      searchFilter : { authid : '', memberid : '', startdate : '', enddate : '' }

    }
    this.updatePageHierarchy = this.updatePageHierarchy.bind(this)
    this.revokePageHierarchy = this.revokePageHierarchy.bind(this)
    this.getSearchFilter = this.getSearchFilter.bind(this)
  }
  componentDidMount () {

  }
  componentWillUpdate () {}

  revokePageHierarchy (pageHierarchy) {
    this.setState({
      currentHierarchy : pageHierarchy
    })
  }

  updatePageHierarchy (pageHierarchy, selectedAuthID, sequenceNumber) {
    this.setState({
      currentHierarchy : pageHierarchy,
      selectedAuthID : selectedAuthID,
      sequenceNumber : sequenceNumber
    })
  }

  getSearchFilter (params) {
    this.setState({ searchFilter : params })
  }

  render () {
    return (
      <div className='grid-container full' >
        <BreadCrumView currentPage={this.state.currentHierarchy} revokePageHierarchy={this.revokePageHierarchy} />
        {
          (this.state.currentHierarchy.pageName && !this.state.currentHierarchy.primaryLevel && !this.state.currentHierarchy.secondaryLevel)
          ? <div name='claimpage'>
            <Search getSearchFilter={this.getSearchFilter} searchFilter={this.state.searchFilter} />
            <ClaimsTable searchFilter={this.state.searchFilter} updatePageHierarchy={this.updatePageHierarchy} />
          </div>
          : ''
        }
        {
          (this.state.currentHierarchy.primaryLevel === 'claim details' && !this.state.currentHierarchy.secondaryLevel)
          ? <div name='claimdetail'><ClaimsDetailsView selectedAuthID={this.state.selectedAuthID} updatePageHierarchy={this.updatePageHierarchy} /></div>
          : (this.state.currentHierarchy.primaryLevel === 'member' && !this.state.currentHierarchy.secondaryLevel)
          ? <div name='memberdetail'><MemberView selectedAuthID={this.state.selectedAuthID} sequenceNumber={this.state.sequenceNumber} updatePageHierarchy={this.updatePageHierarchy} /></div>
          : ''
        }
        {
          (this.state.currentHierarchy.secondaryLevel === 'override')
          ? <div name='claimoverride'><OverrideView selectedAuthID={this.state.selectedAuthID} sequenceNumber={this.state.sequenceNumber} updatePageHierarchy={this.updatePageHierarchy} /></div>
          : (this.state.currentHierarchy.secondaryLevel === 'transaction')
          ? <div name='claimtransaction'><TransactionView selectedAuthID={this.state.selectedAuthID} sequenceNumber={this.state.sequenceNumber} updatePageHierarchy={this.updatePageHierarchy} /></div>
          : ''
        }

      </div>
    )
  }
}
ClaimsView.propTypes = {

}
export default ClaimsView
