import { connect } from 'react-redux'
import ClaimsView from 'claims/ClaimsView'

const mapDispatchToProps = (dispatch) => {
  return {

  }
}
const mapStateToProps = (state) => {
  return {

  }
}
export default connect(mapStateToProps, mapDispatchToProps)(ClaimsView)
