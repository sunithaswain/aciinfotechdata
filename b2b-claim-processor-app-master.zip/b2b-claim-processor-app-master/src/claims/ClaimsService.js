
class ClaimsService {

}
export default new ClaimsService()
