import createFetch from 'utils/createFetch'
import { apiResponseIgnore401ErrorHandler } from 'utils/apiResponseFilter'
import { SERVER_API_URL } from 'common/constants/AppGlobals'

const serverAPI = SERVER_API_URL

export default {

  login: (opts) => createFetch(
    serverAPI + '/api/v1/user/login',
    opts,
    {},
    {
      method: 'POST'
    },
    [apiResponseIgnore401ErrorHandler], false, true
  ),
  logout: (opts) => createFetch(
    serverAPI + '/api/v1/user/logout',
    opts,
    {},
    {
      method: 'POST'
    },
    [apiResponseIgnore401ErrorHandler], false, true
  ),
  search: (opts) => createFetch(
    serverAPI + '/api/v1/claim/search',
    opts,
    {},
    {
      method: 'POST'
    },
    [apiResponseIgnore401ErrorHandler], false, true
  ),
  claimdetails: (opts, qryparams) => createFetch(
    serverAPI + '/api/v1/claim/detail' + qryparams,
    opts,
    {},
    {
      method: 'GET'
    },
    [apiResponseIgnore401ErrorHandler], false, true
  ),
  getclaimoverride: (opts, qryparams) => createFetch(
    serverAPI + '/api/v1/claim/override' + qryparams,
    opts,
    {},
    {
      method: 'GET'
    },
    [apiResponseIgnore401ErrorHandler], false, true
  ),
  updateclaimoverride: (opts) => createFetch(
    serverAPI + '/api/v1/claim/override',
    opts,
    {},
    {
      method: 'PUT'
    },
    [apiResponseIgnore401ErrorHandler], false, true
  ),
  getmember: (opts, qryparams) => createFetch(
    serverAPI + '/api/v1/claim/member' + qryparams,
    opts,
    {},
    {
      method: 'GET'
    },
    [apiResponseIgnore401ErrorHandler], false, true
  ),
  gettransaction: (opts, qryparams) => createFetch(
    serverAPI + '/api/v1/claim/transaction' + qryparams,
    opts,
    {},
    {
      method: 'GET'
    },
    [apiResponseIgnore401ErrorHandler], false, true
  ),
  searchEligibility: (opts, qryparams) => createFetch(
    serverAPI + '/api/v1/eligibility/search' + qryparams,
    opts,
    {},
    {
      method: 'GET'
    },
    [apiResponseIgnore401ErrorHandler], false, true
  ),
  geteligibilitymember: (opts, qryparams) => createFetch(
    serverAPI + '/api/v1/eligibility/member' + qryparams,
    opts,
    {},
    {
      method: 'GET'
    },
    [apiResponseIgnore401ErrorHandler], false, true
  ),
  updateeligibilitymember: (opts) => createFetch(
    serverAPI + '/api/v1/eligibility/member',
    opts,
    {},
    {
      method: 'PUT'
    },
    [apiResponseIgnore401ErrorHandler], false, true
  ),

}
