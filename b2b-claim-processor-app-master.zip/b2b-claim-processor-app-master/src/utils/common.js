
const formatDate = (dateString, options = {
  year: 'numeric',
  month: 'numeric',
  day: 'numeric',
  hour: '2-digit',
  minute: '2-digit'
}) => {
  if (dateString) {
    let date = new Date(dateString)
    return date.toLocaleDateString('en-US', options)
  } else {
    return false
  }
}

const formatTime = (dateString, options = {
  hour: '2-digit',
  minute: '2-digit'
}) => {
  if (dateString) {
    let date = new Date(dateString)
    return date.toLocaleTimeString('en-US', options)
  } else {
    return false
  }
}

const currency = (v) => {
  let parsedVal = parseFloat(v)
  return isNaN(parsedVal) ? ''
  : parsedVal.toLocaleString('en-US', { style: 'currency', currency: 'USD' }).replace(/\D\d\d$/, '')
}
const ellipsis = (input, limit) => {
  if (!input || !input.length) return
  return (input.length < limit) ? input : `${input.slice(0, limit)}...`
}

export {
  formatDate,
  formatTime,
  currency,
  ellipsis
}
