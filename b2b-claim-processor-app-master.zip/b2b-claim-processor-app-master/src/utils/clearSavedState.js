
let hasClearedState = false

export const clearStateAndHasClearedState = () => {
  hasClearedState = false
  window.sessionStorage.clear()
}

export const getHasClearedState = () => {
  return hasClearedState
}

export default () => {

}
