
const INITIAL_STATE = {}

export default function claimsdetails (state = INITIAL_STATE, action) {
  switch (action.type) {
    default:
      return state
  }
}
