import React from 'react'
import PropTypes from 'prop-types'
import { get } from 'lodash'

import ClaimsDetailsGrid from 'claimsdetails/ClaimsDetailsGridView'

class ClaimsDetailsView extends React.Component {
    constructor (props) {
        super(props)
        this.state = {}
    }
    componentDidMount () {}
    componentWillMount () {}
    componentWillUpdate () {}

    render () {
        const tabledata = get(this.props, 'claimstable')
        return (
          <div>
            <ClaimsDetailsGrid datas={tabledata} updatePageHierarchy={this.props.updatePageHierarchy} />
          </div>
        )
    }
}

ClaimsDetailsView.propTypes = {
    updatePageHierarchy : PropTypes.func
}

export default ClaimsDetailsView
