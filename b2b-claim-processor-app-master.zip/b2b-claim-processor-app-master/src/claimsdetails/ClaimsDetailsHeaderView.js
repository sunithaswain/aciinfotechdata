import React from 'react'

class ClaimsDetailsHeaderView extends React.Component {
  constructor (props) {
    super(props)
    this.state = { }
  }
  componentDidMount () {

  }

  componentWillUpdate () {

  }

  render () {
    return (
      <div>

        <div className='row'>
          <div className='small-2 columns'>NPI</div>
          <div className='small-2 columns' />
          <div className='small-2 columns'>NCPDP</div>
          <div className='small-2 columns' />
          <div className='small-2 columns' />
          <div className='small-2 columns' />
        </div>
        <div className='row'>
          <div className='small-2 columns'>Address</div>
          <div className='small-2 columns' />
          <div className='small-2 columns' />
          <div className='small-2 columns' />
          <div className='small-2 columns' />
          <div className='small-2 columns' />
        </div>

      </div>
    )
  }
}

ClaimsDetailsHeaderView.propTypes = {

}

export default ClaimsDetailsHeaderView
