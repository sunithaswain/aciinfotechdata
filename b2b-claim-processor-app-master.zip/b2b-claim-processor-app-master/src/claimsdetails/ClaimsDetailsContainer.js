import { connect } from 'react-redux'
import ClaimsDetailsView from 'claimsdetails/ClaimsDetailsView'
import { bindActionCreators } from 'redux'
import { claimsdetails } from 'claimsdetails/ClaimsDetailsActions'

const mapDispatchToProps = (dispatch) => {
  return {
    claimsdetails:bindActionCreators(claimsdetails, dispatch)
  }
}
const mapStateToProps = (state) => {
  return state
}
export default connect(mapStateToProps, mapDispatchToProps)(ClaimsDetailsView)
