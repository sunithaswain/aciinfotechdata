import ClaimsDetailsService from 'claimsdetails/ClaimsDetailsService'
import { browserHistory } from 'react-router'

const SCREEN_LOADER = '@SCREEN_LOADER@'

export const claimsdetails = () => {
  return async (dispatch) => {
    dispatch({
      type: SCREEN_LOADER,
      payload: { show: true }
    })
   try {
        const result = await ClaimsDetailsService.claimsdetails()
        if (result) {
          // console.log(result.result)
        }
    } catch (e) {
        if (e.status === 500) {
          window.alert('ERROR: Internal Server or Application(Claimdetails API Endpoint) Error. Please contact the Integration team.')
          browserHistory.push('/')
        } else if (e.status === 502) {
          window.alert('ERROR: Server(Bad Gateway) Error. Please contact the Integration team.')
          browserHistory.push('/')
        } else {
          window.alert('ERROR: Application(Claimdetails API Endpoint) Error. Please contact the Integration team.')
          browserHistory.push('/error/')
        }
    } finally {
      dispatch({
        type: SCREEN_LOADER,
        payload: { show: false }
      })
    }
  }
}
