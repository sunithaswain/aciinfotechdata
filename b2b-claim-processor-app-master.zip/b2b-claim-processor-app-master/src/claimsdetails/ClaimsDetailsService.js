
class ClaimsDetailsService {

}
export default new ClaimsDetailsService()
