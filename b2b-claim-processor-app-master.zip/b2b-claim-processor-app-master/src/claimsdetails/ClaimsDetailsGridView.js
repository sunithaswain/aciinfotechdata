import React from 'react'
import PropTypes from 'prop-types'

class ClaimsDetailsGridView extends React.Component {
  constructor (props) {
    super(props)
    this.state = {}
  }
  componentDidMount () { }

  componentWillUpdate () { }

  openClaimOverride (event) {
    const currentPageLevel = {
      pageName : 'claim', primaryLevel: 'claim details', secondaryLevel: 'override'
    }
    const sequenceNumber = event.target.getAttribute('value')
    const selectedAuthid = event.target.getAttribute('name')

    this.props.updatePageHierarchy(currentPageLevel, selectedAuthid, sequenceNumber)
  }

  openClaimTransaction (event) {
    const currentPageLevel = {
      pageName : 'claim', primaryLevel: 'claim details', secondaryLevel: 'transaction'
    }
    const sequenceNumber = event.target.getAttribute('value')
    const selectedAuthid = event.target.getAttribute('name')

    this.props.updatePageHierarchy(currentPageLevel, selectedAuthid, sequenceNumber)
  }

  render () {
    const tabledata = this.props.datas

    if (!tabledata.length) {
      return (
        <div />
        )
    }

    return (

      <div className='enableScroll'>
        <table className='fixed_header'>
          <thead>
            <tr>
              <th>Date / Time</th>
              <th>Member ID</th>
              <th>Response Status</th>
              <th>Transfer Status</th>
              <th>Transaction Type</th>
              <th>Seq.No</th>
              <th>Product Name</th>
              <th>Group ID</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {
            tabledata.map((value, index) => {
              return <tr key={index}>
                <td>{value.date_time}</td>
                <td>{value.memberid}</td>
                <td>{value.status}</td>
                <td>{value.transferstatus}</td>
                <td>{value.transactioncode}</td>
                <td>{value.sequencenumber}</td>
                <td>{value.product_name}</td>
                <td>{value.group_id}</td>
                <td>{value.firstname}</td>
                <td>{value.lastname}</td>
                <td><div>
                  <a name={value.auth_id} value={value.sequencenumber + '|' + value.product_name} onClick={(event) => this.openClaimOverride(event)} >Override </a> |
                  <a name={value.auth_id} value={value.sequencenumber} onClick={(event) => this.openClaimTransaction(event)} > Transaction</a>
                </div></td>
              </tr>
            })
          }
          </tbody>
        </table>
      </div>

    )
  }
}

ClaimsDetailsGridView.propTypes = {
  updatePageHierarchy : PropTypes.func,
  datas : PropTypes.array
}

export default ClaimsDetailsGridView
