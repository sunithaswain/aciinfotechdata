import React from 'react'
import PropTypes from 'prop-types'

class SearchView extends React.Component {
 constructor (props) {
    super(props)
    this.state = {
      authid:this.props.searchFilter['authid'],
      memberid:this.props.searchFilter['memberid'],
      startdate:this.props.searchFilter['startdate'],
      enddate:this.props.searchFilter['enddate']
    }
    this.handleInputChange = this.handleInputChange.bind(this)
    this.handleKeyDown = this.handleKeyDown.bind(this)
   }

  componentDidMount () { }

  handleClick (event) {
    let isValidDateRange = true
    if (this.state.startdate !== '' && this.state.enddate !== '') {
      var sdate = new Date(this.state.startdate)
      var edate = new Date(this.state.enddate)
      sdate.setHours(0, 0, 0, 0)
      edate.setHours(0, 0, 0, 0)
      if (sdate.getTime() >= edate.getTime()) {
        isValidDateRange = false
      }
    }
    if (isValidDateRange) {
      let searchFilter = { authid : this.state.authid, memberid : this.state.memberid, startdate : this.state.startdate, enddate : this.state.enddate }
      // this.props.search(this.state.authid, this.state.memberid, this.state.startdate, this.state.enddate, 0)
      this.props.getSearchFilter(searchFilter)
    } else {
      window.alert('Start Date should be less than End Date')
    }
}

  handleInputChange (event) {
    const target = event.target
    const value = target.value
    const name = target.name

    this.setState({
      [name]: value
    })
  }

  handleKeyDown (event) {
    if (event.keyCode === 13) this.handleClick()
  }

  render () {
      return (

        <div className='grid-x grid-padding-x'>
          <div className='medium-2 cell'>
            <label>Auth ID
              <input type='text' name='authid' placeholder='Auth ID' value={this.state.authid} onChange={this.handleInputChange} onKeyDown={this.handleKeyDown} />
            </label>
          </div>
          <div className='medium-2 cell'>
            <label>Member ID
              <input type='text' name='memberid' placeholder='Member ID' value={this.state.memberid} onChange={this.handleInputChange} onKeyDown={this.handleKeyDown} />
            </label>
          </div>
          <div className='medium-2 cell'>
            <label>Start Date
              <input type='date' name='startdate' placeholder='MM/DD/YYYY' value={this.state.startdate} onChange={this.handleInputChange} />
            </label>
          </div>
          <div className='medium-2 cell'>
            <label>End Date
              <input type='date' name='enddate' placeholder='MM/DD/YYYY' value={this.state.enddate} onChange={this.handleInputChange} />
            </label>
          </div>
          <div className='medium-4 cell'>

            <button className='button claimsearchbtn' type='button' onClick={(event) => this.handleClick(event)} >Search</button>

          </div>

        </div>

      )
  }
}
SearchView.propTypes = {
  // search:PropTypes.func,
  searchFilter : PropTypes.object,
  getSearchFilter : PropTypes.func
}
export default SearchView
