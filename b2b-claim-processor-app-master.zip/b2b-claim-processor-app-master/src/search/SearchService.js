import api from 'utils/api'
import Common from 'common/services/Common'

class SearchService {

  fillAuthId (authid) {
    const missingNums = (13 - authid.length)
    return (missingNums > 0 ? '0'.repeat(missingNums) + authid : authid)
  }

  async search (authid, memberid, startdate, enddate, offset) {
    const body = { 'authid':authid, 'memberid': memberid, 'startdate':startdate, 'enddate':enddate, 'offset':offset }
    const data = await api.search(
        {
          body: JSON.stringify(body),
          customToken: { value: Common.getJwtToken() },
          tokenType: 'Bearer'
        })

    return data
  }
}
export default new SearchService()
