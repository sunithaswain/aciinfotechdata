import { connect } from 'react-redux'
import SearchView from 'search/SearchView'
import { bindActionCreators } from 'redux'
import { search } from 'search/SearchActions'
import { get } from 'lodash'

const mapDispatchToProps = (dispatch) => {
  return {
        search:bindActionCreators(search, dispatch)
  }
}
const mapStateToProps = (state) => {
  return {
    searchDetails: [get(state, 'search')]
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(SearchView)
