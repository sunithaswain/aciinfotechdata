import SearchService from 'search/SearchService'
import { browserHistory } from 'react-router'
import { SEARCH_CLAIMS_SUCCESS } from 'common/constants/ActionConstants'
import createAction from 'utils/createAction'

const searchClaimsSuccessAction = createAction(SEARCH_CLAIMS_SUCCESS)
const SCREEN_LOADER = '@SCREEN_LOADER@'

export const search = (authid, memberid, startdate, enddate, offset) => {
   return async (dispatch) => {
    dispatch({
      type: SCREEN_LOADER,
      payload: { show: true }
    })
    try {
      if (authid) {
        authid = SearchService.fillAuthId(authid)
      }
        const result = await SearchService.search(authid, memberid, startdate, enddate, offset)

        if (result) {
          dispatch(searchClaimsSuccessAction(result))
        }
    } catch (e) {
        if (e.status === 500) {
          window.alert('ERROR: Internal Server or Application(Claim API Endpoint) Error. Please contact the Integration team.')
          browserHistory.push('/')
        } else if (e.status === 502) {
          window.alert('ERROR: Server(Bad Gateway) Error. Please contact the Integration team.')
          browserHistory.push('/')
        } else {
          window.alert('ERROR: Application(Claim API Endpoint) Error. Please contact the Integration team.')
          browserHistory.push('/error/')
        }
      } finally {
        dispatch({
          type: SCREEN_LOADER,
          payload: { show: false }
        })
    }
   }
}
