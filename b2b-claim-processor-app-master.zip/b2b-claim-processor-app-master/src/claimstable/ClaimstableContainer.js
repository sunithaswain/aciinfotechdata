import { connect } from 'react-redux'
import ClaimstableView from 'claimstable/ClaimstableView'
import { bindActionCreators } from 'redux'
import { claimsdata } from 'claimstable/ClaimstableActions'
import { search } from 'search/SearchActions'

const mapDispatchToProps = (dispatch) => {
  return {
        claimsdata:bindActionCreators(claimsdata, dispatch),
        loadclaimsdata:bindActionCreators(search, dispatch)
  }
}
const mapStateToProps = (state) => {
  return state
}

export default connect(mapStateToProps, mapDispatchToProps)(ClaimstableView)
