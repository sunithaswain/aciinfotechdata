import ClaimstableService from 'claimstable/ClaimstableService'
import { browserHistory } from 'react-router'
import { CLAIMSTABLE_CLAIMS_SUCCESS } from 'common/constants/ActionConstants'
import createAction from 'utils/createAction'

const searchClaimsSuccessAction = createAction(CLAIMSTABLE_CLAIMS_SUCCESS)
const SCREEN_LOADER = '@SCREEN_LOADER@'

export const claimsdata = (authid) => {
   return async (dispatch) => {
    dispatch({
      type: SCREEN_LOADER,
      payload: { show: true }
    })
    dispatch(searchClaimsSuccessAction([]))
    try {
      const result = await ClaimstableService.claimdetails(authid)

        if (result) {
          dispatch(searchClaimsSuccessAction(result.result))
        }
    } catch (e) {
        if (e.status === 500) {
          window.alert('ERROR: Internal Server or Application(Claim API Endpoint) Error. Please contact the Integration team.')
          browserHistory.push('/')
        } else if (e.status === 502) {
          window.alert('ERROR: Server(Bad Gateway) Error. Please contact the Integration team.')
          browserHistory.push('/')
        } else {
          window.alert('ERROR: Application(Claim API Endpoint) Error. Please contact the Integration team.')
          browserHistory.push('/error/')
        }
      } finally {
        dispatch({
          type: SCREEN_LOADER,
          payload: { show: false }
        })
    }
   }
}
