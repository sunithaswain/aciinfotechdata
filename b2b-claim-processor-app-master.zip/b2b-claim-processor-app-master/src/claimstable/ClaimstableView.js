import React from 'react'
import PropTypes from 'prop-types'
import { get } from 'lodash'
import ReactPaginate from 'react-paginate'

class ClaimstableView extends React.Component {
  static propTypes = {

  };
  constructor (props) {
    super(props)
    this.state = {}
  }

  componentDidMount () {
    const authid = this.props.searchFilter['authid']
    const memberid = this.props.searchFilter['memberid']
    const startdate = this.props.searchFilter['startdate']
    const enddate = this.props.searchFilter['enddate']
    this.props.loadclaimsdata(authid, memberid, startdate, enddate, 0)
  }
  componentWillMount () {

  }
  componentDidUpdate (prevProps) {
    let isneedupdate = false
    if (prevProps['searchFilter']['authid'] !== this.props.searchFilter['authid']) {
      isneedupdate = true
    }
    if (prevProps['searchFilter']['memberid'] !== this.props.searchFilter['memberid']) {
      isneedupdate = true
    }
    if (prevProps['searchFilter']['startdate'] !== this.props.searchFilter['startdate']) {
      isneedupdate = true
    }
    if (prevProps['searchFilter']['enddate'] !== this.props.searchFilter['enddate']) {
      isneedupdate = true
    }
    if (isneedupdate) {
      const authid = this.props.searchFilter['authid']
      const memberid = this.props.searchFilter['memberid']
      const startdate = this.props.searchFilter['startdate']
      const enddate = this.props.searchFilter['enddate']

      this.props.loadclaimsdata(authid, memberid, startdate, enddate, 0)
    }
  }
  openClaimDetails (event) {
    this.props.claimsdata(event.target.getAttribute('value'))

    const currentPageLevel = {
      pageName:'claim', primaryLevel:'claim details', secondaryLevel:undefined
    }

    const selectedAuthid = event.target.getAttribute('value')
    const sequenceNumber = undefined
    this.props.updatePageHierarchy(currentPageLevel, selectedAuthid, sequenceNumber)
  }

  openMemberDetails (event) {
    const currentPageLevel = {
      pageName:'claim', primaryLevel:'member', secondaryLevel:undefined
    }

    const selectedMemberid = event.target.getAttribute('name')
    const selectedPersoncode = event.target.getAttribute('value')
    this.props.updatePageHierarchy(currentPageLevel, selectedMemberid, selectedPersoncode)
  }

  handlePageClick = data => {
    let selected = data.selected
    let offset = Math.ceil(selected * 20)
    const authid = this.props.searchFilter['authid']
    const memberid = this.props.searchFilter['memberid']
    const startdate = this.props.searchFilter['startdate']
    const enddate = this.props.searchFilter['enddate']
    this.props.loadclaimsdata(authid, memberid, startdate, enddate, offset)
  };

  render () {
    const tabledata = get(this.props, 'search')
    let pageCount = 1
      if (_.isEmpty(tabledata)) {
        return (
          <div />
          )
      } else if (tabledata['result'].length === 0) {
        return (
          <div>
            <table>
              <thead>
                <tr>
                  <th>No Record Found</th>
                </tr>
              </thead>
            </table>
          </div>
        )
      } else {
        pageCount = Math.ceil(tabledata['total'] / 20)
        return (

          <div>
            <table>
              <thead>
                <tr>
                  <th>Date / Time</th>
                  <th>AuthID</th>
                  <th>Member ID</th>
                  <th>Response Status</th>
                  <th>Transfer Status</th>
                  <th>Transaction Type</th>
                  <th>First Name</th>
                  <th>Last Name</th>
                  <th>Seq.No</th>
                  <th>Product Name</th>
                  <th>Group ID</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {
              tabledata['result'].map((value, index) => {
                return <tr key={index}>
                  <td>{value.date_time}</td>
                  <td>{value.auth_id}</td>
                  <td>{value.memberid}</td>
                  <td>{value.status}</td>
                  <td>{value.transferstatus}</td>
                  <td>{value.transactioncode}</td>
                  <td>{value.firstname}</td>
                  <td>{value.lastname}</td>
                  <td>{value.sequencenumber}</td>
                  <td>{value.product_name}</td>
                  <td>{value.group_id}</td>
                  <td><div>
                    <a value={value.auth_id} onClick={(event) => this.openClaimDetails(event)} >Claim Details </a> |
                    <a name={value.memberid} value={value.personcode} onClick={(event) => this.openMemberDetails(event)} > Member</a>
                  </div></td>
                </tr>
              })
            }
              </tbody>
            </table>

            <ReactPaginate
              previousLabel={'Previous'}
              nextLabel={'Next'}
              breakLabel={'...'}
              breakClassName={'break-me'}
              pageCount={pageCount}
              marginPagesDisplayed={2}
              pageRangeDisplayed={5}
              onPageChange={this.handlePageClick}
              containerClassName={'pagination'}
              subContainerClassName={'pages pagination'}
              activeClassName={'active'}
            />

          </div>
      )
      }
  }
}
ClaimstableView.propTypes = {
  updatePageHierarchy : PropTypes.func,
  claimsdata : PropTypes.func,
  loadclaimsdata:PropTypes.func,
  searchFilter : PropTypes.object
}
export default ClaimstableView
