import getSavedState from 'utils/getSavedState'
import { CLAIMSTABLE_CLAIMS_SUCCESS } from 'common/constants/ActionConstants'
const INITIAL_STATE = getSavedState('CPA.searchDetails', {})

export default function search (state = INITIAL_STATE, action) {
  switch (action.type) {
    case CLAIMSTABLE_CLAIMS_SUCCESS:
        return action.payload
    default:
      return state
  }
}
