import PropTypes from 'prop-types'
import React from 'react'

const indexRoute = ({ children }) => (
  <div className='em-cc-bp'>
    { children }
  </div>
)

const Login = (store) => ({
  getComponent (nextState, cb) {
    require.ensure([], (require) => {
      const Login = require('login/LoginContainer').default
      cb(null, Login)
    }, 'login-bp')
  }
})

const Logout = (store) => ({
  getComponent (nextState, cb) {
    require.ensure([], (require) => {
      const Logout = require('logout/LogoutContainer').default
      cb(null, Logout)
    }, '')
  }
})

const Error = (store) => ({
  getComponent (nextState, cb) {
    require.ensure([], (require) => {
      const Error = require('error/ErrorContainer').default
      cb(null, Error)
    }, '')
  }
})

const Claims = (store) => ({
  getComponent (nextState, cb) {
    require.ensure([], (require) => {
      const Claims = require('claims/ClaimsContainer').default
      cb(null, Claims)
    }, '')
  }
})

const Eligibility = (store) => ({
  getComponent (nextState, cb) {
    require.ensure([], (require) => {
      const Eligibility = require('eligibility/EligibilityContainer').default
      cb(null, Eligibility)
    }, '')
  }
})

const Override = (store) => ({
  getComponent (nextState, cb) {
    require.ensure([], (require) => {
      const Override = require('override/OverrideContainer').default
      cb(null, Override)
    }, '')
  }
})

export default (pathPrefix = '', store) => ([

  {
    path        : '/',
    component   : indexRoute,
    indexRoute  : Claims,
    childRoutes : []
  },
  {
    path        : '/login/',
    component   : indexRoute,
    indexRoute  : Login,
    childRoutes : []
  },

  {
    path        : '/logout/',
    component   : indexRoute,
    indexRoute  : Logout,
    childRoutes : []
  },

  {
    path        : '/error/',
    component   : indexRoute,
    indexRoute  : Error,
    childRoutes : []
  },

  {
    path        : '/claims/',
    component   : indexRoute,
    indexRoute  : Claims,
    childRoutes : []
   },

   {
    path        : '/override/',
    component   : indexRoute,
    indexRoute  : Override,
    childRoutes : []
   },
   {
    path        : '/eligibility/',
    component   : indexRoute,
    indexRoute  : Eligibility,
    childRoutes : []
   },
].map((r) => {
  r.path = `${pathPrefix}${r.path}`
  if (!r._storeSet) {
    r.indexRoute = r.indexRoute(store)
  }
  r._storeSet = true
  return r
}))

indexRoute.propTypes = {
  children: PropTypes.object,
}
