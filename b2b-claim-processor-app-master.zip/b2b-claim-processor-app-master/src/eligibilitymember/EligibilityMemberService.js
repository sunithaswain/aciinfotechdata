import api from 'utils/api'
import Common from 'common/services/Common'

class EligibilityMemberService {
    async geteligibilitymember (memberdetails) {
        var mwords = memberdetails.split('|')
        var wmail = 'workmail=' + mwords[0]
        var dname = '&domainname=' + mwords[1]
        var mid = '&memberid=' + mwords[2]
        var mtype = '&membertype=' + mwords[3]
        var pcode = '&personcode=' + mwords[4]

        const qryparams = '?' + wmail + dname + mid + mtype + pcode
        const data = await api.geteligibilitymember(
          {
              customToken: { value: Common.getJwtToken() },
              tokenType: 'Bearer'
          }, qryparams)

        return data
    }

    async updateeligibiltiymember (eligibilityMemberInputParam) {
        const body = eligibilityMemberInputParam

        const data = await api.updateeligibilitymember(
          {
              body: JSON.stringify(body),
              customToken: { value: Common.getJwtToken() },
              tokenType: 'Bearer'
          })

          return data
    }
}
export default new EligibilityMemberService()
