import getSavedState from 'utils/getSavedState'
import { MEMBER_ELIGIBILITY_SUCCESS } from 'common/constants/ActionConstants'
const INITIAL_STATE = getSavedState('CPA.searchDetails', {})

export default function eligibilitymember (state = INITIAL_STATE, action) {
  switch (action.type) {
    case MEMBER_ELIGIBILITY_SUCCESS:
        return action.payload
    default:
      return state
  }
}
