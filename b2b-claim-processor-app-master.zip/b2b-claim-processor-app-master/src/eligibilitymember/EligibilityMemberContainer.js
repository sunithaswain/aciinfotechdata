import { connect } from 'react-redux'
import EligibilityMemberView from 'eligibilitymember/EligibilityMemberView'
import { bindActionCreators } from 'redux'
import { geteligibilitymember, updateeligibilitymember } from 'eligibilitymember/EligibilityMemberActions'

const mapDispatchToProps = (dispatch) => {
  return {
    geteligibilitymember:bindActionCreators(geteligibilitymember, dispatch),
    updateeligibilitymember:bindActionCreators(updateeligibilitymember, dispatch)
  }
}
const mapStateToProps = (state) => {
  return state
}
export default connect(mapStateToProps, mapDispatchToProps)(EligibilityMemberView)
