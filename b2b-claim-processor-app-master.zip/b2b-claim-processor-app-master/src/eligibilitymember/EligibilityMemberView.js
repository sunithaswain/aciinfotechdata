import React from 'react'
import PropTypes from 'prop-types'

import EligibilityMemberForm from 'eligibilitymember/EligibilityMemberFormView'

class EligibilityMemberView extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      readMode:true
    }
    this.updateeligibilitymember = this.updateeligibilitymember.bind(this)
  }
  componentDidMount () {
    this.props.geteligibilitymember(this.props.selectedMemberid)
  }
  componentWillUpdate () {}
  updateeligibilitymember (eligibilityMemberInputParam) {
    this.props.updateeligibilitymember(eligibilityMemberInputParam)
  }
  render () {
    let eligibilitymemberdata = {}
    if (this.props.eligibilitymember) {
      eligibilitymemberdata = this.props.eligibilitymember

      eligibilitymemberdata['readMode'] = true
    }

    return (

      <div className='grid-container full' >

        <div className='row'>
          <h3 className='small-12 columns'>Eligibility Member Details</h3>
        </div>
        <EligibilityMemberForm selectedMemberid={this.props.selectedMemberid} selectedPersoncode={this.props.selectedPersoncode}
          updateeligibilitymember={this.updateeligibilitymember} eligibilitymemberdata={eligibilitymemberdata} />

      </div>
    )
  }
}
EligibilityMemberView.propTypes = {
  geteligibilitymember : PropTypes.func,
  updateeligibilitymember : PropTypes.func,
  eligibilitymember : PropTypes.object,
  selectedMemberid : PropTypes.string,
  selectedPersoncode : PropTypes.string
}
export default EligibilityMemberView
