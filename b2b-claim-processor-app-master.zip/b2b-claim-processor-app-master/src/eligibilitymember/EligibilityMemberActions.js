import { browserHistory } from 'react-router'
import { MEMBER_ELIGIBILITY_SUCCESS } from 'common/constants/ActionConstants'
import createAction from 'utils/createAction'
import EligibilityMemberService from 'eligibilitymember/EligibilityMemberService'

const memberEligibilitySuccessAction = createAction(MEMBER_ELIGIBILITY_SUCCESS)
const SCREEN_LOADER = '@SCREEN_LOADER@'

export const geteligibilitymember = (memberdetails) => {
  return async (dispatch) => {
    dispatch({
      type: SCREEN_LOADER,
      payload: { show: true }
    })
    dispatch(memberEligibilitySuccessAction({}))
    try {
        const result = await EligibilityMemberService.geteligibilitymember(memberdetails)
        if (result.result) {
          dispatch(memberEligibilitySuccessAction(result.result))
        }
    } catch (e) {
        if (e.status === 500) {
          window.alert('ERROR: Internal Server or Application(Eligibility Member API Endpoint) Error. Please contact the Integration team.')
          browserHistory.push('/eligibility')
        } else if (e.status === 502) {
          window.alert('ERROR: Server(Bad Gateway) Error. Please contact the Integration team.')
          browserHistory.push('/eligibility')
        } else {
          window.alert('ERROR: Application(Eligibility Member API Endpoint) Error. Please contact the Integration team.')
          browserHistory.push('/error/')
        }
    } finally {
      dispatch({
        type: SCREEN_LOADER,
        payload: { show: false }
      })
    }
  }
}

export const updateeligibilitymember = (eligibilityMemberInputParam) => {
    return async (dispatch) => {
        dispatch({
          type: SCREEN_LOADER,
          payload: { show: true }
        })
        try {
          const result = await EligibilityMemberService.updateeligibiltiymember(eligibilityMemberInputParam)// await EligibilityMemberService.updateeligibilitymember(eligibilityMemberInputParam)

          if (result.result) {
            window.alert('Submission is success')
          }
      } catch (e) {
          if (e.status === 500) {
            window.alert('ERROR: Internal Server or Application(Eligibility member update API Endpoint) Error. Please contact the Integration team.')
            browserHistory.push('/eligibility')
          } else if (e.status === 502) {
            window.alert('ERROR: Server(Bad Gateway) Error. Please contact the Integration team.')
            browserHistory.push('/eligibility')
          } else {
            window.alert('ERROR: Application(Eligibility member update API Endpoint) Error. Please contact the Integration team.')
            browserHistory.push('/error/')
          }
        } finally {
          dispatch({
            type: SCREEN_LOADER,
            payload: { show: false }
          })
      }
     }
}
