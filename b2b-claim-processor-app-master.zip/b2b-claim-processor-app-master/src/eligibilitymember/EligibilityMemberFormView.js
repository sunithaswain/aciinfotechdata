import React from 'react'
import PropTypes from 'prop-types'

class EligibilityMemberForm extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      coveragestatus : '',
      coverageeffectivedate : '',
      coverageterminationdate : '',
      cobraeffectivedate : '',
      cobraterminationdate : '',
      membertype : 'Primary',
      planyear : ''
    }
    this.handleInputChange = this.handleInputChange.bind(this)
    this.eligibilitymemberSubmit = this.eligibilitymemberSubmit.bind(this)
  }
  componentDidMount () {

  }

  componentWillUpdate () {

  }

  handleInputChange (event) {
    const target = event.target
    const value = target.value
    const name = target.name

    this.setState({
      [name]: value
    })
  }

  eligibilitymemberSubmit () {
    const eligibilityMemberInputParam = {
      'workmail': this.props.eligibilitymemberdata.email,
      'personcode': this.props.eligibilitymemberdata.personcode,
      'relationshipcode': this.props.eligibilitymemberdata.relationshipcode,
      'coveragestatus': this.state.coveragestatus,
      'coverageeffectivedate': this.state.coverageeffectivedate,
      'coverageterminationdate': this.state.coverageterminationdate,
      'cobraeffectivedate': this.state.cobraeffectivedate,
      'cobraterminationdate': this.state.cobraterminationdate
    }

    this.props.updateeligibilitymember(eligibilityMemberInputParam)
  }

  render () {
    const templates = ['2018', '2019', '2020']
    return (
      <div name='overrideform'>
        <div className='row'>
          <div className='small-2 columns labelstrong'>Carrier ID:</div>
          <div className='small-2 columns'>
            {this.props.eligibilitymemberdata.carrierid}
          </div>
          <div className='small-2 columns labelstrong'>Carrier Name:</div>
          <div className='small-2 columns'>
            {this.props.eligibilitymemberdata.carriername}
          </div>
          <div className='small-4 columns' />

        </div>
        <div className='row'>
          <div className='small-2 columns labelstrong'>Account ID:</div>
          <div className='small-2 columns'>
            {this.props.eligibilitymemberdata.accountid}
          </div>
          <div className='small-2 columns labelstrong'>Account Name:</div>
          <div className='small-2 columns'>
            {this.props.eligibilitymemberdata.accountname}
          </div>
          <div className='small-4 columns' />

        </div>
        <div className='row'>
          <div className='small-2 columns labelstrong'>Group ID:</div>
          <div className='small-2 columns'>
            {this.props.eligibilitymemberdata.groupid}
          </div>
          <div className='small-2 columns labelstrong'>Group Name:</div>
          <div className='small-2 columns'>
            {this.props.eligibilitymemberdata.groupname}
          </div>
          <div className='small-4 columns' />

        </div>
        <div className='row'>
          <div className='small-2 columns labelstrong'>Member ID:</div>
          <div className='small-2 columns'>
            {this.props.eligibilitymemberdata.memberid}
          </div>
          <div className='small-2 columns' />
          <div className='small-2 columns'>
            &nbsp;
          </div>
          <div className='small-4 columns' />
        </div>

        <div className='row'>

          <div className='small-2 columns labelstrong'>First Name:</div>
          <div className='small-2 columns'>
            {this.props.eligibilitymemberdata.firstname}
          </div>
          <div className='small-2 columns labelstrong'>Last Name:</div>
          <div className='small-2 columns'>
            {this.props.eligibilitymemberdata.lastname}
          </div>
          <div className='small-2 columns labelstrong'>MI:</div>
          <div className='small-2 columns'>
            {this.props.eligibilitymemberdata.middlename}
          </div>

        </div>
        <div className='row'>

          <div className='small-2 columns labelstrong'>Person Code:</div>
          <div className='small-2 columns'>
            {this.props.eligibilitymemberdata.personcode}
          </div>
          <div className='small-2 columns labelstrong'>Relationship Code:</div>
          <div className='small-2 columns'>
            {this.props.eligibilitymemberdata.relationshipcode}
          </div>
          <div className='small-4 columns' />

        </div>
        <div className='row'>
          <div className='small-2 columns labelstrong'>Gender:</div>
          <div className='small-2 columns'>
            {this.props.eligibilitymemberdata.gender}
          </div>
          <div className='small-2 columns labelstrong'>DOB:</div>
          <div className='small-2 columns'>
            {this.props.eligibilitymemberdata.dob}
          </div>
          <div className='small-4 columns' />

        </div>
        <div className='row'>

          <div className='small-2 columns labelstrong'>Address:</div>
          <div className='small-2 columns'>
            {this.props.eligibilitymemberdata.address}
          </div>
          <div className='small-2 columns labelstrong'>City:</div>
          <div className='small-2 columns'>
            {this.props.eligibilitymemberdata.city}
          </div>
          <div className='small-4 columns' />

        </div>
        <div className='row'>
          <div className='small-2 columns labelstrong'>State:</div>
          <div className='small-2 columns'>
            {this.props.eligibilitymemberdata.state}
          </div>
          <div className='small-2 columns labelstrong'>ZIP:</div>
          <div className='small-2 columns'>
            {this.props.eligibilitymemberdata.zip}
          </div>
          <div className='small-4 columns' />

        </div>
        <div className='row'>
          <div className='small-2 columns labelstrong'>Phone:</div>
          <div className='small-2 columns'>
            {this.props.eligibilitymemberdata.phone}&nbsp;
          </div>
          <div className='small-2 columns labelstrong'>Email:</div>
          <div className='small-2 columns'>
            {this.props.eligibilitymemberdata.email}
          </div>
          <div className='small-4 columns' />

        </div>
        <div className='row'>

          <div className='small-2 columns labelstrong'>Plan override:</div>
          <div className='small-2 columns'>
            &nbsp;{this.props.eligibilitymemberdata.planoverride}
          </div>
          <div className='small-2 columns labelstrong'>Member Type</div>
          <div className='small-2 columns'>
            <select name='membertype' onChange={this.handleInputChange} value={this.state.membertype}>
              <option value='Primary'>Primary</option>
              <option value='Dependent' >Dependent</option>
            </select>
          </div>
          <div className='small-4 columns' />
          <div className='small-2 columns labelstrong' />
          <div className='small-2 columns' />

        </div>
        <div className='row'>

          <div className='small-2 columns labelstrong'>From Date:</div>
          <div className='small-2 columns'>
            <input type='date' name='coverageeffectivedate' value={this.state.coverageeffectivedate} onChange={this.handleInputChange} />
          </div>
          <div className='small-2 columns labelstrong'>Through Date:</div>
          <div className='small-2 columns'>
            <input type='date' name='coverageterminationdate' value={this.state.coverageterminationdate} onChange={this.handleInputChange} />
          </div>
          <div className='small-4 columns' />
          <div className='small-2 columns labelstrong' />
          <div className='small-2 columns' />

        </div>
        <div className='row'>
          <div className='small-2 columns labelstrong'>Coverage Status:</div>
          <div className={this.state.membertype === 'Primary' ? 'small-2 columns' : 'hidden'}>

            <select name='coveragestatus' onChange={this.handleInputChange} value={this.state.coveragestatus}>
              <option value='Active'>Active</option>
              <option value='Terminated' >Terminated</option>
              <option value='COBRA' >COBRA</option>
            </select>

          </div>
          <div className='small-2 columns labelstrong hidden'>Plan Year</div>
          <div className='small-2 columns hidden'>
            <select name='planyear' onChange={this.handleInputChange} value={this.state.planyear}>
              {
                templates.map(msgTemplate => {
                  return (
                    <option key={msgTemplate} value={msgTemplate}>
                      {msgTemplate}
                    </option>
                  )
                })
              }
            </select>
          </div>
          <div className='small-4 columns' />

        </div>
        <div className='row'>

          <div className='small-2 columns labelstrong'>COBRA From Date:</div>
          <div className='small-2 columns'>
            <input type='date' name='cobraeffectivedate' value={this.state.cobraeffectivedate} onChange={this.handleInputChange} />
          </div>
          <div className='small-2 columns labelstrong'>COBRA Through Date:</div>
          <div className='small-2 columns'>
            <input type='date' name='cobraterminationdate' value={this.state.cobraterminationdate} onChange={this.handleInputChange} />
          </div>
          <div className='small-4 columns' />
          <div className='small-2 columns labelstrong' />
          <div className='small-2 columns' />

        </div>
        <div className='row'>
          <div className='small-6 columns text-right'>
            <button className='button claimoverridebtn' type='button' onClick={this.eligibilitymemberSubmit}>Update</button>
          </div>
          <div className='small-6 columns text-left' />

        </div>
      </div>
    )
  }
}
EligibilityMemberForm.propTypes = {
  eligibilitymemberdata : PropTypes.object,
  updateeligibilitymember : PropTypes.func
}
export default EligibilityMemberForm
