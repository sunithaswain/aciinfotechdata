import api from 'utils/api'
import Common from 'common/services/Common'

class MemberService {
    async getmember (memberid, personcode) {
        const qryparams = '?memberid=' + memberid + '&personcode=' + personcode
        const data = await api.getmember(
          {
              customToken: { value: Common.getJwtToken() },
              tokenType: 'Bearer'
          }, qryparams)

      return data
    }
}
export default new MemberService()
