import React from 'react'
import PropTypes from 'prop-types'

import MemberForm from 'member/MemberFormView'

class MemberView extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      readMode:true
    }
  }
  componentDidMount () {
    this.props.getmember(this.props.selectedAuthID, this.props.sequenceNumber)
  }
  componentWillUpdate () {}

  render () {
    let memberdata = {}
    if (this.props.member) {
      memberdata = this.props.member

      memberdata['readMode'] = true
    }

    return (

      <div className='grid-container full' >

        <div className='row'>
          <h3 className='small-12 columns'>Member Details</h3>
        </div>
        <MemberForm memberdata={memberdata} />

      </div>
    )
  }
}
MemberView.propTypes = {
  getmember : PropTypes.func,
  member : PropTypes.object,
  selectedAuthID : PropTypes.string,
  sequenceNumber : PropTypes.string
}
export default MemberView
