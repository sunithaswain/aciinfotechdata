import getSavedState from 'utils/getSavedState'
import { MEMBER_CLAIMS_SUCCESS } from 'common/constants/ActionConstants'
const INITIAL_STATE = getSavedState('CPA.searchDetails', {})

export default function member (state = INITIAL_STATE, action) {
  switch (action.type) {
    case MEMBER_CLAIMS_SUCCESS:
        return action.payload
    default:
      return state
  }
}
