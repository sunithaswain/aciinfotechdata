import { browserHistory } from 'react-router'
import { MEMBER_CLAIMS_SUCCESS } from 'common/constants/ActionConstants'
import createAction from 'utils/createAction'
import MemberService from 'member/MemberService'

const memberClaimsSuccessAction = createAction(MEMBER_CLAIMS_SUCCESS)
const SCREEN_LOADER = '@SCREEN_LOADER@'

export const getmember = (memberid, personcode) => {
  return async (dispatch) => {
    dispatch({
      type: SCREEN_LOADER,
      payload: { show: true }
    })
    dispatch(memberClaimsSuccessAction({}))
    try {
        const result = await MemberService.getmember(memberid, personcode)
        if (result) {
          dispatch(memberClaimsSuccessAction(result))
        }
    } catch (e) {
        if (e.status === 500) {
          window.alert('ERROR: Internal Server or Application(Claim Member API Endpoint) Error. Please contact the Integration team.')
          browserHistory.push('/')
        } else if (e.status === 502) {
          window.alert('ERROR: Server(Bad Gateway) Error. Please contact the Integration team.')
          browserHistory.push('/')
        } else {
          window.alert('ERROR: Application(Claim member API Endpoint) Error. Please contact the Integration team.')
          browserHistory.push('/error/')
        }
    } finally {
      dispatch({
        type: SCREEN_LOADER,
        payload: { show: false }
      })
    }
  }
}
