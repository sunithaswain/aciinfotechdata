import React from 'react'
import PropTypes from 'prop-types'

class MemberForm extends React.Component {
  constructor (props) {
    super(props)
    this.state = {

    }
  }
  componentDidMount () {

  }

  componentWillUpdate () {

  }
  render () {
    return (
      <div name='overrideform'>
        <div className='row'>
          <div className='small-2 columns labelstrong'>Carrier ID:</div>
          <div className='small-2 columns'>
            &nbsp;{this.props.memberdata.carrierid}
          </div>
          <div className='small-2 columns labelstrong'>Carrier Name:</div>
          <div className='small-2 columns'>
            {this.props.memberdata.carriername}
          </div>
          <div className='small-4 columns' />

        </div>
        <div className='row'>
          <div className='small-2 columns labelstrong'>Account ID:</div>
          <div className='small-2 columns'>
            &nbsp;{this.props.memberdata.accountid}
          </div>
          <div className='small-2 columns labelstrong'>Account Name:</div>
          <div className='small-2 columns'>
            {this.props.memberdata.accountname}
          </div>
          <div className='small-4 columns' />

        </div>
        <div className='row'>
          <div className='small-2 columns labelstrong'>Group ID:</div>
          <div className='small-2 columns'>
            &nbsp;{this.props.memberdata.groupid}
          </div>
          <div className='small-2 columns labelstrong'>Group Name:</div>
          <div className='small-2 columns'>
            {this.props.memberdata.groupname}
          </div>
          <div className='small-4 columns' />

        </div>
        <div className='row'>
          <div className='small-2 columns labelstrong'>Member ID:</div>
          <div className='small-2 columns'>
            &nbsp;{this.props.memberdata.memberid}
          </div>
          <div className='small-2 columns' />
          <div className='small-2 columns'>
            &nbsp;
          </div>
          <div className='small-4 columns' />
        </div>
        <div className='row'>
          <div className='small-2 columns labelstrong'>From Date:</div>
          <div className='small-2 columns'>
            &nbsp;{this.props.memberdata.coveragefromdate}
          </div>
          <div className='small-2 columns labelstrong'>To Date:</div>
          <div className='small-2 columns'>
            {this.props.memberdata.coveragetodate}
          </div>
          <div className='small-4 columns' />

        </div>

        <div className='row'>

          <div className='small-2 columns labelstrong'>First Name:</div>
          <div className='small-2 columns'>
            &nbsp;{this.props.memberdata.firstname}
          </div>
          <div className='small-2 columns labelstrong'>Last Name:</div>
          <div className='small-2 columns'>
            &nbsp;{this.props.memberdata.lastname}
          </div>
          <div className='small-2 columns labelstrong'>MI:</div>
          <div className='small-2 columns'>
            {this.props.memberdata.middlename}
          </div>

        </div>
        <div className='row'>

          <div className='small-2 columns labelstrong'>Person Code:</div>
          <div className='small-2 columns'>
            &nbsp;{this.props.memberdata.personcode}
          </div>
          <div className='small-2 columns labelstrong'>Relationship Code:</div>
          <div className='small-2 columns'>
            {this.props.memberdata.relationshipcode}
          </div>
          <div className='small-4 columns' />

        </div>
        <div className='row'>
          <div className='small-2 columns labelstrong'>Gender:</div>
          <div className='small-2 columns'>
            &nbsp;{this.props.memberdata.gender}
          </div>
          <div className='small-2 columns labelstrong'>DOB:</div>
          <div className='small-2 columns'>
            {this.props.memberdata.dob}
          </div>
          <div className='small-4 columns' />

        </div>
        <div className='row'>

          <div className='small-2 columns labelstrong'>Address:</div>
          <div className='small-2 columns'>
            &nbsp;{this.props.memberdata.address}
          </div>
          <div className='small-2 columns labelstrong'>City:</div>
          <div className='small-2 columns'>
            {this.props.memberdata.city}
          </div>
          <div className='small-4 columns' />

        </div>
        <div className='row'>
          <div className='small-2 columns labelstrong'>State:</div>
          <div className='small-2 columns'>
            &nbsp;{this.props.memberdata.state}
          </div>
          <div className='small-2 columns labelstrong'>ZIP:</div>
          <div className='small-2 columns'>
            {this.props.memberdata.zip}
          </div>
          <div className='small-4 columns' />

        </div>
        <div className='row'>
          <div className='small-2 columns labelstrong'>Phone:</div>
          <div className='small-2 columns'>
            &nbsp;{this.props.memberdata.phone}&nbsp;
          </div>
          <div className='small-2 columns labelstrong'>Email:</div>
          <div className='small-2 columns'>
            {this.props.memberdata.email}
          </div>
          <div className='small-4 columns' />

        </div>
        <div className='row'>

          <div className='small-2 columns labelstrong'>Plan override:</div>
          <div className='small-2 columns'>
            &nbsp;{this.props.memberdata.planoverride}
          </div>
          <div className='small-2 columns labelstrong'>From Date:</div>
          <div className='small-2 columns'>
            &nbsp;{this.props.memberdata.fromdate}
          </div>

          <div className='small-2 columns labelstrong'>Through Date:</div>
          <div className='small-2 columns'>
            {this.props.memberdata.throughdate}
          </div>

        </div>
        <div className='text-center' />
      </div>
    )
  }
}
MemberForm.propTypes = {
  memberdata : PropTypes.object
}
export default MemberForm
