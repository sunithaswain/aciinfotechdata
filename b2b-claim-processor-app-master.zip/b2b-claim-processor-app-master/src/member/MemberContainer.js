import { connect } from 'react-redux'
import MemberView from 'member/MemberView'
import { bindActionCreators } from 'redux'
import { getmember } from 'member/MemberActions'

const mapDispatchToProps = (dispatch) => {
  return {
    getmember:bindActionCreators(getmember, dispatch)
  }
}
const mapStateToProps = (state) => {
  return state
}
export default connect(mapStateToProps, mapDispatchToProps)(MemberView)
