import React from 'react'
import PropTypes from 'prop-types'

import OverrideHeader from 'override/OverrideHeaderView'
import OverrideSubmission from 'override/OverrideSubmissionView'

class OverrideView extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      readMode:true,
      errors: []
    }
    this.changeMode = this.changeMode.bind(this)
    this.updateOverride = this.updateOverride.bind(this)
    this.updateErrorMsg = this.updateErrorMsg.bind(this)
  }
  componentDidMount () {
    this.props.getoverride(this.props.selectedAuthID, this.props.sequenceNumber)
  }
  componentWillUpdate () {}
  changeMode (docmode) {
    this.setState({ readMode: docmode })
  }
  updateErrorMsg (errors) {
    this.setState({ errors })
  }

  updateOverride (overrideInputParam) {
    this.props.updateoverride(overrideInputParam)
  }

  render () {
    const { errors } = this.state
    let overridedata = {}

    if (this.props.override) {
      overridedata = this.props.override

      overridedata['readMode'] = !!(this.state.readMode && overridedata['over_ride'] === 'Y')
    }

    return (

      <div className='grid-container full' >
        <div className={errors.length > 0 ? 'row isa_error' : 'row'}>
          {errors.map(error => (
            <p key={error}>Error: {error}</p>
        ))}
        </div>
        <div className='row'>
          <h3 className='small-12 columns'>Override Details</h3>
        </div>

        <OverrideHeader overridedata={overridedata} />
        <OverrideSubmission selectedAuthID={this.props.selectedAuthID} sequenceNumber={this.props.sequenceNumber} updateOverride={this.updateOverride}
          changeMode={this.changeMode} overridedata={overridedata} updateErrorMsg={this.updateErrorMsg} />

      </div>
    )
  }
}
OverrideView.propTypes = {
  getoverride : PropTypes.func,
  updateoverride : PropTypes.func,
  override : PropTypes.object,
  selectedAuthID : PropTypes.string,
  sequenceNumber : PropTypes.string
}
export default OverrideView
