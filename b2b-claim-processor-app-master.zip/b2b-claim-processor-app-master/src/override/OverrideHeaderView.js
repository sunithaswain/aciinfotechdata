import React from 'react'
import PropTypes from 'prop-types'

class OverrideHeader extends React.Component {
  constructor (props) {
    super(props)
    this.state = {

    }
  }
  componentDidMount () {

  }

  componentWillUpdate () {

  }

  render () {
    return (

      <div name='overrideheader' className='overrideheader'>
        <div className='row'>

          <div className='small-4 columns overrideheadercontent'>
            <div className='small-6 columns'>Group Member</div>
            <div className='small-6 columns'>{this.props.overridedata.groupname}</div>
          </div>

          <div className='small-4 columns overrideheadercontent'>
            <div className='small-6 columns'>Member ID</div>
            <div className='small-6 columns'>{this.props.overridedata.memberid}</div>
          </div>
          <div className='small-4 columns' />

        </div>
        <div className='row'>

          <div className='small-4 columns overrideheadercontent'>
            <div className='small-6 columns'>Last Name</div>
            <div className='small-6 columns'>{this.props.overridedata.lastname}</div>
          </div>

          <div className='small-4 columns overrideheadercontent'>
            <div className='small-6 columns'>First Name</div>
            <div className='small-6 columns'>{this.props.overridedata.firstname}</div>
          </div>
          <div className='small-4 columns' />

        </div>
        <div className='row'>

          <div className='small-4 columns overrideheadercontent'>
            <div className='small-6 columns'>Person Code</div>
            <div className='small-6 columns'>{this.props.overridedata.personcode}</div>
          </div>

          <div className='small-4 columns overrideheadercontent'>
            <div className='small-6 columns'>Rel Code</div>
            <div className='small-6 columns'>{this.props.overridedata.relationshipcode}</div>
          </div>
          <div className='small-4 columns' />

        </div>
        <div className='row'>
          <div className='small-4 columns overrideheadercontent'>
            <div className='small-6 columns'>Product Name</div>
            <div className='small-6 columns'>{this.props.overridedata.productname}</div>
          </div>

          <div className='small-4 columns overrideheadercontent'>
            <div className='small-6 columns'>Product ID</div>
            <div className='small-6 columns'>{this.props.overridedata.product_id}</div>
          </div>
          <div className='small-4 columns' />

        </div>
        <div className='row'>

          <div className='small-4 columns overrideheadercontent'>
            <div className='small-6 columns'>GPI Code</div>
            <div className='small-6 columns'>{this.props.overridedata.gpicode}</div>
          </div>

          <div className='small-4 columns overrideheadercontent'>
            <div className='small-6 columns'>Authorization Number</div>
            <div className='small-6 columns'>{this.props.overridedata.authid}</div>
          </div>
          <div className='small-4 columns' />

        </div>
      </div>

    )
  }
}
OverrideHeader.propTypes = {
  overridedata : PropTypes.object
}
export default OverrideHeader
