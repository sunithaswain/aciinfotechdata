import React from 'react'
import PropTypes from 'prop-types'

class OverrideSubmission extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      overridenumber:'',
      overridefrom:'',
      overridethru:'',
      overrideamount:'',
      overridepercentage:'',
      copay_override:'N'

    }
    this.changeModeChild = this.changeModeChild.bind(this)
    this.overrideSubmit = this.overrideSubmit.bind(this)
    this.handleInputChange = this.handleInputChange.bind(this)
    this.overrideCancel = this.overrideCancel.bind(this)
  }
  componentDidMount () {

  }

  componentWillUpdate () {

  }

  validateOverrideForm () {
    const errors = []
    if (this.state.overridefrom === '') {
      errors.push('Override From field should not be empty.')
    }
    if (this.state.overridethru === '') {
      errors.push('Override Thru field should not be empty.')
    }
    if (this.state.overridenumber === '') {
      errors.push('Override Number field should not be empty.')
    }

    if (this.state.overridefrom !== '') {
      var fdate = new Date(this.state.overridefrom)
      var curdate = new Date()
      var prevdate = curdate.getDate() - 5
      curdate.setDate(prevdate)
      fdate.setHours(0, 0, 0, 0)
      curdate.setHours(0, 0, 0, 0)
      if (fdate.getTime() < curdate.getTime()) {
        errors.push('Override From should not be less than (current date - 5 Days)')
      }
    }

    if (this.state.overridefrom !== '' && this.state.overridethru !== '') {
      var sdate = new Date(this.state.overridefrom)
      var edate = new Date(this.state.overridethru)
      sdate.setHours(0, 0, 0, 0)
      edate.setHours(0, 0, 0, 0)
      if (sdate.getTime() >= edate.getTime()) {
        errors.push('Override Thru should be greater than Override From')
      }
    }
    return errors
  }

  handleInputChange (event) {
    const target = event.target
    const value = target.value
    const name = target.name

    this.setState({
      [name]: value
    })
  }

  overrideSubmit () {
    const errors = this.validateOverrideForm()
    this.props.updateErrorMsg(errors)
    if (errors.length > 0) {
      return
    }

    let serviceproviderid = this.props.overridedata.service_provider_id
    let productid = this.props.overridedata.product_id
    let cardholderid = this.props.overridedata.cardholder_id
    let lastname = this.props.overridedata.cardholder_last_name ? this.props.overridedata.cardholder_last_name : ''
    let dateofbirth = this.props.overridedata.date_of_birth
    let dateofservice = this.props.overridedata.date_of_service
    let prescriptionid = this.props.overridedata.prescription_id
    let overridefrom = this.state.overridefrom
    var sdate = new Date(this.state.overridefrom)
    sdate.setHours(0, 0, 0, 0)
    const syear = sdate.getFullYear().toString()
    const smonth = sdate.getMonth() + 1 < 10 ? '0' + (sdate.getMonth() + 1).toString() : (sdate.getMonth() + 1).toString()
    const sday = sdate.getDate() < 10 ? '0' + (sdate.getDate()).toString() : sdate.getDate().toString()
    overridefrom = syear + '-' + smonth + '-' + sday
    let overridethru = this.state.overridethru
    var edate = new Date(this.state.overridethru)
    edate.setHours(0, 0, 0, 0)
    const eyear = edate.getFullYear().toString()
    const emonth = edate.getMonth() + 1 < 10 ? '0' + (edate.getMonth() + 1).toString() : (edate.getMonth() + 1).toString()
    const eday = edate.getDate() < 10 ? '0' + (edate.getDate()).toString() : edate.getDate().toString()
    overridethru = eyear + '-' + emonth + '-' + eday
    let overrideamount = this.state.overrideamount
    let overridepercentage = this.state.overridepercentage
    if (this.state.copay_override === 'N') {
      overrideamount = ''
      overridepercentage = ''
    }

    const overrideInputParam = {
      'authid': this.props.selectedAuthID,
      'sequencenumber': parseInt(this.props.sequenceNumber),
      'copay_override': this.state.copay_override,
      'override_amount': overrideamount,
      'override_percentage': overridepercentage,
      'overridenumber': this.state.overridenumber,
      'overridefrom': overridefrom,
      'overridethru': overridethru,
      'service_provider_id': serviceproviderid,
      'product_id': productid,
      'cardholder_id': cardholderid,
      'last_name': lastname,
      'date_of_birth': dateofbirth,
      'dateofservice': dateofservice,
      'prescriptionid': prescriptionid
    }

    this.props.updateOverride(overrideInputParam)
  }

  changeModeChild (event) {
    this.props.changeMode(false)
    this.setState({ overridenumber:this.props.overridedata.overridenumber })
    this.setState({ copay_override:this.props.overridedata.copay_override })
    this.setState({ overrideamount:this.props.overridedata.override_amount })
    this.setState({ overridepercentage:this.props.overridedata.override_percentage })
    this.setState({ overridefrom:this.props.overridedata.override_from })
    this.setState({ overridethru:this.props.overridedata.override_thru })
  }

  overrideCancel () {
    this.props.changeMode(true)
  }

  render () {
    if (this.props.overridedata.readMode) {
      return (
        <div name='overrideform'>
          <div className='row'>
            <div className='small-2 columns'>Number</div>
            <div className='small-2 columns'>
              {this.props.overridedata.overridenumber}
            </div>
            <div className='small-8 columns' />
          </div>
          <div className='row'>
            <div className='small-2 columns'>From</div>
            <div className='small-2 columns'>
              {this.props.overridedata.override_from}
            </div>
            <div className='small-2 columns'>Thru</div>
            <div className='small-2 columns'>
              {this.props.overridedata.override_thru}
            </div>
            <div className='small-4 columns' />
          </div>
          <div className='row'>
            <div className='small-2 columns'>Copay Override?</div>
            <div className='small-2 columns'>
              {this.props.overridedata.copay_override}
            </div>
            <div className='small-8 columns' />

          </div>
          <div className={this.props.overridedata.copay_override === 'Y' ? 'row' : 'hidden'}>

            <div className='small-2 columns'>Amount</div>
            <div className='small-2 columns'>
              {this.props.overridedata.override_amount}
            </div>
            <div className='small-2 columns'>Or Percentage</div>
            <div className='small-2 columns'>
              {this.props.overridedata.override_percentage}
            </div>
            <div className='small-4 columns' />

          </div>
          <div className='text-center'>
            <button className='button claimoverridebtn' type='button' onClick={(event) => this.changeModeChild(event)}>Edit</button>
          </div>
        </div>

      )
    }

    return (

      <div name='overrideform'>
        <div className='row'>
          <div className='small-2 columns'>Number</div>
          <div className='small-2 columns'>
            <input type='text' name='overridenumber' value={this.state.overridenumber} onChange={this.handleInputChange} />
          </div>
          <div className='small-8 columns' />
        </div>
        <div className='row'>
          <div className='small-2 columns'>From</div>
          <div className='small-2 columns'>
            <input type='date' required name='overridefrom' value={this.state.overridefrom} onChange={this.handleInputChange} />
          </div>
          <div className='small-2 columns'>Thru</div>
          <div className='small-2 columns'>
            <input type='date' required name='overridethru' value={this.state.overridethru} onChange={this.handleInputChange} />
          </div>
          <div className='small-4 columns' />
        </div>
        <div className='row'>
          <div className='small-2 columns'>Copay Override?</div>
          <div className='small-2 columns'>
            <select name='copay_override' onChange={this.handleInputChange} value={this.state.copay_override}>
              <option value='N'>No</option>
              <option value='Y' >Yes</option>
            </select>
          </div>
          <div className='small-8 columns' />

        </div>
        <div className={this.state.copay_override === 'Y' ? 'row' : 'hidden'}>

          <div className='small-2 columns'>Amount</div>
          <div className='small-2 columns'>
            <input type='text' name='overrideamount' placeholder='' value={this.state.overrideamount} onChange={this.handleInputChange} />
          </div>
          <div className='small-2 columns'>Or Percentage</div>
          <div className='small-2 columns'>
            <input type='text' name='overridepercentage' placeholder='' value={this.state.overridepercentage} onChange={this.handleInputChange} />
          </div>
          <div className='small-4 columns' />

        </div>
        <div className='row'>
          <div className='small-6 columns text-right'><button className='button claimoverridebtn' type='button' onClick={this.overrideCancel}>Cancel</button></div>
          <div className='small-6 columns text-left'><button className='button claimoverridebtn small-2 columns' type='button' onClick={this.overrideSubmit}>Submit</button></div>
        </div>
      </div>

    )
  }
}
OverrideSubmission.propTypes = {
  overridedata : PropTypes.object,
  updateOverride : PropTypes.func,
  changeMode : PropTypes.func,
  updateErrorMsg : PropTypes.func,
  selectedAuthID : PropTypes.string,
  sequenceNumber : PropTypes.string
}
export default OverrideSubmission
