import { OVERRIDE_CLAIMS_SUCCESS } from 'common/constants/ActionConstants'
import createAction from 'utils/createAction'
import OverrideService from 'override/OverrideService'
import { browserHistory } from 'react-router'

const overrideClaimsSuccessAction = createAction(OVERRIDE_CLAIMS_SUCCESS)
const SCREEN_LOADER = '@SCREEN_LOADER@'

export const getoverride = (authid, sequencenumber) => {
    return async (dispatch) => {
      dispatch({
        type: SCREEN_LOADER,
        payload: { show: true }
      })
      try {
          const result = await OverrideService.getoverride(authid, sequencenumber)
          if (result.authid) {
            dispatch(overrideClaimsSuccessAction(result))
          }
      } catch (e) {
          if (e.status === 500) {
            window.alert('ERROR: Internal Server or Application(Override API Endpoint) Error. Please contact the Integration team.')
            browserHistory.push('/')
          } else if (e.status === 502) {
            window.alert('ERROR: Server(Bad Gateway) Error. Please contact the Integration team.')
            browserHistory.push('/')
          } else {
            window.alert('ERROR: Application(Override API Endpoint) Error. Please contact the Integration team.')
            browserHistory.push('/error/')
          }
        } finally {
          dispatch({
            type: SCREEN_LOADER,
            payload: { show: false }
          })
      }
     }
}

export const updateoverride = (overrideInputParam) => {
    return async (dispatch) => {
        dispatch({
          type: SCREEN_LOADER,
          payload: { show: true }
        })
        try {
          const result = await OverrideService.updateoverride(overrideInputParam)

          if (result.result) {
            window.alert('Submission is success')
          } else {
            window.alert('Submission is failure')
          }
      } catch (e) {
          if (e.status === 500) {
            window.alert('ERROR: Internal Server or Application(Override update API Endpoint) Error. Please contact the Integration team.')
            browserHistory.push('/')
          } else if (e.status === 502) {
            window.alert('ERROR: Server(Bad Gateway) Error. Please contact the Integration team.')
            browserHistory.push('/')
          } else {
            window.alert('ERROR: Application(Override API Endpoint) Error. Please contact the Integration team.')
            browserHistory.push('/error/')
          }
        } finally {
          dispatch({
            type: SCREEN_LOADER,
            payload: { show: false }
          })
      }
     }
}
