import { connect } from 'react-redux'
import OverrideView from 'override/OverrideView'
import { bindActionCreators } from 'redux'
import { getoverride, updateoverride } from 'override/OverrideActions'

const mapDispatchToProps = (dispatch) => {
  return {
    getoverride:bindActionCreators(getoverride, dispatch),
    updateoverride:bindActionCreators(updateoverride, dispatch)
  }
}
const mapStateToProps = (state) => {
  return state
}
export default connect(mapStateToProps, mapDispatchToProps)(OverrideView)
