import api from 'utils/api'
import Common from 'common/services/Common'

class OverrideService {
    async getoverride (authid, sequencenumber) {
        var overwords = sequencenumber.split('|')
        const qryparams = '?authid=' + authid + '&sequencenumber=' + parseInt(overwords[0]) + '&productname=' + overwords[1]
        const data = await api.getclaimoverride(
          {
              customToken: { value: Common.getJwtToken() },
              tokenType: 'Bearer'
          }, qryparams)

      return data
    }

    async updateoverride (overrideInputParam) {
        const body = overrideInputParam

        const data = await api.updateclaimoverride(
          {
              body: JSON.stringify(body),
              customToken: { value: Common.getJwtToken() },
              tokenType: 'Bearer'
          })

      return data
    }
}
export default new OverrideService()
