import api from 'utils/api'
import Common from 'common/services/Common'

class EligibilitySearchService {
  async search (svalue) {
    const qryparams = '?searchvalue=' + svalue
    const data = await api.searchEligibility(
            {
                  customToken: { value: Common.getJwtToken() },
                  tokenType: 'Bearer'
            }, qryparams)
    return data
  }
}
export default new EligibilitySearchService()
