import EligibilitySearchService from 'eligibilitysearch/EligibilitySearchService'
import { browserHistory } from 'react-router'
import { SEARCH_ELIGIBILITY_SUCCESS } from 'common/constants/ActionConstants'
import createAction from 'utils/createAction'

const searchEligibilitySuccessAction = createAction(SEARCH_ELIGIBILITY_SUCCESS)
const SCREEN_LOADER = '@SCREEN_LOADER@'

export const eligibilitysearch = (memberid) => {
   return async (dispatch) => {
    dispatch({
      type: SCREEN_LOADER,
      payload: { show: true }
    })
    try {
        const result = await EligibilitySearchService.search(memberid)

        if (result) {
          dispatch(searchEligibilitySuccessAction(result.result))
        }
    } catch (e) {
        if (e.status === 500) {
          window.alert('ERROR: Internal Server or Application(Eligibility member API Endpoint) Error. Please contact the Integration team.')
          browserHistory.push('/eligibility')
        } else if (e.status === 502) {
          window.alert('ERROR: Server(Bad Gateway) Error. Please contact the Integration team.')
          browserHistory.push('/eligibility')
        } else {
          window.alert('ERROR: Application(Eligibility member API Endpoint) Error. Please contact the Integration team.')
          browserHistory.push('/error/')
        }
      } finally {
        dispatch({
          type: SCREEN_LOADER,
          payload: { show: false }
        })
    }
   }
}
