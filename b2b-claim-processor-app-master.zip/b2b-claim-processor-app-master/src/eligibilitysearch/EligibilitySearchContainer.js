import { connect } from 'react-redux'
import EligibilitySearchView from 'eligibilitysearch/EligibilitySearchView'
import { bindActionCreators } from 'redux'
import { eligibilitysearch } from 'eligibilitysearch/EligibilitySearchActions'
import { get } from 'lodash'

const mapDispatchToProps = (dispatch) => {
  return {
        search:bindActionCreators(eligibilitysearch, dispatch)
  }
}
const mapStateToProps = (state) => {
  return {
    searchDetails: [get(state, 'search')]
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(EligibilitySearchView)
