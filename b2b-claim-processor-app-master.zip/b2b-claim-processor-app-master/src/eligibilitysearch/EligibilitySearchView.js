import React from 'react'
import PropTypes from 'prop-types'

class EligibilitySearchView extends React.Component {
 constructor (props) {
    super(props)
    this.state = {
      memberid:undefined
    }
    this.handleInputChange = this.handleInputChange.bind(this)
   }

  componentDidMount () {

  }

  handleClick (event) {
      this.props.search(this.state.memberid)
  }

  handleInputChange (event) {
    const target = event.target
    const value = target.value
    const name = target.name

    this.setState({
      [name]: value
    })
  }
  render () {
      return (

        <div className='grid-x grid-padding-x'>
          <div className='medium-2 cell' />
          <div className='medium-4 cell'>
            <label>Member ID / Last Name
              <input type='text' name='memberid' placeholder='Member ID / Last Name' value={this.state.memberid} onChange={this.handleInputChange} />
            </label>
          </div>

          <div className='medium-2 cell' />
          <div className='medium-4 cell'>

            <button className='button claimsearchbtn' type='button' onClick={(event) => this.handleClick(event)} >Search</button>

          </div>

        </div>

      )
  }
}
EligibilitySearchView.propTypes = {
  search:PropTypes.func
}
export default EligibilitySearchView
