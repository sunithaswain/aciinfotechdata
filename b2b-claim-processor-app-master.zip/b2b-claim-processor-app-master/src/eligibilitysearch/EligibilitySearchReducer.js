import getSavedState from 'utils/getSavedState'
import { SEARCH_ELIGIBILITY_SUCCESS } from 'common/constants/ActionConstants'
const INITIAL_STATE = getSavedState('CPA.searchDetails', {})

export default function eligibilitysearch (state = INITIAL_STATE, action) {
  switch (action.type) {
    case SEARCH_ELIGIBILITY_SUCCESS:
        return action.payload
    default:
      return state
  }
}
