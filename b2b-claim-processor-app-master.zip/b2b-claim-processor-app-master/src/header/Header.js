const SCREEN_LOADER = '@SCREEN_LOADER@'

const Header = (payload) => {
  return {
    type: SCREEN_LOADER,
    payload
  }
}

export default Header
