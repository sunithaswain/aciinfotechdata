import React from 'react'
// import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import { browserHistory } from 'react-router'

class Header extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      currentPath : '/'
    }
    this.showPage = this.showPage.bind(this)
  }

  showPage = (pagename) => {
    browserHistory.push(pagename)
    this.setState({
      currentPath : pagename
    })
  }

  render () {
    const curPathName = browserHistory.getCurrentLocation().pathname

    if (curPathName === '/' || curPathName === '/login/' || curPathName === '/logout/') {
      return (<ul className='header' />)
    }
    return (

      <ul className='header row'>
        <li className={curPathName === '/claims/' ? 'small-1 columns cpamenuselected' : 'small-1 columns'}>
          <a onClick={() => this.showPage('/claims/')} >Claim</a>
        </li>
        <li className={curPathName === '/eligibility/' ? 'small-1 columns cpamenuselected' : 'small-1 columns'}>
          <a onClick={() => this.showPage('/eligibility/')}>Eligibility</a>
        </li>
        <li className={curPathName === '/pharmacy/' ? 'small-1 columns cpamenuselected' : 'small-1 columns'}>
          <a>Pharmacy</a>
        </li>
        <li className={curPathName === '/report/' ? 'small-1 columns cpamenuselected' : 'small-1 columns'}>
          <a>Report</a>
        </li>
        <li className='login-align small-1 columns'>
          <a onClick={() => this.showPage('/logout/')} >Logout</a>
        </li>
      </ul>
    )
  }
}

Header.propTypes = {

}

const mapDispatchToProps = (dispatch) => {
  return { }
}

const mapStateToProps = (state, meta) => {
  return {
    opts: state.screenLoader
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Header)
