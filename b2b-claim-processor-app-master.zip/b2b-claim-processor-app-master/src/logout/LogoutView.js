import React from 'react'
import PropTypes from 'prop-types'

class LogoutView extends React.Component {
 constructor (props) {
    super(props)
    this.state = {

    }
   }
  componentDidMount () {
  }

  componentWillMount () {
    this.props.logout()
  }

  render () {
      return (

        <div className='login-container'>
          <div className='log-in-form'>
            <label>You did logout!</label>
          </div>
        </div>
      )
  }
}
LogoutView.propTypes = {
  logout : PropTypes.func
}
export default LogoutView
