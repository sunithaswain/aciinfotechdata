import { connect } from 'react-redux'
import LogoutView from 'logout/LogoutView'
import { bindActionCreators } from 'redux'
import { logout } from 'logout/LogoutActions'

const mapDispatchToProps = (dispatch) => {
  return {
        logout:bindActionCreators(logout, dispatch)
  }
}
const mapStateToProps = (state) => {
  return state
}

export default connect(mapStateToProps, mapDispatchToProps)(LogoutView)
