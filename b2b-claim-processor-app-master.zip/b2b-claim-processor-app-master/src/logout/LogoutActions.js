import Common from 'common/services/Common'
import LogoutService from 'logout/LogoutService'

const SCREEN_LOADER = '@SCREEN_LOADER@'

export const logout = () => {
   return async (dispatch) => {
    dispatch({
      type: SCREEN_LOADER,
      payload: { show: true }
    })
    try {
      const result = await LogoutService.logout()

      if (result['result'] === 'success') {
          Common.removeJwtToken()
      } else {
        window.alert('logout is failure')
      }
    } catch (e) {
          window.alert('ERROR')
    } finally {
        dispatch({
          type: SCREEN_LOADER,
          payload: { show: false }
        })
    }
   }
}
