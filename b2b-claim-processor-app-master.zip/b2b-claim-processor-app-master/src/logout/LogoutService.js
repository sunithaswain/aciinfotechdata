import api from 'utils/api'
import Common from 'common/services/Common'

class LogoutService {
  async logout (token) {
    const body = { }
    const data = await api.logout(
        {
          body: JSON.stringify(body),
          customToken: { value: Common.getJwtToken() },
          tokenType: 'Bearer'
        })

    return data
  }
}
export default new LogoutService()
