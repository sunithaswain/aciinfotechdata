
class EligibilityService {

}
export default new EligibilityService()
