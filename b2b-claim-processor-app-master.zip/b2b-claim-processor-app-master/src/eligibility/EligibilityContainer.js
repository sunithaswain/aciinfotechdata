import { connect } from 'react-redux'
import EligibilityView from 'eligibility/EligibilityView'

const mapDispatchToProps = (dispatch) => {
  return {

  }
}
const mapStateToProps = (state) => {
  return {

  }
}
export default connect(mapStateToProps, mapDispatchToProps)(EligibilityView)
