import React from 'react'

import EligibilitySearch from '../eligibilitysearch/EligibilitySearchContainer'
import EligibilityTable from '../eligibilitytable/EligibilitytableContainer'
import BreadCrumView from 'common/components/breadcrums'

import EligibilityMemberView from '../eligibilitymember/EligibilityMemberContainer'

class EligibilityView extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      currentHierarchy : { pageName : 'eligibility', primaryLevel : undefined, secondaryLevel : undefined },
      selectedMemberid : undefined,
      selectedPersoncode : undefined

    }
    this.updatePageHierarchy = this.updatePageHierarchy.bind(this)
    this.revokePageHierarchy = this.revokePageHierarchy.bind(this)
  }
  componentDidMount () {}
  componentWillUpdate () {}

  revokePageHierarchy (pageHierarchy) {
    this.setState({
      currentHierarchy : pageHierarchy
    })
  }

  updatePageHierarchy (pageHierarchy, selectedMemberid, selectedPersoncode) {
    this.setState({
      currentHierarchy : pageHierarchy,
      selectedMemberid : selectedMemberid,
      selectedPersoncode : selectedPersoncode
    })
  }

  render () {
    return (
      <div className='grid-container full' >
        <BreadCrumView currentPage={this.state.currentHierarchy} revokePageHierarchy={this.revokePageHierarchy} />
        {
          (this.state.currentHierarchy.pageName === 'eligibility' && !this.state.currentHierarchy.primaryLevel && !this.state.currentHierarchy.secondaryLevel)
          ? <div name='claimpage'><EligibilitySearch /><EligibilityTable updatePageHierarchy={this.updatePageHierarchy} /></div>
          : ''
        }
        {
          (this.state.currentHierarchy.pageName === 'eligibility' && this.state.currentHierarchy.primaryLevel === 'member' && !this.state.currentHierarchy.secondaryLevel)
          ? <div name='memberdetail'>
            <EligibilityMemberView selectedMemberid={this.state.selectedMemberid} selectedPersoncode={this.state.selectedPersoncode} updatePageHierarchy={this.updatePageHierarchy} />
          </div>
          : ''
        }

      </div>
    )
  }
}
EligibilityView.propTypes = {

}
export default EligibilityView
