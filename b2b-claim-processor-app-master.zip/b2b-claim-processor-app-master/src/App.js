import React from 'react'
import { browserHistory, Router } from 'react-router'
import { Provider } from 'react-redux'
import PropTypes from 'prop-types'

import FooterView from 'common/components/footer'
import Header from 'header/HeaderContainer'
import Common from 'common/services/Common'

import ScreenLoader from 'screenloader/ScreenLoaderContainer'
//dummy change for pagination fix

class App extends React.Component {
  constructor (props) {
    super(props)
    this.state = {

    }
  }

  static propTypes = {
    store: PropTypes.object.isRequired,
    routes: PropTypes.array.isRequired,
  }
  componentDidMount () {

  }
  componentWillMount () {
    if (!Common.getJwtToken()) {
      browserHistory.push('/login/')
    } else if (window.location.pathname === '/') {
      browserHistory.push('/claims/')
    }
  }

  render () {
    return (
      <Provider store={this.props.store}>
        <div style={{ height: '100%' }}>
          <div>
            <h2><img src='/img/flipt-logo.png' className='logo-flipt' />Claim Processor</h2>

            <Header />

            <Router history={browserHistory} children={this.props.routes} />

            <FooterView />

          </div>
          <ScreenLoader />
        </div>
      </Provider>
    )
  }
}

export default App
