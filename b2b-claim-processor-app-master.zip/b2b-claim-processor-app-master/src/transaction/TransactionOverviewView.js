import React from 'react'
import PropTypes from 'prop-types'
// import { get } from 'lodash'

class TransactionOverview extends React.Component {
    constructor (props) {
        super(props)
        this.state = {}
    }
    componentDidMount () {}
    componentWillMount () {}
    componentWillUpdate () {}

    render () {
        if (!this.props.transactiondata.overview) {
          return (<div />)
        }
        return (
          <div className='overviewpanel'>

            <div className='row'>
              <h5 className='small-12 columns'>Claim</h5>
              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns'>Bin:</div>
                <div className='small-2 columns'>
                  {this.props.transactiondata.overview.claimbin}
                </div>
                <div className='small-2 columns'>PCN:</div>
                <div className='small-2 columns'>
                  {this.props.transactiondata.overview.claimpcn}
                </div>
                <div className='small-4 columns' />

              </div>
              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns'>Date of Service:</div>
                <div className='small-2 columns'>
                  {this.props.transactiondata.overview.claimdateofservice}
                </div>
                <div className='small-2 columns'>Auth Number:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.claimauthid}
                </div>
                <div className='small-4 columns' />

              </div>
              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns'>Sequence Number:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.claimsequencenumber}
                </div>
                <div className='small-2 columns'>Status:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.claimstatus}
                </div>
                <div className='small-4 columns' />

              </div>
              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns'>Rx No:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.claimrxnumber}
                </div>
                <div className='small-2 columns'>eRx Transaction ID:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.claimerxtranactionid}
                </div>
                <div className='small-4 columns' />
              </div>

              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns'><h4>Transfer</h4></div>
                <div className='small-2 columns'>
                  &nbsp;
                </div>
                <div className='small-2 columns' />
                <div className='small-2 columns'>
                  &nbsp;
                </div>
                <div className='small-4 columns' />
              </div>

              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns'>BIN:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.claimtransferbin}
                </div>
                <div className='small-2 columns'>PCN:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.claimtransferpcn}
                </div>
                <div className='small-4 columns' />
              </div>

              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns'>Transfer Status:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.claimtransferstatus}
                </div>
                <div className='small-2 columns' />
                <div className='small-2 columns'>
                  &nbsp;
                </div>
                <div className='small-4 columns' />
              </div>

              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns'>Payer Name:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.claimtransferpayername}
                </div>
                <div className='small-2 columns'>Payer Help Desk Number:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.claimtransferpayerdeskno}
                </div>
                <div className='small-4 columns' />
              </div>

              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns'>Payer Help Desk email:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.claimtransferpayerdeskmail}
                </div>
                <div className='small-2 columns' />
                <div className='small-2 columns'>
                  &nbsp;
                </div>
                <div className='small-4 columns' />
              </div>

            </div>
            <div className='row'>
              <h5 className='columns small-12'>Pharmacy</h5>
              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns'>NPI:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.pharmacynpi}
                </div>
                <div className='small-2 columns'>NCPDP:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.pharmacyncpdp}
                </div>
                <div className='small-4 columns' />

              </div>
              <div className='columns small-12 otherpanellineheight'>

                <div className='small-2 columns'>Name:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.pharmacyname}
                </div>
                <div className='small-2 columns' />
                <div className='small-2 columns' />
                <div className='small-2 columns' />
                <div className='small-2 columns' />

              </div>
            </div>
            <div className='row'>
              <h5 className='columns small-12'>Member</h5>
              <div className='columns small-12 otherpanellineheight'>

                <div className='small-2 columns'>Carrier:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.membercarrier}
                </div>
                <div className='small-2 columns'>Account:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.memberaccount}
                </div>
                <div className='small-4 columns' />

              </div>
              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns'>Group:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.membergroup}
                </div>
                <div className='small-2 columns'>Member ID:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.memberid}
                </div>
                <div className='small-4 columns' />

              </div>
              <div className='columns small-12 otherpanellineheight'>

                <div className='small-2 columns'>First Name:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.firstname}
                </div>
                <div className='small-2 columns'>Last Name:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.lastname}
                </div>
                <div className='small-4 columns' />

              </div>
              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns'>Person Code:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.personcode}
                </div>
                <div className='small-2 columns'>Relationship Code:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.relationshipcode}
                </div>
                <div className='small-4 columns' />

              </div>
              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns'>DOB:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.dob}
                </div>
                <div className='small-2 columns'>Gender:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.gender}
                </div>
                <div className='small-4 columns' />

              </div>
            </div>
            <div className='row'>
              <h5 className='columns small-12'>Product</h5>
              <div className='columns small-12 otherpanellineheight'>

                <div className='small-2 columns'>Product ID:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.productid}
                </div>
                <div className='small-2 columns'>GPI Code:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.gpicode}
                </div>
                <div className='small-4 columns' />

              </div>
              <div className='columns small-12 otherpanellineheight'>

                <div className='small-2 columns'>Product Name:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.productname}
                </div>
                <div className='small-2 columns'>Quantity:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.productquantity}
                </div>
                <div className='small-4 columns' />

              </div>
              <div className='columns small-12 otherpanellineheight'>

                <div className='small-2 columns'>Day Supply:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.productdaysupply}
                </div>
                <div className='small-2 columns'>Multi Source Code:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.productmultisourcecode}
                </div>
                <div className='small-4 columns' />

              </div>
              <div className='columns small-12 otherpanellineheight'>

                <div className='small-2 columns'>OTC Indicator:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.productotcindicator}
                </div>
                <div className='small-2 columns'>Manufacturer:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.productmanufacturer}
                </div>
                <div className='small-4 columns' />

              </div>
            </div>
            <div className='row'>
              <h5 className='columns small-12'>Override</h5>
              <div className='columns small-12 otherpanellineheight'>

                <div className='small-2 columns'>Number:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.priorauthnumber}
                </div>
                <div className='small-2 columns'>Transaction ID:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.transactionid}
                </div>
                <div className='small-4 columns' />

              </div>
              <div className='columns small-12 otherpanellineheight'>

                <div className='small-2 columns'>Other Coverage Code:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.othercoveragecode}
                </div>
                <div className='small-2 columns'>Other Coverage Amount:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.overview.othercoverageamount}
                </div>
                <div className='small-4 columns' />

              </div>
            </div>

          </div>
        )
    }
}

TransactionOverview.propTypes = {
  transactiondata : PropTypes.object
}

export default TransactionOverview
