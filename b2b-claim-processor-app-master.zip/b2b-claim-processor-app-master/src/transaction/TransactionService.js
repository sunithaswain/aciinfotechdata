import api from 'utils/api'
import Common from 'common/services/Common'

class TransactionService {
    async transaction (authid, sequencenumber) {
        const qryparams = '?authid=' + authid + '&sequencenumber=' + sequencenumber
        const data = await api.gettransaction(
            {
                  customToken: { value: Common.getJwtToken() },
                  tokenType: 'Bearer'
            }, qryparams)
        return data
      }
}
export default new TransactionService()
