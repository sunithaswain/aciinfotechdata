import { connect } from 'react-redux'
import TransactionView from 'transaction/TransactionView'
import { bindActionCreators } from 'redux'
import { gettransaction } from 'transaction/TransactionActions'

const mapDispatchToProps = (dispatch) => {
  return {
    gettransaction:bindActionCreators(gettransaction, dispatch)
  }
}
const mapStateToProps = (state) => {
  return state
}
export default connect(mapStateToProps, mapDispatchToProps)(TransactionView)
