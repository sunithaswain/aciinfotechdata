import React from 'react'
import PropTypes from 'prop-types'
// import { get } from 'lodash'

class TransactionRejection extends React.Component {
    constructor (props) {
        super(props)
        this.state = {}
    }
    componentDidMount () {}
    componentWillMount () {}
    componentWillUpdate () {}

    render () {
      if (!this.props.transactiondata.rejection) {
        return (<div />)
      }
        return (
          <div className='rejectionpanel'>

            <div className='row rejectpanellineheight'>
              <div className='small-2 columns labelstrong'>Flipt Reject Code:</div>
              <div className='small-2 columns'>
                &nbsp;{this.props.transactiondata.rejection.rejectcode}
              </div>
              <div className='small-2 columns labelstrong' />
              <div className='small-2 columns'>
                &nbsp;
              </div>
              <div className='small-4 columns' />

            </div>
            <div className='row rejectpanellineheight'>
              <div className='small-2 columns labelstrong'>Flipt Reject Message 1:</div>
              <div className='small-2 columns'>
                &nbsp;{this.props.transactiondata.rejection.rejectmessage1}
              </div>
              <div className='small-2 columns labelstrong' />
              <div className='small-2 columns'>
                &nbsp;
              </div>
              <div className='small-4 columns' />

            </div>
            <div className='row rejectpanellineheight'>
              <div className='small-2 columns labelstrong'>Flipt Reject Message 2:</div>
              <div className='small-2 columns'>
                &nbsp;{this.props.transactiondata.rejection.rejectmessage2}
              </div>
              <div className='small-2 columns labelstrong' />
              <div className='small-2 columns'>
                &nbsp;
              </div>
              <div className='small-4 columns' />

            </div>
            <div className='row rejectpanellineheight'>
              <div className='small-2 columns labelstrong'>Payer Reject Code:</div>
              <div className='small-2 columns'>
                &nbsp;{this.props.transactiondata.rejection.payerrejectcode}
              </div>
              <div className='small-2 columns labelstrong' />
              <div className='small-2 columns'>
                &nbsp;
              </div>
              <div className='small-4 columns' />

            </div>
            <div className='row rejectpanellineheight'>
              <div className='small-2 columns labelstrong'>Payer Reject Message 1:</div>
              <div className='small-2 columns'>
                &nbsp;{this.props.transactiondata.rejection.payerrejectmessage1}
              </div>
              <div className='small-2 columns labelstrong' />
              <div className='small-2 columns'>
                &nbsp;
              </div>
              <div className='small-4 columns' />

            </div>
            <div className='row rejectpanellineheight'>
              <div className='small-2 columns labelstrong'>Payer Reject Message 2:</div>
              <div className='small-2 columns'>
                &nbsp;{this.props.transactiondata.rejection.payerrejectmessage2}
              </div>
              <div className='small-2 columns labelstrong' />
              <div className='small-2 columns'>
                &nbsp;
              </div>
              <div className='small-4 columns' />

            </div>
          </div>
        )
    }
}

TransactionRejection.propTypes = {
  transactiondata : PropTypes.object
}

export default TransactionRejection
