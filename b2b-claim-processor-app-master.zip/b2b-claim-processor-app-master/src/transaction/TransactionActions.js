import TransactionService from 'transaction/TransactionService'
import { browserHistory } from 'react-router'

import { TRANSACTION_CLAIMS_SUCCESS } from 'common/constants/ActionConstants'
import createAction from 'utils/createAction'

const transactionClaimsSuccessAction = createAction(TRANSACTION_CLAIMS_SUCCESS)
const SCREEN_LOADER = '@SCREEN_LOADER@'

export const gettransaction = (authid, sequencenumber) => {
  return async (dispatch) => {
    dispatch({
      type: SCREEN_LOADER,
      payload: { show: true }
    })
    dispatch(transactionClaimsSuccessAction({}))
   try {
    const result = await TransactionService.transaction(authid, sequencenumber)
        if (result) {
          dispatch(transactionClaimsSuccessAction(result))
        }
    } catch (e) {
        if (e.status === 500) {
          window.alert('ERROR: Internal Server or Application(Transaction API Endpoint) Error. Please contact the Integration team.')
          browserHistory.push('/')
        } else if (e.status === 502) {
          window.alert('ERROR: Server(Bad Gateway) Error. Please contact the Integration team.')
          browserHistory.push('/')
        } else {
          window.alert('ERROR: Application(Transaction API Endpoint) Error. Please contact the Integration team.')
          browserHistory.push('/error/')
        }
    } finally {
      dispatch({
        type: SCREEN_LOADER,
        payload: { show: false }
      })
    }
  }
}
