import React from 'react'
import PropTypes from 'prop-types'
// import { get } from 'lodash'
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs'

import TransactionOverview from 'transaction/TransactionOverviewView'
import TransactionPricing from 'transaction/TransactionPricingView'
import TransactionProvider from 'transaction/TransactionProviderView'
import TransactionRejection from 'transaction/TransactionRejectionView'

class TransactionView extends React.Component {
    constructor (props) {
        super(props)
        this.state = {}
    }
    componentDidMount () {
      this.props.gettransaction(this.props.selectedAuthID, this.props.sequenceNumber)
    }
    componentWillMount () {}
    componentWillUpdate () {}

    render () {
      let transactiondata = {}
      if (this.props.transaction) {
        transactiondata = this.props.transaction
      }

        return (
          <div>

            <Tabs>
              <TabList>
                <Tab>Overview</Tab>
                <Tab>Pricing</Tab>
                <Tab>Providers</Tab>
                <Tab>Rejection</Tab>
              </TabList>

              <TabPanel>
                <TransactionOverview transactiondata={transactiondata} />
              </TabPanel>
              <TabPanel>
                <TransactionPricing transactiondata={transactiondata} />
              </TabPanel>
              <TabPanel>
                <TransactionProvider transactiondata={transactiondata} />
              </TabPanel>
              <TabPanel>
                <TransactionRejection transactiondata={transactiondata} />
              </TabPanel>

            </Tabs>
          </div>
        )
    }
}

TransactionView.propTypes = {
  transaction : PropTypes.any,
  selectedAuthID : PropTypes.string,
  sequenceNumber : PropTypes.string,
  gettransaction : PropTypes.func
}

export default TransactionView
