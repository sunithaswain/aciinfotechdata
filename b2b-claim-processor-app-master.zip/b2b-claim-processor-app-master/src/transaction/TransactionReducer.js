
import getSavedState from 'utils/getSavedState'
import { TRANSACTION_CLAIMS_SUCCESS } from 'common/constants/ActionConstants'
const INITIAL_STATE = getSavedState('CPA.searchDetails', {})

export default function transaction (state = INITIAL_STATE, action) {
  switch (action.type) {
    case TRANSACTION_CLAIMS_SUCCESS:
        return action.payload
    default:
      return state
  }
}
