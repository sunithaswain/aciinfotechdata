import React from 'react'
import PropTypes from 'prop-types'
// import { get } from 'lodash'

class TransactionPricing extends React.Component {
    constructor (props) {
        super(props)
        this.state = {}
    }
    componentDidMount () {}
    componentWillMount () {}
    componentWillUpdate () {}

    render () {
      if (!this.props.transactiondata.pricing) {
        return (<div />)
      }

        return (
          <div className='pricingpanel'>

            <div className='row'>

              <div className='columns small-12 pricetableheader'>
                <div className='small-2 columns'>&nbsp;</div>
                <div className='small-2 columns'>
                  SUBMITTED
                </div>
                <div className='small-2 columns'>CALCULATED</div>
                <div className='small-2 columns'>
                  CLIENT
                </div>
                <div className='small-4 columns'>RESPONSE</div>

              </div>
              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns pricetablerowheader'>ING.COST</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.pricing.submittedingcost}
                </div>
                <div className='small-2 columns'>&nbsp;{this.props.transactiondata.pricing.calculatedingcost}</div>
                <div className='small-2 columns'>
                  {this.props.transactiondata.pricing.clientengcost}
                </div>
                <div className='small-4 columns'>&nbsp;{this.props.transactiondata.pricing.responseingcost}</div>

              </div>
              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns pricetablerowheader'>DISP FEE</div>
                <div className='small-2 columns'>
                  {this.props.transactiondata.pricing.submitteddispfee}
                </div>
                <div className='small-2 columns'>&nbsp;{this.props.transactiondata.pricing.calculatedispfee}</div>
                <div className='small-2 columns'>
                  {this.props.transactiondata.pricing.clientdispfee}
                </div>
                <div className='small-4 columns'>&nbsp;{this.props.transactiondata.pricing.responsedispfee}</div>

              </div>
              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns pricetablerowheader'>ADMIN FEE</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.pricing.submittedadminfee}
                </div>
                <div className='small-2 columns'>&nbsp;{this.props.transactiondata.pricing.calculatedadminfee}</div>
                <div className='small-2 columns'>
                  {this.props.transactiondata.pricing.clientadminfee}
                </div>
                <div className='small-4 columns'>&nbsp;{this.props.transactiondata.pricing.responseadminfee}</div>

              </div>
              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns pricetablerowheader'>SALES TAX</div>
                <div className='small-2 columns'>
                  {this.props.transactiondata.pricing.submittedsalestax}
                </div>
                <div className='small-2 columns'>&nbsp;{this.props.transactiondata.pricing.calculatedsalestax}</div>
                <div className='small-2 columns'>
                  {this.props.transactiondata.pricing.clientsalestax}
                </div>
                <div className='small-4 columns'>&nbsp;{this.props.transactiondata.pricing.responsesalestax}</div>

              </div>
              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns pricetablerowheader'>PAT PAY</div>
                <div className='small-2 columns'>
                  {this.props.transactiondata.pricing.submittedpatpay}
                </div>
                <div className='small-2 columns'>&nbsp;{this.props.transactiondata.pricing.calculatedpatpay}</div>
                <div className='small-2 columns'>
                  {this.props.transactiondata.pricing.clientpatpay}
                </div>
                <div className='small-4 columns'>&nbsp;{this.props.transactiondata.pricing.responsepatpay}</div>

              </div>
              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns pricetablerowheader'>U & C</div>
                <div className='small-2 columns'>
                  {this.props.transactiondata.pricing.submittedUC}
                </div>
                <div className='small-2 columns'>&nbsp;{this.props.transactiondata.pricing.calculatedUC}</div>
                <div className='small-2 columns'>
                  {this.props.transactiondata.pricing.clientUC}
                </div>
                <div className='small-4 columns'>&nbsp;{this.props.transactiondata.pricing.responseUC}</div>

              </div>
              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns pricetablerowheader'>TOTAL DUE</div>
                <div className='small-2 columns'>
                  {this.props.transactiondata.pricing.submittedtotaldue}
                </div>
                <div className='small-2 columns'>&nbsp;{this.props.transactiondata.pricing.calculatedtotaldue}</div>
                <div className='small-2 columns'>
                  {this.props.transactiondata.pricing.clienttotaldue}
                </div>
                <div className='small-4 columns'>&nbsp;{this.props.transactiondata.pricing.responsetotaldue}</div>

              </div>

            </div>

            <div className='row'>
              <h5 className='columns small-12'>Pharmacy</h5>
              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns'>Price Type:</div>
                <div className='small-2 columns'>
                  {this.props.transactiondata.pricing.pharmacypricetype}
                </div>
                <div className='small-2 columns'>Unit Price:</div>
                <div className='small-2 columns'>
                  {this.props.transactiondata.pricing.pharmacyunitprice}
                </div>
                <div className='small-4 columns' />

              </div>
              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns'>Mac List:</div>
                <div className='small-2 columns'>
                  {this.props.transactiondata.pricing.pharmacymaclist}
                </div>
                <div className='small-2 columns' />
                <div className='small-2 columns' />
                <div className='small-4 columns' />

              </div>

            </div>
            <div className='row'>
              <h5 className='columns small-12'>Client</h5>
              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns'>Price Type:</div>
                <div className='small-2 columns'>
                  {this.props.transactiondata.pricing.clientpricetype}
                </div>
                <div className='small-2 columns'>Unit Price:</div>
                <div className='small-2 columns'>
                  {this.props.transactiondata.pricing.clientunitprice}
                </div>
                <div className='small-4 columns' />

              </div>
              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns'>Mac List:</div>
                <div className='small-2 columns'>
                  {this.props.transactiondata.pricing.clientmaclist}
                </div>
                <div className='small-2 columns' />
                <div className='small-2 columns'>
                  &nbsp;
                </div>
                <div className='small-4 columns' />

              </div>
            </div>

            <div className='row otherpanellineheight'>
              <div className='small-2 columns'>AttribToDed:</div>
              <div className='small-2 columns'>
                {this.props.transactiondata.pricing.attribtoded}
              </div>
              <div className='small-2 columns'>OOP:</div>
              <div className='small-2 columns'>
                {this.props.transactiondata.pricing.oop}
              </div>
              <div className='small-4 columns' />

            </div>

          </div>
        )
    }
}

TransactionPricing.propTypes = {
  transactiondata : PropTypes.object
}

export default TransactionPricing
