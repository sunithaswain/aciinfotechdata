import React from 'react'
import PropTypes from 'prop-types'
// import { get } from 'lodash'

class TransactionProvider extends React.Component {
    constructor (props) {
        super(props)
        this.state = {}
    }
    componentDidMount () {}
    componentWillMount () {}
    componentWillUpdate () {}

    render () {
      if (!this.props.transactiondata.providers) {
        return (<div />)
      }

        return (
          <div className='providerpanel'>
            <div className='row'>
              <h5 className='columns small-12'>Pharmacy</h5>
              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns'>NPI:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.providers.pharmacynpi}
                </div>
                <div className='small-2 columns'>NCPDP:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.providers.pharmacyncpdp}
                </div>
                <div className='small-4 columns' />

              </div>
              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns'>Address:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.providers.pharmacyaddress}
                </div>
                <div className='small-2 columns'>Phone:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.providers.pharmacyphone}
                </div>
                <div className='small-4 columns' />

              </div>
              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns'>Fax:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.providers.pharmacyfax}
                </div>
                <div className='small-2 columns' />
                <div className='small-2 columns'>
                  &nbsp;
                </div>
                <div className='small-4 columns' />

              </div>
            </div>
            <div className='row'>
              <h5 className='columns small-12'>Prescriber</h5>
              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns'>NPI:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.providers.prescribernpi}
                </div>
                <div className='small-2 columns'>Address:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.providers.prescriberaddress}
                </div>
                <div className='small-4 columns' />

              </div>
              <div className='columns small-12 otherpanellineheight'>
                <div className='small-2 columns'>Phone:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.providers.prescriberphone}
                </div>
                <div className='small-2 columns'>Fax:</div>
                <div className='small-2 columns'>
                  &nbsp;{this.props.transactiondata.providers.prescriberfax}
                </div>
                <div className='small-4 columns' />

              </div>
            </div>
          </div>
        )
    }
}

TransactionProvider.propTypes = {
  transactiondata : PropTypes.object
}

export default TransactionProvider
