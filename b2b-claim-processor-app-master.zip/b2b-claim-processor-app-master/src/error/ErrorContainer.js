import { connect } from 'react-redux'
import ErrorView from 'error/ErrorView'
import { bindActionCreators } from 'redux'
import { error } from 'error/ErrorActions'

const mapDispatchToProps = (dispatch) => {
  return {
        error:bindActionCreators(error, dispatch)
  }
}
const mapStateToProps = (state) => {
  return state
}

export default connect(mapStateToProps, mapDispatchToProps)(ErrorView)
