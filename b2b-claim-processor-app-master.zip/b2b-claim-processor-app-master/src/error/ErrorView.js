import React from 'react'

class ErrorView extends React.Component {
  render () {
      return (

        <div className='login-container'>
          <div className='log-in-form'>
            <label>Contact support team</label>
          </div>
        </div>
      )
  }
}
ErrorView.propTypes = {

}
export default ErrorView
