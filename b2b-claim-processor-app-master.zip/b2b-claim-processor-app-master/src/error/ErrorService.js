
class ErrorService {

}
export default new ErrorService()
