import api from 'utils/api'
import Common from 'common/services/Common'

class EligibilitytableService {
    async eligibilitydetails (authid) {
        const qryparams = '?authid=' + authid

        const data = await api.claimdetails(
          {
              customToken: { value: Common.getJwtToken() },
              tokenType: 'Bearer'
          }, qryparams)

      return data
    }
}
export default new EligibilitytableService()
