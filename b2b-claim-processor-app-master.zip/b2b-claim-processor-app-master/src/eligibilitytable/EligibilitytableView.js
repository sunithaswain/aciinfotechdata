import React from 'react'
import PropTypes from 'prop-types'
import { get } from 'lodash'

class EligibilitytableView extends React.Component {
  constructor (props) {
    super(props)
    this.state = { }
  }

  openClaimDetails (event) {
    this.props.eligibilitydata(event.target.getAttribute('value'))

    const currentPageLevel = {
      pageName:'eligibility', primaryLevel:'member details', secondaryLevel:undefined
    }

    const selectedMemberid = event.target.getAttribute('name')
    const selectedPersoncode = undefined
    this.props.updatePageHierarchy(currentPageLevel, selectedMemberid, selectedPersoncode)
  }

  openMemberDetails (event) {
    const currentPageLevel = {
      pageName:'eligibility', primaryLevel:'member', secondaryLevel:undefined
    }

    const selectedMemberdetails = event.target.getAttribute('name')
    this.props.updatePageHierarchy(currentPageLevel, selectedMemberdetails, '')
  }

  render () {
    const tabledata = get(this.props, 'eligibilitysearch')

      if (!tabledata.length) {
        return (
          <div />
          )
      } else {
        return (

          <div>
            <table>
              <thead>
                <tr>
                  <th>Member ID</th>
                  <th>Last Name</th>
                  <th>First Name</th>
                  <th>Group</th>
                  <th>PC</th>
                  <th>DOB</th>
                  <th>From Date</th>
                  <th>Thru Date</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {
              tabledata.map((value, index) => {
                return <tr key={index}>
                  <td>{value.memberid}</td>
                  <td>{value.lastname}</td>
                  <td>{value.firstname}</td>
                  <td>{value.group}</td>
                  <td>{value.personcode}</td>
                  <td>{value.dob}</td>
                  <td>{value.fromdate}</td>
                  <td>{value.thrudate}</td>
                  <td><div>
                    <a name={value.workmail + '|' + value.domain_name + '|' + value.memberid + '|' + value.membertype + '|' + value.personcode}
                      onClick={(event) => this.openMemberDetails(event)} > Member</a>
                  </div></td>
                </tr>
              })
            }
              </tbody>
            </table>
          </div>
      )
      }
  }
}
EligibilitytableView.propTypes = {
  updatePageHierarchy : PropTypes.func,
  eligibilitydata : PropTypes.func
}
export default EligibilitytableView
