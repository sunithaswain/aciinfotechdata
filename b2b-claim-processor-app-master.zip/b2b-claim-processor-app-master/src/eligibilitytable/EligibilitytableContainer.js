import { connect } from 'react-redux'
import EligibilitytableView from 'eligibilitytable/EligibilitytableView'
import { bindActionCreators } from 'redux'
import { eligibilitydata } from 'eligibilitytable/EligibilitytableActions'

const mapDispatchToProps = (dispatch) => {
  return {
        eligibilitydata:bindActionCreators(eligibilitydata, dispatch)
  }
}
const mapStateToProps = (state) => {
  return state
}

export default connect(mapStateToProps, mapDispatchToProps)(EligibilitytableView)
