import React from 'react'

const FooterView = () => {
    return (
      <div className='footer'>&copy; Copyright 2020 </div>
    )
  }

FooterView.propTypes = {

}
export default FooterView
