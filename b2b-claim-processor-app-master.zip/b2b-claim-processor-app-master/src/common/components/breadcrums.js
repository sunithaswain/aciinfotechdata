import React from 'react'
import PropTypes from 'prop-types'

class BreadCrumView extends React.Component {
    constructor (props) {
      super(props)
      this.state = { }
    }

    openClaimHierarchy = (currentPageLevel) => {
      this.props.revokePageHierarchy(currentPageLevel)
    }

    render () {
      return (
        <ul className='breadcrumb'>

          <li>
            <a onClick={() => this.openClaimHierarchy({ pageName:this.props.currentPage.pageName, primaryLevel:undefined, secondaryLevel:undefined })}>
              {this.props.currentPage.pageName}
            </a>
          </li>
          {this.props.currentPage.primaryLevel
            ? <li>
              <a onClick={() => this.openClaimHierarchy({ pageName:'claim', primaryLevel:'claim details', secondaryLevel:undefined })} >
                {this.props.currentPage.primaryLevel}
              </a>
            </li>
            : ''
            }
          {this.props.currentPage.secondaryLevel
            ? <li>
              <a onClick={() => this.openClaimHierarchy({ pageName:'claim', primaryLevel:'claim details', secondaryLevel:'override' })} >
                {this.props.currentPage.secondaryLevel}
              </a>
            </li>
            : ''
            }

        </ul>
      )
    }
}

BreadCrumView.propTypes = {
  currentPage : PropTypes.object,
  revokePageHierarchy : PropTypes.func
}
export default BreadCrumView
