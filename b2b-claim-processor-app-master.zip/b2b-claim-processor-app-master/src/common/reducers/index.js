import { combineReducers } from 'redux'
import screenLoader from 'screenloader/ScreenLoaderReducer'
import search from 'search/SearchReducer'
import claimstable from 'claimstable/ClaimstableReducer'
import override from 'override/OverrideReducer'
import member from 'member/MemberReducer'
import transaction from 'transaction/TransactionReducer'
import CPA from 'common/reducers/AppReducer'
import eligibilitysearch from 'eligibilitysearch/EligibilitySearchReducer'
import eligibilitymember from 'eligibilitymember/EligibilityMemberReducer'

const makeRootReducer = (asyncReducers) => {
  return combineReducers({
    screenLoader,
    CPA,
    search,
    claimstable,
    override,
    member,
    transaction,
    eligibilitysearch,
    eligibilitymember,
    ...asyncReducers

  })
}

export default makeRootReducer
