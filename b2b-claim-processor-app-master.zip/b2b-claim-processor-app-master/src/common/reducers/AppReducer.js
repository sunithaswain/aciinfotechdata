import {
  SEARCH_CLAIM_SUCCESS
} from 'common/constants/ActionConstants'
import search from 'search/SearchReducer'

const INITIAL_STATE = {}

export default function CPA (state = INITIAL_STATE, action) {
  switch (action.type) {
    case SEARCH_CLAIM_SUCCESS:
      return {
        ...state,
        searchDetails: search(state.searchDetails, action)
      }
    default:
      return state
  }
}
