import mainApi from 'utils/api'
import { default as queryParams } from 'utils/queryParams'
import {
    JWT_TOKEN_KEY
} from 'common/constants/AppGlobals'

class Common {
  constructor () {
    this.api = { ...mainApi }
    this.params = queryParams(window.location.search)
    this.JWT_Key = JWT_TOKEN_KEY
  }

  setJwtToken (value) {
    window.sessionStorage.setItem(this.JWT_Key, value)
  }
  removeJwtToken () {
    window.sessionStorage.removeItem(this.JWT_Key)
  }
  getJwtToken () {
    return window.sessionStorage.getItem(this.JWT_Key)
  }

  createRequest (request, orderIndex) {

  }

  createMarkup (text) {
    return { __html: text }
  }
}
export default new Common()
