import mainApi from 'utils/api'
import { constructQueryString, default as queryParams } from 'utils/queryParams'
import {
  TOKEN_KEY
} from 'common/constants/AppGlobals'

class AuthService {
  constructor () {
    this.api = { ...mainApi }
    this.params = queryParams(window.location.search)
    this.tokenKey = TOKEN_KEY
  }

  getToken (key = this.tokenKey) {
    const token = window.sessionStorage.getItem(key)
    if (token) {
      return JSON.parse(token)
    }
  }

  setToken (key, token) {
    window.sessionStorage.setItem(key, token)
  }

  removeToken (key) {
    window.sessionStorage.removeItem(key)
  }

  setAuthToken (token) {
    this.setToken(this.tokenKey, token)
  }

  clearToken () {
    this.removeToken(this.tokenKey)
  }

  async getMe () {
    try {
      let userData = await mainApi.getMe()
      return userData
    } catch (e) {

    }
  }

  checkToken () {
    return this.getToken(this.tokenKey)
  }

  redirectToLogin (queryParams, _window = window) {
    _window.location.href = `/login/${_window.location.search}&${constructQueryString(queryParams)}`
  }
  redirectOnLogout (queryParams, _window = window) {
    _window.location.href = `/login/` +
      `${_window.location.search}&${constructQueryString(queryParams)}`
  }
}

export default new AuthService()
