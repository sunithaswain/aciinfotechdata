/* eslint-disable max-len */
export const errorMessages = {

  GENERAL_ERROR: 'Sorry, our systems are unavailable at this time. Please try again later.'

}
