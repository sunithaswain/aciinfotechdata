export const SERVER_API_URL = process.env.SERVER_API_URL
export const STORAGE_PREFIX = 'CPA_APPS'
export const JWT_TOKEN_KEY = `${STORAGE_PREFIX}-JWTtoken`
