import grpc

# import the generated classes
import Member_pb2
import Member_pb2_grpc
from flask import Flask           # import flask
app = Flask(__name__)             # create an app instance

@app.route("/MemberEligibility/<cardholder_id>/<first_name>/<last_name>/<gender>/<date_of_birth>/<date_of_service>")                   # at the end point /
def MemberEligibility(cardholder_id,first_name,last_name,gender,date_of_birth,date_of_service):                      # call method hello
    # open a gRPC channel
    channel = grpc.insecure_channel('localhost:50051')

    # create a stub (client)
    stub = Member_pb2_grpc.VerfiyMemberStub(channel)

    # create a valid request message
    request = Member_pb2.MemberEligibilityRequest()
    #request.cardholder_id = '100424501'
    #request.first_name = 'QAUSERNOVF2'
    #request.last_name = 'QAUSERNOVL2'
    #request.gender = 'M'
    #request.date_of_birth = '1988-01-01'
    #request.date_of_service = '2020-03-04'
    request.cardholder_id = cardholder_id
    request.first_name = first_name
    request.last_name = last_name
    request.gender = gender
    request.date_of_birth = date_of_birth
    request.date_of_service = date_of_service

    # make the call
    response = stub.VerifyMember(request)


    print("**************************************************************")
    return response        # which returns "hello world"


if __name__ == "__main__":        # on running python app.py
    app.run()                     # run the flask app