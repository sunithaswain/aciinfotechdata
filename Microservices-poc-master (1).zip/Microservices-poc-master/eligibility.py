import os
from member import Member

def run(cardholder_id,first_name,last_name,gender,date_of_birth,date_of_service):
    tv_uri=os.environ['TV_URI']
    tv_api_key=os.environ['TV_API_KEY']
    date_of_service = ''
    print("Initiating the api to true vault")
    member = Member(cardholder_id=cardholder_id,
                    first_name='QAUSERNOVL2',
                    last_name='QAUSERNOVF2',
                    gender='M',
                    date_of_birth='1985-01-01',
                    date_of_service=date_of_service,
                    tv_uri=tv_uri,
                    tv_api_key=tv_api_key)
    print("Verifying users")
    data = member.is_eligible()
    print(data)
    return data

#run(cardholder_id='100424501',
#                    first_name='QAUSERNOVL2',
#                    last_name='QAUSERNOVF2',
#                    gender='M',
#                    date_of_birth='1985-01-01',
#                    date_of_service='2020-03-04')