# Copyright 2015 gRPC authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""The Python implementation of the GRPC helloworld.Greeter server."""

from concurrent import futures
import logging
import grpc
import Member_pb2
import Member_pb2_grpc
import eligibility
import json
from google.protobuf.json_format import *

class Member(Member_pb2_grpc.VerfiyMemberServicer):

    def VerifyMember(self, request, context):
        response = Member_pb2.MemberEligibilityResponse()
        data = eligibility.run(cardholder_id=request.cardholder_id,
                                    first_name=request.first_name,
                                    last_name=request.last_name,
                                    gender=request.gender,
                                    date_of_birth=request.date_of_birth,
                                    date_of_service=request.date_of_service)
        #print("**************************************************************")
        #print(data)
        return ParseDict(js_dict=data, message=response,ignore_unknown_fields=True)


def serve():
      
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    Member_pb2_grpc.add_VerfiyMemberServicer_to_server(Member(), server)
    server.add_insecure_port('[::]:50051')
    server.start()
    print("Server Started on port 50051")
    server.wait_for_termination()

if __name__ == '__main__':
    logging.basicConfig()
    serve()
