import base64
import datetime
import json
import logging
from requests.auth import HTTPBasicAuth
import vault_manager
#import Member_pb2

class Member(object):
    def __init__(self,cardholder_id, first_name, last_name, gender, date_of_birth, date_of_service,tv_uri,tv_api_key):
        self.URI = tv_uri
        self.TRUEVAULT_API_KEY = tv_api_key
        self.flipt_member_id = str(cardholder_id)[:-2]
        self.flipt_employee_id = str(cardholder_id)
        self.first_name = first_name
        self.person_code = str(cardholder_id)[-2:]
        self.last_name = last_name
        self.date_of_birth = date_of_birth
        self.date_of_service = str(date_of_service) + ' 00:00:00'
        self.primary_person_code = '01'
        self.tpa_member_id = str(cardholder_id)
        self.gender = gender.replace('1', 'M').replace('2', 'F')
        self.log = logging.getLogger()

    def _is_primary_user(self, person_code, primary_tpa_member_id, user, search_parameter):

        if not self._is_last_name_valid(user):
            return False, 'CB', 'Missing or Invalid Patient Last Name'
        else:
            if not self._is_dob_valid(user):
                return False, '9', 'Missing or Invalid Birth Date'

        return True, '', ''

    def _is_last_name_valid(self, user):
        return True if self.last_name == user['last_name'] else False

    def _is_dob_valid(self, user):
        return True if self.date_of_birth == user['date_of_birth'] else False

    def _identify_patient(self, user_matches, search_parameter):

        if len(user_matches) == 1:
            return user_matches[0]
        filtered_users = []

        if len(self.flipt_employee_id) > 7 and search_parameter == 'flipt_person_id':
            filtered_users = [
                user for user in user_matches if user['person_code'] == self.person_code]
        else:
            filtered_users.extend(user_matches)
        if not filtered_users or len(filtered_users) > 1:
            filtered_users = [
                user for user in user_matches if user['first_name'] == self.first_name]

        if len(filtered_users) == 1:
            return filtered_users[0]

        return {}

    def _get_dependent_info(self, user, person_code, search_parameter):
        """
        :param user:
        :param person_code:
        :return: dependent info(dict)
        """
        dependent_matches = []
        last_name_validation, dob_validation = False, False

        for dependent in user.get('dependents', []):
            if self._is_last_name_valid(dependent):
                last_name_validation = True
                if self._is_dob_valid(dependent):
                    dob_validation = True
                    dependent_matches.append(dependent)

        if dependent_matches:
            return dependent_matches, '', ''

        if not last_name_validation:
            return [], 'CB', 'Missing or Invalid Patient Last Name'
        else:
            return [], '9', 'Missing or Invalid Birth Date'

    def get_eligibility(self, user):

        covered = True

        eligibility = [coverage for coverage in user['eligibility'] if (
            coverage['coverage_effective_date'] <= self.date_of_service and self.date_of_service <= coverage['coverage_termination_date'])]
        if not eligibility:
            covered = False
            eligibility = [user['eligibility'][-1]]

        return eligibility, covered

    def is_eligible(self):
        """
        :param data: expects data in str format with required 5 params, checks if the user is eligible for
                        the claim.
        :return: returns TRUE or FALSE depending upon the input data
        """
        self.log.debug("Inside member eligibility")

        def _prepare_response(user, err_code, err_msg):
            #response = Member_pb2.MemberEligibilityResponse()
            if err_code:
                res = {'result': 'false',
                       'return-code': err_code,
                       'message': err_msg
                       }
                #response.result='false'
                #response.return_code = err_code
                #response.message = err_msg
                self.log.debug(
                    "Error while processing the member eligibility: {}".format(res))
                if user:
                    try:
                        res.update({'benefit-plan-name': user['benefit_plan_name'],
                                    'domain': user['domain_name'],
                                    'plan-year': self.date_of_service[:4],
                                    'user': user})
                    except Exception as _:
                        pass
                return res
            else:
                return {'benefit-plan-name': user['benefit_plan_name'],
                        'domain': user['domain_name'],
                        'result-code': '0',
                        'message': 'success',
                        'plan-year': self.date_of_service[:4],
                        'user': user}

        error_code = None
        err_msg = ''
        user, userid = self.search_user()

        if not user:
            err_msg = "Non-Matched Cardholder ID"
            self.log.debug(err_msg)
            return _prepare_response(user, "52", err_msg)

        user['user_id'] = userid
        active_user = user
        search_parameter = 'flipt_person_id'
        if self.tpa_member_id in active_user.get('tpa_member_id', '') == self.tpa_member_id:
            search_parameter = 'tpa_member_id'

        self.log.debug("Eligibility search by:"+search_parameter)

        user_info = {}
        user_covered = False
        user['rx_flipt_person_id'] = user['flipt_person_id']
        user['rx_member_id'] = user['flipt_person_id'] + user['person_code']
        if user.get('eligibility') is not None:
            eligibility, user_covered = self.get_eligibility(user)
            user['benefit_plan_name'] = eligibility[0]['benefit_plan_name']
            user['coverage_tier_name'] = eligibility[0]['coverage_tier_name']
        patient_primary_user, primary_user_rejection_code, primary_user_rejection_message = self._is_primary_user(self.person_code, user.get(
            'tpa_member_id', ''), user, search_parameter)
        dependent_matches, dependent_rejection_code, dependent_rejection_message = self._get_dependent_info(
            user, self.person_code, search_parameter)
        if primary_user_rejection_message and dependent_rejection_message:
            if self.person_code == self.primary_person_code:
                return _prepare_response(user, primary_user_rejection_code, primary_user_rejection_message)
            return _prepare_response(user, dependent_rejection_code, dependent_rejection_message)

        user_matches = []
        if not primary_user_rejection_message:
            user_matches.append(user)
        if not dependent_rejection_message:
            user_matches.extend(dependent_matches)
        active_user = self._identify_patient(user_matches, search_parameter)

        if not active_user:
            return _prepare_response(user, "65", "Patient Not Covered")

        if active_user:
            active_user['employment_status'] = user['employment_status']
            user['rx_flipt_person_id'] = active_user['flipt_person_id']

            user['rx_member_id'] = user['flipt_person_id'] + \
                active_user['person_code']
            if 'payment_option' in active_user:
                user['payment_option'] = active_user['payment_option']
            if user.get('eligibility') is not None:
                eligibility, user_covered = self.get_eligibility(active_user)
                user['benefit_plan_name'] = eligibility[0]['benefit_plan_name']
                user['coverage_tier_name'] = eligibility[0]['coverage_tier_name']

        if not user_covered:
            return _prepare_response(user, "65", "Patient Not Covered")

        return _prepare_response(user, error_code, err_msg)

    def search_user(self):
        """
        :return: This functions takes the above params as input and creates a curl command and post
                  request to true-vault with base64encoding.
        """
        self.log.debug("Getting info for the user from truevault: {}".format(
            self.flipt_member_id))

        search_option = {'full_document': True,
                         'filter': {
                             'flipt_person_id': {'type': 'in', 'value': [self.flipt_member_id, self.flipt_employee_id],
                                                 'case_sensitive': False},
                             'tpa_member_id': {'type': 'wildcard', 'value': self.tpa_member_id+'*',
                                               'case_sensitive': False}}, 'filter_type': 'or'}
        search_opt = base64.b64encode(str.encode(json.dumps(search_option)))

        search_json = {'search_option': search_opt}

        session = vault_manager.VaultSession().session
        res = session.post(self.URI, auth=HTTPBasicAuth(self.TRUEVAULT_API_KEY, ''),
                           data=search_json)

        response = res.json()

        if 'error' in response:
            err_msg = str(response['error'])
            self.log.debug(
                "Received error response from truevault: {}".format(err_msg))
            return

        if (res.status_code != 200 or 'data' not in response or
                (res.status_code == 200 and not response['data'].get('documents'))):
            return

        if len(response['data']['documents']) > 1:
            return self.resolve_multiple_users(response['data']['documents'])

        return json.loads(base64.b64decode(response['data']['documents'][0]['attributes']).
                          decode('utf-8')), response['data']['documents'][0]['user_id']

    def resolve_multiple_users(self, search_response):

        user_attributes = []
        user_id = ''
        number_of_matches = 0

        for user in search_response:
            attributes = json.loads(base64.b64decode(
                user['attributes']).decode('utf-8'))
            if 'parent_id' in attributes or user['status'] == 'DEACTIVATED':
                continue
            if self._is_dob_valid(attributes) and self._is_last_name_valid(attributes):
                user_attributes = attributes
                user_id = user.get('user_id', '')
                number_of_matches = number_of_matches + 1
                continue
            for dependent in attributes['dependents']:
                if self._is_dob_valid(dependent) and self._is_last_name_valid(dependent):
                    user_attributes = attributes
                    if 'user_id' in dependent:
                        user_id = dependent['user_id']
                    else:
                        user_id = user.get('user_id', '')
                    number_of_matches = number_of_matches + 1
                    break
        if number_of_matches > 1:
            return [], ''

        return user_attributes, user_id