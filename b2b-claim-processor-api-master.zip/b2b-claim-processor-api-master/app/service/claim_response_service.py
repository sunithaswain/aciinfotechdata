import base64
import json
import logging
import re
import time
from threading import Thread

import couchbase.subdocument as SD
from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA
from couchbase import FMT_JSON
from ddtrace import tracer
from ddtrace.constants import ANALYTICS_SAMPLE_RATE_KEY


class ClaimResponseProcessor(object):

    def __init__(self, config, query_ex):
        self.transactionid = ''
        self.parsedclaim = {}
        self.config = config
        self.query_ex = query_ex
        self.cb = self.config.cb

    @staticmethod
    def parse_header(header_str):
        header_str = header_str.strip('\x1e\x1c')
        return dict(version=header_str[0:2],
                    transaction_code=header_str[2:4],
                    transaction_count=header_str[4:5],
                    header_response_status=header_str[5:6],
                    service_provider_id_qualifier=header_str[6:8],
                    service_provider_id=header_str[8:18].strip(),
                    date_of_service=header_str[18:28])

    def parse_segments(self, segment_list):

        segments_map = {'AM21': {'AN': ('transaction_response_status', 1),
                                 'F3': ('authorization_number', 13),
                                 'FA': ('reject_count', 1),
                                 'FB': ('reject_code', 3),
                                 'UF': ('additional_message_information_count', 1),
                                 'UH': ('additional_message_information_qualifier', 2),
                                 'FQ': ('additional_message_information', 200),
                                 'MANDATORY': ('FB', 'FA')},
                        'AM20': {'F4': ('message', 200)},
                        'AM22': {'EM': ('prescription_number_qualifier', 1),
                                 'D2': ('prescription_ref_num', 12),
                                 'MANDATORY': ('D2', 'F4')}}
        res_dict = {}
        try:
            segment_list = re.sub(r'[^\w]', '', segment_list).replace(
                'AM', ' AM').lstrip().split(' ')
            mandatory_list = ("AM20", "AM21", "AM22")
            res = [x for x in segment_list if x.startswith(mandatory_list)]
            self.log.debug("Segments after splitting {}".format(segment_list))
            # Length of FB as 2, but it can be 2 or 3
            for segment in res:
                segment_type = segment[:4]  # eg AM21
                segment = segment[4:]  # eg everything else after AM21
                # for field in segments_map[segment_type].get('MANDATORY', []):
                #     if field not in segment:
                #         self.log.debug((f'{field} not present in segment: {segment_type}'))
                #         raise Exception (f'{field} not present in segment: {segment_type}')
                if segment_type == "AM21":
                    pattern = "({})".format(
                        "|".join(segments_map['AM21'].keys()))
                    r = re.split(pattern, segment)
                    i = 0
                    while i < len(r):
                        id_str = r[i]
                        if id_str in segments_map[segment_type]:
                            id_str = segments_map[segment_type][id_str][0]
                            id_val = r[i + 1]
                            if id_str in res_dict:
                                if isinstance(res_dict[id_str], list):
                                    res_dict[id_str].append(id_val)
                                else:
                                    res_dict[id_str] = [
                                        res_dict[id_str], id_val]
                            else:
                                # pdb.set_trace()
                                res_dict[id_str] = id_val
                        i += 1  # increment to process next index
                    continue
                while segment:
                    id = segment[:2]  # eg individual ids in segment like 'AN'
                    segment = segment[2:]  # eg everything else after 'AN'
                    id_str, size = segments_map[segment_type][id]
                    id_val = segment[:size]
                    if id_str in res_dict:
                        if isinstance(res_dict[id_str], list):
                            res_dict[id_str].append(id_val)
                        else:
                            res_dict[id_str] = [res_dict[id_str], id_val]
                    else:
                        res_dict[id_str] = id_val
                    segment = segment[size:]
            self.log.debug(f"Result after parsing the segments: {res_dict}")
            return res_dict
        except Exception as e:
            self.log.debug("Error in splitting of segments {}".format(str(e)))

    def encrypt(self, data):
        self.log.debug("Getting the public key from env variable")
        fd = open("/run/secrets/incoming_claims.pem", "rb")
        # fd = open("public.pem", "rb")
        public_key = fd.read()
        fd.close()
        publickey = RSA.importKey(public_key)

        publickey = PKCS1_OAEP.new(publickey)

        encrypted_msg = publickey.encrypt(data)
        encoded_encrypted_msg = base64.b64encode(encrypted_msg)
        return encoded_encrypted_msg.decode('utf-8')

    def get_data(self, request_data):
        self.log.debug(
            "Stripping the string with header and rest of the segments")
        self.parsedclaim['header'] = self.parse_header(
            request_data['contents'][:28])
        self.log.debug("self.log.debug the header seg: {}".format(
            self.parsedclaim['header']))
        self.parsedclaim['segments'] = self.parse_segments(
            request_data['contents'][28:])
        self.log.debug("self.log.debug the rest od segments: {}".format(
            self.parsedclaim['segments']))
        segment_data = self.parsedclaim['header']
        segment_data.update(self.parsedclaim['segments'])
        data = {'claim_transfer_response': segment_data,
                'transferResponse': self.ecrypted_request_data}
        self.log.debug(f"Trying to identify the existing claim using prescription ref number: "
                       f"{self.parsedclaim['segments']['prescription_ref_num']} and transaction number "
                       f"{self.transactionid}")
        # trying to find existing b1 claim and b2 claim
        existing_claim = self.query_ex.execute_query('meta().id',
                                                     'claim',
                                                     filters={'transactionId': self.transactionid,
                                                              'claim_request.prescription_reference_number':
                                                                  self.parsedclaim['segments']['prescription_ref_num'],
                                                              })
        if existing_claim is None:
            self.log.debug(
                f"Did not found the existing claim for the transaction : {self.transactionid}")
        else:
            self.log.debug(
                f"Found the existing claim for the transaction : {self.transactionid}")
            appened_data = self.cb.get(existing_claim['id']).value
            # data = existing data in cb + new data came in
            data.update(appened_data)
            self.cb.upsert(existing_claim['id'], data, format=FMT_JSON)

        self.save_claim(self.parsedclaim, self.transactionid)

    def save_claim(self, parsed_claim, transaction_id):
        self.log.debug("Starting the thread for post processing")
        self.log.debug("parsed claim: {}".format(parsed_claim))
        retry_count = 3
        while retry_count:
            self.log.debug("Inside the while loop")
            res = self.query_ex.execute_query('claim_request.prescription_reference_number, meta().id, '
                                              'claim_request.transaction_code, prescription_id',
                                              'claim',
                                              filters={'transactionId': transaction_id,
                                                       'claim_request.prescription_reference_number':
                                                           parsed_claim['segments']['prescription_ref_num']
                                                       })

            if res.get('prescription_id') is None:
                self.log.debug("prescription_id is none ?")
                if retry_count:
                    self.log.debug(
                        f"Could not find transaction ID: '{self.transactionid}'. Retry after 60sec")
                    time.sleep(60)
                    retry_count -= 1
                    continue
                else:
                    self.log.debug(f"Exausted all retry counts searching for transaction: '{self.transactionid}'"
                                   f". Exiting...")
                    self.cb.mutate_in(res['id'], SD.upsert('claims_reconciliation_error',
                                                           'Did not found the prescription in claims document'))
                    return

            self.log.debug("self.log.debuging the res vaules: {}".format(res))

            self.log.debug("Getting the existing prescription details using prec id : {}".format(
                res['prescription_id']))

            presc_obj = self.query_ex.execute_query('meta().id', 'prescription',
                                                    filters={"prescription_id": res['prescription_id']})

            if res['transaction_code'] == 'B1':
                self.post_process_b1_reject(presc_obj, res, transaction_id)
            else:
                self.post_process_b2_reject(presc_obj, res, transaction_id)

            return parsed_claim, transaction_id

    def post_process_b1_reject(self, presc_obj, res, transaction_id):

        self.cb.mutate_in(presc_obj['id'],
                          SD.upsert('rx_status', 'Routed'))
        self.log.debug(f"Updated the prescription to routed status : "
                       f"{presc_obj['id']}")
        self.log.debug("Getting the record in rx history")
        del_history = self.query_ex.execute_query('meta().id, prescription_id', 'rx_history',
                                                  filters={
                                                      'prescription_id': res['prescription_id']},
                                                  orderby='order by create_date desc')
        if del_history is None:
            self.log.debug(
                f"Record does not exists in rx_history for prescriprion_id :{res['prescription_id']}")
            self.cb.mutate_in(res['id'], SD.upsert('claims_reconciliation_error',
                                                   'Did not found the prescription in rx_history'))
        else:
            self.log.debug(f"Deleting the record rx history for {del_history}")
            delete_hisroty = self.cb.remove(del_history['id'], quiet=True)
            # del_history = self.query_ex.execute_delete_query(del_history['id'], 'rx_history')
            self.log.debug("Deleted the record from rx_history")
        reward_id = self.query_ex.execute_query('meta().id,prescription_id', 'rewardtransaction',
                                                filters={
                                                    'prescription_id': res['prescription_id']},
                                                orderby='order by create_date desc')
        if reward_id:
            del_transaction = self.query_ex.execute_delete_query(
                reward_id['id'], 'rewardtransaction')
            self.log.debug("Deleted from the reward transaction")
        else:
            self.cb.mutate_in(res['id'], SD.upsert('claims_reconciliation_error',
                                                   'Did not found the prescription in reward_transaction'))
            self.log.debug(f"Record does not exists in rewardtransaction for prescriprion_id "
                           f":{res['prescription_id']}")
        self.log.debug(
            f"Finished processing for the claim : {transaction_id}")

    def post_process_b2_reject(self, presc_obj, res, transaction_id):

        self.cb.mutate_in(presc_obj['id'],
                          SD.upsert('rx_status', 'Routed'))
        self.log.debug(f"Updated the prescription to Filled status : "
                       f"{presc_obj['id']}")

    @tracer.wrap()
    def process_response_claim(self, request_data, type):
        span = tracer.current_span()
        span.set_tag(ANALYTICS_SAMPLE_RATE_KEY, True)
        self.log = logging.getLogger()

        if type.lower() == 'erx':
            self.log.debug("Inside the response api process ")
            request_data = json.loads(request_data.decode(
                "utf-8"), encoding="utf-8", strict=False)
            self.request_data = request_data['contents']
            self.transactionid = request_data['transactionid']
            self.log.debug(
                "Received the request with transaction_di: {}".format(self.transactionid))
        else:
            self.request_data = request_data.decode("utf-8")
        self.log.debug("Converting the saved claim to encrypted format")

        self.ecrypted_request_data = self.encrypt(self.request_data.encode())
        self.get_data(request_data)
        Thread(target=self.save_claim, args=(
            self.parsedclaim, self.transactionid)).start()

        if type.lower() == 'erx':
            responseformat = 'json'
            response = json.dumps(
                {'contents': self.request_data, 'transactionid': self.transactionid})
            return response, responseformat
