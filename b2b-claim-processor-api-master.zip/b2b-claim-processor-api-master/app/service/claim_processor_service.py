import base64
import json
import logging
import re
from datetime import datetime, timedelta
import time
from collections import ChainMap

import ddtrace
import pandas as pd
from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA
import couchbase.subdocument as SD

from app.models.b1_claim_request import B1ClaimRequest
from app.models.b1_claim_response import B1ClaimResponse
from app.models.b2_claim_request import B2ClaimRequest
from app.models.b2_claim_response import B2ClaimResponse
from app.utility.bootstrap import OptionalModules
from app.utility.twilio_send_sms import SendSms


class ClaimProcessor(object):

    def __init__(self, config, claimobj, claimdataprovobj, validationobj, deductibleinfoobj=None):
        self.requestdata = ''
        self.claimobj = claimobj
        self.claimdataprovobj = claimdataprovobj
        self.validationobj = validationobj
        self.config = config
        self.requesttype = ''
        self.otherinfo = {}
        self.durg_formulary_data = {}
        self.rxplan_master_data = {}
        self.deductibleinfoobj = deductibleinfoobj
        self.module_invalid = False
        self.requestdata = ''
        self.transactionid = ''
        self.cb = self.config.cb

    def _prepare_response(self, info, req_type, domain_flags):
        self.claimobj.ClaimResponse = self.claimobj.ClaimResponse.setAttributes()
        encryptedresponseString = self.encrypt(
            self.claimobj.ClaimResponse.responseString.encode())
        # should be inside if claimrequest is not None, else self.claimkey will be undefined
        self.claimdataprovobj.updateIntent(self.claimkey, {
            'claim_response': self.claimobj.ClaimResponse.responseclaim, 'responseData': encryptedresponseString,
            'endDate': datetime.now().isoformat()})

        claimtransferresponse = self.claimTransfer(req_type, domain_flags)
        if claimtransferresponse:
            response, responseformat = self.send_response(
                claimtransferresponse, req_type)
            return response, responseformat, info
        finalresponse = self.claimobj.ClaimResponse.responseString
        response, responseformat = self.send_response(finalresponse, req_type)
        self.log.debug(f"Printing info {info}")

        return response, responseformat, info

    def adjudicateClaim(self, requestdata, req_type):

        self.module_invalid = False
        self.claimobj.createDate = datetime.now().isoformat()
        self.claimobj.updateDate = datetime.now().isoformat()
        self.claimobj.startDate = datetime.now().isoformat()
        self.otherinfo = {}
        self.transactionid = ''
        self.requesttype = ''
        covered_drugs = {}
        self.log = logging.getLogger()
        self.log.debug("Inside Adjudicate Claim")
        if req_type.lower() == 'erx':
            self.log.debug("Request received from user: {}".format(req_type))
            self.log.debug(
                "Claim data received from user: {}".format(requestdata))
            requestdata = json.loads(
                requestdata, encoding="utf-8", strict=False)
            self.requestdata = requestdata['contents']
            self.transactionid = requestdata['transactionid']
            self.log.debug(
                "Transaction ID for the claim received: {}".format(self.transactionid))
        else:
            self.requestdata = requestdata.decode("utf-8")

        self.claimobj.requestData = self.encrypt(self.requestdata.encode())

        try:
            self.requesttype = self.requestdata[8:10]
            # self.__log.info('Transaction type is %s', self.requesttype)
        except Exception as e:
            # self.__log.info('Could not determine transaction type')
            self.log.debug("Error getting request type: {}".format(e))
            pass

        if self.requesttype == 'B1':
            self.log.debug(
                "Request received is of {} type".format(self.requesttype))
            self.claimobj.ClaimRequest = B1ClaimRequest(
                self.requestdata).setAttributes()
            self.log.debug("Finished extracting data from the raw claim")

        elif self.requesttype == 'B2':
            self.log.debug(
                "Request received is of {} type".format(self.requesttype))
            self.claimobj.ClaimRequest = B2ClaimRequest(
                self.requestdata).setAttributes()

        self.otherinfo = {'intent_absent': False, 'prescription': {}, 'rejectioncode': '', 'rejectionreason': '',
                          'message': '', 'responsetype': '', 'gpi': '', 'brand_generic': '', 'drug_name': ''}
        domain_flags = {}

        if self.claimobj.ClaimRequest != None:
            strt_time = time.time()
            response, responseformat = self.setAdditionalFields(
                self.claimobj, req_type)
            total_time = time.time() - strt_time
            self.log.debug(
                f"total time taken for additional fields {total_time}")
            self.otherinfo['flipt_person_id'] = self.claimobj.ClaimRequest.insuranceseg.cardholder_id

            # domain_flags = {}
            flattenclaim = {}
            flattenclaim['claim_request'] = {}
            for mainkey, mainvalue in self.claimobj.ClaimRequest.parsedclaim.items():
                if mainkey == 'claim_request':
                    for ck, cv in mainvalue.items():
                        flattenclaim['claim_request'].update(cv)
                else:
                    flattenclaim[mainkey] = mainvalue

            self.claimkey = self.claimdataprovobj.saveClaim(flattenclaim)

            if 'prescription_id' in self.otherinfo['prescription']:
                self.claimdataprovobj.updateIntent(
                    self.claimkey, {'prescription_id': self.otherinfo['prescription']['prescription_id']})
            if not self.module_invalid:
                self.log.debug("Starting data validation")
                self.otherinfo['rejectioncode'], self.otherinfo['rejectionreason'] = self.validationobj.validateData(
                    self.claimobj.ClaimRequest, self.otherinfo["ndc_info"], False)

                self.log.debug("Finished data validation process")
            if self.otherinfo['rejectioncode']:
                self.module_invalid = True

            if self.requesttype == 'B1':

                self.log.debug("Checking member eligibility process")

                usereligibility_result = self.userEligibilityCheck()
                self.log.debug("Finished member eligibility process")
                try:
                    domain_flags = self.claimdataprovobj.getDomainFlags(
                        usereligibility_result['domain'])
                    self.otherinfo['phone'] = domain_flags['phone']
                except Exception as _:
                    pass
                if usereligibility_result.get('user', {}):
                    date_of_service = datetime.strftime(
                        datetime.strptime(self.claimobj.ClaimRequest.header.date_of_service, '%Y%m%d'), '%Y-%m-%d')+'T'+datetime.now().time().isoformat()

                    self.claimdataprovobj.get_rxplan_master_info({
                        'domain_name': usereligibility_result.get('domain',''),
                        'plan_name': usereligibility_result.get('benefit-plan-name',''),
                        'date_of_service': date_of_service
                    })
                    self.otherinfo["rxplan_info"] = self.claimdataprovobj.rxplan_info



                self.log.debug("Starting over-ride check")
                overrideresponse, ovrriderespformat, updates = self.overrideCheck(domain_flags, usereligibility_result,
                                                                                  self.claimkey, req_type)
                if overrideresponse:
                    return overrideresponse, ovrriderespformat, [updates, domain_flags, self, usereligibility_result]
                self.log.debug("Finished over-ride check")

                if usereligibility_result.get('user', {}) and not self.module_invalid:
                    self.log.debug("Checking to see if the drug is otc or not")
                    over_the_counter = OptionalModules.over_the_counter()
                    self.log.debug("Getting drug information by ndc id")
                    if not self.otherinfo['ndc_info'].get('gpi'):
                        self.log.debug(
                            "Drug is not covered and cannot be dispensed")
                        info = [{}, domain_flags, self, usereligibility_result]
                        self.otherinfo["rejectioncode"] = "70"
                        self.otherinfo["rejectionreason"] = "Product/Service Not Covered."
                        self.claimobj.ClaimResponse = B1ClaimResponse(
                            self.claimobj, self.otherinfo)
                        return self._prepare_response(info, req_type, domain_flags)

                    current_eligibility = usereligibility_result['user']

                    self.log.debug("Checking to see if the drug is otc or not")
                    
                    is_otc_covered = over_the_counter.is_otc_drug_covered(
                        drug={
                            'otc_indicator': self.otherinfo['ndc_info']['otc_indicator']},
                        rxplan_master=self.otherinfo["rxplan_info"],
                        formulary=self.otherinfo["formulary_info"])

                    if not is_otc_covered:
                        info = [{}, domain_flags, self, usereligibility_result]
                        self.otherinfo["rejectioncode"] = "70"
                        self.otherinfo["rejectionreason"] = "OTC drugs is not covered."
                        self.claimobj.ClaimResponse = B1ClaimResponse(
                            self.claimobj, self.otherinfo)
                        self.module_invalid = True
                        return self._prepare_response(info, req_type, domain_flags)

                    covered_drugs = self.drug_covered(
                        usereligibility_result, self.otherinfo["formulary_info"], self.otherinfo["rxplan_info"])
                    if covered_drugs['drug_covered'] == covered_drugs['drug_dispensed'] == False:
                        self.log.debug(
                            "Drug is not covered and cannot be dispensed")
                        info = [{}, domain_flags, self, usereligibility_result]
                        self.otherinfo["rejectioncode"] = "70"
                        self.otherinfo["rejectionreason"] = "Product/Service Not Covered."
                        self.claimobj.ClaimResponse = B1ClaimResponse(
                            self.claimobj, self.otherinfo)
                        self.module_invalid = True
                        return self._prepare_response(info, req_type, domain_flags)
                    self.log.debug(f"Is drug covered {covered_drugs}")

                self.log.debug("Starting Plan eligibility")
                self.planEligibilityCheck(domain_flags, usereligibility_result)
                self.log.debug("Finished plan eligibility check")
                self.log.debug("Starting prescriber restriction check")
                self.prescriberRestrictionCheck(domain_flags)
                self.log.debug("Finished prescriber restriction check")
                self.log.debug("Starting intent check process")

                intent_result = self.intentCheck(
                    domain_flags, usereligibility_result, False)
                self.log.debug("Finished intent check process")

                self.log.debug("Starting refill check process")
                self.refillCheck()
                self.log.debug("Finished refill check process")
                info = [{}, domain_flags, self, usereligibility_result]
                temp = self.otherinfo['prescription']
                if self.otherinfo['rejectionreason'] in ['','Prior Authorization In Process']:
                    if intent_result['result'] == 'True' or self.otherinfo.get('responsetype', '') == 'Duplicate':
                        updates = self.quantityDifferenceCheck(
                            usereligibility_result, domain_flags)
                    updates = self.drugCostCompare(
                        updates, usereligibility_result, domain_flags)
                    info = [updates, domain_flags,
                            self, usereligibility_result]
                self.otherinfo['prescription'].update(updates)
                self.log.debug("B1 response")
                self.claimobj.ClaimResponse = B1ClaimResponse(
                    self.claimobj, self.otherinfo)
                self.otherinfo['prescription'].update(temp)

            elif self.requesttype == 'B2':
                if self.otherinfo['prescription']:
                    domain_flags = self.claimdataprovobj.getDomainFlags(
                        self.otherinfo['prescription']['domain'])
                    self.otherinfo['phone'] = domain_flags['phone']
                else:
                    domain_flags = {}
                info = [{}, domain_flags, self, {}]

                temp = self.otherinfo['prescription']
                self.log.debug("B2 response")
                self.claimobj.ClaimResponse = B2ClaimResponse(
                    self.claimobj, self.otherinfo)

        self.log.debug("preparing response")
        self.claimobj.ClaimResponse = self.claimobj.ClaimResponse.setAttributes()
        encryptedresponseString = self.encrypt(
            self.claimobj.ClaimResponse.responseString.encode())
        # should be inside if claimrequest is not None, else self.claimkey will be undefined
        self.claimdataprovobj.updateIntent(self.claimkey, {'claim_response': self.claimobj.ClaimResponse.responseclaim,
                                                           'responseData': encryptedresponseString,
                                                           'endDate': datetime.now().isoformat()})

        claimtransferresponse = self.claimTransfer(req_type, domain_flags)
        if claimtransferresponse:
            response, responseformat = self.send_response(
                claimtransferresponse, req_type)
            return response, responseformat, info
        finalresponse = self.claimobj.ClaimResponse.responseString
        response, responseformat = self.send_response(finalresponse, req_type)

        return response, responseformat, info

    def send_response(self, response_data, req_type):

        if req_type.lower() == 'erx':
            response = '{"contents": "' + response_data + \
                       '", "transactionid": "' + self.transactionid + '"}'
            responseformat = 'json'

        else:
            responseformat = 'text'
            response = response_data

        return response, responseformat

    def encrypt(self, data):
        try:

            self.log.debug("Getting the public key from env variable")
            fd = open("/run/secrets/incoming_claims.pem", "rb")
            # fd = open("public.pem", "rb")
            public_key = fd.read()
            fd.close()
            publickey = RSA.importKey(public_key)
            publickey = PKCS1_OAEP.new(publickey)
            encrypted_msg = publickey.encrypt(data)
            encoded_encrypted_msg = base64.b64encode(encrypted_msg)
            return encoded_encrypted_msg.decode('utf-8')
        except Exception as e:
            self.log.debug('String encryption error')
            return ""

    def setAdditionalFields(self, claimobj, req_type):
        self.log.debug(
            "Adding additional fields to the request claim in setAdditonalFields")

        if claimobj.ClaimRequest.claimsseg.product_id:
            claimobj.ClaimRequest.claimsseg.product_id = str(
                claimobj.ClaimRequest.claimsseg.product_id).zfill(11)
            claimobj.ClaimRequest.parsedclaim['claim_request']['claims_segment']['product_id'] = str(
                claimobj.ClaimRequest.claimsseg.product_id).zfill(11)

        if claimobj.ClaimRequest.compoundseg.ingredient_component_count or claimobj.ClaimRequest.claimsseg.compound_code == '2':
            claimobj.ClaimRequest.claimsseg.product_id = str('0').zfill(11)
            claimobj.ClaimRequest.claimsseg.quantity_dispensed = '1'
            claimobj.ClaimRequest.claimsseg.product_id_qualifier = '03'
            claimobj.ClaimRequest.parsedclaim['claim_request']['claims_segment']['product_id'] = str(
                claimobj.ClaimRequest.claimsseg.product_id).zfill(11)
            claimobj.ClaimRequest.parsedclaim['claim_request']['claims_segment']['product_id_qualifier'] = '03'
            claimobj.ClaimRequest.parsedclaim['claim_request']['claims_segment']['quantity_dispensed'] = str(
                claimobj.ClaimRequest.claimsseg.quantity_dispensed)
        self.log.debug(
            "Additional fields processed ingredient_component_count")
        ndc_info = self.claimdataprovobj.getGPI(
            self.claimobj.ClaimRequest.claimsseg.product_id)
        if not ndc_info:
            self.otherinfo["rejectioncode"] = "70"
            self.otherinfo["rejectionreason"] = "Product/Service Not Covered."
            self.claimobj.ClaimResponse = B1ClaimResponse(
                self.claimobj, self.otherinfo)
            self.claimobj.ClaimResponse = self.claimobj.ClaimResponse.setAttributes()
            finalresponse = self.claimobj.ClaimResponse.responseString
            response, responseformat = self.send_response(
                finalresponse, req_type)
            return response, responseformat
        self.otherinfo["ndc_info"] = ndc_info
        self.claimobj.ClaimRequest.parsedclaim['claim_request'][
            'claims_segment']['gpi'] = self.otherinfo["ndc_info"]["gpi"]
        self.claimobj.transactionId = self.transactionid

        self.log.debug("Additional fields processed getGPI")
        self.detectDuplicateClaims()
        self.log.debug("Processed detectDuplicateClaims")

        additional_fields = ['auth_id', 'sequenceNumber', 'startDate',
                             'createDate', 'updateDate', 'type', 'requestData', 'transactionId']
        for field in additional_fields:
            claimobj.ClaimRequest.parsedclaim.update(
                {field: self.claimobj.__dict__[field]})
        self.log.debug("Finished processing get additional fields")
        return '', ''

    def userEligibilityCheck(self):
        if self.requesttype in ['B2']:
            return {}
        cardholderid = self.claimobj.ClaimRequest.insuranceseg.cardholder_id
        lastname = self.claimobj.ClaimRequest.insuranceseg.cardholder_last_name
        firstname = self.claimobj.ClaimRequest.insuranceseg.cardholder_first_name
        gender = self.claimobj.ClaimRequest.patientseg.patient_gender_code
        try:
            dob = datetime.strptime(self.claimobj.ClaimRequest.patientseg.date_of_birth, '%Y%m%d'). \
                strftime('%Y-%m-%d 00:00:00')
            dos = datetime.strptime(self.claimobj.ClaimRequest.header.date_of_service, '%Y%m%d'). \
                strftime('%Y-%m-%d')
        except Exception as _:
            dob = ''
            dos = ''

        if self.claimobj.ClaimRequest.patientseg.patient_last_name:
            lastname = self.claimobj.ClaimRequest.patientseg.patient_last_name
            firstname = self.claimobj.ClaimRequest.patientseg.patient_first_name
        elig_obj = OptionalModules.userelig(card_holder_id=cardholderid,
                                            last_name=lastname,
                                            date_of_birth=dob,
                                            date_of_service=dos,
                                            gender=gender,
                                            first_name=firstname)

        try:
            result = elig_obj.is_eligible()
        except Exception as ex:
            result = {'result': 'false', 'return-code': '65',
                      'message': 'Patient is not Covered'}

        if result['message'] != 'success':
            self.module_invalid = True
            self.otherinfo['rejectioncode'] = result['return-code']
            self.otherinfo['rejectionreason'] = result['message']
        if result.get('user', {}):
            if result['user'].get('rx_member_id', '') and result['user'].get('rx_member_id',
                                                                             '') != self.claimobj.ClaimRequest.insuranceseg.cardholder_id:
                self.log.debug(
                    "Cardholder ID different from patient ID")
                member_id_update = {}
                if result['user'].get('tpa_member_id', '') == self.claimobj.ClaimRequest.insuranceseg.cardholder_id:
                    member_id_update = {'claim_request.cardholder_id': result['user'].get(
                        'rx_member_id', ''),
                        'claim_request.tpa_member_id': self.claimobj.ClaimRequest.insuranceseg.cardholder_id}
                else:
                    member_id_update = {'claim_request.cardholder_id': result['user'].get(
                        'rx_member_id', ''),
                        'claim_request.original_cardholder_id': self.claimobj.ClaimRequest.insuranceseg.cardholder_id}
                self.claimobj.ClaimRequest.insuranceseg.cardholder_id = result['user'].get(
                    'rx_member_id', '')
                self.claimdataprovobj.updateIntent(
                    self.claimkey, member_id_update)

        return result

    def refillCheck(self):

        if (self.module_invalid and self.otherinfo['rejectionreason'] != 'Prior Authorization In Process') or self.requesttype in ['B2'] or self.otherinfo['responsetype'] == 'Duplicate':
            return

        self.log.debug("refill check")

        patientid = self.claimobj.ClaimRequest.insuranceseg.cardholder_id

        refill_chk = OptionalModules.refillvalid(gpi=self.otherinfo['gpi'],
                                                 cardholder_id=patientid,
                                                 drug_name=self.otherinfo['drug_name'],
                                                 brand_generic=self.otherinfo['brand_generic'],
                                                 intents=self.otherinfo.get('intent_data', []))

        result = refill_chk.is_refill_valid()

        if not result['status']:
            self.module_invalid = True
            self.otherinfo['rejectioncode'] = result['rejectioncode']
            self.otherinfo['rejectionreason'] = result['rejectionreason']
            self.otherinfo['message'] = result['message']
        else:
            self.otherinfo['days_of_supply'] = result['days_of_supply']

    def overrideCheck(self, domain_flags, userresult, claimkey, req_type):

        invalid_override_rejections = ['Missing/Invalid Refill Number',
                                       'Missing or Invalid Associated Prescription/Service Reference Number']

        if self.requesttype in ['B2'] or self.otherinfo['rejectionreason'] in invalid_override_rejections:
            return '', '', {}
        domain_flags['override_flag'] = 'Y'

        if 'override_flag' in domain_flags and domain_flags['override_flag'] == 'Y':

            patientid = self.claimobj.ClaimRequest.insuranceseg.cardholder_id
            if self.claimobj.ClaimRequest.patientseg.patient_id:
                patientid = self.claimobj.ClaimRequest.patientseg.patient_id

            ocobj = OptionalModules.overridecheck(
                date_of_service=self.claimobj.ClaimRequest.header.date_of_service,
                product_id=self.claimobj.ClaimRequest.parsedclaim[
                    'claim_request']['claims_segment']['gpi'],
                presc_ref_num=self.claimobj.ClaimRequest.claimsseg.prescription_reference_number,
                fill_num=self.claimobj.ClaimRequest.claimsseg.fill_number,
                service_provider_id=self.claimobj.ClaimRequest.header.service_provider_id)

            paobj = OptionalModules.paoverridecheck(
                date_of_service=self.claimobj.ClaimRequest.header.date_of_service,
                gpi=self.otherinfo['ndc_info']['gpi'],
                drug_name=self.otherinfo['ndc_info']['drug_name'],
                brand_generic=self.otherinfo['ndc_info']['brand_generic'],
                flipt_person_id=userresult.get(
                    'user', {}).get('rx_flipt_person_id', ''),
                plan_name=userresult.get('user', {}).get(
                    'benefit_plan_name', ''),
                domain=userresult.get('user', {}).get('domain_name', '')
            )

            result = paobj.is_pa_overridden()
            formulary = result['formularyinfo']
            if formulary.get('formulary_info',{}):
                self.otherinfo.update(
                    {'formulary_info': formulary['formulary_info']})
                if 'alternative_formulary' in formulary:
                    self.otherinfo.update(
                        {'alternative_formulary': formulary['alternative_formulary']})
            else:
                self.otherinfo.update(
                {'formulary_info': {}})

            if not result['result']:
                result = ocobj.get_over_ride_info()

            if result['result'] and self.requesttype == 'B1':
                if self.otherinfo['prescription']:
                    result['prescription_id'] = self.otherinfo['prescription']['prescription_id']
                    self.claimdataprovobj.updateIntent(result['prescription_id'], {
                        'rx_status': 'Routed', 'pa_flag': 'N'})

                self.module_invalid = False
                try:
                    self.intentCheck(domain_flags, userresult, True)
                except Exception as _:
                    self.log.debug(
                        "Intent check error - override check")
                self.otherinfo['rejectionreason'] = ''
                self.otherinfo['rejectioncode'] = ''
                self.module_invalid = False

                if self.requesttype == 'B1':

                    self.log.debug(
                        "Calling quantity difference check from over ride check service layer")
                    updates = self.quantityDifferenceCheck(
                        userresult, domain_flags)
                    self.otherinfo['prescription'].update(updates)
                    if 'payment_option' not in self.otherinfo['prescription']:
                        self.otherinfo['prescription']['payment_option'] = 'Pay at Pharmacy'
                    if self.otherinfo['prescription']['payment_option'] != 'Pay via Payroll Deduction':
                        try:
                            if not self.otherinfo['prescription'].get('drug_cost',0):
                                self.log.debug('Override: no drug cost calculated')
                                if self.claimobj.ClaimRequest.pricingseg.gross_amount_due:
                                    self.otherinfo['prescription'][
                                        'drug_cost'] = self.claimobj.ClaimRequest.pricingseg.gross_amount_due
                                if self.claimobj.ClaimRequest.pricingseg.usual_and_customary_charge:
                                    if float(self.otherinfo['prescription']['drug_cost']) > 0:
                                        self.otherinfo['prescription']['drug_cost'] = min(float(
                                            self.claimobj.ClaimRequest.pricingseg.usual_and_customary_charge),
                                            float(self.otherinfo['prescription']['drug_cost']))
                                    else:
                                        self.otherinfo['prescription'][
                                            'drug_cost'] = self.claimobj.ClaimRequest.pricingseg.usual_and_customary_charge
                                if self.claimobj.ClaimRequest.pricingseg.ingredient_cost_submitted:
                                    if float(self.otherinfo['prescription']['drug_cost']) > 0:
                                        self.otherinfo['prescription']['drug_cost'] = min(float(
                                            self.claimobj.ClaimRequest.pricingseg.ingredient_cost_submitted),
                                            float(self.otherinfo['prescription']['drug_cost']))
                                    else:
                                        self.otherinfo['prescription'][
                                            'drug_cost'] = self.claimobj.ClaimRequest.pricingseg.ingredient_cost_submitted
                                self.log.debug('Override drug cost: '+str(self.otherinfo["prescription"].get("drug_cost",0)))
                                self.otherinfo['prescription']['drug_cost'] = self.otherinfo['prescription'][
                                    'drug_cost'] + float(
                                    self.claimobj.ClaimRequest.pricingseg.dispensing_fee_submitted)
                                self.otherinfo['prescription'][
                                    'pharmacy_dispensing_fee'] = self.claimobj.ClaimRequest.pricingseg.dispensing_fee_submitted
                                self.otherinfo['prescription']['employee_opc'] = self.otherinfo['prescription']['drug_cost']
                        except Exception as _:
                            pass
                    try:
                        if result['override_percentage']:
                            self.otherinfo['prescription']['employee_opc'] = float(
                                self.otherinfo['prescription']['drug_cost']) * (float(
                                    result['override_percentage']) / 100.0)
                        elif result['override_amount']:
                            self.otherinfo['prescription']['employee_opc'] = float(
                                float(result['override_amount']))
                        self.otherinfo['prescription']['employer_cost'] = max(0, (
                            float(self.otherinfo['prescription']['drug_cost']) -
                            float(self.otherinfo['prescription']['employee_opc'])))
                    except Exception as _:
                        pass
                    if not self.otherinfo['prescription'].get('bin',''):
                        self.otherinfo['prescription']['bin']=self.claimobj.ClaimRequest.header.bin_number
                        self.otherinfo['prescription']['pcn']=self.claimobj.ClaimRequest.header.processor_control_number

                    self.claimobj.ClaimResponse = B1ClaimResponse(
                        self.claimobj, self.otherinfo)
                    self.claimobj.ClaimResponse = self.claimobj.ClaimResponse.setAttributes()
                    encryptedresponseString = self.encrypt(
                        self.claimobj.ClaimResponse.responseString.encode('utf-8'))
                    claimtransferresponse = self.claimTransfer(
                        req_type, domain_flags)

                    self.claimdataprovobj.updateIntent(claimkey, {
                        'claim_response': self.claimobj.ClaimResponse.responseclaim,
                        'responseData': encryptedresponseString})
                    if 'prescription_id' in self.otherinfo['prescription']:
                        self.claimdataprovobj.updateIntent(self.otherinfo['prescription']['prescription_id'], {
                            'override_amount': result['override_amount'],
                            'override_percentage': result['override_percentage'], 'rx_status': 'Filled',
                            'filled_date': datetime.now().isoformat()})

                    response, responseformat = '', ''

                    if claimtransferresponse:
                        response, responseformat = self.send_response(
                            claimtransferresponse, req_type)
                    else:
                        response, responseformat = self.send_response(
                            self.claimobj.ClaimResponse.responseString, req_type)

                    updates['override'] = 'Y'

                    return response, responseformat, updates
        return '', '', {}

    def planEligibilityCheck(self, domain_flags, userresult):

        if self.module_invalid or self.requesttype in ['B2']:
            return
        prescriber_restriction_flag = self.claimdataprovobj.getPrescriberRestrictionFlag(
            [userresult['domain'], userresult['benefit-plan-name'], userresult['plan-year']])

        if prescriber_restriction_flag == 'Y':
            pln_elg = OptionalModules.planelig(
                prescriber_id=self.claimobj.ClaimRequest.prescriberseg.prescriber_id)
            if pln_elg.is_prescriber_restricted():
                self.module_invalid = True
                self.otherinfo['rejectioncode'] = 'dummycode_plan'
                self.otherinfo['rejectionreason'] = 'dummyreason_plan'

    def prescriberRestrictionCheck(self, domain_flags):

        if self.module_invalid or self.requesttype in ['B2']:
            return

        if 'validate_prescriber' in domain_flags and domain_flags['validate_prescriber'] == 'Y':
            valid_prscbr = OptionalModules.prescvalid(
                prescriber_id=self.claimobj.ClaimRequest.prescriberseg.prescriber_id)

            if not valid_prscbr.is_prescriber_active():
                self.module_invalid = True
                self.otherinfo['rejectioncode'] = '56'
                self.otherinfo['rejectionreason'] = 'Prescribing Physician License Number not on File'

    def intentCheck(self, domain_flags, usereligibilityresult, override):

        if self.module_invalid or self.requesttype in ['B2']:
            return {'result':'False'}

        self.log.debug("intent check")

        patientid = self.claimobj.ClaimRequest.insuranceseg.cardholder_id

        intent_chk = OptionalModules.intentvalid(
            service_provider_id=self.claimobj.ClaimRequest.header.service_provider_id,
            gpi=self.otherinfo['ndc_info']['gpi'],
            cardholder_id=patientid,
            drug_name=self.otherinfo['ndc_info']['drug_name'],
            brand_generic=self.otherinfo['ndc_info']['brand_generic'])

        result = intent_chk.is_intent_present()
        self.otherinfo.update({'intent_data': result.get('intents', [])})

        if result['result'] == 'False':
            self.otherinfo['intent_absent'] = True
            autoerxobj = OptionalModules.autoerxlite(
                claimprocobj=self, user_info=usereligibilityresult, domain_flags=domain_flags, override=override)
            autoerxliteresult = autoerxobj.getERxLite()
            self.otherinfo['prescription'].update(autoerxliteresult)

            if not autoerxliteresult['rejection_reason']:
                self.otherinfo['intent_absent'] = False
            if autoerxliteresult['rejection_reason'] == 'PA drug':
                self.otherinfo['rejectioncode'] = '3W'
                self.otherinfo['rejectionreason'] = 'Prior Authorization In Process'
            elif autoerxliteresult['rejection_reason'] == 'Unit Price Not Found':
                self.module_invalid = True
                self.otherinfo['rejectioncode'] = '70'
                self.otherinfo['rejectionreason'] = 'Product/Service Not Covered'
        else:
            if 'status' in result and result['status'] == 'PA':
                self.otherinfo['rejectioncode'] = '3W'
                self.otherinfo['rejectionreason'] = 'Prior Authorization In Process'
            self.otherinfo['prescription'].update(
                self.claimdataprovobj.getIntentData(result['prescription_id']))
            if self.otherinfo['prescription']['payment_option'] == 'Pay via Payroll Deduction':
                self.otherinfo['prescription']['employee_opc'] = '0'
            self.claimdataprovobj.updateIntent(
                self.claimkey, {'prescription_id': result['prescription_id']})
            print(result['prescription_id'], result['status'], 'intent found')

        # print(self.otherinfo['prescription'])
        return result

    def quantityDifferenceCheck(self, result, domain_flags):

        try:
            self.log.debug("Inside quantity diff check")
            prescription_quantity = float(self.otherinfo['prescription']['package_size']) * \
                int(self.otherinfo['prescription']['package_quantity'])
            dispensed_quantity = float(
                self.claimobj.ClaimRequest.claimsseg.quantity_dispensed)
            self.log.debug(
                "Total quantity dispensed : {}".format(dispensed_quantity))
            if int(prescription_quantity) == int(dispensed_quantity) and self.otherinfo.get('responsetype', '') == 'Duplicate' and self.otherinfo.get('duplicate_response', {}):
                if self.otherinfo['prescription'].get('prescription_id', ''):
                    self.otherinfo['prescription'].update(
                        self.claimdataprovobj.getIntentData(str(self.otherinfo['prescription'].get('prescription_id', ''))))
                self.otherinfo['prescription']['employee_opc'] = self.otherinfo['duplicate_response']['patient_pay_amount']
                self.otherinfo['prescription']['pharmacy_dispensing_fee'] = self.otherinfo['duplicate_response']['dispensing_fee_paid']
                self.otherinfo['prescription']['drug_cost'] = float(
                    self.otherinfo['duplicate_response']['patient_pay_amount']) + float(self.otherinfo['duplicate_response']['total_amount_paid'])
            elif prescription_quantity != dispensed_quantity:

                self.log.debug("Prescription quantity {} is different from dispensed quantity {}".format(
                    prescription_quantity, dispensed_quantity))
                autoerxobj = OptionalModules.autoerxlite(
                    claimprocobj=self, domain_flags=domain_flags)
                self.otherinfo['prescription'].update(
                    {'dispensed_qty': float(self.claimobj.ClaimRequest.claimsseg.quantity_dispensed),
                     'plan_name': result['benefit-plan-name'],
                     'npi': self.claimobj.ClaimRequest.header.service_provider_id})
                autoerxliteresult = autoerxobj.recalculatePrices(
                    info=self.otherinfo['prescription'], drug_cost=0)
                if autoerxliteresult['rejection_reason']:
                    return {}
                update_data = {'employee_opc': autoerxliteresult['employee_opc'],
                               'drug_cost': autoerxliteresult['drug_cost'],
                               'employer_cost': autoerxliteresult['employer_cost'],
                               'dispensed_qty': str(float(self.claimobj.ClaimRequest.claimsseg.quantity_dispensed)),
                               'drug_copay': autoerxliteresult['copay'],
                               'orig_employee_opc': self.otherinfo['prescription']['employee_opc'],
                               'orig_drug_cost': self.otherinfo['prescription']['drug_cost'],
                               'orig_employer_cost': self.otherinfo['prescription']['employer_cost'],
                               'orig_drug_copay': self.otherinfo['prescription']['drug_copay'],
                               'original_employee_opc': autoerxliteresult['original_employee_opc'],
                               'deductible_met': autoerxliteresult['deductible_met'],
                               'outofpocket_met': autoerxliteresult['outofpocket_met']}
                return update_data
        except Exception as e:
            self.log.debug("initial qty difference check {}".format(e))
            return {}

        return {}

    def drugCostCompare(self, updates, usereligibilityresult, domain_flags):

        if self.claimobj.ClaimRequest.claimsseg.product_id == '00000000000':
            return updates

        if 'orig_drug_cost' in updates:
            drug_cost = updates['drug_cost']
            employee_opc = updates['employee_opc']
        else:
            drug_cost = self.otherinfo['prescription']['drug_cost']
            employee_opc = self.otherinfo['prescription']['employee_opc']
        unc = self.claimobj.ClaimRequest.pricingseg.usual_and_customary_charge
        gross_amt = self.claimobj.ClaimRequest.pricingseg.gross_amount_due

        try:
            drug_cost = float(drug_cost)
        except Exception as _:
            drug_cost = 0
        try:
            unc = float(unc)
        except Exception as _:
            unc = drug_cost * 2
        try:
            gross_amt = float(gross_amt)
        except Exception as _:
            gross_amt = drug_cost * 2
        try:
            employee_opc = float(employee_opc)
        except Exception as _:
            employee_opc = 0
        mincost = min(gross_amt, unc)
        pricetype = ''
        if gross_amt < unc:
            mincost = gross_amt
            pricetype = 'GROSS DUE AMT'
        else:
            mincost = unc
            pricetype = 'U&C'
        self.log.debug(" cost compare - drug_cost: %s, employee_opc: %s, gross_amt: %s, unc: %s",
                       drug_cost, employee_opc, gross_amt, unc)

        if (mincost - drug_cost) < 0:
            autoerxobj = OptionalModules.autoerxlite(
                claimprocobj=self, domain_flags=domain_flags, user_info=usereligibilityresult)
            self.otherinfo['prescription'].update(
                {'dispensed_qty': float(self.claimobj.ClaimRequest.claimsseg.quantity_dispensed),
                 'plan_name': usereligibilityresult['benefit-plan-name'],
                 'npi': self.claimobj.ClaimRequest.header.service_provider_id,
                 'domain': usereligibilityresult['domain']})

            autoerxliteresult = autoerxobj.recalculatePrices(
                info=self.otherinfo['prescription'], drug_cost=mincost)
            if int(autoerxliteresult['employee_opc'] - employee_opc) <= 0:
                self.otherinfo['prescription']['drug_cost'] = str(mincost)
                self.otherinfo['prescription']['employer_cost'] = str(
                    autoerxliteresult['employer_cost'])
                self.otherinfo['prescription']['employee_opc'] = str(
                    autoerxliteresult['employee_opc'])
                self.otherinfo['prescription']['original_employee_opc'] = str(
                    autoerxliteresult['original_employee_opc'])
                self.otherinfo['prescription'].update({'deductible_met': autoerxliteresult['deductible_met'],
                                                       'outofpocket_met': autoerxliteresult['outofpocket_met']})
                self.otherinfo['prescription'].update(
                    {'price_type': pricetype})
                updates['pricing_changed'] = True
                self.log.debug("Pricing changed in cost comparison {}".format(
                    self.otherinfo['prescription']['employee_opc']))
                newcost = {'employee_opc': self.otherinfo['prescription']['employee_opc'], 'drug_cost': self.otherinfo[
                    'prescription']['drug_cost'], 'employer_cost': self.otherinfo['prescription']['employer_cost']}
                updates.update(newcost)
                if 'prescription_id' in self.otherinfo['prescription']:
                    self.claimdataprovobj.updateIntent(
                        self.otherinfo['prescription']['prescription_id'], newcost)
                if self.otherinfo['rejectionreason'] == 'Prior Authorization In Process' and autoerxliteresult[
                        'rejection_reason'] != 'PA drug' and self.otherinfo['prescription']['pa_flag'] == 'pa_cost':
                    self.otherinfo['rejectionreason'] = ''
                    self.otherinfo['rejectioncode'] = ''
        return updates

    def postProcessUpdate(self, small_updates, domain_flags, obj, usereligibilityresult, ctx):
        if ctx is not None:
            ddtrace.tracer.context_provider.activate(ctx)
        self.log.debug("post proc updates")
        if obj.module_invalid:
            return

        if obj.requesttype == 'B1':

            filled_date = datetime.now()
            phone = ''
            autoerx = None

            def getPhoneNumber():
                autoerx = OptionalModules.autoerx(
                    claimobj=obj, user_info=usereligibilityresult, domain_flag=domain_flags,
                    override=False)
                if not obj.claimobj.ClaimRequest.patientseg.patient_id:
                    autoerx.userinfoobj = autoerx.userinfoobj.setAttributes(
                        usereligibilityresult['user'], obj.claimobj.ClaimRequest.patientseg.patient_id)
                else:
                    autoerx.userinfoobj = autoerx.userinfoobj.setAttributes(
                        usereligibilityresult['user'], obj.claimobj.ClaimRequest.insuranceseg.cardholder_id)
                autoerx.signinobj = autoerx.signinobj.getUserToken(
                    autoerx.userinfoobj.user_id)
                autoerx.phone_number = autoerx.userinfoobj.getCommunicationPhone(
                    autoerx.signinobj.headers, autoerx.userinfoobj.flipt_person_id)
                phone = autoerx.phone_number
                return autoerx, phone

            def quantityDifferenceUpdate(updates, autoerx, phone):
                if 'orig_employee_opc' in updates:
                    autoerx.pharmacyinfoobj = autoerx.pharmacyinfoobj.setAttributes(
                        obj.claimobj.ClaimRequest.header.service_provider_id)
                    autoerx.druginfoobj = autoerx.druginfoobj.setAttributes(
                        obj.otherinfo['ndc_info'], updates['dispensed_qty'], True, '')
                    error_message, pricelist = autoerx.pricecalcobj.getPrices(
                        autoerx)

                    current_drug = pricelist.loc[pricelist['pharmacy_npi']
                                                 == autoerx.pharmacyinfoobj.npi]

                    if error_message != 'Success':
                        return

                    update_data = {'employee_opc': updates['employee_opc'], 'drug_cost': updates['drug_cost'],
                                   'employer_cost': updates['employer_cost'],
                                   'baseline_cost': current_drug['drug_baseline_price'].values[0],
                                   'pbm_price': current_drug['pbm_price'].values[0],
                                   'package_qty': autoerx.druginfoobj.package_qty,
                                   'package_quantity': autoerx.druginfoobj.package_quantity,
                                   'package_size': autoerx.druginfoobj.package_size,
                                   'quantity': autoerx.druginfoobj.quantity,
                                   'drug_copay': current_drug['drug_copay'].values[0],
                                   'rewards': current_drug["drug_reward"].values[0],
                                   'deductible_accumulator_amount': current_drug["deductible_accumulator_amount"].values[0],
                                   'oop_accumulator_amount': current_drug["oop_accumulator_amount"].values[0],
                                   'orig_employee_opc': updates['orig_employee_opc'],
                                   'orig_drug_cost': updates['orig_drug_cost'],
                                   'orig_baseline_cost': obj.otherinfo['prescription']['baseline_cost'],
                                   'orig_pbm_price': obj.otherinfo['prescription']['pbm_price'],
                                   'orig_package_qty': obj.otherinfo['prescription']['package_qty'],
                                   'orig_package_quantity': obj.otherinfo['prescription']['package_quantity'],
                                   'orig_package_size': obj.otherinfo['prescription']['package_size'],
                                   'orig_employer_cost': updates['orig_employer_cost'],
                                   'orig_quantity': obj.otherinfo['prescription']['quantity'],
                                   'orig_drug_copay': obj.otherinfo['prescription']['drug_copay'],
                                   'orig_rewards': obj.otherinfo['prescription']['rewards']}
                    if not ('pricing_changed' in updates and updates['pricing_changed']):
                        update_data.update(
                            {'employee_opc': current_drug['employee_opc'].values[0], 'drug_cost': current_drug[
                                'drug_price'].values[0], 'employer_cost': current_drug['drug_employer_cost'].values[0]})

                    obj.claimdataprovobj.updateIntent(
                        obj.otherinfo['prescription']['prescription_id'], update_data)
                    obj.otherinfo['prescription'].update(update_data)

                    if float(current_drug["drug_reward"].values[0]) > 0:
                        rewardid = obj.claimdataprovobj.getRewardData(
                            [obj.otherinfo['prescription']['prescription_id']])
                        obj.claimdataprovobj.updateIntent(rewardid, {
                            'reward_amount': current_drug["drug_reward"].values[0],
                            'update_date': datetime.now().isoformat()})
                    try:
                        if float(update_data['employee_opc']) != float(update_data['orig_employee_opc']) or float(
                                update_data['rewards']) != float(update_data['orig_rewards']):
                            message = "The quantity dispensed for " + obj.otherinfo['prescription'][
                                'drug_name'] + " is different than the quantity selected in your eRx. Your reward and co-pay has been adjusted accordingly. Your reward = $" + str(
                                update_data['rewards']) + ", Your Co-Pay = $" + str(update_data['employee_opc'])
                            obj.sendNotifications(obj.otherinfo['prescription']['domain'], message,
                                                  obj.otherinfo['prescription']['flipt_person_id'], phone, obj)

                    except Exception as e:
                        self.log.debug(
                            "final qty difference check {}".format(e))
                        pass
                    return update_data
                return {}

            def createAutoerx(updates):
                if 'prescription_id' not in obj.otherinfo['prescription'] and obj.otherinfo['rejectionreason'] in \
                        ['', 'Prior Authorization In Process', 'Product/Service Not Covered']:
                    self.log.debug("create auto-erx")
                    override = False
                    if 'override' in updates:
                        override = True
                    autoerxobj = OptionalModules.autoerx(
                        claimobj=obj, user_info=usereligibilityresult, domain_flag=domain_flags, override=override)
                    autoerxresult = autoerxobj.createIntent()

                    # print(autoerxresult)
                    if autoerxresult and autoerxresult['status'] == 'True' and autoerxresult['message'] == '':
                        obj.claimdataprovobj.updateIntent(
                            obj.claimkey, {'prescription_id': autoerxresult['prescription_id']})
                        obj.otherinfo['intent_absent'] = False
                        obj.otherinfo['prescription'].update(
                            obj.claimdataprovobj.getIntentData(autoerxresult['prescription_id']))
                        if obj.otherinfo['rejectionreason']:
                            return

                        try:
                            drug_cost_difference = int(autoerxresult['pricing']['drug_cost']) - int(
                                obj.otherinfo['prescription']['drug_cost'])
                            employee_opc_difference = int(autoerxresult['pricing']['employee_opc']) - int(
                                obj.otherinfo['prescription']['employee_opc'])

                            if abs(drug_cost_difference) > 0.5 or abs(employee_opc_difference) > 0.5:
                                costupdate = {
                                    'drug_cost_sent': obj.otherinfo['prescription']['drug_cost'],
                                    'employee_opc_sent': obj.otherinfo['prescription']['employee_opc'],
                                    'employer_cost_sent': obj.otherinfo['prescription']['employer_cost']}
                                obj.claimdataprovobj.updateIntent(
                                    autoerxresult['prescription_id'], costupdate)
                        except Exception as e1:
                            pass

                        obj.otherinfo['prescription'].update(
                            obj.claimdataprovobj.getIntentData(autoerxresult['prescription_id']))

            def insertReward(updates):
                self.log.debug("reward insert")
                if not float(obj.otherinfo['prescription']['rewards']) > 0:
                    return
                rewardtransaction = {}
                rewardtransaction['type'] = "rewardtransaction"
                rewardtransaction['create_date'] = filled_date.isoformat()
                rewardtransaction['created_by'] = obj.otherinfo['prescription']['flipt_person_id']
                rewardtransaction['flipt_person_id'] = obj.otherinfo['prescription']['rx_flipt_person_id']
                rewardtransaction['prescription_id'] = obj.otherinfo['prescription']['prescription_id']
                rewardtransaction['update_date'] = filled_date.isoformat()
                rewardtransaction['updated_by'] = obj.otherinfo['prescription']['flipt_person_id']
                rewardtransaction['domain'] = obj.otherinfo['prescription']['domain']
                rewardtransaction['reward_amount'] = obj.otherinfo['prescription']['rewards']
                rewardtransaction['reward_date'] = filled_date.isoformat()
                rewardtransaction['drug_name'] = obj.otherinfo['prescription']['drug_name']
                obj.claimdataprovobj.saveRewards(rewardtransaction)

            def upsertRxHistory(updates):
                self.log.debug("rx history updates")
                rxhistory = {}
                prescription_quantity = float(
                    obj.otherinfo['prescription']['package_size']) * float(
                    obj.otherinfo['prescription']['package_quantity'])
                dispensed_quantity = float(
                    obj.claimobj.ClaimRequest.claimsseg.quantity_dispensed)
                if prescription_quantity != dispensed_quantity and updates:
                    rxhistory['package_qty'] = updates['package_qty']
                    rxhistory['package_size'] = updates['package_size']
                    rxhistory['quantity'] = updates['quantity']
                    rxhistory['prescription_id'] = obj.otherinfo['prescription']['prescription_id']
                else:
                    rxhistory['package_qty'] = obj.otherinfo['prescription']['package_qty']
                    rxhistory['package_size'] = obj.otherinfo['prescription']['package_size']
                    rxhistory['quantity'] = obj.otherinfo['prescription']['quantity']
                    rxhistory['domain'] = obj.otherinfo['prescription']['domain']
                    rxhistory['rxcui'] = ''
                    rxhistory['type'] = 'rx_history'
                    rxhistory['flipt_person_id'] = obj.otherinfo['prescription']['rx_flipt_person_id']
                    rxhistory['ddid'] = obj.otherinfo['prescription']['ddid']
                    rxhistory['drug_name'] = obj.otherinfo['prescription']['drug_name']
                    rxhistory['gpi'] = obj.otherinfo['prescription']['gpi']
                    rxhistory['brandorgeneric'] = obj.otherinfo['prescription']['brand_generic']
                    rxhistory['form'] = obj.otherinfo['prescription']['dosage']
                    rxhistory['dosage_strength'] = obj.otherinfo['prescription']['dosage_strength']
                    if obj.otherinfo['prescription'].get('dosage_image'):
                        rxhistory['dosage_image'] = obj.otherinfo['prescription']['dosage_image']
                    rxhistory['equivalent_brand'] = obj.otherinfo['prescription']['equivalent_brand']
                    rxhistory['npi'] = obj.otherinfo['prescription']['npi']
                    rxhistory['start_date'] = filled_date.isoformat()
                    rxhistory['daysofsupply'] = str(
                        int(obj.claimobj.ClaimRequest.claimsseg.days_supply))
                    rxhistory['estimated_stop_date'] = (filled_date + timedelta(days=(int(
                        obj.claimobj.ClaimRequest.claimsseg.days_supply) - int(
                        domain_flags['quantity_restriction_buffer'])))).isoformat()
                    rxhistory['currently_taking_flag'] = 'Y'
                    rxhistory['pharmacy_name'] = obj.otherinfo['prescription']['pharmacy']
                    rxhistory['location'] = obj.otherinfo['prescription']['location']
                    rxhistory['ready_to_refill'] = 'N'
                    rxhistory['created_date'] = filled_date.isoformat()
                    rxhistory['updated_date'] = filled_date.isoformat()
                    rxhistory['created_by'] = obj.otherinfo['prescription']['flipt_person_id']
                    rxhistory['last_udpated_by'] = obj.otherinfo['prescription']['flipt_person_id']
                    rxhistory['prescription_id'] = obj.otherinfo['prescription']['prescription_id']
                docid = obj.claimdataprovobj.getRxhistoryData(
                    {'drug_name': obj.otherinfo['prescription']['drug_name'],
                     'gpi': obj.otherinfo['prescription']['gpi'],
                     'rx_flipt_person_id': obj.otherinfo['prescription']['rx_flipt_person_id']})
                obj.claimdataprovobj.saveRxHistoryData(docid, rxhistory)

            def fillIntent(updates):

                self.log.debug("fill intent")
                try:
                    pharmacy_type = obj.otherinfo['prescription']['pharmacy_type']
                except:
                    pharmacy_type = ''

                try:
                    available_fill_date = (filled_date + timedelta(days=(float(
                        self.claimobj.ClaimRequest.claimsseg.days_supply) * float(
                        domain_flags['claims_refill_consumption_pct']) / 100.0))).isoformat()
                except:
                    available_fill_date = ''
                fill_data = {'rx_status': "Filled",
                             'auth_id': obj.claimobj.auth_id,
                             'dispensed_qty': float(obj.claimobj.ClaimRequest.claimsseg.quantity_dispensed),
                             'patient_paid': float(obj.claimobj.ClaimResponse.__dict__['responseclaim']
                                                   ['claim_response']['patient_pay_amount']),
                             'filled_date': filled_date.isoformat(),
                             'update_date': filled_date.isoformat(),
                             'prescriber_npi': obj.claimobj.ClaimRequest.prescriberseg.prescriber_id,
                             'rx_number': obj.claimobj.ClaimRequest.claimsseg.prescription_reference_number,
                             'available_fill_date': available_fill_date,
                             'pharmacy_type': pharmacy_type}

                if updates and 'orig_employee_opc' not in updates:
                    fill_data.update(updates)

                try:
                    daysofsupply = int(
                        obj.claimobj.ClaimRequest.claimsseg.days_supply)
                    fill_data.update({'daysofsupply': daysofsupply})
                except Exception as e:
                    self.log.debug("fillIntent days of supply".format(e))
                    pass
                if 'filled_date' in obj.otherinfo['prescription']:
                    drugname, pharmacy = '', ''
                    if obj.otherinfo['prescription']['drug_name']:
                        drugname = 'for ' + \
                                   obj.otherinfo['prescription']['drug_name']
                    if obj.otherinfo['prescription']['pharmacy']:
                        drugname = 'at ' + \
                                   obj.otherinfo['prescription']['pharmacy']
                    message = "Your prescription " + drugname + \
                              " is being processed " + pharmacy + \
                              ". Your eRx card will move from Pending to Filled section."
                    obj.sendNotifications(obj.otherinfo['prescription']['domain'], message,
                                          obj.otherinfo['prescription']['flipt_person_id'], phone, obj)

                # print(obj.otherinfo['prescription'], '------')
                self.log.debug(
                    f"filling intent {obj.otherinfo['prescription']['prescription_id']}: {json.dumps(fill_data)} ")
                obj.claimdataprovobj.updateIntent(
                    obj.otherinfo['prescription']['prescription_id'], fill_data)

            def graph_ql_updates():

                prescription = self.otherinfo.get('prescription', {})
                baseline_cost = prescription.get('baseline_cost', '')
                drug_penalty = prescription.get('drug_penalty', '')
                package_quantity = prescription.get('package_quantity', '')
                package_size = prescription.get('package_size', '')
                otc_indicator = prescription.get('otc_indicator', '')
                alternative_drug_rewards = '0' if prescription.get(
                    'alternative_drug_rewards') == 'None' else prescription.get('alternative_drug_rewards')
                alternate_penalty = '0' if prescription.get(
                    'alternate_penalty') == None else prescription.get('alternate_penalty')
                total_reward = prescription.get('total_reward', 0)
                retail_reward = prescription.get('retail_reward', 0)
                rewards = prescription.get('rewards', 0)
                rebate_amount = prescription.get('rebate_amount', 0)
                default_payment_option = prescription.get('payment_option', '')
                rebate_factor = prescription.get('rebate_factor', '')
                reward_percentage = prescription.get('reward_percentage', '')
                reward_share = prescription.get('reward_share', '')
                gppc = prescription.get('gppc', '')
                unit_price = prescription.get('unit_price')
                unit_price_before_rebate = prescription.get(
                    'unit_price_before_rebate')
                if prescription.get('application') == "Auto eRx":
                    opc_remaining = prescription.get(
                        'out_of_pocket_remaining', '')
                    copay_type = prescription.get('copay_type', '')
                    copay = prescription.get('drug_copay', '')
                    copay_amt = prescription.get('drug_copay', '')
                    price_type = prescription.get('price_type', '')
                    pharmacy_name = prescription.get('pharmacy', '')
                    pharmacy_chain_code = prescription.get('chaincode', '')
                    drug_manufacturer = self.otherinfo['ndc_info'].get('mfg', '')
                    if obj.otherinfo['prescription'].get('deductible_met', '') == False and \
                            obj.otherinfo['prescription']['formularyinfo'].get('deductible_accumulator_flag', '') == 'Y':
                        deductible_accumulator_amount = prescription.get(
                            'original_employee_opc')
                    else:
                        deductible_accumulator_amount = 0
                    if (obj.otherinfo['prescription'].get('outofpocket_met', '') == False and
                            obj.otherinfo['prescription']['formularyinfo'].get('oop_accumulator_flag', '') == 'Y'):
                        oop_accumulator_amount = prescription.get(
                            'original_employee_opc')
                    else:
                        oop_accumulator_amount = 0

                    if prescription.get('pa_status', '') == 'Approved':
                        if prescription.get('deductible_accumulator_amount', ''):
                            deductible_accumulator_amount = prescription.get(
                                'deductible_accumulator_amount', '')
                        if prescription.get('oop_accumulator_amount', ''):
                            oop_accumulator_amount = prescription.get(
                                'oop_accumulator_amount', '')
                else:
                    opc_remaining = prescription.get('opc_remaining', '')
                    copay_type = prescription.get('copay_type', '')
                    copay = prescription.get('drug_copay', '')
                    copay_amt = prescription.get('drug_copay', '')
                    price_type = prescription.get('price_type', '')
                    pharmacy_name = prescription.get('pharmacy', '')
                    pharmacy_chain_code = prescription.get('chaincode', '')
                    self.otherinfo.update(self.claimdataprovobj.getGPI(
                        self.claimobj.ClaimRequest.claimsseg.product_id))
                    drug_manufacturer = self.otherinfo['ndc_info'].get('mfg', '')
                    deductible_accumulator_amount = prescription.get(
                        'deductible_accumulator_amount', '')
                    oop_accumulator_amount = prescription.get(
                        'oop_accumulator_amount', '')

                keys = ['baseline_cost', 'drug_penalty', 'package_quantity', 'package_quantity', 'package_size',
                        'otc_indicator', 'default_payment_option', 'alternative_drug_rewards', 'total_reward',
                        'rebate_factor', 'rebate_amount', 'retail_reward', 'reward_percentage', 'reward_share',
                        'rewards',
                        'opc_remaining', 'copay_type', 'copay', 'copay_amt', 'price_type', 'pharmacy_name',
                        'pharmacy_chain_code', 'drug_manufacturer', 'gppc',
                        'alternate_penalty', 'unit_price', 'unit_price_before_rebate', 'deductible_accumulator_amount',
                        'oop_accumulator_amount']
                values = [baseline_cost, drug_penalty, package_quantity, package_quantity, package_size,
                          otc_indicator, default_payment_option, alternative_drug_rewards, total_reward,
                          rebate_factor, rebate_amount, retail_reward, reward_percentage, reward_share, rewards,
                          opc_remaining, copay_type, copay, copay_amt, price_type, pharmacy_name, pharmacy_chain_code,
                          drug_manufacturer, gppc, alternate_penalty, unit_price,
                          unit_price_before_rebate, deductible_accumulator_amount, oop_accumulator_amount]

                self.log.debug(
                    f"Keys and values for post updates: {keys} and {values}")
                res_dict = dict(zip(keys, values))
                self.log.debug(
                    f"Resultant dict after merging keys and values : {res_dict}")
                for k, v in res_dict.items():
                    self.cb.mutate_in(obj.claimkey, SD.upsert(f'{k}', v))
            if obj.otherinfo.get('responsetype', '') != 'Duplicate':
                try:
                    createAutoerx(small_updates)
                except Exception as err:
                    self.log.debug(
                        f"Exception occured for createAutoerx function: {err}")
                try:
                    autoerx, phone = getPhoneNumber()
                except Exception as err:
                    self.log.debug(
                        f"Exception occured for getPhoneNumber function: {err}")
                try:
                    updates = quantityDifferenceUpdate(
                        small_updates, autoerx, phone)
                except Exception as err:
                    self.log.debug(
                        f"Exception occured in quantityDifferenceUpdate function: {err}")
                if 'Prior Authorization' not in obj.otherinfo['rejectionreason']:
                    try:
                        fillIntent(small_updates)
                    except Exception as err:
                        self.log.debug(
                            f"Exception occured in fillIntent function : {err}")
                    try:
                        insertReward(updates)
                    except Exception as err:
                        self.log.debug(
                            f"Exception occured in insertReward function : {err}")
                    try:
                        upsertRxHistory(updates)
                    except Exception as err:
                        self.log.debug(
                            f"Exception occured in upsertRxHistory function : {err}")
                    self.log.debug("Finished rx history updates")

            def update_claim_document():
                self.log.debug("Post process updates for downs-stream usage")
                prescription = self.otherinfo.get('prescription', {})
                brand_generic = {'G': "Generic", 'T': 'Brand'}.get(
                    prescription.get('brand_generic'), '')
                update_dict = dict()
                client_pricing = {}
                update_dict['brand_generic'] = brand_generic
                update_dict['drug_name'] = prescription.get('drug_name', '')
                update_dict['drug_dosage'] = prescription.get('dosage', '')
                update_dict['multi_source'] = self.otherinfo['ndc_info'].get(
                    'multi_source', '')
                update_dict['payer_brand_generic'] = prescription.get('payer_brand_generic','')
                update_dict['drug_strength'] = prescription.get(
                    'dosage_strength', '')
                update_dict['domain'] = prescription.get('domain_name', '') if prescription.get('domain_name', '') \
                    else prescription.get('domain', '')

                update_dict['pa_flag'] = prescription.get('pa_flag', '')
                update_dict['coverage_tier_name'] = usereligibilityresult.get(
                    'user').get('coverage_tier_name', '')
                update_dict['plan_year'] = usereligibilityresult.get(
                    'plan-year', '')
                update_dict['benefit_plan_name'] = usereligibilityresult.get(
                    'benefit-plan-name', '')
                if prescription.get('application') == "Auto eRx":
                    update_dict['employee_opc'] = float(
                        prescription.get('original_employee_opc', '0'))
                update_dict['claims_processor'] = prescription.get(
                    'claims_processor', '')
                if update_dict['claims_processor'] == '':
                    claims_processor = self.claimdataprovobj.getClaimProcessor(
                        {'rxbin': self.otherinfo['prescription']['bin'].strip(),
                         'rxpcn': self.otherinfo['prescription']['pcn'].strip()})
                    update_dict['claims_processor'] = claims_processor['claim_processor']

                update_dict['opc_remaining'] = float(prescription.get('opc_remaining', '0')) if prescription.get(
                    'opc_remaining', '') != '' else float(
                    prescription.get('out_of_pocket_remaining', '0'))
                update_dict['pharmacy_name'] = prescription.get('pharmacy', '')
                update_dict['price_type'] = prescription.get('price_type', '')
                update_dict['copay_type'] = prescription.get('copay_type', '')

                quantity_dispensed = obj.claimobj.ClaimRequest.parsedclaim[
                    'claim_request']['claims_segment']['quantity_dispensed']
                patient_pay_amount = float(
                    obj.claimobj.ClaimResponse.pricingseg.patient_pay_amount)
                pharmacy_discount = prescription.get('pharmacy_discount')
                drug_cost = float(prescription.get('drug_cost', '0'))
                unit_price = float(prescription.get('unit_price', '0'))
                unit_price_before_rebate = float(
                    prescription.get('unit_price_before_rebate', '0'))
                pharmacy_dispensing_fee = (
                    prescription.get('pharmacy_dispensing_fee', '0'))
                if pharmacy_dispensing_fee in ['', None]:
                    pharmacy_dispensing_fee = vars(obj.claimobj.ClaimResponse)[
                        'responseclaim']['claim_response']['dispensing_fee_paid']
                if domain_flags.get('rebate_at_pos_adjustment', 'N') == 'N':
                    unit_price = float(unit_price_before_rebate)
                else:
                    unit_price = unit_price
                if prescription.get('application') == "Auto eRx":
                    calculated_drug_cost = float(unit_price) * float(pharmacy_discount) * \
                        float(quantity_dispensed) + \
                        float(pharmacy_dispensing_fee)

                    client_pricing['calculated'] = calculated_drug_cost
                    calculated_ing_cost = float(unit_price) * float(pharmacy_discount) * \
                        float(quantity_dispensed)
                    calculated_disp_fee = float(pharmacy_dispensing_fee)
                    if pharmacy_dispensing_fee in ['', None]:
                        pharmacy_dispensing_fee = vars(obj.claimobj.ClaimResponse)['responseclaim']['claim_response'][
                            'dispensing_fee_paid']
                    calculated_patient_pay_amt = patient_pay_amount
                    calculated_employer_cost = calculated_drug_cost - calculated_patient_pay_amt
                    calculated_employer_cost = 0 if calculated_employer_cost < 0 else calculated_employer_cost
                    calculated_employee_opc = float(prescription.get('copay', '0')) if prescription.get(
                        'copay', '') else float(prescription.get('drug_copay', '0'))
                else:
                    calculated_drug_cost = prescription.get('drug_cost', '')

                    calculated_disp_fee = float(
                        prescription.get('pharmacy_dispensing_fee', '0'))
                    if calculated_disp_fee in ['', None]:
                        calculated_disp_fee = vars(obj.claimobj.ClaimResponse)[
                            'responseclaim']['claim_response']['dispensing_fee_paid']
                    calculated_patient_pay_amt = prescription.get(
                        'employee_opc', '')
                    calculated_employer_cost = prescription.get(
                        'employer_cost', '')
                    calculated_employee_opc = prescription.get(
                        'employee_opc', '')
                    calculated_ing_cost = float(
                        calculated_drug_cost) - float(calculated_disp_fee)

                    # validation for mobile app pricing
                    if calculated_employer_cost == (calculated_ing_cost + calculated_disp_fee) - float(calculated_patient_pay_amt):
                        calculated_employer_cost = calculated_employer_cost
                    else:
                        calculated_employer_cost = (
                            calculated_ing_cost + calculated_disp_fee) - float(calculated_patient_pay_amt)
                    if calculated_employer_cost < 0:
                        calculated_employer_cost = 0

                try:
                    unc_drug_cost = float(
                        obj.claimobj.ClaimRequest.pricingseg.usual_and_customary_charge)
                    unc_ing_cost = float(
                        obj.claimobj.ClaimRequest.pricingseg.usual_and_customary_charge)
                    unc_employer_cost = unc_drug_cost - patient_pay_amount
                    unc_employer_cost = 0 if unc_employer_cost < 0 else unc_employer_cost
                    unc_disp_fee = 0
                    client_pricing['unc'] = unc_drug_cost
                except:
                    unc_drug_cost = ''
                    unc_ing_cost = ''
                    unc_employer_cost = ''
                    unc_disp_fee = ''
                # unc_patient_paid_amount = float(obj.claimobj.ClaimRequest.pricingseg.patient_paid_amount_submitted)

                try:
                    submitted_drug_cost = float(
                        obj.claimobj.ClaimRequest.pricingseg.gross_amount_due)
                    client_pricing['submitted'] = submitted_drug_cost
                    submitted_employer_cost = submitted_drug_cost - patient_pay_amount
                    submitted_employer_cost = 0 if submitted_employer_cost < 0 else submitted_employer_cost
                except:
                    submitted_drug_cost = ''
                    submitted_employer_cost = ''
                try:
                    submitted_ing_cost = float(
                        obj.claimobj.ClaimRequest.pricingseg.ingredient_cost_submitted)
                except:
                    submitted_ing_cost = ''
                try:
                    submitted_disp_fee = float(
                        obj.claimobj.ClaimRequest.pricingseg.dispensing_fee_submitted)
                except:
                    submitted_disp_fee = ''
                # submitted_patient_paid_amount = float(obj.claimobj.ClaimRequest.pricingseg.patient_paid_amount_submitted)

                minimum_pricing = (
                    min(client_pricing, key=lambda k: client_pricing[k]))
                if prescription.get('application') == "Auto eRx":
                    self.log.debug(f'minimum price found: {minimum_pricing}')
                    client_ing_cost = eval(f'{minimum_pricing}_ing_cost')
                    client_drug_cost_paid = eval(
                        f'{minimum_pricing}_drug_cost')
                    client_disp_fee_paid = eval(f'{minimum_pricing}_disp_fee')
                    client_employer_cost = eval(
                        f'{minimum_pricing}_employer_cost')
                    client_employee_paid = patient_pay_amount
                    client_deductible = 0 if prescription.get('deductible_accumulator_flag') is 'N' else \
                        float(
                            obj.claimobj.ClaimResponse.pricingseg.patient_pay_amount)
                else:
                    self.log.debug(
                        "Intent is existing, client paid values are prescription values")
                    client_ing_cost = float(unit_price_before_rebate) * float(pharmacy_discount) * \
                        float(quantity_dispensed)
                    client_drug_cost_paid = prescription.get('drug_cost', '')
                    client_disp_fee_paid = float(pharmacy_dispensing_fee)
                    client_employer_cost = prescription.get(
                        'employer_cost', '')
                    client_employee_paid = prescription.get('employee_opc', '')
                    client_deductible = 0 if prescription.get('deductible_accumulator_flag') is 'N' else \
                        prescription.get('employee_opc', '')
                update_dict['patient_pay_amount'] = patient_pay_amount
                update_dict['pharmacy_discount'] = pharmacy_discount
                update_dict['drug_cost'] = drug_cost
                update_dict['unit_price'] = unit_price
                update_dict['unit_price_before_rebate'] = unit_price_before_rebate
                update_dict['quantity_dispensed'] = quantity_dispensed
                update_dict['drug_cost'] = drug_cost
                update_dict['pharmacy_dispensing_fee'] = pharmacy_dispensing_fee
                update_dict['calculated_drug_cost'] = calculated_drug_cost
                update_dict['calculated_ing_cost'] = calculated_ing_cost
                update_dict['calculated_disp_fee'] = calculated_disp_fee
                update_dict['calculated_patient_pay_amt'] = calculated_patient_pay_amt
                update_dict['calculated_employer_cost'] = calculated_employer_cost
                update_dict['calculated_employee_opc'] = calculated_employee_opc
                update_dict['unc_drug_cost'] = unc_drug_cost
                update_dict['unc_ing_cost'] = unc_ing_cost
                update_dict['unc_disp_fee'] = unc_disp_fee
                # update_dict['unc_patient_paid_amount'] = unc_patient_paid_amount
                update_dict['unc_employer_cost'] = unc_employer_cost
                update_dict['submitted_drug_cost'] = submitted_drug_cost
                update_dict['submitted_ing_cost'] = submitted_ing_cost
                update_dict['submitted_disp_fee'] = submitted_disp_fee
                # update_dict['submitted_patient_paid_amount'] = submitted_patient_paid_amount
                update_dict['submitted_employer_cost'] = submitted_employer_cost
                update_dict['submitted_employer_cost'] = submitted_employer_cost
                update_dict['client_ing_cost'] = client_ing_cost
                update_dict['client_drug_cost_paid'] = client_drug_cost_paid
                update_dict['client_disp_fee_paid'] = client_disp_fee_paid
                update_dict['client_employer_cost'] = client_employer_cost
                update_dict['client_employee_paid'] = client_employee_paid
                update_dict['client_deductible'] = client_deductible
                if prescription.get('brand_generic_switch') == True:
                    update_dict['generic_drug_cost'] = prescription.get('generic')[
                        'drug_cost']
                    update_dict['generic_drug_name'] = prescription.get('generic')[
                        'drug_name']
                    update_dict['generic_employee_opc'] = prescription.get('generic')[
                        'employee_opc']
                    update_dict['generic_employer_cost'] = prescription.get('generic')[
                        'employer_cost']
                    update_dict['generic_copay_type'] = self.otherinfo.get(
                        'alternative_formulary')[0]['copay_type']
                    update_dict['generic_unit_price'] = prescription.get('generic')[
                        'unit_price']
                    update_dict['generic_pharmacy_discount'] = prescription.get('generic')[
                        'pharmacy_discount']
                    update_dict['generic_pharmacy_dispensing_fee'] = prescription.get('generic')[
                        'pharmacy_dispensing_fee']
                    update_dict['generic_price_type'] = prescription.get('generic')[
                        'price_type']
                    update_dict['generic_reward'] = prescription.get('generic')[
                        'reward']
                    if prescription.get('generic')['rejection_reason'] == '':
                        update_dict['generic_unit_price_before_rebate'] = prescription.get('generic')[
                            'unit_price_before_rebate']
                    else:
                        update_dict['generic_rejection_reason'] = prescription.get('generic')[
                            'rejection_reason']
                if prescription.get('rra_penalty_type'):
                    update_dict['rra_penalty_type'] = prescription.get(
                        'rra_penalty_type')
                self.log.debug(
                    f"Calculated values for claims reporting: {update_dict.keys()}, {update_dict.values()}")
                for k, v in update_dict.items():
                    self.cb.mutate_in(obj.claimkey, SD.upsert(f'{k}', v))

            try:
                if obj.requesttype == 'B1' and not obj.otherinfo['responsetype'] == 'Duplicate':
                    update_claim_document()
                    self.log.debug("Finished updating the down stream data")
                elif obj.requesttype == 'B1' and obj.otherinfo['responsetype'] == 'Duplicate':
                    b1_claim_info = {}
                    b1_claim_info.update(
                        self.claimdataprovobj.getb1_data(self.otherinfo))
                    for k, v in b1_claim_info.items():
                        self.cb.mutate_in(obj.claimkey, SD.upsert(f'{k}', v))

            except Exception as err:
                self.log.debug(
                    f"Exception occured for getting reporting data: {err}")
            self.log.debug("Adding graphql values")
            try:
                graph_ql_updates()
            except Exception as err:
                self.log.debug(
                    f"Exception occured in graph_ql_updates function : {err}")
        elif obj.requesttype == 'B2':
            reverse_date = datetime.now()

            def update_b2_document():
                b1_claim_info = {}
                b1_claim_info.update(
                    self.claimdataprovobj.getb1_data(self.otherinfo))
                for k, v in b1_claim_info.items():
                    if k in ['alternate_penalty', 'alternative_drug_rewards', 'baseline_cost', 'copay', 'copay_amt',
                             'drug_penalty', 'employee_opc', 'employer_cost', 'pharmacy_dispensing_fee',
                             'rebate_amount', 'retail_reward', 'rewards', 'total_reward', 'client_deductible',
                             'calculated_disp_fee', 'calculated_drug_cost', 'calculated_employee_opc',
                             'calculated_employer_cost', 'calculated_ing_cost', 'calculated_patient_pay_amt',
                             'client_deductible', 'client_disp_fee_paid', 'client_drug_cost_paid',
                             'client_employee_paid', 'client_employer_cost', 'client_ing_cost',
                             'submitted_disp_fee', 'submitted_drug_cost', 'submitted_employer_cost',
                             'submitted_ing_cost', 'unc_disp_fee', 'unc_drug_cost',
                             'unc_employer_cost', 'unc_ing_cost', 'unit_price', 'unit_price_before_rebate',
                             'drug_cost', 'pharmacy_discount', 'quantity_dispensed', 'patient_pay_amount',
                             'deductible_accumulator_amount', 'oop_accumulator_amount']:
                        v = f'-{str(v)}' if (not str(v).startswith('-')
                                             and str(v) not in ['', '0']) else str(v)
                    self.cb.mutate_in(obj.claimkey, SD.upsert(f'{k}', v))

            def removeReward():

                rewardsid = obj.claimdataprovobj.findRewards(
                    {'prescription_id': obj.otherinfo['prescription']['prescription_id']})
                if rewardsid != '':
                    obj.claimdataprovobj.removeData(rewardsid)

            def updateRxHistory():

                docid = obj.claimdataprovobj.getRxhistoryData(
                    {'drug_name': obj.otherinfo['prescription']['drug_name'],
                     'gpi': obj.otherinfo['prescription']['gpi'],
                     'rx_flipt_person_id': obj.otherinfo['prescription']['rx_flipt_person_id']})

                prescriptioninfo = obj.claimdataprovobj.getLastFilledPrescription(
                    {'drug_name': obj.otherinfo['prescription']['drug_name'],
                     'gpi': obj.otherinfo['prescription']['gpi'],
                     'rx_flipt_person_id': obj.otherinfo['prescription']['rx_flipt_person_id']}, True)
                prescriptioninfo = dict(ChainMap(*prescriptioninfo))
                if prescriptioninfo:
                    rxhistory = {}
                    rxhistory['npi'] = prescriptioninfo['npi']
                    rxhistory['start_date'] = prescriptioninfo['filled_date']
                    rxhistory['daysofsupply'] = prescriptioninfo['daysofsupply']
                    rxhistory['estimated_stop_date'] = (datetime.strptime(prescriptioninfo['filled_date'],
                                                                          "%Y-%m-%dT%H:%M:%S.%f") + timedelta(days=(int(
                                                                              prescriptioninfo['daysofsupply']) - int(
                                                                              domain_flags['quantity_restriction_buffer'])))).isoformat()
                    rxhistory['currently_taking_flag'] = 'Y'
                    rxhistory['pharmacy_name'] = prescriptioninfo['pharmacy']
                    rxhistory['location'] = prescriptioninfo['location']
                    rxhistory['ready_to_refill'] = 'N'
                    rxhistory['updated_date'] = reverse_date.isoformat()
                    obj.claimdataprovobj.updateIntent(docid, rxhistory)
                elif docid:
                    obj.claimdataprovobj.removeData(docid)

            def reverseIntent():

                reversal_data = {'rx_status': "Routed",
                                 'auth_id': obj.claimobj.auth_id,
                                 'routed_date': reverse_date.isoformat(),
                                 'update_date': reverse_date.isoformat(),
                                 'rx_number': obj.claimobj.ClaimRequest.claimsseg.prescription_reference_number,
                                 'available_fill_date': ''}
                self.log.debug(
                    f"reversing intent {obj.otherinfo['prescription']['prescription_id']}: {json.dumps(reversal_data)}")
                obj.claimdataprovobj.updateIntent(
                    obj.otherinfo['prescription']['prescription_id'], reversal_data)

            try:
                update_b2_document()
                self.log.debug(
                    "Updated the b2 document with the reporting fields")
            except Exception as err:
                self.log.debug(
                    f"Exception while updating b2 document with the reporting fields: {err}")
            try:
                reverseIntent()
            except Exception as err:
                self.log.debug(f"Exception in reverseIntent function: {err}")
            self.log.debug("Finished reversing the intent")
            try:
                removeReward()
            except Exception as err:
                self.log.debug(f"Exception in removeReward function: {err}")
            self.log.debug("Removed the reward")
            try:
                updateRxHistory()
            except Exception as err:
                self.log.debug(f"Exception in removeReward function: {err}")
            self.log.debug("Updated the RX history table")

    def sendNotifications(self, domain, message, flipt_person_id, phone, obj):

        result, info = SendSms(obj.config, message, phone).sendSMS()
        if result == 'success':
            return
        messagecenter = {}
        action = {}
        messagecenter['action'] = action
        messagecenter['create_date'] = str(datetime.now().isoformat())
        messagecenter['created_by'] = "System"
        messagecenter['domain'] = domain
        messagecenter['flipt_person_id'] = flipt_person_id
        messagecenter['message'] = ""
        messagecenter['message_method'] = "in-app"
        messagecenter['status'] = "New"
        messagecenter['sub_message'] = message
        messagecenter['type'] = "message_center"
        messageid = obj.claimdataprovobj.saveClaim(messagecenter)
        action_data = {'action': {}}
        action['notification_id'] = messageid
        action['sub_title'] = message
        action['title'] = ""
        action['type'] = 'message'
        action_data['action'] = action
        obj.claimdataprovobj.updateIntent(
            messageid, {'action': action_data, 'message_id': messageid})

    def claimTransfer(self, req_type, domain_flags):

        if (self.module_invalid or self.otherinfo['rejectionreason']) and self.otherinfo.get('responsetype', '') != 'Duplicate':
            return ''

        claimprocinfo = self.claimdataprovobj.getClaimProcessor(
            {'rxbin': self.otherinfo['prescription']['bin'].strip(),
             'rxpcn': self.otherinfo['prescription']['pcn'].strip()})

        if req_type.lower() not in ['erx']:
            return ''
        modifiedfields = {'claim_transfer_request': {}}

        if self.requesttype == 'B1':
            transferrequest = self.requestdata
            bin_pcn_len = 20
            bin_pcn_str = f"{claimprocinfo['transfer_rxbin']}D0B1{claimprocinfo['transfer_rxpcn']}".ljust(
                bin_pcn_len)
            transferrequest = transferrequest.replace(
                transferrequest[:bin_pcn_len], bin_pcn_str)

            self.log.debug(f"Claim transfer (bin-pcn): {bin_pcn_str}")

            copay = str(round(float(self.otherinfo['prescription']['employee_opc']), 1)).replace(
                '.', '') + '{'
            if domain_flags.get('max_plan_coverage_per_script') == 'Y':
                self.log.debug(f"Finding maximum coverage per script")
                coverage_obj = OptionalModules.max_coverage_info(
                    domain_flags=domain_flags, other_info=self.otherinfo)
                result = coverage_obj.get_coverage()
                self.log.debug(f"Finding maximum coverage per script")
                copay = str(round(float(result[1]))) + '{'
                self.claimobj.ClaimResponse.pricingseg.patient_pay_amount = result[1]
                self.claimobj.ClaimResponse.pricingseg.total_amount_paid = result[0]
                self.claimobj.ClaimResponse.__dict__[
                    'responseclaim']['claim_response']['patient_pay_amount'] = result[1]
                self.claimobj.ClaimResponse.__dict__[
                    'responseclaim']['claim_response']['total_amount_paid'] = self.otherinfo['prescription']['employer_cost']
                self.otherinfo['prescription']['employer_cost'] = result[0]
                self.claimdataprovobj.updateIntent(self.claimkey, {
                    'claim_response': self.claimobj.ClaimResponse.responseclaim,
                    'total_amount_paid': result[0]})
                self.claimobj.ClaimResponse.pricingseg.patient_pay_amount = copay
                self.otherinfo['prescription']['employer_cost'] = result[0]

            search_field = re.search('\x1cDX[0-9{.]{1,}', transferrequest)
            self.log.debug(f"Claim transfer (patient pay amount):{copay}")
            if search_field:
                transferrequest = re.sub(
                    '\x1cDX[0-9{.]{1,}', '\x1cDX' + copay, transferrequest)
            elif '\x1e\x1cAM11\x1c' in transferrequest:
                transferrequest = re.sub(
                    '\x1e\x1cAM11\x1c', '\x1e\x1cAM11\x1cDX' + copay + '\x1c', transferrequest)
            else:
                transferrequest = transferrequest + '\x1e\x1cAM11\x1cDX' + copay

            fields = {
                'bin_number': claimprocinfo['transfer_rxbin'],
                'processor_control_number': claimprocinfo['transfer_rxpcn']}
        elif self.requesttype == 'B2':
            claimprocinfo = self.claimdataprovobj.getClaimProcessor(
                {'rxbin': self.otherinfo['prescription']['bin'], 'rxpcn': self.otherinfo['prescription']['pcn']})
            transferrequest = self.requestdata
            bin_pcn_len = 20
            bin_pcn_str = f"{claimprocinfo['transfer_rxbin']}D0B2{claimprocinfo['transfer_rxpcn']}".ljust(
                bin_pcn_len)
            transferrequest = transferrequest.replace(
                transferrequest[:bin_pcn_len], bin_pcn_str)
            fields = {
                'bin_number': claimprocinfo['transfer_rxbin'],
                'processor_control_number': claimprocinfo['transfer_rxpcn']}
        modifiedfields['claim_transfer_request'] = fields
        encryptedresponseString = self.encrypt(transferrequest.encode('utf-8'))
        self.claimdataprovobj.updateIntent(self.claimkey,
                                           {'claim_transfer_request': modifiedfields,
                                            'claimTransferRequestData': encryptedresponseString})

        return transferrequest

    def detectDuplicateClaims(self):
        self.log.debug("Checking for duplicate claims")
        self.otherinfo['rejectioncode'], self.otherinfo['rejectionreason'] = \
            self.validationobj.validateData(
                self.claimobj.ClaimRequest, self.otherinfo["ndc_info"], True)
        if self.otherinfo['rejectioncode']:
            self.module_invalid = True
            self.claimobj.auth_id = str(
                self.claimdataprovobj.getNextICN()).zfill(13)
            self.claimobj.sequenceNumber = 1
            return
        search_parameters = [self.claimobj.ClaimRequest.header.service_provider_id.strip().zfill(10),
                             self.claimobj.ClaimRequest.claimsseg.prescription_reference_number.strip(),
                             self.claimobj.ClaimRequest.parsedclaim['claim_request']['claims_segment']['gpi'],
                             self.claimobj.ClaimRequest.insuranceseg.cardholder_id]
        if self.requesttype == 'B1':
            try:
                search_parameters.append(
                    str(int(self.claimobj.ClaimRequest.claimsseg.fill_number)))
            except:
                search_parameters.append(
                    self.claimobj.ClaimRequest.claimsseg.fill_number)
        # for i in range(10):
        self.log.debug("Going to get claim from db")
        currentclaims = self.claimdataprovobj.getClaims(search_parameters)
        self.log.debug("Finished checking for claims in db for duplicate")
        # i+=1

        if currentclaims:
            self.log.debug(
                "Found existing claim, marking the current one as duplicate")
            claims = pd.DataFrame(currentclaims)
            prescriptionid = ''
            sequencenumber = 0
            if self.requesttype == 'B1':

                for i, r in claims.iterrows():
                    if 'claim_request' not in r or 'claim_response' not in r or pd.isnull(
                            r['claim_request']) or pd.isnull(r['claim_response']):
                        continue
                    if 'prescription_id' in r and not pd.isnull(r['prescription_id']):
                        prescriptionid = r['prescription_id']
                    if 'sequenceNumber' in r and sequencenumber < 1:
                        sequencenumber = r['sequenceNumber']
                    if r['claim_request']['transaction_code'] == 'B2' and (
                            r['claim_response']['transaction_response_status'] in ['A', 'S']):
                        break
                    elif r['claim_request']['transaction_code'] == 'B1' and (
                            r['claim_response']['transaction_response_status'] in ['P', 'D']):
                        if r['claim_request']['date_of_service'] == self.claimobj.ClaimRequest.header.date_of_service:
                            self.log.debug('B1 Duplicate')
                            self.otherinfo['responsetype'] = 'Duplicate'
                            self.otherinfo['duplicate_response'] = r['claim_response']
                            self.otherinfo['b1_auth_id'] = r['auth_id']
                            self.otherinfo['b1_seq_num'] = r['sequenceNumber']

                        break
            elif self.requesttype == 'B2':

                b1found = False
                b2found = False

                for i, r in claims.iterrows():

                    if 'claim_request' not in r or 'claim_response' not in r or pd.isnull(
                            r['claim_request']) or pd.isnull(r['claim_response']):
                        continue
                    if 'prescription_id' in r and not pd.isnull(r['prescription_id']):
                        prescriptionid = r['prescription_id']
                    if 'sequenceNumber' in r and sequencenumber < 1:
                        sequencenumber = r['sequenceNumber']
                    if r['claim_request']['transaction_code'] == 'B2' and (
                            r['claim_response']['transaction_response_status'] in ['A', 'S']):
                        b2found = True
                        if r['claim_request']['date_of_service'] == self.claimobj.ClaimRequest.header.date_of_service:
                            self.log.debug('B2 duplicate')
                            self.otherinfo['responsetype'] = 'Duplicate'
                            self.claimobj.ClaimRequest.parsedclaim['claim_request'][
                                'claims_segment']['fill_number'] = r['claim_request']['fill_number']
                            self.claimobj.ClaimRequest.parsedclaim['claim_request']['insurance_segment'][
                                'cardholder_id'] = r['claim_request']['cardholder_id']
                            self.claimobj.ClaimRequest.insuranceseg.cardholder_id = r[
                                'claim_request']['cardholder_id']
                            self.claimobj.ClaimRequest.parsedclaim['claim_request']['insurance_segment'][
                                'tpa_member_id'] = r['claim_request'].get('tpa_member_id', '')
                            self.otherinfo['prescription'].update(
                                {'total_amount_paid': r['claim_response']['total_amount_paid']})
                            self.claimobj.ClaimRequest.claimsseg.fill_number = r[
                                'claim_request']['fill_number']
                            self.otherinfo['b1_auth_id'] = r['auth_id']
                            self.otherinfo['b1_seq_num'] = r['sequenceNumber']
                            if 'D3' not in self.requestdata:
                                self.log.debug(
                                    "Adding D3 field in the claim request")
                                len = self.requestdata.find('EM1')
                                refill_num_str = f"D3{r['claim_request']['fill_number']}\x1c"
                                self.requestdata = self.requestdata[:len] + \
                                    refill_num_str + self.requestdata[len:]
                                self.log.debug(
                                    f"Claim response after adding D3 : {self.requestdata}")

                            break
                    elif r['claim_request']['transaction_code'] == 'B1' and (
                            r['claim_response']['transaction_response_status'] in ['P', 'D']):
                        b1found = True
                        self.claimobj.ClaimRequest.parsedclaim['claim_request']['claims_segment']['fill_number'] = r[
                            'claim_request']['fill_number']
                        self.claimobj.ClaimRequest.parsedclaim['claim_request']['insurance_segment'][
                            'cardholder_id'] = r['claim_request']['cardholder_id']
                        self.claimobj.ClaimRequest.insuranceseg.cardholder_id = r[
                            'claim_request']['cardholder_id']
                        self.claimobj.ClaimRequest.parsedclaim['claim_request']['insurance_segment'][
                            'tpa_member_id'] = r['claim_request'].get('tpa_member_id', '')
                        self.otherinfo['prescription'].update(
                            {'total_amount_paid': r['claim_response']['total_amount_paid']})
                        self.claimobj.ClaimRequest.claimsseg.fill_number = r[
                            'claim_request']['fill_number']
                        self.otherinfo['b1_auth_id'] = r['auth_id']
                        self.otherinfo['b1_seq_num'] = r['sequenceNumber']
                        if 'D3' not in self.requestdata:
                            self.log.debug(
                                "Adding D3 field in the claim request")
                            len = self.requestdata.find('EM1')
                            refill_num_str = f"D3{r['claim_request']['fill_number']}\x1c"
                            self.requestdata = self.requestdata[:len] + \
                                refill_num_str + self.requestdata[len:]
                            self.log.debug(
                                f"Claim response after adding D3 : {self.requestdata}")
                        break
                if (not b1found and not b2found):
                    print('claim not captured')
                    self.module_invalid = True
                    self.otherinfo['rejectioncode'] = '84'
                    self.otherinfo['rejectionreason'] = 'Claim has Not been Paid/Captured'

            if 'prescription' in prescriptionid:
                self.otherinfo['prescription'].update(
                    self.claimdataprovobj.getIntentData(str(prescriptionid)))
            self.claimobj.auth_id = claims.loc[0, 'auth_id']
            self.claimobj.sequenceNumber = sequencenumber + 1

        else:
            self.log.debug("This is a new claim")
            self.claimobj.auth_id = str(
                self.claimdataprovobj.getNextICN()).zfill(13)
            self.claimobj.sequenceNumber = 1
            if self.requesttype == 'B2':
                self.module_invalid = True
                self.otherinfo['rejectioncode'] = '84'
                self.otherinfo['rejectionreason'] = 'Claim has Not been Paid/Captured'

    def drug_covered(self, usereligibility_result, formulary_data, rxplan_master):
        self.log.debug("Check if drug is covered or not")

        if self.module_invalid:
            return {'drug_covered': '', 'drug_dispensed': False}

        data = dict()

        data['domain'] = usereligibility_result.get('domain', '')
        if not data['domain']:
            return {'drug_covered': '', 'drug_dispensed': False}
        data['plan_year'] = usereligibility_result['plan-year']
        data['benefit_plan_name'] = usereligibility_result['benefit-plan-name']
        data['gpi'] = self.otherinfo['gpi']
        data['drug_name'] = self.otherinfo['drug_name']
        drug_covered_obj = OptionalModules.drug_covered()
        res = drug_covered_obj.get_drug_info(
            data, formulary_data, rxplan_master)
        if res['drug_covered'] == res['drug_dispensed'] == False:
            self.otherinfo["rejectioncode"] = "70"
            self.otherinfo["rejectionreason"] = "Product/Service Not Covered"
            self.module_invalid = True

        return res
