from flask import Blueprint, request, jsonify
from app.tools.messages import errors
from .controllers import *

api = Blueprint('restriction', __name__, url_prefix="/restriction")


@api.route("/otc", methods=["POST"])
def get_otc_by_ddids():
    data = request.get_json()

    is_otc, ddids = data.get("is_otc"), data.get("ddids")

    if isinstance(is_otc, type(None)) or not isinstance(is_otc, bool):
        return jsonify(errors.ERROR_MESSAGE_MISSING_FIELDS({"fields": ["is_otc", "ddids"]})), 400

    if isinstance(ddids, type(None)) or not isinstance(ddids, list):
        return jsonify(errors.ERROR_MESSAGE_MISSING_FIELDS({"fields": ["is_otc", "ddids"]})), 400

    return jsonify(get_otc_drugs_by_ddids(is_otc, ddids)), 200


@api.route('/pa_check', methods=['POST'])
def pa_logic():
    request_data = request.get_json()
    return jsonify(pa_tree_logic(request_data)), 200
