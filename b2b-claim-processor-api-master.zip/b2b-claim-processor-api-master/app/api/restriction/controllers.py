from app.utility.bootstrap import OptionalModules


def get_otc_drugs_by_ddids(is_otc, ddids):

    if not is_otc:
        return {"ddids": ddids}

    over_the_counter = OptionalModules.over_the_counter()

    result = over_the_counter.get_otc_indicator_by_ddids(ddids)

    return {"ddids": result}


def pa_tree_logic(data):

    pa_logic = OptionalModules.pa_tree_logic()
    #pa_logic.get_drug_info("63323032320", "1245312024", "30")

    return pa_logic.is_pa_required(data)
