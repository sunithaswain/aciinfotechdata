import couchbase.subdocument as SD
from autologging import logged
from couchbase.n1ql import N1QLQuery
import logging


@logged
class ClaimProvider(object):

    def __init__(self, config):
        self.config = config
        self.cb = self.config.cb
        self.instance_type = self.config.CB_INSTANCE
        self.TRUEVAULT_API_KEY = self.config.tv_api_key
        self.URI = self.config.tv_uri
        self.log = logging.getLogger()

    def saveClaim(self, data):
        self.__log.info('Saving claim data')
        docid = str(self.cb.counter('docid', delta=1).value)
        response = self.cb.upsert(docid, data)
        self.__log.info('Claim data saved to %s', response.key)
        return response.key

    def validateBinNumber(self, attribute_value):
        query = N1QLQuery('Select rxbin from `'+self.instance_type +
                          '` where type="claim_processor" and rxbin=$v', v=attribute_value)
        self.log.debug(f"Query to validate bin number: {query}")
        for result in self.cb.n1ql_query(query):
            if attribute_value == result['rxbin']:
                return True

        return False

    def get_rxplan_master_info(self, plan_information):
        base_query = f"SELECT * FROM `{self.instance_type}` WHERE type='rxplan_master' AND domain_name='" \
                     f"{plan_information['domain_name']}' AND plan_name='{plan_information['plan_name']}' AN" \
                     f"D plan_end_date>='{plan_information['date_of_service']}' AND plan_start_date<='{plan_information['date_of_service']}'"
        query = N1QLQuery(base_query)
        self.log.debug(f"Query to get rxplan info: {query}")
        
        result = self.cb.n1ql_query(query).get_single_result()
        self.rxplan_info = result[self.instance_type] if result else {}
        
        return self.rxplan_info
        

    def get_formulary_for_drug(self, drug, plan_information):
        document_types = ['formulary_'+plan_information['domain_name'],'formulary']
        for doctype in document_types: 
            base_query = f"SELECT  pa_override,copay_type, pa_flag, deductibleexempted," \
                f"copay_30daysupply,copay_60daysupply, copay_90daysupply, copayabove90daysupply," \
                f"co_ins_min_amount, co_ins_max_amount, brand_generic , ARRAY cf FOR cf IN company_formulary WHEN cf.company = '" \
                f"{plan_information['domain_name']}' AND cf.plan_name = '{plan_information['plan_name']}' AND " \
                f"cf.effective_start_date<='{plan_information['date_of_service']}' " \
                f"AND cf.effective_end_date>='{plan_information['date_of_service']}' END as cf FROM `{self.instance_type}` " \
                f"WHERE type='{doctype}' AND gpi='{drug['gpi']}'"
            self.log.debug(f"Query to get the formulary info: {base_query}")
            query = N1QLQuery(base_query)
            self.formulary_info = self.cb.n1ql_query(query)
            result = []
            for r in self.formulary_info:
                result.append(r)
            print(result)
            return result

    def validateServiceProviderClaim(self, attribute_value):
        query = N1QLQuery('Select pharmacynpi from `'+self.instance_type +
                          '` where type="cp_pharmacy" and pharmacynpi=$v', v=attribute_value)
        self.log.debug(f"Query to validate the service provider : {query}")
        for result in self.cb.n1ql_query(query):
            if attribute_value == result['pharmacynpi']:
                return True

        return False

    def validateNDC(self, attribute_value):
        query = N1QLQuery('Select *   from `' +
                          self.instance_type + '` where type="ndc_drugs" and ndc=$v', v=attribute_value)

        for result in self.cb.n1ql_query(query):
            if attribute_value == result[self.instance_type]['ndc']:
                return result[self.instance_type]

        return False

    def getGPI(self, attribute_value):

        query = f"SELECT brand_generic, custom_qty, ddid, dosage, dosage_strength, drug_class, drug_full_name," \
            f"drug_group, drug_name, drug_subclass,form, gpi, gppc,item_status_flag,maintenance_drug_code," \
            f"multi_source,ndc,ndc_id,otc_indicator,package_desc,package_qty,package_quantity," \
            f"package_size,pkg_desc_cd,pkg_uom,quantity_type,strengths,type,unit_dose,update_date  FROM `{self.instance_type}` WHERE type='ndc_drugs' and ndc='{attribute_value}'"

        query = N1QLQuery(query)
        self.log.debug(f"Query to get drug info from ndc table: {query}")
        self.ndc_info = self.cb.n1ql_query(query).get_single_result()
        return self.ndc_info

    def getb1_data(self, attribute_value):
        query = N1QLQuery('Select alternate_penalty,alternative_drug_rewards, baseline_cost, benefit_plan_name, brand_generic,'
                          'claims_processor, copay, copay_amt, copay_type, coverage_tier_name,'
                          'default_payment_option, domain, drug_dosage, drug_manufacturer, drug_name,'
                          'drug_penalty, drug_strength, employee_opc, employer_cost,'
                          'gppc, multi_source, opc_remaining, otc_indicator, pa_flag,'
                          'package_quantity, package_size, pharmacy_chain_code, pharmacy_dispensing_fee, pharmacy_name,'
                          'plan_year, prescription_id, price_type, rebate_amount, rebate_factor, retail_reward, '
                          'reward_percentage, reward_share, rewards, total_reward, '
                          'calculated_disp_fee, calculated_drug_cost, calculated_employee_opc, '
                          'calculated_employer_cost, calculated_ing_cost, calculated_patient_pay_amt, '
                          'client_deductible, client_disp_fee_paid, client_drug_cost_paid, client_employee_paid, '
                          'client_employer_cost, client_ing_cost, submitted_disp_fee, submitted_drug_cost, '
                          'submitted_employer_cost, submitted_ing_cost, unc_disp_fee, '
                          'unc_drug_cost, unc_employer_cost, unc_ing_cost, unit_price, unit_price_before_rebate,'
                          'drug_cost, pharmacy_discount, quantity_dispensed, patient_pay_amount, generic_copay_type,'
                          'generic_drug_cost, generic_drug_name, generic_employee_opc, generic_employer_cost, '
                          'generic_pharmacy_discount, generic_pharmacy_dispensing_fee, generic_price_type, '
                          'generic_reward, generic_unit_price, generic_unit_price_before_rebate,'
                          'deductible_accumulator_amount, oop_accumulator_amount from `' +
                          self.instance_type + '` where type="claim" and auth_id=$v1 and sequenceNumber=$v2',
                          v1=attribute_value['b1_auth_id'], v2=attribute_value['b1_seq_num'])
        self.log.debug(f"Query to get existing b1 data: {query}")
        for result in self.cb.n1ql_query(query):
            return result

        return ''

    def getSequenceNumber(self, attribute_value):

        count = 1
        auth_id = ''
        code = []
        prescription_id = ''

        query = N1QLQuery('Select auth_id, prescription_id, claim_request.transaction_code,sequenceNumber  from `'+self.instance_type+'` where type="claim" and prescription_id is not missing and claim_request.service_provider_id=$v1 and claim_request.prescription_reference_number=$v2 and claim_request.fill_number=$v3 and claim_request.gpi=$v4 order by updateDate',
                          v1=attribute_value[0], v2=attribute_value[1], v3=attribute_value[2], v4=attribute_value[3])
        self.log.debug(
            f"Query to get the next sequence number for the claim: {query}")
        for result in self.cb.n1ql_query(query):
            count = count + 1
            auth_id = result['auth_id']
            prescription_id = result['prescription_id']
            if result['transaction_code'] in ['B1', 'B2']:
                code.append(result['transaction_code'])

        return count, auth_id, code, prescription_id

    def getClaims(self, attribute_value):
        finalresult = []
        attribute_value = [x for x in attribute_value if x]
        query = N1QLQuery(
            'Select responseData,claim_response,auth_id, prescription_id, claim_request,sequenceNumber  from `' + self.instance_type +
            '` where type="claim" and claim_request.service_provider_id=$v1 and '
            'claim_request.prescription_reference_number=$v2 and claim_request.gpi=$v3 '
            ' order by startDate desc', v1=attribute_value[0],
            v2=attribute_value[1], v3=attribute_value[2])
        if len(attribute_value) == 5:

            query = N1QLQuery(
                'Select responseData,claim_response,auth_id, prescription_id, claim_request,sequenceNumber  from `' + self.instance_type +
                '` where type="claim" and claim_request.service_provider_id=$v1 and '
                'claim_request.prescription_reference_number=$v2 and '
                'claim_request.gpi=$v3 '
                'and (claim_request.cardholder_id like $v4 or claim_request.original_cardholder_id like $v7 or claim_request.tpa_member_id=$v6) and '
                'tostring(tonumber(claim_request.fill_number))=$v5 order by startDate desc',
                v1=attribute_value[0], v2=attribute_value[1],
                v3=attribute_value[2], v4='%'+attribute_value[3]+'%',
                v5=attribute_value[4], v6=attribute_value[3], v7='%'+attribute_value[3][:-2]+'%')
        self.log.debug(f"Query used to find the existing claim: {query}")

        for result in self.cb.n1ql_query(query):
            finalresult.append(result)

        return finalresult

    def getDomainFlags(self, attribute_value):

        domain_flags = {}

        query = N1QLQuery('Select * from `'
                          + self.instance_type+'` where type="domain" and domain=$v', v=attribute_value)
        self.log.debug(f"Query to get the domain information : {query}")
        for result in self.cb.n1ql_query(query):
            domain_flags.update(result[self.instance_type])

        return domain_flags

    def getPrescriberRestrictionFlag(self, attribute_value):

        query = N1QLQuery('Select prescriber_restriction_flag from `' +
                          self.instance_type+'` where type="rxplan_master" and domain_name=$v1 and '
                                             'plan_name=$v2 and plan_year=$v3',
                          v1=attribute_value[0], v2=attribute_value[1], v3=attribute_value[2])
        for result in self.cb.n1ql_query(query):
            return result['prescriber_restriction_flag']

        return 'N'

    def getIntentData(self, attribute_value):
        data = self.cb.get(attribute_value, quiet=True)
        data = data.value
        return data

    def getRewardData(self, attribute_value):

        query = N1QLQuery('Select meta().id id from `'+self.instance_type +
                          '` where type="rewardtransaction" and prescription_id=$v1', v1=attribute_value[0])
        for result in self.cb.n1ql_query(query):
            return result['id']

        return ''

    def getRxhistoryData(self, attribute_value):

        query = N1QLQuery('select meta().id as id from `' + self.instance_type +
                          '` Where type = "rx_history" and drug_name = $drug and gpi = $gpi and flipt_person_id = $rx_flipt_id', drug=attribute_value['drug_name'], gpi=attribute_value['gpi'], rx_flipt_id=attribute_value['rx_flipt_person_id'])
        for result in self.cb.n1ql_query(query):
            return result['id']

        return ''

    def getLastFilledPrescription(self, attribute_value, limit):

        single_result = ''
        if limit:
            single_result = 'limit 1'

        query = N1QLQuery('select filled_date, tonumber(daysofsupply) daysofsupply, pharmacy, npi, location, prescription_id from `' + self.instance_type +
                          '` Where type = "prescription" and drug_name = $drug and gpi = $gpi and flipt_person_id = $rx_flipt_id and rx_status="Filled" order by filled_date desc '+single_result, drug=attribute_value['drug_name'], gpi=attribute_value['gpi'], rx_flipt_id=attribute_value['rx_flipt_person_id'])
        self.log.debug(f"Query to get the last filled prescription: {query}")
        for result in self.cb.n1ql_query(query):
            if isinstance(result, dict):
                return [result]
            return result

        return []

    def updateIntent(self, docid, attribute_value):
        for key, value in attribute_value.items():
            if not isinstance(value, dict):
                self.cb.mutate_in(docid, SD.upsert(
                    key, str(value)))
            else:
                def nestedInsert(pathstring, currkey, currvalue):
                    if not isinstance(list(currvalue.values())[0], dict):
                        self.cb.mutate_in(docid, SD.upsert(
                            pathstring, currvalue, create_parents=True))
                        return
                    else:
                        for k, v in currvalue.items():
                            if isinstance(v, dict):
                                pathstring = pathstring + '.' + k
                            nestedInsert(pathstring, k, v)
                            pathstring = pathstring.replace(str('.'+k), '')

                nestedInsert(key, key, value[key])

    def getClaimProcessor(self, attribute_value):
        query = N1QLQuery('Select claim_processor, transfer_rxbin, transfer_rxpcn, is_flipt_contract from `'+self.instance_type +
                          '` where type="claim_processor" and rxbin=$v1 and rxpcn=$v2',
                          v1=attribute_value['rxbin'], v2=attribute_value['rxpcn'])
        self.log.debug(
            f"query to get the claim processor information : {query}")
        for result in self.cb.n1ql_query(query):
            return result

        return None

    def getNextICN(self):

        counter = str(self.cb.counter('icncounter', delta=1).value)
        return counter

    def saveRewards(self, data):

        docid = 'rewardtransaction::' + \
            str(self.cb.counter('rewardtransaction_counter', delta=1).value)
        data.update({'id': docid})
        response = self.cb.upsert(docid, data)

    def saveRxHistoryData(self, docid, data):

        if docid == '':
            docid = 'rx_history::' + \
                str(self.cb.counter('docid', delta=1).value)
        response = self.cb.upsert(docid, data)

    def findRewards(self, attribute_value):

        query = N1QLQuery('select meta().id as id from `' + self.instance_type +
                          '` Where type = "rewardtransaction" and prescription_id = $v', v=attribute_value['prescription_id'])
        for result in self.cb.n1ql_query(query):
            return result['id']

        return ''

    def getPAOverrideData(self, data):

        query = N1QLQuery('select override_id from `' + self.instance_type +
                          '` Where type = "pa_override" and drug_name = $drug and gpi = $gpi and brand_generic=$bg and rx_flipt_person_id = $rx_flipt_id and pa_override_status="Active" and  pa_override_start_date<=$date_of_service and pa_override_end_date>=$date_of_service limit 1 ', drug=data['drug_name'], gpi=data['gpi'], rx_flipt_id=data['rx_flipt_person_id'], bg=data['brand_generic'], date_of_service=data['date_of_service'])

        for result in self.cb.n1ql_query(query):
            if isinstance(result, dict):
                return [result]
            return result

    def removeData(self, docid):

        response = self.cb.remove(docid)
