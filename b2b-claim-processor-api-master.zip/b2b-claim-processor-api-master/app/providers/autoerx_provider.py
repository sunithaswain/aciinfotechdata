from couchbase.n1ql import N1QLQuery
import couchbase.subdocument as SD
from datetime import datetime
import logging


class AutoerxProvider(object):

    def __init__(self, config):

        self.config = config
        self.cb = self.config.cb
        self.instance_type = self.config.CB_INSTANCE
        self.log = logging.getLogger()

        # def get_otc_info_from_formulary(self, attribute_values):
    #     if attribute_values['brand_generic'] == 'B':
    #         attribute_values['brand_generic'] = 'T'
    #     _query_string = f"SELECT company_formulary, ARRAY cf FOR cf IN company_formulary WHEN cf.company = '" \
    #                  f"{attribute_values['domain_name']}' AND cf.plan_name = '{attribute_values['plan_name']}' AND " \
    #                  f"cf.effective_start_date='{attribute_values['plan_start_date']}' AND cf.effective_end_date='{attribute_values['plan_end_date']}' END as cf FROM `{self.instance_type}` WHERE " \
    #                  f"type='formulary' AND gpi='{attribute_values['gpi']}'  AND " \
    #                  f"drug_name='{attribute_values['drug_name']}' AND brand_generic='{attribute_values['brand_generic']}'"
    #
    #     query = N1QLQuery(_query_string)
    #
    #     for result in self.cb.n1ql_query(query):
    #         return result.get('cf', {})
    #
    #     return {}
    def _get_rxplaninfo(self, plan_information):
        base_query = f"SELECT * FROM `{self.instance_type}` WHERE type='rxplan_master' AND domain_name='" \
                     f"{plan_information['domain_name']}' AND plan_name='{plan_information['plan_name']}' AN" \
                     f"D plan_end_date>='{plan_information['date_of_service']}' AND plan_start_date<='{plan_information['date_of_service']}'"
        query = N1QLQuery(base_query)
        self.log.debug(f"Query to get rxplan info: {query}")
        for result in self.cb.n1ql_query(query):
            return result[self.instance_type]

        return {}

    def _get_deductibleinfo(self, attribute_value, individual):

        field = 'emp_flipt_person_id'
        if individual:
            field = 'dep_flipt_person_id'
        deductible = 0
        opc = 0
        query = N1QLQuery("Select sum(tonumber(deductible_accrued)) deductible_accrued,sum(tonumber(out_of_pocket_accrued)) out_of_pocket_accrued from `" +
                          self.instance_type + "` where type='deductible' and " + field + "=$v1 and plan_year=$v2", v1=attribute_value['flipt_person_id'], v2=attribute_value['plan_year'])
        self.log.debug(f"Query for getting _get_deductibleinfo: {query}")
        for res in self.cb.n1ql_query(query):
            if res['deductible_accrued']:
                deductible = res['deductible_accrued']
            if res['out_of_pocket_accrued']:
                opc = res['out_of_pocket_accrued']
        return deductible, opc

    def _get_drugrestricted_info(self, attribute_value1, attribute_value2, attribute_value3, attribute_value4):
        query = N1QLQuery('select ARRAY_CONTAINS(pharmacy_restrict, $v) AS dgr from `'+self.instance_type +
                          '` where type="rxplan_master" and plan_name = $pname and plan_year = $pyr and domain_name = $dname', v=attribute_value1, pname=attribute_value2, pyr=attribute_value3, dname=attribute_value4)
        self.log.debug(f"Query for getting _get_drugrestricted_info: {query}")
        for result in self.cb.n1ql_query(query):
            if result['dgr'] == True:
                return True
        return False

    # To get pharmacytype for retail check and to know whether pharmacy is active or inactive.

    def _get_pharmacy_info(self, attribute_value):
        query = N1QLQuery('Select cp_pharmacy_info,pharmacyzip1,geo_lat,geo_lng,pharmacytype,wl_name,pharmacyaddress1,pharmacynpi, pharmacyname from `' +
                          self.instance_type+'` where type="cp_pharmacy" and pharmacynpi=$v', v=attribute_value)
        record = {}
        self.log.debug(f"Query for getting _get_pharmacy_info: {query}")
        for res in self.cb.n1ql_query(query):
            record.update(res)
        return record

    # To check if prescription is available.

    def _get_presc_info(self, attribute_value1, attribute_value2, attribute_value3):
        query = N1QLQuery('Select prescription_id from `'+self.instance_type +
                          '` where type="prescription" and rx_status="New" and gpi=$gpi and rx_flipt_person_id=$rxid and prescription_id in $prescid', rxid=attribute_value1, prescid=attribute_value2, gpi=attribute_value3)
        self.log.debug(f"Query for getting _get_presc_info: {query}")
        for r in self.cb.n1ql_query(query):
            return True
        return False

    def getPrescriptionCounter(self):

        prescid = str(self.cb.counter('prescription_counter', delta=1).value)
        prescid = 'prescription::'+str(prescid)
        response = self.cb.upsert(prescid, {})
        return prescid

    def get_drug_info(self, attribute_dict):
        attribute_dict = attribute_dict or {}

        query_filter = map(
            lambda x: f"{x[0]}='{x[1]}'", attribute_dict.items())
        # query_filter = (list(starmap(lambda key, value: f"{key}='{value}'", attribute_dict.items())))
        query_filter = " and ".join(query_filter)
        query = f"select * from `{self.instance_type}` where type='drug'"
        if query:
            query = f"{query} and {query_filter}"
        result = []
        res = self.cb.n1ql_query(N1QLQuery(query))
        self.log.debug(f"Query for getting _get_drug_info: {query}")
        for r in res:
            result.append(r[f'{self.instance_type}'])
        return result

        # data = []
        # result = self.cb.n1ql_query(query)
        # for i in result:
        #     print(i[f'{self.instance_type}'])
        #     data.append(i[f'{self.instance_type}'])
        # return data
    # def _get_ndcdrug_info(self, attribute_value):
    #     query = N1QLQuery('Select gpi,gppc,drug_name,custom_qty,dosage_strength,package_desc,package_qty,package_quantity,package_size,pkg_desc_cd,pkg_uom,quantity_type,strengths  from `' +
    #                       self.instance_type+'` where type="ndc_drugs" and ndc=$v', v=attribute_value)
    #     for res in self.cb.n1ql_query(query):
    #         return res
    #
    #     return {}

    def _get_notification_log(self, attribute_value):

        query = N1QLQuery("Select time_message_sent, status, meta().id from `" + self.instance_type +
                          "` where type='notification_log' and flipt_person_id = $flp and phone_number = $pn order by time_message_sent desc", flp=attribute_value['flipt_person_id'], pn='+1 ' + attribute_value['phone'])
        self.log.debug(f"Query for getting _get_notification_log: {query}")
        for res in self.cb.n1ql_query(query):
            return res

        return []

    def get_claimprocessor_info(self, attribute_value):

        query = N1QLQuery("Select rxbin,rxpcn,is_flipt_contract from `" + self.instance_type +
                          "` where type='claim_processor' and claim_processor=$v", v=attribute_value)
        self.log.debug(f"Query for getting _get_claimprocessor_info: {query}")
        for res in self.cb.n1ql_query(query):
            return res

        return {}

    def _get_rx_history_info(self, attribute_value):
        query = N1QLQuery("Select start_date from `" + self.instance_type + "` where type='rx_history' and flipt_person_id=$fid and gpi=$gpi and drug_name=$dn and start_date>$aed",
                          dn=attribute_value['drug_name'], gpi=attribute_value['gpi'], fid=attribute_value['rx_flipt_person_id'], aed=attribute_value['alternate_effective_date'])
        self.log.debug(f"Query for getting _get_rx_history_info: {query}")
        for res in self.cb.n1ql_query(query):
            return res

        return []

    def _get_drug_alternative_info(self, attribute_value):

        query = N1QLQuery("Select TONUMBER(alternate_drug_reward_per_unit) alternate_drug_reward_per_unit from `" + self.instance_type + "` where type='drug_alternative' and gpi=$gpi and drug_name=$dn limit 1",
                          gpi=attribute_value['gpi'], dn=attribute_value['drug_name'])
        self.log.debug(
            f"Query for getting _get_drug_alternative_info: {query}")
        for res in self.cb.n1ql_query(query):
            return res['alternate_drug_reward_per_unit']

            return None

    def _get_reward_details(self, attribute_value):

        query = N1QLQuery("Select IFNULL(SUM(TONUMBER(reward_amount)),0) reward_amount from `" + self.instance_type +
                          "` where type='rewardtransaction' and flipt_person_id=$fid and date_part_str(reward_date,'year')=$yr", fid=attribute_value['flipt_person_id'], yr=attribute_value['year'])
        self.log.debug(f"Query for getting _get_reward_details info: {query}")
        for res in self.cb.n1ql_query(query):
            return res['reward_amount']

            return 0

    def get_unit_price(self, attribute_dict):
        table_alias = "b"
        attribute_dict = attribute_dict or {}
        query_filter = list(
            map(lambda x: f"{table_alias}.{x[0]}='{x[1]}'", attribute_dict.items()))
        query_filter = " and ".join(query_filter)

        query = (f"Select distinct cp.payer_brand_generic,cp.maclistid,cp.pricetype,cp.claim_processor,tonumber(cp.unitprice) unitprice,"
                 f"tonumber(cp.unit_price_before_rebate) unit_price_before_rebate, b.brandorgeneric, {table_alias}.gppc from "
                 f"`{self.instance_type}` {table_alias} unnest {table_alias}.cp_price cp  where "
                 f"{table_alias}.type='cp_drug_price'")
        if query:
            query = f"{query} and {query_filter}"
        result = []
        self.log.debug(f"Query for getting unit price info: {query}")
        for res in self.cb.n1ql_query(N1QLQuery(query)):
            result.append(res)
        return result

    def _get_formulary_info(self, attribute_value):
        query = N1QLQuery(
            "Select company_formulary,copay_type, pa_flag, deductibleexempted, "
            "copay_30daysupply,copay_60daysupply, copay_90daysupply, "
            "copayabove90daysupply, co_ins_min_amount, co_ins_max_amount "
            "from `" + self.instance_type + "` where type='formulary' and gpi=$v1 and "
            "brand_generic=$v2 and drug_name=$v4 and ((company=$v3 and plan_name=$v5 and plan_year=$v6) "
            "or (company is missing))", v1=attribute_value['gpi'], v2=attribute_value['brand_generic'], v3=attribute_value['domain'], v4=attribute_value['drug_name'], v5=attribute_value['plan_name'], v6=attribute_value['plan_year'])
        self.log.debug(f"Query for getting formulary info: {query}")
        for res in self.cb.n1ql_query(query):

            return res

        return {}

    def _update_intent(self, docid, attribute_value):

        for key, value in attribute_value.items():
            self.cb.mutate_in(docid, SD.upsert(key, str(value)))

    def _save_data(self, data):

        docid = str(self.cb.counter('docid', delta=1).value)
        response = self.cb.upsert(docid, data)
        return response.key

    # def _get_manufacturer_info(self, plan_info, drug_info):
    #     base_query = f"select  domain from `{self.instance_type}` where type = 'rra_drugs' " \
    #         f"and benefit_plan_name = '{plan_info['plan_name']}' " \
    #         f"and plan_start_date <= '{plan_info['plan_start_date']}' " \
    #         f"and plan_end_date >= '{plan_info['plan_end_date']}' " \
    #         f"and domain = '{plan_info['domain_name']}' " \
    #         f"and drug-name = '{drug_info['drug_name']}' " \
    #         f"and gpi = '{drug_info['gpi']}' " \
    #         f"and brand_generic = '{drug_info['brand_generic']}'"
    #
    #     query = N1QLQuery(base_query)
    #     self.manufacturer_info = self.cb.n1ql_query(query).get_single_result()
    #     return self.manufacturer_info

    def get_presc_cnt(self, gpi, drug_name, coverage_effective_date, coverage_end_date, flipt_person_id):
        # mail_order_pharmacies = ['AMBER PHARMACY', 'HUMANA SPECIALTY', 'HUMANA MAIL ORDER', 'EXACT CARE PHARMACY',
        #                          'NOVARTIS-ONSITE PHARMACY', 'SPECIALTY MAIL DELIVERY']
        coverage_effective_date = coverage_effective_date.replace(' ', 'T')
        coverage_end_date = coverage_end_date.replace(' ', 'T')
        count_query = f"select count(*) as fill_count, sum(tonumber(daysofsupply)) as days_of_supply from `{self.instance_type}`" \
            f" where type = 'prescription' and " \
            f"member_id = '{flipt_person_id}' and gpi = '{gpi}' and drug_name='{drug_name}' and " \
            f"filled_date>='{coverage_effective_date}' and filled_date<='{coverage_end_date}' and " \
            f"pharmacy_type = 'RETAIL' and rx_status = 'Filled'"
        self.log.debug(f"Query for getting presc count: {count_query}")
        query = N1QLQuery(count_query)
        self.presc_count = self.cb.n1ql_query(query).get_single_result()
        return self.presc_count

    def get_manufacturer(self, ndc_info):
        manufac_query = f"select domain from `{self.instance_type}` where type = 'rra_drugs' and drug_name = '{ndc_info['drug_name']}' and " \
            f"'{ndc_info['ndc']}' in ndc"
        query = N1QLQuery(manufac_query)
        self.log.debug(f"Query for getting manufacturer details: {query}")
        self.manufacturer = self.cb.n1ql_query(query).get_single_result()
        return self.manufacturer
