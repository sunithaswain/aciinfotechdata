class B1ClaimResponse:

    def __init__(self, requestdata, otherinfo):

        self.headerseg = B1ClaimResponse.Header("", {}, '')
        self.messageseg = B1ClaimResponse.MessageSegment({}, '')
        self.insuranceseg = B1ClaimResponse.InsuranceSegment("", {}, '')
        self.patientseg = B1ClaimResponse.PatientSegment("", {}, '')
        self.statusseg = B1ClaimResponse.StatusSegment("", {}, '')
        self.claimseg = B1ClaimResponse.ClaimSegment("", {}, '')
        self.pricingseg = B1ClaimResponse.PricingSegment("", {}, '')
        self.requestdata = requestdata
        self.otherinfo = otherinfo
        self.responsetype = ''
        self.responseclaim = {}
        self.responseString = ''
        #self.log = logging.getLogger(__name__)

    def setAttributes(self):

        #self.log.debug("Setting attributes for the reposne data")
        if 'responsetype' in self.otherinfo and self.otherinfo['responsetype'] == 'Duplicate':
            self.responsetype = 2
        elif self.otherinfo['rejectioncode'] or self.otherinfo['intent_absent']:
            self.responsetype = 3
        else:
            self.responsetype = 1

        self.headerseg = B1ClaimResponse.Header(
            self.requestdata, self.otherinfo, self.responsetype)
        self.messageseg = B1ClaimResponse.MessageSegment(
            self.otherinfo, self.responsetype)
        self.insuranceseg = B1ClaimResponse.InsuranceSegment(
            self.requestdata, self.otherinfo, self.responsetype)
        self.patientseg = B1ClaimResponse.PatientSegment(
            self.requestdata, self.otherinfo, self.responsetype)
        self.statusseg = B1ClaimResponse.StatusSegment(
            self.requestdata, self.otherinfo, self.responsetype)
        self.claimseg = B1ClaimResponse.ClaimSegment(
            self.requestdata, self.otherinfo, self.responsetype)
        self.pricingseg = B1ClaimResponse.PricingSegment(
            self.requestdata, self.otherinfo, self.responsetype)

        self.headerseg.setAttributes()
        self.messageseg.setAttributes()
        self.insuranceseg.setAttributes()
        self.patientseg.setAttributes()
        self.statusseg.setAttributes()
        self.claimseg.setAttributes()
        self.pricingseg.setAttributes()
        self.prepareResponse()

        return self

    def prepareResponse(self):
        #self.log.debug("Preparing reponse data")

        self.responseclaim['claim_response'] = {}

        self.responseclaim['claim_response'].update(
            self.headerseg.__dict__)
        self.responseclaim['claim_response'].update(
            self.messageseg.__dict__)
        self.responseclaim['claim_response'].update(
            self.insuranceseg.__dict__)
        self.responseclaim['claim_response'].update(
            self.patientseg.__dict__)
        self.responseclaim['claim_response'].update(
            self.statusseg.__dict__)
        self.responseclaim['claim_response'].update(
            self.claimseg.__dict__)
        self.responseclaim['claim_response'].update(
            self.pricingseg.__dict__)

        phi_fields = ['patient_first_name','patient_last_name']
        for field in phi_fields:
            self.responseclaim['claim_response'].pop(field, None)

        eliminate_fields = ['responseString','requestdata','otherinfo','responsetype']

        for field in  eliminate_fields:
            self.responseclaim['claim_response'].pop(field, None)

        if self.headerseg.responseString:
            self.responseString = self.headerseg.responseString.strip()
        if self.messageseg.responseString:
            self.responseString += '\x1e\x1cAM20\x1c' + self.messageseg.responseString.strip()
        if self.insuranceseg.responseString:
            self.responseString += '\x1e\x1cAM25\x1c' + self.insuranceseg.responseString.strip()
        if self.patientseg.responseString:
            self.responseString += '\x1e\x1cAM29\x1c' + self.patientseg.responseString.strip()
        if self.statusseg.responseString:
            self.responseString += '\x1d\x1e\x1cAM21\x1c' + self.statusseg.responseString.strip()
        if self.claimseg.responseString:
            self.responseString += '\x1e\x1cAM22\x1c' + self.claimseg.responseString.strip()
        if self.pricingseg.responseString:
            self.responseString += '\x1e\x1cAM23\x1c' + self.pricingseg.responseString.strip()

        #print(self.responseString.encode(),'----')

        self.responseString = self.responseString.encode().decode()
        #self.responseString = self.responseString.encode('utf-8')

    class Header:
        def __init__(self, requestdata, otherinfo, responsetype):
            self.version = ''
            self.transaction_code = ''
            self.transaction_count = ''
            self.response_status = ''
            self.service_provider_id_qualifier = ''
            self.service_provider_id = ''
            self.date_of_service = ''
            self.responseString = ''
            self.requestdata = requestdata
            self.otherinfo = otherinfo
            self.responsetype = responsetype
            #self.log = logging.getLogger(__name__)

        def setAttributes(self):
            #self.log.debug("Setting Header for the reposne data")
            self.version = 'D0'
            self.transaction_code = self.requestdata.ClaimRequest.header.transaction_code
            self.transaction_count = self.requestdata.ClaimRequest.header.transaction_count
            # For a transmission the response status should always be Accepted (A)
            self.response_status = 'A'
            self.service_provider_id_qualifier = self.requestdata.ClaimRequest.header.service_provider_id_qualifier
            self.service_provider_id = self.requestdata.ClaimRequest.header.service_provider_id
            self.date_of_service = self.requestdata.ClaimRequest.header.date_of_service
            responseformat = {'version': {'type': [1, 2, 3]},
                              'transaction_code': {'type': [1, 2, 3]},
                              'transaction_count': {'type': [1, 2, 3]},
                              'response_status': {'type': [1, 2, 3]},
                              'service_provider_id_qualifier': {'type': [1, 2, 3]},
                              'service_provider_id': {'type': [1, 2, 3]},
                              'date_of_service': {'type': [1, 2, 3]}}
            for key, value in responseformat.items():
                if key == 'service_provider_id':
                    self.responseString = self.responseString + \
                        (self.__dict__[key] + '     ')
                    continue
                if self.responsetype in value['type'] and self.__dict__[key]:
                    self.responseString = self.responseString + self.__dict__[key]
            self.responseString = self.responseString

    class MessageSegment:
        def __init__(self, otherinfo, responsetype):
            self.message = ''
            self.responseString = ''
            self.otherinfo = otherinfo
            self.responsetype = responsetype
            #self.log = logging.getLogger(__name__)

        def setAttributes(self):

            if self.responsetype == 3:
                self.message = self.otherinfo['rejectionreason']

            responseformat = {'message': {'type': [3], 'code': 'F4'}}
            for key, value in responseformat.items():
                if self.responsetype in value['type'] and self.__dict__[key]:
                    self.responseString = self.responseString + '\x1c' + \
                        value['code'] + self.__dict__[key]

    class InsuranceSegment:
        def __init__(self, requestdata, otherinfo, responsetype):
            self.group_id = ''
            self.plan_id = ''
            self.network_reimbursement_id = ''
            self.payer_id_qualifier = ''
            self.payer_id = ''
            self.cardholder_id = ''
            self.responseString = ''
            self.requestdata = requestdata
            self.otherinfo = otherinfo
            self.responsetype = responsetype
            #self.log = logging.getLogger(__name__)

        def setAttributes(self):
            self.group_id = self.requestdata.ClaimRequest.insuranceseg.group_id
            self.plan_id = self.requestdata.ClaimRequest.insuranceseg.plan_id
            self.network_reimbursement_id = ''
            self.payer_id_qualifier = ''
            self.payer_id = ''
            self.cardholder_id = self.requestdata.ClaimRequest.insuranceseg.cardholder_id
            responseformat = {'group_id': {'type': [1, 2, 3], 'code': 'C1'},
                              'plan_id': {'type': [1, 2, 3], 'code': 'FO'},
                              'network_reimbursement_id': {'type': [1, 2, 3], 'code': '2F'},
                              'payer_id_qualifier': {'type': [1, 2, 3], 'code': 'J7'},
                              'payer_id': {'type': [1, 2, 3], 'code': 'J8'},
                              'cardholder_id': {'type': [1, 2, 3], 'code': 'C2'}}
            for key, value in responseformat.items():
                if self.responsetype in value['type'] and self.__dict__[key]:
                    self.responseString = self.responseString + '\x1c' + \
                        value['code'] + self.__dict__[key]

    class PatientSegment:
        def __init__(self, requestdata, otherinfo, responsetype):
            self.patient_first_name = ''
            self.patient_last_name = ''
            self.date_of_birth = ''
            self.responseString = ''
            self.requestdata = requestdata
            self.otherinfo = otherinfo
            self.responsetype = responsetype
            #self.log = logging.getLogger(__name__)

        def setAttributes(self):
            if self.requestdata.ClaimRequest.patientseg.patient_first_name:
                self.patient_first_name = self.requestdata.ClaimRequest.patientseg.patient_first_name
                self.patient_last_name = self.requestdata.ClaimRequest.patientseg.patient_last_name
            else:
                self.patient_first_name = self.requestdata.ClaimRequest.insuranceseg.cardholder_first_name
                self.patient_last_name = self.requestdata.ClaimRequest.insuranceseg.cardholder_last_name

            self.date_of_birth = self.requestdata.ClaimRequest.patientseg.date_of_birth

            responseformat = {'patient_first_name': {'type': [1, 2], 'code': 'CA'},
                              'patient_last_name': {'type': [1, 2], 'code': 'CB'},
                              'date_of_birth': {'type': [1, 2], 'code': 'C4'}}
            for key, value in responseformat.items():
                if self.responsetype in value['type'] and self.__dict__[key]:
                    self.responseString = self.responseString + '\x1c' + \
                        value['code'] + self.__dict__[key]

    class StatusSegment:
        def __init__(self, requestdata, otherinfo, responsetype):
            self.transaction_response_status = ''
            self.authorization_number = ''
            self.reject_count = ''
            self.reject_code = ''
            self.reject_field_occurrence_indicator = ''
            self.additional_message_information_count = ''
            self.additional_message_information_qualifier = ''
            self.additional_message_information = ''
            self.additional_message_information_continuity = ''
            self.help_desk_phone_number_qualifier = ''
            self.help_desk_phone_number = ''
            self.url = ''
            self.responseString = ''
            self.requestdata = requestdata
            self.otherinfo = otherinfo
            self.responsetype = responsetype
            #self.log = logging.getLogger(__name__)

        def setAttributes(self):
            if self.otherinfo['rejectioncode'] and self.responsetype==3:
                self.transaction_response_status = 'R'
                self.reject_count = '1'
            elif self.responsetype == 2:
                self.transaction_response_status='D'
            else:
                self.transaction_response_status = 'P'
            self.authorization_number = self.requestdata.auth_id

            if self.responsetype == 3:
                self.reject_code = self.otherinfo['rejectioncode']
            self.reject_field_occurrence_indicator = ''
            if  self.otherinfo['message'] and self.responsetype==3:
                self.additional_message_information_count = '1'
                self.additional_message_information_qualifier = '01'
                self.additional_message_information = self.otherinfo['message']
            self.additional_message_information_continuity = ''
            if 'phone' in self.otherinfo:
                self.help_desk_phone_number_qualifier = '03'
                self.help_desk_phone_number = self.otherinfo['phone']
            self.url = ''
            responseformat = {'transaction_response_status': {'type': [1, 2, 3], 'code': 'AN'},
                              'authorization_number': {'type': [1, 2, 3], 'code': 'F3'},
                              'reject_count': {'type': [3], 'code': 'FA'},
                              'reject_code': {'type': [3], 'code': 'FB'},
                              'reject_field_occurrence_indicator': {'type': [3], 'code': '4F'},
                              'additional_message_information_count': {'type': [1, 2, 3], 'code': 'UF'},
                              'additional_message_information_qualifier': {'type': [1, 2, 3], 'code': 'UH'},
                              'additional_message_information': {'type': [1, 2, 3], 'code': 'FQ'},
                              'additional_message_information_continuity': {'type': [3], 'code': 'UG'},
                              'help_desk_phone_number_qualifier': {'type': [1, 2, 3], 'code': '7F'},
                              'help_desk_phone_number': {'type': [1, 2, 3], 'code': '8F'},
                              'url': {'type': [1,2, 3], 'code': 'MA'}}
            for key, value in responseformat.items():
                if self.responsetype in value['type'] and self.__dict__[key]:
                    self.responseString = self.responseString + '\x1c' + \
                        value['code'] + self.__dict__[key]

    class ClaimSegment:
        def __init__(self, requestdata, otherinfo, responsetype):
            self.prescription_reference_number_qualifier = ''
            self.prescription_reference_number = ''
            self.product_count = ''
            self.product_id_qualifier = ''
            self.product_id = ''
            self.product_incentive = ''
            self.product_cost_share_incentive = ''
            self.product_description = ''
            self.responseString = ''
            self.requestdata = requestdata
            self.otherinfo = otherinfo
            self.responsetype = responsetype
            #self.log = logging.getLogger(__name__)

        def setAttributes(self):
            if self.requestdata.ClaimRequest.claimsseg.prescription_reference_number_qualifier:
                self.prescription_reference_number_qualifier = self.requestdata.ClaimRequest.claimsseg.prescription_reference_number_qualifier
            else:
                self.prescription_reference_number_qualifier = '1'
            self.prescription_reference_number = self.requestdata.ClaimRequest.claimsseg.prescription_reference_number
            self.product_count = '1'
            self.product_id_qualifier = ''
            self.product_id = ''
            self.product_incentive = ''
            self.product_cost_share_incentive = ''
            self.product_description = ''
            responseformat = {'prescription_reference_number_qualifier': {'type': [1, 2, 3], 'code': 'EM'},
                              'prescription_reference_number': {'type': [1, 2, 3], 'code': 'D2'},
                              'product_count': {'type': [1, 2], 'code': '9F'},
                              'product_id_qualifier': {'type': [1, 2], 'code': 'AP'},
                              'product_id': {'type': [1, 2], 'code': 'AR'},
                              'product_incentive': {'type': [2], 'code': 'AS'},
                              'product_cost_share_incentive': {'type': [2], 'code': 'AT'},
                              'product_description': {'type': [2], 'code': 'AU'}}
            for key, value in responseformat.items():
                if self.responsetype in value['type'] and self.__dict__[key]:
                    self.responseString = self.responseString + '\x1c' + \
                        value['code'] + self.__dict__[key]

    class PricingSegment:
        def __init__(self, requestdata, otherinfo, responsetype):
            self.patient_pay_amount = ''
            self.ingredient_cost_paid = ''
            self.dispensing_fee_paid = ''
            self.tax_exempt_indicator = ''
            self.other_amount_paid_count = ''
            self.other_amount_paid_qualifier = ''
            self.other_amount_paid = ''
            self.basis_of_reimbursement_determination = ''
            self.amount_attributed_to_sales_tax = ''
            self.amount_of_copay = ''
            self.flat_sales_tax_amount_paid = ''
            self.patient_sales_tax_amount = ''
            self.total_amount_paid = ''
            self.responseString = ''
            self.requestdata = requestdata
            self.otherinfo = otherinfo
            self.responsetype = responsetype
            #self.log = logging.getLogger(__name__)

        def sanitize_segment_value(self, val):
            positive_prefixes = {0: '{', 1: 'A',
                                 2: 'B', 3: 'C',
                                 4: 'D', 5: 'E',
                                 6: 'F', 7: 'G',
                                 8: 'H', 9: 'I'}

            negative_prefixes = {0: '}', 1: 'J',
                                 2: 'K', 3: 'L',
                                 4: 'M', 5: 'N',
                                 6: 'O', 7: 'P',
                                 8: 'Q', 9: 'R'}

            val = str(val)
            if "." not in val:
                return val

            val = round(float(val), 2)
            f = "%.2f" % val  # restrict float to 2 decimal points
            prefix_list = negative_prefixes if f[0] == "-" else positive_prefixes
            f = f.replace(".", "")  # remove point from float
            return f[:-1] + prefix_list[int(f[-1])]

        def setAttributes(self):
            if not self.otherinfo['prescription']:
                return
            self.patient_pay_amount = str(round(float(self.otherinfo['prescription']['employee_opc']), 2))
            self.ingredient_cost_paid = str(round(float(self.otherinfo['prescription']['drug_cost']) - float(
                self.otherinfo['prescription']['pharmacy_dispensing_fee']), 2))
            self.dispensing_fee_paid = str(round(float(
                self.otherinfo['prescription']['pharmacy_dispensing_fee']), 2))
            self.tax_exempt_indicator = '1'
            self.other_amount_paid_count = '1'
            self.other_amount_paid_qualifier = ''
            self.other_amount_paid = ''
            self.total_amount_paid = str(round(float(self.otherinfo['prescription']['drug_cost']) - float(
                self.otherinfo['prescription']['employee_opc']), 2))
            self.basis_of_reimbursement_determination = ''
            self.amount_attributed_to_sales_tax = ''
            self.amount_of_copay = ''
            self.flat_sales_tax_amount_paid = ''
            self.patient_sales_tax_amount = ''
            responseformat = {'patient_pay_amount': {'type': [1, 2], 'code': 'F5'},  # key , value
                              'ingredient_cost_paid': {'type': [1, 2], 'code': 'F6'},
                              'dispensing_fee_paid': {'type': [1, 2], 'code': 'F7'},
                              'tax_exempt_indicator': {'type': [1, 2], 'code': 'AV'},
                              'other_amount_paid_count': {'type': [1, 2], 'code': 'J2'},
                              'other_amount_paid_qualifier': {'type': [1, 2], 'code': 'J3'},
                              'other_amount_paid': {'type': [1, 2], 'code': 'J4'},
                              'total_amount_paid': {'type': [1, 2], 'code': 'F9'},
                              'basis_of_reimbursement_determination': {'type': [1, 2], 'code': 'FM'},
                              'amount_attributed_to_sales_tax': {'type': [1, 2], 'code': 'FN'},
                              'amount_of_copay': {'type': [1, 2], 'code': 'FI'},
                              'flat_sales_tax_amount_paid': {'type': [1, 2], 'code': 'AW'},
                              'patient_sales_tax_amount': {'type': [1, 2], 'code': 'EQ'}}
            for key, value in responseformat.items():
                if self.responsetype in value['type'] and self.__dict__[key]:
                    self.responseString = self.responseString + '\x1c' + value['code'] + self.sanitize_segment_value(
                        self.__dict__[key])
