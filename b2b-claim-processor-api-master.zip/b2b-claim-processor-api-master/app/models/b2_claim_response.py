class B2ClaimResponse:

    def __init__(self, requestdata, otherinfo):

        self.headerseg = B2ClaimResponse.Header("", {}, '')
        self.messageseg = B2ClaimResponse.MessageSegment({}, '')
        self.statusseg = B2ClaimResponse.StatusSegment("", {}, '')
        self.claimseg = B2ClaimResponse.ClaimSegment("", {}, '')
        self.pricingseg = B2ClaimResponse.PricingSegment("", {}, '')
        self.requestdata = requestdata
        self.otherinfo = otherinfo
        self.responsetype = ''
        self.responseclaim = {}
        self.responseString = ''

    def setAttributes(self):

        if 'responsetype' in self.otherinfo and self.otherinfo['responsetype'] == 'Duplicate':
            self.responsetype = 2
        elif self.otherinfo['rejectioncode']:
            self.responsetype = 3
        else:
            self.responsetype = 1

        self.headerseg = B2ClaimResponse.Header(
            self.requestdata, self.otherinfo, self.responsetype)
        self.messageseg = B2ClaimResponse.MessageSegment(
            self.otherinfo, self.responsetype)
        self.statusseg = B2ClaimResponse.StatusSegment(
            self.requestdata, self.otherinfo, self.responsetype)
        self.claimseg = B2ClaimResponse.ClaimSegment(
            self.requestdata, self.otherinfo, self.responsetype)
        self.pricingseg = B2ClaimResponse.PricingSegment(
            self.requestdata, self.otherinfo, self.responsetype)

        self.headerseg.setAttributes()
        self.messageseg.setAttributes()
        self.statusseg.setAttributes()
        self.claimseg.setAttributes()
        self.pricingseg.setAttributes()
        self.prepareResponse()

        return self

    def prepareResponse(self):

        self.responseclaim['claim_response'] = {}

        self.responseclaim['claim_response'].update(
            self.headerseg.__dict__)
        self.responseclaim['claim_response'].update(
            self.messageseg.__dict__)
        self.responseclaim['claim_response'].update(
            self.statusseg.__dict__)
        self.responseclaim['claim_response'].update(
            self.claimseg.__dict__)
        self.responseclaim['claim_response'].update(
            self.pricingseg.__dict__)

        eliminate_fields = ['responseString',
                            'requestdata', 'otherinfo', 'responsetype']

        for field in eliminate_fields:
            self.responseclaim['claim_response'].pop(field, None)

        if self.headerseg.responseString:
            self.responseString = self.headerseg.responseString.strip()
        if self.messageseg.responseString:
            self.responseString += "\x1e\x1cAM20\x1c" + \
                self.messageseg.responseString.strip()
        if self.statusseg.responseString:
            self.responseString += "\x1d\x1e\x1cAM21\x1c" + \
                self.statusseg.responseString.strip()
        if self.claimseg.responseString:
            self.responseString += "\x1e\x1cAM22\x1c" + self.claimseg.responseString.strip()
        if self.pricingseg.responseString:
            self.responseString += "\x1e\x1cAM23\x1c" + \
                self.pricingseg.responseString.strip()

        self.responseString = self.responseString.encode(
            'utf-8').decode('utf-8')

    class Header:
        def __init__(self, requestdata, otherinfo, responsetype):
            self.version = ''
            self.transaction_code = ''
            self.transaction_count = ''
            self.response_status = ''
            self.service_provider_id_qualifier = ''
            self.service_provider_id = ''
            self.date_of_service = ''
            self.responseString = ''
            self.requestdata = requestdata
            self.otherinfo = otherinfo
            self.responsetype = responsetype

        def setAttributes(self):
            self.version = 'D0'
            self.transaction_code = self.requestdata.ClaimRequest.header.transaction_code
            self.transaction_count = self.requestdata.ClaimRequest.header.transaction_count
            self.response_status = 'A'
            self.service_provider_id_qualifier = self.requestdata.ClaimRequest.header.service_provider_id_qualifier
            self.service_provider_id = self.requestdata.ClaimRequest.header.service_provider_id
            self.date_of_service = self.requestdata.ClaimRequest.header.date_of_service
            responseformat = {'version': {'type': [1, 2, 3], 'code': 'A2'},
                              'transaction_code': {'type': [1, 2, 3], 'code': 'A3'},
                              'transaction_count': {'type': [1, 2, 3], 'code': 'A9'},
                              'response_status': {'type': [1, 2, 3], 'code': 'F1'},
                              'service_provider_id_qualifier': {'type': [1, 2, 3], 'code': 'B2'},
                              'service_provider_id': {'type': [1, 2, 3], 'code': 'B1'},
                              'date_of_service': {'type': [1, 2, 3], 'code': 'D1'}}
            for key, value in responseformat.items():
                if key == 'service_provider_id':
                    self.responseString = self.responseString + \
                        self.__dict__[key] + '     '
                    continue
                if self.responsetype in value['type'] and self.__dict__[key]:
                    self.responseString = self.responseString + \
                        self.__dict__[key]

    class MessageSegment:
        def __init__(self, otherinfo, responsetype):
            self.message = ''
            self.responseString = ''
            self.otherinfo = otherinfo
            self.responsetype = responsetype

        def setAttributes(self):

            if self.responsetype == 3:
                self.message = self.otherinfo['rejectionreason']

            responseformat = {'message': {'type': [3], 'code': 'F4'}}
            for key, value in responseformat.items():
                if self.responsetype in value['type'] and self.__dict__[key]:
                    self.responseString = self.responseString + '\x1c' + \
                        self.__dict__[key]

    class StatusSegment:
        def __init__(self, requestdata, otherinfo, responsetype):
            self.transaction_response_status = ''
            self.authorization_number = ''
            self.reject_count = ''
            self.reject_code = ''
            self.reject_field_occurrence_indicator = ''
            self.additional_message_information_count = ''
            self.additional_message_information_qualifier = ''
            self.additional_message_information = ''
            self.additional_message_information_continuity = ''
            self.help_desk_phone_number_qualifier = ''
            self.help_desk_phone_number = ''
            self.url = ''
            self.responseString = ''
            self.requestdata = requestdata
            self.otherinfo = otherinfo
            self.responsetype = responsetype

        def setAttributes(self):
            if self.otherinfo['rejectioncode'] and self.responsetype==3:
                self.transaction_response_status = 'R'
                self.reject_count = '1'
            elif self.responsetype == 1:
                self.transaction_response_status = 'A'
            else:
                self.transaction_response_status = 'S'
            self.authorization_number = self.requestdata.auth_id

            if self.responsetype == 3:
                self.reject_code = self.otherinfo['rejectioncode']
            self.reject_field_occurrence_indicator = ''
            self.additional_message_information_continuity = ''
            if 'phone' in self.otherinfo:
                self.help_desk_phone_number_qualifier = '03'
                self.help_desk_phone_number = self.otherinfo['phone']
            self.url = ''
            responseformat = {'transaction_response_status': {'type': [1, 2, 3], 'code': 'AN'},
                              'authorization_number': {'type': [1, 2, 3], 'code': 'F3'},
                              'reject_count': {'type': [3], 'code': 'FA'},
                              'reject_code': {'type': [3], 'code': 'FB'},
                              'reject_field_occurrence_indicator': {'type': [3], 'code': '4F'},
                              'additional_message_information_count': {'type': [1, 2, 3], 'code': 'UF'},
                              'additional_message_information_qualifier': {'type': [1, 2, 3], 'code': 'UH'},
                              'additional_message_information': {'type': [1, 2, 3], 'code': 'FQ'},
                              'additional_message_information_continuity': {'type': [3], 'code': 'UG'},
                              'help_desk_phone_number_qualifier': {'type': [1, 2, 3], 'code': '7F'},
                              'help_desk_phone_number': {'type': [1, 2, 3], 'code': '8F'},
                              'url': {'type': [1, 2, 3], 'code': 'MA'}}
            for key, value in responseformat.items():
                if self.responsetype in value['type'] and self.__dict__[key]:
                    self.responseString = self.responseString + '\x1c' + \
                        value['code'] + self.__dict__[key]

    class ClaimSegment:
        def __init__(self, requestdata, otherinfo, responsetype):
            self.prescription_reference_number_qualifier = ''
            self.prescription_reference_number = ''
            self.responseString = ''
            self.requestdata = requestdata
            self.otherinfo = otherinfo
            self.responsetype = responsetype

        def setAttributes(self):
            if self.requestdata.ClaimRequest.claimsseg.prescription_reference_number_qualifier:
                self.prescription_reference_number_qualifier = self.requestdata.ClaimRequest.claimsseg.prescription_reference_number_qualifier
            else:
                self.prescription_reference_number_qualifier = '1'
            self.prescription_reference_number = self.requestdata.ClaimRequest.claimsseg.prescription_reference_number
            responseformat = {'prescription_reference_number_qualifier': {'type': [1, 2], 'code': 'EM'},
                              'prescription_reference_number': {'type': [1, 2], 'code': 'D2'}}
            for key, value in responseformat.items():
                if self.responsetype in value['type'] and self.__dict__[key]:
                    self.responseString = self.responseString + '\x1c' + \
                        value['code'] + self.__dict__[key]

    class PricingSegment:
        def __init__(self, requestdata, otherinfo, responsetype):
            self.total_amount_paid = ''
            self.incentive_amount_paid = ''
            self.responseString = ''
            self.requestdata = requestdata
            self.otherinfo = otherinfo
            self.responsetype = responsetype

        def sanitize_segment_value(self, val):
            positive_prefixes = {0: '{', 1: 'A',
                                 2: 'B', 3: 'C',
                                 4: 'D', 5: 'E',
                                 6: 'F', 7: 'G',
                                 8: 'H', 9: 'I'}

            negative_prefixes = {0: '}', 1: 'J',
                                 2: 'K', 3: 'L',
                                 4: 'M', 5: 'N',
                                 6: 'O', 7: 'P',
                                 8: 'Q', 9: 'R'}

            val = str(val)
            if "." not in val:
                return val

            val = round(float(val), 2)
            f = "%.2f" % val  # restrict float to 2 decimal points
            prefix_list = negative_prefixes if f[0] == "-" else positive_prefixes
            f = f.replace(".", "")  # remove point from float
            return f[:-1] + prefix_list[int(f[-1])]

        def setAttributes(self):

            if not 'total_amount_paid' in self.otherinfo['prescription']:
                return
            self.total_amount_paid = str(
                round(float(self.otherinfo['prescription']['total_amount_paid']), 2))

            responseformat = {'total_amount_paid': {'type': [1, 2], 'code': 'F9'},
                              'incentive_amount_paid': {'type': [1, 2], 'code': 'FL'}}
            for key, value in responseformat.items():
                if self.responsetype in value['type'] and self.__dict__[key]:
                    self.responseString = self.responseString + '\x1c' + value['code'] + self.sanitize_segment_value(
                        self.__dict__[key])
