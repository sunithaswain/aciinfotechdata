import re

from app.models.b1_claim_request import B1ClaimRequest


# @tracer.wrap()
class B2ClaimRequest(B1ClaimRequest):

    def __init__(self, rawclaim):

        self.rawdata = str(rawclaim)+' '
        self.parsedclaim = {}
        B1ClaimRequest.__init__(self, rawclaim)

    def setAttributes(self):

        #self.log.debug("Setting attributes for the received data")
        self.rawdata = self.rawdata.replace('\x1d', '')
        split_segments = re.split('\x1e\x1c', self.rawdata)

        #self.__log.info('Splitting claim into segments')
        try:
            headerdata = split_segments[0]
            self.header = B1ClaimRequest.Header(headerdata)
        except Exception as _:
            pass
        i = 1
        while i < len(split_segments):
            segment_start = split_segments[i][:4].strip()
            if segment_start == 'AM05':
                self.cobseg = self.COBSegment(
                    split_segments[i])
            elif segment_start == 'AM11':
                self.pricingseg = self.PricingSegment(
                    split_segments[i])
            elif segment_start == 'AM07':
                self.claimsseg = self.ClaimsSegment(
                    split_segments[i])
            elif segment_start == 'AM04':
                self.insuranceseg = self.InsuranceSegment(
                    split_segments[i])
            i += 1

        self.header.setHeaderAttributes()
        self.insuranceseg.setAttributes()
        self.claimsseg.setAttributes()
        self.pricingseg.setAttributes()
        self.cobseg.setAttributes()
        self.getClaimData()

        return self

    def getClaimData(self):

        #self.log.debug('Combining individually parsed segments together')
        self.parsedclaim['claim_request'] = {'header': {}, 'insurance_segment': {
        }, 'claims_segment': {}, 'pricing_segment': {}, 'cob_segment': {}}

        self.parsedclaim['claim_request']['header'].update(
            self.header.__dict__)
        self.parsedclaim['claim_request']['insurance_segment'].update(
            self.insuranceseg.__dict__)
        self.parsedclaim['claim_request']['claims_segment'].update(
            self.claimsseg.__dict__)
        self.parsedclaim['claim_request']['pricing_segment'].update(
            self.pricingseg.__dict__)
        self.parsedclaim['claim_request']['cob_segment'].update(
            self.cobseg.__dict__)

        for segment, _ in self.parsedclaim['claim_request'].items():
            self.parsedclaim['claim_request'][segment].pop(
                'rawdata', None)


# obj = B2ClaimRequest('018571D0B2          1011780823500   20190325XXX0100AAA    AM04 C2100289601 CCTEST CDREGISTRATION AM01 C419700101 C51 C701~ AM07 EM1 D216090 E103 D700597002402 E70000400 D5030 D61 DK07 C801 AM11 DX00 DU00041035 DN07 AM03 EZ01 DB1427092659')
# pd = obj.setAttributes()
# with open('data.json', 'w') as fp:
#     json.dump(pd.parsedclaim, fp)
