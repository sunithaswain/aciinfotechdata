import logging
import re

from parse import search, log as parse_log

parse_log.setLevel(logging.WARNING)

class B1ClaimRequest:

    def __init__(self, rawclaim):
        self.rawdata = str(rawclaim)+' '
        self.parsedclaim = {}
        self.header = B1ClaimRequest.Header("")
        self.insuranceseg = B1ClaimRequest.InsuranceSegment("")
        self.patientseg = B1ClaimRequest.PatientSegment("")
        self.claimsseg = B1ClaimRequest.ClaimsSegment("")
        self.pricingseg = B1ClaimRequest.PricingSegment("")
        self.prescriberseg = B1ClaimRequest.PrescriberSegment("")
        self.cobseg = B1ClaimRequest.COBSegment("")
        self.compoundseg = B1ClaimRequest.CompoundSegment("")
        

    def setAttributes(self):

        logging.getLogger().debug("Setting attributes for the received data")
        self.rawdata = self.rawdata.replace('\x1d', '')
        split_segments = re.split('\x1e\x1c', self.rawdata)
        try:
            headerdata = split_segments[0]
            self.header = B1ClaimRequest.Header(headerdata)
        except Exception as _:
            pass
        i = 1
        while i < len(split_segments):
            segment_start = split_segments[i][:4].strip()
            if segment_start == 'AM10':
                self.compoundseg = B1ClaimRequest.CompoundSegment(
                    split_segments[i])
            elif segment_start == 'AM05':
                self.cobseg = B1ClaimRequest.COBSegment(
                    split_segments[i])
            elif segment_start == 'AM03':
                self.prescriberseg = B1ClaimRequest.PrescriberSegment(
                    split_segments[i])
            elif segment_start == 'AM11':
                self.pricingseg = B1ClaimRequest.PricingSegment(
                    split_segments[i])
            elif segment_start == 'AM07':
                self.claimsseg = B1ClaimRequest.ClaimsSegment(
                    split_segments[i])
            elif segment_start == 'AM01':
                self.patientseg = B1ClaimRequest.PatientSegment(
                    split_segments[i])
            elif segment_start == 'AM04':
                self.insuranceseg = B1ClaimRequest.InsuranceSegment(
                    split_segments[i])
            i += 1

        self.header.setHeaderAttributes()
        self.insuranceseg.setAttributes()
        self.patientseg.setAttributes()
        self.claimsseg.setAttributes()
        self.pricingseg.setAttributes()
        self.prescriberseg.setAttributes()
        self.cobseg.setAttributes()
        self.compoundseg.setAttributes()
        self.getClaimData()
        return self

    def getClaimData(self):

        logging.getLogger().debug('Combining individually parsed segments together')
        self.parsedclaim['claim_request'] = {'header': {}, 'insurance_segment': {
        }, 'patient_segment': {}, 'claims_segment': {}, 'pricing_segment': {}, 'prescriber_segment': {}, 'cob_segment': {}, 'compound_segment': {}}

        self.parsedclaim['claim_request']['header'].update(
            self.header.__dict__)
        self.parsedclaim['claim_request']['insurance_segment'].update(
            self.insuranceseg.__dict__)
        self.parsedclaim['claim_request']['patient_segment'].update(
            self.patientseg.__dict__)
        self.parsedclaim['claim_request']['claims_segment'].update(
            self.claimsseg.__dict__)
        self.parsedclaim['claim_request']['pricing_segment'].update(
            self.pricingseg.__dict__)
        self.parsedclaim['claim_request']['prescriber_segment'].update(
            self.prescriberseg.__dict__)
        self.parsedclaim['claim_request']['cob_segment'].update(
            self.cobseg.__dict__)

        if not self.compoundseg.ingredient_component_count:
            self.parsedclaim['claim_request']['compound_segment'].update(
                self.compoundseg.__dict__)
        else:
            compound_dict = {'ingredient_component_count': '',
                             'compound_ingredients': []}
            compound_dict['ingredient_component_count'] = self.compoundseg.ingredient_component_count
            for ingredient in self.compoundseg.compound_ingredients:
                compound_dict['compound_ingredients'].append(
                    ingredient.__dict__)
            self.parsedclaim['claim_request']['compound_segment'].update(
                compound_dict)

        logging.getLogger().debug('Eliminating PHI from claim')

        phi_fields = [('insurance_segment', 'cardholder_first_name'), ('insurance_segment', 'cardholder_last_name'), ('patient_segment', 'patient_first_name'), ('patient_segment', 'patient_last_name'), (
            'patient_segment', 'patient_street_address'), ('patient_segment', 'patient_city_address'), ('patient_segment', 'patient_state_address'), ('patient_segment', 'patient_zip_code'), ('patient_segment', 'patient_phone_number'), ('patient_segment', 'patient_email_address'), ('patient_segment', 'patient_residence')]

        for segment, field in phi_fields:
            self.parsedclaim['claim_request'][segment].pop(field, None)

        logging.getLogger().debug('Eliminated PHI from claim')
        for segment, _ in self.parsedclaim['claim_request'].items():
            self.parsedclaim['claim_request'][segment].pop('rawdata', None)

    class Header:

        def __init__(self, rawdata):
            self.rawdata = rawdata
            self.bin_number = ""
            self.version = ""
            self.transaction_code = ""
            self.processor_control_number = ""
            self.transaction_count = ""
            self.service_provider_id_qualifier = ""
            self.service_provider_id = ""
            self.date_of_service = ""
            self.software_vendor = ""
            

        def setHeaderAttributes(self):

            logging.getLogger().debug('Setting header attributes the service layer')
            position_attributes = {'bin_number': [0, 6],
                                   'version': [6, 8],
                                   'transaction_code': [8, 10],
                                   'processor_control_number': [10, 20],
                                   'transaction_count': [20, 21],
                                   'service_provider_id_qualifier': [21, 23],
                                   'service_provider_id': [23, 38],
                                   'date_of_service': [38, 46],
                                   'software_vendor': [46, 59]}
            for key, value in position_attributes.items():
                try:
                    changed_value = self.rawdata[value[0]:value[1]].strip(
                    )
                    if '{' in changed_value:
                        changed_value = str(
                            float(self.rawdata[value[0]:value[1]].strip().replace('{', ''))/10.0)
                    setattr(self, key, changed_value)
                except Exception as _:
                    # logging.getLogger().debug('Missing attribute %s in header', key)
                    continue

    class InsuranceSegment:

        def __init__(self, rawdata):
            self.rawdata = rawdata.replace("\x1c", " \x1c") + " \x1c"
            self.cardholder_id = ""
            self.cardholder_first_name = ""
            self.cardholder_last_name = ""
            self.home_plan = ""
            self.plan_id = ""
            self.eligibility_clarification_code = ""
            self.group_id = ""
            self.person_code = ""
            self.patient_relationship_code = ""
            self.medigap_id = ""
            self.medicaid_indicator = ""
            self.provider_accept_assignment_indicator = ""
            self.cms_part_d_defined_qualified_facility = ""
            self.medicaid_id_number = ""
            

        def setAttributes(self):

            logging.getLogger().debug('Setting insurance segment attributes the service layer')
            code_attributes = {'C2': 'cardholder_id', 'CC': 'cardholder_first_name',
                               'CD': 'cardholder_last_name', 'CE': 'home_plan', 'FO': 'plan_id',
                               'C9': 'eligibility_clarification_code', 'C1': 'group_id',
                               'C3': 'person_code', 'C6': 'patient_relationship_code', '2A': 'medigap_id',
                               '2B': 'medicaid_indicator', '2D': 'provider_accept_assignment_indicator',
                               'G2': 'cms_part_d_defined_qualified_facility', 'N5': 'medicaid_id_number'}
            for key, value in code_attributes.items():
                try:
                    changed_value = search(
                        "\x1c"+key+"{} \x1c", self.rawdata)[0].strip()
                    if value == 'cardholder_id' and len(changed_value) > 9:
                        #changed_value = re.sub("[^0-9]", "", changed_value)
                        changed_value = re.sub("FLP", "", changed_value)
                    if '{' in changed_value:
                        changed_value = str(float(
                            search("\x1c"+key+"{} \x1c", self.rawdata)[0].strip().replace('{', ''))/10.0)
                    setattr(self, value, changed_value)
                except Exception as _:
                    # logging.getLogger().debug('Missing attribute %s in insurance segment', value)
                    continue

    class PatientSegment:

        def __init__(self, rawdata):
            self.rawdata = rawdata.replace("\x1c", " \x1c") + " \x1c"
            self.patient_id_qualifier = ""
            self.patient_id = ""
            self.date_of_birth = ""
            self.patient_gender_code = ""
            self.patient_first_name = ""
            self.patient_last_name = ""
            self.patient_street_address = ""
            self.patient_city_address = ""
            self.patient_state_address = ""
            self.patient_zip_code = ""
            self.patient_phone_number = ""
            self.place_of_service = ""
            self.employer_id = ""
            self.pregnancy_indicator = ""
            self.patient_email_address = ""
            self.patient_residence = ""
            

        def setAttributes(self):

            logging.getLogger().debug('Setting patient attributes the service layer')
            code_attributes = {'CX': 'patient_id_qualifier', 'CY': 'patient_id', 'C4': 'date_of_birth', 'C5': 'patient_gender_code', 'CA': 'patient_first_name', 'CB': 'patient_last_name', 'CM': 'patient_street_address', 'CN': 'patient_city_address',
                               'CO': 'patient_state_address', 'CP': 'patient_zip_code', 'CQ': 'patient_phone_number', 'C7': 'place_of_service', 'CZ': 'employer_id', '2C': 'pregnancy_indicator', 'HN': 'patient_email_address', '4X': 'patient_residence'}
            for key, value in code_attributes.items():
                try:
                    changed_value = search(
                        "\x1c"+key+"{}\x1c", self.rawdata)[0].strip()
                    if '{' in changed_value:
                        changed_value = str(float(
                            search("\x1c"+key+"{}\x1c", self.rawdata)[0].strip().replace('{', ''))/10.0)
                    setattr(self, value, changed_value)
                except Exception as _:
                    # logging.getLogger().debug('Missing attribute %s in patient segment', key)
                    continue

    class ClaimsSegment:

        def __init__(self, rawdata):
            self.rawdata = rawdata.replace("\x1c", " \x1c") + " \x1c"
            self.prescription_reference_number_qualifier = ""
            self.prescription_reference_number = ""
            self.product_id_qualifier = ""
            self.product_id = ""
            self.associated_prescription_reference_number = ""
            self.associated_prescription_date = ""
            self.procedure_modifier_code_count = ""
            self.procedure_modifier_code = ""
            self.quantity_dispensed = ""
            self.fill_number = ""
            self.days_supply = ""
            self.compound_code = ""
            self.product_selection_code = ""
            self.date_prescription_written = ""
            self.number_of_refills_authorized = ""
            self.prescription_origin_code = ""
            self.submission_clarification_code_count = ""
            self.submission_clarification_code = ""
            self.other_coverage_code = ""
            self.special_packaging_indicator = ""
            self.originally_prescribed_product_id_qualifier = ""
            self.originally_prescribed_product_code = ""
            self.originally_prescribed_quantity = ""
            self.scheduled_prescription_id_number = ""
            self.unit_of_measure = ""
            self.level_of_service = ""
            self.prior_authorization_type_code = ""
            self.prior_authorization_number_submitted = ""
            self.intermediary_authorization_type_id = ""
            self.intermediary_authorization_id = ""
            self.dispensing_status = ""
            self.quantity_intended_dispensed = ""
            self.days_supply_intended_dispensed = ""
            self.delay_reason_code = ""
            self.patient_assignment_indicator = ""
            self.route_of_administration = ""
            self.compound_type = ""
            self.pharmacy_service_type = ""
            self.daw_code = ''

        def setAttributes(self):

            logging.getLogger().debug('Setting claims attributes the service layer')
            code_attributes = {'EM': 'prescription_reference_number_qualifier', 'D2': 'prescription_reference_number',
                               'E1': 'product_id_qualifier', 'D7': 'product_id',
                               'EN': 'associated_prescription_reference_number', 'EP': 'associated_prescription_date',
                               'SE': 'procedure_modifier_code_count', 'ER': 'procedure_modifier_code',
                               'E7': 'quantity_dispensed', 'D3': 'fill_number', 'D5': 'days_supply',
                               'D6': 'compound_code', 'D8': 'product_selection_code', 'DE': 'date_prescription_written',
                               'DF': 'number_of_refills_authorized', 'DJ': 'prescription_origin_code',
                               'NX': 'submission_clarification_code_count', 'DK': 'submission_clarification_code',
                               'C8': 'other_coverage_code',
                               'DT': 'special_packaging_indicator', 'EJ': 'originally_prescribed_product_id_qualifier',
                               'EA': 'originally_prescribed_product_code', 'EB': 'originally_prescribed_quantity',
                               'EK': 'scheduled_prescription_id_number', '28': 'unit_of_measure',
                               'DI': 'level_of_service', 'EU': 'prior_authorization_type_code',
                               'EV': 'prior_authorization_number_submitted', 'EW': 'intermediary_authorization_type_id',
                               'EX': 'intermediary_authorization_id', 'HD': 'dispensing_status',
                               'HF': 'quantity_intended_dispensed', 'HG': 'days_supply_intended_dispensed',
                               'NV': 'delay_reason_code', 'MT': 'patient_assignment_indicator',
                               'E2': 'route_of_administration', 'G1': 'compound_type', 'U7': 'pharmacy_service_type'}
            for key, value in code_attributes.items():
                try:
                    changed_value = search(
                        "\x1c"+key+"{}\x1c", self.rawdata)[0].strip()
                    if key == 'E7' and '{' not in changed_value:
                        changed_value = str(int(changed_value)/1000)
                    if '{' in changed_value:
                        changed_value = str(float(
                            search("\x1c"+key+"{}\x1c", self.rawdata)[0].strip().replace('{', ''))/10.0)
                    setattr(self, value, changed_value)
                except Exception as _:
                    # logging.getLogger().debug('Missing attribute %s in claims segment', key)
                    continue

    class PricingSegment:

        def __init__(self, rawdata):
            self.rawdata = rawdata.replace("\x1c", " \x1c") + " \x1c"
            self.ingredient_cost_submitted = ""
            self.dispensing_fee_submitted = ""
            self.patient_paid_amount_submitted = ""
            self.incentive_amount_submitted = ""
            self.other_amount_claimed_submitted_count = ""
            self.other_amount_claimed_submitted_qualifier = ""
            self.other_amount_claimed_submitted = ""
            self.flat_sales_tax_amount_submitted = ""
            self.percentage_sales_tax_amount_submitted = ""
            self.percentage_sales_tax_rate_submitted = ""
            self.percentage_sales_tax_basis_submitted = ""
            self.usual_and_customary_charge = ""
            self.gross_amount_due = ""
            self.basis_of_cost_determination = ""
            

        def sanitize_segment_value(self, val):
            positive_prefixes = {'{': 0, 'A': 1,
                                 'B': 2, 'C': 3,
                                 'D': 4, 'E': 5,
                                 'F': 6, 'G': 7,
                                 'H': 8, 'I': 9}

            negative_prefixes = {'J': 1, 'K': 2,
                                 'L': 3, 'M': 4,
                                 'N': 5, 'O': 6,
                                 'P': 7, 'Q': 8,
                                 'R': 9, '}': 0}

            char_prefix = val[-1]
            from itertools import chain
            if char_prefix in chain(list(positive_prefixes.keys()), list(negative_prefixes.keys())):
                multiplier, prefix_list = (.01, positive_prefixes) if char_prefix in positive_prefixes else \
                    (-.01, negative_prefixes)
                return int(val[:-1] + str(prefix_list[char_prefix])) * multiplier
            return val

        def setAttributes(self):

            # self.__log.info('Setting pricing attributes the service layer')
            code_attributes = {'D9': 'ingredient_cost_submitted', 'DC': 'dispensing_fee_submitted',
                               'DX': 'patient_paid_amount_submitted', 'E3': 'incentive_amount_submitted',
                               'H7': 'other_amount_claimed_submitted_count',
                               'H8': 'other_amount_claimed_submitted_qualifier', 'H9': 'other_amount_claimed_submitted',
                               'HA': 'flat_sales_tax_amount_submitted', 'GE': 'percentage_sales_tax_amount_submitted',
                               'HE': 'percentage_sales_tax_rate_submitted',
                               'JE': 'percentage_sales_tax_basis_submitted', 'DQ': 'usual_and_customary_charge',
                               'DU': 'gross_amount_due', 'DN': 'basis_of_cost_determination'}
            for key, value in code_attributes.items():
                try:
                    changed_value = self.sanitize_segment_value(
                        search("\x1c" + key + "{}\x1c", self.rawdata)[0].strip())
                    # if '{' in changed_value:
                    #     changed_value = str(float(
                    #         search("\x1c"+key+"{}\x1c", self.rawdata)[0].strip().replace('{', ''))/10.0)

                    setattr(self, value, changed_value)
                except Exception as _:
                    # self.__log.info('Missing attribute %s in pricing segment', key)
                    continue

    class PrescriberSegment:

        def __init__(self, rawdata):
            self.rawdata = rawdata.replace("\x1c", " \x1c") + " \x1c"
            self.prescriber_id_qualifier = ""
            self.prescriber_id = ""
            self.prescriber_last_name = ""
            self.prescriber_phone_number = ""
            self.primary_care_provider_id_qualifier = ""
            self.primary_care_provider_id = ""
            self.primary_care_provider_last_name = ""
            self.prescriber_first_name = ""
            self.prescriber_street_address = ""
            self.prescriber_city_address = ""
            self.prescriber_state_address = ""
            self.prescriber_zip_code = ""
            

        def setAttributes(self):

            logging.getLogger().debug('Setting prescriber attributes the service layer')
            code_attributes = {'EZ': 'prescriber_id_qualifier',
                               'DB': 'prescriber_id',
                               'DR': 'prescriber_last_name',
                               'PM': 'prescriber_phone_number',
                               '2E': 'primary_care_provider_id_qualifier',
                               'DL': 'primary_care_provider_id',
                               '4E': 'primary_care_provider_last_name',
                               '2J': 'prescriber_first_name',
                               '2K': 'prescriber_street_address',
                               '2M': 'prescriber_city_address',
                               '2N': 'prescriber_state_address',
                               '2P': 'prescriber_zip_code'}
            for key, value in code_attributes.items():
                try:
                    changed_value = search(
                        "\x1c"+key+"{}\x1c", self.rawdata)[0].strip()
                    if '{' in changed_value:
                        changed_value = str(float(
                            search("\x1c"+key+"{}\x1c", self.rawdata)[0].strip().replace('{', ''))/10.0)

                    setattr(self, value, changed_value)
                except Exception as _:
                    # logging.getLogger().debug('Missing attribute %s in prescriber segment', key)
                    continue

    class COBSegment:

        def __init__(self, rawdata):
            self.rawdata = rawdata.replace("\x1c", " \x1c") + " \x1c"
            self.payment_count = ""
            self.other_payer_coverage_type = ""
            self.other_payer_id_qualifier = ""
            self.other_payer_id = ""
            self.other_payer_date = ""
            self.internal_control_number = ""
            self.other_payer_amount_paid_count = ""
            self.other_payer_amount_paid_qualifier = ""
            self.other_payer_amount_paid = ""
            self.other_payer_reject_count = ""
            self.other_payer_reject_code = ""
            self.other_payer_patient_responsibility_amount_count = ""
            self.other_payer_patient_responsibility_amount_qualifier = ""
            self.other_payer_patient_responsibility_amount = ""
            self.benefit_stage_count = ""
            self.benefit_stage_qualifier = ""
            self.benefit_stage_amount = ""
            

        def setAttributes(self):

            logging.getLogger().debug('Setting COB segment attributes the service layer')
            code_attributes = {'4C': 'payment_count', '5C': 'other_payer_coverage_type', '6C': 'other_payer_id_qualifier', '7C': 'other_payer_id', 'E8': 'other_payer_date', 'A7': 'internal_control_number', 'HB': 'other_payer_amount_paid_count', 'HC': 'other_payer_amount_paid_qualifier', 'DV': 'other_payer_amount_paid',
                               '5E': 'other_payer_reject_count', '6E': 'other_payer_reject_code', 'NR': 'other_payer_patient_responsibility_amount_count', 'NP': 'other_payer_patient_responsibility_amount_qualifier', 'NQ': 'other_payer_patient_responsibility_amount', 'MU': 'benefit_stage_count', 'MV': 'benefit_stage_qualifier', 'MW': 'benefit_stage_amount'}
            for key, value in code_attributes.items():
                try:
                    changed_value = search(
                        "\x1c"+key+"{}\x1c", self.rawdata)[0].strip()
                    if '{' in changed_value:
                        changed_value = str(float(
                            search("\x1c"+key+"{}\x1c", self.rawdata)[0].strip().replace('{', ''))/10.0)

                    setattr(self, value, changed_value)
                except Exception as _:
                    # logging.getLogger().debug('Missing attribute %s in COB segment', key)
                    continue

    class CompoundSegment:

        def __init__(self, rawdata):
            self.rawdata = rawdata.replace("\x1c", " \x1c") + " \x1c"
            self.ingredient_component_count = ""
            self.dispensing_unit_form_indicator = ""
            self.dosgae_form_desc_code = ""
            self.compound_ingredients = []
            

        def setAttributes(self):

            if not self.rawdata.strip():
                return

            logging.getLogger().debug('Setting Compound segment attributes the service layer')

            setattr(self, 'ingredient_component_count', search(
                "\x1cEC" + "{}\x1c", self.rawdata)[0].strip())
            try:
                setattr(self, 'dispensing_unit_form_indicator', search("\x1cEG" + "{}\x1c", self.rawdata)[0].strip())
            except:
                try:
                    setattr(self, 'dosgae_form_desc_code', search("\x1cEF" + "{}\x1c", self.rawdata)[0].strip())
                except:
                    pass

            code_attributes = {'RE': 'product_id_qualifier', 'TE': 'product_id', 'ED': 'ingredient_quantity', 'EE': 'ingredient_drug_cost',
                               'UE': 'basis_of_cost_determination', '2G': 'ingredient_modifier_code_count', '2H': 'ingredient_modifier_code'}

            splitdata = self.rawdata.split('\x1c')
            ingredient = None

            for i in range(len(splitdata)):
                if 'EC' in splitdata[i] or 'EG' in splitdata[i] or 'EF' in splitdata[i] or not splitdata[i] or i == 0:
                    continue
                if 'RE' in splitdata[i]:
                    if ingredient:
                        self.compound_ingredients.append(ingredient)
                    ingredient = self.CompoundIngredient()
                    #ingredient.__dict__[code_attributes[splitdata[i][0:2]]] = splitdata[i][2:].strip().zfill(11)
                if '2H' not in splitdata[i]:
                    changed_value = splitdata[i][2:].strip()
                    if '{' in changed_value:
                        changed_value = str(float(splitdata[i][2:].strip(
                        ).replace('{', ''))/10.0)
                    ingredient.__dict__[
                        code_attributes[splitdata[i][0:2]]] = changed_value
                else:

                    ingredient.__dict__[code_attributes[splitdata[i][0:2]]].append(
                        splitdata[i][2:].strip())
            if ingredient:
                self.compound_ingredients.append(ingredient)

        class CompoundIngredient:

            def __init__(self):
                self.product_id_qualifier = ""
                self.product_id = ""
                self.ingredient_quantity = ""
                self.ingredient_drug_cost = ""
                self.basis_of_cost_determination = ""
                self.ingredient_modifier_code_count = ""
                self.ingredient_modifier_code = []
                


'''
obj = B1ClaimRequest(
    "610740D0B1FLIPT     1019990000272     20190613XXX0100AAA\x1e\x1cAM04\x1cC2100289601\x1cCCTEST \x1cCDREGISTRATION\x1cC1FLIPTALL\x1cC301\x1cC61\x1e\x1cAM01\x1cC419700101\x1cC51\x1d\x1e\x1cAM07\x1cEM1\x1cD2\x1cE103\x1cD752959069902\x1cE730 \x1cD399\x1cD5030\x1cD61\x1cDK07\x1cC801\x1e\x1cAM11\x1cDX60{\x1cDU235{\x1cDQ135{\x1cDN07\x1e\x1cAM03\x1cEZ01\x1cDB1427092660")
pd = obj.setAttributes()
f = open('data1.json', 'w')
f.write(json.dumps(pd.parsedclaim))
f.close()
'''
# import pdb;pdb.set_trace()
# import pprint
# pprint.pprint(pd.parsedclaim['claim_request']['header'])
# print(pd)
