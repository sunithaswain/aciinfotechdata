from dependency_injector import providers, containers


class Configs(containers.DeclarativeContainer):

    from app.utility.config import Configuration
    config = providers.Singleton(Configuration)


class DataProviders(containers.DeclarativeContainer):

    from app.providers.claim_provider import ClaimProvider

    claimdataprovider = providers.Factory(ClaimProvider, Configs.config)

    from app.providers.db_queries import QueryExecutor
    dataqueriesprovider = providers.Factory(QueryExecutor, Configs.config)

    from app.providers.autoerx_provider import AutoerxProvider
    autoerxprovider = providers.Factory(AutoerxProvider, Configs.config)

    from app.providers.claim_portal_provider import ClaimPortalProvider
    claimportaldataprovider = providers.Factory(
        ClaimPortalProvider, Configs.config)


class Models(containers.DeclarativeContainer):

    from app.models.claim import Claim

    claimmodel = providers.Factory(Claim)

    #from app.models.b1_claim_request import B1ClaimRequest

    #b1request = providers.Factory(B1ClaimRequest, reqdata='')

    from app.models.b1_claim_response import B1ClaimResponse

    b1response = providers.Factory(B1ClaimResponse)


class MandatoryModules(containers.DeclarativeContainer):

    from app.modules.claim_validation.validation import ClaimValidation

    claimvalidation = providers.Factory(
        ClaimValidation, DataProviders.claimdataprovider)


class OptionalModules(containers.DeclarativeContainer):

    from app.modules.restrictions.over_the_counter_drug import OverTheCounterDrug
    from app.modules.restrictions.pa_tree_logic import PaCheck
    from app.modules.member_eligibility.eligibility import UserEligibilityCheck
    from app.modules.plan_eligibility.benefit_plan_eligibility import PlanEligibilityCheck
    from app.modules.prescriber_validation.validate_prescriber import PrescriberValidator
    from app.modules.intent_check.intent_check import IntentValidator
    from app.modules.over_ride_check.over_ride_check import OverRideCheck
    from app.modules.pa_override.pa_override_check import PAOverRideCheck
    from app.modules.max_coverage_per_script.coverage_per_script import MaxCoveragePerScript
    from app.modules.refill_check.check_refill import RefillValidator
    from app.modules.auto_eRx import auto_erx, drug_info, new_prescription, pharmacy_info, \
        price_calculation, route_prescription, sign_in, user_info
    from app.modules.auto_eRx_lite import auto_erx_lite, get_copay, get_deductible_opc, get_prices, get_unit_price
    from app.models.user import User
    from app.modules.restrictions.drug_covered import DrugCovered
    userelig = providers.Factory(UserEligibilityCheck, Configs.config,
                                 card_holder_id='', last_name='',
                                 date_of_birth='', date_of_service='', gender='', first_name='',  insurance_person_code='')
    planelig = providers.Factory(
        PlanEligibilityCheck, DataProviders.dataqueriesprovider,
        prescriber_id='')
    prescvalid = providers.Factory(
        PrescriberValidator, DataProviders.dataqueriesprovider, prescriber_id='')
    intentvalid = providers.Factory(
        IntentValidator, DataProviders.dataqueriesprovider, service_provider_id='', gpi='', cardholder_id='', drug_name='', brand_generic='')
    overridecheck = providers.Factory(
        OverRideCheck, DataProviders.dataqueriesprovider, date_of_service='', product_id='',
        presc_ref_num='', fill_num='', service_provider_id='')
    pa_tree_logic = providers.Factory(
        PaCheck, DataProviders.dataqueriesprovider, Configs.config)
    paoverridecheck = providers.Factory(
        PAOverRideCheck, DataProviders.claimdataprovider, date_of_service='', gpi='', drug_name='', brand_generic='', flipt_person_id='', plan_name='', domain='')
    refillvalid = providers.Factory(
        RefillValidator, DataProviders.dataqueriesprovider, gpi='', cardholder_id='', drug_name='', brand_generic='', intents=[])
    user = providers.Factory(User, Configs.config, username='', password='', role='',
                             usertype='', first_name='', last_name='')

    druginfo = providers.Factory(
        drug_info.DrugInfo, DataProviders.autoerxprovider)
    generic_druginfo = providers.Factory(
        drug_info.DrugInfo, DataProviders.autoerxprovider)
    newpresc = providers.Factory(
        new_prescription.NewPrescription, Configs.config, DataProviders.autoerxprovider)
    pharmainfo = providers.Factory(
        pharmacy_info.PharmacyInfo, DataProviders.autoerxprovider)
    pricecalc = providers.Factory(
        price_calculation.PriceCalculation, Configs.config, DataProviders.autoerxprovider)
    routepresc = providers.Factory(
        route_prescription.RoutePrescription, Configs.config, DataProviders.autoerxprovider)
    signin = providers.Factory(
        sign_in.SignIn, Configs.config)
    userinfo = providers.Factory(
        user_info.UserInfo, Configs.config)

    autoerx = providers.Factory(auto_erx.Autoerx, Configs.config, DataProviders.autoerxprovider, userinfo, pharmainfo, druginfo, signin,
                                newpresc, pricecalc, routepresc, claimobj=None, user_info=None, domain_flag=None, override=False)

    copayinfo = providers.Factory(get_copay.CopayCalculation)
    deductibleinfo = providers.Factory(
        get_deductible_opc.DeductibleOPCCalculation)
    unitpriceinfo = providers.Factory(get_unit_price.UnitPrice)
    pricesinfo = providers.Factory(get_prices.PriceCalculation)

    autoerxlite = providers.Factory(auto_erx_lite.AutoerxLite, claimprocobj=None, druginfoobj=druginfo,
                                    generic_druginfoobj=generic_druginfo,
                                    pharmainfoobj=pharmainfo, user_info=None, userinfoobj=userinfo,
                                    dataprovider=DataProviders.autoerxprovider, domain_flags=None, copayobj=copayinfo,
                                    deductibleinfoobj=deductibleinfo, pricesobj=pricesinfo,
                                    unitpriceobj=unitpriceinfo, override=None, pacheckobj=pa_tree_logic)

    userelig = providers.Factory(UserEligibilityCheck, Configs.config,
                                 card_holder_id='', last_name='',
                                 date_of_birth='', date_of_service='')

    max_coverage_info = providers.Factory(MaxCoveragePerScript, DataProviders.dataqueriesprovider, domain_flags='',
                                          other_info='')

    over_the_counter = providers.Factory(
        OverTheCounterDrug, config=Configs.config)
    drug_covered = providers.Factory(
        DrugCovered, query_ex=DataProviders.dataqueriesprovider, config=Configs.config)

    over_the_counter = providers.Factory(
        OverTheCounterDrug, config=Configs.config)
    drug_covered = providers.Factory(
        DrugCovered, query_ex=DataProviders.dataqueriesprovider, config=Configs.config)


class Service(containers.DeclarativeContainer):
    from app.service.claim_processor_service import ClaimProcessor
    from app.service.claim_response_service import ClaimResponseProcessor
    from app.service.claim_portal_service import ClaimPortalProcessor

    cpservice = providers.Factory(ClaimProcessor, config=Configs.config, claimobj=Models.claimmodel,
                                  claimdataprovobj=DataProviders.claimdataprovider,
                                  validationobj=MandatoryModules.claimvalidation)
    claim_response_processor = providers.Factory(ClaimResponseProcessor, config=Configs.config,
                                                 query_ex=DataProviders.dataqueriesprovider)
    portal_service = providers.Factory(ClaimPortalProcessor, config=Configs.config, claimobj=Models.claimmodel,
                                       claimportaldataprovobj=DataProviders.claimportaldataprovider)


class Utilities(containers.DeclarativeContainer):

    from app.utility.error_email_notifier import EmailNotificationHandler
    emailnotif = providers.Factory(EmailNotificationHandler)

    from app.utility.sendgridemail import SendgridEmail
    sendemail = providers.Factory(SendgridEmail)
