import logging
import sys
import threading
import traceback
from ast import literal_eval
from datetime import datetime, timedelta
import json
from app import resources
from app.resources import basicauthrequired
from app.utility.bootstrap import Configs
from app.utility.bootstrap import Service
from app.utility import process_worker
import ddtrace
from ddtrace import patch_all
from ddtrace import tracer
from ddtrace.constants import ANALYTICS_SAMPLE_RATE_KEY
from flask import jsonify
from flask import request, Flask, Response
from flask_cors import CORS
from flask_jwt_extended import JWTManager, jwt_required
from flask_restful import Api
from app.api.restriction.views import api as restriction


patch_all(logging=True)


app = Flask(__name__)

log = logging.getLogger(__name__)

FORMAT = ('%(asctime)s %(levelname)s [%(name)s] [%(filename)s:%(lineno)d] '
          '[dd.trace_id=%(dd.trace_id)s dd.span_id=%(dd.span_id)s] '
          '- %(message)s')

#FORMAT = ('- %(message)s')

logging.basicConfig(format=FORMAT, level=logging.DEBUG)


api = Api(app)
cp = Service.cpservice()
cr = Service.claim_response_processor()
cportal = Service.portal_service()
CORS(app)
cf = Configs.config()

app.config['SECRET_KEY'] = cf.secret_key
app.config['JWT_SECRET_KEY'] = cf.jwt_secret_key
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=24)
jwt = JWTManager(app)

api.add_resource(resources.UserRegistration, '/api/v1/user/registration')
api.add_resource(resources.UserLogin, '/api/v1/user/login')
api.add_resource(resources.UserLogout, '/api/v1/user/logout')
api.add_resource(resources.TVUserRegistration, '/api/v1/tvuser/registration')
api.add_resource(resources.TVUserDetail, '/api/v1/tvuser/detail')
api.add_resource(resources.TVUserSchemaUpdate, '/api/v1/tvuser/schema')
app.register_blueprint(restriction, url_prefix="/api/v1/restriction")


@app.route('/api/v1/Auth', methods=['GET'])
@basicauthrequired(utype='eRx')
def try_auth(userattribute):
    # print(userattribute)
    return "Welcome to FLipt, You are Authenticated"


@app.route('/api/v1/test', methods=['GET'])
@basicauthrequired()
def try_get():
    log.debug("This will be traced by data-dog")
    return "Welcome to Flipt, API is up and Running"


@tracer.wrap()
@app.route('/api/v1/RequestClaim', methods=['POST'])
@basicauthrequired()
def claim_request(userattribute):
    global cp
    starttime = datetime.now()
    # print('claim req', datetime.now())
    # claim_request._log.info('Claim Requested')
    try:
        span = tracer.current_span()
        start_time = datetime.fromtimestamp(span.start)
        span.set_tag(ANALYTICS_SAMPLE_RATE_KEY, True)
        log.debug("Received the request and processing the claim ")
        responsestring, responseformat, info = cp.adjudicateClaim(
            request.data, userattribute['usertype'])

        resp = Response(responsestring.encode(), status=200,
                        mimetype='application/' + responseformat)
        claim_delta = str((start_time - datetime.now()).microseconds/1000)
        response_data = info[2]
        transaction_id = literal_eval(responsestring).get('transactionid')
        log_metric_data = {
            "transaction_id": transaction_id,
            "timestamp": datetime.now(),
            "sequence_number": response_data.claimobj.sequenceNumber,
            "auth_id": response_data.claimobj.auth_id,
            "request_type": response_data.requesttype,
            "claim_status": response_data.claimobj.ClaimResponse.statusseg.transaction_response_status,
            "claim_delta": claim_delta,
            "response_string": responsestring
        }
        log.debug(
            f'Claim request was finished in {",".join(["=".join([key, str(value)]) for key, value in log_metric_data.items()])}')
        current_ctx = None
        if ddtrace.tracer.context_provider._has_active_context():
            current_ctx = ddtrace.tracer.context_provider.active()
            # If we have a context then make sure we clone it
            # DEV: We don't know if the future will finish executing before the parent span finishes
            # so we clone to ensure we properly collect/report the future's spans
            current_ctx = current_ctx.clone()

        worker_thread_pool = process_worker.ThreadPool(2)
        worker_thread_pool.add_task(
            cp.postProcessUpdate, info[0], info[1], info[2], info[3], current_ctx)
        # th2 = threading.Thread(target=cp.postProcessUpdate,
        #                        args=()).start()
        print('received response', resp)
        # self._log.info('Claim Response to be returned')
        print('claim req processed', datetime.now())
        print('time taken', (datetime.now()-starttime).seconds)
        return resp
    except Exception as e:
        type, value, etraceback = sys.exc_info()
        error = ""
        x = traceback.format_exception(type, value, etraceback)
        for i in x:
            error = error + i
        print(error, 'index.py')
        log.debug(error)
        # claim_request._log.error(error, exc_info=True)

        print('claim req processed', datetime.now())


@tracer.wrap()
@app.route('/api/v1/ResponseClaim', methods=['POST'])
@basicauthrequired()
def response_claim(claim_data):
    global cr
    log.debug("Reveived the response req and processing the claim ")
    response, respform = cr.process_response_claim(
        request.data, claim_data['usertype'])
    resp = Response(response, status=200,
                    mimetype='application/' + respform)
    return resp


@app.route('/api/v1/claim/search', methods=['POST'])
@jwt_required
def getclaim():
    global cportal
    log.debug("Received the claim filter and processing to search the claim")

    responsestring = cportal.getClaim(request.data)
    return jsonify(responsestring), 200


@app.route('/api/v1/claim/detail', methods=['GET'])
@jwt_required
def getclaimdetails():
    global cportal
    log.debug(
        "Received the claim detaiil request and processing to search the claim details")

    responsestring = cportal.getClaimDetails(request.args)
    return jsonify(responsestring), 200


@app.route('/api/v1/claim/override', methods=['GET'])
@jwt_required
def getclaimoverride():
    global cportal
    log.debug(
        "Received the claim override request and processing to return the claim override")

    responsestring = cportal.getClaimOverride(request.args)
    return jsonify(responsestring), 200


@app.route('/api/v1/claim/override', methods=['PUT'])
@jwt_required
def updateclaimoverride():
    global cportal
    log.debug(
        "Received the claim override request and processing to update the claim override")

    responsestring = cportal.updateClaimOverride(request.data)
    return jsonify(responsestring), 200


@app.route('/api/v1/claim/member', methods=['GET'])
@jwt_required
def getclaimmember():
    global cportal
    log.debug(
        "Received the claim member request and processing to return the claim member")

    responsestring = cportal.getClaimMember(request.args)
    return jsonify(responsestring), 200


@app.route('/api/v1/claim/transaction', methods=['GET'])
@jwt_required
def getclaimtransaction():
    global cportal
    log.debug(
        "Received the claim transaction request and processing to return the claim transaction")

    responsestring = cportal.getClaimTransaction(request.args)
    return jsonify(responsestring), 200


@app.route('/api/v1/eligibility/search', methods=['GET'])
@jwt_required
def geteligibility():
    global cportal
    log.debug(
        "Received the eligibility member request for search and processing to return the eligibility member")

    responsestring = cportal.getEligibilityReport(request.args)
    return jsonify(responsestring), 200


@app.route('/api/v1/eligibility/member', methods=['GET'])
@jwt_required
def geteligibilitymember():
    global cportal
    log.debug(
        "Received the eligibility member request and processing to return the eligibility member")

    responsestring = cportal.getEligibilityMember(request.args)
    return jsonify(responsestring), 200


@app.route('/api/v1/eligibility/member', methods=['PUT'])
@jwt_required
def updateeligibilitymember():
    global cportal
    log.debug(
        "Received the eligibility member request and processing to update the eligibility member")

    responsestring = cportal.updateEligibilityMember(request.data)
    return jsonify(responsestring), 200


# if __name__ == '__main__':
#     # logging.basicConfig(handlers=[Utilities.emailnotif()], level=int(
#     #     cf.LEVEL), format='%(threadName)s:%(levelname)s:%(asctime)s:%(name)s:%(funcName)s:%(message)s', datefmt='%d-%m-%y %H:%M:%S')
#     app.run(port=5010, host='0.0.0.0', use_reloader=False,
#             threaded=False, debug=False)
