import logging


class IntentValidator(object):
    def __init__(self, query_ex, service_provider_id, gpi, cardholder_id, drug_name, brand_generic):
        self.service_provider_id = service_provider_id
        self.gpi = gpi
        self.brand_generic = brand_generic
        self.drug_name = drug_name
        self.flipt_member_id = cardholder_id
        self.query_ex = query_ex
        self.log = logging.getLogger()

    def is_intent_present(self):  # intent == prescription
        """
        :return: Return true if intent exists, else false
        """
        self.log.debug("Inside intent check module")

        """
        Captured the drug details from the ndc_drugs and passing them to the
        prescription table to check if intent is existing or not
        """
        res = self.query_ex.execute_query('npi,application,rx_status,pa_flag,quantity,routed_date,filled_date,prescription_id,available_fill_date', 'prescription',
                                          filters={'member_id': self.flipt_member_id,
                                                   # varied with depending upon the dependent code
                                                   'brand_generic': self.brand_generic,
                                                   'gpi': self.gpi,
                                                   'drug_name': self.drug_name},
                                          orderby='order by routed_date desc',
                                          get_single_result=False
                                          )

        res = [r for r in res]

        prescription_result = [
            result for result in res if result['rx_status'] in ['Routed', 'PA'] and result['npi'] == self.service_provider_id]
        if prescription_result:
            prescription_result = prescription_result[0]

        if prescription_result and prescription_result.get('application', '').lower().strip() not in ['web app', 'mobile app'] and prescription_result.get('pa_flag', '') in ['N', '']:
            return self.prepare_response({}, res)

        return self.prepare_response(prescription_result, res)

    def prepare_response(self, result, all_intents):
        if result and (result['rx_status'] == 'Routed' or (result['rx_status'] == 'PA' and result['pa_flag'] == 'Y')):
            res = {'result': 'True',
                   'status': result['rx_status'],
                   'quantity': result['quantity'],
                   'prescription_id': result['prescription_id'],
                   'intents': all_intents
                   }
            self.log.debug("Intent is existing")
            return res
        else:
            self.log.debug("Intent is not existing")
            res = {'result': 'False',
                   'intents': all_intents}
            return res


#  Do not remove data to test the module
'''
if __name__ == "__main__":
    uec_obj = IntentValidator(
        '1001679', '00002120001', '100012201')
    print(uec_obj.is_intent_present())
'''
