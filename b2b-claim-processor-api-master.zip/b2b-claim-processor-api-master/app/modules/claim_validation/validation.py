from cerberus import Validator
from datetime import datetime
import logging


class ClaimValidation:

    def __init__(self, dataprov):
        self.claimdata = {}
        self.dataprov = dataprov
        self.schema = {}
        self.log = logging.getLogger()

    def validateData(self, claimObj, ndc_drug, preValidation=False):
        self.log.debug('pre going to validate')

        self.claimdata = claimObj.parsedclaim['claim_request']

        rejectioncode, rejectionreason = '', ''

        if not preValidation and self.claimdata['header']['transaction_code'] == 'B1':
            rejectioncode, rejectionreason = self.b1ClaimValidations(ndc_drug)
        if self.claimdata['header']['transaction_code'] == 'B2':
            if preValidation:
                rejectioncode, rejectionreason = self.b2ClaimPreValidations()
            else:
                rejectioncode, rejectionreason = self.b2ClaimValidations()
        return rejectioncode, rejectionreason

    def b1ClaimValidations(self, ndc_drug):

        def verifyvalue(field, value, error):
            '''
            custom validator to verify value within the DB
            '''
            if field == 'bin_number':
                if str(value).strip() == '' or not self.dataprov.validateBinNumber(value):
                    error(field, 'not present in DB')
            elif field == 'service_provider_id':
                if str(value).strip() == '' or not self.dataprov.validateServiceProviderClaim(value):
                    error(field, 'not present in DB')
            elif field == 'product_id':
                if str(value).strip() == '' or not ndc_drug['ndc']:
                    error(field, 'not present in DB')
            elif field in ['date_of_service', 'date_of_birth']:
                try:
                    formatdate = datetime.strptime(value, '%Y%m%d').strftime(
                        '%Y-%m-%d 00:00:00')
                except Exception as e:
                    error(field, 'invalid format')

        errorcodes = {"header": {"bin_number": ['1', 'Missing or Invalid BIN'],
                                 "version": ['2', 'Missing or Invalid Version Number'],
                                 "transaction_code": ['3', 'Missing or Invalid Transaction Code'],
                                 "transaction_count": ['A9', 'Missing or Invalid Transaction Count'],
                                 "service_provider_id_qualifier": ['B2', 'Missing or Invalid Service Provider ID Qualifier'],
                                 "service_provider_id": ['5', 'Missing or Invalid Pharmacy Number'],
                                 "date_of_service": ['15', 'Missing or Invalid Date of Service']},
                      "insurance_segment": {"cardholder_id": ['7', 'Missing or Invalid Cardholder ID Number']},
                      "patient_segment": {"date_of_birth": ['9', 'Missing or Invalid Date of Birth'],
                                          "patient_gender_code": ['10', 'Missing or Invalid Patient Gender Code']},
                      "claims_segment": {"fill_number": ['211', 'Missing/Invalid Refill Number'],
                                         "prescription_reference_number_qualifier": ['EM', 'Missing or Invalid Prescription/Service Reference Number Qualifier'],
                                         "prescription_reference_number": ['EN', 'Missing or Invalid Associated Prescription/Service Reference Number'],
                                         "product_id_qualifier": ['EJ', 'Missing or Invalid Originally Prescribed Product/Service ID Qualifier'],
                                         "product_id": ['21', 'Missing or Invalid Product/Service ID'],
                                         "days_supply": ['19', 'Missing or Invalid Days Supply'],
                                         "compound_code": ['20', 'Missing or Invalid Compound Code']},
                      "pricing_segment": {"patient_paid_amount_submitted": ['DX', 'Missing or Invalid Patient Paid Amount Submitted'],
                                          "gross_amount_due": ['DU', 'Missing or Invalid Gross Amount Due']}}

        schema = {"header":
                  {"type": "dict",
                   "schema": {
                       "bin_number": {"validator": verifyvalue},
                       "version": {"allowed": ["D0"]},
                       "transaction_code": {"allowed": ["B1"]},
                       "transaction_count": {"allowed": ["1", "01"]},
                       "service_provider_id_qualifier": {"allowed": ["01"]},
                       "service_provider_id": {"minlength": 10, "validator": verifyvalue},
                       "date_of_service": {"minlength": 8, "maxlength": 8, "validator": verifyvalue}}},
                  "insurance_segment":
                  {"type": "dict",
                   "schema": {
                       "cardholder_id": {"type": "string", "maxlength": 20, "minlength": 2}}},
                  "patient_segment":
                  {"type": "dict",
                   "schema": {
                       "date_of_birth": {"minlength": 8, "maxlength": 8, "validator": verifyvalue},
                       "patient_gender_code": {"allowed": ["0", "1", "2"]}}},
                  "claims_segment":
                  {"type": "dict",
                   "schema": {
                       "fill_number": {"allowed": [x for x in range(0, 100)]},
                       "prescription_reference_number_qualifier": {"allowed": ["1"]},
                       "prescription_reference_number": {"minlength": 1},
                       "product_id_qualifier": {"allowed": ["03", "00"]},
                       "product_id": {"validator": verifyvalue},
                       "days_supply": {"forbidden": [""], "regex": "^ *\d[\d ]*$"},
                       "compound_code": {"allowed": ["1", "2"]}}}}

        if not self.claimdata['insurance_segment']['cardholder_id']:
            self.claimdata['insurance_segment']['cardholder_id'] = self.claimdata['patient_segment']['patient_id']
        try:
            self.claimdata['claims_segment']['fill_number'] = int(
                self.claimdata['claims_segment']['fill_number'])
        except Exception as _:
            pass

        v = Validator(schema, allow_unknown=True)
        result = v.validate(self.claimdata)

        self.claimdata['claims_segment']['fill_number'] = str(
            self.claimdata['claims_segment']['fill_number'])

        if not result:
            print("Printing the errors in data validations", v.errors)
            errors = v.errors
            for segment, fields in errorcodes.items():
                if segment in errors:
                    field_errors = errors[segment]
                    rejections = {}
                    for field in field_errors:
                        rejections.update(field)
                        for key, value in errorcodes[segment].items():
                            if key in rejections:
                                return value[0], value[1]
        return '', ''

    def b2ClaimValidations(self):

        def verifyvalue(field, value, error):
            '''
            custom validator to verify value within the DB
            '''
            if field == 'bin_number':
                if str(value).strip() == '' or not self.dataprov.validateBinNumber(value):
                    error(field, 'not present in DB')
            elif field == 'date_of_service':
                try:
                    formatdate = datetime.strptime(value, '%Y%m%d').strftime(
                        '%Y-%m-%d 00:00:00')
                except Exception as _:
                    error(field, 'invalid format')

        errorcodes = {"header": {"bin_number": ['1', 'Missing or Invalid BIN'],
                                 "version": ['2', 'Missing or Invalid Version Number'],
                                 "transaction_code": ['3', 'Missing or Invalid Transaction Code'],
                                 "transaction_count": ['A9', 'Missing or Invalid Transaction Count'],
                                 "date_of_service": ['15', 'Missing or Invalid Date of Service']}}

        schema = {"header":
                  {"type": "dict",
                   "schema": {
                       "bin_number": {"validator": verifyvalue},
                       "version": {"allowed": ["D0"]},
                       "transaction_code": {"allowed": ["B2"]},
                       "transaction_count": {"allowed": ["1"]},
                       "date_of_service": {"minlength": 8, "maxlength": 8, "validator": verifyvalue}}}}

        v = Validator(schema, allow_unknown=True)
        result = v.validate(self.claimdata)

        if not result:
            errors = v.errors
            for segment, fields in errorcodes.items():
                if segment in errors:
                    field_errors = errors[segment]
                    rejections = {}
                    for field in field_errors:
                        rejections.update(field)
                        for key, value in errorcodes[segment].items():
                            if key in rejections:
                                return value[0], value[1]

        return '', ''

    def b2ClaimPreValidations(self):

        def verifyvalue(field, value, error):
            '''
            custom validator to verify value within the DB
            '''
            if field == 'service_provider_id':
                if str(value).strip() == '' or not self.dataprov.validateServiceProviderClaim(value):
                    error(field, 'not present in DB')
            elif field == 'product_id':
                if str(value).strip() == '' or not self.dataprov.validateNDC(value):
                    error(field, 'not present in DB')

        errorcodes = {"header": {"service_provider_id_qualifier": ['B2', 'Missing or Invalid Service Provider ID Qualifier'],
                                 "service_provider_id": ['5', 'Missing or Invalid Pharmacy Number']},
                      "claims_segment": {"prescription_reference_number_qualifier": ['EM', 'Missing or Invalid Prescription/Service Reference Number Qualifier'],
                                         "prescription_reference_number": ['EN', 'Missing or Invalid Associated Prescription/Service Reference Number'],
                                         "product_id_qualifier": ['EJ', 'Missing or Invalid Originally Prescribed Product/Service ID Qualifier'],
                                         "product_id": ['21', 'Missing or Invalid Product/Service ID']}}

        schema = {"header":
                  {"type": "dict",
                   "schema": {
                       "service_provider_id_qualifier": {"allowed": ["01"]},
                       "service_provider_id": {"minlength": 10, "validator": verifyvalue}}},
                  "claims_segment":
                  {"type": "dict",
                   "schema": {
                       "prescription_reference_number_qualifier": {"allowed": ["1"]},
                       "prescription_reference_number": {"minlength": 1},
                       "product_id_qualifier": {"allowed": ["03", "00"]},
                       "product_id": {"validator": verifyvalue}}}}

        v = Validator(schema, allow_unknown=True)

        result = v.validate(self.claimdata)

        if not result:
            errors = v.errors
            for segment, fields in errorcodes.items():
                if segment in errors:
                    field_errors = errors[segment]
                    rejections = {}
                    for field in field_errors:
                        rejections.update(field)
                        for key, value in errorcodes[segment].items():
                            if key in rejections:
                                return value[0], value[1]

        return '', ''
