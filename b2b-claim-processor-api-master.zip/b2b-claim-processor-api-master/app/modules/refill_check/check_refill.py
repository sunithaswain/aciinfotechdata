import logging
from datetime import datetime


class RefillValidator(object):
    def __init__(self, query_ex, gpi, cardholder_id, drug_name, brand_generic, intents):
        self.gpi = gpi
        self.brand_generic = brand_generic
        self.drug_name = drug_name
        self.flipt_member_id = cardholder_id
        self.query_ex = query_ex
        self.intents = intents
        self.log = logging.getLogger(__name__)

    def is_refill_valid(self):
        """
        :return: Return true if refill is valid, else false
        """
        self.log.debug("Inside refill check module")

        result = [res for res in self.intents if res['rx_status'] == 'Filled']
        if len(result) > 0:
            result = sorted(result, key=lambda i: i['filled_date'])
            result = result[-1]
        available_fill_date = ''

        if result and result.get('available_fill_date', ''):
            try:
                dateofservice = datetime.strftime(
                    datetime.now(), "%Y-%m-%dT23:59:59.0000")
                if result['available_fill_date'] > dateofservice:
                    rejectioncode = '79'
                    rejectionreason = 'Refill Too Soon'
                    available_fill_date = datetime.strftime(datetime.strptime(
                        result['available_fill_date'], "%Y-%m-%dT%H:%M:%S.%f"), "%Y/%m/%d")
                    message = 'Next Available Fill Date = ' + available_fill_date
                    return self.prepare_response(status=False, rejectioncode=rejectioncode, rejectionreason=rejectionreason, message=message)
            except Exception as e:
                pass

        return self.prepare_response(status=True, result=result)

    def prepare_response(self, status, rejectioncode="", rejectionreason="", message="", result=""):

        if status:
            result = result or {}
            return {"status": status,
                    "days_of_supply": result.get('daysofsupply')}
        else:
            return {
                "status": status,
                "rejectioncode": rejectioncode,
                "rejectionreason": rejectionreason,
                "message": message
            }
