import logging
from datetime import datetime


class OverRideCheck(object):
    def __init__(self, query_ex, date_of_service, product_id, presc_ref_num, fill_num, service_provider_id):
        self.date_of_service = date_of_service
        self.query_ex = query_ex
        self.presc_num = presc_ref_num
        self.fill_num = fill_num
        self.product_id = product_id
        self.service_provider_id = service_provider_id
        self.log = logging.getLogger()

    def get_over_ride_info(self):
        self.log.debug("Inside override check")
        over_ride = self.query_ex.execute_query('override_from, override_thru, claim_request.date_of_service,'
                                                'claim_request.gpi, over_ride, overridenumber, copay_override, '
                                                'override_amount, override_percentage',
                                                doc_type='claim',
                                                filters={'claim_request.date_of_service': self.date_of_service,
                                                         'claim_request.gpi': self.product_id,
                                                         'over_ride': 'Y',
                                                         'claim_request.prescription_reference_number': self.presc_num,
                                                         'claim_request.fill_number': self.fill_num,
                                                         'claim_request.service_provider_id': self.service_provider_id},
                                                orderby='order by override_thru desc')

        if over_ride is None:
            return self._prepare_response()

        start_date = datetime.strftime(datetime.strptime(
            over_ride['override_from'], "%Y-%m-%d"), "%Y%m%d")
        end_date = datetime.strftime(datetime.strptime(
            over_ride['override_thru'], "%Y-%m-%d"), "%Y%m%d")

        if not (start_date <= self.date_of_service <= end_date):
            return self._prepare_response()

        return self._prepare_response(over_ride["over_ride"], over_ride["overridenumber"], over_ride["copay_override"],
                                      over_ride["override_amount"], over_ride["override_percentage"])

    def _prepare_response(self, over_ride="", override_number="", copay_override="", override_amount="",
                          override_percentage=""):
        status = True if over_ride else False
        res = {'result': status,
               'override_number': override_number,
               'copay_override': copay_override,
               'override_amount': override_amount,
               'override_percentage': override_percentage,
               'over_ride_result': over_ride}
        return res


'''
if __name__ == "__main__":
    uec_obj = OverRideCheck(
        "9d327fb6-31d1-49fd-8590-28810d03e32d", "100289601", "20190325", "99999909999")
    uec_obj.get_over_ride_info()
'''
