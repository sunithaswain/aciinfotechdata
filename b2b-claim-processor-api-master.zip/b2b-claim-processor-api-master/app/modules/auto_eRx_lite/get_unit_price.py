import pandas as pd
import logging


class UnitPrice:

    def __init__(self):

        self.rejection_reason = ''
        self.unit_price = 0
        self.price_type = ''
        self.claim_processor = ''
        self.pharmacy_discount = 0
        self.pharmacy_dispensing_fee = 0
        self.payer_brand_generic = ''
        self.log = logging.getLogger(__name__)

    def getCompoundPrice(self, erxliteobj):

        self.log.debug('Getting compound drug unit price in auto erx lite')

        cppharmainfo = pd.DataFrame(data=erxliteobj.pharmaobj.cp_pharmacy_info)
        for i, r in cppharmainfo.iterrows():
            if 'compound_discount_pct' in r and float(r['compound_discount_pct']) > self.pharmacy_discount:
                self.pharmacy_discount = float(
                    r['compound_discount_pct'])/100.0
                self.claim_processor = r['claim_processor']
                self.pharmacy_dispensing_fee = float(r['pharmnonmacpricefee'])
        if self.pharmacy_discount == 0:
            self.pharmacy_discount = float(
                erxliteobj.domain_flags['compound_discount_pct']) / 100
            self.pharmacy_dispensing_fee = 1.75
            self.claim_processor = 'FLIPT'

        self.price_type = ''
        compoundpricelist = [
            erxliteobj.claimobj.ClaimRequest.pricingseg.usual_and_customary_charge, erxliteobj.claimobj.ClaimRequest.pricingseg.gross_amount_due, erxliteobj.claimobj.ClaimRequest.pricingseg.ingredient_cost_submitted]
        price_type_map = {0: 'U&C', 1: 'GROSS DUE AMT', 2: 'ING COST'}
        self.unit_price = -1
        ite = -1
        for price in compoundpricelist:
            ite = ite+1
            try:
                price = float(price)
                if self.unit_price != -1:
                    self.unit_price = min(price, self.unit_price)
                else:
                    self.unit_price = price
                if price == self.unit_price:
                    self.price_type = price_type_map[ite]
            except Exception as e:
                continue

        if not self.unit_price > 0:
            self.rejection_reason = 'Unit Price Not found'

        return

    def getAllUnitPrices(self, erxliteobj, unit_price):
        self.log.debug('Getting all unit prices in auto erx lite')

        
        unitprices = unit_price
        if not unitprices:
            self.rejection_reason = 'Unit Price Not Found'
            return pd.DataFrame(), None

        unitprices = pd.DataFrame(unitprices)

        if erxliteobj.domain_flags.get('rebate_at_pos_adjustment', 'N') == 'N':
            unitprices['unitprice'] = unitprices['unit_price_before_rebate']

        price_source = erxliteobj.domain_flags['price_source']
        if erxliteobj.is_otc:
            price_source = erxliteobj.domain_flags['otc_price_source']

        unitprices = unitprices[unitprices['claim_processor'].isin(
            price_source)]

        if unitprices is None or unitprices.empty:
            self.rejection_reason = 'Unit Price Not Found'
            return pd.DataFrame(), None

        # get final unit price
        cppharmainfo = pd.DataFrame(data=erxliteobj.pharmaobj.cp_pharmacy_info)

        cppharmainfo = cppharmainfo[cppharmainfo['claim_processor'].isin(
            price_source)]

        if erxliteobj.drugobj.gppc in list(unitprices['gppc']):
            unitprices_filtered = unitprices[unitprices['gppc']
                                             == erxliteobj.drugobj.gppc]
            if set(cppharmainfo['claim_processor']).intersection(list(unitprices_filtered['claim_processor'])):
                unitprices = unitprices_filtered

        if cppharmainfo.empty:
            self.rejection_reason = 'Unit Price Not Found'
            return pd.DataFrame(), None

        return unitprices, cppharmainfo

    def getUnitPrice(self, erxliteobj, unit_price):
        if erxliteobj.compound_drug:
            self.getCompoundPrice(erxliteobj)
            return self
        unitprices, cppharmainfo = self.getAllUnitPrices(
            erxliteobj, unit_price)
        if unitprices.empty:
            return self

        if 'payer_brand_generic' not in list(unitprices):
            unitprices['payer_brand_generic'] = erxliteobj.drugobj.brand_generic

        self.log.debug('Finding best unit price in auto erx lite')

        tempprice = max(list(unitprices['unitprice'])) * 200000

        for i, r in cppharmainfo.iterrows():
            if r['claim_processor'] not in list(unitprices['claim_processor']):
                continue
            tempindex = []
            tempindex.extend(unitprices[(unitprices['maclistid'] == r['maclistid']) & (
                unitprices['claim_processor'] == r['claim_processor'])].index)
            if not tempindex:
                tempindex.extend(unitprices[(unitprices['maclistid'] == 'ALLCLAIMMAC') & (
                    unitprices['claim_processor'] == r['claim_processor'])].index)
            if not tempindex:
                tempindex.extend(unitprices[((unitprices['pricetype'] == 'AWP') & (
                    unitprices['claim_processor'] == r['claim_processor']))].index)
            currprice = max(list(unitprices['unitprice'])) * 20
            currindex = -1
            for index in tempindex:
                if unitprices.loc[index, 'unitprice'] < currprice:
                    currprice = unitprices.loc[index, 'unitprice']
                    currindex = index
            nonretail = ''
            if erxliteobj.pharmaobj.pharmacy_type != 'RETAIL':
                nonretail = 'mo'

            if currindex != -1:
                if unitprices.loc[currindex, 'pricetype'] == 'MAC':
                    pharmacydiscount = (
                        float(r['pharmmacpriceamt'+nonretail]) / 100.0)
                    pharmacydispensingfee = float(
                        r['pharmmacpricefee' + nonretail])

                elif unitprices.loc[currindex, 'payer_brand_generic'] != 'G':
                    pharmacydiscount = (
                        float(r['pharmbrandpriceamt'+nonretail]) / 100.0)
                    pharmacydispensingfee = float(
                        r['pharmbrandpricefee'+nonretail])

                else:
                    pharmacydiscount = (
                        float(r['pharmnonmacpriceamt'+nonretail]) / 100.0)
                    pharmacydispensingfee = float(
                        r['pharmnonmacpricefee' + nonretail])

                try:
                    if tempprice > (pharmacydiscount * currprice * float(erxliteobj.claimobj.ClaimRequest.claimsseg.quantity_dispensed) + pharmacydispensingfee):
                        tempprice = pharmacydiscount * currprice * \
                            float(
                                erxliteobj.claimobj.ClaimRequest.claimsseg.quantity_dispensed) + pharmacydispensingfee
                        self.price_type = unitprices.loc[currindex,
                                                         'pricetype']
                        self.unit_price = unitprices.loc[currindex,
                                                         'unitprice']
                        self.unit_price_before_rebate = unitprices.loc[currindex,
                                                                       'unit_price_before_rebate']
                        self.payer_brand_generic = unitprices.loc[currindex,
                                                                       'payer_brand_generic']
                        self.claim_processor = r['claim_processor']
                        self.pharmacy_discount = pharmacydiscount
                        self.pharmacy_dispensing_fee = pharmacydispensingfee
                        self.log.debug(f"Pricing of each claims engine: price_type={self.price_type},"
                                       f"unit_price={self.unit_price}, claim_processor={self.claim_processor},"
                                       f"pharmacy_discount={self.pharmacy_discount},"
                                       f"pharmacy_dispensing_fee={self.pharmacy_dispensing_fee}")
                except Exception as exp:
                    self.log.debug(exp)

        if not self.unit_price:
            self.rejection_reason = 'Unit Price Not Found'

        return self
