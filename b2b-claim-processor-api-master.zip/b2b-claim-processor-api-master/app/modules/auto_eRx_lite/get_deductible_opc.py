from datetime import datetime
import logging


class DeductibleOPCCalculation:
    def __init__(self):
        self.deductible_remaining = 0
        self.opc_remaining = 0
        self.log = logging.getLogger(__name__)

    def getDeductibleRemaining(self, erxliteobj, individual_deductible_accrued,
                               individual_opc_accrued, family_deductible_accrued, family_opc_accrued):

        self.log.debug('Calculating deductible remaining in auto erx lite')

        if erxliteobj.rxplan_info['deductible_exempted'] == 'N' and erxliteobj.rxplan_info['individual_deductible_embedded'] == 'N':
            if erxliteobj.user_info['coverage_tier_name'] != 'Individual':
                self.deductible_remaining = max(0, int(
                    erxliteobj.rxplan_info['annual_deductible_family']) - family_deductible_accrued)
            else:
                self.deductible_remaining = max(0, int(
                    erxliteobj.rxplan_info['annual_deductible_individual']) - individual_deductible_accrued)
        elif erxliteobj.rxplan_info['deductible_exempted'] == 'N' and erxliteobj.rxplan_info['individual_deductible_embedded'] == 'Y':
            if erxliteobj.user_info['coverage_tier_name'] != 'Individual':
                if int(erxliteobj.rxplan_info['annual_deductible_family']) - family_deductible_accrued <= 0:
                    self.deductible_remaining = 0
                else:
                    self.deductible_remaining = max(0, int(
                        erxliteobj.rxplan_info['annual_deductible_individual']) - individual_deductible_accrued)
            else:
                self.deductible_remaining = max(0, int(
                    erxliteobj.rxplan_info['annual_deductible_individual']) - individual_deductible_accrued)

    def getOPCRemaining(self, erxliteobj, individual_deductible_accrued, individual_opc_accrued,
                        family_deductible_accrued, family_opc_accrued):

        self.log.debug('Calculating OPC remaining in auto erx lite')

        if erxliteobj.rxplan_info['individual_out_of_pocket_embedded'] == 'Y':
            if erxliteobj.user_info['coverage_tier_name'] != 'Individual':
                self.opc_remaining = max(0, int(
                    erxliteobj.rxplan_info['annual_out_of_pocket_individual']) - individual_opc_accrued)
                if family_opc_accrued != 0 and self.opc_remaining != 0:
                    self.opc_remaining = max(
                        0, int(erxliteobj.rxplan_info['annual_out_of_pocket_family']) - family_opc_accrued)
            else:
                self.opc_remaining = max(0, int(
                    erxliteobj.rxplan_info['annual_out_of_pocket_individual']) - individual_opc_accrued)

    def getDeductibleOPCRemaining(self, erxliteobj):

        self.log.debug('Getting deductible-OPC info in auto erx lite')
        individual_deductible_accrued, individual_opc_accrued = erxliteobj.dataprovider._get_deductibleinfo(
            {'flipt_person_id': erxliteobj.user_info['flipt_person_id'], 'plan_year': str(datetime.now().year)}, True)
        family_deductible_accrued, family_opc_accrued = 0, 0
        if erxliteobj.user_info['coverage_tier_name'] != 'Individual':
            family_deductible_accrued, family_opc_accrued = erxliteobj.dataprovider._get_deductibleinfo(
                {'flipt_person_id': erxliteobj.user_info['flipt_person_id'], 'plan_year': str(datetime.now().year)}, False)

        self.getDeductibleRemaining(
            erxliteobj, individual_deductible_accrued, individual_opc_accrued, family_deductible_accrued, family_opc_accrued)

        self.getOPCRemaining(
            erxliteobj, individual_deductible_accrued, individual_opc_accrued, family_deductible_accrued, family_opc_accrued)
        self.deductible_met = False

        self.outofpocket_met = False

        if self.deductible_remaining > 0:
            self.deductible_met = False
        else:
            self.deductible_met = True
        if self.opc_remaining > 0:
            self.outofpocket_met = False
        else:
            self.outofpocket_met = True
        return self
