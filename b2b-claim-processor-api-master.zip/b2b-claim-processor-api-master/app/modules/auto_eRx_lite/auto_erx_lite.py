import logging
from datetime import datetime

from app.modules.auto_eRx_lite import get_copay, get_prices, get_unit_price


class AutoerxLite:

    def __init__(self, claimprocobj=None, druginfoobj=None, generic_druginfoobj=None, pharmainfoobj=None,
                 userinfoobj=None,
                 dataprovider=None, user_info=None, domain_flags=None, copayobj=None, deductibleinfoobj=None,
                 pricesobj=None, unitpriceobj=None, override=False, pacheckobj=None):
        self.claimobj = None
        self.drugobj = druginfoobj
        self.generic_drugobj = generic_druginfoobj
        self.pharmaobj = pharmainfoobj
        self.userobj = userinfoobj
        self.dataprovider = dataprovider
        self.user_info = None
        self.rxplan_info = None
        self.domain_flags = domain_flags
        if user_info and user_info.get('user', ''):
            self.user_info = user_info['user']
        if claimprocobj:
            self.claimprocobj = claimprocobj
            self.claimobj = claimprocobj.claimobj
        self.copayobj = copayobj
        self.generic_copayobj = get_copay.CopayCalculation()
        self.deductibleinfoobj = deductibleinfoobj
        self.pricesobj = pricesobj
        self.generic_pricesobj = get_prices.PriceCalculation()
        self.unitpriceobj = unitpriceobj
        self.generic_unitpriceobj = get_unit_price.UnitPrice()
        self.rejection_reason = ''
        self.bin = ''
        self.pcn = ''
        self.compound_drug = False
        self.is_otc = False
        self.override = override
        self.pacheckobj = pacheckobj
        self.pa_flag = 'N'
        self.rra_penalty_type = ''
        self.brand_generic_switch = False
        self.manufacturer_pricing = False
        self.apply_non_manufacturer_penalty = False
        self.original_employe_opc = ''
        self.log = logging.getLogger(__name__)

    def preCalculationInfo(self):

        self.log.debug("Getting user info in auto erx lite")
        if not self.user_info:
            self.rejection_reason = 'User Not Found'
            return
        self.userobj = self.userobj.setAttributes(
            self.user_info, self.claimobj.ClaimRequest.insuranceseg.cardholder_id)

        self.log.debug("Getting user plan info in auto erx lite")
        self.rxplan_info = self.claimprocobj.otherinfo['rxplan_info']

        # get pharmacy info
        self.log.debug("Getting pharmacy info in auto erx lite")
        self.pharmaobj = self.pharmaobj.setAttributes(
            self.claimobj.ClaimRequest.header.service_provider_id)
        if not self.pharmaobj.pharmacy:
            self.rejection_reason = 'Pharmacy not Found'

        # get drug info
        self.log.debug("Getting drug info in auto erx lite")

        self.drugobj, _, _ = self.drugobj.setAttributes(
            self.claimobj.ClaimRequest.claimsseg.product_id, self.claimobj.ClaimRequest.claimsseg.quantity_dispensed, False)

        if self.drugobj.status == 'inactive':
            self.rejection_reason = 'Unit Price Not Found'
            return
        if not self.drugobj.gpi:
            self.rejection_reason = 'Unit Price Not Found'
            return

        # check if otc drug
        if self.drugobj.otc_indicator != 'R':
            self.drugobj.set_otc_indicator({
                'domain_name': self.rxplan_info['domain_name'],
                'plan_name': self.rxplan_info['plan_name'],
                'plan_start_date': self.rxplan_info['plan_start_date'],
                'plan_end_date': self.rxplan_info['plan_end_date']})
            if not self.drugobj.is_otc_inclusion:
                self.rejection_reason = 'Unit Price Not Found'

        # check if compound drug
        if self.drugobj.gpi == '00000000000000':
            self.compound_drug = True

    def recalculatePrices(self, info, drug_cost):

        self.log.debug(
            "Recalculating prices --> quantity difference/unc-gda cost compare")
        self.brand_generic_switch = False
        if 'coinsurance_amounts' in info:
            self.copayobj.copay_type = info['copay_type']
            self.copayobj.copay_amt = info['copay_amt']
            self.copayobj.drug_deductible_exempt = info['drug_deductible_exempt']
            self.copayobj.coinsurance_amounts = info['coinsurance_amounts']
            self.pa_flag = info['pa_flag']
        else:
            self.userobj.domain_name = info['domain']
            self.userobj.benefit_plan_name = info['plan_name']
            self.drugobj.gpi = info['gpi']
            self.drugobj.drug_name = info['drug_name']
            self.drugobj.brand_generic = info['brand_generic']
            self.pharmaobj.pharmacy_type = 'RETAIL'
            if 'mo_shipto_location' in info:
                self.pharmaobj.pharmacy_type = 'MAILORDER'
            self.copayobj = self.copayobj.getCopay(
                self, self.claimprocobj.otherinfo['formulary_info'][0])
        self.copayobj.formularyinfo = self.claimprocobj.otherinfo['formulary_info'][0]
        self.unitpriceobj.unit_price = float(info['unit_price'])
        self.unitpriceobj.pharmacy_discount = float(info['pharmacy_discount'])
        self.unitpriceobj.pharmacy_dispensing_fee = float(
            info['pharmacy_dispensing_fee'])
        self.deductibleinfoobj.deductible_remaining = float(
            info['deductible_remaining'])
        if 'out_of_pocket_remaining' in info:
            self.deductibleinfoobj.opc_remaining = float(
                info['out_of_pocket_remaining'])
        else:
            self.deductibleinfoobj.opc_remaining = float(info['opc_remaining'])
        self.deductibleinfoobj.outofpocket_met = True
        self.deductibleinfoobj.deductible_met = True
        if self.deductibleinfoobj.opc_remaining > 0:
            self.deductibleinfoobj.outofpocket_met = False
        if self.deductibleinfoobj.deductible_remaining > 0:
            self.deductibleinfoobj.deductible_met = False
        self.rxplan_info = self.claimprocobj.otherinfo['rxplan_info']
        self.pricesobj = self.pricesobj.getPrices(
            self, drug_cost, self.unitpriceobj)
        self.original_employe_opc = self.pricesobj.employee_opc
        self.rejection_reason = self.pricesobj.rejection_reason

        return self.prepareResponse()

    def get_pharmacy_data(self):
        self.log.debug("Getting pharmacy info in auto erx lite")
        self.pharmaobj = self.pharmaobj.setAttributes(
            self.claimobj.ClaimRequest.header.service_provider_id)
        self.claimprocobj.otherinfo["pharma_obj"] = self.pharmaobj
        if not self.pharmaobj.pharmacy:
            self.rejection_reason = 'Pharmacy not Found'
        return self

    def get_deductible_info(self):
        self.log.debug("Getting deductible information")
        self.deductibleinfoobj = self.deductibleinfoobj.getDeductibleOPCRemaining(
            self)

        return self.deductibleinfoobj

    def get_drug_data(self, ndc_info):

        attribute_dict = {'gpi': ndc_info['gpi']}

        if not self.brand_generic_switch:
            attribute_dict['drug_name'] = ndc_info['drug_name']
            attribute_dict['brand_generic'] = ndc_info['brand_generic']
        return self.dataprovider.get_drug_info(attribute_dict)

    def apply_penalty(self, panalty_percent):
        # now calculate penalty cost
        self.log.debug("Adding penalty to the patient")
        if self.brand_generic_switch and self.generic_pricesobj.rejection_reason == '':
            patient_pay_amount = (self.pricesobj.drug_cost - self.generic_pricesobj.drug_cost) + \
                                 (panalty_percent/100 *
                                  self.generic_pricesobj.drug_cost)
            # patient_penalty_amount = float(panalty_percent)/100 * float(self.generic_pricesobj.drug_cost)
            self.log.debug(f"patient pay amount: {patient_pay_amount}")
            # patient_pay_amount = self.pricesobj.employee_opc + patient_penalty_amount
        else:
            patient_pay_amount = float(
                panalty_percent) / 100 * float(self.pricesobj.drug_cost)
        self.log.debug(
            f"patient pay amount after adding the penalty: {patient_pay_amount}")
        drug_cost = self.pricesobj.drug_cost
        patient_pay_amount = drug_cost if patient_pay_amount > drug_cost else patient_pay_amount

        employer_cost = float(drug_cost) - patient_pay_amount
        self.log.debug(
            f"Employer cost after adding penalty to employee: {employer_cost}")
        return patient_pay_amount, employer_cost

    def get_presc_count(self, ndc_info):
        return self.dataprovider.get_presc_cnt(ndc_info['gpi'], ndc_info['drug_name'],
                                               self.rxplan_info['plan_start_date'],
                                               self.rxplan_info['plan_end_date'],
                                               self.claimprocobj.claimobj.ClaimRequest.insuranceseg.cardholder_id)

    def coins_amts(self, formulary_info):
        if self.copayobj.copay_type == 'co_ins_percentage':
            self.min_copay = formulary_info[0]['co_ins_min_amount'] if self.pharmaobj.pharmacy_type == 'RETAIL' else formulary_info[0]['mo_co_ins_min_amount']
            if float(self.min_copay) > float(self.pricesobj.employee_opc):
                self.pricesobj.employee_opc = self.min_copay
                self.pricesobj.employer_cost = float(
                    self.pricesobj.drug_cost) - float(self.pricesobj.employee_opc)

    def getERxLite(self):
        if not self.user_info:
            self.rejection_reason = 'User Not Found'
            return
        self.userobj = self.userobj.setAttributes(
            self.user_info, self.claimobj.ClaimRequest.insuranceseg.cardholder_id)

        self.rxplan_info = self.claimprocobj.otherinfo.get('rxplan_info', None)
        if not self.rxplan_info:
            self.rxplan_info = self.dataprovider._get_rxplaninfo({'date_of_service': datetime.strftime(
                datetime.strptime(self.claimobj.ClaimRequest.header.date_of_service, '%Y%m%d'), '%Y-%m-%d')+'T'+datetime.now().time().isoformat(),
                'plan_name': self.userobj.benefit_plan_name, 'domain_name': self.userobj.domain_name})

        ndc_info = self.claimprocobj.otherinfo["ndc_info"]
        drug_manufacturer = self.dataprovider.get_manufacturer(ndc_info)
        quantity_dispensed = self.claimobj.ClaimRequest.claimsseg.quantity_dispensed
        self.get_pharmacy_data()

        self.deductible_info_obj = self.get_deductible_info()
        self.log.debug((self.deductibleinfoobj.__dict__))
        if self.deductibleinfoobj.deductible_met:
            self.log.debug("Met deductible check the manufacturer and domain")
            if drug_manufacturer is not None and drug_manufacturer['domain'] == self.rxplan_info["domain_name"]:
                '''
                Condition 1 
                when drug manufacturer is equal to domain do not switch the brand to generic
                and met his deductible so eligible for manufacture pricing
                manufacture pricing = employer will pay full drug cost and employee will pay 0
                '''
                self.manufacturer_pricing = True
                self.log.debug("Calculating on manufacturer pricing")
            elif drug_manufacturer != self.rxplan_info["domain_name"]:
                self.log.debug("Manufacturer and domain are different")
                if self.rxplan_info.get('brand_covered_upto_generic_copay_flag') == "Y":
                    self.log.debug(
                        "Manufacturer covers brand drug up to generic prices")
                    self.apply_non_manufacturer_penalty = True
                    if ndc_info['brand_generic'] in ["T", "B"]:
                        '''
                        Conditionin 3 
                        when manufacturer not equal to domain and domain wants their employee to buy generics when 
                        brnad drug available
                        '''
                        self.brand_generic_switch = True

        self.log.debug(f"brand_generic_switch={self.brand_generic_switch}")
        self.log.debug(f"manufacturer_pricing={self.manufacturer_pricing}")

        ''' 
        domain != manufacturer
        what if the drug is generic 
        in this case 
        brand generic switch is false
        generic is very cheap 
        penalty is on type of pharmacies no penalty in case of 
        
        '''
        formulary_info = self.claimprocobj.otherinfo['formulary_info']
        alternative_formulary = None
        if ndc_info["brand_generic"] == "G":
            alternative_formulary = None
        elif len(formulary_info) > 1 and self.brand_generic_switch:
            alternative_formulary = self.claimprocobj.otherinfo['alternative_formulary']
        elif (not len(formulary_info) > 1) and self.brand_generic_switch:
            self.brand_generic_switch = False
        self.drug_info = self.get_drug_data(ndc_info)
        generic_drug_info = ''
        if self.brand_generic_switch and len(self.drug_info) > 1:
            generic_drug_info_index = next((index for (index, d) in enumerate(self.drug_info) if d["brand_generic"] == "G"),
                                           None)
            brand_drug_info_index = next((index for (index, d) in enumerate(self.drug_info) if d["brand_generic"] in
                                          ["T", "B"]), None)
            generic_drug_info = self.drug_info[generic_drug_info_index]
            self.drug_info = self.drug_info[brand_drug_info_index]
        else:
            self.brand_generic_switch = False
        if isinstance(self.drug_info, list) and not self.brand_generic_switch:
            self.drug_info = self.drug_info[0]

        self.drugobj = self.drugobj.setAttributes(
            ndc_info, quantity_dispensed, False, self.drug_info)

        if self.brand_generic_switch and not self.rejection_reason:
            self.generic_drugobj = self.generic_drugobj.setAttributes(ndc_info, quantity_dispensed, False,
                                                                      generic_drug_info)
        if self.drugobj.status == 'inactive' or not self.drugobj.gpi:
            self.rejection_reason = 'Unit Price Not Found'
        # check if otc drug
        if self.drugobj.otc_indicator != 'R':
            if self.claimprocobj.otherinfo['formulary_info'][0].get('otc_inclusion', 'N') == 'Y':
                self.is_otc_inclusion = True
            if not self.drugobj.is_otc_inclusion:
                self.rejection_reason = 'Unit Price Not Found'

        # check if compound drug
        if self.drugobj.gpi == '00000000000000':
            self.compound_drug = True

        if not self.rejection_reason:
            self.copayobj = self.copayobj.getCopay(self, formulary_info[0])
            self.rejection_reason = self.copayobj.rejection_reason

            if self.brand_generic_switch and not self.rejection_reason and alternative_formulary:
                self.generic_copayobj = self.generic_copayobj.getCopay(
                    self, alternative_formulary[0])

        unit_prices_dict = {"gpi": ndc_info["gpi"]}

        if self.brand_generic_switch is False:
            unit_prices_dict['drug_name'] = ndc_info['drug_name']
            unit_prices_dict['brandorgeneric'] = "Generic" if ndc_info['brand_generic'] == "G" else "Brand"
        unitprices = self.dataprovider.get_unit_price(unit_prices_dict)
        unit_prices = ''
        generic_unit_price = None
        if self.brand_generic_switch and any(d.get('brandorgeneric', None) == 'Generic' for d in unitprices):
            # generic_unit_price = list(filter(lambda x: x.get('brandorgeneric')=='Generic', unitprices))
            generic_unit_price = []
            unit_prices = []
            for item in unitprices:
                brandorgeneric = item.get('brandorgeneric')
                if brandorgeneric == "Generic":
                    generic_unit_price.append(item)
                elif brandorgeneric == "Brand":
                    unit_prices.append(item)
        self.unitpriceobj = self.unitpriceobj.getUnitPrice(
            self, unitprices if not unit_prices else unit_prices)
        self.rejection_reason = self.unitpriceobj.rejection_reason

        if self.brand_generic_switch and not self.rejection_reason:
            self.generic_unitpriceobj = self.generic_unitpriceobj.getUnitPrice(
                self, generic_unit_price)
        if not self.rejection_reason:
            self.pricesobj = self.pricesobj.getPrices(
                self, 0, self.unitpriceobj)
            self.rejection_reason = self.pricesobj.rejection_reason
            self.copayobj.copay = self.pricesobj.copay

        if self.brand_generic_switch and not self.rejection_reason:
            self.generic_pricesobj = self.generic_pricesobj.getPrices(
                self, 0, self.generic_unitpriceobj)
            self.generic_copayobj.copay = self.generic_pricesobj.copay
        self.original_employe_opc = self.pricesobj.employee_opc
        # employer cost and employee opc calculation is finished, additional penalty checks
        # mail_order_pharmacies = ['AMBER PHARMACY', 'HUMANA SPECIALTY', 'HUMANA MAIL ORDER', 'EXACT CARE PHARMACY',
        #                          'NOVARTIS-ONSITE PHARMACY', 'MAILORDER', 'SPECIALTY MAIL DELIVERY']
        self.log.debug(self.pricesobj.__dict__)
        self.log.debug(self.generic_pricesobj.__dict__)
        if not self.rejection_reason:
            if not self.brand_generic_switch and self.manufacturer_pricing:
                if self.pharmaobj.pharmacy_type != 'RETAIL':
                    '''
                    This block is executed when condition 1, i.e, 
                    Novartis drug and Novartis employee
                    manufacturer and domain are same 
                    no penalty applies as patient is buying from mail order pharmacy
                    '''
                    self.log.debug("Condition 1 Manufacturer Pricing and mail order pharmacy "
                                   "patient met his deductible, employer covering the entire drug cost")
                    self.pricesobj.copay = 0.00
                    self.pricesobj.employee_opc = 0.00
                    self.pricesobj.employer_cost = self.pricesobj.drug_cost

                elif self.pharmaobj.pharmacy_type == 'RETAIL' and \
                        self.rxplan_info.get('manufacture_rra') is not None:
                    '''
                    This block is executed when condition 1, i.e, 
                    Novartis drug and Novartis employee
                    manufacturer and domain are same 
                    check if penalty applies as patient is buying from retail pharmacy
                    '''
                    self.log.debug("Condition 1 Manufacturer Pricing and patient met his deductible, "
                                   "Checking for penalty as patient opted retail pharmacy")
                    presc_cnt = self.get_presc_count(ndc_info)
                    rra_daysofsupply_fillcount = self.rxplan_info['rra_daysofsupply_fillcount']
                    manufacture_rra = self.rxplan_info['manufacture_rra']
                    presc_cnt[rra_daysofsupply_fillcount] = "0" if presc_cnt[rra_daysofsupply_fillcount] == None else \
                        presc_cnt[rra_daysofsupply_fillcount]
                    if rra_daysofsupply_fillcount == "days_of_supply":
                        current_count = int(
                            self.claimobj.ClaimRequest.claimsseg.days_supply)
                    elif rra_daysofsupply_fillcount == "fill_count":
                        current_count = 1
                    total_count = int(
                        presc_cnt[rra_daysofsupply_fillcount]) + current_count
                    if total_count < int(manufacture_rra):
                        self.pricesobj.copay = self.pricesobj.employee_opc = 0.0
                        self.pricesobj.employer_cost = self.pricesobj.drug_cost
                    else:
                        self.log.debug(
                            "Adding Penalty Patient exceed the retail pharmacy limit")
                        self.pricesobj.employee_opc, self.pricesobj.employer_cost = \
                            self.apply_penalty(
                                self.rxplan_info['manufacture_rra_penalty'])
                        self.coins_amts(formulary_info)
            elif self.apply_non_manufacturer_penalty is True:
                self.log.debug("Non-Manufacturer drug")
                if self.drugobj.brand_generic in ["B", "T"] and self.generic_pricesobj.drug_cost != 0:
                    self.log.debug(
                        "Patient opted for brand drug, generic is available")
                    drug_cost = self.pricesobj.drug_cost
                    self.log.debug(f"Changing employer cost : {self.pricesobj.employer_cost} to generic employer "
                                   f"cost {self.generic_pricesobj.employer_cost}")
                    self.pricesobj.employer_cost = self.generic_pricesobj.employer_cost
                    self.log.debug(
                        "new employee opc with substracting eneric employer cost and adding brand copay")
                    employee_opc = (
                        drug_cost - self.generic_pricesobj.employer_cost)
                    self.pricesobj.employee_opc = drug_cost if employee_opc > drug_cost else employee_opc
                    self.log.debug(
                        f"Check if employee_opc: {employee_opc} is exceeding drug_cost : {drug_cost}")
                    self.log.debug("Updated employer and employee cost")
                    self.coins_amts(formulary_info)
                    self.log.debug(vars(self.pricesobj))

                if self.pharmaobj.pharmacy_type == 'RETAIL':
                    # apply penalty to employee
                    self.log.debug("Checking if penalty is applicable or not")
                    rra_penalty_type = None
                    if self.drugobj.specialty_flag == "Y" and self.rxplan_info["specialty_rra"]:
                        rra_penalty_type = "specialty"
                        self.log.debug(
                            "Drug belongs to speciality category and domain has speciality raa check")
                    elif self.drugobj.specialty_flag == "N" and self.rxplan_info["standard_rra"]:
                        rra_penalty_type = "standard"
                        self.log.debug(
                            "Drug belongs to standard category and domain has standard raa check")

                    if rra_penalty_type is not None:
                        presc_cnt = self.get_presc_count(ndc_info)

                        rra_daysofsupply_fillcount = self.rxplan_info['rra_daysofsupply_fillcount']
                        presc_cnt[rra_daysofsupply_fillcount] = "0" if presc_cnt[
                            rra_daysofsupply_fillcount] == None else presc_cnt[rra_daysofsupply_fillcount]
                        current_count = ''
                        if rra_daysofsupply_fillcount == "days_of_supply":
                            current_count = int(
                                self.claimobj.ClaimRequest.claimsseg.days_supply)
                        elif rra_daysofsupply_fillcount == "fill_count":
                            current_count = 1
                        total_count = int(
                            presc_cnt[rra_daysofsupply_fillcount]) + current_count

                        if total_count > int(self.rxplan_info[f"{rra_penalty_type}_rra"]):
                            self.pricesobj.employee_opc, self.pricesobj.employer_cost = \
                                self.apply_penalty(
                                    self.rxplan_info[f"{rra_penalty_type}_rra_penalty"])
                            self.rra_penalty_type = rra_penalty_type
                            self.coins_amts(formulary_info)
                            self.log.debug(vars(self.pricesobj))
        self.bin = self.claimobj.ClaimRequest.header.bin_number
        self.pcn = self.claimobj.ClaimRequest.header.processor_control_number

        if not self.rejection_reason and self.override is False:

            data = {'routed_date': self.claimobj.ClaimRequest.header.date_of_service, 'gpi': self.drugobj.gpi, 'drug_name': self.drugobj.drug_name, 'ddid': self.drugobj.ddid, 'brand_generic': self.drugobj.brand_generic,
                    'domain': self.domain_flags['domain'], 'benefit_plan_name': self.rxplan_info['plan_name'], 'quantity': self.claimobj.ClaimRequest.claimsseg.quantity_dispensed, 'days_of_supply': self.claimobj.ClaimRequest.claimsseg.days_supply, 'employer_cost': self.pricesobj.employer_cost, 'date_of_birth': self.userobj.date_of_birth}
            pa_result, pa_flag = self.pacheckobj.is_pa_required(
                data, formulary_info[0], self.rxplan_info)
            if pa_result:
                self.log.info('PA process required :'+pa_flag+' flag')
                self.rejection_reason = 'PA drug'
                self.pa_flag = pa_flag

        if self.unitpriceobj.claim_processor:
            claimprocinfo = self.dataprovider.get_claimprocessor_info(
                self.unitpriceobj.claim_processor)
            if claimprocinfo:
                self.bin = claimprocinfo['rxbin']
                self.pcn = claimprocinfo['rxpcn']
        self.log.debug(self.rejection_reason)
        return self.prepareResponse()

    def prepareResponse(self):
        result = {}
        result.update(self.rxplan_info)
        result.update(vars(self.copayobj))
        result.update(vars(self.deductibleinfoobj))
        result.update(vars(self.pricesobj))
        result.update(vars(self.unitpriceobj))
        result.update({'bin': self.bin, 'pcn': self.pcn,
                       'rejection_reason': self.rejection_reason, 'pa_flag': self.pa_flag, 'payment_option': self.userobj.payment_option})
        result.update(vars(self.pharmaobj))
        result['original_employee_opc'] = self.original_employe_opc
        result['brand_generic_switch'] = self.brand_generic_switch
        result['manufacturer_pricing'] = self.manufacturer_pricing
        result['apply_non_manufacturer_penalty'] = self.apply_non_manufacturer_penalty
        if self.rra_penalty_type:
            result['rra_penalty_type'] = self.rra_penalty_type
        if self.brand_generic_switch:
            result['generic'] = {}
            result['generic'].update(vars(self.generic_copayobj))
            result['generic'].update(vars(self.generic_pricesobj))
            result['generic'].update(vars(self.generic_unitpriceobj))
            result['generic'].update(vars(self.generic_drugobj))
        return result
