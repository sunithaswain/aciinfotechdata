from datetime import datetime
import logging


class CopayCalculation:

    def __init__(self):
        self.copay_amt = 0
        self.drug_deductible_exempt = '0'
        self.rejection_reason = ''
        self.copay_type = ''
        self.daysofsupply = ''
        self.penalty_factor = ''
        self.coinsurance_amounts = {}
        self.formularyinfo = {}
        self.log = logging.getLogger(__name__)

    def getCopay(self, erxliteobj, formularyinfo):

        self.log.debug('Getting copay in auto erx lite')
        # formularyinfo = claimprocobj.otherinfo['formulary_info'][0]

        if not formularyinfo:
            return self

        self.formularyinfo = formularyinfo

        # check PA
        nonretail = ''
        if erxliteobj.pharmaobj.pharmacy_type != 'RETAIL':
            nonretail = 'mo_'
        self.copay_type = formularyinfo['copay_type']
        self.coinsurance_amounts = {
            'co_ins_min_amount': formularyinfo['co_ins_min_amount']}

        self.log.debug(
            f"Co-insurance amounts from the formulary : {self.coinsurance_amounts}")
        self.drug_deductible_exempt = formularyinfo['deductibleexempted']
        self.penalty_factor = formularyinfo['penalty_factor']

        try:
            self.daysofsupply = int(
                erxliteobj.claimobj.ClaimRequest.claimsseg.days_supply)
        except Exception as e:
            self.daysofsupply = '30'
            erxliteobj.claimobj.ClaimRequest.claimsseg.days_supply = '30'
        if int(erxliteobj.claimobj.ClaimRequest.claimsseg.days_supply) > 90:
            self.copay_amt = float(
                formularyinfo[nonretail+'copayabove90daysupply'])
            if formularyinfo.get('co_ins_max_amount_above90daysupply', '') and not nonretail:
                self.coinsurance_amounts = {
                    'co_ins_min_amount': formularyinfo['co_ins_min_amount'], 'co_ins_max_amount': formularyinfo['co_ins_max_amount_above90daysupply']}
        elif int(erxliteobj.claimobj.ClaimRequest.claimsseg.days_supply) <= 90 and int(erxliteobj.claimobj.ClaimRequest.claimsseg.days_supply) > 60:
            self.copay_amt = float(
                formularyinfo[nonretail + 'copay_90daysupply'])
            if formularyinfo.get('co_ins_max_amount_90daysupply', '') and not nonretail:
                self.coinsurance_amounts = {
                    'co_ins_min_amount': formularyinfo['co_ins_min_amount'], 'co_ins_max_amount': formularyinfo['co_ins_max_amount_90daysupply']}
        elif int(erxliteobj.claimobj.ClaimRequest.claimsseg.days_supply) <= 60 and int(erxliteobj.claimobj.ClaimRequest.claimsseg.days_supply) > 30:
            self.copay_amt = float(
                formularyinfo[nonretail + 'copay_60daysupply'])
            if formularyinfo.get('co_ins_max_amount_60daysupply', '') and not nonretail:
                self.coinsurance_amounts = {
                    'co_ins_min_amount': formularyinfo['co_ins_min_amount'], 'co_ins_max_amount': formularyinfo['co_ins_max_amount_60daysupply']}
        else:
            self.copay_amt = float(
                formularyinfo[nonretail + 'copay_30daysupply'])
            if formularyinfo.get('co_ins_max_amount', '') and not nonretail:
                self.coinsurance_amounts = {
                    'co_ins_min_amount': formularyinfo['co_ins_min_amount'], 'co_ins_max_amount': formularyinfo['co_ins_max_amount']}

        return self

    def getCoinsuranceCopay(self, drug_cost, copay, coinsuranceamounts):

        self.log.debug('Calculating coinsurance copay in auto erx lite')
        copay = float(drug_cost) * float(copay)/100.0
        if float(drug_cost) < float(copay):
            copay = float(drug_cost)
        if coinsuranceamounts.get('co_ins_min_amount'):
            copay = max(copay, float(
                coinsuranceamounts.get('co_ins_min_amount')))
        if coinsuranceamounts.get('co_ins_max_amount'):
            copay = min(copay, float(
                coinsuranceamounts.get('co_ins_max_amount')))
        return copay
