import logging
from datetime import datetime


class PriceCalculation:

    def __init__(self):

        self.drug_cost = 0
        self.employee_opc = 0
        self.employer_cost = 0
        self.rejection_reason = ''
        self.copay = 0
        self.reward = 0
        self.penalty = 0
        self.baseline_price = 0
        self.total_payment = 0
        self.log = logging.getLogger(__name__)

    def getPrices(self, erxliteobj, drug_cost, unitpriceobj,):
        self.log.debug('Calculating costs in auto erx lite')

        if drug_cost == 0:
            try:
                self.drug_cost = float(unitpriceobj.unit_price)*float(erxliteobj.claimobj.ClaimRequest.claimsseg.quantity_dispensed)*float(unitpriceobj.pharmacy_discount) + \
                    float(unitpriceobj.pharmacy_dispensing_fee)
                self.log.debug(f"Claculated drug cost: {self.drug_cost}")
            except Exception as _:
                pass
        else:
            self.drug_cost = drug_cost
        if not self.drug_cost > 0:
            self.rejection_reason = "Could not calculate price"
            return self

        copayadded = False

        if erxliteobj.copayobj.copay_type.lower() == 'co_ins_percentage':
            self.copay = erxliteobj.copayobj.getCoinsuranceCopay(
                self.drug_cost, erxliteobj.copayobj.copay_amt, erxliteobj.copayobj.coinsurance_amounts)
        else:
            self.copay = erxliteobj.copayobj.copay_amt

        self.copay = min(self.drug_cost, self.copay)

        if not (erxliteobj.deductibleinfoobj.opc_remaining > 0) and erxliteobj.claimprocobj.otherinfo['formulary_info'][0].get('outofpocket_max_exempt') == "N":
            self.employee_opc = 0

        elif erxliteobj.copayobj.drug_deductible_exempt == '1' or \
                (not (erxliteobj.deductibleinfoobj.deductible_remaining > 0) and
                 erxliteobj.deductibleinfoobj.opc_remaining > 0):
            erxliteobj.deductibleinfoobj.deductible_remaining = 0
            self.employee_opc = min(self.drug_cost, self.copay)

        elif erxliteobj.deductibleinfoobj.deductible_remaining > 0:
            if erxliteobj.deductibleinfoobj.opc_remaining < 0:
                self.employee_opc = self.drug_cost
            else:
                if not (erxliteobj.deductibleinfoobj.opc_remaining > 0):
                    self.employee_opc = 0
                elif max(erxliteobj.deductibleinfoobj.deductible_remaining, self.copay) > self.drug_cost:
                    self.employee_opc = self.drug_cost
                elif max(erxliteobj.deductibleinfoobj.deductible_remaining, self.copay) < self.drug_cost:
                    self.employee_opc = max(
                        erxliteobj.deductibleinfoobj.deductible_remaining, self.copay)
                    if erxliteobj.deductibleinfoobj.deductible_remaining < self.copay:
                        copayadded = True
            if erxliteobj.deductibleinfoobj.opc_remaining > 0 and self.employee_opc >= erxliteobj.deductibleinfoobj.deductible_remaining:
                self.employee_opc = erxliteobj.deductibleinfoobj.deductible_remaining + \
                    min(self.copay, self.drug_cost -
                        erxliteobj.deductibleinfoobj.deductible_remaining)
                if self.copay < (self.drug_cost - erxliteobj.deductibleinfoobj.deductible_remaining):
                    copayadded = True
        if erxliteobj.claimprocobj.otherinfo['formulary_info'][0].get('outofpocket_max_exempt') == "Y":
            self.employee_opc = min(self.drug_cost, self.copay)

        pass
        if copayadded:
            self.employee_opc = max((self.employee_opc - self.copay), 0)

        self.employer_cost = self.drug_cost - self.employee_opc

        '''

        # baseline-penalty-rewards logic

        erxliteobj.pricesobj = self
        self.getBaseline(erxliteobj)
        erxliteobj.pricesobj.baseline_price = self.baseline_price
        if erxliteobj.domain_flags and erxliteobj.domain_flags.get('rewards_autoerx', '') == 'Y':
            self.getRewards(erxliteobj)
        erxliteobj.pricesobj.reward = self.reward
        self.getPenalty(erxliteobj)
        '''

        return self

    def getBaseline(self, erxliteobj):

        self.baseline_price = 0
        return self

    def getRewards(self, erxliteobj):

        totalrewards = erxliteobj.dataprovider._get_reward_details(
            {'flipt_person_id': erxliteobj.userobj.rx_flipt_person_id, 'year': str(datetime.now().year)})

        if int(max(erxliteobj.deductibleinfoobj.deductible_remaining - erxliteobj.pricesobj.employee_opc, 0)) == 0 and erxliteobj.domain_flags.get('reward_share', ''):
            self.reward = max(erxliteobj.pricesobj.baseline_price -
                              erxliteobj.pricesobj.drug_cost, 0) * (float(erxliteobj.domain_flags['reward_share'].replace('%', '')) / 100.0)

        if erxliteobj.domain_flags.get('max_reward_per_year', '') and totalrewards >= float(erxliteobj.domain_flags.get('max_reward_per_year', '')):
            self.reward = 0

        if erxliteobj.domain_flags.get('max_reward_per_rx', '') and self.reward > float(erxliteobj.domain_flags.get('max_reward_per_rx', '')):
            self.reward = float(
                erxliteobj.domain_flags.get('max_reward_per_rx', ''))

        if erxliteobj.domain_flags.get('rewards_opc_multiplier', '') and erxliteobj.domain_flags.get('rewards_baseline_multiplier', '') and erxliteobj.domain_flags.get('rewards_fixed_amount', ''):
            self.reward = min(self.reward, min(max(float(erxliteobj.domain_flags.get('rewards_opc_multiplier', '')) * erxliteobj.pricesobj.employee_opc, float(
                erxliteobj.domain_flags.get('rewards_baseline_multiplier', '').replace('%', ''))*erxliteobj.pricesobj.baseline_price), float(erxliteobj.domain_flags.get('rewards_fixed_amount', ''))))
        return self

    def getPenalty(self, erxliteobj):

        self.penalty = round(
            max(0, erxliteobj.pricesobj.drug_cost - erxliteobj.pricesobj.baseline_price))
        #import pdb
        if erxliteobj.copayobj.penalty_factor:
            penalty_factor = erxliteobj.copayobj.penalty_factor

        elif erxliteobj.domain_flags.get('employer_penalty_factor', ''):
            penalty_factor = erxliteobj.domain_flags.get(
                'employer_penalty_factor', '')
        else:
            penalty_factor = 100

        self.penalty = round(self.penalty * (int(penalty_factor) / 100))

        if not erxliteobj.deductibleinfoobj.opc_remaining > 0 and erxliteobj.domain_flags.get('apply_penalty_after_outofpocketmet', '') == 'N':
            self.penalty = 0

        if erxliteobj.deductibleinfoobj.deductible_remaining > 0:
            self.penalty = 0

        self.employee_opc = self.employee_opc + self.penalty

        self.total_payment = max(self.employee_opc - self.reward, 0)

        return self
