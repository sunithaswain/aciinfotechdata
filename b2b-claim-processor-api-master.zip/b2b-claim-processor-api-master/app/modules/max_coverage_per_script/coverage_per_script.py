import logging
from datetime import datetime, timedelta


class MaxCoveragePerScript(object):

    def __init__(self, query_ex, domain_flags, other_info):
        self.log = logging.getLogger()
        self.domain_flags = domain_flags
        self.other_info = other_info
        self.domain = domain_flags['domain']
        self.plan = other_info['rxplan_info']['plan_name']
        self.year = other_info['rxplan_info']['plan_year']
        self.rxplaninfo = other_info.get('rxplan_info', {})
        self.days_of_supply = other_info['prescription']['daysofsupply']
        self.query_ex = query_ex
        # for current prescription
        self.current_employer_cost = other_info['prescription']['employer_cost']
        self.employee_opc = other_info['prescription']['employee_opc']
        # patient pay amount
        self.drug_copay = other_info['prescription']['copay'] if other_info['prescription'].get(
            'copay', '') else other_info['prescription']['drug_copay']
        self.drug_name = other_info['drug_name']
        self.gpi = other_info['gpi']
        self.flipt_person_id = other_info['flipt_person_id']

    def get_days_back_to_look(self, days_of_supply, plan_coverage_days):
        dos = int(days_of_supply)
        if dos <= 30:
            days = plan_coverage_days
        elif 30 < dos <= 60:
            days = plan_coverage_days * 2
        else:
            days = plan_coverage_days * 3
        return int(days) - 5

    def get_max_coverage(self, days_of_supply, plan_coverage_per_drug):
        dos = int(days_of_supply)
        if dos <= 30:
            max_coverage = plan_coverage_per_drug
        elif 30 < dos <= 60:
            max_coverage = plan_coverage_per_drug * 2
        else:
            max_coverage = plan_coverage_per_drug * 3
        return max_coverage

    def get_greater_than_date(self, days):
        dt = datetime.now() - timedelta(days=int(days))
        # return time in ISO string format
        return dt.isoformat()

    def get_historical_emp_cost(self, drug_name, flipt_person_id, coverageStart):
        presc_res = self.query_ex.execute_query('sum(tonumber(employer_cost)) as historical_emp_cost', 'prescription',
                                                filters={'flipt_person_id': flipt_person_id[:-2],
                                                         'drug_name': drug_name,
                                                         'rx_status': "Filled",
                                                         'filled_date >': coverageStart}
                                                )
        # employer spent on that drug in the prescribed days
        return 0 if presc_res['historical_emp_cost'] is None else presc_res['historical_emp_cost']

    def update_costs(self, coverage_balance, current_employer_cost, employee_opc, drug_copay):
        '''
        :param self:
        :param coverage_balance:
        :param current_employer_cost:
        :param employee_opc:
        :param drug_copay:
        :return: employer_funding, copay+cost_to_employee
        '''
        copay = employee_opc if employee_opc < drug_copay else drug_copay
        if coverage_balance <= 0:
            employer_funding = 0
            cost_to_employee = float(copay) + float(current_employer_cost)
            self.log.debug(
                f"Employer funding and employee cost for this drug: {employer_funding} and {cost_to_employee}")
        elif float(coverage_balance) >= float(current_employer_cost):
            employer_funding = current_employer_cost
            cost_to_employee = copay
            self.log.debug(
                f"Employer funding and employee cost for this drug: {employer_funding} and {cost_to_employee}")
        else:
            # coverage_balance is less than current_employer_cost
            employer_funding = coverage_balance
            cost_to_employee = float(
                copay) + (float(current_employer_cost) - float(coverage_balance))
            self.log.debug(
                f"Employer funding and employee cost for this drug: {employer_funding} and {cost_to_employee}")
        return employer_funding, cost_to_employee

    def get_coverage(self):
        '''
        res = self.query_ex.execute_query('plan_coverage_per_drug, plan_coverage_days', 'rxplan_master',
                                          filters={'domain_name': self.domain,
                                                   'plan_name': self.plan,
                                                   'plan_year': self.year}
                                          )
        '''
        # 1000 or 2000 1250

        plan_coverage_per_drug = self.rxplaninfo['plan_coverage_per_drug']
        # 30 or 60 or 90
        plan_coverage_days = self.rxplaninfo['plan_coverage_days']
        self.log.debug(
            f"Max coverage per drug and coverage days: {plan_coverage_per_drug} and {plan_coverage_days}")
        if not (plan_coverage_per_drug and plan_coverage_days):
            return "Coverage data not found"
        max_coverage = self.get_max_coverage(
            self.days_of_supply, plan_coverage_per_drug)  # 1000, 30
        self.log.debug(
            f"Coverage days as per the prescription: {max_coverage}")
        days_to_query = self.get_days_back_to_look(
            self.days_of_supply, plan_coverage_days)
        self.log.debug(
            f"No.of Days to check in prescription for historical data: {days_to_query}")
        min_date = self.get_greater_than_date(days_to_query)
        self.log.debug(f"Getting total employer spent ")
        historical_emp_cost = self.get_historical_emp_cost(
            self.drug_name, self.flipt_person_id, min_date)
        # result - self.update_costs(historical_coverage, )
        # this os the left over balance
        coverage_balance = max(max_coverage - historical_emp_cost, 0)
        result = self.update_costs(
            coverage_balance, self.current_employer_cost, self.employee_opc, self.drug_copay)
        return result

    '''
    case 1
    max coverage = 5000
    historical_coverage = 3000
    current_employer_cost = 1000
    employer will pay 1000 usd and employee will pay 30 his copay we do nothing inthis case

    case 2
    max coverage = 5000
    historical_coverage = 2500
    current_employer_cost = 2500
    patient is still covered 
    copay = 30 usd 
    current_employer cost = 2500 
    we will do nothing 

    case 3
    max covered = 5000
    historical_coverage = 3000
    current_employer_cost = 3000

    now employer will pay current_employer_cost = (max covered  -  historical_coverage)

    now current_employer_Cost will become 2000
    and copay = copay + current_employer_cost
                    30 + 1000 this is the new patient pay amt

    case 4

    max covered = 5000
    historica = 5000

    current_employer cost = 5000

    patient has to pay the full amount as employer limit was already reached '''
