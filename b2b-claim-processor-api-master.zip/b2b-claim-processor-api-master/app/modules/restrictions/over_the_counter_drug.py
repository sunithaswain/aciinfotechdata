from datetime import datetime
from couchbase.n1ql import N1QLQuery
from couchbase.cluster import Cluster, PasswordAuthenticator


class OverTheCounterDrug(object):

    def __init__(self, config):
        self.config = config
        self.cb = self.config.cb
        self.instance_type = self.config.CB_INSTANCE

    def get_rxplan_master_info(self, plan_information):

        base_query = f"SELECT * FROM `{self.instance_type}` WHERE type='rxplan_master' AND domain_name='" \
                     f"{plan_information['domain_name']}' AND plan_name='{plan_information['plan_name']}' AN" \
                     f"D plan_end_date='{plan_information['plan_end_date']}' AND plan_start_date='{plan_information['plan_start_date']}'"
        query = N1QLQuery(base_query)

        return self.cb.n1ql_query(query).get_single_result()

    def get_formulary_for_drug(self, drug, plan_information):
        if drug['brand_generic'] == 'B':
            drug['brand_generic'] = 'T'
        document_types = ['formulary_'+plan_information['domain_name'],'formulary']
        for doctype in document_types:
            base_query = f"SELECT company_formulary, ARRAY cf FOR cf IN company_formulary WHEN cf.company = '" \
                        f"{plan_information['domain_name']}' AND cf.plan_name = '{plan_information['plan_name']}' AND " \
                        f"cf.effective_start_date='{plan_information['plan_start_date']}' AND cf.effective_end_date='{plan_information['plan_end_date']}' END as cf FROM `{self.instance_type}` WHERE " \
                        f"type='{doctype}' AND gpi='{drug['gpi']}'  AND " \
                        f"drug_name='{drug['drug_name']}' AND brand_generic='{drug['brand_generic']}'"

            query = N1QLQuery(base_query)

            return self.cb.n1ql_query(query).get_single_result()

    def is_otc_drug_covered(self, drug, rxplan_master, formulary):
        result = True if drug['otc_indicator'] != 'R' else False

        if not result:
            return True

        if result:
            otc_inclusion_flag = rxplan_master
            if otc_inclusion_flag.get('otc_inclusion_flag', 'N') == 'Y':
                otc_inclusion = formulary

                if otc_inclusion.get('cf', False):
                    if otc_inclusion['cf'][0].get('otc_inclusion', 'N') == 'Y':
                        return True

        return False

    def get_drug_info_by_ndc(self, ndc_id):

        base_query = f"SELECT * FROM `{self.instance_type}` WHERE type='ndc_drugs' AND ndc='{ndc_id}'"

        query = N1QLQuery(base_query)

        result = self.cb.n1ql_query(query).get_single_result()

        if not result:
            return {}

        return result[self.instance_type]

    def __stringified_ids(self, ids):
        ids_array = ""

        for id in ids:
            ids_array += f"'{id}',"

        return ids_array[:-1]

    def get_otc_indicator_by_ddids(self, ddids):
        base_query = f"SELECT DISTINCT(otc_indicator), ddid FROM `{self.instance_type}` WHERE type='ndc_drugs' " \
                     f"AND ddid IN [{self.__stringified_ids(ddids)}]"

        query = N1QLQuery(base_query)

        result = self.cb.n1ql_query(query)

        response = []

        for res in result:
            if res["otc_indicator"] != "R":
                response.append({"ddid": res["ddid"], "is_otc": False})
            else:
                response.append({"ddid": res["ddid"], "is_otc": True})

        return response
