import logging


class DrugCovered(object):
    def __init__(self, query_ex, config):
        self.query_ex = query_ex
        self.config = config
        self.log = logging.getLogger()

    def get_drug_info(self, data, formulary_data, rxplan_master):
        """

        :return: returns the drug information from ndc_drugs and drug tables
        """
        is_api_call = True if 'ddid' in data else False
        domain = data['domain']
        plan_year = data['plan_year']
        plan_name = data['benefit_plan_name']
        drug_name_str = 'drug_name'
        drug_name = data['drug_name']
        if is_api_call:
            drug_id = data['ddid']
            drug_id_str = 'ddid'
        elif 'gpi' in data:
            drug_id = data['gpi']
            drug_id_str = 'gpi'

        # query = (f"select * from `{self.config.CB_INSTANCE}` b unnest b.company_formulary cf " +
        #          f"where b.type='formulary' and cf.company='{domain}' and cf.plan_year='{plan_year}' " +
        #          f"and cf.plan_name='{plan_name}' and " +
        #          f"b.{drug_id_str} = '{drug_id.strip()}' and b.{drug_name_str} = '{drug_name}'")
        # self.log.debug(f"Preparing the query for getting drug info: {query}")

        # Check if the drug is covered or not
        if not formulary_data:
            self.log.debug(f"Drug not found in the formulary for domain:{domain}, {drug_id_str}:{drug_id}, "
                           f"plan_name:{plan_name}, plan_year:{plan_year}")
            result = {'drug_covered': False, 'drug_dispensed': False}
            return result
        result = {'drug_covered': True, 'drug_dispensed': True}
        if formulary_data[0]['drug_covered'] == 'N':
            self.log.info(f"Drug is not covered, checking can be dispensed")
            domain_covered_res = rxplan_master
            self.log.debug(
                "Executing the query to check if drug can be dispensed or not")
            if domain_covered_res['drug_notcovered_can_be_dispensed'] == 'N':
                self.log.info(
                    f"Drug is not covered and cannot be dispensed: {drug_id}")
                result['drug_covered'] = False
                result['drug_dispensed'] = False
            else:
                result['drug_dispensed'] = True

        if is_api_call:
            result.update(data)
        return result
