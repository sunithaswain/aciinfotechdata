import logging
from datetime import datetime, timedelta
from app.modules.pa_override import pa_override_check


class PaCheck(object):
    def __init__(self, query_ex, config):
        self.query_ex = query_ex
        self.config = config
        self.log = logging.getLogger()

    def is_pa_required(self, data, formulary={}, rxplaninfo={}):
        """
        :return: returns if pa process is to be followed for the rx
        """
        is_api_call = True if not formulary else False

        try:
            datetime.strptime(data['routed_date'], '%Y-%m-%d %H:%M:%S.%f')
        except:
            try:
                data['routed_date'] = datetime.strftime(datetime.strptime(
                    data['routed_date'], '%Y-%m-%d'), '%Y-%m-%d 00:00:00')
            except:
                try:
                    data['routed_date'] = datetime.strftime(
                        datetime.strptime(data['routed_date'], '%Y%m%d'), '%Y-%m-%d 00:00:00')
                except:
                    data['routed_date'] = datetime.strftime(
                        datetime.today(), '%Y-%m-%d 00:00:00')
        date_of_birth = data.get('date_of_birth', '')
        try:
            date_of_birth = datetime.strptime(
                date_of_birth, '%Y-%m-%d %H:%M:%S')
            data['age'] = (
                datetime.today() - date_of_birth) // timedelta(days=365.2425)
        except:
            self.log.info('Invalid date of birth:' +
                          data.get('date_of_birth', ''))

        if 'ndc' in data:
            drugresult = self.get_drug_info(data['ndc'])
            data['gpi'] = drugresult['gpi']
            data['drug_name'] = drugresult['gpi']
            data['ddid'] = drugresult['ddid']
            data['brand_generic'] = drugresult['brand_generic']

        if not formulary:
            formulary = self.get_formulary_info(
                data['domain'], data['routed_date'], data['benefit_plan_name'], data['ddid'], data['gpi'], data['drug_name'], data['brand_generic'])

        try:
            if rxplaninfo and float(rxplaninfo['pa_employer_cost_limit']) < float(data['employer_cost']):
                formulary['pa_flag'] = 'Y'
                formulary['pa_cost'] = 'Y'
        except:
            pass
        if formulary.get('pa_flag', '') == 'N':
            return False, 'N'
        if is_api_call:

            if self.is_pa_overridden(data['routed_date'], data['gpi'], data['drug_name'], data['brand_generic'], data['flipt_person_id'], data['benefit_plan_name'], data['domain']):
                return False

        pa_category_sequence = self.query_ex.execute_query('pa_category', 'pa_category_sequence',
                                                           get_single_result=False, orderby='order by tonumber(sequence)')
        #import pdb
        # pdb.set_trace()

        for pa_category in pa_category_sequence:
            pa_check_result = self.pa_category_check(
                data, pa_category['pa_category'], formulary, rxplaninfo)
            if pa_check_result:
                return True, pa_category['pa_category']

        return False, 'N'

    def get_drug_info(self, drug_ndc):
        ndc_res = self.query_ex.execute_query('gpi, drug_name, ddid, brand_generic', 'ndc_drugs',
                                              filters={'ndc': drug_ndc}, get_single_result=True)
        return ndc_res

    def get_formulary_info(self, domain, date_of_service, plan_name, ddid, gpi, drug_name, brand_generic):

        formulary_res = self.query_ex.execute_query(
            'company_formulary', 'formulary', filters={'ddid': ddid, 'gpi': gpi, 'drug_name': drug_name, 'brand_generic': brand_generic}, get_single_result=True)

        formulary = [record for record in formulary_res['company_formulary'] if (
            (record['company'] == domain) and (record['plan_name'] == plan_name) and (record['effective_start_date'] <= date_of_service <= record['effective_end_date']))]

        if formulary:
            return formulary[0]
        return {}

    def check_is_pa_overridden(self, date_of_service, gpi, drug_name, brand_generic, flipt_person_id, plan_name, domain):
        obj = pa_override_check().is_pa_overridden(date_of_service=date_of_service,
                                                   gpi=gpi,
                                                   drug_name=drug_name,
                                                   brand_generic=brand_generic,
                                                   flipt_person_id=flipt_person_id,
                                                   plan_name=plan_name,
                                                   domain=domain)
        if obj.get_pa_override_info():
            return True

        return False

    def pa_category_check(self, data, pa_category, formulary, rxplaninfo):

        self.log.info(pa_category+' flag check')

        if pa_category in ['pa_clinical', 'pa_abuse_misuse']:
            if formulary[pa_category] == 'Y':
                return True

        elif pa_category == 'pa_age':
            try:
                pa_age = int(formulary[pa_category])
                patient_age = int(data['age'])
                if pa_age <= 0 and patient_age > abs(pa_age):
                    return True
                elif pa_age >= 0 and patient_age < pa_age:
                    return True
            except Exception as e:
                self.log.info(e)

        elif pa_category == 'pa_gender':
            if formulary[pa_category] != data.get('gender', '') and formulary[pa_category] not in ['N', '']:
                return True

        elif pa_category == 'pa_quantity':

            try:
                rx_qa_ratio = float(data['quantity']) / \
                    float(data['days_of_supply'])
                if formulary[pa_category] == 'Y' and rx_qa_ratio > float(formulary['ql_ratio']):
                    return True
            except Exception as e:
                self.log.info(e)

        elif pa_category == 'pa_cost':
            if formulary[pa_category] == 'Y':
                if not rxplaninfo:
                    pa_employer_cost_limit = self.query_ex.execute_query('pa_employer_cost_limit,plan_start_date,', 'rxplan_master',
                                                                         filters={'plan_name': data['benefit_plan_name'],
                                                                                  'domain_name': data['domain'], 'plan_start_date <': data['routed_date'],
                                                                                  'plan_end_date >': data['routed_date']},
                                                                         get_single_result=True)
                else:
                    pa_employer_cost_limit = rxplaninfo.get(
                        'pa_employer_cost_limit', '')
                try:
                    pa_employer_cost_limit = float(pa_employer_cost_limit)
                    rx_employer_cost = float(
                        data['employer_cost']) / (float(data['days_of_supply']) / 30.0)
                    if (pa_employer_cost_limit < rx_employer_cost) or (pa_employer_cost_limit < float(data['employer_cost'])):
                        return True
                except Exception as e:
                    self.log.info(e)

        return False
