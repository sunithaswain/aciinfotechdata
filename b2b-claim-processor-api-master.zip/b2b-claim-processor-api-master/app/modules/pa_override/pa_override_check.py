import logging
from datetime import datetime


class PAOverRideCheck(object):
    def __init__(self, query_ex, date_of_service, gpi, drug_name, brand_generic, flipt_person_id, plan_name, domain):
        self.date_of_service = date_of_service
        self.query_ex = query_ex
        self.gpi = gpi
        self.drug_name = drug_name
        self.brand_generic = brand_generic.replace('B','T')
        self.date_of_service = datetime.strftime(
            datetime.strptime(date_of_service, '%Y%m%d'), '%Y-%m-%d')+'T'+datetime.now().time().isoformat()+'Z'
        self.plan_name = plan_name
        self.domain = domain
        self.flipt_person_id = flipt_person_id
        self.formularyinfo = {}
        self.log = logging.getLogger()

    def get_pa_override_info(self):

        over_ride = self.query_ex.getPAOverrideData({'drug_name': self.drug_name,
                                                     'gpi': self.gpi,
                                                     'pa_override_status': 'Active',
                                                     'brand_generic': self.brand_generic,
                                                     'rx_flipt_person_id': self.flipt_person_id,
                                                     'date_of_service': self.date_of_service})
        if self.formularyinfo.get('formulary_info', []) and self.formularyinfo.get('formulary_info')[0]['pa_override'] == 'N':
            over_ride = None
        return over_ride

    def is_pa_overridden(self):
        self.log.debug("Inside pa override check")

        formulary = self.query_ex.get_formulary_for_drug(drug={'gpi': self.gpi}, plan_information={
                                                         'date_of_service': self.date_of_service, 'plan_name': self.plan_name, 'domain_name': self.domain})
        default_formulary_index = next((index for (index, d) in enumerate(formulary)
                                        if d["brand_generic"] == self.brand_generic), None)
        alternative_formulary_index = next((index for (index, d) in enumerate(formulary)
                                            if d["brand_generic"] != self.brand_generic), None)
        if alternative_formulary_index is not None:
            self.formularyinfo["alternative_formulary"] = formulary[alternative_formulary_index]['cf']
        if default_formulary_index is not None:
            self.formularyinfo['formulary_info'] = formulary[default_formulary_index]['cf']

        over_ride = self.get_pa_override_info()

        if not over_ride:
            return self._prepare_response(formularyinfo=self.formularyinfo)

        return self._prepare_response("Y", over_ride[0]["override_id"], "",
                                      "", "", self.formularyinfo)

    def _prepare_response(self, over_ride="", override_number="", copay_override="", override_amount="",
                          override_percentage="", formularyinfo={}):
        status = True if over_ride else False
        res = {'result': status,
               'override_number': override_number,
               'copay_override': copay_override,
               'override_amount': override_amount,
               'override_percentage': override_percentage,
               'over_ride_result': over_ride,
               'formularyinfo': formularyinfo}
        return res
