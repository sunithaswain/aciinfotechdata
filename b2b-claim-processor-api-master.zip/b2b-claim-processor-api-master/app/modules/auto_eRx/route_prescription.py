import requests
import json
from types import SimpleNamespace as Namespace


class RoutePrescription:

    def __init__(self, config, dataprovider):
        self.url = config.graphql_url
        self.dataprovider = dataprovider

    def routeIntent(self, autoerxobj, pricelist):
        mutation = """mutation (
            $prescription_id: String
            $baseline_cost: String
            $bin: String
            $deductible_remaining: String
            $drug_copay: String
            $drug_cost: String
            $drug_deductible_exempt: Boolean
            $drug_penalty: String
            $employee_opc: String
            $employer_cost: String
            $group_id: String
            $member_id: String
            $npi: String
            $out_of_pocket_remaining: String
            $payment_option: String
            $pbm_estimated_cost: String
            $pbm_price: String
            $pcn: String
            $pharmacy: String
            $reward_percentage: String
            $rewards: String
            $chaincode: String
            $drug_cost_before_rebate: String
            $pharmacy_discount: String
            $pharmacy_dispensing_fee: String
            $rebate_amount: String
            $rebate_factor: String
            $unit_price: String
            $unit_price_before_rebate: String
            $zone: String
            $reward_share: String
            $retail_reward: String
            $total_payment: String
            $penalty_factor: String
            $pa_flag: String
            $pa_form: String
            $pa_reason: String
            $pa_override: String
            $alternative_drug_rewards: String
            $drug_class: String
            $otc_indicator: String
            $maintenance_drug_flag: String
            $specialty_flag: String
            $oop_accumulator_amount: Float
            $deductible_accumulator_amount: Float
            

        ) {
        v2RoutePrescription(
            prescription_id: $prescription_id
            baseline_cost: $baseline_cost
            bin: $bin
            deductible_remaining: $deductible_remaining
            drug_copay: $drug_copay
            drug_cost: $drug_cost
            drug_deductible_exempt: $drug_deductible_exempt
            drug_penalty: $drug_penalty
            employee_opc: $employee_opc
            employer_cost: $employer_cost
            group_id: $group_id
            member_id: $member_id
            npi: $npi
            out_of_pocket_remaining: $out_of_pocket_remaining
            payment_option: $payment_option
            pbm_estimated_cost: $pbm_estimated_cost
            pbm_price: $pbm_price
            pcn: $pcn
            pharmacy: $pharmacy
            reward_percentage: $reward_percentage
            rewards: $rewards
            chaincode: $chaincode
            drug_cost_before_rebate: $drug_cost_before_rebate
            pharmacy_discount: $pharmacy_discount
            pharmacy_dispensing_fee: $pharmacy_dispensing_fee
            rebate_amount: $rebate_amount
            rebate_factor: $rebate_factor
            unit_price: $unit_price
            unit_price_before_rebate: $unit_price_before_rebate
            zone: $zone
            reward_share: $reward_share
            retail_reward: $retail_reward
            total_payment: $total_payment
            penalty_factor: $penalty_factor
            pa_flag: $pa_flag
            pa_form: $pa_form
            pa_reason: $pa_reason
            pa_override: $pa_override
            alternative_drug_rewards: $alternative_drug_rewards
            drug_class: $drug_class,
            otc_indicator: $otc_indicator,
            maintenance_drug_flag: $maintenance_drug_flag,
            specialty_flag: $specialty_flag,
            oop_accumulator_amount: $oop_accumulator_amount,
            deductible_accumulator_amount: $deductible_accumulator_amount
        ) {
            prescription_id
        }
        } """

        current_drug = pricelist.loc[pricelist['pharmacy_npi']
                                     == autoerxobj.pharmacyinfoobj.npi]

        bin = autoerxobj.claimobj.ClaimRequest.header.bin_number
        pcn = autoerxobj.claimobj.ClaimRequest.header.processor_control_number
        provider_name = current_drug['provider_name'].values[0]
        claimprocinfo = self.dataprovider.get_claimprocessor_info(
            provider_name)
        if claimprocinfo:
            bin = claimprocinfo['rxbin']
            pcn = claimprocinfo['rxpcn']

        try:
            total_reward = str(
                int(current_drug['alternate_reward'].values[0]) + int(current_drug['retail_reward'].values[0]))
        except Exception as _:
            total_reward = '0'

        pa_flag = 'N'
        if 'rejection_reason' in autoerxobj.otherinfo['prescription'] and autoerxobj.otherinfo['prescription']['rejection_reason'] == 'PA drug':
            pa_flag = 'Y'
        if 'rewards_autoerx' in autoerxobj.domain_flag and autoerxobj.domain_flag['rewards_autoerx']:
            rewards = '0'
        else:
            rewards = str(current_drug["drug_reward"].values[0])

        routevalues = {"prescription_id": str(autoerxobj.prescription_id),
                       "baseline_cost": str(current_drug["drug_baseline_price"].values[0]),
                       "bin": bin,
                       "deductible_remaining": str(current_drug["deductible_remaining"].values[0]),
                       "drug_copay": str(current_drug["drug_copay"].values[0]),
                       "drug_cost": str(current_drug["drug_price"].values[0]),
                       "drug_deductible_exempt": bool(current_drug["drug_deductible_exempt"].values[0]),
                       "drug_penalty": str(current_drug["drug_penalty"].values[0]),
                       "employee_opc": str(current_drug["employee_opc"].values[0]),
                       "employer_cost": str(current_drug["drug_employer_cost"].values[0]),
                       "group_id": str(autoerxobj.claimobj.ClaimRequest.insuranceseg.group_id),
                       "member_id": str(autoerxobj.userinfoobj.emp_flipt_person_id)+str(autoerxobj.userinfoobj.person_code),
                       "npi": str(autoerxobj.pharmacyinfoobj.npi),
                       "out_of_pocket_remaining": str(current_drug["out_of_pocket_remaining"].values[0]),
                       "payment_option": autoerxobj.userinfoobj.payment_option,
                       "pbm_estimated_cost": str(current_drug["pbm_estimated_cost"].values[0]),
                       "pbm_price": str(current_drug["pbm_price"].values[0]),
                       "pcn": pcn,
                       "pharmacy": str(autoerxobj.pharmacyinfoobj.pharmacy),
                       "reward_percentage": str(current_drug["reward_percentage"].values[0]),
                       "rewards": rewards,
                       "chaincode": str(current_drug["chaincode"].values[0]),
                       "drug_cost_before_rebate": str(current_drug["drug_cost_before_rebate"].values[0]),
                       "pharmacy_discount": str(current_drug["pharmacy_discount"].values[0]),
                       "pharmacy_dispensing_fee": str(current_drug["pharmacy_dispensing_fee"].values[0]),
                       "rebate_amount": str(current_drug["rebate_amount"].values[0]),
                       "rebate_factor": str(current_drug["rebate_factor"].values[0]),
                       "unit_price": str(current_drug["unit_price"].values[0]),
                       "unit_price_before_rebate": str(current_drug["unit_price_before_rebate"].values[0]),
                       "zone": str(current_drug["zone"].values[0]),
                       "reward_share": str(current_drug["reward_share"].values[0]),
                       "retail_reward": str(current_drug["retail_reward"].values[0]),
                       "total_payment": str(current_drug["total_payment"].values[0]),
                       "penalty_factor": str(current_drug["penalty_factor"].values[0]),
                       "pa_flag": pa_flag,
                       "pa_form": str(current_drug["pa_form"].values[0]),
                       "pa_reason": str(current_drug["pa_reason"].values[0]),
                       "pa_override": str(current_drug["pa_override"].values[0]),
                       "alternative_drug_rewards": str(current_drug['alt_reward'].values[0]),
                       "locationSelected": autoerxobj.pharmacyinfoobj.location_selected,
                       "drug_class": autoerxobj.druginfoobj.drug_class,
                       "otc_indicator": autoerxobj.druginfoobj.otc_indicator,
                       "maintenance_drug_flag": autoerxobj.druginfoobj.maintenance_drug_flag,
                       "specialty_flag": autoerxobj.druginfoobj.specialty_flag,
                       "oop_accumulator_amount": str(current_drug["oop_accumulator_amount"].values[0]),
                       "deductible_accumulator_amount": str(current_drug["deductible_accumulator_amount"].values[0]),

                       }

        try:
            rpresc = requests.post(
                self.url, json={'query': mutation, 'variables': routevalues}, headers=autoerxobj.signinobj.headers)
            decoded = rpresc.json()
            print(decoded, 'routed prescription')
            prescid = ''
            prescid = decoded['data']['v2RoutePrescription']['prescription_id']
            prescid = str(prescid)

            self.dataprovider._update_intent(prescid, {
                                             'flipt_person_id': autoerxobj.userinfoobj.flipt_person_id,
                                             'rx_flipt_person_id': autoerxobj.userinfoobj.rx_flipt_person_id,
                                             'total_reward': total_reward,
                                             "locationSelected": autoerxobj.pharmacyinfoobj.location_selected,
                                             "claims_processor": str(current_drug["claim_processor"].values[0]),
                                             "copay_type": str(current_drug["copay_type"].values[0]),
                                             "price_type": str(current_drug["price_type"].values[0]),
                                             "calc_baseline_cost": str(autoerxobj.otherinfo['prescription']['baseline_price']),
                                             "calc_rewards": str(autoerxobj.otherinfo['prescription']['reward']),
                                             "calc_penalty": str(autoerxobj.otherinfo['prescription']['penalty']),
                                             "calc_total_payment": str(autoerxobj.otherinfo['prescription']['total_payment'])})
            if autoerxobj.pharmacyinfoobj.pharmacy_type != 'RETAIL':
                self.dataprovider._update_intent(prescid, {
                    'mo_contact_email': autoerxobj.userinfoobj.mo_contact_email,
                    'mo_contact_phone': autoerxobj.userinfoobj.mo_contact_phone,
                    'mo_shipto_location': autoerxobj.userinfoobj.mo_shipto_location})

        except Exception as e:
            print(e, 'route prescription')
            return ''

        return prescid
