import logging
from datetime import datetime

import requests

from app.utility.twilio_send_sms import SendSms


class Autoerx(object):
    def __init__(self, config, dataprovider, userinfoobj, pharmacyinfoobj, druginfoobj, signinobj, newprescobj,
                 pricecalcobj, routeprescobj, claimobj, user_info, domain_flag, override):

        self.claimobj = claimobj.claimobj
        self.config = config
        self.url = config.graphql_url
        self.user_info = user_info
        self.domain_flag = domain_flag
        self.dataprovider = dataprovider
        self.userinfoobj = userinfoobj
        self.pharmacyinfoobj = pharmacyinfoobj
        self.druginfoobj = druginfoobj
        self.signinobj = signinobj
        self.newprescobj = newprescobj
        self.pricecalcobj = pricecalcobj
        self.routeprescobj = routeprescobj
        self.exact_days_of_supply = ''
        self.rounded_days_of_supply = ''
        self.prescription_id = ''
        self.phone_number = []
        self.otherinfo = claimobj.otherinfo
        self.claimkey = claimobj.claimkey
        self.override = override
        self.log = logging.getLogger()

    def createIntent(self):

        self.log.debug('autoerx begin inside create_intent function')

        self.log.debug("initial attributes set")

        self.ndc = self.claimobj.ClaimRequest.claimsseg.product_id
        self.dispensed_quantity = self.claimobj.ClaimRequest.claimsseg.quantity_dispensed
        self.npi = self.claimobj.ClaimRequest.header.service_provider_id
        try:
            self.benefit_plan_name = self.user_info['benefit-plan-name']
            self.domain = self.user_info['domain']
        except Exception as _:
            pass

        self.log.debug("drug/pharmacy restriction check")
        s = datetime.now()
        '''

        pharmacy_check, drug_check = self.restrictionCheck(
            pharmacy_restriction_flag, drug_restriction_flag, self.ndc, self.npi, self.benefit_plan_name, self.domain)
        if pharmacy_check:
            return self.prepareResponse(
                'False', '', '12', 'Service provider is not covered by the plan')

        if drug_check:
            return self.prepareResponse(
                'False', '', '13', 'Plan does not cover this drug')
        '''

        self.log.debug("get User Info")
        s = datetime.now()

        if self.claimobj.ClaimRequest.patientseg.patient_id:
            self.userinfoobj = self.userinfoobj.setAttributes(
                self.user_info['user'], self.claimobj.ClaimRequest.patientseg.patient_id)
        else:
            self.userinfoobj = self.userinfoobj.setAttributes(
                self.user_info['user'], self.claimobj.ClaimRequest.insuranceseg.cardholder_id)

        self.log.debug('user info')

        self.log.debug("set days of supply")

        try:
            self.exact_days_of_supply = int(
                self.claimobj.ClaimRequest.claimsseg.days_supply)
            if self.exact_days_of_supply <= 30:
                self.rounded_days_of_supply = 'UP TO 30'
            elif self.exact_days_of_supply > 30 and self.exact_days_of_supply <= 60:
                self.rounded_days_of_supply = 'UP TO 60'
            elif self.exact_days_of_supply > 60 and self.exact_days_of_supply <= 90:
                self.rounded_days_of_supply = 'UP TO 90'
            else:
                self.exact_days_of_supply = 'OVER 90'
        except Exception as e:
            self.log.debug(e, 'autoerxcreation days of supply error')
            pass

        self.log.debug("get pharmacy info")
        s = datetime.now()

        self.pharmacyinfoobj = self.pharmacyinfoobj.setAttributes(self.npi)
        self.log.debug('pharmacy info')

        self.log.debug("get drug info")

        s = datetime.now()
        self.druginfoobj = self.druginfoobj.setAttributes(
            self.otherinfo['ndc_info'], self.dispensed_quantity, True, '')

        # self.druginfoobj = vars(self.druginfoobj)

        # if error_code:
        #     return self.prepareResponse(
        #         'False', '', error_code, err_message, None)
        self.log.debug('drug info')

        self.log.debug("sign in as patient/employee")
        s = datetime.now()
        self.signinobj = self.signinobj.getUserToken(self.userinfoobj.user_id)
        self.log.debug('sign in')
        self.log.debug("save Prescription in Basket")
        s = datetime.now()
        self.prescription_id = self.newprescobj.saveIntent(self)
        if self.prescription_id == '':
            return self.prepareResponse('False', '', '', 'Could not create new prescription', None)
        self.log.debug('save presc')

        self.log.debug("get user phone number")
        s = datetime.now()
        self.phone_number = self.userinfoobj.getCommunicationPhone(
            self.signinobj.headers, self.userinfoobj.flipt_person_id)
        self.userinfoobj.mo_contact_phone = self.phone_number
        self.log.debug('get phone no')

        '''

        self.log.debug(update user's basket in case of non retail pharmacy
        s = datetime.now()

        if self.pharmacyinfoobj.pharmacy_type != 'RETAIL':
            self.updateBasket()
            return self.prepareResponse('True', self.prescription_id, '', 'Script for Mail Order/Specialty in New Status')
        self.log.debug('update basket if mailorder/specialty')
        self.dataprovider._update_intent(self.prescription_id, {
                                         'preselected_pharmacy': self.pharmacyinfoobj.pharmacy, 'preselected_npi': self.pharmacyinfoobj.npi})

        '''
        auto_route_prescription = self.domain_flag['auto_route_prescription']
        if auto_route_prescription == 'N':
            return self.prepareResponse('False', self.prescription_id, '', 'Auto-route flag turned off', None)

        self.log.debug("get prices")
        s = datetime.now()

        self.getprices_result, pricelist = self.pricecalcobj.getPrices(self)
        if self.getprices_result != 'Success':
            return self.prepareResponse('False', '', '', self.getprices_result, None)
        self.log.debug('get prices')

        self.log.debug("route prescription")
        s = datetime.now()
        self.routing_result = self.routeprescobj.routeIntent(self, pricelist)
        if self.routing_result == '':
            return self.prepareResponse('False', '', '', 'Could not route prescription', None)
        self.log.debug('route presc')

        try:
            self.pricecalcobj.getSavings(pricelist, self)
            self.log.debug('calc savings')
        except Exception as err:
            self.log.debug('Calculate savings error')

        try:
            self.log.debug("send text for PA/autoeRx")
            self.sendFinalTextMessage(pricelist, self)
        except Exception as err:
            self.log.debug('Text message error')

        self.log.debug('send final response')
        return self.prepareResponse('True', self.prescription_id, '', '', pricelist)

    def restrictionCheck(self, pharmacy_restriction_flag, drug_restriction_flag, ndc, npi, benefit_plan_name, domain):

        self.log.debug(
            "In restriction check auto erx for pharmacy restriction")
        pharmacy_check = False
        drug_check = False

        if pharmacy_restriction_flag == 'Y':
            pharmacy_check, _ = self.dataprovider._get_rxplaninfo(
                {'npi': npi, 'plan_name': benefit_plan_name, 'domain': domain, 'plan_year': datetime.now()})
        if drug_restriction_flag == 'Y':
            drug_check = self.dataprovider._get_drugrestricted_info(
                ndc, benefit_plan_name, domain)

        self.log.debug("Finished restriction check")
        return pharmacy_check, drug_check

    def updateBasket(self):

        self.log.debug("Updating the basket using graphql")
        basketquery = """query {user {employee{ prescription_basket }}}"""
        basketid = requests.post(
            self.url, json={'query': basketquery}, headers=self.signinobj.headers)
        decoded = basketid.json()
        basketprescs = []
        try:
            basketprescs.extend(
                decoded['data']['user']['employee']['prescription_basket'])
            prescpresent = self.dataprovider._get_presc_info(
                self.userinfoobj.rx_flipt_person_id, basketprescs, self.druginfoobj.gpi)
        except Exception as noprescription:
            prescpresent = False
        if not prescpresent:
            basketprescs.append(self.prescription_id)
            variables = {"prescriptions_id": ",".join(
                x for x in basketprescs)}
            updatebasket = """mutation ($prescriptions_id: String!){ updateBasket(prescriptions_id: $prescriptions_id)"""
            basketid = requests.post(
                self.url, json={'query': updatebasket, 'variables': variables}, headers=self.signinobj.headers)
            decoded = basketid.json()

        message = self.pharmacyinfoobj.pharmacy_type+" Auto eRx is created for " + \
            self.druginfoobj.drug_name+". Review your basket to confirm pharmacy " + \
            self.pharmacyinfoobj.pharmacy + " and shipping address."

        if isinstance(self.phone_number, list):
            for phone in self.phone_number:
                sent, info = SendSms(self.config, message, phone).sendSMS()
        else:
            sent, info = SendSms(self.config, message,
                                 self.phone_number).sendSMS()

    def sendFinalTextMessage(self, pricelist, obj):
        self.log.debug("In  send final test message ")

        current_drug = pricelist.loc[pricelist['pharmacy_npi']
                                     == obj.pharmacyinfoobj.npi]
        message = ''
        if 'rejection_reason' in self.otherinfo['prescription'] and self.otherinfo['prescription']['rejection_reason'] == 'PA drug':
            message = "Your Prescription for " + obj.druginfoobj.drug_name + " received at " + obj.pharmacyinfoobj.pharmacy + \
                " requires Prior Authorization before it can be filled. Please contact Flipt Concierge (833-354-7879) to initiate approval."
        else:
            message = 'Your prescription for ' + obj.druginfoobj.drug_name + ' has been created at ' \
                      + obj.pharmacyinfoobj.pharmacy + ". Your co-pay=$" + "%.2f" % float(
                          obj.otherinfo['prescription']['employee_opc']) + ' and your reward=$' + "%.2f" % float(
                          current_drug["drug_reward"].values[0]) + ' for this prescription.'

        self.log.debug("Sending message to the patient")
        if isinstance(obj.phone_number, list):
            for phone in obj.phone_number:
                sent, info = SendSms(obj.config, message, phone).sendSMS()
        else:
            sent, info = SendSms(obj.config, message,
                                 obj.phone_number).sendSMS()

    def prepareResponse(self, status, prescription_id, errorcode, message, pricelist):
        finalpricing = {}

        if status == 'False':
            self.log.debug("Error occured in auto erx preparing response")
            # update rejection reason
            if self.claimobj.ClaimResponse.statusseg.transaction_response_status == 'P' or 'Prior Authorization' in self.otherinfo['rejectionreason']:
                pricelist, self.prescription_id = self.newprescobj.createPrescription(
                    self)
                status = 'True'
                prescription_id = self.prescription_id
                errorcode = ''
                message = ''
                finalpricing = pricelist
            self.dataprovider._update_intent(
                self.claimkey, {'autoerx_failure_reason': message})
        else:

            try:
                erxcosts = pricelist.loc[pricelist['pharmacy_npi']
                                         == self.pharmacyinfoobj.npi]
                finalpricing['employee_opc'] = erxcosts['employee_opc'].values[0]
                finalpricing['drug_cost'] = erxcosts['drug_price'].values[0]
                finalpricing['employer_cost'] = erxcosts['drug_employer_cost'].values[0]
            except Exception as e:
                self.log.debug('Pricing update error in autoerx response')

        return {'status': status,
                'prescription_id': prescription_id,
                'errorcode': errorcode,
                'message': message,
                'pricing': finalpricing}
