import base64
import logging

import requests


class SignIn:
    def __init__(self, config):
        self.url = config.graphql_url
        self.bot_user = config.BOTUSERID
        self.bot_password = config.BOTPWD
        self.log = logging.getLogger()

        self.headers = {}
        self.user_id = ''

    def getUserToken(self, userid):
        self.log.debug("Logging into graphql")
        #self.log.debug(f"User id : {userid}, url:{self.url}")
        self.user_id = userid
        try:
            mutation = """mutation {signIn(email: """+'"'+self.bot_user+'"' + \
                """, password: """+'"' + \
                self.bot_password + \
                '"' + """) {access_token}}"""
            signInrequest = requests.post(
                self.url, json={'query': mutation}, headers="")
            decoded = signInrequest.json()
            # self.log.debug(decoded, '-----', self.user_id)
            token = decoded['data']['signIn']['access_token']
            token = token+':'
            b64Val = base64.b64encode(bytes(token, 'utf-8'))
            # self.log.debug(1)
            header = "Basic "+str(b64Val).lstrip('b')
            headers = {'Authorization': header}
            self.user_id = '"'+userid+'"'
            self.log.debug("Get User token")
            query = """query {getUserToken(user_id: """+self.user_id+""")}"""
            tokenrequest = requests.post(
                self.url, json={'query': query}, headers=headers)
            # decoded is a dictionary to get the token value.
            decoded = tokenrequest.json()
            #self.log.debug(decoded, 'next')
            token = decoded['data']['getUserToken']
            token = token+':'
            b64Val = base64.b64encode(bytes(token, 'utf-8'))
            header = "Basic "+str(b64Val).lstrip('b')
            # self.log.debug(2)
            self.headers = {'Authorization': header}
        except Exception as e:
            self.log.debug(e, 'sign in')
            pass
        return self
