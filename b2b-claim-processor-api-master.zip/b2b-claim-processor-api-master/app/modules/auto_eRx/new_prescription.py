import requests
import json
from types import SimpleNamespace as Namespace
from datetime import datetime


class NewPrescription:

    def __init__(self, config, dataprovider):
        self.dataprovider = dataprovider
        self.url = config.graphql_url

    def saveIntent(self, autoerxobj):

        mutation = """mutation (
        $gpi: String!
        $dpa: String
        $drug: String!
        $form: String!
        $dosage: String!
        $quantity: String!
        $daysofsupply: String
        $locationSelected: String
        $location: String
        $zipCode: String
        $ddn_form: String
        $ddn_name: String
        $ddn_strength: String
        $strengths: String
        $dosage_strength: String
        $lm_strength: String
        $lm_form: String
        $lm_name: String
        $drug_name: String
        $brand_generic: String
        $ddid: String
        $drug_type: String
        $package_desc: String
        $pkg_desc_cd: String
        $package_qty: String
        $package_quantity: String
        $package_size: String
        $pkg_uom: String
        $lm_ndc: String
        $search_location: String
        $flipt_person_id: String
        $gppc: String
        $search_prescription_id: String
        $custom_quantity: Boolean
        $quantity_type: String
        $custom_qty: String
        $admin_flipt_person_id: String
        $rxcui: String
        $days_of_supply: String
        $equivalent_brand: String
        ) {
        savePrescription(
            gpi: $gpi
            drug: $drug
            form: $form
            dosage: $dosage
            lm_ndc: $lm_ndc
            quantity: $quantity
            dpa: $dpa
            locationSelected: $locationSelected
            location: $location
            zipCode: $zipCode
            ddn_form: $ddn_form
            ddn_name: $ddn_name
            ddn_strength: $ddn_strength
            strengths: $strengths
            dosage_strength: $dosage_strength
            lm_strength: $lm_strength
            lm_form: $lm_form
            lm_name: $lm_name
            drug_name: $drug_name
            brand_generic: $brand_generic
            ddid: $ddid
            drug_type: $drug_type
            package_desc: $package_desc
            pkg_desc_cd: $pkg_desc_cd
            package_qty: $package_qty
            package_quantity: $package_quantity
            package_size: $package_size
            pkg_uom: $pkg_uom
            daysofsupply: $daysofsupply
            search_location: $search_location
            flipt_person_id: $flipt_person_id
            gppc: $gppc
            search_prescription_id: $search_prescription_id
            custom_quantity: $custom_quantity
            quantity_type: $quantity_type
            custom_qty: $custom_qty
            admin_flipt_person_id: $admin_flipt_person_id
            rxcui:$rxcui
            days_of_supply: $days_of_supply
            equivalent_brand: $equivalent_brand
            ) {
                prescription_id
            }
            }
        """
        variables = {"gpi": autoerxobj.druginfoobj.gpi,
                     "dpa": autoerxobj.druginfoobj.pda,
                     "drug": autoerxobj.druginfoobj.drug_name,
                     "form": autoerxobj.druginfoobj.dosage,
                     "dosage": autoerxobj.druginfoobj.dosage,
                     "quantity": str(autoerxobj.druginfoobj.quantity),
                     "daysofsupply": autoerxobj.exact_days_of_supply,
                     "locationSelected": autoerxobj.pharmacyinfoobj.location_selected,
                     "zipCode": autoerxobj.pharmacyinfoobj.zipcode,
                     "ddn_form": autoerxobj.druginfoobj.ddn_form,
                     "ddn_name": autoerxobj.druginfoobj.ddn_name,
                     "ddn_strength": autoerxobj.druginfoobj.ddn_strength,
                     "strengths": autoerxobj.druginfoobj.strengths,
                     "dosage_strength": autoerxobj.druginfoobj.dosage_strength,
                     "lm_strength": autoerxobj.druginfoobj.lm_strength,
                     "lm_form": autoerxobj.druginfoobj.lm_form,
                     "lm_name": autoerxobj.druginfoobj.lm_name,
                     "drug_name": autoerxobj.druginfoobj.drug_name,
                     "brand_generic": autoerxobj.druginfoobj.brand_generic,
                     "ddid": autoerxobj.druginfoobj.ddid,
                     "drug_type": autoerxobj.druginfoobj.drug_type,
                     "package_desc": autoerxobj.druginfoobj.package_desc,
                     "pkg_desc_cd": autoerxobj.druginfoobj.pkg_desc_cd,
                     "package_qty": str(
                         autoerxobj.druginfoobj.package_qty),
                     "package_quantity": str(autoerxobj.druginfoobj.package_quantity),
                     "package_size": str(autoerxobj.druginfoobj.package_size),
                     "pkg_uom": autoerxobj.druginfoobj.pkg_uom,
                     "lm_ndc": 'nan',
                     "search_location": autoerxobj.pharmacyinfoobj.search_location,
                     "flipt_person_id": autoerxobj.userinfoobj.flipt_person_id,
                     "gppc": autoerxobj.druginfoobj.gppc,
                     "custom_quantity": autoerxobj.druginfoobj.custom_quantity,
                     "quantity_type": autoerxobj.druginfoobj.quantity_type,
                     "custom_qty": autoerxobj.druginfoobj.custom_qty,
                     "admin_flipt_person_id": "1001598",
                     "days_of_supply": autoerxobj.rounded_days_of_supply,
                     "location": autoerxobj.pharmacyinfoobj.location,
                     "equivalent_brand": ''}

        try:

            newprescription = requests.post(
                self.url, json={'query': mutation, 'variables': variables}, headers=autoerxobj.signinobj.headers)
            decoded = newprescription.json()

            prescriptionid = decoded['data']['savePrescription']['prescription_id']
            print(decoded, 'new prescription')
            prescriptionid = str(prescriptionid)

            update_data = {'domain': autoerxobj.userinfoobj.domain_name,
                           'flipt_person_id': autoerxobj.userinfoobj.flipt_person_id,
                           'rx_flipt_person_id': autoerxobj.userinfoobj.rx_flipt_person_id,
                           'auth_id': autoerxobj.claimobj.auth_id,
                           'dosage_image': autoerxobj.druginfoobj.dosage_image,
                           "application": "Auto eRx"
                           }

            self.dataprovider._update_intent(prescriptionid, update_data)
            return prescriptionid

        except Exception as e:
            print(e, 'new prescription')
            return ''

    def createPrescription(self, autoerxobj):

        if not autoerxobj.prescription_id:
            autoerxobj.prescription_id = self.dataprovider.getPrescriptionCounter()
        rx_status = 'Filled'
        pa_flag = 'N'
        pa_status = ''
        filled_date = datetime.now().isoformat()
        if 'Prior Authorization' in autoerxobj.claimobj.ClaimResponse.messageseg.message:
            rx_status = 'PA'
            pa_flag = 'Y'
            filled_date = ''
            pa_status = 'PA Initiated'
        if 'drug_cost' not in autoerxobj.otherinfo['prescription']:
            autoerxobj.otherinfo['prescription']['drug_cost'] = '0'
            autoerxobj.otherinfo['prescription']['employer_cost'] = '0'
        patientid = autoerxobj.claimobj.ClaimRequest.insuranceseg.cardholder_id
        if autoerxobj.claimobj.ClaimRequest.patientseg.patient_id:
            patientid = autoerxobj.claimobj.ClaimRequest.patientseg.patient_id
        if 'daysofsupply' in autoerxobj.otherinfo['prescription']:
            daysofsupply = autoerxobj.otherinfo['prescription']['daysofsupply']
        else:
            daysofsupply = autoerxobj.claimobj.ClaimRequest.claimsseg.days_supply
        deductible_accumulator_amount = 0
        oop_accumulator_amount = 0
        if autoerxobj.otherinfo['prescription'].get('deductible_met', '') == False and autoerxobj.otherinfo['prescription']['formularyinfo'].get('deductible_accumulator_flag', '') == 'Y':
            deductible_accumulator_amount = autoerxobj.otherinfo['prescription'].get(
                'original_employee_opc')
        if autoerxobj.otherinfo['prescription'].get('outofpocket_met', '') == False and autoerxobj.otherinfo['prescription']['formularyinfo'].get('oop_accumulator_flag', '') == 'Y':
            oop_accumulator_amount = autoerxobj.otherinfo['prescription'].get(
                'original_employee_opc')

        prescriptiondata = {"admin_flipt_person_id": "1001598",
                            "alternative_drug_rewards": "None",
                            "application": "Auto eRx",
                            "auth_id": autoerxobj.claimobj.auth_id,
                            "baseline_cost": "0",
                            "bin": autoerxobj.otherinfo['prescription'].get('bin'),
                            "chaincode": "",
                            "create_date": datetime.now().isoformat(),
                            "created_by": "1001598",
                            "daysofsupply": daysofsupply,
                            "deductible_remaining": "0",
                            "dispensed_qty": autoerxobj.claimobj.ClaimRequest.claimsseg.quantity_dispensed,
                            "domain": autoerxobj.userinfoobj.domain_name,
                            "drug_class_exclusion_flag": "N",
                            "drug_copay": autoerxobj.otherinfo['prescription'].get('copay'),
                            "drug_cost": autoerxobj.otherinfo['prescription']['drug_cost'],
                            "drug_cost_before_rebate": "0",
                            "drug_deductible_exempt": "false",
                            "drug_name_exclusion_flag": "N",
                            "drug_penalty": "0",
                            "employee_opc": autoerxobj.otherinfo['prescription']['employee_opc'],
                            "employer_cost": autoerxobj.otherinfo['prescription']['employer_cost'],
                            "filled_date": filled_date,
                            "flipt_person_id": autoerxobj.userinfoobj.flipt_person_id,
                            "group_id": "",
                            "member_id": patientid,
                            "npi": autoerxobj.pharmacyinfoobj.npi,
                            "out_of_pocket_remaining": "0",
                            "pa_flag": pa_flag,
                            "pa_form": "",
                            "pa_override": "N",
                            "pa_reason": "",
                            "pa_status": pa_status,
                            "payment_option": autoerxobj.otherinfo['prescription']['payment_option'],
                            "pbm_estimated_cost": "0",
                            "pbm_price": "0",
                            "pcn": autoerxobj.otherinfo['prescription'].get('pcn'),
                            "penalty_factor": "0",
                            "pharmacy": autoerxobj.pharmacyinfoobj.pharmacy,
                            "pharmacy_discount": autoerxobj.otherinfo['prescription']['pharmacy_discount'],
                            "pharmacy_dispensing_fee": autoerxobj.otherinfo['prescription']['pharmacy_dispensing_fee'],
                            "pharmacy_exclusion_flag": "N",
                            "prescription_basket_id": autoerxobj.prescription_id,
                            "prescription_id": autoerxobj.prescription_id,
                            "rebate_amount": "0",
                            "rebate_factor": "1.0",
                            "retail_reward": "0",
                            "reward_percentage": "50",
                            "reward_share": "50",
                            "rewards": "0",
                            "routed_date": datetime.now().isoformat(),
                            "rx_flipt_person_id": autoerxobj.userinfoobj.rx_flipt_person_id,
                            "rx_number": autoerxobj.claimobj.ClaimRequest.claimsseg.prescription_reference_number,
                            "rx_status": rx_status,
                            "saved_date": datetime.now().isoformat(),
                            "total_payment": "0",
                            "total_reward": "0",
                            "copay_type": autoerxobj.otherinfo['prescription']['formularyinfo']['copay_type'],
                            "price_type": autoerxobj.otherinfo['prescription']['price_type'],
                            "type": "prescription",
                            "unit_price": str(autoerxobj.otherinfo['prescription']['unit_price']),
                            "unit_price_before_rebate": str(autoerxobj.otherinfo['prescription']['unit_price_before_rebate']),
                            "update_date": datetime.now().isoformat(),
                            "updated_by": autoerxobj.userinfoobj.flipt_person_id,
                            "zone": "",
                            "gpi": autoerxobj.druginfoobj.gpi,
                            "dpa": autoerxobj.druginfoobj.pda,
                            "drug": autoerxobj.druginfoobj.drug_name,
                            "form": autoerxobj.druginfoobj.dosage,
                            "dosage": autoerxobj.druginfoobj.dosage,
                            "quantity": str(autoerxobj.druginfoobj.quantity),
                            "daysofsupply": autoerxobj.exact_days_of_supply,
                            "locationSelected": autoerxobj.pharmacyinfoobj.location_selected,
                            "zipCode": autoerxobj.pharmacyinfoobj.zipcode,
                            "ddn_form": autoerxobj.druginfoobj.ddn_form,
                            "ddn_name": autoerxobj.druginfoobj.ddn_name,
                            "ddn_strength": autoerxobj.druginfoobj.ddn_strength,
                            "strengths": autoerxobj.druginfoobj.strengths,
                            "dosage_strength": autoerxobj.druginfoobj.dosage_strength,
                            "lm_strength": autoerxobj.druginfoobj.lm_strength,
                            "lm_form": autoerxobj.druginfoobj.lm_form,
                            "lm_name": autoerxobj.druginfoobj.lm_name,
                            "drug_name": autoerxobj.druginfoobj.drug_name,
                            "brand_generic": autoerxobj.druginfoobj.brand_generic,
                            "ddid": autoerxobj.druginfoobj.ddid,
                            "drug_type": autoerxobj.druginfoobj.drug_type,
                            "package_desc": autoerxobj.druginfoobj.package_desc,
                            "pkg_desc_cd": autoerxobj.druginfoobj.pkg_desc_cd,
                            "package_qty": str(
                                autoerxobj.druginfoobj.package_qty),
                            "package_quantity": str(autoerxobj.druginfoobj.package_quantity),
                            "package_size": str(autoerxobj.druginfoobj.package_size),
                            "pkg_uom": autoerxobj.druginfoobj.pkg_uom,
                            "lm_ndc": 'nan',
                            "search_location": autoerxobj.pharmacyinfoobj.search_location,
                            "flipt_person_id": autoerxobj.userinfoobj.flipt_person_id,
                            "gppc": autoerxobj.druginfoobj.gppc,
                            "custom_quantity": autoerxobj.druginfoobj.custom_quantity,
                            "quantity_type": autoerxobj.druginfoobj.quantity_type,
                            "custom_qty": autoerxobj.druginfoobj.custom_qty,
                            "days_of_supply": autoerxobj.rounded_days_of_supply,
                            "location": autoerxobj.pharmacyinfoobj.location,
                            "equivalent_brand": '',
                            "deductible_accumulator_amount": deductible_accumulator_amount,
                            "oop_accumulator_amount": oop_accumulator_amount
                            }
        if autoerxobj.pharmacyinfoobj.pharmacy_type != 'RETAIL':
            prescriptiondata.update({'mo_contact_email': autoerxobj.userinfoobj.mo_contact_email,
                                     'mo_contact_phone': autoerxobj.userinfoobj.mo_contact_phone,
                                     'mo_shipto_location': autoerxobj.userinfoobj.mo_shipto_location})

        self.dataprovider._update_intent(
            autoerxobj.prescription_id, prescriptiondata)
        pricing = {'employee_opc': prescriptiondata['employee_opc'],
                   'drug_cost': prescriptiondata['drug_cost'], 'employer_cost': prescriptiondata['employer_cost']}
        return pricing, autoerxobj.prescription_id
