class PharmacyInfo:

    def __init__(self, dataprovider):
        self.npi = ''
        self.pharmacy = ''
        self.pharmacy_type = ''
        self.zipcode = ''
        self.search_location = ''
        self.location_selected = ''
        self.location = ''
        self.cp_pharmacy_info = []
        self.dataprovider = dataprovider

    def setAttributes(self, npi):

        self.npi = npi
        pharma_info = self.dataprovider._get_pharmacy_info(self.npi)
        try:
            self.pharmacy = pharma_info['wl_name']
            self.pharmacy_type = pharma_info['pharmacytype']
            self.zipcode = pharma_info['pharmacyzip1']
            self.search_location = pharma_info['geo_lat'] + \
                ', '+pharma_info['geo_lng']
            self.location_selected = 'Current Location'
            self.location = pharma_info['pharmacyaddress1']
            self.cp_pharmacy_info = pharma_info['cp_pharmacy_info']
            self.pharmacy_chain_code = self.cp_pharmacy_info[0]['chaincode']
            self.pharmacy_name = pharma_info['pharmacyname']
            if len(self.zipcode) > 5:
                self.zipcode = self.zipcode.zfill(9)
            else:
                self.zipcode = self.zipcode.zfill(5)
        except Exception as _:
            pass

        return self
