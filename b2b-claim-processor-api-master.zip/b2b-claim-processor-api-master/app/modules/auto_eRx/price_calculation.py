import logging
from datetime import datetime

import dateutil.parser as parser
import pandas as pd
import requests

from app.utility.twilio_send_sms import SendSms


class PriceCalculation:
    def __init__(self, config, dataprovider):
        self.config = config
        self.url = config.graphql_url
        self.dataprovider = dataprovider
        self.flipt_phone = config.RESPONSE_PHONENUMBER
        self.log = logging.getLogger()

    def getPrices(self, autoerxobj):
        self.log.debug("Inside price calculation graphql")
        if autoerxobj.otherinfo['ndc_info']['ndc'] == '00000000000':
            return self.getPricesCompound(autoerxobj)

        rewardforcurrentyear = self.dataprovider._get_reward_details({
            'flipt_person_id': autoerxobj.userinfoobj.rx_flipt_person_id,
            'year': datetime.now().year})
        domain_price_source = set(autoerxobj.domain_flag['price_source'])
        pharmacy_price_source = set(
            [x['claim_processor'] for x in autoerxobj.pharmacyinfoobj.cp_pharmacy_info])
        price_source = list(
            domain_price_source.intersection(pharmacy_price_source))

        #alt_reward = self.getAlternativeDrugRewards(autoerxobj)
        #print(alt_reward)

        mutation = """mutation (
            $term: String,
            $ndc: String,
            $address: String!,
            $pda: String!,
            $gpi: String!,
            $form: String!,
            $package_size: String!,
            $package_quantity: String!,
            $zip_code: String!,
            $brand_generic: String,
            $days_of_supply: String,
            $dosage_strength: String,
            $flipt_person_id: String!,
            $drug_name: String,
            $package_qty: String,
            $dosage: String,
            $gppc: String,
            $custom_quantity: Boolean,
            $specialty_flag: String,
            $price_source: [String],
            $enable_smart_rewards: String!,
            $user_flipt_person_id: String!,
            $mo_dayssupply: String!,
            $comfort_zone_pharmacies: String!,
            $economy_zone_pharmacies: String!,
            $saver_zone_factor: String!,
            $pbm_price_display: String!,
            $use_pbm_price_for_baseline: String!,
            $use_observed_pbm_price: String!,
            $domain: String!,
            $pbm_provider: String!,
            $generic_discount: String!,
            $brand_discount: String!,
            $parent_id: String,
            $benefit_plan_name: String!,
            $coverage_tier_name: String!,
            $rewards_earned_current_year: Float!,
            $employer_penalty_factor: String!,
            $max_reward_per_year: String!,
            $max_reward_per_rx: String!,
            $rewards_opc_multiplier: String!,
            $rewards_baseline_multiplier: String!,
            $rewards_fixed_amount: String!,
            $npi: String,
            $ddid: String,
            $drug_class: String,
            $pa_override_threshold: String,
            $quantity_restriction_buffer: String,
            $reward_share: String)
            {
            getPrices(
                term: $term,
                ndc: $ndc,
                address: $address,
                pda: $pda,
                gpi: $gpi,
                form: $form,
                package_size: $package_size,
                package_quantity: $package_quantity,
                zip_code: $zip_code,
                brand_generic: $brand_generic,
                days_of_supply: $days_of_supply,
                dosage_strength: $dosage_strength,
                flipt_person_id: $flipt_person_id,
                drug_name: $drug_name,
                package_qty: $package_qty,
                dosage: $dosage,
                gppc: $gppc,
                custom_quantity: $custom_quantity,
                specialty_flag: $specialty_flag,
                price_source: $price_source,
                enable_smart_rewards: $enable_smart_rewards,
                user_flipt_person_id: $user_flipt_person_id,
                mo_dayssupply: $mo_dayssupply,
                comfort_zone_pharmacies: $comfort_zone_pharmacies,
                economy_zone_pharmacies: $economy_zone_pharmacies,
                saver_zone_factor: $saver_zone_factor,
                pbm_price_display: $pbm_price_display,
                use_pbm_price_for_baseline: $use_pbm_price_for_baseline,
                use_observed_pbm_price: $use_observed_pbm_price,
                domain: $domain, pbm_provider: $pbm_provider,
                generic_discount: $generic_discount,
                brand_discount: $brand_discount,
                parent_id: $parent_id,
                benefit_plan_name: $benefit_plan_name,
                coverage_tier_name: $coverage_tier_name,
                employer_penalty_factor: $employer_penalty_factor,
                max_reward_per_year: $max_reward_per_year,
                rewards_earned_current_year: $rewards_earned_current_year
                max_reward_per_rx: $max_reward_per_rx,
                rewards_opc_multiplier: $rewards_opc_multiplier,
                rewards_baseline_multiplier: $rewards_baseline_multiplier,
                rewards_fixed_amount: $rewards_fixed_amount,
                npi: $npi,
                ddid: $ddid,
                drug_class: $drug_class,
                pa_override_threshold: $pa_override_threshold,
                quantity_restriction_buffer: $quantity_restriction_buffer,
                reward_share: $reward_share)
                {
                pharmacy_name
                pharmacy_city
                pharmacy_address
                pharmacy_zip_code
                pharmacy_npi
                pharmacy_open_hour
                pharmacy_close_hour
                drug_price
                drug_baseline_price
                drug_copay
                drug_employer_cost
                drug_out_of_pocket
                drug_reward
                drug_distance
                drug_distance_value
                drug_duration
                drug_duration_value
                drug_deductible_exempt
                provider_id
                provider_name
                pbm_price
                pbm_estimated_cost
                deductible_remaining
                reward_percentage
                out_of_pocket_remaining
                drug_penalty
                unit_price_before_rebate
                unit_price
                rebate_factor
                pharmacy_discount
                pharmacy_dispensing_fee
                drug_cost_before_rebate
                rebate_amount
                chaincode
                zone
                pa_flag
                pa_reason
                pa_form
                pa_override
                total_payment
                retail_reward
                reward_share
                employee_opc
                penalty_factor
                alternate_reward
                copay_type
                price_type
                claim_processor
                oop_accumulator_amount
                deductible_accumulator_amount
                }
            }

        """

        variables = {"term": "",
                     "ndc": autoerxobj.otherinfo['ndc_info']['ndc'],
                     "address": autoerxobj.pharmacyinfoobj.location,
                     "pda": autoerxobj.druginfoobj.pda,
                     "gpi": autoerxobj.druginfoobj.gpi,
                     "form": autoerxobj.druginfoobj.dosage,
                     "package_size": autoerxobj.druginfoobj.package_size,
                     "package_quantity": autoerxobj.druginfoobj.package_quantity,
                     "zip_code": autoerxobj.pharmacyinfoobj.zipcode[:5],
                     "brand_generic": autoerxobj.druginfoobj.brand_generic,
                     "days_of_supply": str(int(autoerxobj.claimobj.ClaimRequest.claimsseg.days_supply)),
                     "dosage_strength": autoerxobj.druginfoobj.dosage_strength,
                     "flipt_person_id": autoerxobj.userinfoobj.rx_flipt_person_id,
                     "drug_name": autoerxobj.druginfoobj.drug_name,
                     "package_qty": autoerxobj.druginfoobj.package_qty,
                     "dosage": autoerxobj.druginfoobj.dosage,
                     "gppc": autoerxobj.druginfoobj.gppc,
                     "custom_quantity": bool(autoerxobj.druginfoobj.custom_quantity),
                     "specialty_flag": autoerxobj.druginfoobj.specialty_flag,
                     "price_source": price_source,
                     "enable_smart_rewards": autoerxobj.domain_flag['enable_smart_rewards'],
                     "user_flipt_person_id": autoerxobj.userinfoobj.flipt_person_id,
                     "mo_dayssupply": autoerxobj.domain_flag['mo_dayssupply'],
                     "comfort_zone_pharmacies": autoerxobj.domain_flag['comfort_zone_pharmacies'],
                     "economy_zone_pharmacies": autoerxobj.domain_flag['economy_zone_pharmacies'],
                     "saver_zone_factor": autoerxobj.domain_flag['saver_zone_factor'],
                     "pbm_price_display": autoerxobj.domain_flag['pbm_price_display'],
                     "use_pbm_price_for_baseline": autoerxobj.domain_flag['use_pbm_price_for_baseline'],
                     "use_observed_pbm_price": autoerxobj.domain_flag['use_observed_pbm_price'],
                     "domain": autoerxobj.userinfoobj.domain_name,
                     "pbm_provider": autoerxobj.domain_flag['pbm_provider'],
                     "generic_discount": autoerxobj.domain_flag['generic_discount'],
                     "brand_discount": autoerxobj.domain_flag['brand_discount'],
                     "parent_id": "",
                     "benefit_plan_name": autoerxobj.userinfoobj.benefit_plan_name,
                     "coverage_tier_name": autoerxobj.userinfoobj.coverage_tier_name,
                     "employer_penalty_factor": autoerxobj.domain_flag['employer_penalty_factor'],
                     "max_reward_per_year": autoerxobj.domain_flag['max_reward_per_year'],
                     "max_reward_per_rx": autoerxobj.domain_flag['max_reward_per_rx'],
                     "rewards_opc_multiplier": autoerxobj.domain_flag['rewards_opc_multiplier'],
                     "rewards_baseline_multiplier": autoerxobj.domain_flag['rewards_baseline_multiplier'],
                     "rewards_fixed_amount": autoerxobj.domain_flag['rewards_fixed_amount'],
                     "npi": autoerxobj.pharmacyinfoobj.npi,
                     "rewards_earned_current_year": rewardforcurrentyear,
                     "ddid": autoerxobj.druginfoobj.ddid,
                     "drug_class": autoerxobj.druginfoobj.drug_class,
                     "pa_override_threshold": autoerxobj.domain_flag['pa_override_threshold'],
                     "quantity_restriction_buffer": autoerxobj.domain_flag['quantity_restriction_buffer'],
                     "reward_share": autoerxobj.domain_flag['reward_share'],
                     "copay_type": autoerxobj.otherinfo['prescription']['copay_type']}
        self.log.debug("sending mutation for getprices")
        try:
            self.log.debug("Trying to post for graphql")
            drugprice = requests.post(
                self.url, json={'query': mutation, 'variables': variables}, headers=autoerxobj.signinobj.headers)
            decoded = drugprice.json()
            prices = decoded['data']['getPrices']
            pricelist = pd.DataFrame()
            for x in prices:
                employee_opc = x['drug_out_of_pocket']

                try:
                    if int(employee_opc) == 0:
                        employee_opc = x['drug_copay']
                except Exception as _:
                    pass
                pricelist = pricelist.append({'pharmacy_name': x['pharmacy_name'],
                                              'pharmacy_city': x['pharmacy_city'],
                                              'pharmacy_address': x['pharmacy_address'],
                                              'pharmacy_zip_code': x['pharmacy_zip_code'],
                                              'pharmacy_npi': x['pharmacy_npi'],
                                              'drug_price': x['drug_price'],
                                              'drug_baseline_price': x['drug_baseline_price'],
                                              'drug_copay': x['drug_copay'],
                                              'drug_employer_cost': x['drug_employer_cost'],
                                              'drug_out_of_pocket': x['drug_out_of_pocket'],
                                              'drug_reward': x['drug_reward'],
                                              'drug_distance': x['drug_distance'],
                                              'drug_duration': x['drug_duration'],
                                              'drug_duration_value': x['drug_duration_value'],
                                              'drug_deductible_exempt': x['drug_deductible_exempt'],
                                              'provider_id': x['provider_id'],
                                              'provider_name': x['provider_name'],
                                              'pbm_price': x['pbm_price'],
                                              'pbm_estimated_cost': x['pbm_estimated_cost'],
                                              'deductible_remaining': x['deductible_remaining'],
                                              'reward_percentage': x['reward_percentage'],
                                              'out_of_pocket_remaining': x['out_of_pocket_remaining'],
                                              'drug_penalty': x['drug_penalty'],
                                              'unit_price_before_rebate': x['unit_price_before_rebate'],
                                              'unit_price': x['unit_price'],
                                              'rebate_factor': x['rebate_factor'],
                                              'pharmacy_discount': x['pharmacy_discount'],
                                              'pharmacy_dispensing_fee': x['pharmacy_dispensing_fee'],
                                              'drug_cost_before_rebate': x['drug_cost_before_rebate'],
                                              'rebate_amount': x['rebate_amount'],
                                              'chaincode': x['chaincode'],
                                              'zone': x['zone'],
                                              'pa_flag': x['pa_flag'],
                                              'pa_reason': x['pa_reason'],
                                              'pa_form': x['pa_form'],
                                              'total_payment': x['total_payment'],
                                              'retail_reward': x['retail_reward'],
                                              'reward_share': x['reward_share'],
                                              'penalty_factor': x['penalty_factor'],
                                              'employee_opc': employee_opc,
                                              'pa_override': x['pa_override'],
                                              'alt_reward': x['alternate_reward'],
                                              'claim_processor': x['claim_processor'],
                                              'copay_type': x['copay_type'],
                                              'price_type': x['price_type'],
                                              'oop_accumulator_amount': x['oop_accumulator_amount'],
                                              'deductible_accumulator_amount': x['deductible_accumulator_amount'],
                                              }, ignore_index=True)

            if pricelist.empty or len(pricelist) == 0:
                self.log.debug("No price found")
                return 'No Price Found', None

            if autoerxobj.pharmacyinfoobj.npi not in list(pricelist['pharmacy_npi']):
                self.log.debug("Price for Pharmacy not found")
                return 'Price for Pharmacy not found', None
            #print(pricelist)

            return 'Success', pricelist
        except Exception as e:
            print(e, 'get prices error')
            self.log.debug("get prices error")
            return 'Get prices Error', None

    def getPricesCompound(self, autoerxobj):
        self.log.debug("Calculating prices for compound drugs")
        pricelist = pd.DataFrame()

        pricelist = pricelist.append({'pharmacy_name': '',
                                      'pharmacy_city': '',
                                      'pharmacy_address': '',
                                      'pharmacy_zip_code': '',
                                      'pharmacy_npi': autoerxobj.claimobj.ClaimRequest.header.service_provider_id,
                                      'drug_price': autoerxobj.otherinfo['prescription']['drug_cost'],
                                      'drug_baseline_price': '0',
                                      'drug_copay': autoerxobj.otherinfo['prescription']['copay'],
                                      'drug_employer_cost': autoerxobj.otherinfo['prescription']['employer_cost'],
                                      'drug_out_of_pocket': autoerxobj.otherinfo['prescription']['employee_opc'],
                                      'drug_reward': '0',
                                      'drug_distance': '0',
                                      'drug_duration': '',
                                      'drug_duration_value': '',
                                      'drug_deductible_exempt': autoerxobj.otherinfo['prescription']['drug_deductible_exempt'],
                                      'provider_id': '',
                                      'provider_name': '',
                                      'pbm_price': '0',
                                      'pbm_estimated_cost': '0',
                                      'deductible_remaining': autoerxobj.otherinfo['prescription']['deductible_remaining'],
                                      'reward_percentage': '',
                                      'out_of_pocket_remaining': autoerxobj.otherinfo['prescription']['opc_remaining'],
                                      'drug_penalty': '0',
                                      'unit_price_before_rebate': autoerxobj.otherinfo['prescription']['unit_price'],
                                      'unit_price': autoerxobj.otherinfo['prescription']['unit_price'],
                                      'rebate_factor': '0',
                                      'pharmacy_discount': autoerxobj.otherinfo['prescription']['pharmacy_discount'],
                                      'pharmacy_dispensing_fee': autoerxobj.otherinfo['prescription']['pharmacy_dispensing_fee'],
                                      'drug_cost_before_rebate': autoerxobj.otherinfo['prescription']['drug_cost'],
                                      'rebate_amount': '0',
                                      'chaincode': '',
                                      'zone': '',
                                      'pa_flag': 'Y',
                                      'pa_reason': '',
                                      'pa_form': '',
                                      'total_payment': '0',
                                      'retail_reward': '0',
                                      'reward_share': '0',
                                      'penalty_factor': '0',
                                      'employee_opc': autoerxobj.otherinfo['prescription']['employee_opc'],
                                      'pa_override': 'N',
                                      'alt_reward': '0',
                                      'total_reward': '0'}, ignore_index=True)
        self.log.debug("Finished calculating price for compound drugs")

        return 'Success', pricelist

    def getSavings(self, pricelist, autoerxobj):

        self.log.debug("Calculating savings in getsavings")
        if pricelist.empty or len(pricelist) < 2:
            return

        pricelist['drug_out_of_pocket'] = pricelist['drug_out_of_pocket'].apply(
            lambda x: float(x))

        current_drug = pricelist.loc[pricelist['pharmacy_npi']
                                     == autoerxobj.pharmacyinfoobj.npi]
        all_other_drugs = pricelist.loc[(pricelist['pharmacy_npi']
                                         != autoerxobj.pharmacyinfoobj.npi) & (pricelist['drug_distance'] != 'Mail Delivery')]

        new_savings = 0
        try:
            lowest_price_series = all_other_drugs.loc[all_other_drugs.drug_out_of_pocket.idxmin(
            )]
            lowest_price = lowest_price_series.drug_out_of_pocket
            new_savings = float(current_drug.drug_out_of_pocket).__round__(
            ) - float(lowest_price).__round__()
        except Exception as _:
            pass
        min_savings = autoerxobj.domain_flag['min_split_pharmacy_savings']

        phone = autoerxobj.phone_number
        time_sent = datetime.now().isoformat()
        savings_send_result = False
        if new_savings >= int(min_savings):

            lowest_price_series['drug_distance'] = lowest_price_series['drug_distance'].replace(
                'mi', '').strip()

            message = 'Your prescription for {} was received at {} with a due of ${:.2f}. Flipt found {} with ${:.2f}' \
                      ' savings {} miles away. Reply Y to transfer your Rx and save ${:.2f}.'.format(
                          str(autoerxobj.druginfoobj.drug_name),
                          str(current_drug['pharmacy_name'].values[0]),
                          float(current_drug['drug_out_of_pocket'].values[0]),
                          str(lowest_price_series['pharmacy_name']),
                          float(new_savings),
                          str(round(
                              float(lowest_price_series['drug_distance']), 3)),
                          float(new_savings))

            if isinstance(phone, list):
                for ph in phone:
                    sent, info = SendSms(self.config, message, phone).sendSMS()
            else:
                sent, info = SendSms(self.config, message, phone).sendSMS()

            if phone is None:
                phone = ''

            notfication_result = self.dataprovider._get_notification_log(
                {'flipt_person_id': autoerxobj.userinfoobj.flipt_person_id, 'phone': phone})

            notifrec = {}

            for row in notfication_result:
                if savings_send_result:
                    self.dataprovider._update_intent(
                        str(row['id']), {'status': 'Inactive'})

                time_diff = (parser.parse(time_sent) -
                             parser.parse(row['time_message_sent'])).days

                if time_diff >= 1 and row['status'] == 'Active':
                    self.dataprovider._update_intent(
                        str(row['id']), {'status': 'Inactive'})

            notifrec['type'] = "notification_log"
            notifrec['rx_flipt_person_id'] = autoerxobj.userinfoobj.rx_flipt_person_id
            notifrec['flipt_person_id'] = autoerxobj.userinfoobj.flipt_person_id
            notifrec['phone_number'] = '+1' + phone
            notifrec['prescription_id'] = autoerxobj.prescription_id
            notifrec['notification_type'] = 'autoerx'
            notifrec['status'] = 'Active'
            notifrec['result'] = sent.lower()
            notifrec['message'] = message
            notifrec['response'] = ''
            notifrec['time_message_sent'] = time_sent
            notifrec['time_reponse_sent'] = ''
            notifrec['create_date'] = datetime.now().isoformat()
            notifrec['awaiting_response'] = 'Y'

            self.dataprovider._save_data(notifrec)
            self.log.debug("Finished calculating savings")

    def getAlternativeDrugRewards(self, autoerxobj):

        self.log.debug("Trying to find the alternative drug rewards")
        alternative_drug_rewards = "0"
        rx_history_result = self.dataprovider._get_rx_history_info({
            'gpi': autoerxobj.druginfoobj.gpi,
            'rx_flipt_person_id': autoerxobj.userinfoobj.rx_flipt_person_id,
            'drug_name': autoerxobj.druginfoobj.drug_name,
            'alternate_effective_date': autoerxobj.domain_flag['alternate_effective_date']})
        for rxrow in rx_history_result:
            alt_drug_result = self.dataprovider._get_drug_alternative_info({
                'gpi': autoerxobj.druginfoobj.gpi,
                'drug_name': autoerxobj.druginfoobj.drug_name})
            try:
                alternative_drug_rewards = alt_drug_result * float(
                    autoerxobj.druginfoobj.package_size) * float(autoerxobj.druginfoobj.package_quantity)
            except Exception as e1:
                print(e1)
        self.log.debug("Finished checking alternative rewards")
        return str(alternative_drug_rewards)
