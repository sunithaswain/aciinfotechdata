import pandas as pd


class DrugInfo:
    def __init__(self, dataprovider):

        self.dataprovider = dataprovider
        self.ndc_info = ''
        self.dispensed_quantity = ''
        self.gpi = ''
        self.drug_name = ''
        self.gppc = ''
        self.brand_generic = ''
        self.ddid = ''
        self.dosage = ''
        self.otc_indicator = ''
        self.pda = ''
        self.custom_qty = ''
        self.custom_quantity = False
        self.dosage_strength = ''
        self.package_desc = ''
        self.package_qty = ''
        self.package_quantity = '1'
        self.package_size = '1'
        self.pkg_desc_cd = ''
        self.pkg_uom = ''
        self.quantity_type = ''
        self.dosage_image = ''
        self.quantity = '1'
        self.specialty_flag = ''
        self.strengths = ''
        self.maintenance_drug_flag = ''
        self.drug_class = ''
        self.ddn_form = ''
        self.ddn_name = ''
        self.ddn_strength = ''
        self.lm_strength = ''
        self.lm_form = ''
        self.lm_name = ''
        self.drug_type = ''
        self.is_otc_inclusion = False
        self.status = 'active'

    def setAttributes(self, ndc_info, dispensedquantity, splitquantity, drug_info):
        self.ndc_info = ndc_info
        try:
            self.dispensed_quantity = str(float(dispensedquantity))
        except Exception as exp:
            self.dispensed_quanitity = "1.0"
            pass
        # self.ndc_info = self.dataprovider._get_ndcdrug_info(
        #     self.ndc)
        try:

            self.gpi, self.gppc, self.custom_qty, self.dosage_strength = self.ndc_info['gpi'], \
                self.ndc_info['gppc'],\
                self.ndc_info['custom_qty'], \
                self.ndc_info['dosage_strength']
            if drug_info is '':
                atribute_dict = {}
                atribute_dict['gpi'] = self.gpi
                atribute_dict['drug_name'] = self.ndc_info['drug_name']
                druginfo = self.dataprovider.get_drug_info(atribute_dict)

            if not drug_info and not druginfo:
                return self, '', ''

            drug_params = ['brand_generic', 'ddid', 'dosage', 'otc_indicator', 'pda', 'specialty_flag', 'strengths',
                           'maintenance_drug_flag',
                           'drug_class', 'ddn_form', 'ddn_name', 'ddn_strength', 'lm_strength', 'lm_form', 'lm_name',
                           'drugtype', 'status', 'drug_name']
            if drug_info == '':
                drug_info = druginfo[0]
            if drug_info:
                for dp in drug_params:
                    if dp in drug_info:
                        setattr(self, dp, drug_info[dp])
            if splitquantity:
                self.errorcode, self.error_message = self.splitQuantity(self.ndc_info,
                                                                        pd.DataFrame(drug_info['quantity']))

        except Exception as _:
            pass

        return self

    def splitQuantity(self, ndc_info, quantitydf):

        qtysplit = False

        try:
            difference = float(self.dispensed_quantity) / \
                (float(ndc_info['package_size']) *
                 float(ndc_info['package_quantity']))
            self.package_qty = ndc_info['package_qty']
            self.package_quantity = ndc_info['package_quantity']
            self.package_size = ndc_info['package_size']
            self.package_desc = ndc_info['package_desc']
            self.pkg_desc_cd = ndc_info['pkg_desc_cd']
            self.pkg_uom = ndc_info['pkg_uom']
            if 'quantity_type' in ndc_info:
                self.quantity_type = ndc_info['quantity_type']
            if int(difference) != 1:
                self.custom_quantity = True

            if self.custom_qty == 'package_size':
                self.package_size = str(
                    float(self.dispensed_quantity)/float(self.package_quantity))
                self.package_qty = str(self.dispensed_quantity) + \
                    " " + self.quantity_type
                qtysplit = True
            elif self.custom_qty == 'package_quantity':
                self.package_quantity = str(
                    float(self.dispensed_quantity)/float(self.package_size))
                self.package_qty = str(self.package_quantity) + \
                    " " + self.quantity_type
                qtysplit = True
        except Exception as _:
            self.package_qty = ''
            self.package_desc = ''
            self.pkg_desc_cd = ''
            self.pkg_uom = ''
            self.quantity_type = ''
            self.custom_quantity = False
            self.custom_qty = ''
            self.package_quantity = '1'
            self.package_size = '1'
            self.package_qty = ''

        for element in ['gppc', 'quantity_type', 'package_desc']:
            try:
                self.dosage_image = quantitydf.loc[quantitydf[element] == getattr(
                    self, element), 'dosage_image'].values[0]
                if not self.quantity_type and qtysplit:
                    self.quantity_type = quantitydf.loc[quantitydf[element] == getattr(
                        self, element), 'quantity_type'].values[0]
                    self.package_qty = self.package_qty+self.quantity_type
                break
            except Exception as e:
                print(e)
                continue
        return '', ''
