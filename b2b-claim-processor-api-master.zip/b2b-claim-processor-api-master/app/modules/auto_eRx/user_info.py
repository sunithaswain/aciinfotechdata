import requests
import json
from types import SimpleNamespace as Namespace


class UserInfo:
    def __init__(self, config):
        self.url = config.graphql_url
        self.phone = []
        self.payment_option = 'Pay at Pharmacy'
        self.benefit_plan_name = ''
        self.coverage_tier_name = ''
        self.rx_flipt_person_id = ''
        self.config = config
        self.rx_flipt_person_id = ''
        self.flipt_person_id = ''
        self.emp_flipt_person_id = ''
        self.domain_name = ''
        self.user_id = ''
        self.person_code = ''
        self.mo_contact_email = ''
        self.mo_contact_phone = ''
        self.mo_shipto_location = ''
        self.date_of_birth = ''

    def setAttributes(self, data, flipt_id):

        if 'payment_option' in data:
            self.payment_option = data['payment_option']
        self.benefit_plan_name = data['benefit_plan_name']
        self.coverage_tier_name = data['coverage_tier_name']
        if 'user_id' in data:
            self.user_id = data['user_id']
        self.domain_name = data['domain_name']
        self.person_code = flipt_id[-2:]
        self.emp_flipt_person_id = data['flipt_person_id']
        self.flipt_person_id = data['flipt_person_id']
        self.rx_flipt_person_id = data['flipt_person_id']
        self.mo_contact_email = data['work_email']
        self.mo_contact_phone = ''
        self.mo_shipto_location = 'Home'
        self.date_of_birth = data['date_of_birth']

        for dependent in data['dependents']:
            if dependent['person_code'] == self.person_code:
                self.rx_flipt_person_id = dependent['flipt_person_id']
                self.date_of_birth = dependent['date_of_birth']
                if 'user_id' in dependent and ('active' in dependent and dependent['active']):
                    self.user_id = data['user_id']
                    self.flipt_person_id = dependent['flipt_person_id']
        return self

    def getCommunicationPhone(self, headers, flipt_person_id):

        fid = '"' + flipt_person_id + '"'

        query = """query {getPatientPhoneNumber(flipt_person_id: """ + \
            fid + """)}"""
        communication_ph = requests.post(
            self.url, json={'query': query}, headers=headers)
        try:
            decoded = communication_ph.json()
            phone_no = decoded['data']['getPatientPhoneNumber']
        except Exception as e:
            print(e, 'user phone number')
            return ''
        return phone_no
