class PlanEligibilityCheck(object):

    def __init__(self, query_ex, prescriber_id):
        self.prescriber_id = prescriber_id
        self.query_ex = query_ex

    def is_prescriber_restricted(self):
        """
        :return: Return True/False validating if prescriber is restricted or not
        """

        res = self.query_ex.execute_query('restricted_prescriber_npi', 'restricted_npis',
                                          filters=None, get_single_result=True)

        if res and self.prescriber_id in res['restricted_prescriber_npi']:
            return True
        else:
            return False
        


#  Do not remove data to test the module
'''
if __name__ == "__main__":
    uec_obj = PlanEligibilityCheck('00310460039')
    print(uec_obj.is_prescriber_restricted())

'''

