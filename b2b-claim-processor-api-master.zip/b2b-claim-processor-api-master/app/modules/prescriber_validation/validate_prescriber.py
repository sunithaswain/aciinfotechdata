class PrescriberValidator(object):
    def __init__(self, query_ex, prescriber_id):
        self.prescriber_id = prescriber_id
        self.query_ex = query_ex

    # This will be validated once the prescriber data is ready
    def is_prescriber_active(self):
        """

        :return: Returns true if prescriber is in active state else false
        """
        res = self.query_ex.execute_query('npi_deactivation_date', 'prescriber',
                                          filters={'npi': self.prescriber_id})
        if res and res['npi_deactivation_date'] == 'nan':
            return True
        return False
