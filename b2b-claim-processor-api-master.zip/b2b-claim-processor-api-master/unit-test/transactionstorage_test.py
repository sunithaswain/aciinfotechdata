from mock import MagicMock, patch
import unittest
from app.service.claim_processor_service import ClaimProcessor
from app.models.b1_claim_response import B1ClaimResponse
from app.models.b1_claim_request import B1ClaimRequest
from app.models.claim import Claim


class TestTransactionStorage(unittest.TestCase):

    def setUp(self):
        testrequestdata = b'018571D0B1          1011003004938   20190325XXX0100AAA    AM04 C2100289601 CCTEST CDREGISTRATION AM01 C419700101 C51 C701~ AM07 EM1 D216090 E103 D700597002402 E70000700 D5030 D61 DK07 C801 AM11 DX00 DU00041035 DN07 AM03 EZ01 DB1427092659'

        self.b1claimrequest = B1ClaimRequest(testrequestdata.decode("utf-8"))
        self.b1claimrequest = self.b1claimrequest.setAttributes()

    def test_request_parsing(self):
        '''
        test if request data has been parsed correctly
        '''

        parsedrequest = {'header': {'bin_number': '018571', 'version': 'D0', 'transaction_code': 'B1', 'processor_control_number': '', 'transaction_count': '1', 'service_provider_id_qualifier': '01', 'service_provider_id': '1003004938', 'date_of_service': '20190325', 'software_vendor': 'XXX0100AAA'},
                         'insurance_segment': {'cardholder_id': '100289601', 'home_plan': '', 'plan_id': '', 'eligibility_clarification_code': '', 'group_id': '', 'person_code': '', 'patient_relationship_code': '', 'medigap_id': '', 'medicaid_indicator': '', 'provider_accept_assignment_indicator': '', 'cms_part_d_defined_qualified_facility': '', 'medicaid_id_number': '', 'cardholder_last_name': 'REGISTRATION'},
                         'patient_segment': {'patient_id_qualifier': '', 'patient_id': '', 'date_of_birth': '19700101', 'patient_gender_code': '1', 'place_of_service': '01~', 'employer_id': '', 'pregnancy_indicator': '', 'patient_last_name': 'REGISTRATION'},
                         'claims_segment': {'prescription_reference_number_qualifier': '1', 'prescription_reference_number': '16090', 'product_id_qualifier': '03', 'product_id': '00597002402', 'associated_prescription_reference_number': '', 'associated_prescription_date': '', 'procedure_modifier_code_count': '', 'procedure_modifier_code': '', 'quantity_dispensed': '0000700', 'fill_number': '', 'days_supply': '030', 'compound_code': '1', 'product_selection_code': '', 'date_prescription_written': '', 'number_of_refills_authorized': '', 'prescription_origin_code': '', 'submission_clarification_code_count': '', 'submission_clarification_code': '07', 'other_coverage_code': '01', 'special_packaging_indicator': '', 'originally_prescribed_product_id_qualifier': '', 'originally_prescribed_product_code': '', 'originally_prescribed_quantity': '', 'scheduled_prescription_id_number': '', 'unit_of_measure': '', 'level_of_service': '', 'prior_authorization_type_code': '', 'prior_authorization_number_submitted': '', 'intermediary_authorization_type_id': '',
                                            'intermediary_authorization_id': '', 'dispensing_status': '', 'quantity_intended_dispensed': '', 'days_supply_intended_dispensed': '', 'delay_reason_code': '', 'patient_assignment_indicator': '', 'route_of_administration': '', 'compound_type': '', 'pharmacy_service_type': '', 'gpi': '44209902013420'},
                         'pricing_segment': {'ingredient_cost_submitted': '', 'dispensing_fee_submitted': '', 'patient_paid_amount_submitted': '00', 'incentive_amount_submitted': '', 'other_amount_claimed_submitted_count': '', 'other_amount_claimed_summited_qualifier': '', 'other_amount_claimed_submitted': '', 'flat_sales_tax_amount_submitted': '', 'percentage_sales_tax_amount_submitted': '', 'percentage_sales_tax_rate_submitted': '', 'percentage_sales_tax_basis_submitted': '', 'usual_and_customary_charge': '', 'gross_amount_due': '00041035', 'basis_of_cost_determination': '07'},
                         'prescriber_segment': {'prescriber_id_qualifier': '01', 'prescriber_id': '1427092659', 'prescriber_last_name': '', 'prescriber_phone_number': '', 'primary_care_provider_id_qualifier': '', 'primary_care_provider_id': '', 'primary_care_provider_last_name': '', 'prescriber_first_name': '', 'prescriber_street_address': '', 'prescriber_city_address': '', 'prescriber_state_address': '', 'prescriber_zip_code': ''},
                         'cob_segment': {'payment_count': '', 'other_payer_coverage_type': '', 'other_payer_id_qualifier': '', 'other_payer_id': '', 'other_payer_date': '', 'internal_control_number': '', 'other_payer_amount_paid_count': '', 'other_payer_amount_paid_qualifier': '', 'other_payer_amount_paid': '', 'other_payer_reject_count': '', 'other_payer_reject_code': '', 'other_payer_patient_responsibility_amount_count': '', 'other_payer_patient_responsibility_amount_qualifier': '', 'other_payer_patient_responsibility_amount': '', 'benefit_stage_count': '', 'benefit_stage_qualifier': '', 'benefit_stage_amount': ''},
                         'compound_segment': {'ingredient_component_count': '', 'compound_ingredients': []}}
        self.assertDictEqual(
            self.b1claimrequest.parsedclaim['claim_request'], parsedrequest)


if __name__ == '__main__':
    unittest.main()
