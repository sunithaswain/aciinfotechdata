import unittest

from app.modules.prescriber_validation.validate_prescriber import PrescriberValidator

class mockQueryExecutor(object):
    def __init__(self, ret_val, *args, **kwargs):
        self.ret_val = ret_val

    def execute_query(self, *args, **kwargs):
        return self.ret_val


class TestPrescriberValidator(unittest.TestCase):
    def setUp(self):
        self.pec_obj = PrescriberValidator(mockQueryExecutor(""), prescriber_id='ABCD')


    def test_prescriber_active_with_no_deactivation_date(self):
        ret_val = {}
        self.pec_obj.query_ex.ret_val = ret_val

        assert self.pec_obj.is_prescriber_active() is True

    def test_prescriber_active_with_none_deactivation_date(self):
        ret_val = {'deactivation_date': None}
        self.pec_obj.query_ex.ret_val = ret_val

        assert self.pec_obj.is_prescriber_active() is True

    # def test_prescriber_inactive(self):
    #     # given
    #     ret_val = {'deactivation_date': "20181231"}
    #     data_provider = mockQueryExecutor(ret_val)
    #
    #     assert self.pec_obj.is_prescriber_active(data_provider=data_provider) is False