import unittest

from app.modules.plan_eligibility.benefit_plan_eligibility import PlanEligibilityCheck


class mockQueryExecutor(object):
    def __init__(self, ret_val, *args, **kwargs):
        self.ret_val = ret_val

    def execute_query(self, *args, **kwargs):
        return self.ret_val


class TestPlanEligibilityCheck(unittest.TestCase):

    def setUp(self):
        ret_val = {'restricted_prescriber_npi': ['ABCD']}
        self.query_ex = mockQueryExecutor(ret_val)

    def test_restricted_prescriber(self):
        pec_obj = PlanEligibilityCheck(query_ex=self.query_ex, prescriber_id='ABCD')

        assert pec_obj.is_prescriber_restricted() is True

    def test_valid_prescriber(self):
        pec_obj = PlanEligibilityCheck(query_ex=self.query_ex, prescriber_id='ABCD_valid')

        assert pec_obj.is_prescriber_restricted() is False


if __name__ == '__main__':
    unittest.main()
