import unittest

from app.modules.over_ride_check.over_ride_check import OverRideCheck


class mockQueryExecutor(object):
    def __init__(self, ret_val, *args, **kwargs):
        self.ret_val = ret_val

    def execute_query(self, *args, **kwargs):
        return self.ret_val


class TestOverrideCheck(unittest.TestCase):

    def setUp(self):
        self.ov_obj = OverRideCheck(mockQueryExecutor(""),
                                    auth_id='1234', patient_id='5678',
                                    date_of_service='20190404', product_id='9999999999')

    def test_override_is_none(self):
        ret_val = None
        self.ov_obj.query_ex.ret_val = ret_val
        assert self.ov_obj.get_over_ride_info()["result"] == "false"

    def test_override_dos_lt_start_date(self):
        ret_val = {'startDate': '2019-04-02T22:40:18.862023',
                   'endDate': '2019-04-10T22:40:18.862023'}
        self.ov_obj.query_ex.ret_val = ret_val
        self.ov_obj.date_of_service = "20190401"
        assert self.ov_obj.get_over_ride_info()["result"] == "false"

    def test_override_dos_gt_end_date(self):
        ret_val = {'startDate': '2019-04-02T22:40:18.862023',
                   'endDate': '2019-04-10T22:40:18.862023'}
        self.ov_obj.query_ex.ret_val = ret_val
        self.ov_obj.date_of_service = "20190501"
        assert self.ov_obj.get_over_ride_info()["result"] == "false"

    def test_override_dos_bw_start_end_date(self):
        ret_val = {'startDate': '2019-04-02T22:40:18.862023',
                   'endDate': '2019-04-10T22:40:18.862023',
                   'overridenumber': '1234',
                   'copay_override': '1234',
                   'override_amount': '34',
                   'override_percentage': '4'}

        self.ov_obj.query_ex.ret_val = ret_val
        self.ov_obj.date_of_service = "20190403"
        assert self.ov_obj.get_over_ride_info()["result"] == "true"
