import mock
import unittest
from app.models.b1_claim_request import B1ClaimRequest
from app.modules.claim_validation.validation import ClaimValidation


class mockClaimDataProvider(object):

    def __init__(self, return_value):
        self.return_value = return_value

    def validateBinNumber(self, attribute, *args, **kwargs):
        return self.return_value

    def validateServiceProviderClaim(self, attribute, *args, **kwargs):
        return self.return_value

    def validateNDC(self, atrribute, *args, **kwargs):
        return self.return_value


class TestB1Claim(unittest.TestCase):

    def setUp(self):
        requestdata = '018571D0B1          1011780823500   20190325XXX0100AAA    AM04 C2100289601 CCTEST CDREGISTRATION AM01 C419700101 C51 C701~ AM07 EM1 D216090 E103 D700597002402 E70000400 D5030 D61 DK07 C801 AM11 DX00 DU00041035 DN07 AM03 EZ01 DB1427092659'
        obj = B1ClaimRequest(requestdata)
        obj.parsedclaim = {"claim_request": {"header": {"bin_number": "018571", "version": "D0", "transaction_code": "B1", "processor_control_number": "", "transaction_count": "1", "service_provider_id_qualifier": "01", "service_provider_id": "1780823500", "date_of_service": "20190325", "software_vendor": "XXX0100AAA"}, "insurance_segment": {"cardholder_id": "100289601", "home_plan": "", "plan_id": "", "eligibility_clarification_code": "", "group_id": "", "person_code": "", "patient_relationship_code": "", "medigap_id": "", "medicaid_indicator": "", "provider_accept_assignment_indicator": "", "cms_part_d_defined_qualified_facility": "", "medicaid_id_number": ""}, "patient_segment": {"patient_id_qualifier": "", "patient_id": "", "date_of_birth": "19700101", "patient_gender_code": "1", "place_of_service": "01~", "employer_id": "", "pregnancy_indicator": ""}, "claims_segment": {"prescription_reference_number_qualifier": "1", "prescription_reference_number": "16090", "product_id_qualifier": "03", "product_id": "00597002402", "associated_prescription_reference_number": "", "associated_prescription_date": "", "procedure_modifier_code_count": "", "procedure_modifier_code": "", "quantity_dispensed": "0000400", "fill_number": "", "days_supply": "030", "compound_code": "1", "product_selection_code": "", "date_prescription_written": "", "number_of_refills_authorized": "", "prescription_origin_code": "", "submission_clarification_code_count": "", "submission_clarification_code": "07", "other_coverage_code": "01", "special_packaging_indicator": "", "originally_prescribed_product_id_qualifier": "", "originally_prescribed_product_code": "", "originally_prescribed_quantity": "", "scheduled_prescription_id_number": "", "unit_of_measure": "", "level_of_service": "", "prior_authorization_type_code": "", "prior_authorization_number_submitted": "", "intermediary_authorization_type_id": "",
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        "intermediary_authorization_id": "", "dispensing_status": "", "quantity_intended_dispensed": "", "days_supply_intended_dispensed": "", "delay_reason_code": "", "patient_assignment_indicator": "", "route_of_administration": "", "compound_type": "", "pharmacy_service_type": ""}, "pricing_segment": {"ingredient_cost_submitted": "", "dispensing_fee_submitted": "", "patient_paid_amount_submitted": "00", "incentive_amount_submitted": "", "other_amount_claimed_submitted_count": "", "other_amount_claimed_summited_qualifier": "", "other_amount_claimed_submitted": "", "flat_sales_tax_amount_submitted": "", "percentage_sales_tax_amount_submitted": "", "percentage_sales_tax_rate_submitted": "", "percentage_sales_tax_basis_submitted": "", "usual_and_customary_charge": "", "gross_amount_due": "00041035", "basis_of_cost_determination": "07"}, "prescriber_segment": {"prescriber_id_qualifier": "01", "prescriber_id": "1427092659", "prescriber_last_name": "", "prescriber_phone_number": "", "primary_care_provider_id_qualifier": "", "primary_care_provider_id": "", "primary_care_provider_last_name": "", "prescriber_first_name": "", "prescriber_street_address": "", "prescriber_city_address": "", "prescriber_state_address": "", "prescriber_zip_code": ""}, "cob_segment": {"payment_count": "", "other_payer_coverage_type": "", "other_payer_id_qualifier": "", "other_payer_id": "", "other_payer_date": "", "internal_control_number": "", "other_payer_amount_paid_count": "", "other_payer_amount_paid_qualifier": "", "other_payer_amount_paid": "", "other_payer_reject_count": "", "other_payer_reject_code": "", "other_payer_patient_responsibility_amount_count": "", "other_payer_patient_responsibility_amount_qualifier": "", "other_payer_patient_responsibility_amount": "", "benefit_stage_count": "", "benefit_stage_qualifier": "", "benefit_stage_amount": ""}}}
        self.b1obj = obj
        claimproviderobj = mockClaimDataProvider(False)
        cvalidobj = ClaimValidation(claimproviderobj)
        rejectioncode, rejectionreason = cvalidobj.validateData(
            self.b1obj)

    def test_bin_number_validation(self):
        '''
        test invalid bin number detected with rejection code and reason
        '''

        claimproviderobj = mockClaimDataProvider(False)
        cvalidobj = ClaimValidation(claimproviderobj)
        rejectioncode, rejectionreason = cvalidobj.validateData(
            self.b1obj)

        result = {'valid': {'code': '', 'reason': ''}, 'invalid': {
            'code': '1', 'reason': 'Missing or Invalid BIN'}}

        self.assertDictEqual({'code': rejectioncode, 'reason': rejectionreason}, {
                             'code': result['invalid']['code'], 'reason': result['invalid']['reason']})

    def test_version_number_validation(self):
        '''
        test invalid version number detected with rejection code and reason
        '''

        claimproviderobj = mockClaimDataProvider(True)
        cvalidobj = ClaimValidation(claimproviderobj)
        rejectioncode, rejectionreason = cvalidobj.validateData(
            self.b1obj)

        result = {'valid': {'code': '', 'reason': ''}, 'invalid': {
            'code': '2', 'reason': 'Missing or Invalid Version Number'}}

        self.assertDictEqual({'code': rejectioncode, 'reason': rejectionreason}, {
                             'code': result['valid']['code'], 'reason': result['valid']['reason']})

    def test_transaction_count_valdiation(self):
        '''
        test invalid transaction count detected with rejection code and reason
        '''

        claimproviderobj = mockClaimDataProvider(True)
        cvalidobj = ClaimValidation(claimproviderobj)
        rejectioncode, rejectionreason = cvalidobj.validateData(
            self.b1obj)

        result = {'valid': {'code': '', 'reason': ''}, 'invalid': {
            'code': 'A9', 'reason': 'Missing or Invalid Transaction Count'}}

        self.assertDictEqual({'code': rejectioncode, 'reason': rejectionreason}, {
                             'code': result['valid']['code'], 'reason': result['valid']['reason']})

    def test_service_provider_id_qualifier_validation(self):
        '''
        test invalid service provider id qualifier detected with rejection code and reason
        '''

        claimproviderobj = mockClaimDataProvider(True)
        cvalidobj = ClaimValidation(claimproviderobj)
        rejectioncode, rejectionreason = cvalidobj.validateData(
            self.b1obj)

        result = {'valid': {'code': '', 'reason': ''}, 'invalid': {
            'code': 'B2', 'reason': 'Missing or Invalid Service Provider ID Qualifier'}}

        self.assertDictEqual({'code': rejectioncode, 'reason': rejectionreason}, {
                             'code': result['valid']['code'], 'reason': result['valid']['reason']})

    def test_service_provider_id_validation(self):
        '''
        test invalid service provider id detected with rejection code and reason
        '''

        claimproviderobj = mockClaimDataProvider(True)
        cvalidobj = ClaimValidation(claimproviderobj)
        rejectioncode, rejectionreason = cvalidobj.validateData(
            self.b1obj)

        result = {'valid': {'code': '', 'reason': ''}, 'invalid': {
            'code': '5', 'reason': 'Missing or Invalid Pharmacy Number'}}

        self.assertDictEqual({'code': rejectioncode, 'reason': rejectionreason}, {
                             'code': result['valid']['code'], 'reason': result['valid']['reason']})

    def test_date_of_service_validation(self):
        '''
        test invalid date of service detected with rejection code and reason
        '''

        claimproviderobj = mockClaimDataProvider(True)
        cvalidobj = ClaimValidation(claimproviderobj)
        rejectioncode, rejectionreason = cvalidobj.validateData(
            self.b1obj)

        result = {'valid': {'code': '', 'reason': ''}, 'invalid': {
            'code': '15', 'reason': 'Missing or Invalid Date of Service'}}

        self.assertDictEqual({'code': rejectioncode, 'reason': rejectionreason}, {
                             'code': result['valid']['code'], 'reason': result['valid']['reason']})

    def test_software_vendor_validation(self):
        '''
        test invalid software vendor detected with rejection code and reason
        '''

        claimproviderobj = mockClaimDataProvider(True)
        cvalidobj = ClaimValidation(claimproviderobj)
        rejectioncode, rejectionreason = cvalidobj.validateData(
            self.b1obj)

        result = {'valid': {'code': '', 'reason': ''}, 'invalid': {
            'code': 'AK', 'reason': 'Missing or Invalid Software Vendor/Certification ID'}}

        self.assertDictEqual({'code': rejectioncode, 'reason': rejectionreason}, {
                             'code': result['valid']['code'], 'reason': result['valid']['reason']})

    def test_cardholder_id_validation(self):
        '''
        test invalid cardholder id detected with rejection code and reason
        '''

        claimproviderobj = mockClaimDataProvider(True)
        cvalidobj = ClaimValidation(claimproviderobj)
        rejectioncode, rejectionreason = cvalidobj.validateData(
            self.b1obj)

        result = {'valid': {'code': '', 'reason': ''}, 'invalid': {
            'code': '7', 'reason': 'Missing or Invalid Cardholder ID Number'}}

        self.assertDictEqual({'code': rejectioncode, 'reason': rejectionreason}, {
                             'code': result['valid']['code'], 'reason': result['valid']['reason']})

    def test_date_of_birth_validation(self):
        '''
        test invalid date of birth detected with rejection code and reason
        '''

        claimproviderobj = mockClaimDataProvider(True)
        cvalidobj = ClaimValidation(claimproviderobj)
        rejectioncode, rejectionreason = cvalidobj.validateData(
            self.b1obj)

        result = {'valid': {'code': '', 'reason': ''}, 'invalid': {
            'code': '9', 'reason': 'Missing or Invalid Date of Birth'}}

        self.assertDictEqual({'code': rejectioncode, 'reason': rejectionreason}, {
                             'code': result['valid']['code'], 'reason': result['valid']['reason']})

    def test_gender_code_validation(self):
        '''
        test invalid gender code detected with rejection code and reason
        '''

        claimproviderobj = mockClaimDataProvider(True)
        cvalidobj = ClaimValidation(claimproviderobj)
        rejectioncode, rejectionreason = cvalidobj.validateData(
            self.b1obj)

        result = {'valid': {'code': '', 'reason': ''}, 'invalid': {
            'code': '10', 'reason': 'Missing or Invalid Patient Gender Code'}}

        self.assertDictEqual({'code': rejectioncode, 'reason': rejectionreason}, {
                             'code': result['valid']['code'], 'reason': result['valid']['reason']})

    def test_prescription_reference_number_qualifier_validation(self):
        '''
        test invalid prescription reference number qualifier detected with rejection code and reason
        '''

        claimproviderobj = mockClaimDataProvider(True)
        cvalidobj = ClaimValidation(claimproviderobj)
        rejectioncode, rejectionreason = cvalidobj.validateData(
            self.b1obj)

        result = {'valid': {'code': '', 'reason': ''}, 'invalid': {
            'code': 'EM', 'reason': 'Missing or Invalid Prescription/Service Reference Number Qualifier'}}

        self.assertDictEqual({'code': rejectioncode, 'reason': rejectionreason}, {
                             'code': result['valid']['code'], 'reason': result['valid']['reason']})

    def test_prescription_reference_number_validation(self):
        '''
        test invalid prescription reference number detected with rejection code and reason
        '''

        claimproviderobj = mockClaimDataProvider(True)
        cvalidobj = ClaimValidation(claimproviderobj)
        rejectioncode, rejectionreason = cvalidobj.validateData(
            self.b1obj)

        result = {'valid': {'code': '', 'reason': ''}, 'invalid': {
            'code': 'EN', 'reason': 'Missing or Invalid Associated Prescription/Service Reference Number'}}

        self.assertDictEqual({'code': rejectioncode, 'reason': rejectionreason}, {
                             'code': result['valid']['code'], 'reason': result['valid']['reason']})

    def test_product_id_qualifier_validation(self):
        '''
        test invalid product id qualifier detected with rejection code and reason
        '''

        claimproviderobj = mockClaimDataProvider(True)
        cvalidobj = ClaimValidation(claimproviderobj)
        rejectioncode, rejectionreason = cvalidobj.validateData(
            self.b1obj)

        result = {'valid': {'code': '', 'reason': ''}, 'invalid': {
            'code': 'EJ', 'reason': 'Missing or Invalid Originally Prescribed Product/Service ID Qualifier'}}

        self.assertDictEqual({'code': rejectioncode, 'reason': rejectionreason}, {
                             'code': result['valid']['code'], 'reason': result['valid']['reason']})

    def test_product_id_validation(self):
        '''
        test invalid product id detected with rejection code and reason
        '''

        claimproviderobj = mockClaimDataProvider(True)
        cvalidobj = ClaimValidation(claimproviderobj)
        rejectioncode, rejectionreason = cvalidobj.validateData(
            self.b1obj)

        result = {'valid': {'code': '', 'reason': ''}, 'invalid': {
            'code': '21', 'reason': 'Missing or Invalid Product/Service ID'}}

        self.assertDictEqual({'code': rejectioncode, 'reason': rejectionreason}, {
                             'code': result['valid']['code'], 'reason': result['valid']['reason']})

    def test_days_supply_validation(self):
        '''
        test invalid days of supply detected with rejection code and reason
        '''

        claimproviderobj = mockClaimDataProvider(True)
        cvalidobj = ClaimValidation(claimproviderobj)
        rejectioncode, rejectionreason = cvalidobj.validateData(
            self.b1obj)

        result = {'valid': {'code': '', 'reason': ''}, 'invalid': {
            'code': '19', 'reason': 'Missing or Invalid Days Supply'}}

        self.assertDictEqual({'code': rejectioncode, 'reason': rejectionreason}, {
                             'code': result['valid']['code'], 'reason': result['valid']['reason']})

    def test_compound_code_validation(self):
        '''
        test invalid compound code detected with rejection code and reason
        '''

        claimproviderobj = mockClaimDataProvider(True)
        cvalidobj = ClaimValidation(claimproviderobj)
        rejectioncode, rejectionreason = cvalidobj.validateData(
            self.b1obj)

        result = {'valid': {'code': '', 'reason': ''}, 'invalid': {
            'code': '20', 'reason': 'Missing or Invalid Compound Code'}}

        self.assertDictEqual({'code': rejectioncode, 'reason': rejectionreason}, {
                             'code': result['valid']['code'], 'reason': result['valid']['reason']})

    def test_patient_paid_amount_submitted_validation(self):
        '''
        test invalid patient paid amount submitted detected with rejection code and reason
        '''

        claimproviderobj = mockClaimDataProvider(True)
        cvalidobj = ClaimValidation(claimproviderobj)
        rejectioncode, rejectionreason = cvalidobj.validateData(
            self.b1obj)

        result = {'valid': {'code': '', 'reason': ''}, 'invalid': {
            'code': 'DX', 'reason': 'Missing or Invalid Patient Paid Amount Submitted'}}

        self.assertDictEqual({'code': rejectioncode, 'reason': rejectionreason}, {
                             'code': result['valid']['code'], 'reason': result['valid']['reason']})

    def test_gross_amount_due_validation(self):
        '''
        test invalid gross amount due detected with rejection code and reason
        '''

        claimproviderobj = mockClaimDataProvider(True)
        cvalidobj = ClaimValidation(claimproviderobj)
        rejectioncode, rejectionreason = cvalidobj.validateData(
            self.b1obj)

        result = {'valid': {'code': '', 'reason': ''}, 'invalid': {
            'code': 'DU', 'reason': 'Missing or Invalid Gross Amount Due'}}

        self.assertDictEqual({'code': rejectioncode, 'reason': rejectionreason}, {
                             'code': result['valid']['code'], 'reason': result['valid']['reason']})


if __name__ == '__main__':
    unittest.main()
