from app.utility.bootstrap import Service
from app.utility.config import Config
from app.providers.claim_provider import ClaimProvider
from app.models.b1_claim_request import B1ClaimRequest
#from app.utility.bootstrap import OptionalModules
from app.modules.claim_validation.validation import ClaimValidation
from app.utility.twilio_send_sms import sendSMS
from mock import MagicMock, patch
import unittest


class TestServiceLayer(unittest.TestCase):

    @patch('app.service.claim_processor_service.OptionalModules')
    def setUp(self, modulemock):

        Config._get_cb_connection = MagicMock(
            return_value=None)
        self.serviceobj = Service.cpservice()
        claimreqobj = B1ClaimRequest("")
        requestdata = {"header": {"bin_number": "018571", "version": "D0", "transaction_code": "B1", "processor_control_number": "", "transaction_count": "1", "service_provider_id_qualifier": "01", "service_provider_id": "1003004938", "date_of_service": "20190325", "software_vendor": "XXX0100AAA"}, "insurance_segment": {"cardholder_id": "100289601", "home_plan": "", "plan_id": "", "eligibility_clarification_code": "", "group_id": "", "person_code": "", "patient_relationship_code": "", "medigap_id": "", "medicaid_indicator": "", "provider_accept_assignment_indicator": "", "cms_part_d_defined_qualified_facility": "", "medicaid_id_number": "", "cardholder_last_name": "REGISTRATION"}, "patient_segment": {"patient_id_qualifier": "", "patient_id": "", "date_of_birth": "19700101", "patient_gender_code": "1", "place_of_service": "01~", "employer_id": "", "pregnancy_indicator": "", "patient_last_name": "REGISTRATION"}, "claims_segment": {"prescription_reference_number_qualifier": "1", "prescription_reference_number": "16090", "product_id_qualifier": "03", "product_id": "00597002402", "associated_prescription_reference_number": "", "associated_prescription_date": "", "procedure_modifier_code_count": "", "procedure_modifier_code": "", "quantity_dispensed": "0000700", "fill_number": "", "days_supply": "030", "compound_code": "1", "product_selection_code": "", "date_prescription_written": "", "number_of_refills_authorized": "", "prescription_origin_code": "", "submission_clarification_code_count": "", "submission_clarification_code": "07", "other_coverage_code": "01", "special_packaging_indicator": "", "originally_prescribed_product_id_qualifier": "", "originally_prescribed_product_code": "", "originally_prescribed_quantity": "", "scheduled_prescription_id_number": "", "unit_of_measure": "", "level_of_service": "", "prior_authorization_type_code": "", "prior_authorization_number_submitted": "", "intermediary_authorization_type_id": "",
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               "intermediary_authorization_id": "", "dispensing_status": "", "quantity_intended_dispensed": "", "days_supply_intended_dispensed": "", "delay_reason_code": "", "patient_assignment_indicator": "", "route_of_administration": "", "compound_type": "", "pharmacy_service_type": ""}, "pricing_segment": {"ingredient_cost_submitted": "", "dispensing_fee_submitted": "", "patient_paid_amount_submitted": "00", "incentive_amount_submitted": "", "other_amount_claimed_submitted_count": "", "other_amount_claimed_summited_qualifier": "", "other_amount_claimed_submitted": "", "flat_sales_tax_amount_submitted": "", "percentage_sales_tax_amount_submitted": "", "percentage_sales_tax_rate_submitted": "", "percentage_sales_tax_basis_submitted": "", "usual_and_customary_charge": "", "gross_amount_due": "00041035", "basis_of_cost_determination": "07"}, "prescriber_segment": {"prescriber_id_qualifier": "01", "prescriber_id": "1427092659", "prescriber_last_name": "", "prescriber_phone_number": "", "primary_care_provider_id_qualifier": "", "primary_care_provider_id": "", "primary_care_provider_last_name": "", "prescriber_first_name": "", "prescriber_street_address": "", "prescriber_city_address": "", "prescriber_state_address": "", "prescriber_zip_code": ""}, "cob_segment": {"payment_count": "", "other_payer_coverage_type": "", "other_payer_id_qualifier": "", "other_payer_id": "", "other_payer_date": "", "internal_control_number": "", "other_payer_amount_paid_count": "", "other_payer_amount_paid_qualifier": "", "other_payer_amount_paid": "", "other_payer_reject_count": "", "other_payer_reject_code": "", "other_payer_patient_responsibility_amount_count": "", "other_payer_patient_responsibility_amount_qualifier": "", "other_payer_patient_responsibility_amount": "", "benefit_stage_count": "", "benefit_stage_qualifier": "", "benefit_stage_amount": ""}, "compound_segment": {"ingredient_component_count": "", "compound_ingredients": []}}
        segmentmapping = {"header": "header", "insurance_segment": "insuranceseg", "patient_segment": "patientseg", "claims_segment": "claimsseg",
                          "pricing_segment": "pricingseg", "prescriber_segment": "prescriberseg", "cob_segment": "cobseg", "compound_segment": "compoundseg"}
        claimreqobj.parsedclaim.update({'claim_request': requestdata})
        for segment, fields in requestdata.items():
            claimreq = claimreqobj.__dict__
            obj = claimreq[segmentmapping[segment]]
            for field, value in fields.items():
                if field == 'gpi':
                    continue
                setattr(obj, field, value)
            setattr(claimreqobj, segmentmapping[segment], obj)
        B1ClaimRequest.setAttributes = MagicMock(return_value=claimreqobj)
        ClaimProvider.getGPI = MagicMock(return_value='44209902013420')
        ClaimProvider.getSequenceNumber = MagicMock(
            return_value=['2', 'dummyauthid'])
        ClaimProvider.saveClaim = MagicMock(return_value='claimkey')
        ClaimValidation.validateData = MagicMock(return_value=['', ''])
        user_result = {'benefit-plan-name': 'HSA Value Plan', 'domain': 'FLIPT001', 'result-code': '0', 'message': 'success', 'plan-year': '2019', 'user': {'terms_hipaa_accepted': True, 'last_terms_compliance_presented': '2', 'terms_hipaa_accepted_date': '2019-02-22T10:45:46.287Z', 'terms_compliance_accepted': True, 'terms_compliance_accepted_date': '2018-07-11T19:53:32.280Z', 'employment_status': 'Active', 'user_id': '6f9f8f09-366c-4b0b-ab08-a85e0edede13', 'city': 'South Plainfield', 'gender': 'M', 'locations': [], 'payment_option': 'Pay at Pharmacy', 'type': 'employee', 'home_address_1': '111 Coolidge St', 'flipt_person_id': '1002896', 'tmp_password': '070800076', 'group': 'FLIPTALL', 'domain_name': 'FLIPT001', 'date_of_birth': '1970-01-0100:00:00', 'zip': '07080', 'patient_last_name': 'REGISTRATION', 'coverage_effective_date': '2019-01-01 00:00:00', 'employee_id': 'TEST900076', 'dependents': [
            {'employee_id': 'TEST900076', 'last_name': 'REGTEST1', 'updated_at': '2019-01-25T19:02:22.686288', 'coverage_termination_date': '2019-12-31 23:59:59', 'flipt_person_id': '1003053', 'dependent_ssn': 'T100-00-1088', 'relationship': 'Spouse', 'first_name': 'SPOUSE', 'date_of_birth': '1980-01-01 00:00:00', 'created_at': '2019-01-25T19:02:22.686288', 'person_code': '02', 'coverage_effective_date': '2019-01-01 00:00:00'}], 'coverage_tier_name': 'Individual', 'termination_date': '', 'home_address_2': '', 'updated_at': '2019-01-25T19:02:23.733218', 'coverage_termination_date': '2019-12-31 23:59:59', 'work_email': 'cp_testing@fliptrx.com', 'employee_ssn': 'T100-00-0076', 'location': 'South Plainfield', 'first_name': 'TEST', 'active': True, 'hire_date': '2015-01-01 00:00:00', 'created_at': '2018-12-13T20:10:25.144071', 'state': 'NJ', 'person_code': '01', 'benefit_plan_name': 'HSA Value Plan'}}
        modulemock.userelig.return_value.is_eligible.return_value = user_result
        domain_flags = {'quantity_restriction_buffer': '5',
                        'min_split_pharmacy_savings': '3',
                        'switch_pharmacy_radius': '2',
                        'auto_route_prescription': 'Y',
                        'alternate_effective_date': '2018-01-01T00:00:00.0000',
                        'pharmacy_restriction_flag': 'N',
                        'drug_restriction_flag': 'N',
                        'enable_smart_rewards': 'N',
                        'mo_dayssupply': '90',
                        'comfort_zone_pharmacies': '3',
                        'economy_zone_pharmacies': '5',
                        'saver_zone_factor': '110%',
                        'pbm_price_display': 'N',
                        'use_pbm_price_for_baseline': 'NO',
                        'use_observed_pbm_price': 'N',
                        'pbm_provider': 'Est. Aetna',
                        'generic_discount': '0.71',
                        'brand_discount': '0.15',
                        'employer_penalty_factor': '50',
                        'max_reward_per_year': '10000',
                        'max_reward_per_rx': '75',
                        'rewards_opc_multiplier': '3',
                        'rewards_baseline_multiplier': '50%',
                        'rewards_fixed_amount': '100',
                        'override_flag': 'Y',
                        'validate_prescriber': 'Y'}
        ClaimProvider.getDomainFlags = MagicMock(return_value=domain_flags)
        override_result = {'result': 'false', 'override_number': '',
                           'copay_override': '', 'override_amount': '', 'override_percentage': ''}
        modulemock.overridecheck.return_value.get_over_ride_info.return_value = override_result
        ClaimProvider.getPrescriberRestrictionFlag = MagicMock(
            return_value='Y')
        modulemock.planelig.return_value.is_prescriber_restricted.return_value = False
        modulemock.prescvalid.return_value.is_prescriber_active.return_value = True
        intent_result = {'result': 'True', 'status': 'Routed',
                         'quantity': '400', 'prescription_id': 'prescription::19248'}
        modulemock.intentvalid.return_value.is_intent_present.return_value = intent_result
        presc_result = {"admin_flipt_person_id": "1001598",
                        "alternative_drug_rewards": "0",
                        "application": "Auto eRx",
                        "auth_id": "a2acef57-bba9-4971-b0f5-8320d4f85db4",
                        "baseline_cost": "51655.5444",
                        "bin": "018570",
                        "brand_generic": "T",
                        "chaincode": "39",
                        "create_date": "2019-05-01T16:32:21.122Z",
                        "created_by": "1001598",
                        "custom_qty": "package_quantity",
                        "custom_quantity": True,
                        "days_of_supply": "UP TO 30",
                        "daysofsupply": "30",
                        "ddid": "174202",
                        "ddn_form": "nan",
                        "ddn_name": "nan",
                        "ddn_strength": "nan",
                        "deductible_remaining": "0",
                        "domain": "FLIPT001",
                        "dosage": "INHALER",
                        "dosage_image": "INHALER",
                        "dosage_strength": "4 GM of 20-100 MCG/ACT",
                        "dpa": "COMBIVENT    AER 20-100  ",
                        "drug": "COMBIVENT RESPIMAT",
                        "drug_copay": "30",
                        "drug_cost": "51655.5444",
                        "drug_cost_before_rebate": "71813.535715",
                        "drug_deductible_exempt": "true",
                        "drug_name": "COMBIVENT RESPIMAT",
                        "drug_penalty": "0",
                        "drug_type": "nan",
                        "employee_opc": "0.0",
                        "employer_cost": "51625.5444",
                        "equivalent_brand": "",
                        "flipt_person_id": "1002896",
                        "form": "INHALER",
                        "gpi": "44209902013420",
                        "gppc": "79520KCT",
                        "group_id": "",
                        "lm_form": "nan",
                        "lm_name": "nan",
                        "lm_ndc": "nan",
                        "lm_strength": "nan",
                        "location": "446 SABATTUS STREET",
                        "locationSelected": "Current Location",
                        "member_id": "100289601",
                        "npi": "1003004938",
                        "out_of_pocket_remaining": "3425",
                        "pa_flag": "N",
                        "pa_form": "",
                        "pa_override": "None",
                        "pa_reason": "",
                        "package_desc": "INHALER",
                        "package_qty": "175 INHALER",
                        "package_quantity": "175",
                        "package_size": "4.0",
                        "patient_paid": "00",
                        "payment_option": "Pay at Pharmacy",
                        "pbm_estimated_cost": "0",
                        "pbm_price": "0",
                        "pcn": "",
                        "penalty_factor": "50",
                        "pharmacy": "CVS",
                        "pharmacy_discount": "0.85",
                        "pharmacy_dispensing_fee": "1.5",
                        "pkg_desc_cd": "IH",
                        "pkg_uom": "GM",
                        "prescription_basket_id": "prescription::19258",
                        "prescription_id": "prescription::19258",
                        "preselected_npi": "1003004938",
                        "preselected_pharmacy": "CVS",
                        "quantity": "175",
                        "quantity_type": "INHALER",
                        "rebate_amount": "20157.991315000007",
                        "rebate_factor": "0.719295060335451",
                        "retail_reward": "0",
                        "reward_percentage": "50",
                        "reward_share": "50",
                        "rewards": "0",
                        "routed_date": "2019-05-01T16:32:30.904Z",
                        "rx_flipt_person_id": "1002896",
                        "rx_status": "Routed",
                        "saved_date": "2019-05-01T16:32:21.122Z",
                        "search_location": "44.1017368, -70.1927028",
                        "search_prescription_id": "",
                        "specialty_flag": "N",
                        "strengths": "nan",
                        "total_payment": "30",
                        "type": "prescription",
                        "unit_price": "86.81352",
                        "unit_price_before_rebate": "120.692497",
                        "update_date": "2019-05-03T20:42:31.623272",
                        "updated_by": "1002896",
                        "zipCode": "04240",
                        "zone": "1"}

        ClaimProvider.getIntentData = MagicMock(return_value=presc_result)
        autoerxobj = modulemock.autoerx(claimobj=self.serviceobj)
        userobj = modulemock.user()
        autoerxobj.userinfoobj.setAttributes = MagicMock(return_value=userobj)
        autoerxobj.signinobj.getUserToken = MagicMock(
            return_value={'Authorization': 'dummytoken'})
        autoerxobj.userinfoobj.getCommunicationPhone = MagicMock(
            return_value='dummyphone')
        ClaimProvider.saveRewards = MagicMock()
        ClaimProvider.getRxhistoryData = MagicMock(
            return_value="rxhistory::test")
        ClaimProvider.saveRxHistoryData = MagicMock()
        ClaimProvider.updateIntent = MagicMock()
        sendSMS = MagicMock(return_value=['success', ''])
        self.responsestring = self.serviceobj.adjudicateClaim(
            b'018570D0B1          1011003004938   20190501XXX0100AAA    AM04 C2100289601 CCTEST CDREGISTRATION AM01 C419700101 C51 C701~ AM07 EM1 D216090 E103 D700597002402 E70000700 D5030 D61 DK07 C801 AM11 DX00 DU00041035 DN07 AM03 EZ01 DB1427092659 AM10 EC2 RE01 TE12345678 ED2300 UE7400 RE01 TE234567890 ED5600 2G02 2H678 2H456')
        self.modulemock = modulemock

    def test_requesttype(self):

        self.assertEqual(self.serviceobj.requesttype, 'B1')

    def test_usereligibilitymodulecall(self):

        self.modulemock.userelig.assert_called_with(card_holder_id='100289601',
                                                    date_of_birth='1970-01-01 00:00:00',
                                                    date_of_service='2019-03-25',
                                                    last_name='REGISTRATION')

    def test_overridecheckmodulecall(self):

        self.modulemock.overridecheck.assert_called_with(auth_id='dummyauthid',
                                                         patient_id='100289601',
                                                         date_of_service='20190325',
                                                         product_id='44209902013420')

    def test_planeligibilitymodulecall(self):

        self.modulemock.planelig.assert_called_with(prescriber_id='1427092659')

    def test_prescribervalidationmodulecall(self):

        self.modulemock.prescvalid.assert_called_with(
            prescriber_id='1427092659')

    def test_intentcheckmodulecall(self):

        self.modulemock.intentvalid.assert_called_with(service_provider_id='1003004938',
                                                       product_id='00597002402',
                                                       cardholder_id='100289601')

    def test_responsestring(self):

        self.assertEqual(self.responsestring,
                         'A2D0 A3B1 A91 F1A B201 B11003004938 D120190325 AM25 2Ftbd C2100289601 AM29 CBREGISTRATION AM21 ANA F3dummyauthid AM22 EM1 D216090 9F1 AM23 F50.0 F651654.0444 AV1 J21 J301 F951655.5444 FM1')
