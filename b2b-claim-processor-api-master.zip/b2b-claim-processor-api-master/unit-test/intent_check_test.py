import unittest

from app.modules.intent_check.intent_check import IntentValidator


class mockQueryExecutor(object):
    def __init__(self, ret_val, *args, **kwargs):
        self.ret_val = ret_val

    def execute_query(self, cols, doc_type, *args, **kwargs):
        return self.ret_val[doc_type]


class TestIntentValidator(unittest.TestCase):
    def setUp(self):
        self.iv_obj = IntentValidator(mockQueryExecutor({}),
                                      service_provider_id='SPID',
                                      product_id='PID',
                                      cardholder_id='PAID'
                                      )

    def test_intent_not_present(self):
        # given
        ret_val = {'ndc_drugs': {'brand_generic': 'BG', 'gpi': 'GPI', 'drug_name': 'DN'},
                   'prescription': {}}

        self.iv_obj.query_ex.ret_val = ret_val

        # then
        assert self.iv_obj.is_intent_present()['result'] == 'False'

    def test_intent_routed_rx_status(self):
        # given
        ret_val = {'ndc_drugs': {'brand_generic': 'BG', 'gpi': 'GPI', 'drug_name': 'DN'},
                   'prescription': {'rx_status': 'Routed',
                                    'quantity': '',
                                    'prescription_id': ''}}
        self.iv_obj.query_ex.ret_val = ret_val

        # then
        assert self.iv_obj.is_intent_present()['result'] == 'True'

    def test_intent_PA_rx_status_pa_flag_is_Y(self):
        # given
        ret_val = {'ndc_drugs': {'brand_generic': 'BG', 'gpi': 'GPI', 'drug_name': 'DN'},
                   'prescription': {'rx_status': 'PA',
                                    'pa_flag': 'Y',
                                    'quantity': '',
                                    'prescription_id': ''}}
        self.iv_obj.query_ex.ret_val = ret_val
        # then
        assert self.iv_obj.is_intent_present()['result'] == 'True'

    def test_intent_PA_rx_status_pa_flag_is_N(self):
        # given
        ret_val = {'ndc_drugs': {'brand_generic': 'BG', 'gpi': 'GPI', 'drug_name': 'DN'},
                   'prescription': {'rx_status': 'PA', 'pa_flag': 'N'}}
        self.iv_obj.query_ex.ret_val = ret_val
        # then
        assert self.iv_obj.is_intent_present()['result'] == 'False'
