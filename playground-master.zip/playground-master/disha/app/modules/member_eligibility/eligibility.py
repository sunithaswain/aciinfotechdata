import os
import json
import logging
import base64
import requests

from requests.auth import HTTPBasicAuth

TRUEVAULT_API_KEY = os.environ['TV_API_KEY']
ACTIVE_EMP_STATUS = "Active"
URI = 'https://api.truevault.com/v1/users/search'

class UserEligibuilityCheck(object):
    def __init__(self, flipt_member_id, date_of_service, first_name, last_name, date_of_birth,
                 gender):
        self.flipt_member_id = str(flipt_member_id)[:-2]
        self.person_code = str(flipt_member_id)[-2:]
        self.date_of_service = date_of_service
        self.first_name = first_name
        self.last_name = last_name
        self.date_of_birth = date_of_birth
        self.gender = gender
        self.logger = logging.getLogger(__name__)
        self.logger.level = logging.DEBUG
        
    def is_eligible(self):
        """
        :param data: expects data in str format with required 5 params, checks if the user is eligible for
                        the claim.
        :return: returns TRUE or FALSE depending upon the input data
        """

        user = self.search_user()
        if user is None:
            err_msg = "Invalid Flipt Member details for this member_id: %s", self.flipt_member_id
            self.logger.info(err_msg)
            return False

        if user.get('employment_status') != ACTIVE_EMP_STATUS or \
                user.get('flipt_person_id') != self.flipt_member_id:
            return False

        # validations for active user
        if user['coverage_termination_date'] <= self.date_of_service:
            self.logger.info("Member is in active status and covered while processing the claim")
            return True

    def search_user(self):
        """""
        :return: This functions takes the above params as input and creates a curl command and post
                  request to truevault with base64encoding.
        """
        self.logger.info("Inside search user function truevault")
        search_option = {'full_document': True,
                         'filter': {
                             'flipt_person_id': {
                                 'type': 'eq',
                                 'value': self.flipt_member_id,
                                 'case_sensitive': False
                             },
                             'first_name': {
                                 'type': 'eq',
                                 'value': self.first_name,
                                 'case_sensitive': False
                             },
                             'last_name': {
                                 'type': 'eq',
                                 'value': self.last_name,
                                 'case_sensitive': False
                             },
                             'date_of_birth': {
                                 'type': 'eq',
                                 'value': self.date_of_birth,
                                 'case_sensitive': False
                             },
                             'gender': {
                                 'type': 'eq',
                                 'value': self.gender,
                                 'case_sensitive': False
                             },
                             '$tv.status': {'type': 'eq', 'value': 'ACTIVATED'}}, 'filter_type': 'and'}

        print(search_option)
        search_opt = base64.b64encode(str.encode(json.dumps(search_option)))
        search_dict = {'search_option': search_opt}
        res = requests.post(URI, auth=HTTPBasicAuth(TRUEVAULT_API_KEY, ''), data=search_dict)

        # print(res)

        response = res.json()
        print(response)
        if 'error' in response:
            err_msg = str(response['error'])
            self.logger.error(err_msg)
            return

        if (res.status_code != 200 or 'data' not in response or
                (res.status_code == 200 and not response['data'].get('documents'))):
            return
        res = base64.b64decode(response['data']['documents'][0]['attributes']).decode('utf-8')
        return json.loads(res)

'''
if __name__ == "__main__":
    uec_obj = UserEligibuilityCheck('100272101', '20190101', 'HEMANT', 'KUMAR',
                                    '1968-03-11 00:00:00', 'M')
    print(uec_obj.is_eligible())

'''