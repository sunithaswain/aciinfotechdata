from app.models.b1claimrequest import B1ClaimRequest
from app.models.b1claimresponse import B1ClaimResponse
from app.providers.Couchbase import Couchbase
from flask_injector import inject
#from app.modules.member_eligibility.eligibility import UserEligibuilityCheck


class ClaimProcessorAPI():

    def __init__(self,requestdata):
        self.requestdata = requestdata

    @inject(data_provider=Couchbase)
    def processData(self,data_provider=Couchbase):
        b1request_obj = B1ClaimRequest(self.requestdata)
        parseddata = b1request_obj.getClaimData()
        data_provider.saveClaim(data_provider,parseddata)
        #elig_obj = UserEligibuilityCheck(parseddata['patient_id'],parseddata['date_of_service'],parseddata['patient_first_name'],parseddata['patient_last_name'],parseddata['date_of_birth'],parseddata['patient_gender_code'])
        #result = elig_obj.is_eligible()
        #print(result)


    def getResponse(self):
        return "610442D0B1          1010000000071   20120101XXX0100AAA    AM04 C2333224444931101  AM01 C419220402 C51 C701~  AM07 EM1 D2123450234567 E103 D700078010409 E70000100000 D5030 D61 DK07 C802 EU01 EV11111111111  AM11 DX00001000 DU0000220 DN00  AM03 EZ01 DB1234567893    AM05 4C1 5C01 HB1 HC01 DV00001100"

