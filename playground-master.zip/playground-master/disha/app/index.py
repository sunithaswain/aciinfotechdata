from flask import request,Flask,Response
from app.service.api_service import ClaimProcessorAPI
from app.providers import Couchbase
from injector import Binder
from flask_injector import FlaskInjector


def configure(binder:Binder) -> Binder:
    binder.bind(
        interface = Couchbase.Couchbase,
        to = Couchbase.Couchbase()
    )

app = Flask(__name__)
@app.route('/fliptclaimprocessor',methods = ['POST'])
def incomingclaim():

    cp = ClaimProcessorAPI(request.data)
    cp.processData()
    responsestring = cp.getResponse()
    resp = Response(responsestring, status=200, mimetype='application/text')
    return resp

if __name__=='__main__':
    FlaskInjector(app=app,modules=[configure])
    app.run()

