from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from couchbase import FMT_JSON
import os
from injector import provider,inject,Module

cluster = Cluster('http://13.90.231.152')
authenticator = PasswordAuthenticator('dev-backend.python-scripts', 'befog-dialysis-exemplar-tori')
cluster.authenticate(authenticator)
cb = cluster.open_bucket('dev-fliptrx-app')

class Couchbase(Module):

    @inject
    def __init__(self):
        print('creating db ops obj')
        self.cb = cluster.open_bucket('dev-fliptrx-app')

    @provider
    def saveClaim(self,data):
        
        print('saving data---------')
        #cb.upsert(str(cb.counter('docid',delta=1).value),data, format=FMT_JSON)

    @provider
    def validateClaim(self,attribute_name,attribute_value):
        
        if attribute_name == 'bin_number':
            db_attribute = 'rxbin'
            query = N1QLQuery('Select rxbin from `dev-fliptrx-app` where type="claim_processor" and rxbin=$v',v=attribute_value)
        elif attribute_name == 'service_provider_id':
            db_attribute = 'pharmacynpi'
            query = N1QLQuery('Select pharmacynpi from `dev-fliptrx-app` where type="cp_pharmacy" and pharmacynpi=$v',v=attribute_value)
        elif attribute_name == 'product_id':
            db_attribute = 'ndc'
            query = N1QLQuery('Select ndc from `dev-fliptrx-app` where type="ndc_drugs" and ndc=$v',v=attribute_value)
        for result in cb.n1ql_query(query):
            if attribute_value == result[db_attribute]:
                return True
        return False
            

