#!/usr/bin/env python
"""
mocking requests calls
"""
import mock
import json

import unittest
from app.modules.member_eligibility import eligibility

TRUEVAULT_RESPONSE_TEMPLATE = {'data': {'info': {'per_page': 100, 'total_result_count': 1, 'num_pages': 1, 'current_page': 1}, 'documents': [{'id': '27a1cd88-dda6-4250-9d82-f6f2cda8a621', 'attributes': 'eyJsb2NhdGlvbnMiOiBbXSwgInVwZGF0ZWRfYXQiOiAiMjAxOS0wMy0wMVQyMDoxMDowNy4wNDg0OTYiLCAiY292ZXJhZ2VfZWZmZWN0aXZlX2RhdGUiOiAiMjAxOS0wMS0wMSAwMDowMDowMCIsICJjb3ZlcmFnZV90ZXJtaW5hdGlvbl9kYXRlIjogIjIwMTktMTItMzEgMjM6NTk6NTkiLCAicGVyc29uX2NvZGUiOiAiMDEiLCAiZW1wbG95ZWVfc3NuIjogInh4eC14eC0wNzE5IiwgImZsaXB0X3BlcnNvbl9pZCI6ICIxMDAyNzIxIiwgImNpdHkiOiAiRG95bGVzdG93biIsICJsb2NhdGlvbiI6ICJROFYiLCAiZW1wbG95ZWVfaWQiOiAiNzAwNzkwIiwgImhvbWVfYWRkcmVzc18yIjogIiIsICJ0ZXJtaW5hdGlvbl9kYXRlIjogIiIsICJlbXBsb3ltZW50X3N0YXR1cyI6ICJBY3RpdmUiLCAiemlwIjogIjE4OTAyIiwgImhpcmVfZGF0ZSI6ICIyMDEzLTA1LTAxIDAwOjAwOjAwIiwgIndvcmtfZW1haWwiOiAiaGt1bWFyQGZsaXB0cnguY29tIiwgImRvbWFpbl9uYW1lIjogIkZMSVBUMDAxIiwgImFjdGl2ZSI6IGZhbHNlLCAic3RhdGUiOiAiUEEiLCAiaG9tZV9hZGRyZXNzXzEiOiAiNDU4NCBSaWRnZXRvcCBSb2FkIiwgImxhc3RfbmFtZSI6ICJLVU1BUiIsICJ0bXBfcGFzc3dvcmQiOiAiMTg5MDIwNzE5IiwgImdyb3VwIjogIkZMSVBUQUxMIiwgImRhdGVfb2ZfYmlydGgiOiAiMTk2OC0wMy0xMSAwMDowMDowMCIsICJkZXBlbmRlbnRzIjogW3sidXBkYXRlZF9hdCI6ICIyMDE5LTAzLTAxVDIwOjEwOjA3LjA3MjY0MyIsICJjb3ZlcmFnZV9lZmZlY3RpdmVfZGF0ZSI6ICIyMDE5LTAxLTAxIDAwOjAwOjAwIiwgImNvdmVyYWdlX3Rlcm1pbmF0aW9uX2RhdGUiOiAiMjAxOS0xMi0zMSAyMzo1OTo1OSIsICJwZXJzb25fY29kZSI6ICIwMiIsICJyZWxhdGlvbnNoaXAiOiAiU3BvdXNlIiwgImNyZWF0ZWRfYXQiOiAiMjAxOC0xMC0xNlQxNzowOTozMC40NzMyMzgiLCAiZGF0ZV9vZl9iaXJ0aCI6ICIxOTcwLTA0LTI1IDAwOjAwOjAwIiwgImVtcGxveWVlX2lkIjogIjcwMDc5MCIsICJmaXJzdF9uYW1lIjogIk5FRU5BIiwgImxhc3RfbmFtZSI6ICJLVU1BUiIsICJnZW5kZXIiOiAiRiIsICJmbGlwdF9wZXJzb25faWQiOiAiMTAwMjcyMiIsICJkZXBlbmRlbnRfc3NuIjogInh4eC14eC0yNTgzIn0sIHsidXBkYXRlZF9hdCI6ICIyMDE5LTAzLTAxVDIwOjEwOjA3LjA3NjU3MyIsICJjb3ZlcmFnZV9lZmZlY3RpdmVfZGF0ZSI6ICIyMDE5LTAxLTAxIDAwOjAwOjAwIiwgImNvdmVyYWdlX3Rlcm1pbmF0aW9uX2RhdGUiOiAiMjAxOS0xMi0zMSAyMzo1OTo1OSIsICJwZXJzb25fY29kZSI6ICIwMyIsICJyZWxhdGlvbnNoaXAiOiAiQ2hpbGQiLCAiY3JlYXRlZF9hdCI6ICIyMDE4LTEwLTE2VDE3OjA5OjMwLjQ3MzIzOCIsICJkYXRlX29mX2JpcnRoIjogIjE5OTMtMDktMjMgMDA6MDA6MDAiLCAiZW1wbG95ZWVfaWQiOiAiNzAwNzkwIiwgImZpcnN0X25hbWUiOiAiRUtBTlNIIiwgImxhc3RfbmFtZSI6ICJLVU1BUiIsICJnZW5kZXIiOiAiTSIsICJmbGlwdF9wZXJzb25faWQiOiAiMTAwMjcyMyIsICJkZXBlbmRlbnRfc3NuIjogInh4eC14eC04NDA5In0sIHsidXBkYXRlZF9hdCI6ICIyMDE5LTAzLTAxVDIwOjEwOjA3LjA4MDMxMyIsICJjb3ZlcmFnZV9lZmZlY3RpdmVfZGF0ZSI6ICIyMDE5LTAxLTAxIDAwOjAwOjAwIiwgImNvdmVyYWdlX3Rlcm1pbmF0aW9uX2RhdGUiOiAiMjAxOS0xMi0zMSAyMzo1OTo1OSIsICJwZXJzb25fY29kZSI6ICIwNCIsICJyZWxhdGlvbnNoaXAiOiAiQ2hpbGQiLCAiY3JlYXRlZF9hdCI6ICIyMDE4LTEwLTE2VDE3OjA5OjMwLjQ3MzIzOCIsICJkYXRlX29mX2JpcnRoIjogIjE5OTktMTAtMTQgMDA6MDA6MDAiLCAiZW1wbG95ZWVfaWQiOiAiNzAwNzkwIiwgImZpcnN0X25hbWUiOiAiRVNIQVdOIiwgImxhc3RfbmFtZSI6ICJLVU1BUiIsICJnZW5kZXIiOiAiTSIsICJmbGlwdF9wZXJzb25faWQiOiAiMTAwMjcyNCIsICJkZXBlbmRlbnRfc3NuIjogInh4eC14eC01MzI0In1dLCAiZ2VuZGVyIjogIk0iLCAiZmlyc3RfbmFtZSI6ICJIRU1BTlQiLCAiYmVuZWZpdF9wbGFuX25hbWUiOiAiSFNBIE1heCBWYWx1ZSBQbGFuIiwgImNvdmVyYWdlX3RpZXJfbmFtZSI6ICJFbXBsb3llZSBhbmQgRmFtaWx5IiwgImNyZWF0ZWRfYXQiOiAiMjAxOC0xMC0xNlQxNzowOTozMC40NzMyMzgiLCAidHlwZSI6ICJlbXBsb3llZSJ9', 'username': 'hkumar@fliptrx.com', 'status': 'ACTIVATED', 'user_id': '856501cd-22b8-4aeb-8892-73aad6ed06da'}]}, 'transaction_id': 'b6f07385-ea2b-4688-ac1f-422f0d55d9d7', 'result': 'success'}



class TestRequestsCall(unittest.TestCase):
    """
    Mock requests.post and return a mock Response object
    """
    def _mock_post_response(
            self,
            status=200,
            content="CONTENT",
            json_data=None,
            raise_for_status=None):
        """
        since we typically test a bunch of different
        requests calls for a service, we are going to do
        a lot of mock responses, so its usually a good idea
        to have a helper function that builds these things
        """
        mock_resp = mock.Mock()
        # mock raise_for_status call w/optional error
        mock_resp.raise_for_status = mock.Mock()
        if raise_for_status:
            mock_resp.raise_for_status.side_effect = raise_for_status
        # set status code and content
        mock_resp.status_code = status
        mock_resp.content = content
        # add json data if provided
        if json_data:
            # mock_resp.json = json_data
            mock_resp.json = mock.Mock(
                return_value=json.loads(json_data)
            )
        return mock_resp

    @mock.patch('requests.post')
    def test_is_user_eligible_valid(self, mock_post):
        """
        test true-vault query method
        """
        mock_resp = self._mock_post_response(json_data=json.dumps(TRUEVAULT_RESPONSE_TEMPLATE))
        mock_post.return_value = mock_resp
        uec_obj = eligibility.UserEligibuilityCheck('100272101', '20190101', 'HEMANT', 'KUMAR', '1968-03-11 00:00:00', 'M')
        result = uec_obj.is_eligible()
        self.assertEqual(result, True)

    @mock.patch('requests.post')
    def test_is_user_eligible_invalid(self, mock_post):
        """
        test true-vault query method
        """
        mock_resp = self._mock_post_response(json_data=json.dumps(TRUEVAULT_RESPONSE_TEMPLATE))
        mock_post.return_value = mock_resp
        uec_obj = eligibility.UserEligibuilityCheck('100272101-INVALID', '20190101', 'HEMANT', 'KUMAR', '1968-03-11 00:00:00', 'M')
        result = uec_obj.is_eligible()
        self.assertEqual(result, False)

if __name__ == '__main__':
    unittest.main()
