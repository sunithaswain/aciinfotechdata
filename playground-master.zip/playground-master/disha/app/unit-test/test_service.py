#use pytest module
#use tempfile module

#function to test validate auth credential input

#function to test authentication




