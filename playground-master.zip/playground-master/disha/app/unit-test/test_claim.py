#use pytest module
#use tempfile module

#function to test parsing a claim

#function to test validation for each segment
