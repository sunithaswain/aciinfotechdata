#class switch (like erx or relay health)
#also includes authentication