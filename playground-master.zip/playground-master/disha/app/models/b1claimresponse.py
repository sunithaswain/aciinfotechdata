class B1ClaimResponse:

        def __init__(self):
                pass

        def prepareResponse(self):
                return "abcdefi"
            