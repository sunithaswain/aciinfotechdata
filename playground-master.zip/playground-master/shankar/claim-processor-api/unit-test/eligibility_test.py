"""
mocking requests calls
"""
import mock
import json
import base64
import unittest
from app.modules.member_eligibility import eligibility

FLIPT_PERSON_ID = 1002721

RESPONSE_ATTR = {
    'first_name': 'DEMOEMPLOYEE_LN9', 'location': 'South Plainfield',
    'dependents': [
        {"coverage_termination_date": "2019-12-31 23:59:59", "date_of_birth": "1980-01-01 00:00:00",
         "employee_id": "TEST900124", "created_at": "2019-02-04T14:56:09.617863", "last_name": "DOE",
         "updated_at": "2019-02-04T14:56:09.617863", "flipt_person_id": "1003185", "dependent_ssn": "T100-00-1211",
         "person_code": "02", "coverage_effective_date": "2019-01-01 00:00:00", "relationship": "Spouse",
         "first_name": "MARY", "deductible_remaining": 0, "out_of_pocket_remaining": 5000,
         "individual_deductible_remaining": 0, "individual_out_of_pocket_remaining": 5000,
         "family_deductible_remaining": 0, "family_out_of_pocket_remaining": 10000},
        {"coverage_termination_date": "2019-12-31 23:59:59", "date_of_birth": "2000-01-01 00:00:00",
         "employee_id": "TEST900124", "created_at": "2019-02-04T14:56:09.617863", "last_name": "DOE",
         "updated_at": "2019-02-04T14:56:09.617863", "flipt_person_id": "1003186", "dependent_ssn": "T100-00-1212",
         "person_code": "03", "coverage_effective_date": "2019-01-01 00:00:00", "relationship": "Child",
         "first_name": "SCOTT", "deductible_remaining": 0, "out_of_pocket_remaining": 5000,
         "individual_deductible_remaining": 0, "individual_out_of_pocket_remaining": 5000,
         "family_deductible_remaining": 0, "family_out_of_pocket_remaining": 10000},
        {"coverage_termination_date": "2019-12-31 23:59:59", "date_of_birth": "2000-01-01 00:00:00",
         "employee_id": "TEST900124", "created_at": "2019-02-04T14:56:09.617863", "last_name": "DOE",
         "updated_at": "2019-02-04T14:56:09.617863", "flipt_person_id": "1003187", "dependent_ssn": "T100-00-1213",
         "person_code": "04", "coverage_effective_date": "2019-01-01 00:00:00", "relationship": "Child",
         "first_name": "DAVID", "deductible_remaining": 0, "out_of_pocket_remaining": 5000,
         "individual_deductible_remaining": 0, "individual_out_of_pocket_remaining": 5000,
         "family_deductible_remaining": 0, "family_out_of_pocket_remaining": 10000}],
    'coverage_termination_date': '2019-12-31 23:59:59',
    'work_email': 'demoemployee_fnln9@fliptrx.com', 'employment_status': 'Active', 'employee_ssn': 'T100-00-0124',
    'user_id': 'efffef26-2227-42c2-aa73-d0d7454521b0', 'username': 'demoemployee_fnln9@fliptrx.com',
    'status': 'ACTIVATED', 'zip': '18902', 'hire_date': '2013-05-01 00:00:00',
    'domain_name': 'FLIPT001', 'home_address_2': '', 'date_of_birth': '1970-01-01 00:00:00', 'locations': [],
    'gender': 'M', 'created_at': '2018-10-16T17:09:30.473238', 'home_address_1': '',
    'flipt_person_id': FLIPT_PERSON_ID, 'tmp_password': '189020719', 'person_code': '01', 'city': 'South Plainfield',
    'last_name': 'DEMOEMPLOYEE_FN9', 'updated_at': '2019-03-06T21:22:04.275501', 'employee_id': '700790',
    'type': 'employee', 'termination_date': '', 'state': 'PA', 'coverage_tier_name': 'Employee and Family',
    'benefit_plan_name': 'HSA Max Value Plan', 'group': 'FLIPTALL',
    'coverage_effective_date': '2019-01-01 00:00:00', 'active': False}


class TestRequestsCall(unittest.TestCase):
    """
    Mock requests.post and return a mock Response object
    """

    def _mock_post_response(
            self,
            status=200,
            content="CONTENT",
            data=None,
            raise_for_status=None):
        """
        since we typically test a bunch of different
        requests calls for a service, we are going to do
        a lot of mock responses, so its usually a good idea
        to have a helper function that builds these things
        """
        mock_resp = mock.Mock()
        # mock raise_for_status call w/optional error
        mock_resp.raise_for_status = mock.Mock()
        if raise_for_status:
            mock_resp.raise_for_status.side_effect = raise_for_status
        # set status code and content
        mock_resp.status_code = status
        mock_resp.content = content
        # add json data if provided
        if data:
            # mock_resp.json = json_data
            mock_resp.json = mock.Mock(
                return_value=data
            )
        return mock_resp

    def _get_data(self, response_attr=None):
        if response_attr is None:
            response_attr = RESPONSE_ATTR
        true_vault_response = {
            'data': {'info': {'per_page': 100, 'total_result_count': 1,
                              'num_pages': 1, 'current_page': 1},
                     'documents': [{'id': '27a1cd88-dda6-4250-9d82-f6f2cda8a621',
                                    'attributes': None,
                                    'username': 'demoemployee_fnln9@fliptrx.com', 'status': 'ACTIVATED',
                                    'user_id': 'efffef26-2227-42c2-aa73-d0d7454521b0'}]},
            'transaction_id': 'b6f07385-ea2b-4688-ac1f-422f0d55d9d7', 'result': 'success'}
        attr = base64.b64encode(json.dumps(response_attr).encode('utf-8'))
        true_vault_response['data']['documents'][0]['attributes'] = attr
        return true_vault_response

    @mock.patch('requests.post')
    def test_is_eligible_invalid_flipt_person_id(self, mock_post):
        """
        test true-vault query method
        """
        flipt_member_id = 'invalidID01'
        ref_response = {'result': 'false',
                        'return-code': '52',
                        'message': 'Non-Matched Cardholder ID'
                        }
        mock_resp = self._mock_post_response(
            data=self._get_data(response_attr={}))
        mock_post.return_value = mock_resp
        uec_obj = eligibility.UserEligibilityCheck(flipt_member_id, 'DEMOEMPLOYEE_LN9',
                                                   '1970-01-01 00:00:00', '2019-01-01')

        response = uec_obj.is_eligible()
        self.assertEqual(response, ref_response)

    @mock.patch('requests.post')
    def test_is_eligible_coverage_date_expired(self, mock_post):
        """
        test true-vault query method
        """
        def mock_is_coverage_effective(*args, **kwargs):
            return False

        flipt_member_id = '100318501'
        ref_response = {'benefit-plan-name': 'HSA Max Value Plan',
                        'domain': 'FLIPT001',
                        'plan-year': '2019',
                        'result': 'false',
                        'return-code': '15',
                        'message': 'Missing or invalid date of service'
                        }
        mock_resp = self._mock_post_response(data=self._get_data())
        mock_post.return_value = mock_resp
        uec_obj = eligibility.UserEligibilityCheck(flipt_member_id, 'DEMOEMPLOYEE_LN9',
                                                   '1970-01-01 00:00:00', '2019-01-01')
        uec_obj._is_coverage_effective = mock_is_coverage_effective

        response = uec_obj.is_eligible()
        self.assertEqual(response, ref_response)

    @mock.patch('requests.post')
    def test_is_eligible_is_last_name_invalid(self, mock_post):
        """
        test true-vault query method
        """

        def mock_is_last_name_valid(*args, **kwargs):
            return False

        flipt_member_id = '100318501'
        ref_response = {'benefit-plan-name': 'HSA Max Value Plan',
                        'domain': 'FLIPT001',
                        'plan-year': '2019',
                        'result': 'false',
                        'return-code': 'CB',
                        'message': 'Missing or Invalid Patient Last Name'
                        }
        mock_resp = self._mock_post_response(data=self._get_data())
        mock_post.return_value = mock_resp
        uec_obj = eligibility.UserEligibilityCheck(flipt_member_id, 'DEMOEYEE_LNRE9',
                                                   '1970-01-01 00:00:00', '2019-01-01')
        uec_obj._is_last_name_valid = mock_is_last_name_valid

        response = uec_obj.is_eligible()
        self.assertEqual(response, ref_response)

    @mock.patch('requests.post')
    def test_is_eligible_is_dob_valid_invalid(self, mock_post):
        """
        test true-vault query method
        """

        def mock_is_dob_valid(*args, **kwargs):
            return False

        flipt_member_id = '100318501'
        ref_response = {'benefit-plan-name': 'HSA Max Value Plan',
                        'domain': 'FLIPT001',
                        'plan-year': '2019',
                        'result': 'false',
                        'return-code': 'CB',
                        'message': 'Missing or Invalid Patient Last Name'
                        }
        mock_resp = self._mock_post_response(data=self._get_data())
        mock_post.return_value = mock_resp
        uec_obj = eligibility.UserEligibilityCheck(flipt_member_id, 'DEMOEMPLOYEE_LN9',
                                                   '1975-01-01 00:00:00', '2019-01-01')
        uec_obj._is_dob_valid = mock_is_dob_valid

        response = uec_obj.is_eligible()
        self.assertEqual(response, ref_response)

    def test_is_primary_user_valid(self):
        """
        eligibility: check primary user
        """
        uec_obj = eligibility.UserEligibilityCheck('ID01', 'FOO', '1970-04-25 00:00:00',
                                                   '2019-01-01')
        result = uec_obj._is_primary_user(person_code='01')
        self.assertEqual(result, True)

    def test_is_primary_user_negative(self):
        """
                eligibility: check if user is primary user
        """
        uec_obj = eligibility.UserEligibilityCheck('ID01', 'FOO', '1970-04-25 00:00:00',
                                                   '2019-01-01')
        result = uec_obj._is_primary_user(person_code='02')
        self.assertEqual(result, False)

    def test_is_coverage_effective(self):
        """
            eligibility: check status for inactive user
        """
        user = {'coverage_effective_date': '2019-01-01 00:00:00',
                'coverage_termination_date': '2019-12-31 23:59:59'}
        uec_obj = eligibility.UserEligibilityCheck('ID01', 'FOO', '1970-04-25 00:00:00',
                                                   '2019-06-01')
        result = uec_obj._is_coverage_effective(user)
        self.assertEqual(result, True)

    def test_if_not_coverage_effective(self):
        """
            eligibility: check status for inactive user
        """
        user = {'coverage_effective_date': '2019-01-01 00:00:00',
                'coverage_termination_date': '2019-12-31 23:59:59'}
        uec_obj = eligibility.UserEligibilityCheck('ID01', 'FOO', '1970-04-25 00:00:00',
                                                   '2020-01-01')
        result = uec_obj._is_coverage_effective(user)
        self.assertEqual(result, False)

    def test_is_last_name_valid(self):
        """
        eligibility: check status for inactive user
        """
        user = {'last_name': 'FOO'}
        uec_obj = eligibility.UserEligibilityCheck('ID01', 'FOO', '1970-04-25 00:00:00',
                                                   '2020-01-01')
        result = uec_obj._is_last_name_valid(user)
        self.assertEqual(result, True)

    def test_is_last_name_invalid(self):
        """
        eligibility: check status for inactive user
        """
        user = {'last_name': 'BAR'}
        uec_obj = eligibility.UserEligibilityCheck('ID01', 'FOO', '1970-04-25 00:00:00',
                                                   '2020-01-01')
        result = uec_obj._is_last_name_valid(user)
        self.assertEqual(result, False)

    def test_is_dob_valid(self):
        user = {'date_of_birth': '1970-04-25 00:00:00'}
        uec_obj = eligibility.UserEligibilityCheck('ID01', 'FOO', '1970-04-25 00:00:00',
                                                   '2020-01-01')
        result = uec_obj._is_dob_valid(user)
        self.assertEqual(result, True)

    def test_is_dob_invalid(self):
        user = {'date_of_birth': '1970-04-25 00:00:00'}
        uec_obj = eligibility.UserEligibilityCheck('ID01', 'FOO', '1974-04-25 00:00:00',
                                                   '2020-01-01')
        result = uec_obj._is_dob_valid(user)
        self.assertEqual(result, False)

    def test_get_dependent_info(self):
        user = {'first_name': 'foo', 'dependents': [
            {'first_name': 'bar', 'person_code': '02'}]}
        uec_obj = eligibility.UserEligibilityCheck('ID02', 'foo', '1974-04-25 00:00:00',
                                                   '2020-01-01')
        dependent = uec_obj._get_dependent_info(user, '02')
        assert dependent

    def test_get_dependent_info_invalid(self):
        user = {'first_name': 'foo', 'dependents': [
            {'first_name': 'bar', 'person_code': '02'}]}
        uec_obj = eligibility.UserEligibilityCheck('ID03', 'foo', '1974-04-25 00:00:00',
                                                   '2020-01-01')
        dependent = uec_obj._get_dependent_info(user, '03')
        assert dependent is None

    def test_get_dependent_info_no_dependents(self):
        """
        None if no dependents for user
        """
        user = {"name": "foo"}
        uec_obj = eligibility.UserEligibilityCheck('ID03', 'foo', '1974-04-25 00:00:00',
                                                   '2020-01-01')
        dependent = uec_obj._get_dependent_info(user, '02')
        assert dependent is None


if __name__ == '__main__':
    unittest.main()
