import unittest
from app.service.api_service import ClaimProcessor
from app.models.claimrequest import ClaimRequest
from app.models.b1claimrequest import B1ClaimRequest


class TestRequestClaim(unittest.TestCase):

    def test_determine_valid_transaction_type(self):
        '''
        test if transaction type correctly determined
        '''

        requestdata = '610442D0B1          1010000000071   20190221XXX0100AAA    AM04 C2333224444931101  AM01 CY100095801 C419680311 C51 CAHEMANT CBKUMAR C701~  AM07 EM1 D2123450234567 E103 D700078010409 E70000100000 D5030 D61 DK07 C802 EU01 EV11111111111  AM11 DX00001000 DU0000220 DN00  AM03 EZ01 DB1234567893    AM05 4C1 5C01 HB1 HC01 DV00001100'

        obj = ClaimRequest(requestdata)
        obj.routeRequest()
        self.assertEqual(isinstance(obj.requestobj,B1ClaimRequest), True)

    def test_determine_invalid_transaction_type(self):
        '''
        test if transaction type correctly determined
        '''

        requestdata = '610442D0A1          1010000000071   20190221XXX0100AAA    AM04 C2333224444931101  AM01 CY100095801 C419680311 C51 CAHEMANT CBKUMAR C701~  AM07 EM1 D2123450234567 E103 D700078010409 E70000100000 D5030 D61 DK07 C802 EU01 EV11111111111  AM11 DX00001000 DU0000220 DN00  AM03 EZ01 DB1234567893    AM05 4C1 5C01 HB1 HC01 DV00001100'

        obj = ClaimRequest(requestdata)
        obj.routeRequest()
        self.assertEqual(obj.requestobj,None)

    def test_request_parsing(self):
        '''
        test if request data has been parsed correctly
        '''

        
        requestdata = '610442D0B1          1010000000071   20190221XXX0100AAA    AM04 C2333224444931101  AM01 CY100095801 C419680311 C51 CAHEMANT CBKUMAR C701~  AM07 EM1 D2123450234567 E103 D700078010409 E70000100000 D5030 D61 DK07 C802 EU01 EV11111111111  AM11 DX00001000 DU0000220 DN00  AM03 EZ01 DB1234567893    AM05 4C1 5C01 HB1 HC01 DV00001100'

        result = {"type": "b1claimrequest", "bin_number": "610442", "version": "D0", "transaction_code": "B1", "processor_control_number": "", "transaction_count": "1", "service_provider_id_qualifier": "01", "service_provider_id": "0000000071", "date_of_service": "20190221", "software_vendor": "XXX0100AAA", "cardholder_id": "333224444931101", "cardholder_first_name": "", "cardholder_last_name": "", "home_plan": "", "plan_id": "", "eligibility_clarification_code": "", "group_id": "", "person_code": "", "patient_relationship_code": "", "medigap_id": "", "medicaid_indicator": "", "provider_accept_assignment_indicator": "", "cms_part_d_defined_qualified_facility": "", "medicaid_id_number": "", "patient_id_qualifier": "", "patient_id": "100095801", "date_of_birth": "19680311", "patient_gender_code": "1", "patient_first_name": "HEMANT", "patient_last_name": "KUMAR", "patient_street_address": "", "patient_city_address": "", "patient_state_address": "", "patient_zip_code": "", "patient_phone_number": "", "place_of_service": "01~", "employer_id": "", "pregnancy_indicator": "", "patient_email_address": "", "patient_residence": "", "prescription_reference_number_qualifier": "1", "prescription_reference_number": "123450234567", "product_id_qualifier": "03", "product_id": "00078010409", "associated_prescription_reference_number": "", "associated_prescription_date": "", "procedure_modifier_code_count": "", "procedure_modifier_code": "", "quantity_dispensed": "0000100000", "fill_number": "", "days_supply": "030", "compound_code": "1", "product_selection_code": "", "date_prescription_written": "", "number_of_refills_authorized": "", "prescription_origin_code": "", "submission_clarification_code_count": "", "submission_clarification_code": "07", "other_coverage_code": "02", "special_packaging_indicator": "", "originally_prescribed_product_id_qualifier": "", "originally_prescribed_product_code": "", "originally_prescribed_quantity": "", "scheduled_prescription_id_number": "", "unit_of_measure": "", "level_of_service": "", "prior_authorization_type_code": "01", "prior_authorization_number_submitted": "11111111111", "intermediary_authorization_type_id": "", "intermediary_authorization_id": "", "dispensing_status": "", "quantity_intended_dispensed": "", "days_supply_intended_dispensed": "", "delay_reason_code": "", "patient_assignment_indicator": "", "route_of_administration": "", "compound_type": "", "pharmacy_service_type": "", "ingredient_cost_submitted": "", "dispensing_fee_submitted": "", "patient_paid_amount_submitted": "00001000", "incentive_amount_submitted": "", "other_amount_claimed_submitted_count": "", "other_amount_claimed_summited_qualifier": "", "other_amount_claimed_submitted": "", "flat_sales_tax_amount_submitted": "", "percentage_sales_tax_amount_submitted": "", "percentage_sales_tax_rate_submitted": "", "percentage_sales_tax_basis_submitted": "", "usual_and_customary_charge": "", "gross_amount_due": "0000220", "basis_of_cost_determination": "00", "prescriber_id_qualifier": "01", "prescriber_id": "1234567893", "prescriber_last_name": "", "prescriber_phone_number": "", "primary_care_provider_id_qualifier": "", "primary_care_provider_id": "", "primary_care_provider_last_name": "", "prescriber_first_name": "", "prescriber_street_address": "", "prescriber_city_address": "", "prescriber_state_address": "", "prescriber_zip_code": "", "payment_count": "1", "other_payer_coverage_type": "01", "other_payer_id_qualifier": "", "other_payer_id": "", "other_payer_date": "", "internal_control_number": "", "other_payer_amount_paid_count": "1", "other_payer_amount_paid_qualifier": "01", "other_payer_amount_paid": "00001100", "other_payer_reject_count": "", "other_payer_reject_code": "", "other_payer_patient_responsibility_amount_count": "", "other_payer_patient_responsibility_amount_qualifier": "", "other_payer_patient_responsibility_amount": "", "benefit_stage_count": "", "benefit_stage_qualifier": "", "benefit_stage_amount": ""}


        obj = B1ClaimRequest(requestdata)
        parseddata = obj.getClaimData()
        
        self.assertDictEqual(parseddata,result)

    def test_phi_elimination(self):
        '''
        test if phi is eliminated from given data
        '''
        data = {"type": "b1claimrequest", "bin_number": "610442", "version": "D0", "transaction_code": "B1", "processor_control_number": "", "transaction_count": "1", "service_provider_id_qualifier": "01", "service_provider_id": "0000000071", "date_of_service": "20190221", "software_vendor": "XXX0100AAA", "cardholder_id": "333224444931101", "cardholder_first_name": "", "cardholder_last_name": "", "home_plan": "", "plan_id": "", "eligibility_clarification_code": "", "group_id": "", "person_code": "", "patient_relationship_code": "", "medigap_id": "", "medicaid_indicator": "", "provider_accept_assignment_indicator": "", "cms_part_d_defined_qualified_facility": "", "medicaid_id_number": "", "patient_id_qualifier": "", "patient_id": "100095801", "date_of_birth": "19680311", "patient_gender_code": "1", "patient_first_name": "HEMANT", "patient_last_name": "KUMAR", "patient_street_address": "", "patient_city_address": "", "patient_state_address": "", "patient_zip_code": "", "patient_phone_number": "", "place_of_service": "01~", "employer_id": "", "pregnancy_indicator": "", "patient_email_address": "", "patient_residence": "", "prescription_reference_number_qualifier": "1", "prescription_reference_number": "123450234567", "product_id_qualifier": "03", "product_id": "00078010409", "associated_prescription_reference_number": "", "associated_prescription_date": "", "procedure_modifier_code_count": "", "procedure_modifier_code": "", "quantity_dispensed": "0000100000", "fill_number": "", "days_supply": "030", "compound_code": "1", "product_selection_code": "", "date_prescription_written": "", "number_of_refills_authorized": "", "prescription_origin_code": "", "submission_clarification_code_count": "", "submission_clarification_code": "07", "other_coverage_code": "02", "special_packaging_indicator": "", "originally_prescribed_product_id_qualifier": "", "originally_prescribed_product_code": "", "originally_prescribed_quantity": "", "scheduled_prescription_id_number": "", "unit_of_measure": "", "level_of_service": "", "prior_authorization_type_code": "01", "prior_authorization_number_submitted": "11111111111", "intermediary_authorization_type_id": "", "intermediary_authorization_id": "", "dispensing_status": "", "quantity_intended_dispensed": "", "days_supply_intended_dispensed": "", "delay_reason_code": "", "patient_assignment_indicator": "", "route_of_administration": "", "compound_type": "", "pharmacy_service_type": "", "ingredient_cost_submitted": "", "dispensing_fee_submitted": "", "patient_paid_amount_submitted": "00001000", "incentive_amount_submitted": "", "other_amount_claimed_submitted_count": "", "other_amount_claimed_summited_qualifier": "", "other_amount_claimed_submitted": "", "flat_sales_tax_amount_submitted": "", "percentage_sales_tax_amount_submitted": "", "percentage_sales_tax_rate_submitted": "", "percentage_sales_tax_basis_submitted": "", "usual_and_customary_charge": "", "gross_amount_due": "0000220", "basis_of_cost_determination": "00", "prescriber_id_qualifier": "01", "prescriber_id": "1234567893", "prescriber_last_name": "", "prescriber_phone_number": "", "primary_care_provider_id_qualifier": "", "primary_care_provider_id": "", "primary_care_provider_last_name": "", "prescriber_first_name": "", "prescriber_street_address": "", "prescriber_city_address": "", "prescriber_state_address": "", "prescriber_zip_code": "", "payment_count": "1", "other_payer_coverage_type": "01", "other_payer_id_qualifier": "", "other_payer_id": "", "other_payer_date": "", "internal_control_number": "", "other_payer_amount_paid_count": "1", "other_payer_amount_paid_qualifier": "01", "other_payer_amount_paid": "00001100", "other_payer_reject_count": "", "other_payer_reject_code": "", "other_payer_patient_responsibility_amount_count": "", "other_payer_patient_responsibility_amount_qualifier": "", "other_payer_patient_responsibility_amount": "", "benefit_stage_count": "", "benefit_stage_qualifier": "", "benefit_stage_amount": ""}

        phi_fields = ['cardholder_first_name','cardholder_last_name','patient_first_name','patient_last_name','patient_street_address','patient_city_address','patient_state_address','patient_zip_code','patient_phone_number','patient_email_address','patient_residence']

        obj = ClaimRequest(None)
        result = obj.eliminatePHI(data)
        
        phi_found = False

        for field in phi_fields:
            if field in result:
                phi_found = True

        self.assertEquals(phi_found, False)

    

    


        

if __name__ == '__main__':
    unittest.main()








