#!/bin/bash
pip install virtualenv

virtualenv venv --always-copy

os=${OSTYPE//[0-9.-]*/}

case "$os" in
  msys)
    source ./venv/Scripts/activate
    ;;
  *)
    source ./venv/bin/activate
    ;;
esac
pip install -r requirements.txt
pip install -e .
