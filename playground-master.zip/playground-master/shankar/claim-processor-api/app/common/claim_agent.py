from app.models.b1_claim_request import B1ClaimRequest
from app.providers.claim_provider import ClaimProvider
from datetime import datetime
from autologging import logged, traced

@logged
class ClaimAgent:

    def __init__(self,claimdata):
        self.claimdata = str(claimdata)
        self.requestobj = None

    def routeRequest(self):

        requesttype = ''
        self.__log.info('Determining type of transaction')
        try:
            headerdata = str(self.claimdata.split('AM')[0])
            requesttype = str(headerdata)[8:10]
            self.__log.info('Transaction type is %s', requesttype)
        except Exception as _:
            self.__log.info('Could not determine transaction type')
            pass
        if requesttype == 'B1':
            self.requestobj = B1ClaimRequest(self.claimdata)
        
        '''
        elif requesttype == 'B2':
            self.requestobj = B2ClaimRequest(self.claimdata)
        elif requesttype == 'B3':
            self.requestobj = B3ClaimRequest(self.claimdata)
        elif requesttype == 'E1':
            self.requestobj = E1ClaimRequest(self.claimdata)
        '''
    def prepareClaimData(self):

        self.routeRequest()

        if self.requestobj is not None:
            parseddata = self.requestobj.getClaimData()
            self.__log.info('Data is parsed')
            parseddata = self.addFields(parseddata)
            finaldata = {}
            finaldata.update(parseddata)
            finaldata = self.eliminatePHI(finaldata)
            return parseddata,finaldata
        else:
            return None, None

    def eliminatePHI(self,parseddata):

        self.__log.info('Eliminating PHI from claim')

        phi_fields = ['cardholder_first_name','cardholder_last_name','patient_first_name','patient_last_name','patient_street_address','patient_city_address','patient_state_address','patient_zip_code','patient_phone_number','patient_email_address','patient_residence']

        for field in phi_fields:
            parseddata.pop(field,None)

        self.__log.info('Eliminated PHI from claim')
        return parseddata

    def addFields(self,parseddata):

        self.__log.info('Additional fields to be added')
        parseddata['received_date'] = datetime.now().isoformat()
        parseddata['response_date'] = ''
        parseddata['authorization_id'] = ''
        parseddata['response_code'] = ''
        parseddata['message'] = ''
        parseddata['sequence_number'] = ''
        '''
        fill_number - how to determine
        eligibility number - cardholderid[:-2] + person code 
        rx number - prescription_reference_number
        ''' 
        self.__log.info('Additional fields added')
        return parseddata

        
        


        

