from app.common.claim_agent import ClaimAgent
from app.service.claim_validation_service import ClaimValidation
from app.modules.member_eligibility.eligibility import UserEligibilityCheck
from datetime import datetime
from app.providers.claim_provider import ClaimProvider
from autologging import logged, traced
from flask_injector import inject
from app.models.claim import Claim
from app.models.b1_claim_request import B1ClaimRequest


@logged
class ClaimProcessor:

    def __init__(self, requestdata):
        self.requestdata = requestdata
        self.claim = ''

    @inject(data_provider=ClaimProvider)
    def adjudicateClaim(self, data_provider=ClaimProvider):

        self.__log.info('Entering the service layer')
        headerdata = str(self.requesdata.split('AM')[0])
        requesttype = str(headerdata)[8:10]

        if (requesttype == "B1"):
            self.claim = Claim()
            self.claim.ClaimRequest = B1ClaimRequest(self.requestdata)
            
        elif (requesttype == "B2"):
            pass
            # self.ClaimRequest =

        # parse the claimRequest
        # store it in couchdb claim object by jsonifying 
        # Validate the object
        # Member eligibility
        # Prescriber validation
        
        #claim, finaldata = request_obj.prepareClaimData()

        if claim != None:
            data_provider.saveClaim(data_provider, finaldata)
            cvalidobj = ClaimValidation(claim)
            rejectioncode, rejectionreason = cvalidobj.validateData(
                data_provider)
            print(rejectioncode, rejectionreason)
            self.__log.info('Claim validations done')

            if rejectioncode == '':
                self.__log.info(
                    'Data received is valid, now going into eligibility module')
                elig_obj = UserEligibilityCheck(claim['patient_id'], claim['patient_last_name'], datetime.strptime(claim['date_of_birth'], '%Y%m%d').strftime(
                    '%Y-%m-%d 00:00:00'), datetime.strptime(claim['date_of_service'], '%Y%m%d').strftime('%Y-%m-%d 00:00:00'),)
                result = elig_obj.is_eligible()
                self.__log.info(
                    'Eligibility Module check done, Result: %s', result)
                print('member elig', result)

        self.__log.info('Response prepared')
        return "610442D0B1          1010000000071   20120101XXX0100AAA    AM04 C2333224444931101  AM01 C419220402 C51 C701~  AM07 EM1 D2123450234567 E103 D700078010409 E70000100000 D5030 D61 DK07 C802 EU01 EV11111111111  AM11 DX00001000 DU0000220 DN00  AM03 EZ01 DB1234567893    AM05 4C1 5C01 HB1 HC01 DV00001100"
