from cerberus import Validator

class ClaimValidation:

    def __init__(self, claimdata):
        self.claimdata = claimdata
        self.schema = {}

    def validateData(self,data_provider):

        rejectioncode , rejectionreason = '', ''

        if self.claimdata['transaction_code'] == 'B1':
            rejectioncode , rejectionreason = self.b1ClaimValidations(data_provider)
        return rejectioncode, rejectionreason

    def b1ClaimValidations(self, data_provider):

            def verifyvalue(field, value, error):
                '''
                custom validator to verify value within the DB
                '''
                if str(value).strip()=='' or not data_provider.validateClaim(data_provider,field,value):
                    error(field, 'not present in DB')


            errorcodes = {"bin_number":['1','Missing or Invalid BIN'],
                           "version":['2','Missing or Invalid Version Number'],
                           "transaction_code":['3','Missing or Invalid Transaction Code'],
                           "transaction_count":['A9','Missing or Invalid Transaction Count'],
                           "service_provider_id_qualifier":['B2','Missing or Invalid Service Provider ID Qualifier'],
                           "service_provider_id":['5','Missing or Invalid Pharmacy Number'],
                           "date_of_service":['15','Missing or Invalid Date of Service'],
                           "software_vendor":['AK','Missing or Invalid Software Vendor/Certification ID'],
                           "cardholder_id":['7','Missing or Invalid Cardholder ID Number'],
                           "cardholder_first_name":['CA','Missing or Invalid Patient First Name'],
                           "cardholder_last_name":['CB','Missing or Invalid Patient Last Name'],
                           "date_of_birth":['','Date of Birth Missing'],
                           "patient_gender_code":['10','Missing or Invalid Patient Gender Code'],
                           "prescription_reference_number_qualifier":['EM','Missing or Invalid Prescription/Service Reference Number Qualifier'],
                           "prescription_reference_number":['EN','Missing or Invalid Associated Prescription/Service Reference Number'],
                           "product_id_qualifier":['EJ','Missing or Invalid Originally Prescribed Product/Service ID Qualifier'],
                           "product_id":['21','Missing or Invalid Product/Service ID'],
                           "days_supply":['19','Missing or Invalid Days Supply'],
                           "compound_code":['20','Missing or Invalid Compound Code'],
                           "patient_paid_amount_submitted":['DX','Missing or Invalid Patient Paid Amount Submitted'],
                           "gross_amount_due":['DU','Missing or Invalid Gross Amount Due']}        

            schema = {"type": {"type":"string","allowed":["b1claimrequest"]}, 
                      "bin_number": {"validator":verifyvalue}, 
                      "version": {"allowed":["D0"]}, 
                      "transaction_code": {"allowed":["B1"]}, 
                      "transaction_count": {"allowed":["1"]}, 
                      "service_provider_id_qualifier": {"allowed":["01"]}, 
                      "service_provider_id": {"minlength":10,"validator":verifyvalue}, 
                      "date_of_service": {"minlength":8,"maxlength":8}, 
                      "software_vendor": {"forbidden":[""]}, 
                      "cardholder_id": {"type":"string","maxlength":20}, 
                      "cardholder_first_name": {"type":"string","forbidden":[""]}, 
                      "cardholder_last_name": {"type":"string","forbidden":[""]}, 
                      "date_of_birth": {"minlength":8,"maxlength":8}, 
                      "patient_gender_code": {"allowed":["0","1","2"]},  "prescription_reference_number_qualifier": {"allowed":["1"]}, "prescription_reference_number": {"forbidden":[""]}, 
                      "product_id_qualifier": {"allowed":["03"]}, 
                      "product_id":{"validator":verifyvalue} , 
                      "days_supply": {"forbidden":[""]}, 
                      "compound_code": {"allowed":["1","2"]}, 
                      "patient_paid_amount_submitted": {"forbidden":[""]}, 
                      "gross_amount_due": {"forbidden":[""]}}
                      
            v = Validator(schema,allow_unknown=True)
            result = v.validate(self.claimdata)
            if not result:
                    errors = v.errors
                    for field,errorcode in errorcodes.items():
                            if field in errors:
                                    return errorcode[0],errorcode[1]
            return '',''


            

            
            
            