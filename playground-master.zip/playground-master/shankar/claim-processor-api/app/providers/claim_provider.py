from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from couchbase import FMT_JSON
import os
from injector import provider, inject, Module
from autologging import logged, traced
import configparser

config = configparser.SafeConfigParser(os.environ)
config.read('config.ini')
instance_type = config['GLOBAL']['INSTANCE_TYPE']
cluster = Cluster(config[instance_type]['CB_URL'])
authenticator = PasswordAuthenticator(config[instance_type]['CB_USER'], config[instance_type]['CB_PWD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(config[instance_type]['CB_BUCKET'])

@logged
class ClaimProvider(Module):

    @inject
    def __init__(self):
        self.__log.info('Creating couchbase claim object')

    @provider
    def saveClaim(self,data) -> str:
        
        self.__log.info('Saving claim data')
        #docid = str(cb.counter('docid',delta=1).value)
        #response = cb.upsert(docid,data, format=FMT_JSON)
        #self.__log.info('Claim data saved to %s',response.key)
        return 'Done'

    @provider
    def validateClaim(self,attribute_name,attribute_value) -> bool:

        
        if attribute_name == 'bin_number':
            db_attribute = 'rxbin'
            query = N1QLQuery('Select rxbin from `'+config[instance_type]['CB_BUCKET']+'` where type="claim_processor" and rxbin=$v',v=attribute_value)
        elif attribute_name == 'service_provider_id':
            db_attribute = 'pharmacynpi'
            query = N1QLQuery('Select pharmacynpi from `'+config[instance_type]['CB_BUCKET']+'` where type="cp_pharmacy" and pharmacynpi=$v',v=attribute_value)
        elif attribute_name == 'product_id':
            db_attribute = 'ndc'
            query = N1QLQuery('Select ndc from `'+config[instance_type]['CB_BUCKET']+'` where type="ndc_drugs" and ndc=$v',v=attribute_value)
        for result in cb.n1ql_query(query):
            if attribute_value == result[db_attribute]:
                return True
        
        return False
            

