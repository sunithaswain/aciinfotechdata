from flask import request, Flask, Response
from app.service.claim_processor_service import ClaimProcessor
from app.providers import claim_provider
from injector import Binder
from flask_injector import FlaskInjector
from autologging import logged, traced, TRACE
import logging, time, threading
from datetime import datetime

def configure(binder:Binder) -> Binder:
    binder.bind(
        interface = claim_provider.ClaimProvider,
        to = claim_provider.ClaimProvider()
    )

app = Flask(__name__)

@app.route('/fliptclaimprocessor',methods = ['POST'])
@logged
def incomingclaim():

    incomingclaim._log.info('Claim Requested')
    cp = ClaimProcessor(request.data.decode("utf-8"))
    responsestring = cp.adjudicateClaim()
    incomingclaim._log.info('Claim Data Processed ')
    resp = Response(responsestring, status=200, mimetype='application/text')
    incomingclaim._log.info('Claim Response to be returned')
    return resp


if __name__=='__main__':
    logging.basicConfig(level=logging.DEBUG, filename='Log.log',filemode='w',format="%(threadName)s:%(levelname)s:%(asctime)s:%(name)s:%(funcName)s:%(message)s",datefmt='%d-%m-%y %H:%M:%S')
    FlaskInjector(app=app,modules=[configure])
    app.run(threaded=True,debug=True)


