import json
import os
import re
import base64
import requests
import configparser
from requests.auth import HTTPBasicAuth

config = configparser.SafeConfigParser(os.environ)
config.read('../config.ini')
TRUEVAULT_API_KEY = config['GLOBAL']['TV_API_KEY']

EMP_STATUS = ["Active", "Cobra"]
URI = 'https://api.truevault.com/v1/users/search'


class UserEligibilityCheck(object):
    def __init__(self, flipt_member_id, last_name, date_of_birth, date_of_service):
        self.flipt_member_id = str(flipt_member_id)[:-2]
        self.person_code = str(flipt_member_id)[-2:]
        # extract only alphabets
        self.last_name = re.sub('[^a-zA-Z]', '', last_name)
        self.date_of_birth = date_of_birth
        self.date_of_service = str(date_of_service) + ' 00:00:00'
        self.primary_person_code = '01'

    # def _is_emp_active(self, user):
    #     return True if user['employment_status'] in EMP_STATUS else False

    def _is_primary_user(self, person_code):
        return True if person_code == self.primary_person_code else False

    def _is_coverage_effective(self, user):
        return True if (user['coverage_effective_date']
                        <= self.date_of_service
                        <= user['coverage_termination_date']) else False

    def _is_last_name_valid(self, user):
        return True if self.last_name == user['last_name'] else False

    def _is_dob_valid(self, user):
        return True if self.date_of_birth == user['date_of_birth'] else False

    def _get_dependent_info(self, user, person_code):
        """
        :param user:
        :param person_code:
        :return: dependent info(dict)
        """
        for dependent in user.get('dependents', []):
            if dependent['person_code'] == person_code:
                return dependent

    def is_eligible(self):
        """
        :param data: expects data in str format with required 5 params, checks if the user is eligible for
                        the claim.
        :return: returns TRUE or FALSE depending upon the input data
        """
        def _prepare_response(user, err_code, err_msg):
            if err_code:
                res = {'result': 'false',
                       'return-code': err_code,
                       'message': err_msg
                       }
                if user:
                    res.update({'benefit-plan-name': user['benefit_plan_name'],
                                'domain': user['domain_name'],
                                'plan-year': self.date_of_service[:4]})
                return res
            else:
                return {'benefit-plan-name': user['benefit_plan_name'],
                        'domain': user['domain_name'],
                        'result-code': '0',
                        'message': 'success',
                        'plan-year': self.date_of_service[:4]}

        error_code = None
        err_msg = ''
        user = self.search_user()
        if not user:
            err_msg = "Non-Matched Cardholder ID"
            return _prepare_response(user, "52", err_msg)

        active_user = user
        if not self._is_primary_user(self.person_code):
            active_user = self._get_dependent_info(user, self.person_code)

        if not self._is_coverage_effective(active_user):
            return _prepare_response(user, "15", "Missing or invalid date of service")
        if not self._is_last_name_valid(active_user):
            return _prepare_response(user, "CB", "Missing or Invalid Patient Last Name")
        if not self._is_dob_valid(active_user):
            return _prepare_response(user, "9", "Missing or Invalid Birth Date")

        return _prepare_response(user, error_code, err_msg)

    def search_user(self):
        """
        :return: This functions takes the above params as input and creates a curl command and post
                  request to true-vault with base64encoding.
        """
        search_option = {'full_document': True,
                         'filter': {
                             'flipt_person_id': {'type': 'eq', 'value': self.flipt_member_id,
                                                 'case_sensitive': False},
                             '$tv.status': {'type': 'eq', 'value': 'ACTIVATED'}}, 'filter_type': 'and'}
        search_opt = base64.b64encode(str.encode(json.dumps(search_option)))
        search_json = {'search_option': search_opt}
        res = requests.post(URI, auth=HTTPBasicAuth(TRUEVAULT_API_KEY, ''),
                            data=search_json)

        response = res.json()

        if 'error' in response:
            err_msg = str(response['error'])
            return

        if (res.status_code != 200 or 'data' not in response or
                (res.status_code == 200 and not response['data'].get('documents'))):
            return

        return json.loads(base64.b64decode(response['data']['documents'][0]['attributes']).
                          decode('utf-8'))


if __name__ == "__main__":
    uec_obj = UserEligibilityCheck(
        '100272101', 'KUMAR', '1968-03-11 00:00:00', '2019-01-01')
    uec_obj.is_eligible()
