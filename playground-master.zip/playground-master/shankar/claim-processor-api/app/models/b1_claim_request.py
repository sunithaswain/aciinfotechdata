from parse import search
from flask_injector import inject
from app.providers.Couchbase import Couchbase
from autologging import logged


@logged
class B1ClaimRequest:

        def __init__(self,rawclaim):
                self.rawdata = str(rawclaim)+' '
                self.parsedclaim = {}
                self.parsedclaim['type'] = 'b1claimrequest'
                self.header = B1ClaimRequest.Header("")
                self.insuranceseg = B1ClaimRequest.InsuranceSegment("")
                self.patientseg = B1ClaimRequest.PatientSegment("")
                self.claimsseg = B1ClaimRequest.ClaimsSegment("")
                self.pricingseg = B1ClaimRequest.PricingSegment("")
                self.prescriberseg = B1ClaimRequest.PrescriberSegment("")
                self.cobseg = B1ClaimRequest.COBSegment("")
                

        def setAttributes(self):

                split_segments=self.rawdata.split('AM')
                self.__log.info('Splitting claim into segments')
                try:
                        headerdata = split_segments[0]
                        self.header = B1ClaimRequest.Header(headerdata)
                except Exception as _:
                        pass
                for segment in split_segments[1:]:
                        if segment[0:2] == "05":
                                self.cobseg = B1ClaimRequest.COBSegment(segment[3:])
                        elif segment[0:2] == "03":
                                self.prescriberseg = B1ClaimRequest.PrescriberSegment(segment[3:])
                        elif segment[0:2] == "11":
                                self.pricingseg = B1ClaimRequest.PricingSegment(segment[3:])
                        elif segment[0:2] == "07":
                                self.claimsseg = B1ClaimRequest.ClaimsSegment(segment[3:])
                        elif segment[0:2] == "01":
                                self.patientseg = B1ClaimRequest.PatientSegment(segment[3:])
                        elif segment[0:2] == "04":
                                self.insuranceseg = B1ClaimRequest.InsuranceSegment(segment[3:])
                
                self.header.setHeaderAttributes()
                self.insuranceseg.setAttributes() 
                self.patientseg.setAttributes() 
                self.claimsseg.setAttributes() 
                self.pricingseg.setAttributes()
                self.prescriberseg.setAttributes()
                self.cobseg.setAttributes()

        def getClaimData(self):

                self.setAttributes()
                self.__log.info('Combining individually parsed segments together')
                self.parsedclaim.update(self.header.__dict__)
                self.parsedclaim.update(self.insuranceseg.__dict__) 
                self.parsedclaim.update(self.patientseg.__dict__) 
                self.parsedclaim.update(self.claimsseg.__dict__) 
                self.parsedclaim.update(self.pricingseg.__dict__)
                self.parsedclaim.update(self.prescriberseg.__dict__)
                self.parsedclaim.update(self.cobseg.__dict__)
                del self.parsedclaim['rawdata']
                return self.parsedclaim


        @logged
        class Header:

                def __init__(self,rawdata):
                        self.rawdata = rawdata
                        self.bin_number = ""
                        self.version = ""
                        self.transaction_code = ""
                        self.processor_control_number = ""
                        self.transaction_count = ""
                        self.service_provider_id_qualifier = ""
                        self.service_provider_id = ""
                        self.date_of_service = ""
                        self.software_vendor = ""

                def setHeaderAttributes(self):

                        self.__log.info('Setting header attributes the service layer')
                        position_attributes = {'bin_number' : [0,6], 'version' : [6,8],            'transaction_code' : [8,10], 'processor_control_number' : [10,20],               'transaction_count' : [20,21], 'service_provider_id_qualifier' : [21,23],               'service_provider_id' : [23,36], 'date_of_service' : [36,44],                        'software_vendor' : [44,59]}
                        for key,value in position_attributes.items():
                                try:
                                       setattr(self,key,self.rawdata[value[0]:value[1]].strip())
                                except Exception as _:
                                        self.__log.info('Missing attribute %s in header', key)
                                        continue  
        @logged 
        class InsuranceSegment:

                def __init__(self,rawdata):
                        self.rawdata = rawdata
                        self.cardholder_id = ""
                        self.cardholder_first_name = ""
                        self.cardholder_last_name = ""
                        self.home_plan = ""
                        self.plan_id = ""
                        self.eligibility_clarification_code = ""
                        self.group_id = ""
                        self.person_code = ""
                        self.patient_relationship_code = ""
                        self.medigap_id = ""
                        self.medicaid_indicator = ""
                        self.provider_accept_assignment_indicator = ""
                        self.cms_part_d_defined_qualified_facility = ""
                        self.medicaid_id_number = ""

                def setAttributes(self):

                        self.__log.info('Setting insurance segment attributes the service layer')
                        code_attributes = {'C2':'cardholder_id','CC':'cardholder_first_name','CD':'cardholder_last_name','CE':'home_plan','FO':'plan_id','C9':'eligibility_clarification_code','C1':'group_id','C3':'person_code','C6':'patient_relationship_code','2A':'medigap_id','2B':'medicaid_indicator','2D':'provider_accept_assignment_indicator','G2':'cms_part_d_defined_qualified_facility','N5':'medicaid_id_number'}
                        for key,value in code_attributes.items():
                                try:
                                        setattr(self,value,search(key+"{} ",self.rawdata)[0].strip())
                                except Exception as _:
                                        self.__log.info('Missing attribute %s in insurance segment', value)
                                        continue  
               
        @logged       
        class PatientSegment:

                def __init__(self,rawdata):
                        self.rawdata = rawdata
                        self.patient_id_qualifier = ""
                        self.patient_id = ""
                        self.date_of_birth = ""
                        self.patient_gender_code = ""
                        self.patient_first_name = ""
                        self.patient_last_name = ""
                        self.patient_street_address = ""
                        self.patient_city_address = ""
                        self.patient_state_address = ""
                        self.patient_zip_code = ""
                        self.patient_phone_number = ""
                        self.place_of_service = ""
                        self.employer_id = ""
                        self.pregnancy_indicator = ""
                        self.patient_email_address = ""
                        self.patient_residence = ""

                def setAttributes(self):

                        self.__log.info('Setting patient attributes the service layer')
                        code_attributes = {'CX':'patient_id_qualifier','CY':'patient_id','C4':'date_of_birth','C5':'patient_gender_code','CA':'patient_first_name','CB':'patient_last_name','CM':'patient_street_address','CN':'patient_city_address','CO':'patient_state_address','CP':'patient_zip_code','CQ':'patient_phone_number','C7':'place_of_service','CZ':'employer_id','2C':'pregnancy_indicator','HN':'patient_email_address','4X':'patient_residence'}
                        for key,value in code_attributes.items():
                                try:
                                        setattr(self,value,search(key+"{} ",self.rawdata)[0].strip())
                                except Exception as _:
                                        self.__log.info('Missing attribute %s in patient segment', key)
                                        continue    
        @logged
        class ClaimsSegment:

                def __init__(self,rawdata):
                        self.rawdata = rawdata
                        self.prescription_reference_number_qualifier = ""
                        self.prescription_reference_number = ""
                        self.product_id_qualifier = ""
                        self.product_id = ""
                        self.associated_prescription_reference_number = ""
                        self.associated_prescription_date = ""
                        self.procedure_modifier_code_count = ""
                        self.procedure_modifier_code = ""
                        self.quantity_dispensed = ""
                        self.fill_number = ""
                        self.days_supply = ""
                        self.compound_code = ""
                        self.product_selection_code = ""
                        self.date_prescription_written = ""
                        self.number_of_refills_authorized = ""
                        self.prescription_origin_code = ""
                        self.submission_clarification_code_count = ""
                        self.submission_clarification_code = ""
                        self.other_coverage_code = ""
                        self.special_packaging_indicator = ""
                        self.originally_prescribed_product_id_qualifier = ""
                        self.originally_prescribed_product_code = ""
                        self.originally_prescribed_quantity = ""
                        self.scheduled_prescription_id_number = ""
                        self.unit_of_measure = ""
                        self.level_of_service = ""
                        self.prior_authorization_type_code = ""
                        self.prior_authorization_number_submitted = ""
                        self.intermediary_authorization_type_id = ""
                        self.intermediary_authorization_id = ""
                        self.dispensing_status = ""
                        self.quantity_intended_dispensed = ""
                        self.days_supply_intended_dispensed = ""
                        self.delay_reason_code = ""
                        self.patient_assignment_indicator = ""
                        self.route_of_administration = ""
                        self.compound_type = ""
                        self.pharmacy_service_type = ""

                def setAttributes(self):

                        self.__log.info('Setting claims attributes the service layer')
                        code_attributes = {'EM':'prescription_reference_number_qualifier','D2':'prescription_reference_number','E1':'product_id_qualifier','D7':'product_id','EN':'associated_prescription_reference_number','EP':'associated_prescription_date','SE':'procedure_modifier_code_count','ER':'procedure_modifier_code','E7':'quantity_dispensed','D3':'fill_number','D5':'days_supply','D6':'compound_code','D8':'product_selection_code','DE':'date_prescription_written','DF':'number_of_refills_authorized','DJ':'prescription_origin_code','NX':'submission_clarification_code_count','DK':'submission_clarification_code','C8':'other_coverage_code','DT':'special_packaging_indicator','EJ':'originally_prescribed_product_id_qualifier','EA':'originally_prescribed_product_code','EB':'originally_prescribed_quantity','EK':'scheduled_prescription_id_number','28':'unit_of_measure','DI':'level_of_service','EU':'prior_authorization_type_code','EV':'prior_authorization_number_submitted','EW':'intermediary_authorization_type_id','EX':'intermediary_authorization_id','HD':'dispensing_status','HF':'quantity_intended_dispensed','HG':'days_supply_intended_dispensed','NV':'delay_reason_code','MT':'patient_assignment_indicator','E2':'route_of_administration','G1':'compound_type','U7':'pharmacy_service_type'}
                        for key,value in code_attributes.items():
                                try:
                                        setattr(self,value,search(key+"{} ",self.rawdata)[0].strip())
                                except Exception as _:
                                        self.__log.info('Missing attribute %s in claims segment', key)
                                        continue    
        @logged            
        class PricingSegment:

                def __init__(self,rawdata):
                        self.rawdata = rawdata
                        self.ingredient_cost_submitted = ""
                        self.dispensing_fee_submitted = ""
                        self.patient_paid_amount_submitted = ""
                        self.incentive_amount_submitted = ""
                        self.other_amount_claimed_submitted_count = ""
                        self.other_amount_claimed_summited_qualifier = ""
                        self.other_amount_claimed_submitted = ""
                        self.flat_sales_tax_amount_submitted = ""
                        self.percentage_sales_tax_amount_submitted = ""
                        self.percentage_sales_tax_rate_submitted = ""
                        self.percentage_sales_tax_basis_submitted = ""
                        self.usual_and_customary_charge = ""
                        self.gross_amount_due = ""
                        self.basis_of_cost_determination = ""

                def setAttributes(self):

                        self.__log.info('Setting pricing attributes the service layer')
                        code_attributes = {'D9':'ingredient_cost_submitted','DC':'dispensing_fee_submitted','DX':'patient_paid_amount_submitted','E3':'incentive_amount_submitted','H7':'other_amount_claimed_submitted_count','H8':'other_amount_claimed_summited_qualifier','H9':'other_amount_claimed_submitted','HA':'flat_sales_tax_amount_submitted','GE':'percentage_sales_tax_amount_submitted','HE':'percentage_sales_tax_rate_submitted','JE':'percentage_sales_tax_basis_submitted','DQ':'usual_and_customary_charge','DU':'gross_amount_due','DN':'basis_of_cost_determination'}
                        for key,value in code_attributes.items():
                                try:
                                        setattr(self,value,search(key+"{} ",self.rawdata)[0].strip())
                                except Exception as _:
                                        self.__log.info('Missing attribute %s in pricing segment', key)
                                        continue    
        @logged
        class PrescriberSegment:

                def __init__(self,rawdata):
                        self.rawdata = rawdata
                        self.prescriber_id_qualifier = ""
                        self.prescriber_id = ""
                        self.prescriber_last_name = ""
                        self.prescriber_phone_number = ""
                        self.primary_care_provider_id_qualifier = ""
                        self.primary_care_provider_id = ""
                        self.primary_care_provider_last_name = ""
                        self.prescriber_first_name = ""
                        self.prescriber_street_address = ""
                        self.prescriber_city_address = ""
                        self.prescriber_state_address = ""
                        self.prescriber_zip_code = ""

                        
                def setAttributes(self):

                        self.__log.info('Setting prescriber attributes the service layer')
                        code_attributes = {'EZ':'prescriber_id_qualifier','DB':'prescriber_id','DR':'prescriber_last_name','PM':'prescriber_phone_number','2E':'primary_care_provider_id_qualifier','DL':'primary_care_provider_id','4E':'primary_care_provider_last_name','2J':'prescriber_first_name','2K':'prescriber_street_address','2M':'prescriber_city_address','2N':'prescriber_state_address','2P':'prescriber_zip_code'}
                        for key,value in code_attributes.items():
                                try:
                                        setattr(self,value,search(key+"{} ",self.rawdata)[0].strip())
                                except Exception as _:
                                        self.__log.info('Missing attribute %s in prescriber segment', key)
                                        continue    
        @logged
        class COBSegment:

                def __init__(self,rawdata):
                        self.rawdata = rawdata
                        self.payment_count = ""
                        self.other_payer_coverage_type = ""
                        self.other_payer_id_qualifier = ""
                        self.other_payer_id = ""
                        self.other_payer_date = ""
                        self.internal_control_number = ""
                        self.other_payer_amount_paid_count = ""
                        self.other_payer_amount_paid_qualifier = ""
                        self.other_payer_amount_paid = ""
                        self.other_payer_reject_count = ""
                        self.other_payer_reject_code = ""
                        self.other_payer_patient_responsibility_amount_count = ""
                        self.other_payer_patient_responsibility_amount_qualifier = ""
                        self.other_payer_patient_responsibility_amount = ""
                        self.benefit_stage_count = ""
                        self.benefit_stage_qualifier = ""
                        self.benefit_stage_amount = ""
                        
                def setAttributes(self):

                        self.__log.info('Setting COB segment attributes the service layer')
                        code_attributes = {'4C':'payment_count','5C':'other_payer_coverage_type','6C':'other_payer_id_qualifier','7C':'other_payer_id','E8':'other_payer_date','A7':'internal_control_number','HB':'other_payer_amount_paid_count','HC':'other_payer_amount_paid_qualifier','DV':'other_payer_amount_paid','5E':'other_payer_reject_count','6E':'other_payer_reject_code','NR':'other_payer_patient_responsibility_amount_count','NP':'other_payer_patient_responsibility_amount_qualifier','NQ':'other_payer_patient_responsibility_amount','MU':'benefit_stage_count','MV':'benefit_stage_qualifier','MW':'benefit_stage_amount'}
                        for key,value in code_attributes.items():
                                try:
                                        setattr(self,value,search(key+"{} ",self.rawdata)[0].strip())
                                except Exception as _:
                                        self.__log.info('Missing attribute %s in COB segment', key)
                                        continue    
                
        

'''
obj = B1ClaimRequest('610442D0B1          1010000000071   20190221XXX0100AAA    AM04 C2333224444931101  AM01 CY100095801 C419680311 C51 CAHEMANT CBKUMAR C701~  AM07 EM1 D2123450234567 E103 D700078010409 E70000100000 D5030 D61 DK07 C802 EU01 EV11111111111  AM11 DX00001000 DU0000220 DN00  AM03 EZ01 DB1234567893    AM05 4C1 5C01 HB1 HC01 DV00001100')
pd = obj.getClaimData()
import json
with open('data.json', 'w') as fp:
        json.dump(pd, fp)
'''




        