
class Claim:

    def __init__(self):
        self.auth_id = ''  # generate uniqueId
        self.startDate = ''  # set start date
        self.endDate = ''
        self.ClaimRequest = ''
        self.ClaimResponse = ''
