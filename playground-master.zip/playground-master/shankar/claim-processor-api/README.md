# b2b-claim-processor-api
claim processor api

Installation:
1. Clone the repository 
2. run command "source setup.sh"

Run the REST API:
1. python app/index.py
