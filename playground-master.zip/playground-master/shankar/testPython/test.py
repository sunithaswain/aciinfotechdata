import os
from datetime import datetime
import sys
import pprint
import json
import pandas as pd
import socket
#import requests

from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from couchbase import FMT_JSON
import couchbase.subdocument as SD



cluster = Cluster('couchbase://13.90.231.152')
#cluster = Cluster('couchbase://10.40.2.8')
bucket_name =  'dev-fliptrx-app'
authenticator = PasswordAuthenticator( 'dev-backend.python-scripts',  'befog-dialysis-exemplar-tori')
cluster.authenticate(authenticator)
cb = cluster.open_bucket(bucket_name)

query = N1QLQuery('Select * from `dev-fliptrx-app` where type="prescription" and create_date like "%2019%" and deductible_remaining = "0" and drug_deductible_exempt != "true"')
for drugrow in cb.n1ql_query(query):
   sorted(drugrow)
   print(json.dumps(drugrow, indent=4))
