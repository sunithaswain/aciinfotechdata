from djongo import models


class Post(models.Model):
    title = models.CharField(max_length=255)
    text = models.TextField()
