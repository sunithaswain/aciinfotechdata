import json
from bson import ObjectId
from flask import Flask
from flask import jsonify
from flask import request
from flask_pymongo import PyMongo

app = Flask(__name__)

app.config['MONGO_DBNAME'] = 'sample_mflix'
app.config['MONGO_URI'] = 'mongodb+srv://testuser1:Password1@alexcluster1-rmwmz.gcp.mongodb.net/sample_mflix?retryWrites=true'
mongo = PyMongo(app)


class JSONEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, ObjectId):
            return str(o)
        return json.JSONEncoder.default(self, o)


@app.route("/")
def home_page():
    online_users = mongo.db.users.find()
    users = []
    for sil in online_users:
        users.append({'username': sil['username']})
    return 'hello'


@app.route('/movies', methods=['GET'])
def get_all_movies():

    movie = mongo.db.movies
    output = []
    for sil in movie.find():
        output.append({
            'title': sil['title'],
            'year': sil['year']
        })
    return jsonify(output)


@app.route('/movies/<title>', methods=['GET'])
def get_one_movie(title):
    movie = mongo.db.movies
    return_json = []
    find_movie = movie.find_one({'title': title})
    find_movie['_id'] = str(find_movie['_id'])
    return_json.append(find_movie)

    if return_json:
        return jsonify(return_json)
    else:
        return "No such name"


@app.route('/movies', methods=['POST'])
def add_movie():
    movie = mongo.db.movies
    import pdb;pdb.set_trace()
    title = request.json['title']
    year = request.json['year']
    movie_id = movie.insert_one({'title': title, 'year': year})
    new_movie = movie.find_one({'_id': movie_id})
    output = {'title': new_movie['title'], 'year': new_movie['year']}
    return jsonify({'result': output})


if __name__ == '__main__':
    app.run(debug=True)
