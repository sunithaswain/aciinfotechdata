import json
import logging
import base64
import requests
import os

from requests.auth import HTTPBasicAuth

TRUEVAULT_API_KEY = os.environ['TV_API_KEY']


def query_truevault(data):
    '''

    :param data: Receives the required data and post it to the truevault
    :return: returns the response depending upon the query
    '''
    return requests.post('https://api.truevault.com/v1/users/search',
                      auth=HTTPBasicAuth(TRUEVAULT_API_KEY, ''), data=data)


def process_truevault_query(data):
    '''

    :param data: receives the  base 64encoded data from search user function and sends  the data
                    to query true vault function and process the received data decode to base 64.
    :return: returns the user data from true vault.
    '''
    r = query_truevault(data)
    response = r.json()
    if (r.status_code != 200 or 'data' not in response or
            (r.status_code == 200 and not response['data'].get('documents'))):
        return None
    res = base64.b64decode(response['data']['documents'][0]['attributes']).decode('utf-8')
    print(res)
    return json.loads(res)


def search_user(flipt_member_id, first_name, last_name, date_of_birth):
    '''

    :param flipt_member_id: {member id}
    :param first_name:  {patient first name}
    :param last_name: {patient last name}
    :param date_of_birth: {patient date of birth}
    :return: This functions takes the above params as input and creates a curl command and post
              request to truevault with base64encoding.

    '''
    logger = logging.getLogger(__name__)
    logger.info("Inside search user function truevault")
    search_option = {'full_document': True,
                     'filter': {
                         'flipt_person_id': {
                             'type': 'eq',
                             'value': flipt_member_id,
                             'case_sensitive': False
                         },
                         'first_name': {
                             'type': 'eq',
                             'value': first_name,
                             'case_sensitive': False
                         },
                         'last_name': {
                             'type': 'eq',
                             'value': last_name,
                             'case_sensitive': False
                         },
                         'date_of_birth': {
                             'type': 'eq',
                             'value': date_of_birth,
                             'case_sensitive': False
                         },
                         '$tv.status': {'type': 'eq', 'value': 'ACTIVATED'}}, 'filter_type': 'and'}
    search_opt = base64.b64encode(str.encode(json.dumps(search_option)))
    return process_truevault_query({'search_option': search_opt})
