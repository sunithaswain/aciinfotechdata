#!/usr/bin/env python
"""
mocking requests calls
"""
import mock
import json

import unittest
from truevault import query_truevault
from eligibility import is_user_eligible

TRUEVAULT_RESPONSE_TEMPLATE = {'data': {'documents': [{'id': '54daf0fb-8e09-4a05-ba98-9160d21074e8', 'status': 'ACTIVATED', 'attributes': 'eyJ1cGRhdGVkX2F0IjoiMjAxOS0wMi0wNFQyMDozMzoxNC44ODk4NDIiLCJmbGlwdF9wZXJzb25faWQiOiIxMDAzMjYyIiwiZW1wbG95ZWVfaWQiOiJURVNUOTAwMTQ2IiwiY3JlYXRlZF9hdCI6IjIwMTktMDItMDRUMjA6MzM6MTQuODg5ODQyIiwibGFzdF9uYW1lIjoiRE9FIiwiZGVwZW5kZW50X3NzbiI6IlQxMDAtMDAtMTMyMSIsImNvdmVyYWdlX2VmZmVjdGl2ZV9kYXRlIjoiMjAxOS0wMS0wMSAwMDowMDowMCIsInJlbGF0aW9uc2hpcCI6IlNwb3VzZSIsInBlcnNvbl9jb2RlIjoiMDIiLCJmaXJzdF9uYW1lIjoiTEFSUlkiLCJjb3ZlcmFnZV90ZXJtaW5hdGlvbl9kYXRlIjoiMjAxOS0xMi0zMSAyMzo1OTo1OSIsImRhdGVfb2ZfYmlydGgiOiIyMDAwLTAxLTAxIDAwOjAwOjAwIiwiZGVkdWN0aWJsZV9yZW1haW5pbmciOjAsIm91dF9vZl9wb2NrZXRfcmVtYWluaW5nIjo1MDAwLCJpbmRpdmlkdWFsX2RlZHVjdGlibGVfcmVtYWluaW5nIjowLCJpbmRpdmlkdWFsX291dF9vZl9wb2NrZXRfcmVtYWluaW5nIjo1MDAwLCJmYW1pbHlfZGVkdWN0aWJsZV9yZW1haW5pbmciOjAsImZhbWlseV9vdXRfb2ZfcG9ja2V0X3JlbWFpbmluZyI6MTAwMDAsImh1bWFuYV9hbGxlcmdpZXMiOlsiSU9ESU5FIERZRSIsIkFDRSBJTkhJQklUT1JTIiwiU1VMRkEiLCJQRU5JQ0lMTElOIiwiUEVBTlVUUyIsIkFTUElSSU4iLCJDT0RFSU5FIl0sImRvbWFpbl9uYW1lIjoiRkxJUFQwMDEiLCJwYXJlbnRfaWQiOiIxMDAzMjYxIiwicGFyZW50X3VzZXJfaWQiOiJiZDQ3MmE3YS1jM2UxLTRmODYtYjk1Ni1iNjA0YzMwZGQ5YWEiLCJsb2NhdGlvbnMiOltdLCJob21lX2FkZHJlc3NfMSI6IjExMSBDb29saWRnZSBTdCIsImhvbWVfYWRkcmVzc18yIjoiIiwibG9jYXRpb24iOiJTb3V0aCBQbGFpbmZpZWxkIiwiY2l0eSI6IlNvdXRoIFBsYWluZmllbGQiLCJzdGF0ZSI6Ik5KIiwiemlwIjoiMDcwODAiLCJlbWFpbCI6IlN1a3VtYXJAZmxpcHRyeC5jb20iLCJiZW5lZml0X3BsYW5fbmFtZSI6IkNvcmUgUGxhbiIsImNvdmVyYWdlX3RpZXJfbmFtZSI6IkluZGl2aWR1YWwiLCJhY3RpdmUiOnRydWV9', 'user_id': 'e3630a87-e3f2-4847-9af3-bc554fc09529', 'username': 'Sukumar@fliptrx.com'}], 'info': {'total_result_count': 1, 'current_page': 1, 'num_pages': 1, 'per_page': 100}}, 'result': 'success', 'transaction_id': 'edfccb5e-8f55-4e8a-ad44-0f1f39bd0c70'}


class TestRequestsCall(unittest.TestCase):
    """
    Mock requests.post and return a mock Response object
    """
    def _mock_post_response(
            self,
            status=200,
            content="CONTENT",
            json_data=None,
            raise_for_status=None):
        """
        since we typically test a bunch of different
        requests calls for a service, we are going to do
        a lot of mock responses, so its usually a good idea
        to have a helper function that builds these things
        """
        mock_resp = mock.Mock()
        # mock raise_for_status call w/optional error
        mock_resp.raise_for_status = mock.Mock()
        if raise_for_status:
            mock_resp.raise_for_status.side_effect = raise_for_status
        # set status code and content
        mock_resp.status_code = status
        mock_resp.content = content
        # add json data if provided
        if json_data:
            # mock_resp.json = json_data
            mock_resp.json = mock.Mock(
                return_value=json.loads(json_data)
            )
        return mock_resp

    @mock.patch('requests.post')
    def test_query_truevault(self, mock_post):
        """
        test truevault query method
        """
        mock_resp = self._mock_post_response(json_data=json.dumps(TRUEVAULT_RESPONSE_TEMPLATE))
        mock_post.return_value = mock_resp

        result = query_truevault({'search_option': {}})
        self.assertEqual(result.json(), TRUEVAULT_RESPONSE_TEMPLATE)

    @mock.patch('requests.post')
    def test_is_user_eligible_valid(self, mock_post):
        """
        test truevault query method
        """
        mock_resp = self._mock_post_response(json_data=json.dumps(TRUEVAULT_RESPONSE_TEMPLATE))
        mock_post.return_value = mock_resp
        result = is_user_eligible('1003262,202001,LARRY,DOE,2000-01-01 00:00:00')
        self.assertEqual(result, True)

    @mock.patch('requests.post')
    def test_is_user_eligible_invalid(self, mock_post):
        """
        test truevault query method
        """
        mock_resp = self._mock_post_response(json_data=json.dumps(TRUEVAULT_RESPONSE_TEMPLATE))
        mock_post.return_value = mock_resp
        result = is_user_eligible('1003262-invalid,202001,LARRY,DOE,2000-01-01 00:00:00')
        self.assertEqual(result, False)

if __name__ == '__main__':
    unittest.main()
