import logging
from truevault import search_user
FLIP_CLAIM_PAYLOAD_LEN = 5


def _parse_data(data):
    '''

    :param data: This function excepts data in string format, with five required params. validating
                    the data received and tagging them to respective fields.
    :return: returns the received data with tagged item list
    '''
    item_list = data.split(',')

    # validating claim payload data
    if len(item_list) != FLIP_CLAIM_PAYLOAD_LEN:
        raise Exception("Expecting %s comma separated values in claim payload. Received - %s",
                        FLIP_CLAIM_PAYLOAD_LEN, len(item_list))
    return map(lambda x: x.strip(), item_list)


def is_user_eligible(data):
    '''

    :param data: expects data in str format with required 5 params, checks if the user is eligible for
                    the claim.
    :return: returns TRUE or FALSE depending upon the input data
    '''
    flipt_member_id, date_of_Service, first_name, last_name, date_of_birth = _parse_data(data)

    user = search_user(flipt_member_id, first_name, last_name, date_of_birth)
    if user is None:
        err_msg = "Invalid Flipt Member details for this member_id: %s", flipt_member_id
        logging.info(err_msg)
        return False

    if not user['active'] or user['flipt_person_id'] != flipt_member_id:
        return False

    # validations for active user
    if user['coverage_termination_date'] <= date_of_Service:
        logging.info("Member is in active status and covered while processing the claim")
        return True

is_user_eligible('1003262,202001,LARRY,DOE,2000-01-01 00:00:00')
