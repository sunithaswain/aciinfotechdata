#   Constants for claim processing
# NCPDP D.0 Pharmacy Claim Test Case 1:
# Claim without DUR information filled in. The claim is paid.

version = 'D0'
BIN_NO = "610442"

patient_pay_amount = '00000'

transaction_code = ["B1", "B2", "B3"]


B1claim_paid_format = ("^(?P<bin_no>\d{6})(?P<release_number>\w{2})(?P<transaction_code>\w{2}).........."
              "(?P<transaction_count>\d{1})(?P<service_provider_ID_qualifier>\d{2})(?P<service_provider_ID>\d{10})..."
              "(?P<date_of_service>\w{8})(?P<software_vendor_certification_ID>\w{10})....AM04."
              "C2(?P<cardholder_ID>\w{7})..AM01.(?P<date_of_birth>\w{10}).C5(?P<patient_gender_code>\d{1}).."
              "C7(?P<place_of_service>\d{2})~..AM07.EM(?P<prescription>\d{1}).D2(?P<prescription_number>\d{12})."
              "E1(?P<service_Id_qualifier>\d{2}).D7(?P<service_Id>\d{11}).E7(?P<quantity_dispensed>\d{10})."
              "D5(?P<days_of_supply>\d{3}).D6(?P<compound_code>\d{1}).DK(?P<submission_clarification_code>\d{2})."
              "C8(?P<other_coverage_code>\d{2}).EU(?P<prior_authorization_type_code>\d{2})."
              "EV(?P<prior_authorization_number>\d{11})..AM11.DX(?P<patient_paid_amount>\d{8})."
              "DU(?P<gross_amount_due>\d{7}).DN(?P<basis_of_cost_determination>\d{2})..AM03."
              "EZ(?P<prescriber_ID_qualifier>\d{2}).DB(?P<prescriber_ID>\d{10})....AM05.."
              "4C(?P<coordination_of_benefits>\d{1}).5C(?P<other_payer_coverage_type>\d{2})."
              "HB(?P<other_payer_amount_paid_count>\d{1}).HC(?P<other_payer_amount_paid_qualifier>\d{2})."
              "DV(?P<other_payer_amount_paid>\d{8})$")

# NCPDP D.0 Pharmacy Claim Test Case 2:
# Claim Reversal

claim_reversal_format = ("(?P<bin_no>\d{6})(?P<release_number>\w{2})(?P<transaction_code>\w{2}).........."
                         "(?P<transaction_count>\d{1})(?P<service_provider_ID_qualifier>\d{2})"
                         "(?P<service_provider_ID>\d{10})...(?P<date_filled>\w{8})"
                         "(?P<software_vendor_certification_ID>\w{10})~..AM04.C2(?P<cardholder_ID>\w{15})AM07."
                         "EM(?P<prescription_service_ref_num_qualifier>\d{1}).D2(?P<prescription_number>\d{12})."
                         "E1(?P<service_Id_qualifier>\d{2}).D7(?P<service_Id>\d{11})$")

# NCPDP D.0 Pharmacy Claim Test Case 3:
# Claim without DUR information filled in. Claim is rejected

claim_rejected_format = "^(?P<bin_no>\d{6})(?P<release_number>\w{2})(?P<transaction_code>\w{2}).........." \
                        "(?P<transaction_count>\d{1})(?P<service_provider_ID_qualifier>\d{2})(?P<service_provider_ID>\d{10})..." \
                        "(?P<date_of_service>\d{8})(?P<software_vendor_certification_ID>\w{10}).....AM04." \
                        "C2(?P<cardholder_ID>\w{15})..AM01."\
                        "C4(?P<date_of_birth>\d{8}).C5(?P<patient_gender_code>\d{1}).C7(?P<place_of_service>\d{2})~.." \
                        "AM07.EM(?P<prescription>\d{1}).D2(?P<prescription_number>\d{12})." \
                        "E1(?P<service_Id_qualifier>\d{2}).D7(?P<service_Id>\d{11}).E7(?P<quantity_dispensed>\d{10})." \
                        "D5(?P<days_of_supply>\d{3}).D6(?P<compound_code>\d{1}).DK(?P<submission_clarification_code>\d{2})." \
                        "C8(?P<other_coverage_code>\d{2}).EU(?P<prior_authorization_type_code>\d{2})." \
                        "EV(?P<prior_authorization_number>\d{11})..AM11." \
                        "DU(?P<gross_amount_due>\d{8})."\
                        "DN(?P<basis_of_cost_determination>\d{2})..AM03." \
                        "EZ(?P<prescriber_ID_qualifier>\d{2}).DB(?P<prescriber_ID>\d{9})...$"

b1_transaction_response_format = ("{bin_no}EDSH01IZ513U......{release_number}{transaction_code}{transaction_count}"
                                  "A{service_provider_ID_qualifier}{service_provider_ID}....."
                                  "{date_of_service}..AM29.CA{patient_first_name}.CB{patient_last_name} ...AM21."
                                  "ANP..AM22.EM{prescription}.D2{prescription_number}.."
                                  "AM23.F5{patient_pay_amount}{{.F6{ingredient_cost_paid}{{.F9{total_paid_amount}{{")
