#   Config file used for mapping the incoming data and returning the claim type

claim_paid_config = {"102-A2": "release_number", "103-A3": "transaction_code", "109-A9": "transaction_count",
                      "202-B2": "service_provider_ID_qualifier", "201-B1": "service_provider_ID", "401-D1": "date_of_service",
                      "110-AK": "software_vendor_certification_ID", "302-C2": "cardholder_ID", "304-C4": "date_of_birth",
                      "305-C5": "patient_gender_code", "307-C7": "place_of_service", "455-EM": "prescription",
                      "402-D2": "prescription_number", "436-E1": "service_Id_qualifier",
                      "407-D7": "service_Id", "442-E7": "quantity_dispensed", "405-D5": "days_of_supply",
                      "406-D6": "compound_code", "420-DK": "submission_clarification_code",
                      "308-C8": "other_coverage_code", "461-EU": "prior_authorization_type_code",
                      "462-EV": "prior_authorization_number", "433-DX": "patient_paid_amount",
                      "430-DU": "gross_amount_due", "423-DN": "basis_of_cost_determination",
                      "466-EZ": "prescriber_ID_qualifier", "411-DB": "prescriber_ID",
                      "337-4C": "coordination_of_benefits", "338-5C": "other_payer_coverage_type",
                      "341-HB": "other_payer_amount_paid_count", "342-HC": "other_payer_amount_paid_qualifier",
                      "431-DV": "other_payer_amount_paid"}

#   NCPDP D.0 Pharmacy Claim Test Case 2: Claim Reversal

claim_reversal_config = {"101-A1": "bin_no", "102-A2": "release_number", "103-A3": "transaction_code",
                         "109-A9": "transaction_count", "202-B2": "service_provider_ID_qualifier",
                         "201-B1": "service_provider_ID", "401-D1": "date_filled",
                         "110-AK": "software_vendor_certification_ID", "302-C2": "cardholder_ID",
                         "544-EM": "prescription_service_ref_num_qualifier", "402-D2": "prescription_number",
                         "436-E1": "service_Id_qualifier", "407-D7": "service_Id"}

#   NCPDP D.0 Pharmacy Claim Test Case 3:
#   Claim without DUR information filled in. Claim is rejected

claim_rejected_config = {"102-A2": "release_number", "103-A3": "transaction_code", "109-A9": "transaction_count",
                         "202-B2": "service_provider_ID_qualifier", "201-B1": "service_provider_ID",
                         "401-D1": "date_of_service", "110-AK": "software_vendor_certification_ID",
                         "302-C2": "cardholder_ID", "304-C4": "date_of_birth", "305-C5": "patient_gender_code",
                         "307-C7": "place_of_service", "455-EM": "prescription", "402-D2": "prescription_number",
                         "436-E1": "service_Id_qualifier", "407-D7": "service_Id", "442-E7": "quantity_dispensed",
                         "405-D5": "days_of_supply", "406-D6": "compound_code",
                         "420-DK": "submission_clarification_code", "308-C8": "other_coverage_code",
                         "461-EU": "prior_authorization_type_code", "462-EV": "prior_authorization_number",
                         "430-DU": "gross_amount_due", "423-DN": "basis_of_cost_determination",
                         "466-EZ": "prescriber_ID_qualifier", "411-DB": "prescriber_ID"}


