from suds.client import Client

import datetime
start_time = datetime.datetime.now()

c = Client('http://127.0.0.1:5000/?wsdl')
incoming_data = ('610442D0B1..........1010000000071...20200101XXX0100AAA....AM04.C21003262..'
     'AM01.C419220402.C51..C701~..AM07.EM1.D2123450234567.E103.D700078010409.E70000100000.'
     'D5030.D61.DK07.C802.EU01.EV11111111111..AM11.DX00001000.DU0000220.DN00..AM03.EZ01.'
     'DB1234567893....AM05..4C1.5C01.HB1.HC01.DV00001100')
print (c.service.claim(incoming_data))
end_time = datetime.datetime.now()
delta = (end_time - start_time)
print (delta.total_seconds())
