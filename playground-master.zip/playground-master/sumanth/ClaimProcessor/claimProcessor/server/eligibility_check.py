import os
import json
import logging
import base64
import requests
from requests.auth import HTTPBasicAuth

#api_key = os.environ['TV_API_KEY']
api_key = '83e6beff-1909-4b52-b68d-4cd451a0e830'

def search_user(search_option):
    logging.info("Inside search user function truevault")
    search_opt = base64.b64encode(str.encode(json.dumps(search_option)))
    data = {'search_option': search_opt}
    r = requests.post('https://api.truevault.com/v1/users/search',
                      auth=HTTPBasicAuth(api_key, ''), data=data)
    response = r.json()
    # print(response)
    if 'data' not in response:
        return None
    if r.status_code == 200 and not response['data']['documents']:
        return None
    res = base64.b64decode(response['data']['documents'][0]['attributes'])
    att = json.loads(str(res).strip("b\'"))
    return att


