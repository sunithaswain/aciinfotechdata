import logging

from spyne.decorator import srpc
from spyne.service import ServiceBase
from spyne.model.complex import Iterable
from spyne.model.primitive import Unicode

from ..server.b1_transactions import B1Transaction

class ClaimProcessService(ServiceBase):

    @srpc(Unicode, _returns=Iterable(Unicode))
    def claim(data):
        bin_no = data.split("..", 1)[0]
        if bin_no.endswith("B1"):
            logging.info("Identified transaction as B1, calling respective logic")
            transaction = B1Transaction()
        yield transaction.transact(data)

