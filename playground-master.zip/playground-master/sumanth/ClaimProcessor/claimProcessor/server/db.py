
from couchbase.cluster import Cluster, Bucket
from couchbase.cluster import PasswordAuthenticator
from couchbase.n1ql import N1QLQuery

cluster = Cluster('http://13.90.231.152')
authenticator = PasswordAuthenticator('dev-backend.python-scripts', 'befog-dialysis-exemplar-tori')
cluster.authenticate(authenticator)
cb = cluster.open_bucket('dev-fliptrx-app')

query = N1QLQuery('Select * from `dev-fliptrx-app` where type="ndc_drugs" and ndc=$drugndc',drugndc='00002120001')
query.adhoc=False
for res in cb.n1ql_query(query):
    print(len(res))
    print(res['dev-fliptrx-app'])
Bucket._close(cb)

