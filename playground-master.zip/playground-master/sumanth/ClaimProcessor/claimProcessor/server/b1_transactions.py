import logging
import re
import pprint
from ..server import eligibility_check
from claimProcessor.server.transaction import Transaction
from claimProcessor.params import constants, prec_config


class B1Transaction(Transaction):
    def __init__(self):
        self.claim_map = {constants.B1claim_paid_format: prec_config.claim_paid_config}
        super(B1Transaction, self).__init__()

    def transact(self, data):
        logging.info("Inside B1 transaction logic")
        print(self.claim_map)
        for pattern, config in self.claim_map.items():
            match_obj = re.match(pattern, data)
            if match_obj:
                output = self.prepare_output(match_obj, config)
                pprint.pprint(output)
                # Identifying the type of transaction based on the incoming data
                if constants.version != output['102-A2']['release_number']:
                    return "Invalid version/release number"
                else:
                    logging.info("Valid release number " + output['102-A2']['release_number'])
                flipt_member_id = output['302-C2']['cardholder_ID']
                date_of_service = output['401-D1']['date_of_service']
                if flipt_member_id:
                    logging.info("Received member_id " + flipt_member_id)
                    logging.info("Validating if the user is existing in the DB and eligible for the claim")
                    import pdb;pdb.set_trace()
                    search_option = {'full_document': True, 'filter':
                        {'flipt_person_id': {'type': 'eq', 'value': flipt_member_id, 'case_sensitive': False},
                         '$tv.status': {'type': 'eq', 'value': 'ACTIVATED'}}, 'filter_type': 'and'}
                    att = eligibility_check.search_user(search_option)
                    if att['active'] and att['coverage_termination_date'] <= date_of_service:
                        logging.info("Member is in active status and covered while processing the claim")
                        res_dict = {}
                        for k, v in output.items():
                            res_dict.update(v)
                        res_dict["bin_no"] = constants.BIN_NO
                        res_dict["patient_first_name"] = att["first_name"]
                        res_dict["patient_last_name"] = att["last_name"]
                        res_dict["patient_pay_amount"] = constants.patient_pay_amount
                        res_dict["ingredient_cost_paid"] = constants.patient_pay_amount
                        res_dict["total_paid_amount"] = constants.patient_pay_amount
                        return constants.b1_transaction_response_format.format(**res_dict)
                    else:
                        return "No match found for specified input format"





