from claimProcessor.params import constants, prec_config


class Transaction(object):
    def __init__(self):
        # self.claim_map = {constants.claim_paid_format: prec_config.claim_paid_config,
        #                   constants.claim_reversal_format: prec_config.claim_reversal_config,
        #                   constants.claim_rejected_format: prec_config.claim_rejected_config}
        pass

    def prepare_output(self, match_obj, config):
        input_parsed_dict = match_obj.groupdict()
        res_dict = {}
        for k, v in config.items():
            res_dict[k] = {v: input_parsed_dict[v]}

        return res_dict
