import logging
from wsgiref.simple_server import make_server
from spyne.util.simple import wsgi_soap11_application

from claimProcessor.server import app


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    logging.getLogger('spyne.protocol.xml').setLevel(logging.DEBUG)

    logging.info("listening to http://0.0.0.0:5000")
    logging.info("wsdl is at: http://localhost:5000/?wsdl")

    wsgi_app = wsgi_soap11_application([app.ClaimProcessService],
                                       'spyne.examples.claimprocess.soap')
    server = make_server('0.0.0.0', 5000, wsgi_app)
    server.serve_forever()
