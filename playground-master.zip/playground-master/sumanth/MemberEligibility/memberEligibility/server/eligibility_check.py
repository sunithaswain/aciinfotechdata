import json
import logging
import base64
import requests
import os

from requests.auth import HTTPBasicAuth


api_key = os.environ['TV_API_KEY']

def search_user(flipt_member_id):
    logger = logging.getLogger(__name__)
    logger.info("Inside search user function truevault")
    search_option = {'full_document': True,
                     'filter': {'flipt_person_id': {'type': 'eq', 'value': flipt_member_id, 'case_sensitive': False},
                                '$tv.status': {'type': 'eq', 'value': 'ACTIVATED'}}, 'filter_type': 'and'}

    search_opt = base64.b64encode(str.encode(json.dumps(search_option)))
    data = {'search_option': search_opt}
    r = requests.post('https://api.truevault.com/v1/users/search',
                      auth=HTTPBasicAuth(api_key, ''), data=data)
    response = r.json()
    # print(response)
    if (r.status_code != 200 or 'data' not in response or
            (r.status_code == 200 and not response['data'].get('documents'))):
        return None

    res = base64.b64decode(response['data']['documents'][0]['attributes'])
    return json.loads(str(res).strip("b\'"))

