import logging

from spyne.decorator import srpc
from spyne.service import ServiceBase
from spyne.model.complex import Iterable
from spyne.model.primitive import Unicode

from ..server.eligibility_check import search_user

class ClaimProcessService(ServiceBase):

    @srpc(Unicode, _returns=Iterable(Unicode))
    def claim(data):
        flipt_member_id = data.split(',')[0]
        date_of_Service = data.split(',')[1]
        if flipt_member_id:
            logging.info("Identified transaction as B1, calling respective logic")
            transaction = search_user(flipt_member_id)
            if transaction is None:
                err_msg = "Invalid Flipt Member ID: %s", flipt_member_id
                logging.info(err_msg)
                return err_msg
            if transaction['active'] and transaction['coverage_termination_date'] <= date_of_Service:
                logging.info("Member is in active status and covered while processing the claim")
                res = "Member is in active status and covered while processing the claim"
                return res
            else:
                res = "Member is inactive or not covered"
                return res


