from suds.client import Client

import datetime
start_time = datetime.datetime.now()

c = Client('http://127.0.0.1:5000/?wsdl')

incoming_data = ('1003262,20200101')
res = (c.service.claim(incoming_data))
for i in res:
    new_res = i[1]
    result = ''.join(new_res)
    print(result)
end_time = datetime.datetime.now()
delta = (end_time - start_time)
print (delta.total_seconds())