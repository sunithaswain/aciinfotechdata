if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
   sys.path.append(rootdir)

# it will changed based on OS
rootdir = rootdir.replace('\\', '/')
path = rootdir + os.environ['CB_DATA']
 
import json
import base64
import pprint
import shutil
import os
from utils import commandline
import sys
import paramiko
import time
import dateutil.parser as parser
import socket
import requests
import pandas as pd
from requests.auth import HTTPBasicAuth
from types import SimpleNamespace as Namespace
from datetime import timedelta
from datetime import datetime
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from utils.sendgridemail import email_log,email_log_custom
import time
from sclaimintegration.scriptclaimsftp import sftptransfer
from sclaimintegration.scriptclaimsftp import fileexists
import sys, traceback
from sclaimintegration.scriptclaimsftp import multiplefilesftptransfer
from couchbase import FMT_JSON
import xlsxwriter
from utils.FliptConcurrent import concurrent

#Command to run the script
# python scdailyclaimsummaryrecon.py  -d GWLABS001 -t dailyclaim_reconciliation -m DRAFT


host = socket.gethostname()
cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
# path = os.environ['CB_DATA']
domain,file_type,file_name,mode = commandline.main(sys.argv[1:])
req=concurrent(sys.argv[0],sys.argv[1:])
currentdate = datetime.now()
displaydatetime = currentdate.strftime("%Y%m%d%H%M")
currentdate = currentdate.isoformat()
remotepath = '/DailyReconciliation'
archivepath = '/DailyReconciliationArchive/'
localpath = path+'/'+domain+'/'+file_type+'/'
archivefile = path+'/'+domain+'/'+file_type+'/archive/'
transferstatus = ''
#Creates an excel
DCReconFile=path+'/'+domain+'/'+file_type+'/log/'+'DCReconciliationReport'+currentdate+'.xlsx'
logrecordcount = 0
# Start from the first cell. Rows and columns are zero indexed.
excrow = 0
exccol = 0
# Create a workbook and add a worksheet.
workbook = xlsxwriter.Workbook(DCReconFile)
worksheet = workbook.add_worksheet()	
# Different Formats for Rows and Columns
header_format = workbook.add_format({
	'bold': True,
	'text_wrap': True,
	'valign': 'top',
	'fg_color': '#FF0000',
	'border': 1})
header_format.set_font_color('#FFFFFF')
header_format.set_border_color('#FF0000')

parameter_format = workbook.add_format({
    'bold': True,
    'text_wrap': True,
    'valign': 'top',
    'fg_color': '#FF0000',
    'border': 1})
parameter_format.set_font_color('#FFFFFF')	
parameter_format.set_border_color('#FF0000')

row_format = workbook.add_format({
	'bold': False,
	'text_wrap': True,
	'valign': 'top',
	'fg_color': '#FFFFFF',
	'border': 1})	
row_format.set_border_color('#FF0000')

merge_format = workbook.add_format({
	'bold': True,
	'text_wrap': True,
	'align': 'center',
	'valign': 'vcenter',
	'fg_color': '#FF0000',
	'border': 1})
merge_format.set_font_size(35)
merge_format.set_font_color('#FFFFFF')
	
	
# Set column Width
worksheet.set_column('A:A',22)
worksheet.set_column('B:B',36)
worksheet.set_column('C:C',23)
worksheet.set_column('D:D',25)
worksheet.set_column('E:E',25)
worksheet.set_column('F:F',25)
worksheet.set_column('G:G',25)
worksheet.set_column('H:H',14)
worksheet.set_column('I:I',14)
worksheet.set_column('J:J',15)
worksheet.set_column('K:K',17)
worksheet.set_column('L:L',17)
worksheet.set_column('M:M',17)
worksheet.set_column('N:N',17)
worksheet.set_column('O:O',17)
worksheet.set_column('P:P',17)
worksheet.set_column('Q:Q',17)
worksheet.set_column('R:R',17)
worksheet.set_column('S:S',17)
worksheet.set_column('T:T',17)		

# reads and inserts claim records found in files present o n the SFTP server
def readfile():
	global logrecordcount
	files = []
	batchids=[]
	files,transferstatus = multiplefilesftptransfer(remotepath,localpath,'GET')
	print(transferstatus)
	if transferstatus == 'S':
		for filename in files:
			batchid=str(cb.counter('docid',delta=1).value)
			batchids.append(batchid)
			filepath = localpath+filename
			with open (filepath, 'rt') as in_file:
				for dcrow in in_file:
					claim = {}
					claim_date = dcrow[0:20].strip()
					
					if claim_date=='': continue
					claim_date = parser.parse(claim_date)
					claim_date = claim_date.isoformat()
					claim['claim_date'] = claim_date
					claim['auth_id'] = dcrow[20:40].strip()
					claim['claim_type'] = dcrow[40:41].strip()
					claim['rx_number'] = dcrow[41:53].strip() 
					claim['bin'] = dcrow[53:59].strip()
					claim['pcn'] = dcrow[59:69].strip()
					claim['carrier'] = dcrow[69:78].strip()
					claim['account'] = dcrow[78:87].strip()
					claim['group'] = dcrow[87:102].strip()
					claim['member_id'] = dcrow[102:120].strip()
					claim['patient_first_name'] = dcrow[120:135].strip()
					claim['patient_last_name'] = dcrow[135:160].strip()
					claim['person_code'] = dcrow[160:163].strip()
					claim['rel_code'] = dcrow[163:164].strip()
					claim['date_of_service'] = dcrow[164:172].strip()
					claim['patient_age'] = dcrow[172:175].strip()
					claim['dob'] = dcrow[175:183].strip()
					claim['gender'] = dcrow[183:184].strip()
					claim['pharmacy_npi'] = dcrow[184:199].strip()
					claim['pharmacy_ncpdp'] = dcrow[199:206].strip()
					claim['pharmacy_name'] = dcrow[206:256].strip()
					claim['network_id'] = dcrow[256:265].strip()
					claim['ing_cost_paid'] = dcrow[265:273].strip()
					claim['disp_fee_paid'] = dcrow[273:281].strip()
					claim['amt_paid_to_pharmacy'] = dcrow[281:289].strip()
					claim['sales_tax_paid'] = dcrow[289:297].strip()
					claim['patient_paid'] = dcrow[297:305].strip()
					claim['client_ing_cost'] = dcrow[305:313].strip()
					claim['client_disp_fee'] = dcrow[313:321].strip()
					claim['client_due_amt'] = dcrow[321:329].strip()
					claim['client_mac_price'] = dcrow[329:341].strip()
					claim['pharmacy_mac_price'] = dcrow[341:353].strip()
					claim['fill_number'] = dcrow[353:355].strip()
					claim['formulary_status'] = dcrow[355:356].strip()
					claim['prescriber_npi'] = dcrow[356:371].strip()
					claim['prescriber_last_name'] = dcrow[371:396].strip()
					claim['prescriber_first_name'] = dcrow[396:411].strip()
					claim['product_name_full'] = dcrow[411:561].strip()
					claim['product_id_ndc'] = dcrow[561:572].strip()
					claim['gpi_code'] = dcrow[572:586].strip()
					claim['manuf_abr'] = dcrow[586:636].strip()
					claim['quantity_dispensed'] = dcrow[636:645].strip()
					claim['days_supply'] = dcrow[645:648].strip()
					claim['multisource_code'] = dcrow[648:649].strip()
					claim['otc_indicator'] = dcrow[649:650].strip()
					claim['awp_unit'] = dcrow[650:662].strip()
					claim['submitted_uc'] = dcrow[662:670].strip()
					claim['submitted_ing_cost'] = dcrow[670:678].strip()
					claim['submitted_disp_fee'] = dcrow[678:686].strip()
					claim['submitted_gross_due'] = dcrow[686:694].strip()
					claim['submitted_sales_tax'] = dcrow[694:702].strip()
					claim['transaction_id'] = "prescription::"+str(dcrow[702:714]).strip()
					claim['pharmacy_rejection_reason'] = dcrow[714:914].strip()
					claim['sequence_number'] = dcrow[914:].strip()
					claim['create_date'] = currentdate
					claim['update_date'] = currentdate
					claim['created_by'] = 'ScriptClaim'
					claim['updated_by'] = 'ScriptClaim'
					claim['batchid'] = str(batchid)
					claim['type'] = 'scdailyclaim_summary'
					cb.upsert(str(cb.counter('docid',delta=1).value),claim)
	else:
		print('No File Found')
		if os.environ['INSTANCE_TYPE'] == 'PROD':
			email_log_custom('noreply@fliptrx.com','FliptIntegration@fliptrx.com','dwagle@fliptrx.com,deepthi.gollapudi@nttdata.com,LPeysekhman@fliptrx.com,kyang@fliptrx.com,TPerkins@FliptRx.com,AGoyal@FliptRx.com,Hkumar@fliptrx.com,AKarlis@FliptRx.com','Daily Claim Reconciliation File Not Found',['No Daily Reconciliation files were found. '],None,False)
		else:
			email_log_custom('noreply@fliptrx.com','FliptIntegration@fliptrx.com','dwagle@fliptrx.com,deepthi.gollapudi@nttdata.com,AKarlis@FliptRx.com','Daily Claim Reconciliation File Not Found',['No Daily Reconciliation files were found. '],None,False)
			
		workbook.close()
		req.error_message='No File Found'
		req.close()
		exit()
	if len(batchids)==0:
		if os.environ['INSTANCE_TYPE'] == 'PROD':
			email_log_custom('noreply@fliptrx.com','FliptIntegration@fliptrx.com','dwagle@fliptrx.com,deepthi.gollapudi@nttdata.com,LPeysekhman@fliptrx.com,kyang@fliptrx.com,TPerkins@FliptRx.com,AGoyal@FliptRx.com,Hkumar@fliptrx.com,AKarlis@FliptRx.com','Daily Claim Reconciliation File Not Found',['No Daily Reconciliation files were found. '],None,False)
		else:
			email_log_custom('noreply@fliptrx.com','FliptIntegration@fliptrx.com','dwagle@fliptrx.com,deepthi.gollapudi@nttdata.com,AKarlis@FliptRx.com','Daily Claim Reconciliation File Not Found',['No Daily Reconciliation files were found. '],None,False)
		workbook.close()
		req.error_message='No File Found'
		req.close()
		exit()
	return batchids
					
def comparemissingclaims():

	global logrecordcount
	global excrow
	time.sleep(10)
	batchids = readfile()
	
	# Report Header
	worksheet.merge_range('D1:G5', 'Daily Claim Reconciliation Report', merge_format)
	
	# Report parameters
	worksheet.write(6, 4, "RunDate ",parameter_format)
	worksheet.write(6, 5, currentdate, row_format)
	
	
	for b in batchids:
		worksheet.write(6, 6, "Batch ID",parameter_format)
		worksheet.write(6, 7, b,row_format)
		worksheet.write(9, 0, "******" ,header_format)
		worksheet.write(9, 1, "Claims Missing in scdailyclaim table" ,header_format)
		worksheet.write(9, 2, "******" ,header_format)		
		worksheet.write(10, 0, "Claim Date",header_format)
		worksheet.write(10, 1, "Rx Number",header_format)
		worksheet.write(10, 2, "Authorization ID",header_format)
		worksheet.write(10, 3, "Claim Type",header_format)
		
		
	query = N1QLQuery("Select trim(claim_date) claim_date,trim(rx_number) rx_number, trim(auth_id) auth_id, trim(claim_type) claim_type from `"+os.environ['CB_INSTANCE']+"` where type='scdailyclaim_summary' and batchid in $bid except Select trim(claim_date) claim_date,trim(rx_number) rx_number, trim(auth_id) auth_id, trim(claim_type) claim_type from `"+os.environ['CB_INSTANCE']+"` where type='scdailyclaim'",bid=batchids)
	query.adhoc = False
	query.timeout = 600
	excrow=11
	for row in cb.n1ql_query(query):
		try:
			worksheet.write(excrow, 0, row['claim_date'],row_format)
		except Exception as e: 
			worksheet.write(excrow, 0, "",row_format)
			
		try:
			worksheet.write(excrow, 1, row['rx_number'],row_format)
		except Exception as e: 
			worksheet.write(excrow, 1, "",row_format)
			
		try:
			worksheet.write(excrow, 2, row['auth_id'],row_format)
		except Exception as e: 
			worksheet.write(excrow, 2, "",row_format)
			
		try:
			worksheet.write(excrow, 3, row['claim_type'],row_format)
		except Exception as e: 
			worksheet.write(excrow, 3, "",row_format)
		excrow=excrow+1		
		logrecordcount = logrecordcount+1
	
	print(logrecordcount)
	return batchids
	
def compareclaimstatus():

	global logrecordcount
	global excrow
	batchids = comparemissingclaims()
	excrow=excrow+1
	
	worksheet.write(excrow, 5, '*****',header_format)
	worksheet.write(excrow, 6, 'Claim Status Mismatch',header_format)
	worksheet.write(excrow, 7, '*****',header_format)
	excrow=excrow+2
	worksheet.write(excrow, 0, "Transaction ID",header_format)
	worksheet.write(excrow, 1, "Authorization ID",header_format)
	worksheet.write(excrow, 2, "SC Claim Type",header_format)
	worksheet.write(excrow, 3, "Flipt Prescription Status",header_format)
	worksheet.write(excrow, 4, "SC Dispensed Quantity",header_format)
	worksheet.write(excrow, 5, "Flipt Prescription Quantity",header_format)
	worksheet.write(excrow, 6, "SC Actual Patient Paid",header_format)
	worksheet.write(excrow, 7, "Flipt Employee OPC",header_format)
	worksheet.write(excrow, 8, "SC Client Due Amount",header_format)
	worksheet.write(excrow, 9, "Flipt Employer Cost",header_format)
	worksheet.write(excrow, 10, "Brand/Generic",header_format)
	worksheet.write(excrow, 11, "Flipt Rebate factor",header_format)
	worksheet.write(excrow, 12, "Flipt Drug Cost",header_format)
	worksheet.write(excrow, 13, "Flipt Drug Cost Before Rebate",header_format)
	worksheet.write(excrow, 14, "SC Unit Price",header_format)
	worksheet.write(excrow, 15, "Flipt Unit Price",header_format)
	worksheet.write(excrow, 16, "Flipt Unit Price Before Rebate",header_format)
	worksheet.write(excrow, 17, "Flipt Pharmacy Discount",header_format)
	worksheet.write(excrow, 18, "Flipt Pharmacy Dispensing Fee",header_format)
	worksheet.write(excrow, 19, "PaymentOption",header_format)
	worksheet.write(excrow, 20, "Message",header_format)
	worksheet.write(excrow, 21, "Analysis",header_format)
	excrow=excrow+1
	
	claimstatus=pd.DataFrame()
	statusmatch = {'P':['filled'],'X':['cancelled','routed']}
	query = N1QLQuery("Select a.claim_type,a.auth_id,a.transaction_id,tonumber(a.client_due_amt) client_due_amt,tonumber(a.quantity_dispensed) quantity_dispensed,tonumber(a.patient_paid) patient_paid,CASE WHEN multisource_code='N' THEN tonumber(awp_unit) ELSE tonumber(client_mac_price) END sc_unit_price from `"+os.environ['CB_INSTANCE']+"` a where a.type='scdailyclaim_summary' and meta(a).id in (Select raw meta(b).id from `"+os.environ['CB_INSTANCE']+"` b where b.type='scdailyclaim_summary' and b.batchid in $bid and b.claim_type in ['P','X'] and trim(b.sequence_number)||trim(b.auth_id)||trim(b.rx_number) in (Select raw trim(tostring(max(tonumber(c.sequence_number))))||trim(c.auth_id)||trim(c.rx_number) from `"+os.environ['CB_INSTANCE']+"` c where c.type='scdailyclaim_summary' and c.claim_type in ['P','X'] and c.batchid in $bid group by trim(c.auth_id),trim(c.rx_number)))",bid=batchids)
	query.adhoc = False
	query.timeout = 600
	
	for row in cb.n1ql_query(query):
		rxstatus = ""
		csvalues={}
		for c in ['rx_status','payment_option','transaction_id','auth_id','brand_generic','claim_type','quantity_dispensed','quantity','patient_paid','employee_opc','client_due_amt','employer_cost','drug_cost','rebate_factor','drug_cost_before_rebate','message','unit_price','unit_price_before_rebate','sc_unit_price','pharmacy_discount','pharmacy_dispensing_fee','analysis']:
			csvalues[c]=""
		try:
			if 'claim_type' in row: csvalues['claim_type']=row['claim_type']
			if 'auth_id' in row: csvalues['auth_id']=row['auth_id']
			if 'transaction_id' in row: csvalues['transaction_id']=row['transaction_id']
			innerquery=None
			qrystr = "Select trim(lower(rx_status)) rx_status,payment_option,CASE WHEN payment_option = 'Pay via Payroll Deduction' THEN 0 ELSE tonumber(employee_opc) END employee_opc,tonumber(drug_cost) drug_cost,tonumber(unit_price) unit_price,tonumber(unit_price_before_rebate) unit_price_before_rebate, tonumber(pharmacy_discount) pharmacy_discount,tonumber(pharmacy_dispensing_fee) pharmacy_dispensing_fee,tonumber(tonumber(package_size)*tonumber(quantity)) as qty, CASE WHEN payment_option = 'Pay via Payroll Deduction' THEN tonumber(drug_cost_before_rebate) ELSE tonumber(drug_cost_before_rebate)-tonumber(employee_opc) END employer_cost, brand_generic,rebate_factor,tonumber(drug_cost_before_rebate) drug_cost_before_rebate from `"+os.environ['CB_INSTANCE']+"` where type='prescription'"
			if str(row['transaction_id']).strip()=="prescription::":
				innerquery = N1QLQuery(qrystr+"and trim(auth_id)=$aid",aid=str(row['auth_id']).strip())
			else:
				innerquery = N1QLQuery(qrystr+"and trim(prescription_id)=$pid",pid=row['transaction_id'])
			innerquery.adhoc = False
			innerquery.timeout = 600
			for record in cb.n1ql_query(innerquery):
				message=''
				analysis = ''
				record['message']=''
				rxstatus=record['rx_status']
				csvalues['rx_status']=record['rx_status']
				if 'claim_type' in row and 'rx_status' in record:
					csvalues['claim_type']=str(row['claim_type'])
					csvalues['rx_status']=str(record['rx_status'])
					if rxstatus not in statusmatch[row['claim_type']]:
						message=message+" Prescription Status not matching with Claim Type ||"
				if 'quantity_dispensed' in row and 'qty' in record:
					csvalues['quantity_dispensed']=str(row['quantity_dispensed'])
					csvalues['quantity']=str(record['qty'])
					if csvalues['quantity_dispensed']!=csvalues['quantity']:
						message=message+" Prescription Quantity not matching with Dispensed Quantity ||"
						if int(csvalues['quantity_dispensed']) <0 and csvalues['claim_type']!='P':
							analysis=analysis+"Dispensed qty is negative and this is a canceled prescription. ||"
							#print (csvalues['analysis'])
						
				if 'patient_paid' in row and 'employee_opc' in record:
					csvalues['patient_paid']=str(row['patient_paid'])
					csvalues['employee_opc']=str(record['employee_opc'])
					if abs(abs(row['patient_paid'])-abs(record['employee_opc']))>1:
						message=message+" Employee OPC not matching with Patient Paid ||"
				if 'client_due_amt' in row and 'employer_cost' in record:
					csvalues['client_due_amt']=str(row['client_due_amt'])
					csvalues['employer_cost']=str(record['employer_cost'])
					if abs(abs(row['client_due_amt'])-(abs(record['drug_cost_before_rebate'])-abs(row['patient_paid'])))>1:
						message=message+" Employer Cost not matching with Client Due Amt ||"
						if record['employer_cost']+row['patient_paid'] >= record['drug_cost_before_rebate']:
							analysis=analysis+" Drugcost is paid.SC still expecting client due amount. ||"
			
				if message!="":
					csvalues['message']=message[:-2]
					csvalues['analysis']=analysis[:-2]
					if 'brand_generic' in record: csvalues['brand_generic']=str(record['brand_generic'])
					if 'rebate_factor' in record: csvalues['rebate_factor']=str(record['rebate_factor'])
					if 'drug_cost_before_rebate' in record: csvalues['drug_cost_before_rebate']=str(record['drug_cost_before_rebate'])
					if 'sc_unit_price' in row: csvalues['sc_unit_price']=str(row['sc_unit_price'])
					if 'unit_price' in record: csvalues['unit_price']=str(record['unit_price'])
					if 'unit_price_before_rebate' in record: csvalues['unit_price_before_rebate']=str(record['unit_price_before_rebate'])
					if 'drug_cost' in record: csvalues['drug_cost']=str(record['drug_cost'])
					if 'pharmacy_dispensing_fee' in record: csvalues['pharmacy_dispensing_fee']=str(record['pharmacy_dispensing_fee'])
					if 'pharmacy_discount' in record: csvalues['pharmacy_discount']=str(record['pharmacy_discount'])
					if 'payment_option' in record:	csvalues['payment_option']=str(record['payment_option'])
					logrecordcount = logrecordcount+1
					
			if rxstatus == '':
				csvalues['message']="No Prescription found"
				logrecordcount = logrecordcount+1
			if csvalues['message']!='':
				claimstatus=claimstatus.append(csvalues,ignore_index=True)
				csvalues['type']='daily_reconciliation_report'
				csvalues['create_date']=currentdate
				csvalues['update_date']=currentdate
				#print(csvalues)
				docidins=str(cb.counter('docid',delta=1).value)
				print(docidins)
				cb.upsert(docidins,csvalues)
		except Exception as e:
			print('Error',e)
			print(row)
	if len(claimstatus)==0 or claimstatus.empty:
		print(claimstatus)
	else:
		claimstatus.fillna("",inplace=True)
		claimstatus.sort_values(by=['transaction_id'],ascending=[True],inplace=True)
		
	for index,line in claimstatus.iterrows():
		#print(line)
		worksheet.write(excrow, 0, line['transaction_id'],row_format)
		worksheet.write(excrow, 1, line['auth_id'],row_format)
		worksheet.write(excrow, 2, line['claim_type'],row_format)
		worksheet.write(excrow, 3, line['rx_status'],row_format)
		worksheet.write(excrow, 4, line['quantity_dispensed'],row_format)
		worksheet.write(excrow, 5, line['quantity'],row_format)
		worksheet.write(excrow, 6, line['patient_paid'],row_format)
		worksheet.write(excrow, 7, line['employee_opc'],row_format)
		worksheet.write(excrow, 8, line['client_due_amt'],row_format)
		worksheet.write(excrow, 9, line['employer_cost'],row_format)
		worksheet.write(excrow, 10, line['brand_generic'],row_format)
		worksheet.write(excrow, 11, line['rebate_factor'],row_format)
		worksheet.write(excrow, 12, line['drug_cost'],row_format)
		worksheet.write(excrow, 13, line['drug_cost_before_rebate'],row_format)
		worksheet.write(excrow, 14, line['sc_unit_price'],row_format)
		worksheet.write(excrow, 15, line['unit_price'],row_format)
		worksheet.write(excrow, 16, line['unit_price_before_rebate'],row_format)
		worksheet.write(excrow, 17, line['pharmacy_discount'],row_format)
		worksheet.write(excrow, 18, line['pharmacy_dispensing_fee'],row_format)
		worksheet.write(excrow, 19, line['payment_option'],row_format)
		worksheet.write(excrow, 20, line['message'],row_format)
		worksheet.write(excrow, 21, line['analysis'],row_format)
		excrow=excrow+1
		
		
	workbook.close()
compareclaimstatus()			
print('Records in Log file:',logrecordcount)
req.no_rec_received=logrecordcount

if os.environ['INSTANCE_TYPE'] == 'PROD':
	if logrecordcount ==0:
		email_log_custom('noreply@fliptrx.com','FliptIntegration@fliptrx.com','dwagle@fliptrx.com,deepthi.gollapudi@nttdata.com,LPeysekhman@fliptrx.com,kyang@fliptrx.com,TPerkins@FliptRx.com,AGoyal@FliptRx.com,Hkumar@fliptrx.com,AKarlis@FliptRx.com','ClaimStatus and Claims Matched with ScriptClaims ',['Processing of Daily Claim Reconciliation File is completed. '],None,False)
		workbook.close()
		req.close()
		exit()
	else:
		email_log('noreply@fliptrx.com','FliptIntegration@fliptrx.com','dwagle@fliptrx.com,deepthi.gollapudi@nttdata.com,LPeysekhman@fliptrx.com,kyang@fliptrx.com,TPerkins@FliptRx.com,AGoyal@FliptRx.com,Hkumar@fliptrx.com,AKarlis@FliptRx.com','Daily Claim Reconciliation File Processing - Completed',['Processing of Daily Claim Reconciliation File ','Daily Claim Summary Exception'],DCReconFile)
		workbook.close()
		req.close()
		exit()

else:
	if logrecordcount ==0:
		email_log_custom('noreply@fliptrx.com','FliptIntegration@fliptrx.com','dwagle@fliptrx.com,deepthi.gollapudi@nttdata.com,AKarlis@FliptRx.com','ClaimStatus and Claims Matched with ScriptClaims ',['Processing of Daily Claim Reconciliation File is completed. '],None,False)
		workbook.close()
		req.close()
		exit()
	else:
		email_log('noreply@fliptrx.com','FliptIntegration@fliptrx.com','dwagle@fliptrx.com,deepthi.gollapudi@nttdata.com,AKarlis@FliptRx.com','Daily Claim Reconciliation File Processing - Completed',['Processing of Daily Claim Reconciliation File ','Daily Claim Summary Exception'],DCReconFile)
		workbook.close()
		req.close()
		exit()		
		