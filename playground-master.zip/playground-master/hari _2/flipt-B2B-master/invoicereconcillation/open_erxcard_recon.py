if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
   sys.path.append(rootdir)

# it will changed based on OS
rootdir = rootdir.replace('\\', '/')
path = rootdir + os.environ['CB_DATA']
 
import json
import csv
import base64
import os
from utils import commandline
import sys
import time
import socket
import requests
import pandas as pd
from requests.auth import HTTPBasicAuth
from datetime import datetime 
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from couchbase import FMT_JSON
from utils.sendgridemail import email_log
from sclaimintegration.scriptclaimsftp import multiplefilesftptransfer_noarchive
from utils.FliptConcurrent import concurrent

# Command to run the script:
#python open_erxcard_recon.py -d domainname -t filetype -m mode
#python open_erxcard_recon.py -d GWLABS001 -t open_erx_reconciliation -m DRAFT

host = socket.gethostname()
print(host)
cluster = Cluster(os.environ['CB_URL'])
print(cluster)
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
# path = os.environ['CB_DATA']
domain,file_type,file_name,mode = commandline.main(sys.argv[1:])
currentdate = datetime.now()
displaydatetime = currentdate.strftime("%Y%m%d%H%M")
currentdate = currentdate.isoformat()
#SC Target Directory
remotepath = '/Open_eRx_Reconcilliation'
#Azure or AWS server source FTP
localpath = path+'/'+domain+'/'+file_type+'/'
transferstatus = ''
#filepath = path+'/'+domain+'/'+file_type+'/eRxReport'+str(currentdate)+'.xlsx'

req=concurrent(sys.argv[0],sys.argv[1:])
#req.writelog('test log from open_erx_reconcilliation script')

'''
req.no_rec_received=100
req.no_rec_processed=100
req.no_rec_errored=1
req.no_old_unres_err=3
req.concurrent_notes='First test for notes with records processed'
req.error_message='No errors'

req.close()
'''

def scriptclaimeRxReconciliation():
	# Get files from SriptClaims FTP Server
	prescount = 0
	rec_received =0
	prescfile=path+'/'+domain+'/'+file_type+'/log/'+'open_eRx'+str(datetime.now())+'.csv'
	log = path+'/'+domain+'/'+file_type+'/log/'+'log_'+str(currentdate)+'.txt'
	#logfile = open(log,"w")
	#logfile.write("=========================================================="+"\r\n")
	#logfile.write("================== Routed eRx Not Available in SC ===================="+"\r\n")	
	#logfile.write("=========================================================="+"\r\n")
	files = []
	files,transferstatus = multiplefilesftptransfer_noarchive(remotepath,localpath,'GET')
	print(transferstatus)
	if transferstatus == 'S':
		#Delete previous data from staging document type called open_erx_reconcilliation
		deleRx = N1QLQuery('DELETE FROM `'+os.environ['CB_INSTANCE']+'` WHERE type = "open_erx_reconcilliation"')
		cb.n1ql_query(deleRx).execute()	
		time.sleep(10)
		print("Delete previous data from staging document type called open_erx_reconcilliation")
		
		#Load the data into a staging document type called ‘open_erx_reconcilliation’ ( load prescription_id as ‘prescription_id::’+<number provided in incoming file’)
		#Loop through files that are read
		for filename in files:
			filepath = localpath+filename
			print(filepath)
			dfrecon = pd.read_csv(filepath)
			#gives the list of columnnames
			cols=list(dfrecon)
			for index,row in dfrecon.iterrows():
				d={}
				d['type'] = 'open_erx_reconcilliation'
				#for c in cols:
				#	d[c.lower()]=str(row[c])
				d['transactionid']="prescription::"+str(row['TransactionID']).strip()
				d['gpicode']=str(row['GPICode']).strip()
				d['productnamefull']=str(row['ProductNameFull']).strip()
				d['groupmember']=str(row['GroupMember']).strip()
				#insert each row in json format with type ‘open_erx_reconcilliation’
				cb.upsert(str(cb.counter('docid',delta=1).value),d, format=FMT_JSON)
				rec_received=rec_received+1
		time.sleep(10)
		
		req.no_rec_received=rec_received
		print('records in input file concurrent',req.no_rec_received)
		
	
	else:
		logfile = open(log,"w")
		logfile.write("=========================================================="+"\r\n")
		logfile.write("Error:File Not Found"+"\r\n")
		logfile.write("=========================================================="+"\r\n")
		logfile.close()
		#email_log('deepthi.gollapudi@nttdata.com','FliptIntegration@fliptrx.com',None,'Exception: No file found to reconcile Routed eRx with ScriptClaims',['File Not Found.Processing of Routed eRx Prescriptions Reconciliation Report ','Daily Rx Exception'],log,True)	
		email_log('deepthi.gollapudi@nttdata.com','deepthi.gollapudi@nttdata.com','dwagle@fliptrx.com','Exception: No file found to reconcile Routed eRx with ScriptClaims',['File Not Found.Processing of Routed eRx Prescriptions Reconciliation Report ','Daily Rx Exception'],log,True)	
		req.error_message='Error:File Not Found'
		req.close()
		sys.exit()
		
	#pulling prescriptions that have to reconciled
	# Dt:9thOct,2018 Add admin_flipt_person_id, flipt_person_id, rx_flipt_person_id, NPI, drug name to this report.
	routedpres = N1QLQuery('Select admin_flipt_person_id,flipt_person_id,rx_flipt_person_id,prescription_id,auth_id,rx_status, create_date, routed_date, filled_date, cancelled_date, npi, drug_name from `'+os.environ['CB_INSTANCE']+'` where type="prescription" and prescription_id in (select raw trim(a.prescription_id) from `'+os.environ['CB_INSTANCE']+'` a WHERE a.type = "prescription" and a.rx_status = "Routed" and DATE_DIFF_STR(clock_local("1111-11-11"),DATE_FORMAT_STR(a.routed_date,"1111-11-11"),"day") < 11 and a.rx_flipt_person_id in (select raw c.dep_flipt_person_id from `'+os.environ['CB_INSTANCE']+'` c where c.type="flipt_person_hierarchy") EXCEPT select raw trim(b.transactionid) from `'+os.environ['CB_INSTANCE']+'` b WHERE b.type = "open_erx_reconcilliation")')
	routedpres.adhoc = False	
	#print(routedpres)
	routedpres.timeout = 100
	l_flipt_flag = 0
	rpresc=pd.DataFrame()
	for rrows in cb.n1ql_query(routedpres):
		l_flipt_flag = 1
		#print(rrows)
		#prescid = rrows['prescription_id']
		rpresc=rpresc.append(rrows,ignore_index=True)
		rpresc.to_csv(prescfile,index=False)			
		prescount=prescount+1		
	if l_flipt_flag == 0:
		req.no_rec_processed = rec_received
		req.concurrent_notes="All Routed eRx are available in ScriptClaims"
		print('Notes:',req.concurrent_notes)
		print('No of records processed',req.no_rec_processed)
			
		logfile = open(log,"w")
		logfile.write("=========================================================="+"\r\n")
		logfile.write("Routed prescription data matched with SriptClaims"+"\r\n")
		logfile.write("=========================================================="+"\r\n")
		logfile.close()
		#email_log('deepthi.gollapudi@nttdata.com','FliptIntegration@fliptrx.com',None,'All Routed eRx are available in ScriptClaims',['Processing of Routed eRx Prescriptions Reconciliation Report ','Daily Rx Exception'],log,True)
		email_log('deepthi.gollapudi@nttdata.com','deepthi.gollapudi@nttdata.com','dwagle@fliptrx.com','All Routed eRx are available in ScriptClaims',['Processing of Routed eRx Prescriptions Reconciliation Report ','Daily Rx Exception'],log,True)
	else:
		#logfile.close()
		req.no_rec_errored=prescount
		req.concurrent_notes= str(prescount) +' Routed eRx prescriptions are not available in ScriptClaims'
		#print('Notes:',req.concurrent_notes)
		#print('Routed eRx not Available in SC:',req.no_rec_errored)
		#email_log('deepthi.gollapudi@nttdata.com','FliptIntegration@fliptrx.com',None,'Exception: Not all Routed eRx are available in ScriptClaims',['Processing of Routed eRx Prescriptions Reconciliation Report ','Daily Rx Exception'],prescfile,True)
		email_log('deepthi.gollapudi@nttdata.com','deepthi.gollapudi@nttdata.com','dwagle@fliptrx.com','Exception: Not all Routed eRx are available in ScriptClaims',['Processing of Routed eRx Prescriptions Reconciliation Report ','Daily Rx Exception'],prescfile,True)
	
	
scriptclaimeRxReconciliation()
print('Before concurrent class close')
req.close()