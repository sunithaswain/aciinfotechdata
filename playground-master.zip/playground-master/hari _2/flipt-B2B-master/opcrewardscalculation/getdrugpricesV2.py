if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
   sys.path.append(rootdir)

# it will changed based on OS
rootdir = rootdir.replace('\\', '/')
path = rootdir + os.environ['CB_DATA']
 
import requests
import os
import sys
import dateutil.parser as parser
import socket
import json
import base64
import pandas as pd
import pprint
from requests.auth import HTTPBasicAuth
from types import SimpleNamespace as Namespace
from decimal import Decimal
from datetime import datetime ,date ,time
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
import couchbase.subdocument as SD
from utils.sendgridemail import email_log
from utils.truevault import User_Class
url = os.environ['GRAPHQL_URL']
host = socket.gethostname()
mheaders = ""
def get_drugprices(term, ndc, address, pda, gpi, form, package_size, package_quantity, zip_code, brand_generic, days_of_supply, dosage_strength, flipt_person_id, drug_name, package_qty, dosage, gppc,pharmacy_npi,userid,custom_quantity,allpharmacies = False):
	#print(term, ndc, address, pda, gpi, form, package_size, package_quantity, zip_code, brand_generic, days_of_supply, dosage_strength, flipt_person_id, drug_name, package_qty, dosage, gppc,pharmacy_npi,userid,custom_quantity)
	# Graphql SignIn Mutation
	mutation = """mutation {signIn(email: "disha.wagle@nttdata.com", password: "123456789") {access_token}}"""
	signInrequest = requests.post(url, json={'query': mutation}, headers=mheaders)
	decoded = json.loads(signInrequest.text, object_hook=lambda d: Namespace(**d))
	#print(decoded)
	token = decoded.data.signIn.access_token
	token = token+':'
	b64Val = base64.b64encode(bytes(token, 'utf-8'))
	header = "Basic "+str(b64Val).lstrip('b')
	headers={'Authorization':header}
	
	# Graphql Query to get Token based on Truevault User ID
	
	query = 'query {getUserToken(user_id: '+userid+')}'
	tokenrequest = requests.post(url, json={'query': query}, headers=headers)
	decoded = json.loads(tokenrequest.text, object_hook=lambda d: Namespace(**d))
	#print(decoded)
	token = decoded.data.getUserToken
	token = token+':'
	b64Val = base64.b64encode(bytes(token, 'utf-8'))
	header = "Basic "+str(b64Val).lstrip('b')	
	headers={'Authorization':header}
	
	
	claim={}
	pharmacy_name = ""
	pharmacy_city = ""
	pharmacy_address = ""
	pharmacy_zip_code = ""
	drug_price = ""
	drug_baseline_price = ""
	deductible_remaining = ""
	drug_copay = ""
	drug_employer_cost = ""
	drug_out_of_pocket = ""
	drug_reward = ""
	drug_distance = ""
	drug_duration = ""
	provider_id = ""
	pbm_price = ""
	provider_name = ""
	out_of_pocket_remaining	= ""
	'''
	print("==================")
	print("inside getdrugprices")
	print(term)
	print(ndc)
	print(address)
	print(pda)
	print(gpi)
	print(form)
	print(package_size)
	print(package_quantity)
	print(zip_code)
	print(brand_generic)
	print(days_of_supply)
	print(dosage_strength)
	print(flipt_person_id)
	print(drug_name)
	print(package_qty)
	print(dosage)
	print(gppc)
	print(pharmacy_npi)
	print("==================")
	'''


	#define and call getDrugPrices mutation;

	
	mutation="""mutation (
	$term: String, 
	$ndc: String, 
	$address: String, 
	$pda: String!, 
	$gpi: String!, 
	$form: String!, 
	$package_size: String!, 
	$package_quantity: String!, 
	$zip_code: String!, 
	$brand_generic: String, 
	$days_of_supply: String, 
	$dosage_strength: String, 
	$flipt_person_id: String, 
	$drug_name: String, 
	$package_qty: String,
	$custom_quantity: Boolean,
	$dosage: String, 
	$gppc: String) {
      getDrugPrices(
	  term: $term, 
	  ndc: $ndc, 
	  address: $address, 
	  pda: $pda, 
	  gpi: $gpi, 
	  form: $form, 
	  package_size: $package_size, 
	  package_quantity: $package_quantity, 
	  zip_code: $zip_code, 
	  brand_generic: $brand_generic, 
	  days_of_supply: $days_of_supply, 
	  dosage_strength: $dosage_strength, 
	  flipt_person_id: $flipt_person_id, 
	  drug_name: $drug_name, 
	  package_qty: $package_qty, 
	  custom_quantity: $custom_quantity,
	  specialty_flag: "Y", 
	  dosage: $dosage, 
	  npi: $npi,
	  gppc: $gppc) {
        pharmacy_name
        pharmacy_city
        pharmacy_address
        pharmacy_zip_code
        drug_price
        drug_baseline_price
        deductible_remaining
        drug_copay
        drug_employer_cost
        drug_out_of_pocket
        drug_reward
        drug_distance
        drug_duration
        provider_id
        pbm_price
        provider_name
        pharmacy_npi
        out_of_pocket_remaining
		pharmacy_location
		drug_penalty
		reward_percentage
		drug_duration_value
		pbm_estimated_cost
		drug_deductible_exempt
		unit_price_before_rebate
		unit_price
		rebate_factor
		pharmacy_discount
		pharmacy_dispensing_fee
		drug_cost_before_rebate
		rebate_amount
		chaincode
		zone
      }
    }"""
	
	
	variables={"address": address, "brand_generic": brand_generic,"days_of_supply": days_of_supply,"dosage": dosage,"dosage_strength": dosage_strength,"drug_name": drug_name,"flipt_person_id": flipt_person_id,"form": form,"gpi": gpi,"gppc": gppc,"ndc": ndc,"package_qty": package_qty,"package_quantity": str(package_quantity),"package_size": str(package_size),"pda": pda, "zip_code": zip_code,"custom_quantity":bool(custom_quantity),"npi":pharmacy_npi}	
	#print(variables)
	drugprice = requests.post(url, json={'query': mutation,'variables':variables}, headers=headers)
	decoded = json.loads(drugprice.text, object_hook=lambda d: Namespace(**d))
	#print(decoded)
	#print(pharmacy_npi,'------------')
	#returns all pharmacies and corresponding drug costs
	if allpharmacies:
		return decoded.data.getDrugPrices
	#print(decoded.data.getDrugPrices)
	for x in decoded.data.getDrugPrices:
		#print(x.pharmacy_npi)
		#print(pharmacy_npi,'------------')
		if int(x.pharmacy_npi) == int(pharmacy_npi):
			print('Matched')
			pharmacy_name  = x.pharmacy_name
			pharmacy_city  = x.pharmacy_city
			pharmacy_address  = x.pharmacy_address
			pharmacy_zip_code  = x.pharmacy_zip_code
			drug_price  = x.drug_price
			drug_baseline_price  = x.drug_baseline_price
			deductible_remaining  = x.deductible_remaining
			drug_copay  = x.drug_copay
			drug_employer_cost  = x.drug_employer_cost
			drug_out_of_pocket  = x.drug_out_of_pocket
			drug_reward  = x.drug_reward
			drug_distance  = x.drug_distance
			drug_duration  = x.drug_duration
			provider_id  = x.provider_id
			pbm_price  = x.pbm_price
			provider_name  = x.provider_name
			pharmacy_npi  = x.pharmacy_npi
			out_of_pocket_remaining  = x.out_of_pocket_remaining
			#print('after calling graphql')
			#print('getdrugprices output')
	'''
	print(pharmacy_name)
	print(pharmacy_city)
	print(pharmacy_address)
	print(pharmacy_zip_code)
	print(drug_price)
	print(drug_baseline_price)
	print(deductible_remaining)
	print(drug_copay)
	print(drug_employer_cost)
	print(drug_out_of_pocket)
	print(drug_reward)
	print(drug_distance)
	print(drug_duration)
	print(provider_id)
	print(pbm_price)
	print(provider_name)
	print(pharmacy_npi)
	print(out_of_pocket_remaining)
	print('returning to main function')
	'''	

	return pharmacy_name,pharmacy_city,pharmacy_address,pharmacy_zip_code,drug_price,drug_baseline_price,deductible_remaining,drug_copay,drug_employer_cost,drug_out_of_pocket,drug_reward,drug_distance,drug_duration,provider_id,pbm_price,provider_name,pharmacy_npi,out_of_pocket_remaining
	
#pharmacy_name,pharmacy_city,pharmacy_address,pharmacy_zip_code,drug_price,drug_baseline_price,deductible_remaining,drug_copay,drug_employer_cost,drug_out_of_pocket,drug_reward,drug_distance,drug_duration,provider_id,pbm_price,provider_name,pharmacy_npi,out_of_pocket_remaining = get_drugprices("ATORVASTATIN CALCIUM", "68645048070", "111 Coolidge St, South Plainfield, 07080", "ATORVASTATIN TAB 10MG    ", "39400010100310", "TABS", "30.0", "1", "07080", "G", "30", "10 MG", "21111111", "ATORVASTATIN CALCIUM", "30 TABLET", "TABLET", "17603033","1619994746") 
#print(pharmacy_name)
#print(pharmacy_city)

#print(get_drugprices("", "", "101 Coopertown Rd, Haverford, 19041", "ROSUVASTATIN TAB 20MG    ", "39400060100320", "TABS", "30.0", "1", "19041", "G", "30", "20 MG", "1000980", "ROSUVASTATIN CALCIUM", "30 TABLET", "TABLET", "36814040","01548364334",'"94098822-739e-448c-aa29-09dacb384b9f"'))