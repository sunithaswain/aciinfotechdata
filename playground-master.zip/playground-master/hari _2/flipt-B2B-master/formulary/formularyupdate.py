########################################
# !/usr/bin/env python  
# title         : formularyupdate.py
# description   : Update formulary document from file data
# author        : Disha
# date created  : 20180101
# date last modified    : 20181212
# version       : 0.1
# maintainer    : Pal
# email         : pmuthanai@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage         : python formularyupdate.py -d GWLABS001 -t formulary -f formulary12112018.xlsx -m DRAFT
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  1.1            Pal         20181212    Added mode support logic to load the data in database
#  1.2            Pal         20181212    Added log file and send mail
#  1.3   		  Pal		  20181212	  Added remove space in columns
# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
   sys.path.append(rootdir)

# it will changed based on OS
rootdir = rootdir.replace('\\', '/')
path = rootdir + os.environ['CB_DATA']
 
import pandas as pd
from couchbase.n1ql import N1QLQuery
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
import os
from utils import commandline
import sys
from datetime import datetime
from couchbase import FMT_JSON
from utils.sendgridemail import email_log

dn,filetype,filename,mode=commandline.main(sys.argv[1:])
cluster=Cluster(os.environ['CB_URL']+'?operation_timeout=2700')
auth=PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(auth)
bucket_name=os.environ['CB_INSTANCE']
cb=cluster.open_bucket(bucket_name)


form=pd.read_excel(path+'//'+dn+'//'+filetype+'//'+filename)

logpath=path+'//'+dn+'//'+filetype+'//log//log'+datetime.now().strftime("%Y%m%d%H%M")+'.txt'
logfile = open(logpath,"w")
logfile.write("=============================================================="+"\r\n")
logfile.write("=============== Formulary Update Log ================="+"\r\n")		
logfile.write("Start time is "+ str(datetime.now()) +"\r\n")

logfile.write("No of records in File "+ str(form.shape[0]) +"\r\n")
form.fillna("",inplace=True)
cols_dict={}
for c in list(form):
	cols_dict[c.lower()]=c.replace(' ','_').lower()

form['gpi']=form['gpi'].apply(lambda x: str(x).zfill(14))
domainlist=[dn]
#if dn=='GWLABS001': domainlist=[dn,'FLIPT001']
query=N1QLQuery('SELECT META().id as id,gpi,brand_generic,create_date FROM `'+bucket_name+'` WHERE type="formulary" and company in $domain',domain=domainlist)
query.timeout=7200
meta_ids=[]
forms=pd.DataFrame()
db_records = 0
for r in cb.n1ql_query(query):
	meta_ids.append(r['id'])
	forms=forms.append({'gpi':r['gpi'],'brand_generic':r['brand_generic'],'create_date':r['create_date']},ignore_index=True)
	db_records=db_records+1
logfile.write("No of database records "+ str(db_records) +"\r\n")
if not forms.empty:
    forms['gpi']=forms['gpi'].apply(lambda x: str(x).zfill(14))
    form['brand_generic']=form['brand_generic'].apply(lambda x: str(x).strip())
ite=-1
for i,r in form.iterrows():
	
	d={}
	d['type']='formulary'
	for c in list(form):
		d[c.lower().strip().replace(' ','_')]=str(r[c])
	for dnrow in domainlist:
		ite=ite+1
		if not forms.empty and ((d['gpi']==forms['gpi'])&(d['brand_generic'].strip()==forms['brand_generic'])).any():
			d['company']=dnrow
			d['create_date']=str(forms[(d['gpi']==forms['gpi'])&(d['brand_generic'].strip()==forms['brand_generic'])]['create_date'].values[0]) 		
		else: d['create_date']=str(datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())
		d['update_date']=str(datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())
		
		if mode.upper().strip()=='FINAL':
			if ite<len(meta_ids):
				cb.upsert(str(meta_ids[ite]),d, format=FMT_JSON)
			
				
			else:
				cb.upsert(str(cb.counter('docid',delta=1).value),d, format=FMT_JSON)
	
if mode.upper().strip()=='FINAL':
	if ite+1<len(meta_ids):
		for h in range(ite+1,len(meta_ids)):
			cb.remove(meta_ids[h],quiet=True)
logfile.write("End time is "+ str(datetime.now()) +"\r\n")

logfile.write("=============================================================="+"\r\n")
logfile.close()
email_log('DWagle@fliptrx.com','DWagle@fliptrx.com','deepthi.gollapudi@nttdata.com,ssubramani@fliptrx.com,PMuthanai@fliptrx.com','Formulary Update - Completed',['Processing of Formulary update File '+logpath,'Formulary update Exception'],logpath,True)
