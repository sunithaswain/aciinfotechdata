
if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
   sys.path.append(rootdir)

# it will changed based on OS
rootdir = rootdir.replace('\\', '/')
path = rootdir + os.environ['CB_DATA']

import requests
import os
import sys
import dateutil.parser as parser
import socket
import json
import base64
import pandas as pd
import pprint
import time
import socket

from requests.auth import HTTPBasicAuth
from types import SimpleNamespace as Namespace
from decimal import Decimal
from datetime import datetime ,date 
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
import couchbase.subdocument as SD

from utils.sendgridemail import email_log
from utils.truevault import User_Class
from opcrewardscalculation.getdrugpricesV1 import get_drugprices
from notification.twilioSendSMS import sendSMS
from notification.pushnotif import send_push_message

cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
# path = os.environ['CB_DATA']
mheaders=""
url=''
url = os.environ['GRAPHQL_URL']
sent_to = ""
errorlog=pd.DataFrame()
host = socket.gethostname()

def getquantity(gpi,drugfullname,dispensedquantity,ndc):

	global errorlog
	sent_to = ""
	result={}
	
	rowindex=0
	gppcfound=False
	#get drug details based on NDC
	result['gppc']=''
	query=N1QLQuery('Select gppc from `'+os.environ['CB_INSTANCE']+'` where type="ndc_drugs" and ndc=$drugndc',drugndc=ndc)
	query.adhoc=False
	for res in cb.n1ql_query(query):
		result['gppc']=res['gppc']
	#print(result)
	quantitydf=None
	
	#get drug details based on gpi and full drug name 
	
	query=N1QLQuery('Select * from `'+os.environ['CB_INSTANCE']+'` where type="drug" and gpi=$gpicode and drug_name in (Select raw b.drug_name from `'+os.environ['CB_INSTANCE']+'` b where b.type="cp_drug_price" and b.productnamefull=$drugfullname and gpi=$gpicode limit 1)',gpicode=gpi,drugfullname=drugfullname)
	result['lm_ndc']=''
	result['equivalent_brand']=''
	result['dosage_image']=''
	drugfound=False
	gppcindex=-1
	for res in cb.n1ql_query(query):
		drugfound=True
		if len(res[os.environ['CB_INSTANCE']]['lm_ndc'])!=0: result['lm_ndc']=res[os.environ['CB_INSTANCE']]['lm_ndc'][0]
		result['dpa']=res[os.environ['CB_INSTANCE']]['pda']
		result['ddn_form']=res[os.environ['CB_INSTANCE']]['ddn_form']
		result['ddn_name']=res[os.environ['CB_INSTANCE']]['ddn_name']
		result['ddn_strength']=res[os.environ['CB_INSTANCE']]['ddn_strength']
		result['strengths']='nan'
		result['lm_strength']=res[os.environ['CB_INSTANCE']]['lm_strength']
		result['lm_form']=res[os.environ['CB_INSTANCE']]['lm_form']
		result['lm_name']=res[os.environ['CB_INSTANCE']]['lm_name']
		result['drug_type']=res[os.environ['CB_INSTANCE']]['drugtype']
		result['rxcui']=res[os.environ['CB_INSTANCE']]['rxcui']
		quantitydf=pd.DataFrame(data=res[os.environ['CB_INSTANCE']]['quantity'])
		result['ddid']=res[os.environ['CB_INSTANCE']]['ddid']
		result['dosage']=res[os.environ['CB_INSTANCE']]['dosage']
		result['brand_generic']=res[os.environ['CB_INSTANCE']]['brand_generic']
		result['drug_name']=res[os.environ['CB_INSTANCE']]['drug_name']
		result['specialty_flag']=res[os.environ['CB_INSTANCE']]['specialty_flag']
		if 'equivalent' in res[os.environ['CB_INSTANCE']]:
			if len(res[os.environ['CB_INSTANCE']]['equivalent'])>0: result['equivalent_brand']=res[os.environ['CB_INSTANCE']]['equivalent'][0]['equ_drug_name']
		
		
	
	if len(result)==0 or not drugfound:
		errorlog=errorlog.append({'Drug Full Name':drugfullname,'GPI':gpi,'Pharmacy NPI':'','Dispensed Quantity':dispensedquantity,'MemberID':'','Error':'Drug Not Found in Drug Database'},ignore_index=True)
		return result
	
	if result['gppc'] in list(quantitydf['gppc']):
		gppcfound=True
		gppcindex=quantitydf[quantitydf['gppc']==result['gppc']].index[0]
		result['custom_qty']=quantitydf.loc[gppcindex,'custom_qty']
	else:
		result['custom_qty']=quantitydf.loc[rowindex,'custom_qty']
		
	
	quantitydf['package_size']=quantitydf['package_size'].apply(lambda x:float(x))
	result['custom_quantity']=False
	
	#get quantity details based on dispensed quantity 
	
	
	if result['custom_qty']=='package_quantity':
		if float(dispensedquantity) in list(quantitydf['package_size']):
			if gppcfound and quantitydf.loc[gppcindex,'package_size']==float(dispensedquantity):
				rowindex=gppcindex
			else:
				rowindex=quantitydf[quantitydf['package_size']==float(dispensedquantity)].index[0]
			[result['dosage_strength'],result['gppc'],result['package_desc'],result['package_qty'],result['package_quantity'],result['package_size'],result['pkg_desc_cd'],result['pkg_uom'],result['quantity_type'],result['dosage_image']]=quantitydf.loc[rowindex,['dosage_strength','gppc','package_desc','package_qty','package_quantity','package_size','pkg_desc_cd','pkg_uom','quantity_type','dosage_image']]
			result['quantity']="1"
		else:
			#calculating new package_qty based on custom dispensed quantity
			psizefound=False
			if gppcfound:
				[result['dosage_strength'],result['gppc'],result['package_desc'],result['package_qty'],result['package_quantity'],result['package_size'],result['pkg_desc_cd'],result['pkg_uom'],result['quantity_type'],result['dosage_image']]=quantitydf.loc[gppcindex,['dosage_strength','gppc','package_desc','package_qty','package_quantity','package_size','pkg_desc_cd','pkg_uom','quantity_type','dosage_image']]
				result['package_quantity']=str(int(float(dispensedquantity)/quantitydf.loc[gppcindex,'package_size']))
				result['package_qty']=str(result['package_quantity'])+" "+result['quantity_type']
				result['quantity']=result['package_quantity']
				psizefound=True
			else:
				quantitydf.sort_values(by=['package_size'],ascending=[False],inplace=True)
				for ind,row in quantitydf.iterrows():
					if float(dispensedquantity)>=row['package_size']:
						psizefound=True
						[result['dosage_strength'],result['package_desc'],result['package_quantity'],result['package_size'],result['pkg_desc_cd'],result['pkg_uom'],result['quantity_type'],result['dosage_image']]=[row['dosage_strength'],row['package_desc'],str(int(float(dispensedquantity)/row['package_size'])),row['package_size'],row['pkg_desc_cd'],row['pkg_uom'],row['quantity_type'],row['dosage_image']]
						result['package_qty']=str(result['package_quantity'])+" "+result['quantity_type']
						result['quantity']=result['package_quantity']
						psizefound=True
						break
			if not psizefound:
				errorlog=errorlog.append({'Drug Full Name':drugfullname,'GPI':gpi,'Pharmacy NPI':'','Dispensed Quantity':dispensedquantity,'MemberID':'','Error':'Package Size(Custom Quantity) cannot be converted using available package sizes in Drug Database'},ignore_index=True)
				
			result['custom_quantity']=True
		
	if result['custom_qty']=='package_size':
		
		if float(dispensedquantity) in list(quantitydf['package_size']):
			if gppcfound and quantitydf.loc[gppcindex,'package_size']==float(dispensedquantity):
				rowindex=gppcindex
			else:
				rowindex=quantitydf[quantitydf['package_size']==float(dispensedquantity)].index[0]
			[result['dosage_strength'],result['package_desc'],result['package_qty'],result['package_quantity'],result['package_size'],result['pkg_desc_cd'],result['pkg_uom'],result['quantity_type'],result['gppc'],result['dosage_image']]=quantitydf.loc[rowindex,['dosage_strength','package_desc','package_qty','package_quantity','package_size','pkg_desc_cd','pkg_uom','quantity_type','gppc','dosage_image']]
			result['quantity']="1"
			
		else:
			if gppcfound:
				rowindex=gppcindex
			else:
				rowindex=0
			#updating new package_size based on custom dispensed quantity 
			[result['dosage_strength'],result['package_desc'],result['package_quantity'],result['pkg_desc_cd'],result['pkg_uom'],result['quantity_type'],result['gppc'],result['dosage_image']]=quantitydf.loc[rowindex,['dosage_strength','package_desc','package_quantity','pkg_desc_cd','pkg_uom','quantity_type','gppc','dosage_image']]
			result['package_size']=str(float(dispensedquantity))
			result['package_qty']=str(result['package_size'])+" "+result['quantity_type']
			result['quantity']="1"
			result['custom_quantity']=True
	
	return result


def create_erxcard(claimid,claim_flipt_person_id):

	global errorlog
	
	errorlog=errorlog.iloc[0:0]

	#graphql sign in
	time.sleep(2)
	claim={}
	sent_to = ""
	print('Auto eRx card creation started')			
	#collect details from scdailyclaim using claim id received as an argument
	query=N1QLQuery('Select * from `'+os.environ['CB_INSTANCE']+'` where type="scdailyclaim" and meta().id=$cid',cid=claimid)
	query.adhoc=False
	for res in cb.n1ql_query(query):
		claim.update(res[os.environ['CB_INSTANCE']])
	print(claim['claim_date'])
	query=N1QLQuery('Select filled_date from `'+os.environ['CB_INSTANCE']+'` where type="prescription" and rx_status="Filled" and DATE_DIFF_STR(DATE_FORMAT_STR($cdate,"1111-11-11"),DATE_FORMAT_STR(filled_date,"1111-11-11"),"day")<1 and rx_flipt_person_id=$cfid and gpi=$gpi',cdate=claim['claim_date'],cfid=claim_flipt_person_id,gpi=claim['gpi_code'])
	query.timeout=60
	for fdate in cb.n1ql_query(query):
		return 'Error',None,None,None,None,['Auto eRx not created because eRx got filled in last 24 hours. Customer service to investigate with pharmacy/ member'] 
	print('next')
	daysofsupplynum=claim['days_supply'].replace('-','')	
	domain=claim['account']
	bin=claim['bin']
	pcn=claim['pcn']
	groupid=claim['group']
	member_id=claim['member_id'].strip()
	dispensedquantity=claim['quantity_dispensed'].replace('-','')
	fliptpersonid=claim['member_id'].strip()[:7]
	personcode='01'
	
	if len(claim['member_id'].strip())==9: personcode=claim['member_id'].strip()[-2:]
	elif claim['person_code'].strip()!='':
		if int(claim['person_code'].strip())>1: personcode=claim['person_code']
	'''
	claim_flipt_person_id='2111111'
	fliptpersonid='2111111'
	personcode='01'
	'''
	daysofsupply=''
	if int(daysofsupplynum)<=30: daysofsupply='UP TO 30'
	elif int(daysofsupplynum)>30 and int(daysofsupplynum)<=60: daysofsupply='UP TO 60'
	elif int(daysofsupplynum)>60 and int(daysofsupplynum)<=90: daysofsupply='UP TO 90'
	else: daysofsupply='OVER 90'
	rxfliptpersonid=claim_flipt_person_id
	#deriving rx flipt person id from member id and flipt person id,first name and device token of user
	if personcode=='01': rxfliptpersonid=fliptpersonid
	accesstoken=[]
	communicationphone,communicationemail,payment_option,empphone,depphone='','','',[],[]
	obj=User_Class()
	search_option={'full_document':True,'filter':{'domain_name':{'type':'eq','value':domain,'case_sensitive':False},'flipt_person_id':{'type':'eq','value':fliptpersonid,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
	att,userid = obj.search_user(search_option)
	firstname=''
	dfirstname=''
	depaccesstoken=False
	print('finding person')
	if att!=None:
		if 'devices' in att: accesstoken.extend(att['devices'])
		firstname=att['first_name']
		if 'communication_option_email' in att: communicationemail=att['communication_option_email']
		if 'communication_option_phone' in att: 
			communicationphone=att['communication_option_phone']
			empphone.append(communicationphone)
		if 'personal_phone' in att:
			if isinstance(att['personal_phone'],list): empphone.extend(att['personal_phone'])
			if isinstance(att['personal_phone'],str): empphone.append(att['personal_phone'])
		if 'payment_option' in att: payment_option=att['payment_option']
		if claim_flipt_person_id!='':
			if att['flipt_person_id']==claim_flipt_person_id: 
				person_code=att['person_code']
				member_id=att['flipt_person_id']+""+person_code
				firstname=att['first_name']
				rxfliptpersonid=claim_flipt_person_id
				
			else:
				for d in att['dependents']:
					if d['flipt_person_id']==claim_flipt_person_id: 
						person_code=d['person_code']
						member_id=att['flipt_person_id']+""+person_code
						dfirstname=d['first_name']
						if 'user_id' in d:	
							if 'devices' in d: accesstoken.extend(d['devices'])
						rxfliptpersonid=claim_flipt_person_id
						
		else:
			if personcode!='01':
				for d in att['dependents']:
					if d['person_code']==personcode: 
						person_code=personcode
						member_id=att['flipt_person_id']+""+person_code
						rxfliptpersonid=d['flipt_person_id']
						if 'user_id' in d:	
							if 'devices' in d: accesstoken.extend(d['devices'])
							firstname=d['first_name']
						else:
							dfirstname=d['first_name']
	else:
		errorlog=errorlog.append({'Drug Full Name':'','GPI':'','Pharmacy NPI':'','Dispensed Quantity':'','MemberID':claim['member_id'],'Error':'Person Not Found in Truevault'},ignore_index=True)
	if personcode!='01':
		obj=User_Class()
		search_option={'full_document':True,'filter':{'domain_name':{'type':'eq','value':domain,'case_sensitive':False},'flipt_person_id':{'type':'eq','value':rxfliptpersonid,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
		att,userid1 = obj.search_user(search_option)
		if att!=None:
			if 'active' in att: 
				if att['active']==True:
					fliptpersonid=rxfliptpersonid
					userid=userid1
					if 'devices' in att:
						depaccesstoken=True
						del accesstoken[:]
						accesstoken.extend(att['devices'])
					dfirstname=att['first_name']
					if 'communication_option_email' in att: communicationemail=att['communication_option_email']
					if 'communication_option_phone' in att: 
						communicationphone=att['communication_option_phone']
						depphone.append(communicationphone)
					if 'personal_phone' in att:
						if isinstance(att['personal_phone'],list): depphone.extend(att['personal_phone'])
						if isinstance(att['personal_phone'],str): depphone.append(att['personal_phone'])
					if 'payment_option' in att: payment_option=att['payment_option']
					
	print(rxfliptpersonid)
	
	#getting claim processor details using pcn-bin from scdailyclaim
	query=N1QLQuery('Select claim_processor from `'+os.environ['CB_INSTANCE']+'` where type="claim_processor" and rxpcn=$rxpcn and rxbin=$rxbin',rxpcn=pcn,rxbin=bin)
	claimproc=[]
	for res in cb.n1ql_query(query):
		claimproc.append(res['claim_processor'].lower().strip())
	print(claimproc,'claim proc')
	#getting pharmacy details based on pharmacy NPI
	npi=claim['pharmacy_npi']
	print('erx npi',npi)
	query=N1QLQuery('Select pharmacyzip1,geo_lat,geo_lng,pharmacyname,cp_pharmacy_info,pharmacytype,wl_name,pharmacyaddress1||", "||pharmacycity||", "||pharmacystate||", "||pharmacyzip1 pharmaddr,pharmacynpi from `'+os.environ['CB_INSTANCE']+'` where type="cp_pharmacy" and tonumber(pharmacynpi)=$pnpi',pnpi=int(npi))
	query.adhoc=False
	query.timeout=3200
	
	zipcode,searchlocation,locationselected,preselected_pharmacy,cpstatus,pharmacytype,location='','','','','','',''
	for res in cb.n1ql_query(query):
		
		preselected_pharmacy=res['wl_name']
		pharmacytype=res['pharmacytype']
		npi=res['pharmacynpi']
		print(preselected_pharmacy,'pharma 1')
		for row in res['cp_pharmacy_info']:
			if row['claim_processor'].lower().strip() in claimproc:
				cpstatus=row['cp_status']
			if cpstatus=='inactive':
				errorlog=errorlog.append({'Drug Full Name':'','GPI':'','Pharmacy NPI':npi,'Dispensed Quantity':'','MemberID':'','Error':'Pharmacy not covered by '+','.join(x for x in claimproc)},ignore_index=True)
		zipcode=res['pharmacyzip1']
		searchlocation=res['geo_lat']+', '+res['geo_lng']
		locationselected='Current Location'
		location=res['pharmaddr']
		print(cpstatus,'cpstatus')
	if cpstatus=='':
		errorlog=errorlog.append({'Drug Full Name':'','GPI':'','Pharmacy NPI':npi,'Dispensed Quantity':'','MemberID':'','Error':'Pharmacy not Found in Database'},ignore_index=True)
	ndc=claim['product_id_ndc']
	gpi=claim['gpi_code']
	drugfullname=claim['product_name_full']
	#call function used to return drug and quantity details 
	errormsg=[]
	result=getquantity(gpi,drugfullname,dispensedquantity,ndc)
	result['pharmacy']=preselected_pharmacy
	if not errorlog.empty:
		filepath=path+'/'+domain+'/prescription/log/AutoeRxCard'+claimid+'.xlsx'
		writer=pd.ExcelWriter(filepath)
		errormsg.extend(list(errorlog['Error'].unique()))
		errormsg=[i+". Contact Product Development Team." for i in errormsg]
		errorlog.to_excel(writer,'Errors',index=False)
		writer.save()
		email_log('noreply@fliptrx.com','DWagle@fliptrx.com','SSubramani@fliptrx.com',"Auto eRx Card Creation Error",['eRx Card Creation Attempt','AutoeRx Exception'],filepath,True)
		print(errormsg)
		return 'Error',None,None,None,None,errormsg
	
	#define and call savePrescription mutation; prescription id returned
	
	mutation1="""mutation (
      $gpi: String!
      $dpa: String
      $drug: String!
      $form: String!
      $dosage: String!
      $quantity: String!
      $daysofsupply: String
      $locationSelected: String
	  $location: String
      $zipCode: String
      $ddn_form: String
      $ddn_name: String
      $ddn_strength: String
      $strengths: String
      $dosage_strength: String
      $lm_strength: String
      $lm_form: String
      $lm_name: String
      $drug_name: String
      $brand_generic: String
      $ddid: String
      $drug_type: String
      $package_desc: String
      $pkg_desc_cd: String
      $package_qty: String
      $package_quantity: String
      $package_size: String
      $pkg_uom: String
      $lm_ndc: String
      $search_location: String
      $flipt_person_id: String
      $gppc: String
      $search_prescription_id: String
      $custom_quantity: Boolean
      $quantity_type: String
      $custom_qty: String
      $admin_flipt_person_id: String
  	  $rxcui: String
      $days_of_supply: String
    ) {
      savePrescription(
        gpi: $gpi
        drug: $drug
        form: $form
        dosage: $dosage
        lm_ndc: $lm_ndc
        quantity: $quantity
        dpa: $dpa
        locationSelected: $locationSelected
		location: $location
        zipCode: $zipCode
        ddn_form: $ddn_form
        ddn_name: $ddn_name
        ddn_strength: $ddn_strength
        strengths: $strengths
        dosage_strength: $dosage_strength
        lm_strength: $lm_strength
        lm_form: $lm_form
        lm_name: $lm_name
        drug_name: $drug_name
        brand_generic: $brand_generic
        ddid: $ddid
        drug_type: $drug_type
        package_desc: $package_desc
        pkg_desc_cd: $pkg_desc_cd
        package_qty: $package_qty
        package_quantity: $package_quantity
        package_size: $package_size
        pkg_uom: $pkg_uom
        daysofsupply: $daysofsupply
        search_location: $search_location
        flipt_person_id: $flipt_person_id
        gppc: $gppc
        search_prescription_id: $search_prescription_id
        custom_quantity: $custom_quantity
        quantity_type: $quantity_type
        custom_qty: $custom_qty
        admin_flipt_person_id: $admin_flipt_person_id
        rxcui:$rxcui
        days_of_supply: $days_of_supply
      ) {
        prescription_id
      }
    }
"""
	
	variables={"gpi":gpi,"dpa":result["dpa"],"drug":result["drug_name"],"form":result["dosage"],"dosage":result["dosage"],"quantity":str(result["quantity"]),"daysofsupply":daysofsupplynum,"locationSelected":locationselected,"zipCode":zipcode,"ddn_form":result["ddn_form"],"ddn_name":result["ddn_name"],"ddn_strength":result["ddn_strength"],"strengths":"nan","dosage_strength":result["dosage_strength"],"lm_strength":result["lm_strength"],"lm_form":result["lm_form"],"lm_name":result["lm_name"],"drug_name":result["drug_name"],"brand_generic":result["brand_generic"],"ddid":result["ddid"],"drug_type":result["drug_type"],"package_desc":result["package_desc"],"pkg_desc_cd":result["pkg_desc_cd"],"package_qty":str(result["package_qty"]),"package_quantity":str(result["package_quantity"]),"package_size":str(result["package_size"]),"pkg_uom":result["pkg_uom"],"lm_ndc":result["lm_ndc"],"search_location":searchlocation,"flipt_person_id":fliptpersonid,"gppc":result["gppc"],"custom_quantity":result["custom_quantity"],"quantity_type":result["quantity_type"],"custom_qty":result["custom_qty"],"admin_flipt_person_id":"1001598","days_of_supply":daysofsupply,"location":location}
	
	
	try:
		mutation = """mutation {signIn(email: """+'"'+os.environ['BOTUSERID']+'"'+""", password: """+'"'+os.environ['BOTPWD']+'"'+""") {access_token}}"""
		signInrequest = requests.post(url, json={'query': mutation}, headers=mheaders)
		decoded = json.loads(signInrequest.text, object_hook=lambda d: Namespace(**d))
		token = decoded.data.signIn.access_token
		token = token+':'
		b64Val = base64.b64encode(bytes(token, 'utf-8'))
		header = "Basic "+str(b64Val).lstrip('b')
		headers={'Authorization':header}
		
		user_id = '"'+userid+'"'
		
		query = """query {getUserToken(user_id: """+user_id+""")}"""
		tokenrequest = requests.post(url, json={'query': query}, headers=headers)
		decoded = json.loads(tokenrequest.text, object_hook=lambda d: Namespace(**d))
		print(decoded)
		token = decoded.data.getUserToken
		token = token+':'
		b64Val = base64.b64encode(bytes(token, 'utf-8'))
		header = "Basic "+str(b64Val).lstrip('b')
		headers={'Authorization':header}
		newpresc = requests.post(url, json={'query': mutation1,'variables':variables}, headers=headers)
		
		decoded = json.loads(newpresc.text, object_hook=lambda d: Namespace(**d))
		
		prescid = decoded.data.savePrescription.prescription_id
		prescid=str(prescid)
		print("autoerx#",prescid)
		
		#make explicit updates to prescription created
		
		cb.mutate_in(prescid,SD.upsert('domain',str(domain)))
		cb.mutate_in(prescid,SD.upsert('flipt_person_id',str(fliptpersonid)))
		cb.mutate_in(prescid,SD.upsert('rx_flipt_person_id',str(rxfliptpersonid)))
		cb.mutate_in(prescid,SD.upsert('auth_id',str(claim['auth_id'])))
		cb.mutate_in(prescid,SD.upsert('equivalent_brand',result['equivalent_brand']))
		cb.mutate_in(prescid,SD.upsert('dosage_image',result['dosage_image']))
		cb.mutate_in(prescid,SD.upsert('application',"Auto eRx"))
		if result['specialty_flag']=='Y':
			cb.mutate_in(prescid,SD.upsert('specialty_flag',str("Y")))
		else:
			cb.mutate_in(prescid,SD.upsert('specialty_flag',str("N")))
		if pharmacytype!="RETAIL":
			#print(preselected_npi,'--------------------------------------')
			basketquery = """query {user {employee{ prescription_basket }}}"""
			basketid = requests.post(url, json={'query': basketquery}, headers=headers)
			decoded = json.loads(basketid.text, object_hook=lambda d: Namespace(**d))
			print('decoded 1',decoded)
			basketprescs=[]
			try:
				basketprescs.extend(decoded.data.user.employee.prescription_basket)
				checknewprescs=N1QLQuery('Select prescription_id from `'+os.environ['CB_INSTANCE']+'` where type="prescription" and rx_status="New" and gpi=$gpi and rx_flipt_person_id=$rxid and prescription_id in $prescid',rxid=str(rxfliptpersonid),prescid=basketprescs,gpi=variables['gpi'])
				checknewprescs.timeout=300
				prescpresent=False
				for r in cb.n1ql_query(checknewprescs):
					prescpresent=True
			except Exception as noprescription:
				prescpresent=False
			if not prescpresent:
				basketprescs.append(prescid)
				variables={"prescriptions_id":",".join(x for x in basketprescs)}
				updatebasket = """mutation ($prescriptions_id: String!){ updateBasket(prescriptions_id: $prescriptions_id) }"""
				basketid = requests.post(url, json={'query': updatebasket,'variables':variables}, headers=headers)
				decoded = json.loads(basketid.text, object_hook=lambda d: Namespace(**d))
				print('decoded 2',decoded)
				#basketprescs = decoded.data
				print('script in basket')
			sendresult=False
			message=pharmacytype+" Auto eRx is created for "+result["drug_name"]+". Review your basket to confirm pharmacy "+result['pharmacy']+" and shipping address."
			
			for ph in depphone:
				sent,info=sendSMS(fliptpersonid,rxfliptpersonid, ph, message)
				if sent.lower()=='success': 
					sendresult=True
					break
			if not sendresult:
				for ph in empphone:
					sent,info=sendSMS(fliptpersonid,rxfliptpersonid, ph, message)
					if sent.lower()=='success': 
						sendresult=True
						break
			return 'Success',prescid,result,fliptpersonid,rxfliptpersonid,['Script for Mail Order/Specialty in New Status']
		cb.mutate_in(prescid,SD.upsert('preselected_pharmacy',str(preselected_pharmacy)))
		cb.mutate_in(prescid,SD.upsert('preselected_npi',str(npi)))
	except Exception as e:
		print(e)
		return 'Error',None,None,None,None,['Could Not Create New eRx']
	try:
		prescrouted=False
		routeerrorlog = []
		savings = 0
		bestoptionname = ""
		if pharmacytype.upper().strip()=='RETAIL':
			prescriptionid,routeerrorlog,savings,bestoptionname=route_prescription(prescid,header,domain,bin,pcn,groupid,variables,preselected_pharmacy,npi,ndc,rxfliptpersonid,member_id,userid,payment_option,fliptpersonid)
			if prescriptionid!="":
				prescrouted=True
			else:
				return 'Error',prescid,result,fliptpersonid,rxfliptpersonid,routeerrorlog
	except Exception as e:
		print(e)
		return 'Error',prescid,result,fliptpersonid,rxfliptpersonid,['Could Not Route New Rx']
	
	
	#if device token found, send push notification to all devices used by user
	extra = {}
	notiflog={}
	success=False
	devicenum=0
	devicenum1=0
	status=cb.get(prescid)
	pstatus=status.value['rx_status']
	print(pstatus)
	if pstatus=='PA':
		routeerrorlog.append('PA status auto eRx')
	#print("savings",savings)
	if os.environ['INSTANCE_TYPE'] == 'PROD':
		
		if pstatus=='PA':
			routeerrorlog.append('PA status auto eRx')
			message="Your Prescription for "+variables['drug_name']+" received at "+preselected_pharmacy+" requires Prior Authorization before it can be filled. Please contact Flipt Concierge (833-354-7879) to initiate approval."
			sendresult=False
			for ph in depphone:
				sent,info=sendSMS(fliptpersonid,rxfliptpersonid, ph, message)
				if sent.lower()=='success': 
					sendresult=True
					break
			if not sendresult:
				for ph in empphone:
					sent,info=sendSMS(fliptpersonid,rxfliptpersonid, ph, message)
					if sent.lower()=='success': 
						sendresult=True
						break
		else:
			if len(accesstoken)>0:
				for at in accesstoken:
					if 'token' not in at: continue
					if dfirstname=='':
						if prescrouted and savings>=3:
							extra = {'message':'Hi '+firstname+', your prescription for '+variables['drug_name']+' is now available for pickup at '+preselected_pharmacy+". Or, if you'd like to save $"+str(savings)+", call Concierge to transfer Rx to "+bestoptionname+". The choice is yours!"}
							
						elif prescrouted and savings<3:
							extra = {'message':'Hi '+firstname+', your prescription is awaiting at '+preselected_pharmacy+"."}
							
						else:
							extra = {'message':'Hi '+firstname+', your prescription is awaiting at '+preselected_pharmacy+". Please confirm the price in Flipt before pickup."}
							
					else:
						if prescrouted and savings>=3:
							if not depaccesstoken:
								extra = {'message':'Hi '+firstname+', your prescription for '+variables['drug_name']+' is now available for pickup at '+preselected_pharmacy+". Or, if you'd like to save $"+str(savings)+", call Concierge to transfer Rx to "+bestoptionname+". The choice is yours!"}
								
							else:
								extra = {'message':'Hi '+dfirstname+', your prescription for '+variables['drug_name']+' is now available for pickup at '+preselected_pharmacy+". Or, if you'd like to save $"+str(savings)+", call Concierge to transfer Rx to "+bestoptionname+". The choice is yours!"}
								
						elif prescrouted and savings<3:
								if not depaccesstoken:
									extra = {'message':'Hi '+firstname+', your prescription for '+dfirstname+' is awaiting at '+preselected_pharmacy+"."}
									
								else:
									extra = {'message':'Hi '+dfirstname+', your prescription is awaiting at '+preselected_pharmacy+"."}
									
						else:
							if not depaccesstoken:
								extra = {'message':'Hi '+firstname+', your prescription for '+dfirstname+' is awaiting at '+preselected_pharmacy+". Please confirm the price in Flipt before pickup."}
								
							else:
								extra = {'message':'Hi '+dfirstname+', your prescription is awaiting at '+preselected_pharmacy+". Please confirm the price in Flipt before pickup."}
								
					response=send_push_message(at['token'][:],extra['message'],extra)
					if response==True: 
						devicenum=devicenum+1
						success=True
					else: 
						devicenum1=devicenum1+1
				if success:
					notiflog['flipt_person_id']=str(rxfliptpersonid)
					notiflog['result']="Success"
					notiflog['type']='notification_log'
					notiflog['notification_type']='auto-erx'
					notiflog['device_count']=str(devicenum)
					notiflog['prescription_id']=prescid
					notiflog['create_date']=datetime.now().isoformat()
					notiflog['update_date']=datetime.now().isoformat()
					cb.upsert(str(cb.counter('docid',delta=1).value),notiflog)
				else:
					notiflog['flipt_person_id']=str(rxfliptpersonid)
					notiflog['result']="Failure"
					notiflog['type']='notification_log'
					notiflog['notification_type']='auto-erx'
					notiflog['device_count']=str(devicenum1)
					notiflog['prescription_id']=prescid
					notiflog['create_date']=datetime.now().isoformat()
					notiflog['update_date']=datetime.now().isoformat()
					cb.upsert(str(cb.counter('docid',delta=1).value),notiflog)
	
	return 'Success',prescid,result,fliptpersonid,rxfliptpersonid,routeerrorlog
	


def route_prescription(prescription_id,header,domain,bin,pcn,groupid,variables,preselected_pharmacy,npi,ndc,rxfliptpersonid,member_id,userid,payment_option,fliptpersonid):

	alternate_effective_date = ""
	query = N1QLQuery("Select auto_route_prescription,alternate_effective_date from`"+os.environ['CB_INSTANCE']+"` where type='domain' and domain=$dn",dn=domain)
	query.timeout=60
	for row in cb.n1ql_query(query):
		alternate_effective_date=row['alternate_effective_date']
		if row['auto_route_prescription']=='N':
			return "",["Auto-route flag turned off"],0,""
	savings,bestoptioncost,bestoptionnpi,bestoptionname,result,drugpricestatus = findbestpharmacyoption(ndc,variables,rxfliptpersonid,npi,userid)	
	if drugpricestatus == 'Error1': 
		return "",["Could not find drug prices"],0,""
	if drugpricestatus == 'Error2': 
		return "",["Could not find pharmacy in the drug prices list"],0,""
	mutation="""mutation (
		$prescription_id: String
		$baseline_cost: String
		$bin: String
		$deductible_remaining: String
		$drug_copay: String
		$drug_cost: String
		$drug_deductible_exempt: Boolean
		$drug_penalty: String
		$employee_opc: String
		$employer_cost: String
		$group_id: String
		$member_id: String
		$npi: String
		$out_of_pocket_remaining: String
		$payment_option: String
		$pbm_estimated_cost: String
		$pbm_price: String
		$pcn: String
		$pharmacy: String
		$reward_percentage: String
		$rewards: String
		$chaincode: String
		$drug_cost_before_rebate: String
		$pharmacy_discount: String
		$pharmacy_dispensing_fee: String
		$rebate_amount: String
		$rebate_factor: String
		$unit_price: String
		$unit_price_before_rebate: String
		$zone: String
		$reward_share: String
		$retail_reward: String
		$total_payment: String
		$penalty_factor: String
		$pa_flag: String
		$pa_form: String
		$pa_reason: String
		$alternative_drug_rewards: String

    ) {
      v2RoutePrescription(
		prescription_id: $prescription_id
		baseline_cost: $baseline_cost
		bin: $bin
		deductible_remaining: $deductible_remaining
		drug_copay: $drug_copay
		drug_cost: $drug_cost
		drug_deductible_exempt: $drug_deductible_exempt
		drug_penalty: $drug_penalty
		employee_opc: $employee_opc
		employer_cost: $employer_cost
		group_id: $group_id
		member_id: $member_id
		npi: $npi
		out_of_pocket_remaining: $out_of_pocket_remaining
		payment_option: $payment_option
		pbm_estimated_cost: $pbm_estimated_cost
		pbm_price: $pbm_price
		pcn: $pcn
		pharmacy: $pharmacy
		reward_percentage: $reward_percentage
		rewards: $rewards
		chaincode: $chaincode
		drug_cost_before_rebate: $drug_cost_before_rebate
		pharmacy_discount: $pharmacy_discount
		pharmacy_dispensing_fee: $pharmacy_dispensing_fee
		rebate_amount: $rebate_amount
		rebate_factor: $rebate_factor
		unit_price: $unit_price
		unit_price_before_rebate: $unit_price_before_rebate
		zone: $zone
		reward_share: $reward_share
		retail_reward: $retail_reward
		total_payment: $total_payment
		penalty_factor: $penalty_factor
		pa_flag: $pa_flag
		pa_form: $pa_form
		pa_reason: $pa_reason
		alternative_drug_rewards: $alternative_drug_rewards
      ) {
        prescription_id
      }
    }
"""
	#calculate alternative_drug_rewards
	alternative_drug_rewards=""
	rxhistoryquery=N1QLQuery("Select start_date from `"+os.environ['CB_INSTANCE']+"` where type='rx_history' and flipt_person_id=$fid and gpi=$gpi and drug_name=$dn and start_date>$aed",dn=variables['drug_name'],gpi=variables['gpi'],fid=rxfliptpersonid,aed=alternate_effective_date)
	rxhistoryquery.adhoc=False
	for rxrow in cb.n1ql_query(rxhistoryquery):
		alternatedrugquery=N1QLQuery("Select TONUMBER(alternate_drug_reward_per_unit) alternate_drug_reward_per_unit from `"+os.environ['CB_INSTANCE']+"` where type='drug_alternative' and gpi=$gpi and drug_name=$dn limit 1",gpi=variables['gpi'],dn=variables['drug_name'])
		for altrow in cb.n1ql_query(alternatedrugquery):
			try:
				alternative_drug_rewards=altrow['alternate_drug_reward_per_unit']*float(variables['package_size'])*float(variables['package_quantity'])
			except Exception as e1:
				pass
	
	routevalues={"prescription_id":str(prescription_id),"baseline_cost":str(result["drug_baseline_price"].values[0]),"bin":str(bin),"deductible_remaining":str(result["deductible_remaining"].values[0]),"drug_copay":str(result["drug_copay"].values[0]),"drug_cost":str(result["drug_price"].values[0]),"drug_deductible_exempt":bool(result["drug_deductible_exempt"].values[0]),"drug_penalty":str(result["drug_penalty"].values[0]),"employee_opc":str(result["drug_out_of_pocket"].values[0]),"employer_cost":str(result["drug_employer_cost"].values[0]),"group_id":str(groupid),"member_id":str(member_id),"npi":str(npi),"out_of_pocket_remaining":str(result["out_of_pocket_remaining"].values[0]),"payment_option":payment_option,"pbm_estimated_cost":str(result["pbm_estimated_cost"].values[0]),"pbm_price":str(result["pbm_price"].values[0]),"pcn":str(pcn),"pharmacy":str(preselected_pharmacy),"reward_percentage":str(result["reward_percentage"].values[0]),"rewards":str(result["drug_reward"].values[0]),"chaincode":str(result["chaincode"].values[0]),"drug_cost_before_rebate":str(result["drug_cost_before_rebate"].values[0]),"pharmacy_discount":str(result["pharmacy_discount"].values[0]),"pharmacy_dispensing_fee":str(result["pharmacy_dispensing_fee"].values[0]),"rebate_amount":str(result["rebate_amount"].values[0]),"rebate_factor":str(result["rebate_factor"].values[0]),"unit_price":str(result["unit_price"].values[0]),"unit_price_before_rebate":str(result["unit_price_before_rebate"].values[0]),"zone":str(result["zone"].values[0]),"reward_share":str(result["reward_share"].values[0]),"retail_reward":str(result["retail_reward"].values[0]),"total_payment":str(result["total_payment"].values[0]),"penalty_factor":str(result["penalty_factor"].values[0]),"pa_flag":str(result["pa_flag"].values[0]),"pa_form":str(result["pa_form"].values[0]),"pa_reason":str(result["pa_reason"].values[0]),"alternative_drug_rewards":str(alternative_drug_rewards)}
	
	headers={'Authorization':header}
	try:
		rpresc = requests.post(url, json={'query': mutation,'variables':routevalues}, headers=headers)
		#print(newpresc.json())
		decoded = json.loads(rpresc.text, object_hook=lambda d: Namespace(**d))
		print(decoded)
		prescid = decoded.data.v2RoutePrescription.prescription_id
		prescid=str(prescid)
		cb.mutate_in(prescid,SD.upsert('flipt_person_id',str(fliptpersonid)))
		cb.mutate_in(prescid,SD.upsert('rx_flipt_person_id',str(rxfliptpersonid)))
		#print(prescid)
		return prescid,[],savings,bestoptionname
	except Exception as e:
		print("1",e)
		return '',["Could not route prescription"],0,""
		
		
	
	
def findbestpharmacyoption(ndc,variables,rxfliptpersonid,npi,userid):

	status='Error'
	try:
		trynum=0
		while trynum<2:
			result = get_drugprices("", ndc.strip(), variables['location'], variables['dpa'], variables['gpi'], variables['form'], variables['package_size'], variables['package_quantity'], variables['zipCode'], variables['brand_generic'], variables['daysofsupply'], variables['dosage_strength'], rxfliptpersonid, variables['drug_name'], variables['package_qty'], variables['dosage'], variables['gppc'],npi,'"'+userid+'"',variables['custom_quantity'],True)
			pricelist = pd.DataFrame()
			
			for r in result:
				if 'Mail Delivery' in r.drug_distance: continue
				pricelist=pricelist.append({'pharmacy_name':r.pharmacy_name,'pharmacy_city':r.pharmacy_city,'pharmacy_address':r.pharmacy_address,'pharmacy_zip_code':r.pharmacy_zip_code,'drug_price':r.drug_price,'drug_baseline_price':r.drug_baseline_price,'deductible_remaining':r.deductible_remaining,'drug_copay':r.drug_copay,'drug_employer_cost':r.drug_employer_cost,'drug_out_of_pocket':r.employee_opc,'drug_reward':r.drug_reward,'drug_distance':r.drug_distance,'drug_duration':r.drug_duration,'provider_id':r.provider_id,'pbm_price':r.pbm_price,'provider_name':r.provider_name,'pharmacy_npi':r.pharmacy_npi.lstrip('0'),'out_of_pocket_remaining':r.out_of_pocket_remaining,'pharmacy_location':r.pharmacy_location,'drug_penalty':r.drug_penalty,'reward_percentage':r.reward_percentage,'drug_duration_value':r.drug_duration_value,'pbm_estimated_cost':r.pbm_estimated_cost,'drug_deductible_exempt':r.drug_deductible_exempt,'unit_price_before_rebate':r.unit_price_before_rebate,'unit_price':r.unit_price,'rebate_factor':r.rebate_factor,'pharmacy_discount':r.pharmacy_discount,'pharmacy_dispensing_fee':r.pharmacy_dispensing_fee,'drug_cost_before_rebate':r.drug_cost_before_rebate,'rebate_amount':r.rebate_amount,'chaincode':r.chaincode,'zone':r.zone,'reward_share':r.reward_share,'retail_reward':r.retail_reward,'total_payment':r.total_payment,'penalty_factor':r.penalty_factor,'pa_flag':r.pa_flag,'pa_form':r.pa_form,'pa_reason':r.pa_reason},ignore_index=True)
			trynum=trynum+1
			if len(result)>0 and npi.lstrip('0') in list(pricelist['pharmacy_npi']):
				break
		
		if pricelist.empty or len(pricelist)==0:
			return '','','','',None,'Error1'
		elif npi.lstrip('0') not in list(pricelist['pharmacy_npi']):
			return '','','','',None,'Error2'
		for c in ['drug_out_of_pocket','drug_reward','drug_distance']:
			if c=='drug_distance':
				pricelist[c]=pricelist[c].apply(lambda x: float(x.replace(' mi','')) if 'mi' in x else float(x.replace(' ft',''))*0.000189394)
			else:
				pricelist[c]=pricelist[c].apply(lambda x: float(x))
		pricelist.sort_values(by=['drug_out_of_pocket','drug_reward','drug_distance'],ascending=[True,False,True],inplace=True)
		pricelist.reset_index(drop=True,inplace=True)
		for i,r in pricelist.iterrows():
			bestoptioncost=r['drug_out_of_pocket']
			bestoptionnpi=r['pharmacy_npi']
			bestoptionname=r['pharmacy_name']
			break
		savings=0
		
		selectedpharmacy=pricelist.loc[(pricelist['pharmacy_npi']==str(npi).lstrip('0')),:]
		
		selectedcost=selectedpharmacy['drug_out_of_pocket'].values[0]
		if int(npi)!=int(bestoptionnpi):
			if float(selectedcost)-float(bestoptioncost)>3:
				savings = float(selectedcost)-float(bestoptioncost)
		status='Success'
		return int(savings),bestoptioncost,bestoptionnpi,bestoptionname,selectedpharmacy,'Success'
	
	except Exception as e:
		print("2",e)
		return '','','','',None,'Error2'
	
	
	
