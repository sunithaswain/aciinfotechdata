if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
   sys.path.append(rootdir)

# it will changed based on OS
rootdir = rootdir.replace('\\', '/')
path = rootdir + os.environ['CB_DATA']
 
import xlsxwriter
import requests
import os
import opccmdline
import sys
import dateutil.parser as parser
import socket
import json
import pandas as pd
import base64
import time
from updatepbmprice import pbmpriceupdate
from requests.auth import HTTPBasicAuth
from types import SimpleNamespace as Namespace
from decimal import Decimal
from datetime import datetime ,date 
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from utils.sendgridemail import email_log
from utils.truevault import User_Class
from utils.FliptConcurrent import concurrent

cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
# path = os.environ['CB_DATA']
url = os.environ['GRAPHQL_URL']
domain,file_type,file_name,mode,start_text,end_text = opccmdline.main(sys.argv[1:])
req=concurrent(sys.argv[0],sys.argv[1:],2)
currentdate = datetime.now().isoformat()
filepath = path+'/'+domain+'/'+file_type+'/MonthlyReconciliationReport'+str(currentdate)+'.xlsx'
image_path = path+'/'+domain+'/'+file_type+'/gnw.PNG'
flipt_path = path+'/'+domain+'/'+file_type+'/flipt.PNG'
host = socket.gethostname()
ename = ''
fname = ''
lname = ''
subject = ''
empid = ''

# Create a workbook and add a worksheet.
workbook = xlsxwriter.Workbook(filepath)
worksheet = workbook.add_worksheet()
start_date = parser.parse(start_text)
start_date = start_date.isoformat()
end_text = end_text+' 23:59:59'
end_date = parser.parse(end_text)
end_date = end_date.isoformat()
filled_date = end_date
brand_discount = 0
generic_discount = 0
mheaders = ""
price_type = ''
print(start_date)
print(end_date)

#load invoice data
batchid=str(cb.counter('docid',delta=1).value)
invoice=pd.read_excel(path+'/'+domain+'/'+file_type+'/'+file_name)
invoice.sort_values(by=['Date/Time'],inplace=True)
invoice['TransactionID']=invoice['TransactionID'].apply(lambda x: int(x) if pd.isnull(x)==False else '')
print(invoice.head())
for i,r in invoice.iterrows():
	d=dict()
	
	for col in list(invoice):
		if col=='Date/Time': continue
		d[col.lower().replace(' ','_')]=str(r[col]).strip()
	
	d['claim_date']=r['Date/Time'].isoformat()
	d['type']='sc_invoice'
	try:
		d['claimdate_millis']=str(datetime.strptime(d['claim_date'],"%Y-%m-%dT%H:%M:%S.%f").timestamp()*1000)
	except Exception as e:
		d['claimdate_millis']=str(datetime.strptime(d['claim_date'],"%Y-%m-%dT%H:%M:%S").timestamp()*1000)
	d['batchid']=batchid
	#print(d)
	cb.upsert(str(cb.counter('docid',delta=1).value),d)
	
print(batchid)
time.sleep(10)

# Code to Sign in and Get the Header by Encoding the Access token

# Different Formats for Rows and Columns
header_format = workbook.add_format({
    'bold': True,
    'text_wrap': True,
    'valign': 'top',
	'align':'center',
    'fg_color': '#FF0000',
    'border': 1})
header_format.set_font_color('#FFFFFF')
header_format.set_border_color('#FF0000')
	
parameter_format = workbook.add_format({
    'bold': True,
    'text_wrap': True,
    'valign': 'top',
    'fg_color': '#FF0000',
    'border': 1})
parameter_format.set_font_color('#FFFFFF')	
parameter_format.set_border_color('#FF0000')

row_format = workbook.add_format({
    'bold': False,
    'text_wrap': True,
    'valign': 'top',
	'align':'center',
    'fg_color': '#FFFFFF',
    'border': 1})	
row_format.set_border_color('#FF0000')

merge_format = workbook.add_format({
    'bold': True,
    'text_wrap': True,
	'align': 'center',
    'valign': 'vcenter',
    'fg_color': '#FF0000',
    'border': 1})
merge_format.set_font_size(35)
merge_format.set_font_color('#FFFFFF')
cell_format1 = workbook.add_format({
	'text_wrap': True,
    'valign': 'top',
	'align':'center',
    'fg_color': '#44F737',
    'border': 1})	
cell_format2 = workbook.add_format({
	'text_wrap': True,
    'valign': 'top',
	'align':'center',
    'fg_color': '#FC3912',
    'border': 1})	


# Start from the first cell. Rows and columns are zero indexed.
row = 0
col = 0
subject = 'Monthly Claims Reconciliation Report - '+host
#worksheet.insert_image('A1', image_path, {'x_scale': 0.5, 'y_scale': 0.5})
worksheet.insert_image('B1', flipt_path, {'x_scale': 0.5, 'y_scale': 0.5})
cancel_date = ''
emp_refund = 0

# Set column Width
worksheet.set_column('A:A',22)
worksheet.set_column('B:B',18)
worksheet.set_column('C:C',23)
worksheet.set_column('D:D',25)
worksheet.set_column('E:E',25)
worksheet.set_column('F:F',25)
worksheet.set_column('G:G',25)
worksheet.set_column('H:H',14)
worksheet.set_column('I:I',14)
worksheet.set_column('J:J',15)
worksheet.set_column('K:K',17)
worksheet.set_column('L:L',17)
worksheet.set_column('M:M',17)
worksheet.set_column('N:N',17)
worksheet.set_column('O:O',17)


# Report Header
worksheet.merge_range('C1:F5', 'Monthly Claims Reconciliation Report', merge_format)

# Report parameters
worksheet.write(7, 0, "Statement Date Range",parameter_format)
worksheet.write(8, 0, "Domain",parameter_format)
worksheet.write(7, 1, start_date,row_format)
worksheet.write(7, 2, end_date,row_format)
worksheet.write(8, 1, domain,row_format)
worksheet.write(7, 4, "Report Generated at ",parameter_format)
worksheet.write(7, 5, currentdate, row_format)

# write it out row by row.
worksheet.write(10, 0, "Rx Number",header_format)
worksheet.write(10, 1, "Drug Name",header_format)
worksheet.write(10, 2, "GPI",header_format)
worksheet.write(10, 3, "Brand/Generic",header_format)
worksheet.write(10, 4, "Unit Price",header_format)
worksheet.write(10, 5, "Script Claim Unit Price",header_format)
worksheet.write(10, 6, "Flipt Drug Cost",header_format)
worksheet.write(10, 7, "Flipt Quantity",header_format)
worksheet.write(10, 8, "Flipt Employer Cost",header_format)
worksheet.write(10, 9, "Flipt Employee OPC",header_format)
worksheet.write(10, 10, "ScriptClaim Dispensed Quantity",header_format)
worksheet.write(10, 11, "ScriptClaim Employer Cost",header_format)
worksheet.write(10, 12, "Employer Cost Difference (SC-Flipt)",header_format)
worksheet.write(10, 13, "ScriptClaim Patient Paid",header_format)
worksheet.write(10, 14, "Flipt Status",header_format)
worksheet.write(10, 15, "Filled Date",header_format)	
worksheet.write(10, 16, "Cancelled Date",header_format)
worksheet.write(10, 17, "Message",header_format)

empcosttotal,empopctotal,clientamttotal,drugcosttotal,patientpaidtotal=0,0,0,0,0
scclaimquery = N1QLQuery('Select round(tonumber(client_due_amt),2) client_due_amt,round(tonumber(patient_pay),2) patient_paid,round(tonumber(qty),2) quantity_dispensed,transactionid from `'+os.environ['CB_INSTANCE']+'` where type="sc_invoice" and meta().id in ( select raw max(meta(t).id) from `'+os.environ['CB_INSTANCE']+'` t where t.type="sc_invoice" and t.claim_date>=$screate_date and t.claim_date<=$ecreate_date and t.trans_type in ["P","X"] and t.batchid=$bid group by t.transactionid ) order by claim_date',screate_date=start_date,ecreate_date=end_date,bid=batchid)
scclaimquery.adhoc = False
scclaimquery.timeout = 100
row = 11


for scresult in cb.n1ql_query(scclaimquery):

	prescquery = N1QLQuery('select unit_price,unit_price_before_rebate,ROUND(TONUMBER(t.drug_cost),2) as drug_cost,t.rx_status,ROUND(TONUMBER(t.employer_cost),2) as employer_cost, ROUND(TONUMBER(t.employee_opc),2) as employee_opc, ROUND(TONUMBER(t.rebate_amount),2) as rebate_amount, t.brand_generic, ROUND(TONUMBER(t.drug_cost_before_rebate),2) as drug_cost_before_rebate, t.npi, t.prescription_id, ROUND(TONUMBER(t.pharmacy_discount)/100,3) as pharmacy_discount, ROUND(TONUMBER(t.pharmacy_dispensing_fee),2) as pharmacy_dispensing_fee, t.filled_date, t.cancelled_date, t.routed_date, tonumber(t.package_size)*tonumber(t.quantity) as qty, t.gpi, t.drug_name, t.payment_option from `'+os.environ['CB_INSTANCE']+'` t Where t.type = "prescription" and t.prescription_id=$pid and t.pharmacy != "nan" and ((t.filled_date >= $screate_date and t.filled_date <= $ecreate_date) or (t.cancelled_date >= $screate_date and t.cancelled_date <= $ecreate_date) or ((t.routed_date >= $screate_date and t.routed_date <= $ecreate_date))) and t.rx_status in ["Filled","Cancelled","Routed"] and t.filled_date is valued and t.flipt_person_id in (select raw x.dep_flipt_person_id from `'+os.environ['CB_INSTANCE']+'` x where x.type = "flipt_person_hierarchy")',screate_date=start_date,ecreate_date=end_date,pid="prescription::"+str(scresult['transactionid']).strip())
	
	prescquery.adhoc=False
	prescquery.timeout=100
	prescfound=False
	for prescrow in cb.n1ql_query(prescquery):
		#print(scrow['transaction_id'])
		prescfound=True
		filled_date=''
		cancelled_date=''
		routed_date=''
		scunitprice=''
		scdailyclaimquery=N1QLQuery('Select CASE WHEN multisource_code="N" THEN tonumber(awp_unit) ELSE tonumber(client_mac_price) END sc_unit_price from `'+os.environ['CB_INSTANCE']+'` where type="scdailyclaim" and claim_type="P" and claim_date>=$strtdate and claim_date<=$enddate and transaction_id=$pid order by claim_date desc limit 1',strtdate=start_date,enddate=end_date,pid="prescription::"+str(scresult['transactionid']).strip())
		for scdrow in cb.n1ql_query(scdailyclaimquery):
			scunitprice=scdrow['sc_unit_price']
			print(scunitprice)
		drug_cost=prescrow['drug_cost']
		if 'filled_date' in prescrow: filled_date=prescrow['filled_date']
		if 'cancelled_date' in prescrow: cancelled_date=prescrow['cancelled_date']
		if 'routed_date' in prescrow: routed_date=prescrow['routed_date']
		#actualempcost = scresult['client_ing_cost']+scresult['client_disp_fee']-
		actualempcost = scresult['client_due_amt']
		brand_generic = prescrow['brand_generic']
		drug_name=prescrow['drug_name']
		gpi=prescrow['gpi']
		employer_cost=prescrow['employer_cost']
		empopc=prescrow['employee_opc']
		qty=prescrow['qty']
		npi=prescrow['npi']
		#print(scresult['transactionid'])
		unitprice=""
		try:
			unitprice=prescrow['unit_price']
			if brand_generic=='T': unitprice=prescrow['unit_price_before_rebate']
		except Exception as e:
			unitprice=""
		rebate_amount=0
		drug_cost_before_rebate=''
		
		#if routed_date> '2018-07-18T00:56:31.424921' and 'rebate_amount' in prescrow:
		if brand_generic=='T':
			rebate_amount=prescrow['rebate_amount']
			drug_cost_before_rebate=prescrow['drug_cost_before_rebate']
			drug_cost=drug_cost_before_rebate
			employer_cost=drug_cost-empopc
		'''
		elif routed_date< '2018-07-18T00:56:31.424921':
			drugdbquery = N1QLQuery('Select cp.pricetype from `'+os.environ['CB_INSTANCE']+'` b unnest b.cp_price cp where b.type="cp_drug_price" and b.gpi=$gpi and b.drug_name=$dn limit 1',gpi=prescrow['gpi'],dn=prescrow['drug_name'])
			drugdbquery.adhoc=False
			drugdbquery.timeout=100
			for dbrow in cb.n1ql_query(drugdbquery):
				if dbrow['pricetype']=='AWP':
					pharmaquery = N1QLQuery('Select tonumber(cp.pharmbrandpriceamt) pharmbrandpriceamt,tonumber(cp.pharmbrandpriceamtmo) pharmbrandpriceamtmo,tonumber(cp.pharmbrandpricefee) pharmbrandpricefee,tonumber(cp.pharmbrandpricefeemo) pharmbrandpricefeemo,b.pharmacytype from `'+os.environ['CB_INSTANCE']+'` b unnest b.cp_pharmacy_info cp where b.type="cp_pharmacy" and b.pharmacynpi=$pnpi limit 1',pnpi=prescrow['npi'])
					pharmaquery.timeout=100
					for pharmrow in cb.n1ql_query(pharmaquery):
						if pharmrow['pharmacytype']=='RETAIL':
							drug_cost=drug_cost-pharmrow['pharmbrandpricefee']
							drug_cost=drug_cost*(pharmrow['pharmbrandpriceamt']/(pharmrow['pharmbrandpriceamt']-5))
						else:
							drug_cost=drug_cost-pharmrow['pharmbrandpricefeemo']
							drug_cost=drug_cost*(pharmrow['pharmbrandpriceamtmo']/(pharmrow['pharmbrandpriceamtmo']-5))
		'''	
		
		employer_cost=drug_cost-empopc	
		
		if prescrow['rx_status']=='Cancelled':
			if filled_date!='' or cancelled_date!='':
				if parser.parse(filled_date).month==parser.parse(cancelled_date).month:
					employer_cost=0
					empopc=0
					qty=0
					drug_cost=0
			else:
				employer_cost=employer_cost*-1
				empopc=empopc*-1
				qty=qty*-1
				drug_cost=drug_cost*-1
				
				
		
		
		if prescrow['payment_option']=='Pay via Payroll Deduction': 
			employer_cost=employer_cost+empopc
			empopc=0
			
		

		#print(prescrow,scrow,)
		
		worksheet.write(row, 0, prescrow['prescription_id'],row_format)
		worksheet.write(row, 1, drug_name,row_format)
		worksheet.write(row, 2, gpi,row_format)
		worksheet.write(row, 3, brand_generic,row_format)
		worksheet.write(row, 4, unitprice,row_format)
		worksheet.write(row, 5, scunitprice,row_format)
		worksheet.write(row, 6, drug_cost,row_format)
		worksheet.write(row, 7,qty,row_format)
		worksheet.write(row, 8, employer_cost,row_format)
		worksheet.write(row, 9, empopc,row_format)
		if float(scresult['quantity_dispensed'])>float(qty):
			worksheet.write(row, 10,scresult['quantity_dispensed'],cell_format2)
		elif float(scresult['quantity_dispensed'])<float(qty):
			worksheet.write(row, 10,scresult['quantity_dispensed'],cell_format1)
		else:
			worksheet.write(row, 10,scresult['quantity_dispensed'],row_format)
			
		if float(actualempcost)>float(employer_cost) and (abs(float(actualempcost))-abs(float(employer_cost)))>3:
			worksheet.write(row, 11,actualempcost,cell_format2)
		elif float(actualempcost)<float(employer_cost) and (abs(float(employer_cost))-abs(float(actualempcost)))>3:
			worksheet.write(row, 11,actualempcost,cell_format1)
		else:
			worksheet.write(row, 11,actualempcost,row_format)
		if abs(float(employer_cost)-float(actualempcost))>1: worksheet.write(row, 12,float(employer_cost)-float(actualempcost),row_format)
		else: worksheet.write(row, 12,"0",row_format)
		if prescrow['rx_status']=='Filled' and float(scresult['patient_paid'])>float(empopc) and (abs(float(scresult['patient_paid']))-abs(float(empopc)))>3:
			worksheet.write(row, 13,scresult['patient_paid'],cell_format2)
		elif prescrow['rx_status']=='Filled' and float(scresult['patient_paid'])<float(empopc) and (abs(float(scresult['patient_paid']))-abs(float(empopc)))>3:
			worksheet.write(row, 13,scresult['patient_paid'],cell_format1)
		else:
			worksheet.write(row, 13,scresult['patient_paid'],row_format)
		
		worksheet.write(row, 14, prescrow['rx_status'],row_format)
		worksheet.write(row, 15, filled_date,row_format)	
		worksheet.write(row, 16,cancelled_date,row_format)
		worksheet.write(row, 17, "",row_format)
		
		empcosttotal=empcosttotal+float(employer_cost)
		empopctotal=empopctotal+float(empopc)
		clientamttotal=clientamttotal+actualempcost
		drugcosttotal=drugcosttotal+float(drug_cost)
		patientpaidtotal=patientpaidtotal+scresult['patient_paid']
		#print(row)
		
	
		row = row + 1
	if not prescfound:
		worksheet.write(row, 0, scresult['transactionid'],row_format)
		worksheet.write(row, 1, "",row_format)
		worksheet.write(row, 2, "",row_format)
		worksheet.write(row, 3, "",row_format)
		worksheet.write(row, 4, "",row_format)
		worksheet.write(row, 5, "",row_format)
		worksheet.write(row, 6, "",row_format)
		worksheet.write(row, 7, "",row_format)
		worksheet.write(row, 8, "",row_format)
		worksheet.write(row, 9, "",row_format)
		worksheet.write(row, 10,scresult['quantity_dispensed'],row_format)
		actualempcost = scresult['client_due_amt']
		worksheet.write(row, 11,actualempcost,row_format)
		worksheet.write(row, 12, "",row_format)
		worksheet.write(row, 13,scresult['patient_paid'],row_format)
		worksheet.write(row, 14, "",row_format)
		worksheet.write(row, 15, "",row_format)
		worksheet.write(row, 16, "",row_format)
		worksheet.write(row, 17, "Unable to Reconcile",row_format)
		row=row+1
			
worksheet.write(row, 0, "Total : ",header_format)
worksheet.write(row, 6, drugcosttotal,row_format)
worksheet.write(row, 9, empopctotal,row_format)
worksheet.write(row, 8, empcosttotal,row_format)
worksheet.write(row, 11, clientamttotal,row_format)
worksheet.write(row, 13, patientpaidtotal,row_format)

	
workbook.close()

if os.environ['INSTANCE_TYPE'] != 'PROD':		
	email_log('DWagle@fliptrx.com','DWagle@fliptrx.com','SSubramani@fliptrx.com,deepthi.gollapudi@nttdata.com',subject,['Processing of Rx Claims Reconciliation Report '+str(file_name),'Daily Rx Exception'],filepath,True)
else :
	email_log('DWagle@fliptrx.com','DWagle@fliptrx.com','SSubramani@fliptrx.com,deepthi.gollapudi@nttdata.com',subject,['Processing of Rx Claims Reconciliation Report '+str(file_name),'Daily Rx Exception'],filepath,True)
	#email_log('DWagle@GWLabs.com','LPeysekhman@GWLabs.com','kyang@fliptrx.com',subject,['Processing of Claims Reconciliation Report '+str(file_name),'Daily Rx Exception'],filepath,True)

#os.remove(filepath)
req.close()