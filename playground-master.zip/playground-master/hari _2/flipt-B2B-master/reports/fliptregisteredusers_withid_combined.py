if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
   sys.path.append(rootdir)

# it will changed based on OS
rootdir = rootdir.replace('\\', '/')
path = rootdir + os.environ['CB_DATA']
 
import requests
from requests.auth import HTTPBasicAuth
import socket
import json
import base64
import pprint
import pandas as pd
from couchbase.cluster import Cluster 
from couchbase.cluster import PasswordAuthenticator
from couchbase.n1ql import N1QLQuery
import sendgrid
import os
import sys, traceback
from sendgrid.helpers.mail import *
from datetime import datetime
from couchbase import FMT_JSON
import sendgrid
from sendgrid.helpers.mail import Email, Content,Attachment, Substitution, Mail 
import urllib.request as urllib
import base64
from pandas import ExcelWriter
from types import SimpleNamespace as Namespace
from utils.FliptConcurrent import concurrent

req=concurrent(sys.argv[0],'')
print('Flipt Registered Users with ID Begin: ',datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())
api_key=os.environ['TV_API_KEY']
#domain_name,file_type,file_name,mode=commandline.main(sys.argv[1:])
cluster = Cluster(os.environ['CB_URL'])
bucket_name=os.environ['CB_INSTANCE']
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(bucket_name)
mutation = """mutation {signIn(email: """+'"'+os.environ['BOTUSERID']+'"'+""", password: """+'"'+os.environ['BOTPWD']+'"'+""") {access_token}}"""
url = os.environ['GRAPHQL_URL']
mheaders=""
signInrequest = requests.post(url, json={'query': mutation}, headers=mheaders)
decoded = json.loads(signInrequest.text, object_hook=lambda d: Namespace(**d))
print(signInrequest.url)
token = decoded.data.signIn.access_token
token = token+':'
b64Val = base64.b64encode(bytes(token, 'utf-8'))
loginheader = "Basic "+str(b64Val).lstrip('b')
df1=pd.DataFrame()
registeredusers=0


class User_Class(object):

    def __init__(self,username=None,password=None,attributes=None,group_ids=None,status=None):
        self.username=username
        self.password=password
        self.attributes=attributes
        self.group_ids=group_ids
        self.status=status
 
    def search_user(self,search_option):
                 
        
        search_opt=base64.b64encode(str.encode(json.dumps(search_option)))
        data={'search_option':search_opt}
        r=requests.post('https://api.truevault.com/v1/users/search',auth=HTTPBasicAuth(api_key, ''),data=data)
        response=r.json()
        #print(response)
        if 'data' not in response: return None,None
        if len(response['data']['documents'])==0 and r.status_code==200: return None,None
        att=json.loads(str(base64.b64decode(response['data']['documents'][0]['attributes']),'utf-8'))
        #print(att)
        userid=response['data']['documents'][0]['user_id']
        return att,userid
		
    def filterusers(self,username):
        filters=['test','domandtom','rey1@company','nttdata','wecare','bluelabel','admin']
        filtered=False
        for xc in filters:
            if xc in username:
                filtered=True
                break
        return filtered				

    def read_user(self,userid):
    
        params={'full':True}
        try:
            r=requests.get('https://api.truevault.com/v2/users/%s' % str(userid),auth=HTTPBasicAuth(api_key, ''),params=params,timeout=10)
            return r.json()		
        except Exception as e:
            type, value, etraceback = sys.exc_info()
            error=""
            x=traceback.format_exception(type, value, etraceback)
            for i in x:
                error=error+i
        return None
    
    def get_all_users_with_id(self):

        global df1,loginheader,registeredusers
        
        usernum=0
        finaldf=pd.DataFrame()
        df=pd.DataFrame()
        r=requests.get('https://api.truevault.com/v1/users',auth=HTTPBasicAuth(api_key,''),timeout=10)
        response=r.json()
        obj=User_Class()
        totalusers=len(response['users'])
        print("Total Number of Users: ",totalusers)
        for i in response['users']:
            usernum=usernum+1
            if usernum%1000==0:
                df=pd.DataFrame()
                finaldf=finaldf.append(df,ignore_index=True)
            #print(i['username'])
            result=obj.read_user(i['user_id'])
            #print(i[''])
            try:
                att=result['users'][0]['attributes']
            except Exception as e:
                continue
            if self.filterusers(i['username'])==False:
                self.getclaimed_users(att,i['username'])
            if 'parent_user_id' in att: continue
            userid='"'+i['user_id']+'"'
            useraccessquery = 'query {getUserToken(user_id: '+userid+')}'
            userheader={'Authorization':loginheader}
            received=False	
            attempts=0			
            while not received:
                attempts=attempts+1
                try:
                    tokenrequest = requests.post(url, json={'query': useraccessquery}, headers=userheader)
                    decoded = json.loads(tokenrequest.text, object_hook=lambda d: Namespace(**d))
                    received=True
                    token = decoded.data.getUserToken
                    token = token+':'
                    b64Val = base64.b64encode(bytes(token, 'utf-8'))
                    header = "Basic "+str(b64Val).lstrip('b')	
                    headers={'Authorization':header}
                except Exception as e:
                    if attempts>3: break
            
            dedopcrem={}
            try:
                gqlquery="query {user {employee{flipt_person_id,deductible_remaining,individual_out_of_pocket_remaining,family_deductible_remaining,     family_out_of_pocket_remaining,dependents {flipt_person_id,deductible_remaining,individual_out_of_pocket_remaining,family_deductible_remaining,    		family_out_of_pocket_remaining }}}}"
                dedopcremaining = requests.post(url, json={'query': gqlquery}, headers=headers)
                decoded = json.loads(dedopcremaining.text, object_hook=lambda d: Namespace(**d))
                dedopcrem['family']=[str(round(float(decoded.data.user.employee.family_deductible_remaining),0)),str(round(float(decoded.data.user.employee.family_out_of_pocket_remaining),0))]
                #print(decoded.data.user.employee.flipt_person_id)
                dedopcrem[decoded.data.user.employee.flipt_person_id]=[str(round(float(decoded.data.user.employee.deductible_remaining),0)),str(round(float(decoded.data.user.employee.individual_out_of_pocket_remaining),0))]
                for dep in decoded.data.user.employee.dependents:
                    dedopcrem[dep.flipt_person_id]=[str(round(float(dep.deductible_remaining),0)),str(round(float(dep.individual_out_of_pocket_remaining),0))]
                #print(dedopcrem)
            except Exception as e:
                _=1
            cl,fn,rel,gender,dob,add1,add2,city,state,zipc,aetnaid,depid,ln,ei,fid,phones,user,active,phonenumbers,opcremain,dedremain,famded,famopc,workloc,ctdate,fmid='','','','','','','','','','','','','','','',[],'Employee','','','','','','','','',''
            if 'location' in att:
                workloc=str(att['location'])			
            if 'family' in dedopcrem:
                famded=dedopcrem['family'][0]
                famopc=dedopcrem['family'][1]
            if 'claimed' in att: 
                cl='Registered'
            if 'gender' in att: 
                gender=str(att['gender'])
            if 'date_of_birth' in att: 
                dob=str(att['date_of_birth'])
            if 'home_address_1' in att: 
                add1=str(att['home_address_1'])
            if 'home_address_2' in att: 
                add2=str(att['home_address_2'])
            if 'city' in att: 
                city=str(att['city'])
            if 'state' in att: 
                state=str(att['state'])
            if 'zip' in att: 
                zipc=str(att['zip'])				
            if 'first_name' in att:
                fn=str(att['first_name'])
            if 'last_name' in att:
                ln=str(att['last_name'])
            if 'employee_id' in att:
                ei=str(att['employee_id'])
            if 'flipt_person_id' in att:
                fid=str(att['flipt_person_id'])
            if 'flipt_person_id' in att and 'person_code' in att:
                fmid=str(att['flipt_person_id'])+str(att['person_code'])
            if 'carrier_phonenumbers' in att:
                if len(att['carrier_phonenumbers'])!=0: phonenumbers=att['carrier_phonenumbers'][0]
            if 'active' in att:
                active=str(att['active'])
            if 'coverage_termination_date' in att:
                ctdate=str(att['coverage_termination_date'])
            if fid!='':
                if fid in dedopcrem:
                    dedremain=dedopcrem[fid][0]
                    opcremain=dedopcrem[fid][1]
                query=N1QLQuery('Select ins_carrier from `'+os.environ['CB_INSTANCE']+'` where type="flipt_person_hierarchy" and dep_flipt_person_id=$fliptid and ins_carrier is not missing',fliptid=fid)
                
                for qres in cb.n1ql_query(query):
                    for rec in qres['ins_carrier']:
                        if rec['ins_carrier_name']=='Aetna':
                            aetnaid=rec['ins_carrier_member_id']
                            depid=rec['ins_relationship_code']
                
			
            df=df.append({'Username':i['username'],'First Name':fn,'Last Name':ln,'Employee_ID':ei,'Claimed':cl,'User':user,'Flipt Person ID':fid,'Flipt Member ID':fmid,'Gender':gender,'Date of Birth':dob,'Home Address1':add1,'Home Address2':add2,'City':city,'State':state,'Zip':zipc,'Relationship':'','Aetna Member ID':aetnaid,'Aetna Relationship ID':depid,'Phone':phonenumbers,'Active':active,'Individual Deductible Remaining':dedremain,'Individual Out of Pocket Remaining':opcremain,'Family Deductible Remaining':famded,'Family Out of Pocket Remaining':famopc,'Work Location':workloc,'Coverage Termination Date':ctdate},ignore_index=True)
            if 'dependents' in att:
                for d in att['dependents']:
                    user='Dependent'
                    cl,gender,email,active,opcremain,dedremain,ctdate,fmid='','','','','','','',''
                    if 'email' in d: 
                        email=d['email']
                        cl='Registered'
                    if 'date_of_birth' in d: dob=str(d['date_of_birth'])
                    if 'home_address_1' in d: add1=str(d['home_address_1'])
                    if 'home_address_2' in d: add2=str(d['home_address_2'])
                    if 'city' in d: city=str(d['city'])
                    if 'state' in d: state=str(d['state'])
                    if 'zip' in d: zipc=str(d['zip'])
                    if 'first_name' in d: fn=str(d['first_name'])
                    if 'last_name' in d: ln=str(d['last_name'])
                    if 'employee_id' in d: ei=str(d['employee_id'])
                    if 'flipt_person_id' in d: fid=str(d['flipt_person_id'])
                    if 'flipt_person_id' in d and 'person_code' in d: fmid=str(att['flipt_person_id'])+str(d['person_code'])
                    if 'relationship' in d: rel=str(d['relationship'])
                    if 'gender' in d: gender=str(d['gender'])
                    if 'active' in d:
                        active=str(att['active'])					
                    if 'coverage_termination_date' in d:
                        ctdate=str(d['coverage_termination_date'])					
                    if fid!='':
                        if fid in dedopcrem:
                            dedremain=dedopcrem[fid][0]
                            opcremain=dedopcrem[fid][1]
                        query=N1QLQuery('Select ins_carrier from `'+os.environ['CB_INSTANCE']+'` where type="flipt_person_hierarchy" and dep_flipt_person_id=$fliptid and ins_carrier is not missing',fliptid=fid)
                        for qres in cb.n1ql_query(query):
                            for rec in qres['ins_carrier']:
                                aetnaid=rec['ins_carrier_member_id']
                                depid=rec['ins_relationship_code']
								
                    #Added ctdate on 21stSep    
                    df=df.append({'Username':email,'First Name':fn,'Last Name':ln,'Employee_ID':ei,'Claimed':cl,'User':user,'Flipt Person ID':fid,'Flipt Member ID':fmid,'Gender':gender,'Date of Birth':dob,'Home Address1':add1,'Home Address2':add2,'City':city,'State':state,'Zip':zipc,'Relationship':rel,'Aetna Member ID':aetnaid,'Aetna Relationship ID':depid,'Phone':phonenumbers,'Active':active,'Individual Deductible Remaining':dedremain,'Individual Out of Pocket Remaining':opcremain,'Family Deductible Remaining':famded,'Family Out of Pocket Remaining':famopc,'Work Location':'','Coverage Termination Date':ctdate},ignore_index=True)
            #print(df)
        alluserscheck,registereduserscheck=False,False
        finaldf=finaldf.append(df,ignore_index=True)		
        finaldf.reset_index(drop=True,inplace=True)
        finaldf.sort_values(by=['Employee_ID','User'],ascending=[True,False],inplace=True)  
        columns=['Relationship','User','Date of Birth','Aetna Member ID','Aetna Relationship ID','Flipt Person ID','Flipt Member ID','Gender','First Name','Last Name','Home Address1','Home Address2','City','State','Zip','Phone','Work Location','Employee_ID','Username','Individual Deductible Remaining','Individual Out of Pocket Remaining','Family Deductible Remaining','Family Out of Pocket Remaining','Claimed','Active','Coverage Termination Date']		
        writer=ExcelWriter(path+'//GWLABS001//employee//AllUsers'+str(datetime.strftime(datetime.now(),'%m%d%Y'))+'.xlsx')
        df[columns].to_excel(writer,'Sheet1',index=False)
        writer.save()
        if len(finaldf)>=totalusers :  alluserscheck=True
        df1.reset_index(drop=True,inplace=True)
        df1.sort_values(by=['Employee_ID','User'],ascending=[True,False],inplace=True)    
        writer=ExcelWriter(path+'//GWLABS001//employee//FliptRegisteredUsers'+str(datetime.strftime(datetime.now(),'%m%d%Y'))+'.xlsx')
        columns=['Claimed','Claimed Date','Employee_ID','Email','First Name','Last Name','User','# of Dependents','Communication Option','Personal Email','Personal Phone','Employment Status','Active','Push Notification','Coverage Termination Date']
        df1[columns].to_excel(writer,'Sheet1',index=False)
        writer.save() 
        req.no_rec_received=registeredusers
        if len(df1)==registeredusers :  registereduserscheck=True  
        return alluserscheck,registereduserscheck,len(finaldf),len(df1)		
		
    def getclaimed_users(self,att,username):
	
        if 'test' in att['employee_id'].strip().lower(): return
        global df1,registeredusers

        cl=''
        cd = ''
        commctnoption=''
        personalemail=''
        personalphone,active,empstatus,pushnotif,ctdate='','','','Disabled',''
        #print(i['username'])

        if 'claimed_date' in att: cd = str(att['claimed_date'])
        if ('gwlabs' in username.lower() or 'fliptrx' in username.lower()) and 'claimed' in att: 
            registeredusers=registeredusers+1
            cl=str(att['claimed']) 
            if 'employment_status' in att: empstatus=att['employment_status']
            if 'active' in att: active=att['active']
            if 'communication_option' in att: commctnoption=att['communication_option']
            if 'personal_email' in att: personalemail=att['personal_email']
            if 'personal_phone' in att: personalphone=att['personal_phone']
            if 'devices' in att: pushnotif='Enabled'
            if 'coverage_termination_date' in att: ctdate=att['coverage_termination_date']
            numofdeps=0
            if 'dependents' in att: numofdeps=len(att['dependents'])
            df1=df1.append({'First Name':att['first_name'],'Last Name':att['last_name'],'Employee_ID':att['employee_id'],'Claimed':cl,'User':'Employee','Email':att['work_email'],'Claimed Date':cd,'# of Dependents':numofdeps,'Communication Option':commctnoption,'Personal Email':personalemail,'Personal Phone':personalphone,'Employment Status':empstatus,'Active':active,'Push Notification':pushnotif,'Coverage Termination Date':ctdate},ignore_index=True)
        elif 'claimed' in att:
	        registeredusers=registeredusers+1
	        if 'communication_option' in att: commctnoption=att['communication_option']
	        if 'personal_email' in att: personalemail=att['personal_email']
	        if 'personal_phone' in att: personalphone=att['personal_phone']
	        if 'coverage_termination_date' in att: ctdate=att['coverage_termination_date']
	        df1=df1.append({'First Name':att['first_name'],'Last Name':att['last_name'],'Employee_ID':att['employee_id'],'Claimed':str(att['claimed']),'User':'Dependent','Email':att['email'],'Claimed Date':cd,'# of Dependents':'','Communication Option':commctnoption,'Personal Email':personalemail,'Personal Phone':personalphone,'Employment Status':empstatus,'Active':active,'Push Notification':'','Coverage Termination Date':ctdate},ignore_index=True)

	    
		
    def sendemail(self):
        allcountcheck,registeredcheck,totalnum,regusers=self.get_all_users_with_id()
           
        sender='noreply@fliptrx.com'
        receiver1='DWagle@fliptrx.com'
        receivers=['SSubramani@fliptrx.com']
        host = socket.gethostname()
        sg,from_email,to_email,subject,filepath,content=None,None,None,None,None,None 
        #email report flipt all users with id
        if allcountcheck: 

            if os.environ['INSTANCE_TYPE']=='PROD': receivers=['kyang@fliptrx.com','CNg@GWLabs.com','LPeysekhman@GWLabs.com','SSubramani@fliptrx.com','TGambill@fliptrx.com','ASerrano@fliptrx.com','SPal@fliptrx.com','deepthi.gollapudi@nttdata.com','Rjuhring@fliptrx.com','Jpowell@fliptrx.com']
            sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))
            from_email = Email(sender)
            to_email = Email(receiver1)
            subject = 'FliptRx All Users with ID'
            filepath= path+'//GWLABS001//employee//AllUsers'+str(datetime.strftime(datetime.now(),'%m%d%Y'))+'.xlsx'
            content = Content("text/plain", 'Attached is a list of all the users of FliptRx App as of '+str(datetime.strftime(datetime.now(),'%m-%d-%Y'))+'.')
        else:
            sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))
            from_email = Email(sender)
            to_email = Email(receiver1)
            subject = 'FliptRx All Users with ID - ERROR!'
            filepath= path+'//GWLABS001//employee//AllUsers'+str(datetime.strftime(datetime.now(),'%m%d%Y'))+'.xlsx'
            content = Content("text/plain", 'Attached is a list of all the users of FliptRx App as of '+str(datetime.strftime(datetime.now(),'%m-%d-%Y'))+'. Only '+str(totalnum)+' users found in this report. Please Investigate.')
        mail = Mail(from_email, subject, to_email, content)
        with open(filepath,'rb') as f:
            data=f.read()
            f.close()
        encoded=base64.b64encode(data).decode()
        attachment=Attachment()
        attachment.content = encoded
        attachment.type = "application/pdf"
        attachment.filename = 'AllUsers'+str(datetime.strftime(datetime.now(),'%m%d%Y'))+'.xlsx' 
        attachment.disposition = "attachment"
        attachment.content_id = "Example Content ID"
        mail.add_attachment(attachment)
        for ids in receivers:
            mail.personalizations[0].add_to(Email(ids))	
        response = sg.client.mail.send.post(request_body=mail.get())
        if 'AllUsers'+str(datetime.strftime(datetime.now(),'%m%d%Y'))+'.xlsx' in os.listdir(path+'//GWLABS001//employee//'):
            os.unlink(path+'//GWLABS001//employee//AllUsers'+str(datetime.strftime(datetime.now(),'%m%d%Y'))+'.xlsx')
            		
        #email report flipt registered users
        if registeredcheck:		
            if os.environ['INSTANCE_TYPE']=='PROD':
                receivers=['CNg@GWLabs.com','SPal@fliptrx.com','LPeysekhman@GWLabs.com','reports@fliptrx.com','kyang@fliptrx.com','KSeetharaman@fliptrx.com','Rjuhring@fliptrx.com','TGambill@fliptrx.com','FliptIntegration@fliptrx.com','deepthi.gollapudi@nttdata.com']
            sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))
            from_email = Email(sender)
            to_email = Email(receiver1)
            subject = 'FliptRx Registered Users'
            filepath= path+'//GWLABS001//employee//FliptRegisteredUsers'+str(datetime.strftime(datetime.now(),'%m%d%Y'))+'.xlsx'
            content = Content("text/plain", 'Attached is a list of all the employees & dependents who have registered in Flipt App as of '+str(datetime.strftime(datetime.now(),'%m-%d-%Y'))+'.')
        else:
            #receivers=['SSubramani@fliptrx.com']
            receivers=['deepthi.gollapudi@nttdata.com']
            sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))
            from_email = Email(sender)
            to_email = Email(receiver1)
            subject = 'FliptRx Registered Users - ERROR!'
            filepath= path+'//GWLABS001//employee//FliptRegisteredUsers'+str(datetime.strftime(datetime.now(),'%m%d%Y'))+'.xlsx'
            content = Content("text/plain", 'Attached is a list of all the employees & dependents who have registered in Flipt App as of '+str(datetime.strftime(datetime.now(),'%m-%d-%Y'))+'. Only '+str(regusers)+' users found in the report. Please Investigate.')            
        mail = Mail(from_email, subject, to_email, content)
        with open(filepath,'rb') as f:
            data=f.read()
            f.close()
        encoded=base64.b64encode(data).decode()
        attachment=Attachment()
        attachment.content = encoded
        attachment.type = "application/pdf"
        attachment.filename = 'FliptRegisteredUsers'+str(datetime.strftime(datetime.now(),'%m%d%Y'))+'.xlsx' 
        attachment.disposition = "attachment"
        attachment.content_id = "Example Content ID"
        mail.add_attachment(attachment)
        for ids in receivers:
            mail.personalizations[0].add_to(Email(ids))	
        response = sg.client.mail.send.post(request_body=mail.get())
        if 'FliptRegisteredUsers'+str(datetime.strftime(datetime.now(),'%m%d%Y'))+'.xlsx' in os.listdir(path+'//GWLABS001//employee//'):
            os.unlink(path+'//GWLABS001//employee//FliptRegisteredUsers'+str(datetime.strftime(datetime.now(),'%m%d%Y'))+'.xlsx')        
		

obj=User_Class()
obj.sendemail()
print('Flipt Registered Users with ID End: ',datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())
req.close()


