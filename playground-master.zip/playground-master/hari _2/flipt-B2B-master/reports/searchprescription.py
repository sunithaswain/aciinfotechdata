if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
   sys.path.append(rootdir)

# it will changed based on OS
rootdir = rootdir.replace('\\', '/')
path = rootdir + os.environ['CB_DATA']
 
import pandas as pd
from datetime import datetime
import json
from couchbase.n1ql import N1QLQuery
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
import os
import time
from utils import commandline
import sys
from couchbase import FMT_JSON
import couchbase.subdocument as SD
import json
import urllib.request as urllib2
import urllib.error
import sendgrid
from sendgrid.helpers.mail import Email, Content,Attachment, Substitution, Mail 
import base64
from updatepharmacydistance import updatedistance
from utils.FliptConcurrent import concurrent



domain_name,file_type,filename,mode=commandline.main(sys.argv[1:])
req=concurrent(sys.argv[0],sys.argv[1:])
updatedistance()
cluster=Cluster(os.environ['CB_URL']+'?operation_timeout=2700')
auth=PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(auth)
bucket_name=os.environ['CB_INSTANCE']
cb=cluster.open_bucket(bucket_name)
sp=pd.DataFrame()
print('Update Start')
query=N1QLQuery('Select * from `'+bucket_name+'` where type="search_prescription" and flipt_person_id in (select raw x.dep_flipt_person_id from `'+os.environ['CB_INSTANCE']+'` x where x.type = "flipt_person_hierarchy")')
query.adhoc=False
query.timeout=3600
for r in cb.n1ql_query(query):
	sp=sp.append(r[bucket_name],ignore_index=True)
print('search_prescription stored')
query=N1QLQuery('Select * from `'+bucket_name+'` where type="analytics" and flipt_person_id in (select raw x.dep_flipt_person_id from `'+os.environ['CB_INSTANCE']+'` x where x.type = "flipt_person_hierarchy") union Select * from `'+bucket_name+'` where type="analytics" and flipt_person_id is missing')
query.adhoc=False
query.timeout=7200
ite=0
df=pd.DataFrame()
for r in cb.n1ql_query(query):
	if ite%1000==0:
		sp=sp.append(df,ignore_index=True)
		df=pd.DataFrame()
		print(ite)
	ite=ite+1
	df=df.append(r[bucket_name],ignore_index=True)
sp=sp.append(df,ignore_index=True)
req.no_rec_received=len(sp)
writer=pd.ExcelWriter(path+'/'+domain_name+'/'+file_type+'/searchprescription.xlsx')
sp.to_excel(writer,index=False)
writer.save()       
print('analytics stored')

sender='noreply@fliptrx.com'
receiver1='FliptIntegration@fliptrx.com'
#receivers=['ASriperambuduru@GWLabs.com','spal@fliptrx.com']
receivers=['CNg@GWLabs.com','kyang@fliptrx.com','TGambill@fliptrx.com','spal@fliptrx.com','deepthi.gollapudi@nttdata.com','dwagle@fliptrx.com']
sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))
from_email = Email(sender)
to_email = Email(receiver1)
subject = 'Searched Prescriptions'
filepath= path+'/'+domain_name+'/'+file_type+'/searchprescription.xlsx'
content = Content("text/plain", 'Attached is a list of all the searched prescriptions as of '+str(datetime.strftime(datetime.now(),'%m-%d-%Y'))+'.')
mail = Mail(from_email, subject, to_email, content)
with open(filepath,'rb') as f:
	data=f.read()
	f.close()
encoded=base64.b64encode(data).decode()
attachment=Attachment()
attachment.content = encoded
attachment.type = "application/pdf"
attachment.filename = 'SearchPrescription'+str(datetime.strftime(datetime.now(),'%m%d%Y'))+'.xlsx'
attachment.disposition = "attachment"
attachment.content_id = "Example Content ID"
mail.add_attachment(attachment)
for ids in receivers:
	mail.personalizations[0].add_to(Email(ids))
response = sg.client.mail.send.post(request_body=mail.get())
if path+'/'+domain_name+'/'+file_type+'/searchprescription.xlsx' in os.listdir(path+'/'+domain_name+'/'+file_type):
	os.unlink(path+'/'+domain_name+'/'+file_type+'/searchprescription.xlsx')
req.close()