if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
   sys.path.append(rootdir)

# it will changed based on OS
rootdir = rootdir.replace('\\', '/')
path = rootdir + os.environ['CB_DATA']
 
import xlsxwriter
import requests
import os
import opccmdline
import sys
import dateutil.parser as parser
import socket
import json
import base64
from updatepbmprice import pbmpriceupdate
from requests.auth import HTTPBasicAuth
from types import SimpleNamespace as Namespace
from decimal import Decimal
from datetime import datetime ,date ,time
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from utils.sendgridemail import email_log
from utils.truevault import User_Class
from utils.FliptConcurrent import concurrent

#command to run the script
#python dailyrxreportgrql.py -d GWLABS001 -t dailyrx -f dailyrxreport.xlsx -m CANCELLED -s 26-FEB-2018 -e $DD
#python dailyrxreportgrql.py -d GWLABS001 -t dailyrx -f dailyrxreport.xlsx -m NEW -s 26-FEB-2018 -e $DD

cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
# path = os.environ['CB_DATA']
url = os.environ['GRAPHQL_URL']
domain,file_type,file_name,mode,start_text,end_text = opccmdline.main(sys.argv[1:])
#print(sys.argv[1:])
req=concurrent(sys.argv[0],sys.argv[1:],2)
currentdate = datetime.now().isoformat()
filepath = path+'/'+domain+'/'+file_type+'/'+file_name+str(currentdate)+'.xlsx'
image_path = path+'/'+domain+'/'+file_type+'/gnw.PNG'
flipt_path = path+'/'+domain+'/'+file_type+'/flipt.PNG'
host = socket.gethostname()
ename = ''
fname = ''
lname = ''
subject = ''
empid = ''

# Create a workbook and add a worksheet.
workbook = xlsxwriter.Workbook(filepath)
worksheet = workbook.add_worksheet()
start_date = parser.parse(start_text)
start_date = start_date.isoformat()
end_text = end_text+' 23:59:59'
end_date = parser.parse(end_text)
end_date = end_date.isoformat()
filled_date = end_date
brand_discount = 0
generic_discount = 0
mheaders = ""
price_type = ''
print(start_date)
print(end_date)

# Call function to update pbm price_source
pbmpriceupdate(domain)

# Code to Sign in and Get the Header by Encoding the Access token
'''
mutation = """mutation {signIn(email: "disha.wagle@gwlabs.com", password: "oracle123") {access_token}}"""
signInrequest = requests.post(url, json={'query': mutation}, headers=mheaders)
decoded = json.loads(signInrequest.text, object_hook=lambda d: Namespace(**d))
token = decoded.data.signIn.access_token
token = token+':'
b64Val = base64.b64encode(bytes(token, 'utf-8'))
header = "Basic "+str(b64Val).lstrip('b')
'''
# Different Formats for Rows and Columns
header_format = workbook.add_format({
    'bold': True,
    'text_wrap': True,
    'valign': 'top',
    'fg_color': '#FF0000',
    'border': 1})
header_format.set_font_color('#FFFFFF')
header_format.set_border_color('#FF0000')
	
parameter_format = workbook.add_format({
    'bold': True,
    'text_wrap': True,
    'valign': 'top',
    'fg_color': '#FF0000',
    'border': 1})
parameter_format.set_font_color('#FFFFFF')	
parameter_format.set_border_color('#FF0000')

row_format = workbook.add_format({
    'bold': False,
    'text_wrap': True,
    'valign': 'top',
    'fg_color': '#FFFFFF',
    'border': 1})	
row_format.set_border_color('#FF0000')

merge_format = workbook.add_format({
    'bold': True,
    'text_wrap': True,
	'align': 'center',
    'valign': 'vcenter',
    'fg_color': '#FF0000',
    'border': 1})
merge_format.set_font_size(35)
merge_format.set_font_color('#FFFFFF')

if mode in ['NEW','CANCELLED']:	
	# Start from the first cell. Rows and columns are zero indexed.
	row = 0
	col = 0
	subject = 'Daily Rx Report - '+host
	#worksheet.insert_image('A1', image_path, {'x_scale': 0.5, 'y_scale': 0.5})
	worksheet.insert_image('B1', flipt_path, {'x_scale': 0.5, 'y_scale': 0.5})
	cancel_date = ''
	emp_refund = 0
	
	# Set column Width
	worksheet.set_column('A:A',22)
	worksheet.set_column('B:B',18)
	worksheet.set_column('C:C',23)
	worksheet.set_column('D:D',25)
	worksheet.set_column('E:E',25)
	worksheet.set_column('F:F',25)
	worksheet.set_column('G:G',25)
	worksheet.set_column('H:H',14)
	worksheet.set_column('I:I',14)
	worksheet.set_column('J:J',15)
	worksheet.set_column('K:K',17)
	worksheet.set_column('L:L',17)
	worksheet.set_column('M:M',17)
	worksheet.set_column('N:N',17)
	worksheet.set_column('O:O',17)
	worksheet.set_column('P:P',17)
	worksheet.set_column('Q:Q',17)
	worksheet.set_column('R:R',17)
	worksheet.set_column('S:S',17)
	worksheet.set_column('T:T',17)
	worksheet.set_column('U:U',17)
	worksheet.set_column('V:V',17)
	worksheet.set_column('W:W',17)
	worksheet.set_column('X:X',17)
	worksheet.set_column('Y:Y',17)
	worksheet.set_column('Z:Z',17)
	worksheet.set_column('AA:AA',17)
	worksheet.set_column('AB:AB',17)
	worksheet.set_column('AC:AC',17)
	worksheet.set_column('AD:AD',17)
	worksheet.set_column('AE:AE',17)
	worksheet.set_column('AF:AF',17)
	worksheet.set_column('AG:AG',17)
	worksheet.set_column('AH:AH',17)
	worksheet.set_column('AI:AI',17)
	worksheet.set_column('AK:AK',17)
	worksheet.set_column('AL:AL',17)
	# Report Header
	worksheet.merge_range('C1:F5', 'Daily Prescription Report', merge_format)

	# Report parameters
	worksheet.write(7, 0, "Statement Date Range",parameter_format)
	worksheet.write(8, 0, "Domain",parameter_format)
	worksheet.write(7, 1, start_date,row_format)
	worksheet.write(7, 2, end_date,row_format)
	worksheet.write(8, 1, domain,row_format)
	worksheet.write(7, 4, "Report Generated at ",parameter_format)
	worksheet.write(7, 5, currentdate, row_format)

	# write it out row by row.
	worksheet.write(10, 0, "Application",header_format)
	worksheet.write(10, 1, "RX Number",header_format)
	#worksheet.write(10, 1, "Employee Number",header_format)
	#worksheet.write(10, 2, "Employee Name",header_format)
	worksheet.write(10, 2, "Employee Flipt Person ID",header_format)
	worksheet.write(10, 3, "Flipt Person ID",header_format)
	worksheet.write(10, 4, "Patient Flipt Person ID",header_format)
	worksheet.write(10, 5, "Pharmacy",header_format)
	worksheet.write(10, 6, "Pharmacy NPI",header_format)
	worksheet.write(10, 7, "Location",header_format)
	worksheet.write(10, 8, "Routed Date",header_format)
	worksheet.write(10, 9, "Cancelled Date",header_format)	
	worksheet.write(10, 10, "Total Price Displayed",header_format)
	worksheet.write(10, 11, "Total Price Before Rebate",header_format)
	worksheet.write(10, 12, "Rebate Factor",header_format)
	worksheet.write(10, 13, "Employer cost",header_format)
	worksheet.write(10, 14, "Employee opc",header_format)
	worksheet.write(10, 15, "Employee Refund",header_format)
	worksheet.write(10, 16, "Rewards",header_format)
	worksheet.write(10, 17, "Rx Status",header_format)
	worksheet.write(10, 18, "Drug Name",header_format)
	worksheet.write(10, 19, "Days of Supply Selected",header_format)
	worksheet.write(10, 20, "Quantity Displayed on App",header_format)
	worksheet.write(10, 21, "Quantity Selected",header_format)
	worksheet.write(10, 22, "Filled Date",header_format)
	worksheet.write(10, 23, "Actual Patient Paid",header_format)
	worksheet.write(10, 24, "Paid Via Payroll",header_format)
	worksheet.write(10, 25, "Actual Pharmacy Name",header_format)
	worksheet.write(10, 26, "Actual Quantity Filled",header_format)
	worksheet.write(10, 27, "Pharmacy Discount",header_format)
	worksheet.write(10, 28, "Dispensing Fee",header_format)
	worksheet.write(10, 29, "Actual Drug Cost Reimbursement",header_format)
	worksheet.write(10, 30, "Client Due Amount",header_format)
	worksheet.write(10, 31, "Actual Days of Supply",header_format)
	worksheet.write(10, 32, "GPI Code",header_format)
	worksheet.write(10, 33, "NDC",header_format)
	#worksheet.write(10, 23, "Patient First Name",header_format)
	#worksheet.write(10, 24, "Patient Last Name",header_format)
	worksheet.write(10, 34, "BaseLine Cost",header_format)
	worksheet.write(10, 35, "Actual AWP Price",header_format)
	worksheet.write(10, 36, "Estimated PBM Price",header_format)
	worksheet.write(10, 37, "NDC Price",header_format)
	worksheet.write(10, 38, "Flipt Unit Price",header_format)
	worksheet.write(10, 39, "Flipt Unit Price Before Rebate",header_format)
	worksheet.write(10, 40, "Script Claim Unit Price",header_format)
	worksheet.write(10, 41, "Brand or Generic",header_format)
	worksheet.write(10, 42, "Price Type",header_format)
	worksheet.write(10, 43, "Deductible",header_format)
	worksheet.write(10, 44, "Payment Option",header_format)
	worksheet.write(10, 45, "eRx Created By (Admin)",header_format)
	worksheet.write(10, 46, "Prescriber NPI",header_format)
	worksheet.write(10, 47, "Cancellation Reason",header_format)
	
	cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET search_prescription_id = "" WHERE type = "prescription" and search_prescription_id is missing')).execute()
	
	admin_flipt_person_id = ''
	paymenttab = N1QLQuery('select pharmacy_discount,unit_price,unit_price_before_rebate,rebate_factor,drug_cost_before_rebate,prescription_id, application,npi,date_diff_str(str_to_utc(cancelled_date),str_to_utc(routed_date),"day") routed_2_cancelled_days,orig_daysofsupply,custom_quantity, pbm_price, pbm_estimated_cost, flipt_person_id, rx_flipt_person_id, pharmacy, dosage_strength,location,routed_date,drug_cost,tostring(ceil(tonumber(employee_opc))) as employee_opc,tostring(tonumber(drug_cost)-ceil(tonumber(employee_opc))) as employer_cost,rx_status,cancelled_date, round(tonumber(rewards),2) as rewards, tonumber(baseline_cost) as baseline_cost, filled_date, drug_name, daysofsupply,gpi, package_qty, package_size, brand_generic,dosage, search_prescription_id,payment_option,tonumber(package_size)*tonumber(quantity) as qty,admin_flipt_person_id,created_by from `'+os.environ['CB_INSTANCE']+'` t Where type = "prescription" and upper(rx_status) != $rxstatus and domain = $dn and npi is not missing and (create_date >= $screate_date and create_date <= $ecreate_date) and t.flipt_person_id in (select raw dep_flipt_person_id from `'+os.environ['CB_INSTANCE']+'` where type = "flipt_person_hierarchy")', screate_date = start_date, ecreate_date = end_date,dn = domain ,rxstatus = mode.upper())
	paymenttab.adhoc = False
	paymenttab.timeout = 100
	row = 11
	for paymentrow in cb.n1ql_query(paymenttab):
		flipt_person_id = paymentrow['flipt_person_id']
		flipt_person_id = flipt_person_id.strip()
		patient_flipt_person_id = paymentrow['rx_flipt_person_id']
		prescription_id = paymentrow['prescription_id']
		pharmacy = paymentrow['pharmacy']
		location,application,pnpi='','',''
		if 'location' in paymentrow:	location = paymentrow['location']
		if 'application' in paymentrow:	application = paymentrow['application']
		if 'npi' in paymentrow:	pnpi = paymentrow['npi'].lstrip('0')
		routed_date = paymentrow['routed_date']
		drug_cost = float(paymentrow['drug_cost'])
		employee_opc = paymentrow['employee_opc']
		rx_status = paymentrow['rx_status']
		rewards = paymentrow['rewards']
		drug_name = paymentrow['drug_name']
		baseline_cost = "{0:.2f}".format(float(paymentrow['baseline_cost']))
		gpi = paymentrow['gpi'].strip()
		packageqty = paymentrow['qty']
		package_quantity = str(paymentrow['package_qty']).strip()
		package_size = str(paymentrow['package_size']).strip()
		brand_generic = paymentrow['brand_generic'].strip()
		dosage_strength = paymentrow['dosage_strength'].strip()
		dosage = paymentrow['dosage'].strip()
		payment_option = paymentrow['payment_option']
		created_by = paymentrow['created_by']
		pharmacy_discount=''
		if 'pharmacy_discount' in paymentrow: pharmacy_discount=paymentrow['pharmacy_discount']
		if 'orig_daysofsupply' in paymentrow: daysofsupply = paymentrow['orig_daysofsupply']
		else: daysofsupply = paymentrow['daysofsupply']
		cancellationreason=""
		if 'routed_2_cancelled_days' in paymentrow and rx_status=='Cancelled':
			if paymentrow['routed_2_cancelled_days']<7: cancellationreason="User Cancelled"
			else: cancellationreason="eRx Expired"
		if 'deductible_remaining' in paymentrow: Deductible = paymentrow['deductible_remaining']
		else: Deductible = 'Not Available'
		custom_quantity='false'
		if 'custom_quantity' in paymentrow:
			custom_quantity=paymentrow['custom_quantity']
			
		#admin_first_name = ''
		# Get Admin Name from True Vault for a Admin Flipt Person id			
		if 'admin_flipt_person_id' in paymentrow:
			admin_flipt_person_id = paymentrow['admin_flipt_person_id']
		drug_cost_before_rebate,unit_price,unit_price_before_rebate,rebate_factor='','','',''
		if 'drug_cost_before_rebate' in paymentrow: drug_cost_before_rebate=paymentrow['drug_cost_before_rebate']
		if 'unit_price' in paymentrow: unit_price=paymentrow['unit_price']
		if 'unit_price_before_rebate' in paymentrow: unit_price_before_rebate=paymentrow['unit_price_before_rebate']
		if 'rebate_factor' in paymentrow: rebate_factor=paymentrow['rebate_factor']
		
		'''
			obj=User_Class(None,None)
			search_option={'full_document':True,'filter':{'domain_name':{'type':'eq','value':domain,'case_sensitive':False},'flipt_person_id':{'type':'eq','value':admin_flipt_person_id,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
			att,userid = obj.search_user(search_option)
			if att!=None:
				admin_first_name = att['first_name']
		'''
		empflipt_person_id = ''
		empfliptidtab = N1QLQuery('select emp_flipt_person_id from `'+os.environ['CB_INSTANCE']+'` where type = "flipt_person_hierarchy" and dep_flipt_person_id=$eid', eid=flipt_person_id)
		empfliptidtab.adhoc = False
		empfliptidtab.timeout = 100
		for fidrow in cb.n1ql_query(empfliptidtab):
			empflipt_person_id = fidrow['emp_flipt_person_id']
		pbmprice=''
		if 'pbm_estimated_cost' in paymentrow:
			pbmprice = "{0:.2f}".format(float(paymentrow['pbm_estimated_cost']))
			
		if brand_generic == 'G':
			b_g = 'Generic'
		else:
			b_g = 'Brand'
			
		#createdBy
		erx_created_by = ''
		if created_by == empflipt_person_id:
			erx_created_by = "Employee"
		elif (created_by == patient_flipt_person_id or created_by == flipt_person_id):
			erx_created_by = "Dependent"
		elif created_by  == "1001598":
			erx_created_by = "Auto eRx"
		else:
			erx_created_by = created_by
		
		# Manipulate data , if status is Cancelled
		if rx_status == 'Cancelled':
			# Cancelled Date is not in Range - Hide Cancel Date and Employee Refund
			if paymentrow['cancelled_date'] >= start_date and paymentrow['cancelled_date'] <= end_date:
				cancel_date = paymentrow['cancelled_date']
				emp_refund = paymentrow['employee_opc']
			else:
				cancel_date = ''
				emp_refund = 0
			
			# Routed Date is not in Range - Hide employee_opc
			if routed_date >= start_date and routed_date <= end_date:
				employee_opc = paymentrow['employee_opc']
			else:
				employee_opc = '0.0'
			
		else:
			cancel_date = ''
			emp_refund = 0
			#employee_opc = paymentrow['employee_opc']
		
		
		dedtab = N1QLQuery('SELECT deductible_balance1 FROM `'+os.environ['CB_INSTANCE']+'` WHERE type = "search_prescription" AND id = $id', id = paymentrow['search_prescription_id'])
		dedtab.adhoc = False
		dedtab.timeout = 100
		for dedrow in cb.n1ql_query(dedtab):
			Deductible = dedrow['deductible_balance1']			
		
		
		pricetab = N1QLQuery('SELECT DISTINCT c.pricetype as pricetype FROM `'+os.environ['CB_INSTANCE']+'` t UNNEST cp_price c WHERE t.type = "cp_drug_price" AND t.gpi = $gpi_code AND t.drug_name = $drugname AND t.brandorgeneric = $brand_gen limit 1', gpi_code = gpi, drugname = drug_name, brand_gen = b_g)
		pricetab.adhoc = False
		pricetab.timeout = 100
		for pricerow in cb.n1ql_query(pricetab):
			price_type = pricerow['pricetype']

		g_gpi= '"'+gpi+'"'
		g_drug_name= '"'+drug_name+'"'
		g_brand_generic = '"'+brand_generic+'"'
		form = '"nan"'
		g_dosage_strength = '"'+dosage_strength+'"'
		days_of_supply = '"'+daysofsupply+'"'
		g_package_qty = '"'+package_quantity+'"'
		g_dosage = '"'+dosage+'"'
		price_source = '"scriptclaim"'
		g_custom_quantity = custom_quantity
		g_package_quantity = '"'+package_quantity+'"'
		g_package_size = '"'+package_size+'"'
				
		actual_patient_paid = ''
		actual_pharmacy_name = ''
		actual_quantity_filled = ''
		dispensing_fee = ''
		actual_drug_cost = ''
		manufacturer = ''
		patient_first_name = ''
		patient_last_name = ''
		actual_awp_price = ''
		prescriber_npi = ''
		paidviapayroll = ''
		actual_days_of_supply = ''
		clientdueamt = ''
		prodndc = ''
		actual_pnpi = ''
		ndcprice = ''
		sc_unit_price = ''
		if rx_status == 'Filled':
			filled_date = paymentrow['filled_date']
			dailytab = N1QLQuery('select client_mac_price,pharmacy_npi,product_id_ndc,rtrim(patient_paid) as actual_patient_paid, rtrim(pharmacy_name) as actual_pharmacy_name, rtrim(quantity_dispensed) as actual_quantity_filled, rtrim(client_disp_fee) as dispensing_fee, tonumber(rtrim(client_ing_cost)) as actual_drug_cost, tonumber(rtrim(client_due_amt)) as client_due_amt,rtrim(manuf_abr) as manufacturer, rtrim(patient_first_name) as patient_first_name, rtrim(patient_last_name) as patient_last_name, rtrim(awp_unit) as actual_awp, rtrim(prescriber_npi) as prescriber_npi, days_supply from `'+os.environ['CB_INSTANCE']+'` WHERE `type` = "scdailyclaim" and rtrim(transaction_id) = $pid and tonumber(replace(replace(rtrim(meta().id),"scdailyclaim::",""),"prescription::","")) in (select raw max(tonumber(replace(replace(rtrim(meta(b).id),"scdailyclaim::",""),"prescription::",""))) from `'+os.environ['CB_INSTANCE']+'` b where b.type="scdailyclaim" and rtrim(b.transaction_id) = $pid and b.claim_type="P")', pid = prescription_id)
			dailytab.adhoc = False
			dailytab.timeout = 100		
			for dailyrow in cb.n1ql_query(dailytab):
				actual_pnpi = dailyrow['pharmacy_npi']
				actual_patient_paid = dailyrow['actual_patient_paid']
				actual_pharmacy_name = dailyrow['actual_pharmacy_name']
				actual_quantity_filled = dailyrow['actual_quantity_filled']
				dispensing_fee = dailyrow['dispensing_fee']
				actual_drug_cost = dailyrow['actual_drug_cost']
				manufacturer = dailyrow['manufacturer']
				patient_first_name = ''
				patient_last_name = ''
				actual_awp_price = dailyrow['actual_awp']
				prescriber_npi = dailyrow['prescriber_npi']
				actual_days_of_supply = dailyrow['days_supply']
				clientdueamt = dailyrow['client_due_amt']
				if price_type=='AWP': sc_unit_price=dailyrow['actual_awp']
				else: sc_unit_price=dailyrow['client_mac_price']
				if payment_option.upper().strip()=='PAY VIA PAYROLL DEDUCTION':
					paidviapayroll=paymentrow['employee_opc']
				prodndc = dailyrow['product_id_ndc']
			ndcquery=N1QLQuery('select tonumber(unit_price) unit_price from `'+os.environ['CB_INSTANCE']+'` where type="ndc_drugs" and ndc=$ndc',ndc=prodndc)
			ndcquery.timeout = 100
			for ndcrow in cb.n1ql_query(ndcquery):
				ndcprice = ndcrow['unit_price'] * packageqty
			if actual_pnpi!='' and actual_pnpi!=pnpi:
				pnpi=actual_pnpi
				location = ''
				getnpi=N1QLQuery('Select pharmacyaddress1||","||pharmacyaddress2||","||pharmacycity||","||pharmacystate||",US,"||pharmacyzip1 location from `'+os.environ['CB_INSTANCE']+'` where type="cp_pharmacy" and pharmacynpi=$pnpi',pnpi=actual_pnpi)
				getnpi.timeout = 100
				for npirow in cb.n1ql_query(getnpi):
					location = npirow['location'].replace(',,',',')
		else:
			filled_date = ''
			actual_patient_paid = ''
			actual_pharmacy_name = ''
			actual_quantity_filled = ''
			dispensing_fee = ''
			actual_drug_cost = ''
			manufacturer = ''
			patient_first_name = ''
			patient_last_name = ''				
			actual_awp_price = ''
			prescriber_npi = ''
			actual_days_of_supply = ''
		
		if employee_opc is None or len(employee_opc) == 0:
			employee_opc = '0.0'
		employer_cost = paymentrow['employer_cost']
		if employer_cost is None or len(employer_cost) == 0:
			employer_cost = '0.0'
		
		payroll_deduction = float(employee_opc) - float(emp_refund)
		
		worksheet.write(row, 0, application,row_format)
		worksheet.write(row, 1, prescription_id,row_format)
		#worksheet.write(row, 1, empid,row_format)
		#worksheet.write(row, 2, ename,row_format)
		worksheet.write(row, 2, empflipt_person_id,row_format)
		worksheet.write(row, 3, flipt_person_id,row_format)
		worksheet.write(row, 4, patient_flipt_person_id,row_format)
		worksheet.write(row, 5, pharmacy,row_format)
		worksheet.write(row, 6, pnpi,row_format)
		worksheet.write(row, 7, location,row_format)
		worksheet.write(row, 8, routed_date,row_format)
		worksheet.write(row, 9, str(cancel_date),row_format)		
		worksheet.write(row, 10, drug_cost,row_format)
		worksheet.write(row, 11, drug_cost_before_rebate,row_format)
		worksheet.write(row, 12, rebate_factor,row_format)
		worksheet.write(row, 13, float(employer_cost),row_format)
		worksheet.write(row, 14, float(employee_opc),row_format)
		worksheet.write(row, 15, float(emp_refund),row_format)
		worksheet.write(row, 16, rewards,row_format)
		worksheet.write(row, 17, rx_status,row_format)
		worksheet.write(row, 18, drug_name,row_format)
		worksheet.write(row, 19, daysofsupply,row_format)
		worksheet.write(row, 20, package_quantity,row_format)
		worksheet.write(row, 21, packageqty,row_format)
		worksheet.write(row, 22, filled_date,row_format)
		worksheet.write(row, 23, actual_patient_paid,row_format)
		worksheet.write(row, 24, paidviapayroll,row_format)
		worksheet.write(row, 25, actual_pharmacy_name,row_format)
		worksheet.write(row, 26, actual_quantity_filled,row_format)
		worksheet.write(row, 27, pharmacy_discount,row_format)
		worksheet.write(row, 28, dispensing_fee,row_format)
		worksheet.write(row, 29, actual_drug_cost,row_format)
		worksheet.write(row, 30, clientdueamt,row_format)
		worksheet.write(row, 31, actual_days_of_supply,row_format)
		worksheet.write(row, 32, gpi,row_format)
		worksheet.write(row, 33, prodndc,row_format)
		#worksheet.write(row, 23, patient_first_name,row_format)
		#worksheet.write(row, 24, patient_last_name,row_format)
		worksheet.write(row, 34, baseline_cost,row_format)
		worksheet.write(row, 35, actual_awp_price,row_format)
		worksheet.write(row, 36, pbmprice,row_format)
		worksheet.write(row, 37, ndcprice,row_format)
		worksheet.write(row, 38, unit_price,row_format)
		worksheet.write(row, 39, unit_price_before_rebate,row_format)
		worksheet.write(row, 40, sc_unit_price,row_format)
		worksheet.write(row, 41, b_g,row_format)
		worksheet.write(row, 42, price_type,row_format)
		worksheet.write(row, 43, Deductible,row_format)
		worksheet.write(row, 44, payment_option,row_format)
		#worksheet.write(row, 37, admin_flipt_person_id,row_format)
		worksheet.write(row, 45, erx_created_by,row_format)		
		worksheet.write(row, 46, prescriber_npi,row_format)
		worksheet.write(row, 47, cancellationreason,row_format)
		
		row = row + 1
	req.no_rec_received=row
	worksheet.write(row, 9, "Total : ",header_format)
	worksheet.write(row, 10, '=SUM(K7:K'+str(row)+')',row_format)
	worksheet.write(row, 11, '=SUM(L7:L'+str(row)+')',row_format)
	worksheet.write(row, 12, '=SUM(M7:M'+str(row)+')',row_format)
	worksheet.write(row, 13, '=SUM(N7:N'+str(row)+')',row_format)
	worksheet.write(row, 14, '=SUM(O7:O'+str(row)+')',row_format)

print('dailyrx report completed')	
workbook.close()
req.close()

if os.environ['INSTANCE_TYPE'] == 'DEV':		
	email_log('DWagle@GWLabs.com','dwagle@fliptrx.com,deepthi.gollapudi@nttdata.com',None,subject,['Processing of Daily Rx Report '+str(file_name),'Daily Rx Exception'],filepath,True)
elif os.environ['INSTANCE_TYPE'] == 'PROD' and mode.upper() == 'NEW':
	email_log('DWagle@GWLabs.com','LPeysekhman@GWLabs.com', 'kyang@fliptrx.com,FliptIntegration@fliptrx.com,TGambill@fliptrx.com,deepthi.gollapudi@nttdata.com,dwagle@fliptrx.com',subject,['Processing of Daily Rx Report '+str(file_name),'Daily Rx Exception'],filepath,True)
elif os.environ['INSTANCE_TYPE'] == 'PROD' and mode.upper() == 'CANCELLED':
	send_to = 'ASerrano@fliptrx.com,FliptIntegration@fliptrx.com,deepthi.gollapudi@nttdata.com,dwagle@fliptrx.com,Rjuhring@fliptrx.com'
	email_log('DWagle@GWLabs.com','jgraham@fliptrx.com',send_to,subject,['Processing of Daily Rx Report '+str(file_name),'Daily Rx Exception'],filepath,True)	
else:
	email_log('DWagle@GWLabs.com','FliptIntegration@fliptrx.com',None,subject,['Processing of Daily Rx Report '+str(file_name),'Daily Rx Exception'],filepath,True)

#os.remove(filepath)
