# -*- coding: utf-8 -*-
import pandas as pd
from datetime import datetime
import json
from couchbase.n1ql import N1QLQuery
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
import os
import time
from utils import commandline
import sys
from couchbase import FMT_JSON
import couchbase.subdocument as SD

def pbmpriceupdate(domain):


	cluster=Cluster(os.environ['CB_URL']+'?operation_timeout=2700')
	auth=PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
	cluster.authenticate(auth)
	bucket_name=os.environ['CB_INSTANCE']
	cb=cluster.open_bucket(bucket_name)
	
	discounts={}
	domainquery=N1QLQuery('SELECT brand_discount,generic_discount FROM `'+bucket_name+'` WHERE type="domain" and domain=$dn',dn=domain)
	domainquery.timeout=7200
	for result in cb.n1ql_query(domainquery):
		discounts=dict(result)

	prescquery=N1QLQuery('SELECT meta().id as id,gpi,drug_name,package_size,package_quantity,create_date,dosage_strength FROM `'+bucket_name+'` WHERE type="prescription" and pbm_estimated_cost is missing and domain=$dn and create_date>"2018-02-26T00:00:00.00000" and drug_name is not missing and flipt_person_id in (select raw t.dep_flipt_person_id from `'+bucket_name+'` t where t.type = "flipt_person_hierarchy")',dn=domain)
	prescquery.timeout=7200
	for rec in cb.n1ql_query(prescquery):
		print(rec)
		observedawpquery=N1QLQuery('SELECT distinct p.observed_unit_price_extended FROM `'+bucket_name+'` b unnest b.provider as p WHERE b.type="pbm_observed_price" and b.gpi=$gpi and b.drug_name=$dn and p.domain=$domn and p.active_flag="Y"',gpi=rec['gpi'],dn=rec['drug_name'],domn=domain)
		observedawpquery.timeout=7200
		observedprice=''
		for r in cb.n1ql_query(observedawpquery):
			observedprice=r['observed_unit_price_extended']
		if rec['create_date']<'2018-04-25T00:00:00.00000':
			observedprice=''
		if observedprice!='':
			pbmprice=str("{0:.4f}".format(float(rec['package_quantity'])*float(observedprice)*float(rec['package_size'])))
			#print(rec,pbmprice)
			cb.mutate_in(rec['id'],SD.upsert('pbm_estimated_cost',str(pbmprice)))
			continue
		query=N1QLQuery('SELECT distinct cp.pricetype FROM `'+bucket_name+'` b unnest b.cp_price as cp WHERE b.type="cp_drug_price" and b.gpi=$gpi and b.drug_name=$dn',gpi=rec['gpi'],dn=rec['drug_name'])
		query.timeout=7200
		pricetype=''
		for r in cb.n1ql_query(query):
			pricetype=r['pricetype']
		query=N1QLQuery('SELECT distinct q.unit_price_extended FROM `'+bucket_name+'` b unnest b.quantities as q WHERE b.type="awp_price" and b.gpi=$gpi and b.drug_name=$drug_name and q.dosage_strength=$ds',gpi=rec['gpi'],drug_name=rec['drug_name'],ds=rec['dosage_strength'])
		query.timeout=7200
		pbmprice=0
		for s in cb.n1ql_query(query):
			awpprice=s['unit_price_extended']
			pbmprice_nodiscount=(float(rec['package_quantity'])*float(awpprice)*float(rec['package_size']))
			if pricetype=='MAC':			
				pbmprice="{0:.4f}".format(pbmprice_nodiscount*(1-float(discounts['generic_discount'])))
			else:	
				pbmprice="{0:.4f}".format(pbmprice_nodiscount*(1-float(discounts['brand_discount'])))
		cb.mutate_in(rec['id'],SD.upsert('pbm_estimated_cost',str(pbmprice)))
			#print(rec,pbmprice)
		

#pbmpriceupdate("GWLABS001")
