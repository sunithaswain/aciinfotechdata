# using SendGrid's Python Library
# https://github.com/sendgrid/sendgrid-python
import sendgrid
import os
from sendgrid.helpers.mail import Email, Content,Attachment, Substitution, Mail 
import urllib.request as urllib
import base64
from datetime import datetime
import socket
#hostname = socket.gethostname()
hostname = os.environ['INSTANCE_TYPE']
def email_log(sender,receiver1,receivers,subject_,body,file_path,attached=True):
	sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))

	sender = 'noreply@fliptrx.com'
	from_email = Email(sender)
	to_email = Email(receiver1)
	subject = hostname+':'+subject_

	if len(body)==1:
		content_='Dear Admin Team,\n '+body[0]+' has started at '+ str(datetime.now())+'. We will send you a log file as soon as processing is completed. Please review the log file as soon as you receive them for exceptions and take appropriate actions.\n \n Best regards,\n FLIPT Integration Team'
	else:
		content_='Dear Admin Team,\n '+body[0]+' is completed at '+ str(datetime.now())+'. Please review the attached log file for exceptions and take appropriate actions. Also run Couchbase '+body[1]+' SQL to find more information.\n \n Best regards,\n FLIPT Integration Team'


	content = Content("text/plain", content_)
	mail = Mail(from_email, subject, to_email, content)
	data=None
	if attached==True:
		with open(file_path,'rb') as f:
			data=f.read()
			f.close()
			encoded=base64.b64encode(data).decode()
			attachment=Attachment()
			attachment.content = encoded
			attachment.type = "application/pdf"
			attachment.filename = file_path.split('/')[-1]
			attachment.disposition = "attachment"
			attachment.content_id = "Example Content ID"
			mail.add_attachment(attachment)
	if receivers!=None:
		receiver2=receivers.split(',')
		for i in receiver2:        
			mail.personalizations[0].add_to(Email(i))	
	response = sg.client.mail.send.post(request_body=mail.get())

def email_log_custom(sender,receiver1,receivers,subject_,body,file_path,attached=True):
	sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))

	sender = 'noreply@fliptrx.com'
	from_email = Email(sender)
	to_email = Email(receiver1)
	subject = hostname+':'+subject_

	content_='Dear Admin Team,\n '+body[0]+' \n \n Best regards,\n FLIPT Integration Team'
	
	

	content = Content("text/plain", content_)
	mail = Mail(from_email, subject, to_email, content)
	data=None
	if attached==True:
		with open(file_path,'rb') as f:
			data=f.read()
			f.close()
		encoded=base64.b64encode(data).decode()
		attachment=Attachment()
		attachment.content = encoded
		attachment.type = "application/pdf"
		attachment.filename = file_path.split('/')[-1]
		attachment.disposition = "attachment"
		attachment.content_id = "Example Content ID"
		mail.add_attachment(attachment)
	if receivers!=None:
		receiver2=receivers.split(',')
		for i in receiver2:        
			mail.personalizations[0].add_to(Email(i))	
	response = sg.client.mail.send.post(request_body=mail.get())
	
def email_log_custombody(sender,receiver1,receivers,subject_,body,file_path,attached=True):
	sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))

	sender = 'noreply@fliptrx.com'
	from_email = Email(sender)
	to_email = Email(receiver1)
	subject = hostname+':'+subject_

	content_=body
	
	

	content = Content("text/plain", content_)
	mail = Mail(from_email, subject, to_email, content)
	data=None
	if attached==True:
		with open(file_path,'rb') as f:
			data=f.read()
			f.close()
		encoded=base64.b64encode(data).decode()
		attachment=Attachment()
		attachment.content = encoded
		attachment.type = "application/pdf"
		attachment.filename = file_path.split('/')[-1]
		attachment.disposition = "attachment"
		attachment.content_id = "Example Content ID"
		mail.add_attachment(attachment)
	if receivers!=None:
		receiver2=receivers.split(',')
		for i in receiver2:        
			mail.personalizations[0].add_to(Email(i))	
	response = sg.client.mail.send.post(request_body=mail.get())


def email_log_zip(sender,receiver1,receivers,subject_,body,file_path,attached=True):
	sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))

	sender = 'noreply@fliptrx.com'
	from_email = Email(sender)
	to_email = Email(receiver1)
	subject = hostname+':'+subject_
	content_ = body

	content = Content("text/plain", content_)
	mail = Mail(from_email, subject, to_email, content)
	data=None
	if attached==True:
		with open(file_path,'rb') as f:
			data=f.read()
			f.close()
			encoded=base64.b64encode(data).decode()
			attachment=Attachment()
			attachment.content = encoded
			attachment.type = "application/zip"
			attachment.filename = file_path.split('/')[-1]
			attachment.disposition = "attachment"
			attachment.content_id = "Example Content ID"
			mail.add_attachment(attachment)
	if receivers!=None:
		receiver2=receivers.split(',')
		for i in receiver2:        
			mail.personalizations[0].add_to(Email(i))	
	response = sg.client.mail.send.post(request_body=mail.get())

