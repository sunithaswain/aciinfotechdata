#!/usr/bin/python

import sys, getopt

def main(argv):
   domain     = None 
   file_type  = None
   file_name  = None
   help=None
   processing_type=None
   start_date=None
   end_date=None
   #print(argv)
   try:
       opts, args = getopt.getopt(sys.argv[1:], "hd:t:f:m:s:e:", ["help", "domain=","file_type=","file_name=","processing_type=","start_date=","end_date="])
   except getopt.GetoptError:
      print('filetype.py -d <domain> -t <file_type> -f <file_name> -m <processing_type> -s <start_date> -e <end_date>')
      sys.exit(2)


   #print(opts)
   #print(args)
   for opt, arg in opts:
      #print(opt,arg)
      if opt == '-h':
         print (file_type+'.py','-d <domain> -t <file_type> -f <file_name> -m <processing_type> -s <start_date> -e <end_date>')
         sys.exit()
      elif opt in ("-d", "--domain"):
         domain= arg
      elif opt in ("-t", "--file_type"):
         file_type = arg
      elif opt in ("-f", "--file_name"):
         file_name = arg
      elif opt in ("-m", "--processing_type"):
         processing_type = arg
      elif opt in ("-s", "--start_date"):
         start_date = arg
      elif opt in ("-e", "--end_date"):
         end_date = arg
		 
   if processing_type==None: processing_type='draft'
   return domain,file_type,file_name,processing_type,start_date,end_date
   #print ('domain name :',domain)
   #print ('file Type   :',file_type)
   #print ('file name   :', file_name)

#if __name__ == "__main__":
   #main(sys.argv[1:])
