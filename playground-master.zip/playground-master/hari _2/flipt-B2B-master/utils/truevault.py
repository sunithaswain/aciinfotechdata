import os
import requests
import os
import passwordgen
from requests.auth import HTTPBasicAuth
import json
import base64
import pprint
import pandas as pd
from couchbase.cluster import Cluster 
from couchbase.cluster import PasswordAuthenticator
from couchbase.n1ql import N1QLQuery
import sendgrid
import os
from sendgrid.helpers.mail import *

api_key=os.environ['TV_API_KEY']



class TrueVault_API(object):
    def __init__(self, key):
        self.valut_list = []
        self.key = key
 
    def Vault(self, id):
        return Vault_Class(id, self.key)

class Vault_Class(object):
    def __init__(self, id=None, key=None, name=None):
        r = requests.get('https://api.truevault.com/v1/vaults/%s' % id, auth=HTTPBasicAuth(api_key, ''))
        print (r)
        """
        if r.status_code == 200:
            pass
        else:
            r = requests.get('https://api.truevault.com/v1/vaults/%s' % id)
        """
        response = r.json()
        self.vault = response.get('vault', None)
        self.name = None
        if self.vault:
            self.id = self.vault.get('id')
            self.name = self.vault.get('name')
 
 
    def Document(self, doc_id=None):
        print(vault_id)
        print(doc_id)
        return Document_Class(vault_id, doc_id)

class User_Class(object):

    def __init__(self,username=None,password=None,attributes=None,group_ids=None,status=None):
        self.username=username
        self.password=password
        self.attributes=attributes
        self.group_ids=group_ids
        self.status=status

    def create_user(self):
        self.password=str(passwordgen.generatePassword())
        self.attributes['active']=True
        self.attributes['tmp_password']=self.password
        attributes=base64.b64encode(str.encode(json.dumps(self.attributes)))
        data={'username':self.username, 'password':self.password,'attributes':attributes,'group_ids':self.group_ids}
        r=requests.post('https://api.truevault.com/v1/users',auth=HTTPBasicAuth(api_key, ''),data=data)
        if r.status_code==400 or r.status_code==404: return
        response=r.json()
        userid=response['user']['user_id']
        self.send_email(userid)
        
 
    def search_user(self,search_option):
                 
        
        search_opt=base64.b64encode(str.encode(json.dumps(search_option)))
        data={'search_option':search_opt}
        r=requests.post('https://api.truevault.com/v1/users/search',auth=HTTPBasicAuth(api_key, ''),data=data)
        response=r.json()
        #print(response)
        #if 'data' not in response: return None,None
        if len(response['data']['documents'])==0 and r.status_code==200: return None,None
        att=json.loads(str(base64.b64decode(response['data']['documents'][0]['attributes']),'utf-8'))
       
        userid=response['data']['documents'][0]['user_id']
        return att,userid
    
    def update_user(self):


        cluster=Cluster(os.environ['CB_URL'])
        auth=PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
        cluster.authenticate(auth)
        cb=cluster.open_bucket(os.environ['CB_INSTANCE'])
        search_option={'full_document':True,'filter':{'employee_ssn':{'type':'eq','value':self.attributes['employee_ssn'],'case_sensitive':False},'domain_name':{'type':'eq','value':self.attributes['domain_name'],'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
        att,userid=self.search_user(search_option)
        if userid==None:
            rec={}
            rv=cb.counter('counterid',delta=1)
            self.attributes['flipt_person_id']=str(rv.value)
            rec['flipt_person_id']=str(rv.value)
            rec['dependents']=[]
            for i in range(len(self.attributes['dependents'])):
                d={}
                inc=cb.counter('counterid',delta=1)
                self.attributes['dependents'][i]['flipt_person_id']=str(inc.value)
                d['flipt_person_id']=str(inc.value)
                rec['dependents'].append(d)
            rec['type']='employee_flipt_person'
            cb.upsert(self.attributes['domain_name']+str(rv.value),rec)
            self.username=self.attributes['work_email'].lower()
            
            self.create_user()
            return
        
        new_dependents=False
        for v in list(self.attributes.keys()):
            if v=='dependents':
                if len(self.attributes[v])==0: continue
                elif len(att[v])==0 and len(self.atributes[v])>0:
                    for dep in self.attributes[v]:
                        att[v].append(dep)
                        dep['flipt_person_id']=str(cb.counter('counterid',delta=1).value)
                        new_dependents=True 
                    continue
                else:
                    deps_info=pd.DataFrame()
                    for i in range(len(att[v])):
                        dep=att[v][i]
                        deps_info=deps_info.append({'index_no':i,'fname':dep['first_name'],'lname':dep['last_name'],'dob':dep['date_of_birth']},ignore_index=True)
                    
                       
                    for dep in self.attributes[v]:
                        if ((deps_info['fname']==dep['first_name'])&(deps_info['lname']==dep['last_name'])&(deps_info['dob']==dep['date_of_birth'])).any():
                            index=int(deps_info[(deps_info['fname']==dep['first_name'])&(deps_info['lname']==dep['last_name'])&(deps_info['dob']==dep['date_of_birth'])]['index_no'].values[0])
                            
                            for dep_v in dep:
                                att[v][index][dep_v]=str(dep[dep_v])
                        else:
                            att[v].append(dep)
                            dep['flipt_person_id']=str(cb.counter('counterid',delta=1).value)
                            new_dependents=True
                        continue
                continue
                        
            att[v]=self.attributes[v]
       
        new_att=base64.b64encode(str.encode(json.dumps(att)))
        
        data={'attributes':new_att}
        r=requests.put('https://api.truevault.com/v1/users/%s' % str(userid),auth=HTTPBasicAuth(api_key, ''),data=data)
        
        if new_dependents==True:
            flipt_ids={}
            flipt_ids['flipt_person_id']=att['flipt_person_id']
            flipt_ids['dependents']=[]
            for dep in att['dependents']:
                x={}
                x['flipt_person_id']=dep['flipt_person_id']
                flipt_ids['dependents'].append(x)
            flipt_ids['type']='employee_flipt_person'
            cb.upsert(str(att['domain_name'])+att['flipt_person_id'],flipt_ids)


    def send_email(self,userid):
        
        user_id=userid
        headers = {'Content-Type': 'application/json'}
        data={
         "provider": "SENDGRID",
         "auth": {"sendgrid_api_key": os.environ['SENDGRID_API_KEY']},
         "template_id": "f21152e7-3b48-4e76-8173-beb033e14f54",
         "from_email_address": {"literal_value": "care@fliptrx.com"},
         "to_email_address": {"user_attribute": "work_email"},
         "substitutions": {
            ":username":{"user_attribute":"first_name"},
            ":password": {"literal_value": self.password},
         }
    }
        r=requests.post('https://api.truevault.com/v1/users/%s/message/email'%user_id,headers=headers,auth=HTTPBasicAuth(api_key, ''),data=json.dumps(data))
    
    def create_user_schema(self):
        userschema={"name": "userschema",
                     "fields": [
                      {
                      "name": "domain_name",
                      "index": True,
                      "type": "string"
                      },
                      {
                      "name": "first_name",
                      "index": True,
                      "type": "string"
                      },
                      {
                      "name": "last_name",
                      "index": True,
                      "type": "string"
                      },
                      {
                      "name": "date_of_birth",
                      "index": True,
                      "type": "string"
                      },
                      {
                      "name": "employee_id",
                      "index": True,
                      "type": "string"
                      },
                      {
                      "name": "employee_ssn",
                      "index": True,
                      "type": "string"
                      },
                      {
                      "name": "dependents.dependent_ssn",
                      "index": True,
                      "type": "string"
                      },
                      {
                      "name": "dependents.first_name",
                      "index": True,
                      "type": "string"
                      },
                      {
                      "name": "dependents.last_name",
                      "index": True,
                      "index": True,
                      "type": "string"
                      },

                      ]
                      }

        uschema=base64.b64encode(str.encode(json.dumps(userschema)))
        data={'schema':uschema}
        acc_id=''
        r=requests.put('https://api.truevault.com/v1/accounts/%s/user_schema' % acc_id,auth=HTTPBasicAuth(api_key, ''),data=data)
                       
   
    def delete_user(self):
        f=open('Truevault-users.txt','w')
        r=requests.get('https://api.truevault.com/v1/users',auth=HTTPBasicAuth(api_key,''))
        response=r.json()
        data={'full':'true'}
        for i in response['users']:
            f.write('--Record--')
            search_option={'full_document':True,'filter':{'$tv.username':{'type':'eq','value':i['username'],'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
            uid,att=self.search_user(search_option)
            print(att)
            f.write(att+'\n\n')
        f.close()
        '''
            if 'gwlabstest' in i['username']:
                er_id=i['user_id']
                att=base64.b64encode(str.encode(json.dumps({})))
                data={'username':i['username'].split('@')[0],'attributes':att}
                print(data['username'])
        '''    
                #r1=requests.put('https://api.truevault.com/v1/users/%s' % er_id, auth=HTTPBasicAuth(api_key, ''),data=data)
                #r2=requests.delete('https://api.truevault.com/v1/users/%s' %er_id, auth=HTTPBasicAuth(api_key, ''))
                
class Document_Class(object):
    def __init__(self, vault_id, doc_id=None):
        if doc_id is None:
            r = requests.post('https://api.truevault.com/v1/vaults/%s/documents' % vault_id, auth=HTTPBasicAuth(api_key, ''))
            response = r.json()
            print (response)
            self.id = response.get('document_id')
        
        r = requests.get('https://api.truevault.com/v1/vaults/%s/documents' % vault_id, auth=HTTPBasicAuth(api_key, ''))
        response = r.json()
        print(r)
        print(response.get(doc_id))
       
    def save(self):
        if self.doc is None:
            pass



#obj=User_Class()
#obj.delete_user()
