#!/usr/bin/python
########################################
# !/usr/bin/env python  
# title         : commandline.py
# description   : To read command line arguments
# author        : Disha
# date created  : 20180101
# date last modified    : 
# version       : 0.1
# maintainer    : Hari
# email         : 
# status        : Production
# Python Version: 3.5.2
# usage         : 
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  
# #######################################

import sys, getopt

# Added to update the system path to refer our custom packages
if __name__ == '__main__':
    import os
    import sys
    rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    sys.path.append(rootdir)

def main(argv):
   domain     = None 
   file_type  = None
   file_name  = None
   help=None
   processing_type=None
   #print(argv)
   try:
       
       opts, args = getopt.getopt(sys.argv[1:], "hd:t:f:m:", ["help", "domain=","file_type=","file_name=","processing_type="])
   except getopt.GetoptError:
      print('filetype.py -d <domain> -t <file_type> -f <file_name> -m <processing_type>')
      sys.exit(2)


   #print(opts)
   #print(args)
   for opt, arg in opts:
      #print(opt,arg)
      if opt == '-h':
         print (file_type+'.py','-d <domain> -t <file_type> -f <file_name> -m <processing_type>')
         sys.exit()
      elif opt in ("-d", "--domain"):
         domain= arg
      elif opt in ("-t", "--file_type"):
         file_type = arg
      elif opt in ("-f", "--file_name"):
         file_name = arg
      elif opt in ("-m", "--processing_type"):
         processing_type = arg
   if processing_type==None: processing_type='draft'
   return domain,file_type,file_name,processing_type
   #print ('domain name :',domain)
   #print ('file Type   :',file_type)
   #print ('file name   :', file_name)

#if __name__ == "__main__":
   #main(sys.argv[1:])
