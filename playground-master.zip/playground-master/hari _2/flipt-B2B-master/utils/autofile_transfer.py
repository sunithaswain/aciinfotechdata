########################################
# !/usr/bin/env python  
# title         : autofile_transfer.py
# description   : connect with AWS Sftp to transfer file from AWS S3 to local location
# author        : Hari
# date created  : 20190131
# date last modified    : 
# version       : 0.1
# maintainer    : haris
# email         : hrajendran@fliptrx.com
# status        : Dev
# Python Version: 3.5.2
# usage         : Calling from other programs
#                 from autofile_transfer import multiplefilesftptransfer
#                 multiplefilesftptransfer(remotepath, localpath, 'FLIPT_DRUG_*', "GET")
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------

# #######################################


import os, fnmatch
import paramiko

# os.environ['SCFTPPORT'] = '22'

sftpURL   =  os.environ['AUTOSFTPHOST'].strip()
sftpUser  =  os.environ['AUTOSFTPUSER'].strip()
sftpPass  =  os.environ['AUTOSFTPPWD'].strip()

# print('sftpURL -%s, sftpUser -%s, sftpPass -%s'%(sftpURL, sftpUser, sftpPass))

ssh = paramiko.SSHClient()
# automatically add keys without requiring human intervention
ssh.set_missing_host_key_policy( paramiko.AutoAddPolicy() )

ssh.connect(sftpURL, username=sftpUser, password=sftpPass)

def multiplefilesftptransfer(source, destination, prefix_match, mode):
    sftp = ssh.open_sftp()
    status = 'U'

    if mode == 'GET':
        try:
            filelist = sftp.listdir(path=source+'/')
#             print(filelist)
            for afile in filelist:
                if fnmatch.fnmatch(afile, prefix_match):
                    sftp.get(source+'/'+afile, destination+afile)
                    # Archive folder to move processed files
                    sftp.put(destination+afile, source+'/Archive/'+afile)
                    sftp.remove(source+'/'+afile)
                    status = 'S'
        except IOError:
            status = 'E'
            print ('File not Found in Local Directory')

    sftp.close()
    return filelist,status


# sample call from other programs

# Automate Drug Database Load
# from autofile_transfer import multiplefilesftptransfer
# localpath = "D://Users//HRajendran//Documents//Python_127//Latest//test2//"
# remotepath = 'local'
# multiplefilesftptransfer(remotepath, localpath, 'FLIPT_DRUG_*', "GET")