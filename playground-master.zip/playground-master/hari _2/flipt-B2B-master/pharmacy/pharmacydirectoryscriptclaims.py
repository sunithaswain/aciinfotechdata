﻿if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
   sys.path.append(rootdir)

# it will changed based on OS
rootdir = rootdir.replace('\\', '/')
path = rootdir + os.environ['CB_DATA']
 
import sys
from bs4 import BeautifulSoup
import urllib
import re
from datetime import datetime
import zipfile
import os
import pandas as pd
import time
import requests
import geocoder
from couchbase.cluster import Cluster 
from couchbase.cluster import PasswordAuthenticator
from couchbase.n1ql import N1QLQuery
from couchbase import FMT_JSON
import urllib.request as urllib2
import urllib.error
import json
from utils.sendgridemail import email_log
from utils import commandline
from difflib import SequenceMatcher

class CPPharmacyUpdate(object):

    def __init__(self,location):
        self.cluster=Cluster(location)
        self.auth=PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
        self.cluster.authenticate(self.auth)
        self.cb=self.cluster.open_bucket(os.environ['CB_INSTANCE'])
    
    def replace_all(self,txt):
        chdict={"-":"","'s":"s",".":"",'WAL MART':'WALMART','HY VEE':'HYVEE','WINNDIXIE':'WINN DIXIE',}
        for k,v in chdict.items():
            txt=txt.replace(k,v)
        return txt
  
    def replace_wl(self,txt):
        
        if txt=='Giant Eagle': return txt
        
        chdict={"'s":'s','-':'','Giant':'Giant Pharmacy','Martins':'Martins Pharmacy','&':'and','H.E. Butt (HEB)':'Heb Grocery','WinnDixie':'Winn Dixie'}
        for k,v in chdict.items():
            txt=txt.replace(k,v)
        return txt

    def replace_appname(self,wln):
        end_chars=['PHARMACY','\(','\#','\d','\$',' J','AND DRUG%%',' DRUG%%','DRUGSTORE%%','DRUG STORE%%','DRUGS%%']
        max_ind=10000
        wln=wln+'%%'
        for c in end_chars:
            char_index=re.search(c,wln)
            if char_index:
                max_ind=min(max_ind,char_index.start())
                if max_ind not in [-1,0]: wln=wln[:max_ind].replace('WAL-MART','WALMART')
        return wln.replace('%%','')
        
    def geocodeAddress(self,pharma_dir):
 

        cols_dict={'pharmacynpi':'npi','pharmacyaddress1':'prov_practice_addr_1','pharmacyaddress2':'prov_practice_addr_2','pharmacycity':'prov_practice_city','pharmacystate':'prov_practice_state','pharmacyzip1':'prov_practice_zip'}
        pharma_dir['prov_practice_country']='US'
        pharma_dir.rename(columns=cols_dict,inplace=True)
        header_list = ['npi', 'prov_practice_addr_1', 'prov_practice_addr_2', 'prov_practice_city', 'prov_practice_zip', 'prov_practice_state', 'prov_practice_country']
        pharma_dir.fillna('',inplace=True)
        address=pd.DataFrame(columns=header_list)    
        for i, p in pharma_dir.iterrows():
            if  (p['geo_lat']=='') or (pd.isnull(p['geo_lat'])):
                line_dict = {}
                line_dict['npi'] = str(p['npi']).strip()
                line_dict['prov_practice_addr_1'] = str(p['prov_practice_addr_1']).strip()
                line_dict['prov_practice_addr_2'] = str(p['prov_practice_addr_2']).strip()
                line_dict['prov_practice_city'] = p['prov_practice_city'].strip()
                zip_code = str(p['prov_practice_zip'])[:5].zfill(5)
                if len(zip_code) > 5:
                    zip_code += '-' + zip_code[5:]
                line_dict['prov_practice_zip'] = zip_code
                line_dict['prov_practice_state'] = p['prov_practice_state'].strip()
                line_dict['prov_practice_country'] = 'United States'
                address=address.append(line_dict,ignore_index=True)
        geocodes=self.getGeoCodes(address)
        print('geocoded')
        geocodes.to_csv(path+'//'+filetype+'//log//nongeocodedpharmacies'+str(datetime.now())+'.csv',index=False)
        
        return geocodes
        
    
    def parse_google_fields(self,g, google_fields):
        res = {}
        for f in google_fields.keys():
            gf_type = google_fields[f]['field_type']
            gf_name = google_fields[f]['field_name']
            
            if gf_type == 'property':
                d = g.json
            elif gf_type == 'raw':
                d = g.raw
            
            if d is not None and gf_name in d.keys():
                res[f] = d[gf_name]
            else:
                res[f] = ''
        return res
    
    def split_address(self,addr):
        street_number = ''
        street_name = addr
        
        flds = addr.split(' ')
        for i, f in enumerate(flds):
            if f.isdigit():
                street_number = f
                street_name = ' '.join(flds[i+1:])
                break
        return [street_number, street_name]
    
    def check_addresses(self,i_addr, o_addr, fields=['street_number', 'street', 'city', 'state', 'postal_code', 'country']):
        for f in fields:
            if type(o_addr[f]) == dict and ('short_name' in o_addr[f].keys() or 'long_name' in o_addr[f].keys()):
                if not i_addr[f].upper().replace('.', '') == o_addr[f]['short_name'].upper().replace('.', '') and not i_addr[f].upper().replace('.', '') == o_addr[f]['long_name'].upper().replace('.', ''):
                    return False
            elif type(o_addr[f]) == str and not i_addr[f].upper() == o_addr[f].upper():
                return False
    
        return True
    
    def geocode_data_frame(self,df, new_fields,google_fields, key=None, max_tries=3,geocode_missing=True):
        g_res = {}
        new_cols=[x for x in new_fields]
        new_cols.append('npi')
        geo_df=pd.DataFrame(columns=new_cols)
        geo_errors=pd.DataFrame(columns=new_cols)
    
        for f in new_fields:
            g_res[f] = []
        
        with requests.Session() as session:
            for i, p in df.iterrows():
                geo_ok = False
                address    = p['prov_practice_addr_1'].strip()
                i_city    = p['prov_practice_city'].strip()
                i_state   = p['prov_practice_state'].strip()
                i_postal  = str(p['prov_practice_zip'])
                i_country = p['prov_practice_country'].strip()
    
                geocoded = {}
                for f in new_fields:
                    geocoded[f] = ''
                
                addr = address
                addr += ',' + i_city
                addr += ',' + i_state
                addr += ',' + i_postal
                #addr += ',' + i_country
    
                i_addr = {}
                i_addr['address'] = addr
                i_addr['formatted_address'] = addr
                i_addr['street_number'], i_addr['street'] = self.split_address(address)
                i_addr['city'] = i_city
                i_addr['state'] = i_state
                i_addr['postal_code'] = i_postal[:5]
                if len(i_postal) > 5:
                    i_addr['postal_code_suffix'] = i_postal[5:]
                else:
                    i_addr['postal_code_suffix'] = ''
                i_addr['country'] = i_country
                i_addr['npi']=p['npi']
    
                if geocode_missing:
                    
                    # use geocoder to get data
                    g = geocoder.google(addr, key=key, session=session)
    
                    if not g.ok:
                        ntries = 0
                        while ntries < max_tries:
                            ntries += 1
                            g = geocoder.google(addr, key=key)
                            time.sleep(2)
                            if g.ok:
                                geo_ok = True
                                break
    
                    if g.ok:
                        geocoded = self.parse_google_fields(g, google_fields)
    
                        geocoded['is_same_address'] = 'Y' if self.check_addresses(i_addr, geocoded) else 'N'
    
                        # save results to json file, in json_path if variable set
                        for f in geocoded.keys():
                            if type(geocoded[f]) == dict and 'short_name' in geocoded[f].keys():
                                i_addr['geo_' + f] = geocoded[f]['short_name']
                            else:
                                i_addr['geo_' + f] = geocoded[f]
    
                            geo_df=geo_df.append(i_addr,ignore_index=True)
                            if p['npi'] in list(geo_errors['npi']):
                                geo_errors=geo_errors[geo_errors['npi']!=p['npi']]
                        geo_ok = True
    
                if geo_ok:
                    # add fields to structure
                    for f in new_fields:
                        l = g_res[f]
                        if type(geocoded[f]) == dict and 'short_name' in geocoded[f].keys():
                            l.append(geocoded[f]['short_name'])
                        else:
                            l.append(geocoded[f])
                        g_res[f] = l
                    
                else:
                    # save results to json file, in json_path if variable set
                    for f in new_fields:
                        i_addr['geo_' + f] = ''
    
                    geo_errors=geo_errors.append(i_addr,ignore_index=True)
                        
                    # add fields to structure
                    for f in new_fields:
                        l = g_res[f]
                        l.append('')
                        g_res[f] = l
    
        for f in new_fields:
            df['geo_' + f] = g_res[f]
            
        return df

    
    def getGeoCodes(self,address):
        API_KEY='AIzaSyB_zk3jM6lIpradGijn551UIzzrjv1iwEg'

        google_fields = {'address' : {'field_type': 'property', 'field_name': 'address'},
                         'formatted_address' : {'field_type': 'raw', 'field_name': 'formatted_address'},
                         'street_number' : {'field_type': 'raw', 'field_name': 'street_number'},
                         'street' : {'field_type': 'raw', 'field_name': 'route'},
                         'city' : {'field_type': 'raw', 'field_name': 'locality'},
                         'state' : {'field_type': 'raw', 'field_name': 'administrative_area_level_1'},
                         'county' : {'field_type': 'raw', 'field_name': 'administrative_area_level_2'},
                         'postal_code' : {'field_type': 'raw', 'field_name': 'postal_code'},
                         'postal_code_suffix' : {'field_type': 'raw', 'field_name': 'postal_code_suffix'},
                         'country' : {'field_type': 'raw', 'field_name': 'country'},
                         'lat' : {'field_type': 'property', 'field_name': 'lat'},
                         'lng' : {'field_type': 'property', 'field_name': 'lng'},
                         'confidence' : {'field_type': 'property', 'field_name': 'confidence'},
                         'status' : {'field_type': 'property', 'field_name': 'status'}}
        
        new_fields = ['formatted_address', 'street_number', 'street', 'city', 'state', 'county', 'postal_code',
                      'postal_code_suffix', 'country', 'lat', 'lng', 'confidence', 'status', 'is_same_address']
        geocodes = self.geocode_data_frame(address, new_fields, google_fields,key=API_KEY,geocode_missing=True)
        return geocodes



    
    def readnewupdate(self):
        # df = pd.read_excel(path+'//'+filetype+'//'+filename)
        col_names = ['PharmacyID',
                     'PharmacyNPI',
                     'ChainCode',
                     'CorpName',
                     'PharmacyName',
                     'PharmacyStoreNumber',
                     'PharmacyAddress1',
                     'PharmacyAddress2',
                     'PharmacyCity',
                     'PharmacyState',
                     'PharmacyZip1',
                     'PharmacyPhone',
                     'PharmacyFax',
                     'PharmPrice',
                     'PharmBrandPriceAmt',
                     'PharmBrandPriceFee',
                     'PharmMACPriceAmt',
                     'PharmMACPriceFee',
                     'PharmNonMACPriceAmt',
                     'PharmNonMACPriceFee',
                     'PharmBrandPriceAmtMO',
                     'PharmBrandPriceFeeMO',
                     'PharmMACPriceAmtMO',
                     'PharmMACPriceFeeMO',
                     'PharmNonMACPriceAmtMO',
                     'PharmNonMACPriceFeeMO']
        df = pd.read_csv(path+'//'+filetype+'//'+filename, sep='|', index_col=False, names=col_names,
                         encoding='ISO-8859-1', skiprows=1)

        return df

    def formatupdate(self):
        fn=self.readnewupdate()
        
        fn.fillna("",inplace=True)
        colsdict={}
        for c in list(fn):
        	colsdict[c]=c.replace(' ','_').replace(',','').lower()
        fn.rename(columns=colsdict,inplace=True)
        fn['pharmacyname-new']=[self.replace_all(str(x).upper()) for x in fn['pharmacyname']]
        fn['corpname-new']=[self.replace_all(str(x).upper()) for x in fn['corpname']]
        fn['pharmacyzip1']=fn['pharmacyzip1'].apply(lambda x: str(int(x)).zfill(9) if len(str(int(x)))>5 else str(int(x)).zfill(5))
        fn['pharmacynpi']=fn['pharmacynpi'].apply(lambda x: str(x).zfill(10))
        fn['wl_name']=""
        return fn,1
        
    
    def finalupdate(self):
        
        filtered,num=self.formatupdate()
        
        errors=pd.DataFrame()
        maclist=pd.read_excel(path+'/cp_pharmacy/MacListChainCodeKey.xlsx')
        maclist['ChainCode']=maclist['ChainCode'].apply(lambda x:str(x))
        if num==0: return filtered,False
         
        whitelist=pd.DataFrame()
        rows=self.cb.n1ql_query(N1QLQuery('SELECT * FROM `'+os.environ['CB_INSTANCE']+'` WHERE type=$t',t='whitelisted_pharmacy'))
        for r in rows:
            xele=r[os.environ['CB_INSTANCE']].pop('type','whitelisted_pharmacy')
            whitelist=whitelist.append(r[os.environ['CB_INSTANCE']],ignore_index=True)
        whitelist['replaced_name']=[self.replace_wl(str(x)).upper() for x in whitelist['name']]
       
        filtered['geo_lat']=''
        filtered['geo_lng']=''
        filtered['created_at']=''
        filtered['updated_at']=''
        filtered['updated_by']=''
        filtered['claim_processor']='scriptclaim'
        filtered['cp_status']='active'
        filtered['npi_status']='active'
        filtered['type']='cp_pharmacy_stg'
        filtered['maclistid']='nan'
        filtered['sc_pharmbrandpriceamt']=''
        filtered['sc_pharmbrandpriceamtmo']=''
        filtered['pharmacytype']='RETAIL'
        
        query=N1QLQuery('SELECT meta().id as id FROM `'+os.environ['CB_INSTANCE']+'` WHERE type="cp_pharmacy"')
        query.adhoc=False
        query.timeout=7200
        cppharmacy=pd.DataFrame()
        claimproc=pd.DataFrame()
        metaids=[]
        for r in self.cb.n1ql_query(query):
            metaids.append(r['id'])

        for i in metaids:
            recdict=self.cb.get(i).value
            xele=recdict.pop('type')
            cproc=recdict.pop('cp_pharmacy_info')
            recdict['id']=i
            for rec in cproc:
                #if rec['claim_processor']!='scriptclaim': continue
                recdict.update(rec)
            cppharmacy=cppharmacy.append(recdict,ignore_index=True)
        print('got cp_pharmacy')				
        
        #filtered['pharmacynpi']=filtered['pharmacynpi'].apply(lambda x:str(int(x)).zfill(10))
        cppharmacy['pharmacynpi']=cppharmacy['pharmacynpi'].apply(lambda x:str(int(x)).zfill(10))
        if(len(filtered['pharmacynpi'])>len(set(list(filtered['pharmacynpi'])))):
        	for key,grp in filtered.groupby(['pharmacynpi']):
        		if(len(grp)>1):
        			for i,r in grp.iterrows():
        				errors=errors.append({'pharmacynpi':key,'pharmacyname':r['pharmacyname'],'pharmacyaddress':r['pharmacyaddress1'],'previousaddress':'','error':'Duplicate NPIs'},ignore_index=True)
		
        
	
        for i,r in filtered.iterrows():
        	print(i,r['pharmacynpi'])	
        	if str(filtered.loc[i,'chaincode']) in list(maclist['ChainCode']):
        		filtered.loc[i,'maclistid']=str(maclist[maclist['ChainCode']==str(r['chaincode'])]['MacListID'].values[0]).strip().upper() 
        	filtered.loc[i,'sc_pharmbrandpriceamt']=str(r['pharmbrandpriceamt'])
        	filtered.loc[i,'sc_pharmbrandpriceamtmo']=str(r['pharmbrandpriceamtmo'])
        	filtered.loc[i,'pharmbrandpriceamt']=str(r['pharmbrandpriceamt'])
        	filtered.loc[i,'pharmbrandpriceamtmo']=str(r['pharmbrandpriceamtmo'])
        	if filtered.loc[i,'maclistid']=='WALMARTMAC': filtered.loc[i,'claim_processor']='sc_walmart'						
        	if ((r['pharmacynpi']==cppharmacy['pharmacynpi'])).any():
        		#print('got it')
        		oldrecord=cppharmacy.loc[cppharmacy['pharmacynpi']==r['pharmacynpi'],:]
        		oldrecord.reset_index(drop=True,inplace=True)
        		if oldrecord['pharmacytype'].values[0]=='MAILORDER': filtered.loc[i,'pharmacytype']='MAILORDER'
        		elif oldrecord['pharmacytype'].values[0]=='SPECIALTY MAIL DELIVERY': filtered.loc[i,'pharmacytype']='SPECIALTY MAIL DELIVERY'
        		else: filtered.loc[i,'pharmacytype']='RETAIL'
        		ind=0
        		if SequenceMatcher(None,str(r['pharmacyname']).upper().strip(),str(oldrecord['pharmacyname'].values[ind]).upper().strip()).ratio()>=0.90:
        			filtered.loc[i,'wl_name']=str(oldrecord['wl_name'].values[ind])
        		else:
        			for j,wlr in whitelist.iterrows():
        				wln=None
        				wln=r['pharmacyname']
        				if wlr['replaced_name'].strip().upper() in wln.upper(): wln=wlr['replaced_name']
        				elif wlr['name'].strip().upper() in wln.upper(): wln=wlr['name']
        				filtered.loc[i,'wl_name']=self.replace_appname(wln.upper().strip())
        		if oldrecord['updated_by'].values[ind]=='System':
        			filtered.loc[i,['geo_lat','geo_lng','created_at']]=[oldrecord['geo_lat'].values[ind],oldrecord['geo_lng'].values[ind],oldrecord['created_at'].values[ind]]
        			filtered.loc[i,'updated_by']='System'
        			'''
        			if((SequenceMatcher(None,str(r['pharmacyaddress1']).upper().strip(),str(oldrecord['pharmacyaddress1'].values[ind]).upper().strip()).ratio()>=0.90)):
        				filtered.loc[i,['geo_lat','geo_lng','created_at']]=[oldrecord['geo_lat'].values[ind],oldrecord['geo_lng'].values[ind],oldrecord['created_at'].values[ind]]
        				filtered.loc[i,'updated_by']='System'
        			else:
						
        				try:
        					data=urllib2.urlopen('https://npiregistry.cms.hhs.gov/api/?number='+r['pharmacynpi']+'&enumeration_type=&taxonomy_description=&first_name=&last_name=&organization_name=&address_purpose=&city=&state=&postal_code=&country_code=&limit=&skip=')
        				except:
        					errors=errors.append({'pharmacynpi':r['pharmacynpi'],'pharmacyname':r['pharmacyname'],'pharmacyaddress':r['pharmacyaddress1'],'previousaddress':oldrecord['pharmacyaddress1'].values[ind],'error':'NPI in Previous File, Address not matching'},ignore_index=True)
        					continue
        				try:
        					data=json.loads(data.read().decode('UTF-8','ignore'))
        				except (ValueError, KeyError, TypeError):
        					errors=errors.append({'pharmacynpi':r['pharmacynpi'],'pharmacyname':r['pharmacyname'],'pharmacyaddress':r['pharmacyaddress1'],'previousaddress':oldrecord['pharmacyaddress1'].values[ind],'error':'NPI in Previous File, Address not matching'},ignore_index=True)
        					continue
        				for info in data['results'][0]['addresses']:
        					if info['address_purpose']=='LOCATION':
        						add1,city,state,zip=info['address_1'],info['city'],info['state'],info['postal_code']
        				filtered.loc[i,['pharmacyaddress1','pharmacycity','pharmacystate','pharmacyzip1']]=[add1,city,state,zip]
        				errors=errors.append({'pharmacynpi':r['pharmacynpi'],'pharmacyname':r['pharmacyname'],'pharmacyaddress':r['pharmacyaddress1'],'previousaddress':oldrecord['pharmacyaddress1'].values[ind],'error':'NPI in Previous File, Address not matching'},ignore_index=True)
        			'''
        		else:
        			if((SequenceMatcher(None,str(r['pharmacyaddress1']).upper().strip(),str(oldrecord['pharmacyaddress1'].values[ind]).upper().strip()).ratio()>=0.90)):
        				filtered.loc[i,['pharmacyaddress1','pharmacycity','pharmacystate','pharmacyzip1','geo_lat','geo_lng','created_at']]=[oldrecord['pharmacyaddress1'].values[ind],oldrecord['pharmacycity'].values[ind],oldrecord['pharmacystate'].values[ind],oldrecord['pharmacyzip1'].values[ind],oldrecord['geo_lat'].values[ind],oldrecord['geo_lng'].values[ind],oldrecord['created_at'].values[ind]]
        				filtered.loc[i,'updated_by']='Manually'
        			elif((SequenceMatcher(None,str(r['pharmacyaddress1']).upper().strip(),str(oldrecord['pharmacyaddress1'].values[ind]).upper().strip()).ratio()<0.90)):
        				errors=errors.append({'pharmacynpi':r['pharmacynpi'],'pharmacyname':r['pharmacyname'],'pharmacyaddress':r['pharmacyaddress1'],'previousaddress':oldrecord['pharmacyaddress1'].values[ind],'error':'NPI in Previous File, Address not matching'},ignore_index=True)
        			
        	else:
        		
        		for j,wlr in whitelist.iterrows():
        			wln=None
        			wln=r['pharmacyname']
        			if wlr['replaced_name'].strip().upper() in wln.upper(): 
        				wln=wlr['replaced_name']
        				
        			elif wlr['name'].strip().upper() in wln.upper(): 
        				wln=wlr['name']
        				
        			filtered.loc[i,'wl_name']=self.replace_appname(wln.upper().strip())
				
        		filtered.loc[i,'created_at']=datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat()
        		#errors=errors.append({'pharmacynpi':r['pharmacynpi'],'pharmacyname':r['pharmacyname']+"/wlname:"+r['wl_name'],'pharmacyaddress':r['pharmacyaddress1'],'pharmadiraddress':'','error':'New NPI'},ignore_index=True)
				
        filtered['updated_at']=datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat()
        filtered.drop(['corpname-new','pharmacyname-new'],axis=1,inplace=True)
        filtered.to_csv(path+'/'+filetype+'/updatecp_initial.csv',index=False)
        errors.to_csv(path+'/'+filetype+'/log/errors'+str(datetime.now())+'.csv',index=False)
        
        
        
        
        geocodes=self.geocodeAddress(filtered[filtered['geo_lat']==''])
		           
        if geocodes.empty==False:
        	for i,r in geocodes.iterrows():
        		filtered.loc[filtered['pharmacynpi']==r['npi'],['geo_lat','geo_lng','updated_by']]=[str(r['geo_lat']),str(r['geo_lng']),'System']
        filtered=filtered[filtered['geo_lat']!='']      
        filtered.drop_duplicates(inplace=True)
        oldnew=cppharmacy[cppharmacy['pharmacynpi'].isin(list(filtered['pharmacynpi']))==False]
        oldnew['cp_status']='inactive'
        filtered=pd.concat([filtered,oldnew],ignore_index=True)
        filtered[(filtered['created_at'].str.contains(str(datetime.now().date()))) | (filtered['cp_status']=='inactive')].to_csv(path+'/'+filetype+'/log/NewOrMissing'+str(datetime.now())+'.csv',index=False)
        errors.to_csv(path+'/'+filetype+'/log/errors'+str(datetime.now())+'.csv',index=False)
        filtered.drop(['id'],axis=1,inplace=True)
        filtered.to_csv(path+'/'+filetype+'/cppharmacy'+str(datetime.now())+'.csv',index=False)
        return filtered,True
      
       
    def output(self,cppharma):

        d=dict()
        docid=[]
        #doc_id=self.cb.n1ql_query(N1QLQuery('SELECT META().id as id FROM `'+os.environ['CB_INSTANCE']+'` where type="cp_pharmacy"'))
        #for did in doc_id:
            #docid.append(did['id'])
        cppharma['type']='cp_pharmacy_stg'
        
        
        inner_cols=["claim_processor","cp_status","pharmacyid","pharmbrandpriceamt","pharmbrandpriceamtmo","pharmbrandpricefee","pharmbrandpricefeemo","pharmmacpriceamt","pharmmacpriceamtmo","pharmmacpricefee","pharmmacpricefeemo","pharmnonmacpriceamt","pharmnonmacpriceamtmo","pharmnonmacpricefee","pharmnonmacpricefeemo","sc_pharmbrandpriceamt","sc_pharmbrandpriceamtmo","maclistid","chaincode"]
        cppharma['pharmacyid']=cppharma['pharmacyid'].apply(lambda x: int(x))
        for k,g in cppharma.groupby(['pharmacynpi']):
        	g.reset_index(drop=True,inplace=True)
        	d=dict()
        	for c in list(cppharma):
        		if c.lower() in inner_cols: continue
        		d[c.lower().replace(' ','_')]=str(g.loc[0,c]).strip()
        	d['cp_pharmacy_info']=[]
        	d_inner=dict()
        	for c in inner_cols:
        		d_inner[c.lower().replace(' ','_')]=str(g.loc[0,c]).strip()
        	d['cp_pharmacy_info'].append(d_inner)
        	self.cb.upsert(str(self.cb.counter('docid',delta=1).value),d,format=FMT_JSON)
        

domain,filetype,filename,mode=commandline.main(sys.argv[1:])
#email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','SSubramani@GWLabs.com','Pharmacy Directory Update - Initiated',['Monthly Pharmacy Directory Update'],None,False)
print(datetime.now()) 
location=os.environ['CB_URL']      
ob=CPPharmacyUpdate(location)
pdir,flag=ob.finalupdate()

flag=True
if flag==True and mode.lower().strip()=='final': ob.output(pdir)
print(datetime.now())
email_log('DWagle@GWLabs.com','DWagle@fliptrx.com','akarlis@fliptrx.com','Pharmacy Directory Update - Completed',['Monthly Pharmacy Directory Update','‘Pharmacy Directory Exception’'],path+'/'+filetype+'/log/errors.csv')

