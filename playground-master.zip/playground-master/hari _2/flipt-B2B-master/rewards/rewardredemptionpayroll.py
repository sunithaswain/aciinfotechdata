if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
   sys.path.append(rootdir)

# it will changed based on OS
rootdir = rootdir.replace('\\', '/')
path = rootdir + os.environ['CB_DATA']
 
import xlsxwriter
import os
import opccmdline
import sys
import datetime
import socket
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from utils.sendgridemail import email_log
from utils.truevault import User_Class
import calendar
import dateutil.parser as parser
from utils.FliptConcurrent import concurrent

cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
# path = os.environ['CB_DATA']
domain,file_type,file_name,mode,paytxt,endtxt = opccmdline.main(sys.argv[1:])
req=concurrent(sys.argv[0],sys.argv[1:5])
currentdate = datetime.datetime.now().isoformat()
filepath = path+'/'+domain+'/'+file_type+'/'+'RewardRedemption'+file_name+str(currentdate)+'.xlsx'
image_path = path+'/'+domain+'/'+file_type+'/flipt.PNG'
host = socket.gethostname()

def rewardpayroll(domain,file_type,file_name,mode,paytxt):

	ename = ''
	fname = ''
	lname = ''
	subject = ''
	empid = ''
	# Create a workbook and add a worksheet.
	workbook = xlsxwriter.Workbook(filepath)
	worksheet = workbook.add_worksheet()
	
	# Different Formats for Rows and Columns
	header_format = workbook.add_format({
		'bold': True,
		'text_wrap': True,
		'valign': 'top',
		'fg_color': '#FF0000',
		'border': 1})
	header_format.set_font_color('#FFFFFF')
	header_format.set_border_color('#FF0000')

	parameter_format = workbook.add_format({
		'bold': True,
		'text_wrap': True,
		'valign': 'top',
		'fg_color': '#FF0000',
		'border': 1})
	parameter_format.set_font_color('#FFFFFF')	
	parameter_format.set_border_color('#FF0000')

	row_format = workbook.add_format({
		'bold': False,
		'text_wrap': True,
		'valign': 'top',
		'fg_color': '#FFFFFF',
		'border': 1})	
	row_format.set_border_color('#FF0000')
	
	decimal_format = workbook.add_format({
		'bold': False,
		'text_wrap': True,
		'valign': 'top',
		'fg_color': '#FFFFFF',
		'border': 1,
		'num_format': '#,##0.00'})	
	decimal_format.set_border_color('#FF0000')	

	merge_format = workbook.add_format({
		'bold': True,
		'text_wrap': True,
		'align': 'center',
		'valign': 'vcenter',
		'fg_color': '#FF0000',
		'border': 1})	
	merge_format.set_font_size(30)
	merge_format.set_font_color('#FFFFFF')
	
	if file_name.upper() == 'DETAIL':	
		row = 0	
	elif file_name.upper() == 'SUMMARY':

		# Start from the first cell. Rows and columns are zero indexed.
		row = 0
		col = 0
		location = ''
		subject = 'Reward Redemption Via Payroll Summary Report - '+host
		worksheet.insert_image('A1', image_path, {'x_scale': 0.3, 'y_scale': 0.3})
		work_email = ''
		user_type = ''
		# Set column Width
		worksheet.set_column('A:A',22)
		worksheet.set_column('B:B',40)
		worksheet.set_column('C:C',30)
		worksheet.set_column('D:D',15)
		worksheet.set_column('E:E',30)
		worksheet.set_column('F:F',40)
		worksheet.set_column('G:G',40)
		worksheet.set_column('H:H',40)


		# Report Header
		worksheet.merge_range('C1:F3', 'Flipt Reward Redemption Via Payroll Report', merge_format)

		# Report parameters
		worksheet.write(4, 0, "Payroll Date",parameter_format)
		worksheet.write(4, 1, paytxt,row_format)
		worksheet.write(5, 0, "Domain",parameter_format)
		worksheet.write(5, 1, domain,row_format)
		worksheet.write(4, 4, "Report Generated at ",parameter_format)
		worksheet.write(4, 5, currentdate, row_format)

		# write it out row by row.
		worksheet.write(7, 0, "Employee Number",header_format)
		worksheet.write(7, 1, "Employee Name",header_format)
		worksheet.write(7, 2, "Employee Location",header_format)
		#worksheet.write(7, 3, "Flipt User Type",header_format)
		worksheet.write(7, 3, "Reward Amount in $",header_format)
		worksheet.write(7, 4, "Email Address",header_format)
		worksheet.write(7, 5, "Reward Option",header_format)
		worksheet.write(7, 6, "Redeemed By",header_format)
		
		totalreward=0.0
		paymenttab = N1QLQuery('select created_by,flipt_person_id,reward_option ,SUM(TONUMBER(reward_amount)) as reward_amount from `'+os.environ['CB_INSTANCE']+'` where type = "rewardtransaction" and reward_option = "Redeem Rewards via Payroll" and redemption_request_date is not missing and (redeem_extract_date is missing or redeem_extract_date in ["nan",""]) group by created_by,flipt_person_id,reward_option order by flipt_person_id')
		paymenttab.adhoc = False
		paymenttab.timeout = 100
		row = 8
		cl=''
		for paymentrow in cb.n1ql_query(paymenttab):
			flipt_person_id = paymentrow['flipt_person_id']
			created_by = paymentrow['created_by']
			created_by = created_by.strip()
			flipt_person_id = flipt_person_id.strip()
			emp_reward = float(paymentrow['reward_amount']) * (-1.0)
			reward_option = paymentrow['reward_option']

			emp_flipt_person_id = ''
			emptab = N1QLQuery('select distinct emp_flipt_person_id from `'+os.environ['CB_INSTANCE']+'` Where type = "flipt_person_hierarchy" and dep_flipt_person_id = $person_id',person_id = str(flipt_person_id).strip())
			emptab.adhoc = False
			emptab.timeout = 100
			for emprow in cb.n1ql_query(emptab):
				emp_flipt_person_id = emprow['emp_flipt_person_id']
				
			# Get Employee Name from True Vault for a Flipt Person id
			obj=User_Class(None,None)
			search_option={'full_document':True,'filter':{'domain_name':{'type':'eq','value':domain,'case_sensitive':False},'flipt_person_id':{'type':'eq','value':emp_flipt_person_id,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
			att,userid = obj.search_user(search_option)
			if att!=None:
				fn = att['first_name']
				ln = att['last_name']
				pc = att['person_code']
				location = att['location']
				if pc == '01':
					user_type = "Employee"
					if 'work_email' in att:
						work_email = att['work_email']
				# Dependent Emails
				else:
					user_type = "Dependent"
					if 'email' in att:
						work_email = att['email']
				if att['flipt_person_id'].strip() == emp_flipt_person_id.strip():
					fname = fn
					lname = ln
					empid = att['employee_id']
					ename = lname+', '+fname
					work_email = work_email
			
			else:
				ename = 'Not Found'
				empid = 'Not Found'

			if ename == 'Not Found':
				continue


			edname = ''
			# Get Flipt Name from True Vault for a Flipt Person id
			obj=User_Class(None,None)
			search_option={'full_document':True,'filter':{'domain_name':{'type':'eq','value':domain,'case_sensitive':False},'flipt_person_id':{'type':'eq','value':created_by,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
			att,userid = obj.search_user(search_option)
			if att!=None:
				firstd = att['first_name']
				lastd = att['last_name']
				if att['flipt_person_id'].strip() == created_by.strip():
					fdname = firstd
					ldname = lastd
					edname = ldname+', '+fdname
				
			if emp_reward is None or len(str(emp_reward)) == 0:
				emp_reward = '0.0'
				
			worksheet.write(row, 0, empid,row_format)
			worksheet.write(row, 1, ename,row_format)
			worksheet.write(row, 2, location,row_format)
			#worksheet.write(row, 3, user_type,row_format)
			worksheet.write(row, 3, float(emp_reward),decimal_format)
			#worksheet.write(row, 4, redreqdate,row_format)
			worksheet.write(row, 4, work_email,row_format)
			worksheet.write(row, 5, reward_option,row_format)
			worksheet.write(row, 6, edname,row_format)
			
			row = row + 1
			totalreward=totalreward+float(emp_reward)
		req.no_rec_received=row
		worksheet.write(row, 2, "Total : ",header_format)
		worksheet.write(row, 3, totalreward,decimal_format)
		if mode.lower().strip()=='final':
			cb.n1ql_query(N1QLQuery("update `"+os.environ['CB_INSTANCE']+"` set redeem_extract_date=$rrd where type = 'rewardtransaction' and redemption_request_date is not missing and reward_option = 'Redeem Rewards via Payroll' and (redeem_extract_date is missing or redeem_extract_date in ['nan',''])",rrd=currentdate)).execute()
		
		
	workbook.close()
	send_to='FliptIntegration@fliptrx.com'
	if os.environ['INSTANCE_TYPE']=='PROD': send_to='DAlberto@GWLabs.com,LPeysekhman@fliptrx.com,CNg@GWLabs.com,FliptIntegration@fliptrx.com,Rjuhring@fliptrx.com,deepthi.gollapudi@nttdata.com,dwagle@fliptrx.com,hrpayroll@gwlabs.com'

	email_log('ASriperambuduru@GWLabs.com','SPal@fliptrx.com',send_to,subject,['Processing of '+'RewardRedemption Via Payroll'+str(file_name),'RewardRedemption Exception'],filepath,True)
	#os.remove(filepath)
	
#rewardpayroll(domain,file_type,file_name,mode,starttxt,endtxt)