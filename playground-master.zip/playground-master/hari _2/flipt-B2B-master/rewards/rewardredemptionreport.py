if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
   sys.path.append(rootdir)

# it will changed based on OS
rootdir = rootdir.replace('\\', '/')
path = rootdir + os.environ['CB_DATA']
 
import xlsxwriter
import os
import opccmdline
import sys
import datetime
import socket
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from utils.sendgridemail import email_log
from utils.truevault import User_Class
import calendar
from utils.FliptConcurrent import concurrent

cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
# path = os.environ['CB_DATA']
domain,file_type,file_name,mode,starttxt,endtxt = opccmdline.main(sys.argv[1:])
currentdate = datetime.datetime.now().isoformat()
filepath = path+'/'+domain+'/'+file_type+'/'+'RewardRedemption'+file_name+str(currentdate)+'.xlsx'
image_path = path+'/'+domain+'/'+file_type+'/flipt.PNG'
host = socket.gethostname()
req=concurrent(sys.argv[0],sys.argv[1:])
#email_log('DWagle@GWLabs.com','DWagle@GWLabs.com',"SSubramani@GWLabs,ASriperambuduru@GWLabs.com",host+" RewardRedemption Report Initiated",['Processing of Reward Redemption Summary Report'],None,False)

ename = ''
fname = ''
lname = ''
subject = ''
empid = ''
freq=''
query=N1QLQuery('Select reward_frequency from `'+os.environ['CB_INSTANCE']+'` where type="domain" and domain=$dn',dn=domain)
for x in cb.n1ql_query(query):
    freq=x['reward_frequency']
interval=0
if freq.strip().lower()=='daily': 
	interval=0
elif freq.strip().lower()=='weekly':
	if datetime.datetime.today().weekday()!=0: 
		print('Not Monday of the Week')
		req.error_message='Not A Monday'
		req.close()
		exit()
	interval=7
elif freq.strip().lower()=='biweekly':
	if datetime.datetime.today().weekday()!=0:
		print('Not the Last Day of the Week')
		req.close()
		exit()
	interval=15
elif freq.strip().lower()=='monthly':
	if datetime.datetime.today().day!=1:
		print('Not First Day of the Month')
		req.close()
		exit()
	yr=(datetime.datetime.today()-datetime.timedelta(1)).year
	mth=(datetime.datetime.today()-datetime.timedelta(1)).month
	mrange=calendar.monthrange(yr,mth)
	interval=mrange[1]-mrange[0]+3
start_date = datetime.datetime.today()-datetime.timedelta(interval)
start_date = datetime.datetime.strptime(str(start_date.replace(hour=0,minute=0,second=0)),'%Y-%m-%d %H:%M:%S.%f').isoformat()
end_date=''
if freq.strip().lower()=='daily': end_date = datetime.datetime.today()
else: end_date = datetime.datetime.today()-datetime.timedelta(1)
end_date = datetime.datetime.strptime(str(end_date.replace(hour=23,minute=59,second=59)),'%Y-%m-%d %H:%M:%S.%f').isoformat()
# Create a workbook and add a worksheet.
workbook = xlsxwriter.Workbook(filepath)
worksheet = workbook.add_worksheet()


# Different Formats for Rows and Columns
header_format = workbook.add_format({
    'bold': True,
    'text_wrap': True,
    'valign': 'top',
    'fg_color': '#FF0000',
    'border': 1})
header_format.set_font_color('#FFFFFF')
header_format.set_border_color('#FF0000')

parameter_format = workbook.add_format({
    'bold': True,
    'text_wrap': True,
    'valign': 'top',
    'fg_color': '#FF0000',
    'border': 1})
parameter_format.set_font_color('#FFFFFF')	
parameter_format.set_border_color('#FF0000')

row_format = workbook.add_format({
    'bold': False,
    'text_wrap': True,
    'valign': 'top',
    'fg_color': '#FFFFFF',
    'border': 1})	
row_format.set_border_color('#FF0000')

merge_format = workbook.add_format({
    'bold': True,
    'text_wrap': True,
	'align': 'center',
    'valign': 'vcenter',
    'fg_color': '#FF0000',
    'border': 1})	
merge_format.set_font_size(30)
merge_format.set_font_color('#FFFFFF')

if file_name.upper() == 'DETAIL':	
	# Start from the first cell. Rows and columns are zero indexed.
	startdate=datetime.datetime.strptime(starttxt,'%m-%d-%Y').isoformat()
	enddate=datetime.datetime.strptime(endtxt,'%m-%d-%Y').isoformat()
	row = 0
	col = 0
	subject = 'Reward Redemption Detail Report - '+host
	worksheet.insert_image('A1', image_path, {'x_scale': 0.3, 'y_scale': 0.25})
	cancel_date = ''
	emp_refund = 0
	user_type = ''
	work_email = ''
	reward_option = ''
	# Set column Width
	worksheet.set_column('A:A',22)
	worksheet.set_column('B:B',25)
	worksheet.set_column('C:C',23)
	worksheet.set_column('D:D',25)
	worksheet.set_column('E:E',25)
	worksheet.set_column('F:F',25)
	worksheet.set_column('G:G',25)
	worksheet.set_column('H:H',14)
	worksheet.set_column('I:I',14)
	worksheet.set_column('J:J',15)
	worksheet.set_column('K:K',17)
	worksheet.set_column('L:L',17)
	worksheet.set_column('M:M',25)
	worksheet.set_column('N:N',40)
	worksheet.set_column('O:O',15)

	# Report Header
	worksheet.merge_range('C1:F3', 'Flipt Reward Redemption Report', merge_format)

	# Report parameters
	worksheet.write(3, 0, "Statement Date Range",parameter_format)
	worksheet.write(4, 0, "Domain",parameter_format)
	worksheet.write(3, 1, start_date,row_format)
	worksheet.write(3, 2, end_date,row_format)
	worksheet.write(4, 1, domain,row_format)
	worksheet.write(3, 4, "Report Generated at ",parameter_format)
	worksheet.write(3, 5, currentdate, row_format)

	# write it out row by row.
	worksheet.write(6, 0, "RX Number",header_format)
	worksheet.write(6, 1, "Reward Transaction ID",header_format)
	worksheet.write(6, 2, "Employee Number",header_format)
	worksheet.write(6, 3, "Flipt User Name",header_format)
	worksheet.write(6, 4, "Pharmacy",header_format)
	worksheet.write(6, 5, "Location",header_format)
	worksheet.write(6, 6, "Routed Date",header_format)
	worksheet.write(6, 7, "Drug Cost",header_format)
	worksheet.write(6, 8, "Employer Cost",header_format)
	worksheet.write(6, 9, "Employee OPC",header_format)
	worksheet.write(6, 10, "Reward Amount",header_format)
	worksheet.write(6, 11, "Reward Date",header_format)
	worksheet.write(6, 12, "Redeem Requested Date",header_format)
	worksheet.write(6, 13, "Reward Option",header_format)
	worksheet.write(6, 14, "Flipt User Type",header_format)	
	totalreward=0.0
	paymenttab = N1QLQuery('select prescription_id,id,flipt_person_id,created_by,reward_amount,reward_date,redemption_request_date,reward_option from `'+os.environ['CB_INSTANCE']+'` Where type = "rewardtransaction" and (reward_date>=$std and reward_date<=$end or redemption_request_date>=$std and redemption_request_date<=$end) order by reward_date',std=startdate,end=enddate)
	paymenttab.adhoc = False
	paymenttab.timeout = 100
	row = 7
	for paymentrow in cb.n1ql_query(paymenttab):
		flipt_person_id = paymentrow['flipt_person_id']
		flipt_person_id = flipt_person_id.strip()
		if 'reward_option' in paymentrow:
			reward_option = paymentrow['reward_option']
		created_by = paymentrow['created_by']
		created_by = created_by.strip()
		prescription_id = paymentrow['prescription_id']
		rt_id = paymentrow['id']
		rwa = paymentrow['reward_amount']
		rdate = paymentrow['reward_date']
		rrdate=''
		if 'redemption_request_date' in paymentrow: rrdate = paymentrow['redemption_request_date']
		pharmacy,location,routed_date,drug_cost,employer_cost,employee_opc='','','','','',''
		getpresc = N1QLQuery('select pharmacy,location,routed_date,drug_cost,employer_cost,employee_opc from `'+os.environ['CB_INSTANCE']+'` Where type = "prescription" and prescription_id=$pid',pid=prescription_id)
		for q in cb.n1ql_query(getpresc):
		    pharmacy=q['pharmacy']
		    location=q['location']
		    routed_date=q['routed_date']
		    drug_cost=q['drug_cost']
		    employer_cost=q['employer_cost']
		    employee_opc=q['employee_opc']
		    
		# Get Employee Name from True Vault for a Flipt Person id
		obj=User_Class(None,None)
		search_option={'full_document':True,'filter':{'domain_name':{'type':'eq','value':domain,'case_sensitive':False},'flipt_person_id':{'type':'eq','value':created_by,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
		att,userid = obj.search_user(search_option)
		
		if att!=None:
			fn = att['first_name']
			ln = att['last_name']
			if att['flipt_person_id'].strip() == created_by.strip():
				fname = fn
				lname = ln
				empid = att['employee_id']
				ename = lname+', '+fname
				pc = att['person_code']
				if pc == '01':
					user_type = "Employee"
					if 'work_email' in att:
						work_email = att['work_email']
				# Dependent Emails
				else:
					user_type = "Dependent"
					if 'email' in att:
						work_email = att['email']		
		else:
			ename = 'Not Found'
			empid = 'Not Found'
			
		if ename == 'Not Found':
			continue
			
		worksheet.write(row, 0, prescription_id,row_format)
		worksheet.write(row, 1, rt_id,row_format)
		worksheet.write(row, 2, empid,row_format)
		worksheet.write(row, 3, ename,row_format)
		worksheet.write(row, 4, pharmacy,row_format)
		worksheet.write(row, 5, location,row_format)
		worksheet.write(row, 6, routed_date,row_format)
		worksheet.write(row, 7, drug_cost,row_format)
		worksheet.write(row, 8, employer_cost,row_format)
		worksheet.write(row, 9, employee_opc,row_format)
		worksheet.write(row, 10, float(rwa),row_format)
		worksheet.write(row, 11, rdate,row_format)
		worksheet.write(row, 12, rrdate,row_format)
		worksheet.write(row, 13, reward_option,row_format)
		worksheet.write(row, 14, user_type,row_format)	
		row = row + 1
		totalreward=totalreward+float(rwa)
	worksheet.write(row, 9, "Total : ",header_format)
	worksheet.write(row, 10, totalreward,row_format)
	
elif file_name.upper() == 'SUMMARY':

	# Start from the first cell. Rows and columns are zero indexed.
	row = 0
	col = 0
	subject = 'Reward Redemption Summary Report - '+host
	worksheet.insert_image('A1', image_path, {'x_scale': 0.3, 'y_scale': 0.3})
	work_email = ''
	user_type = ''
	# Set column Width
	worksheet.set_column('A:A',22)
	worksheet.set_column('B:B',40)
	worksheet.set_column('C:C',30)
	worksheet.set_column('D:D',15)
	worksheet.set_column('E:E',30)
	worksheet.set_column('F:F',40)
	worksheet.set_column('G:G',40)


	# Report Header
	worksheet.merge_range('C1:F3', 'Flipt Reward Redemption Report', merge_format)

	# Report parameters
	worksheet.write(4, 0, "Statement Date Range",parameter_format)
	worksheet.write(4, 1, start_date,row_format)
	worksheet.write(4, 2, end_date,row_format)	
	worksheet.write(5, 0, "Domain",parameter_format)
	worksheet.write(5, 1, domain,row_format)
	worksheet.write(4, 4, "Report Generated at ",parameter_format)
	worksheet.write(4, 5, currentdate, row_format)

	# write it out row by row.
	worksheet.write(7, 0, "Employee Number",header_format)
	worksheet.write(7, 1, "Flipt User Name",header_format)
	worksheet.write(7, 2, "Flipt User Type",header_format)
	worksheet.write(7, 3, "Rewards",header_format)
	worksheet.write(7, 4, "Redeem Requested",header_format)
	worksheet.write(7, 5, "Email Address",header_format)
	worksheet.write(7, 6, "Reward Option",header_format)
	totalreward=0.0
	paymenttab = N1QLQuery('select created_by,flipt_person_id,reward_option ,TONUMBER(reward_amount) as reward_amount, redemption_request_date,clock_local() as cl from `'+os.environ['CB_INSTANCE']+'` where type = "rewardtransaction" and reward_option = "Redeem Rewards via Amazon Gift Card" and redemption_request_date is not missing and (redeem_extract_date is missing or redeem_extract_date in ["nan",""])',screate_date = start_date, ecreate_date = end_date)
	paymenttab.adhoc = False
	paymenttab.timeout = 100
	row = 8
	cl=''
	for paymentrow in cb.n1ql_query(paymenttab):
		flipt_person_id = paymentrow['flipt_person_id']
		created_by = paymentrow['created_by']
		created_by = created_by.strip()
		flipt_person_id = flipt_person_id.strip()
		emp_reward = float(paymentrow['reward_amount']) * (-1.0)
		redreqdate = paymentrow['redemption_request_date']
		reward_option = paymentrow['reward_option']
		cl=paymentrow['cl']
		# Get Employee Name from True Vault for a Flipt Person id
		obj=User_Class(None,None)
		search_option={'full_document':True,'filter':{'domain_name':{'type':'eq','value':domain,'case_sensitive':False},'flipt_person_id':{'type':'eq','value':created_by,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
		att,userid = obj.search_user(search_option)
		if att!=None:
			fn = att['first_name']
			ln = att['last_name']
			pc = att['person_code']
			if pc == '01':
				user_type = "Employee"
				if 'work_email' in att:
					work_email = att['work_email']
			# Dependent Emails
			else:
				user_type = "Dependent"
				if 'email' in att:
					work_email = att['email']
			if att['flipt_person_id'].strip() == created_by.strip():
				fname = fn
				lname = ln
				empid = att['employee_id']
				ename = lname+', '+fname
				work_email = work_email
		
		else:
			ename = 'Not Found'
			empid = 'Not Found'

		if ename == 'Not Found':
			continue
		
		if emp_reward is None or len(str(emp_reward)) == 0:
			emp_reward = '0.0'
			
		
			
		worksheet.write(row, 0, empid,row_format)
		worksheet.write(row, 1, ename,row_format)
		worksheet.write(row, 2, user_type,row_format)
		worksheet.write(row, 3, float(emp_reward),row_format)
		worksheet.write(row, 4, redreqdate,row_format)
		worksheet.write(row, 5, work_email,row_format)
		worksheet.write(row, 6, reward_option,row_format)
		row = row + 1
		totalreward=totalreward+float(emp_reward)
		
	worksheet.write(row, 2, "Total : ",header_format)
	worksheet.write(row, 3, totalreward,row_format)
	req.no_rec_received=row
	if mode.lower().strip()=='final':
		cb.n1ql_query(N1QLQuery("update `"+os.environ['CB_INSTANCE']+"` set redeem_extract_date=$rrd where type = 'rewardtransaction' and redemption_request_date is not missing and redemption_request_date>=$screate_date and reward_option = 'Redeem Rewards via Amazon Gift Card' and redemption_request_date<$ecreate_date and (redeem_extract_date is missing or redeem_extract_date in ['nan',''])",screate_date = start_date, ecreate_date = end_date,rrd=cl)).execute()
	
	
workbook.close()
send_to='FliptIntegration@fliptrx.com,deepthi.gollapudi@nttdata.com,dwagle@fliptrx.com'
if host=='AZ-Flipt-Orch': send_to='reports@fliptrx.com,lpeysekhman@fliptrx.com,FliptIntegration@fliptrx.com,deepthi.gollapudi@nttdata.com,dwagle@fliptrx.com'

email_log('DWagle@GWLabs.com','DWagle@GWLabs.com',send_to,subject,['Processing of '+'RewardRedemption'+str(file_name),'RewardRedemption Exception'],filepath,True)
req.close()
#os.remove(filepath)