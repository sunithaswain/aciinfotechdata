
if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
   sys.path.append(rootdir)

# it will changed based on OS
rootdir = rootdir.replace('\\', '/')
path = rootdir + os.environ['CB_DATA']

import json
import base64
import pprint
import pandas as pd
import os
import json
import sys
from datetime import datetime
import requests
from requests.auth import HTTPBasicAuth
import shutil
from pathlib import Path
import pandas as pd
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
import couchbase.subdocument as SD
from couchbase import FMT_JSON

from utils import commandline
from utils.sendgridemail import email_log
from utils.truevault import User_Class

domain_name,file_type,file_name,mode=commandline.main(sys.argv[1:])
email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','SSubramani@GWLabs.com','Flipt Person Hierarchy Update - Initiated',['Processing of Aetna Member file '+file_name],None,False)
df=pd.read_excel(path+'/'+domain_name+'/'+file_type+'/'+file_name)
cluster = Cluster(os.environ['CB_URL'])
bucket_name=os.environ['CB_INSTANCE']
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(bucket_name)
api_key=os.environ['TV_API_KEY']
errorlog=pd.DataFrame()

cols={}
for c in list(df):
	cols[c]=c.lower().replace(' ','_')
df.rename(columns=cols,inplace=True)
df=df.loc[:,['ee_ssn','first_name','last_name','birth_date','cumbid','sequence','relationship','effective','dep_cumbid','home_phone','work_phone','gender']]
#df['ee_ssn']=df['ee_ssn'].apply(lambda x: 'xxx-xx-'+str(x)[-4:])
df['effective']=df['effective'].apply(lambda x:  datetime.strptime(x.replace('00/00/0000','01/01/0001'), '%m/%d/%Y'))
df['cumbid']=df['cumbid'].apply(lambda x: x.replace('W',''))
df['dep_cumbid']=df['dep_cumbid'].apply(lambda x: str(int(x)) if pd.isnull(x)==False else '')
df['sequence']=df['sequence'].apply(lambda x: str(x).zfill(2))
df['home_phone']=df['home_phone'].apply(lambda x: str(int(x)) if pd.isnull(x)==False else '')
df['work_phone']=df['work_phone'].apply(lambda x: str(int(x)) if pd.isnull(x)==False else '')
df['sequence']=df['sequence'].apply(lambda x: str(x).zfill(2))
df['birth_date']=df['birth_date'].apply(lambda x: datetime.strftime(datetime.strptime(x,'%m/%d/%Y'),'%Y-%m-%d 00:00:00'))
df.fillna('',inplace=True)
df.drop_duplicates(inplace=True)

for key,group1 in df.groupby(['ee_ssn']):
	
	group=pd.DataFrame()
	for seq in set(list(group1['sequence'])):
		maxdate=max(list(group1[group1['sequence']==seq]['effective']))
		group=group.append(group1.loc[(group1['sequence']==seq) & (group1['effective']==maxdate),:],ignore_index=True)
	group.reset_index(drop=True,inplace=True)
	g=group.loc[group['sequence']=='01',['birth_date','ee_ssn','first_name','last_name','sequence','cumbid','effective','home_phone','work_phone','gender']]
	g.reset_index(drop=True,inplace=True)
	searched=False
	attlist=[]
	useridlist=[]
	employeefound=False
	attindex=0
	for i,r in group.iterrows():
		#print(r)
		
		
		if not searched:
			
			obj=User_Class(None,None)
			for ind,row in g.iterrows():
				search_option={'full_document':True,'filter':{'employee_ssn':{'type':'eq','value':'xxx-xx-'+str(key)[-4:],'case_sensitive':False},'domain_name':{'type':'eq','value':domain_name,'case_sensitive':False},'date_of_birth':{'type':'eq','value':str(row['birth_date']),'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
				attlist1,userid=obj.search_user_id(search_option)
				attlist.extend(attlist1)
				useridlist.extend(userid)
				if len(attlist)!=0:
					searched=True
					break
			if searched==False: break
		
		if r['sequence']=='01':
			
			if employeefound: continue
			
			for att in attlist:
				if (r['first_name']==att['first_name'] and r['last_name']==att['last_name']) or (r['birth_date']==att['date_of_birth']):
					employeefound=True
					#print('employee')
					#print(r)
					emp_flipt_person_id=att['flipt_person_id']
					carrier=[{'ins_carrier_name':'Aetna','ins_carrier_member_id':str(r['cumbid']),'ins_relationship_code':str(r['sequence']),'coverage_tier_name':str(att['coverage_tier_name']),'benefit_plan_name':str(att['benefit_plan_name'])}]
					phonelist=[]
					if r['home_phone']!='' or int(r['home_phone'])!=0:
						phonelist.append(r['home_phone'])
					if r['work_phone']!='' or r['home_phone']!=r['home_phone'] or int(r['work_phone'])!=0:
						phonelist.append(r['work_phone'])
					tvphone=[]
					if 'personal_phone' in att:
						tvphone.append(att['personal_phone'])
					tvphone.extend(phonelist)
					att['personal_phone']=list(set(tvphone))
				
					if mode.upper().strip()=='FINAL':
						query=N1QLQuery('Select meta().id,dep_flipt_person_id from `'+bucket_name+'`where type="flipt_person_hierarchy" and dep_flipt_person_id=$fid',fid=str(emp_flipt_person_id))
						
						for qres in cb.n1ql_query(query):
							cb.mutate_in(qres['id'],SD.upsert('ins_carrier',carrier))
					break
					attindex=attindex+1
			
				
		else:
			dependentfound=False
			nameError=False
			gr=pd.DataFrame()
			for att in attlist:
				depindex=0
				for dep in att['dependents']:
					if r['birth_date']==dep['date_of_birth']:
						depdict=dict(dep)
						depdict['depindex']=int(depindex)
						gr=gr.append(depdict,ignore_index=True)
					depindex=depindex+1
				fid=''
				gr.reset_index(drop=True,inplace=True)
				if len(gr)==1: 
					dependentfound = True
					fid=gr.loc[0,'flipt_person_id']
					att['dependents'][int(gr.loc[0,'depindex'])]['gender']=r['gender']
				if len(gr)>1:
					for ind,row in gr.iterrows():
						if row['first_name']==r['first_name'].strip() and row['last_name']==r['last_name'].strip():
							dependentfound=True
							fid=row['flipt_person_id']
							att['dependents'][int(row['depindex'])]['gender']=r['gender']
							break
					if not dependentfound:
						errorlog=errorlog.append({'Aetna First Name':r['first_name'],'Aetna Last Name':r['last_name'],'TV First Name':'','TV Last Name':'','Aetna Member ID':r['dep_cumbid'],'Error':'Dependent Name Not Matching Truevault'},ignore_index=True)
						nameError=True
				if dependentfound:
					
					carrier=[{'ins_carrier_name':'Aetna','ins_carrier_member_id':str(r['dep_cumbid']),'ins_relationship_code':str(r['sequence']),'coverage_tier_name':str(att['coverage_tier_name']),'benefit_plan_name':str(att['benefit_plan_name'])}]
					
					#print(carrier)
					query=N1QLQuery('Select meta().id as id,dep_flipt_person_id from `'+bucket_name+'`where type="flipt_person_hierarchy" and dep_flipt_person_id=$fliptid',fliptid=fid)
					for qres in cb.n1ql_query(query):
						if mode.upper().strip()=='FINAL':
							cb.mutate_in(qres['id'],SD.upsert('ins_carrier',carrier))
					break
				elif (not dependentfound and not nameError) or len(gr)==0:
					errorlog=errorlog.append({'Aetna First Name':r['first_name'],'Aetna Last Name':r['last_name'],'TV First Name':'','TV Last Name':'','Aetna Member ID':r['dep_cumbid'],'Error':'Dependent Not Found'},ignore_index=True)
	pprint.pprint(attlist[attindex])
	if mode.upper().strip()=='FINAL' and employeefound:
		updatedatt=attlist[attindex]
		updateuserid=useridlist[attindex]
		new_att=base64.b64encode(str.encode(json.dumps(updatedatt)))
		data={'attributes':new_att}
		r=requests.put('https://api.truevault.com/v1/users/%s' % str(updateuserid),auth=HTTPBasicAuth(api_key, ''),data=data)
	if not employeefound:
		fn=g['first_name'][0]
		ln=g['last_name'][0]
		if len(attlist)==0:
			errorlog=errorlog.append({'Aetna First Name':fn,'Aetna Last Name':ln,'TV First Name':'','TV Last Name':'','Aetna Member ID':g['cumbid'][0],'Error':'Employee Not Found in Truevault'},ignore_index=True)
			continue
		else:
			errorlog=errorlog.append({'Aetna First Name':fn,'Aetna Last Name':ln,'TV First Name':attlist[0]['first_name'],'TV Last Name':attlist[0]['last_name'],'Aetna Member ID':g['cumbid'][0],'Error':'Employee Not Matching with Truevault Attributes'},ignore_index=True)
	
errlog='Errorlog'+str(datetime.now())+'.xlsx'                       
writer=pd.ExcelWriter(path+'/'+domain_name+'/'+file_type+'/log/'+errlog)
errorlog.to_excel(writer,index=False)
writer.save()       
sender='DWagle@GWLabs.com'
receiver=['DWagle@GWLabs.com','SSubramani@GWLabs.com']
subject='Flipt Person Hierarchy Updated - Completed'
body=['Processing of Aetna Members file '+file_name,'Flipt Person Hierarchy Exception’']
email_log(sender,receiver[0],receiver[1],subject,body,path+'/'+domain_name+'/'+file_type+'/log/'+errlog)
			
	
