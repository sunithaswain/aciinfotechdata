
if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
   sys.path.append(rootdir)

# it will changed based on OS
rootdir = rootdir.replace('\\', '/')
path = rootdir + os.environ['CB_DATA']

import sys
from utils import commandline
import os
import traceback
import json
import time
import socket
import requests
from zipfile import ZipFile 
import dateutil.parser as parser
from datetime import datetime

import pandas as pd
from PyPDF2 import PdfFileWriter, PdfFileReader
from PyPDF2.generic import BooleanObject, NameObject, IndirectObject
from pprint import pprint
from collections import OrderedDict
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from couchbase import FMT_JSON
import couchbase.subdocument as SD

from utils.truevault import User_Class
from utils.sendgridemail import email_log,email_log_custom,email_log_custombody
from utils.FliptConcurrent import concurrent

#Command to Run the script
#python aetna_claim_form.py -d GWLABS001 -t aetna_claim_form


def _getFields(obj, tree=None, retval=None, fileobj=None):
	"""
	Extracts field data if this PDF contains interactive form fields.
	The *tree* and *retval* parameters are for recursive use.

	:param fileobj: A file object (usually a text file) to write
		a report to on all interactive form fields found.
	:return: A dictionary where each key is a field name, and each
		value is a :class:`Field<PyPDF2.generic.Field>` object. By
		default, the mapping name is used for keys.
	:rtype: dict, or ``None`` if form data could not be located.
	"""
	fieldAttributes = {'/FT': 'Field Type', '/Parent': 'Parent', '/T': 'Field Name', '/TU': 'Alternate Field Name',
					   '/TM': 'Mapping Name', '/Ff': 'Field Flags', '/V': 'Value', '/DV': 'Default Value'}
	if retval is None:
		retval = OrderedDict()
		catalog = obj.trailer["/Root"]
		# get the AcroForm tree
		if "/AcroForm" in catalog:
			tree = catalog["/AcroForm"]
		else:
			return None
	if tree is None:
		return retval

	obj._checkKids(tree, retval, fileobj)
	for attr in fieldAttributes:
		if attr in tree:
			# Tree is a field
			obj._buildField(tree, retval, fileobj, fieldAttributes)
			break

	if "/Fields" in tree:
		fields = tree["/Fields"]
		for f in fields:
			field = f.getObject()
			obj._buildField(field, retval, fileobj, fieldAttributes)

	return retval

def set_need_appearances_writer(writer: PdfFileWriter):
	# See 12.7.2 and 7.7.2 for more information: http://www.adobe.com/conten...
	
	try:
		catalog = writer._root_object
		# get the AcroForm tree
		if "/AcroForm" not in catalog:
			writer._root_object.update({
				NameObject("/AcroForm"): IndirectObject(len(writer._objects), 0, writer)})

		need_appearances = NameObject("/NeedAppearances")
		writer._root_object["/AcroForm"][need_appearances] = BooleanObject(True)
		return writer

	except Exception as e:
		print('set_need_appearances_writer() catch : ', repr(e))
		return writer

def get_form_fields(infile):
	infile = PdfFileReader(open(infile, 'rb'))
	fields = _getFields(infile)
	return OrderedDict((k, v.get('/V', '')) for k, v in fields.items())		

def updateCheckboxValues(page, fields):
	for j in range(0, len(page['/Annots'])):
		writer_annot = page['/Annots'][j].getObject()
		for field in fields:
			if writer_annot.get('/T') == field:
				writer_annot.update({
					NameObject("/V"): NameObject(fields[field]),
					NameObject("/AS"): NameObject(fields[field])})
	
host = socket.gethostname()
print(host)
domain,file_type,file_name,mode = commandline.main(sys.argv[1:])
req=concurrent(sys.argv[0],sys.argv[1:])
currentdate = datetime.now()
print(currentdate)
displaydate = currentdate.strftime("%Y%m%d")
currentdate = currentdate.isoformat()

field_dictionary={}	
checkbox_dictionary={}
reccount = 1
#To initiate the Couch base connection
cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
# path = os.environ['CB_DATA']

#Location of Template File
localpath = path+'/'+domain+'/'+file_type+'/'	
infile = localpath+'Aetna_Claim_Form_Template.pdf'


#Read pdf template and provide pdf pages to the writer
origfile = open(infile, "rb")
pdf = PdfFileReader(origfile, strict=False)

#Creating a zip file
with ZipFile(localpath+'aetna_claim_files_'+displaydate+'.zip','w') as zip:


	if "/AcroForm" in pdf.trailer["/Root"]:
		pdf.trailer["/Root"]["/AcroForm"].update({NameObject("/NeedAppearances"): BooleanObject(True)})

	#Retrieve all the  Filled prescriptions
	prescription = N1QLQuery('select a.flipt_person_id, a.rx_flipt_person_id, a.prescription_id, a.filled_date,a.domain as domainname from `'+os.environ['CB_INSTANCE']+'` a where type="prescription" and rx_status="Filled" and DATE_DIFF_STR(clock_local("1111-11-11"),DATE_FORMAT_STR(filled_date,"1111-11-11"),"day") > 1 and claimform_extracted_date is missing and to_number(employee_opc) > 0')
	prescription.adhoc = False
	prescription.timeout = 100

	for prescriptionrow in cb.n1ql_query(prescription):

		try:
		
				
			#Writes PDF files 
			pdf2 = PdfFileWriter()
			set_need_appearances_writer(pdf2)
			if "/AcroForm" in pdf2._root_object:
				pdf2._root_object["/AcroForm"].update({NameObject("/NeedAppearances"): BooleanObject(True)})

				
			flipt_person_id = prescriptionrow['flipt_person_id']
			print("FliptPersonId",flipt_person_id)
				
			if 'rx_flipt_person_id' in prescriptionrow:
				rx_flipt_person_id = str(prescriptionrow['rx_flipt_person_id'])
				print("Rx_Flipt_Person_ID",rx_flipt_person_id)
			else:
				rx_flipt_person_id = flipt_person_id
				print("Else rx flipt person id")
			
			dom = prescriptionrow['domainname']
			#TrueVault Call
			obj=User_Class(None,None)	
			search_option={'full_document':True,'filter':{'domain_name':{'type':'eq','value':dom,'case_sensitive':False},'flipt_person_id':{'type':'eq','value':flipt_person_id,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
			att,userid=obj.search_user(search_option)
			
			realuser=False
			if att!=None and 'parent_id' in att:
				type ="Dependent"
				print("Type:"+type)
				person=N1QLQuery('select b.ins_carrier from `'+os.environ['CB_INSTANCE']+'` b where type="flipt_person_hierarchy" and dep_flipt_person_id=$fliptpid', fliptpid = str(att['parent_id']))
				person.adhoc = False
				person.timeout = 100
				
				for personrow in cb.n1ql_query(person):
					realuser=True
					for carrierdetails in personrow['ins_carrier']:
						field_dictionary['member_number'] = 'W'+str(carrierdetails['ins_carrier_member_id'])
						field_dictionary['group_number'] = str(carrierdetails['group_number'])
				if not realuser: continue
				#Truevault Call for Employee Details
				search_option={'full_document':True,'filter':{'domain_name':{'type':'eq','value':dom,'case_sensitive':False},'flipt_person_id':{'type':'eq','value':str(att['parent_id']),'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
				att1,userid=obj.search_user(search_option)			
				if att1!=None:
					#EmployeeName
					field_dictionary['employee_name'] = str(att1['first_name'])+" "+str(att1['last_name'])
					#Employee DOB
					t= parser.parse(att1['date_of_birth'])
					formatteddt = str(t.month).zfill(2)+'/'+str(t.day).zfill(2)+'/'+str(t.year).zfill(2)
					field_dictionary['employee_bday'] = formatteddt
						
					#EmployeeAddress
					if str(att1['home_address_2'])!='':
						field_dictionary['employee_address'] = str(att1['home_address_1'])+','+str(att1['home_address_2'])+','+str(att1['city'])+','+str(att1['state'])+','+str(att1['zip'])
					else:
						field_dictionary['employee_address'] = str(att1['home_address_1'])+','+str(att1['city'])+','+str(att1['state'])+','+str(att1['zip'])
							
					#CompanyAddress		
					companydetails =N1QLQuery('select companylegalname,address1,city,state,zip from `'+os.environ['CB_INSTANCE']+'` where type="domain" and domain = $dn',dn = domain)
					companydetails.adhoc = False
					companydetails.timeout = 100
							
					for cdetails in cb.n1ql_query(companydetails):
						#print("CDETAILS ",cdetails)
						field_dictionary['employee_comp_address'] = str(cdetails['companylegalname'])+','+str(cdetails['address1'])+','+str(cdetails['city'])+','+str(cdetails['state'])+','+str(cdetails['zip'])
					
					#Employee Telephone Number
					carrier_phnumbers = ""
					carrier_telcode = ""			
					
					if 'communication_option_phone' in att1:
						field_dictionary['emp_tel_code']=str(att1['communication_option_phone'][:3])
						field_dictionary['emp_tel_number']= str(att1['communication_option_phone'][3:])
					elif 'carrier_phonenumbers' in att1:
						if len(att1['carrier_phonenumbers'])>0:
							carrier_telcode = str(att1['carrier_phonenumbers'][0])
							carrier_phnumbers = str(att1['carrier_phonenumbers'][0])
							field_dictionary['emp_tel_code']= carrier_telcode[:3]
							field_dictionary['emp_tel_number']= carrier_phnumbers[3:]
					
					#FormDate
					formdate=parser.parse(prescriptionrow['filled_date'])
					field_dictionary['form_date'] = str(formdate.month).zfill(2)+'/'+str(formdate.day).zfill(2)+'/'+str(formdate.year).zfill(2)
					
					#PrescriptionSection For dependent
					
					#PatientName
					if rx_flipt_person_id==str(att1['flipt_person_id']):
						field_dictionary['patient_name'] = str(att1['last_name']) +", "+ str(att1['first_name'])
						if str(att1['gender']) == 'M':
								checkbox_dictionary['gender_male'] = '/Yes'
								checkbox_dictionary['gender_female']= '/Off'
						else:
							checkbox_dictionary['gender_female'] = '/Yes'
							checkbox_dictionary['gender_male'] = '/Off'
						checkbox_dictionary['employee_check'] = '/Yes'
						field_dictionary['patient_name'] = str(att1['last_name']) +", "+ str(att1['first_name'])
						patient_dob= parser.parse(att1['date_of_birth'])
						patient_format_dob = str(patient_dob.month).zfill(2)+'/'+str(patient_dob.day).zfill(2)+'/'+str(patient_dob.year).zfill(2)
						field_dictionary['patient_bday'] = patient_format_dob
						
					#print("PatientName:",field_dictionary['patient_name'])
					#Patient Gender
					else:
						for d in att1['dependents']:
							
							if d['flipt_person_id']==rx_flipt_person_id:
								if str(d['gender']) == 'M':
									checkbox_dictionary['gender_male'] = '/Yes'
									checkbox_dictionary['gender_female']= '/Off'
								else:
									checkbox_dictionary['gender_female'] = '/Yes'
									checkbox_dictionary['gender_male'] = '/Off'
						
								field_dictionary['patient_name'] = str(d['last_name']) +", "+ str(d['first_name'])
						#Patient Employee Check
								if str(d['person_code']) == "02":
									checkbox_dictionary['spouse_check'] = '/Yes'
									checkbox_dictionary['dependent_check'] = '/Off'
									checkbox_dictionary['employee_check'] = '/Off'
								else:
									checkbox_dictionary['dependent_check'] = '/Yes'
									checkbox_dictionary['spouse_check'] = '/Off'
									checkbox_dictionary['employee_check'] = '/Off'
								
								#Patient DOB
								patient_dob= parser.parse(d['date_of_birth'])
								patient_format_dob = str(patient_dob.month).zfill(2)+'/'+str(patient_dob.day).zfill(2)+'/'+str(patient_dob.year).zfill(2)
								field_dictionary['patient_bday'] = patient_format_dob
						
					
					
			elif att!=None and 'parent_id' not in att:
				type="Employee"
				print("Type:"+type)
				person=N1QLQuery('select b.ins_carrier from `'+os.environ['CB_INSTANCE']+'` b where type="flipt_person_hierarchy" and dep_flipt_person_id=$fliptpid', fliptpid = flipt_person_id)
				person.adhoc = False
				person.timeout = 100
				#print(person)
				
				for personrow in cb.n1ql_query(person):
					realuser=True
					#print (personrow)
					for carrierdetails in personrow['ins_carrier']:
						field_dictionary['member_number'] = 'W'+str(carrierdetails['ins_carrier_member_id'])
						field_dictionary['group_number'] = str(carrierdetails['group_number'])
					
				if not realuser: continue
				#If the Patient is Employee
				#EmployeeName
				field_dictionary['employee_name'] = str(att['first_name'])+" "+str(att['last_name'])
					
				#Employee DOB
				t= parser.parse(att['date_of_birth'])
				formatteddt = str(t.month).zfill(2)+'/'+str(t.day).zfill(2)+'/'+str(t.year).zfill(2)
				field_dictionary['employee_bday'] = formatteddt
						
				#EmployeeAddress
				if str(att['home_address_2'])!='':
					field_dictionary['employee_address'] = str(att['home_address_1'])+','+str(att['home_address_2'])+','+str(att['city'])+','+str(att['state'])+','+str(att['zip'])
				else:
					field_dictionary['employee_address'] = str(att['home_address_1'])+','+str(att['city'])+','+str(att['state'])+','+str(att['zip'])
							
				#CompanyAddress		
				companydetails =N1QLQuery('select companylegalname,address1,city,state,zip from `'+os.environ['CB_INSTANCE']+'` where type="domain" and domain = $dn',dn = domain)
				companydetails.adhoc = False
				companydetails.timeout = 100
							
				for cdetails in cb.n1ql_query(companydetails):
					#print("CDETAILS ",cdetails)
					field_dictionary['employee_comp_address'] = str(cdetails['companylegalname'])+','+str(cdetails['address1'])+','+str(cdetails['city'])+','+str(cdetails['state'])+','+str(cdetails['zip'])
						
				#Employee Telephone Number
				carrier_phnumbers = ""
				carrier_telcode = "" 
				if 'communication_option_phone' in att:
					field_dictionary['emp_tel_code']=str(att['communication_option_phone'][:3])
					field_dictionary['emp_tel_number']= str(att['communication_option_phone'][3:])
				elif 'carrier_phonenumbers' in att:
					if len(att['carrier_phonenumbers'])>0:
						carrier_telcode = str(att['carrier_phonenumbers'][0])
						carrier_phnumbers = str(att['carrier_phonenumbers'][0])
						field_dictionary['emp_tel_code']= carrier_telcode[:3]
						field_dictionary['emp_tel_number']= carrier_phnumbers[3:]
				
				#FormDate
				formdate=parser.parse(prescriptionrow['filled_date'])
				field_dictionary['form_date'] = str(formdate.month).zfill(2)+'/'+str(formdate.day).zfill(2)+'/'+str(formdate.year).zfill(2)
						
				#If Prescription For Employee: 
					
				if flipt_person_id == rx_flipt_person_id:
					#print("In if condition:Means EMployee prescription Section")
					#PatientName
					field_dictionary['patient_name'] = str(att['last_name']) +", "+ str(att['first_name'])
					#print("PatientName:",field_dictionary['patient_name'])
					#Patient Gender	
					if str(att['gender']) == 'M':
						checkbox_dictionary['gender_male'] = '/Yes'
						checkbox_dictionary['gender_female']= '/Off'
					else:
						checkbox_dictionary['gender_female'] = '/Yes'
						checkbox_dictionary['gender_male'] = '/Off'
					#Patient Employee Check
					checkbox_dictionary['employee_check'] = '/Yes'
					checkbox_dictionary['spouse_check'] = '/Off'
					checkbox_dictionary['dependent_check'] = '/Off'
					#Patient DOB
					field_dictionary['patient_bday'] = formatteddt
						
				#If Prescription created by Employee for dependent
				elif flipt_person_id != rx_flipt_person_id:
						#print("In else condition:Means dependent prescription Section")
						for dep in att['dependents']:
							dep_flipt_id = str(dep['flipt_person_id'])
							#print("Dependent flipt_Person_ID:",dep_flipt_id)
							if dep_flipt_id == rx_flipt_person_id:
								#PatientName
								
								field_dictionary['patient_name'] = str(dep['last_name']) +", "+ str(dep['first_name'])
								#print("PatientName:",field_dictionary['patient_name'])
								#Patient Gender
								if str(dep['gender']) == 'M':
									checkbox_dictionary['gender_male'] = '/Yes'
									checkbox_dictionary['gender_female']= '/Off'
								else:
									checkbox_dictionary['gender_female'] = '/Yes'
									checkbox_dictionary['gender_male'] = '/Off'
								#Patient Employee Check
								if str(dep['person_code']) == "02":
									checkbox_dictionary['spouse_check'] = '/Yes'
									checkbox_dictionary['dependent_check'] = '/Off'
									checkbox_dictionary['employee_check'] = '/Off'
								else:
									checkbox_dictionary['dependent_check'] = '/Yes'
									checkbox_dictionary['spouse_check'] = '/Off'
									checkbox_dictionary['employee_check'] = '/Off'
								#Patient DOB
								patient_dob= parser.parse(dep['date_of_birth'])
								patient_format_dob = str(patient_dob.month).zfill(2)+'/'+str(patient_dob.day).zfill(2)+'/'+str(patient_dob.year).zfill(2)
								field_dictionary['patient_bday'] = patient_format_dob						
							else:
								continue
								#print("Else")
					#Write into Aetna Claim Form			
			else:
				print("No Att in  truevault")
				
			#print("FieldDictionary:",field_dictionary)
			pdf2.addPage(pdf.getPage(0))
			#print("After AddPage")
			pdf2.updatePageFormFieldValues(pdf2.getPage(0), field_dictionary)
			updateCheckboxValues(pdf2.getPage(0), checkbox_dictionary)
			# Write to pdf file
			with open(localpath+'AetnaClaimForm_'+str(flipt_person_id)+'_'+str(displaydate)+'_'+str(reccount)+'.pdf', "wb") as outputStream:
				pdf2.write(outputStream)
			#Write to Zip File
			zip.write(localpath+'AetnaClaimForm_'+str(flipt_person_id)+'_'+str(displaydate)+'_'+str(reccount)+'.pdf',arcname='AetnaClaimForm_'+str(flipt_person_id)+'_'+str(displaydate)+'_'+str(reccount)+'.pdf')
			cb.mutate_in(prescriptionrow['prescription_id'],SD.upsert('claimform_extracted_date',str(currentdate)))
			
			#email_log('noreply@fliptrx.com','deepthi.gollapudi@nttdata.com','deepthi.gollapudi@nttdata.com','Aetna Claim Form creation - Completed ',['Processing of Routed Aetna Claim Form ','Aetna Claim Form Exception'],localpath+'AetnaClaimForm_'+str(flipt_person_id)+'_'+str(reccount)+'.pdf',True)
			reccount=reccount+1
			
		except Exception as e:
			print(e)
			print(prescriptionrow)

'''
def get_all_file_paths(directory): 
  
    # initializing empty file paths list 
    file_paths = [] 
  
    # crawling through directory and subdirectories 
    for root, directories, files in os.walk(directory): 
        for filename in files: 
            # join the two strings in order to form the full filepath. 
            filepath = os.path.join(root, filename) 
            file_paths.append(filepath) 
  
    # returning all file paths 
    return file_paths         
 			

  
# calling function to get all file paths in the directory 
file_paths = get_all_file_paths(localpath) 

# printing the list of all files to be zipped 
#print('Following files will be zipped:') 
#for file_name in file_paths: 
	#print(file_name) 

# writing files to a zipfile 
with ZipFile(localpath+'claim_files.zip','w') as zip: 
	# writing each file one by one 
	matching = [files for files in file_paths if "20180920" in files] 
	#if any("20180920" in files for files in file_paths):
	for filenames in matching:
			print(filenames)
			zip.write(filenames) 

print('All files zipped successfully!') 			
email_log('noreply@fliptrx.com','deepthi.gollapudi@nttdata.com',None,'Aetna Claim Form creation - Completed ',['Processing of Routed Aetna Claim Form ','Aetna Claim Form Exception'],localpath+'claim_files.zip',True)
'''
#email_log('noreply@fliptrx.com','dwagle@fliptrx.com','deepthi.gollapudi@nttdata.com','Aetna Claim Form creation - Completed ',['Processing of Routed Aetna Claim Form ','Aetna Claim Form Exception'],localpath+'aetna_claim_files_'+displaydate+'.zip',True)
if os.environ['INSTANCE_TYPE']=='PROD':
	email_log_custombody('noreply@fliptrx.com','dwagle@fliptrx.com','deepthi.gollapudi@nttdata.com,JGRAHAM@fliptrx.com,JPowell@fliptrx.com,ASerrano@fliptrx.com,reports@fliptrx.com',' Pre-Filled Aetna Claim Forms ','Hello, \n Attaching the Aetna Claim Forms for today. \n \n Thank You, \n FLIPT Integration Team',localpath+'aetna_claim_files_'+displaydate+'.zip',True)
else:
	email_log_custombody('noreply@fliptrx.com','dwagle@fliptrx.com','deepthi.gollapudi@nttdata.com',' Pre-Filled Aetna Claim Forms ','Hello, \n Attaching the Aetna Claim Forms for today.  \n \n Thank You, \n FLIPT Integration Team',localpath+'aetna_claim_files_'+displaydate+'.zip',True)
req.no_rec_received=reccount
req.close()
	
		
'''
JGRAHAM@fliptrx.com
JPowell@fliptrx.com
ASerrano@fliptrx.com
reports@fliptrx.com
'''
