if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
   sys.path.append(rootdir)
# it will changed based on OS
rootdir = rootdir.replace('\\', '/')
path = rootdir + os.environ['CB_DATA']

import json
import sys
import os
from datetime import datetime
import shutil
from pathlib import Path

import pandas as pd
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
import couchbase.subdocument as SD
from couchbase import FMT_JSON

from utils import commandline
from utils.sendgridemail import email_log
from utils.FliptConcurrent import concurrent
 
print('Update Began',datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())
domain_name,file_type,file_name,mode=commandline.main(sys.argv[1:])
req=concurrent(sys.argv[0],sys.argv[1:])
cluster = Cluster(os.environ['CB_URL'])
bucket_name=os.environ['CB_INSTANCE']
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(bucket_name)

query=N1QLQuery('Select accumulate_flipt_deductible from `'+bucket_name+'` where type="domain" and domain=$dn',dn=domain_name)
query.adhoc=False
for res in cb.n1ql_query(query):
	if res['accumulate_flipt_deductible']=='N':
		print('Update Stopped (Flag set to NO)',datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())
		exit()
log=pd.DataFrame()
query=N1QLQuery('Select ifnull(sum(tonumber(employee_opc)),0) as cost,rx_flipt_person_id from `'+bucket_name+'` where type="prescription" and rx_status="Filled" and tostring(DATE_PART_STR(filled_date, "year"))= $py and drug_deductible_exempt="false" and rx_flipt_person_id in (Select raw c.dep_flipt_person_id from `'+bucket_name+'` c where c.type="flipt_person_hierarchy" and c.domain_name=$dn) group by rx_flipt_person_id',dn=domain_name,py=str(datetime.now().strftime("%Y")))
query.adhoc=False
for r in cb.n1ql_query(query):
	try:
		deductibleexemptaccrued=0
		innerquery=N1QLQuery('Select ifnull(sum(tonumber(employee_opc)),0) as cost from `'+bucket_name+'` where type="prescription" and rx_status="Filled" and tostring(DATE_PART_STR(filled_date, "year"))= $py and drug_deductible_exempt="true" and rx_flipt_person_id in (Select raw c.dep_flipt_person_id from `'+bucket_name+'` c where c.type="flipt_person_hierarchy" and c.domain_name=$dn) and rx_flipt_person_id=$rxid group by rx_flipt_person_id',dn=domain_name,py=str(datetime.now().strftime("%Y")),rxid=r['rx_flipt_person_id'])
		innerquery.adhoc=False
		for innerr in cb.n1ql_query(innerquery):
			deductibleexemptaccrued=innerr['cost']
		query1=N1QLQuery('Select *,meta().id as id from `'+bucket_name+'` where type="deductible" and dep_flipt_person_id=$fid and plan_year=$yr',dn=domain_name,fid=r['rx_flipt_person_id'],yr=str(datetime.now().strftime("%Y")))
		recordfound=False
		query1.adhoc=False
		for res in cb.n1ql_query(query1):
			recordfound=True
			result=dict(res[bucket_name])
			out_of_pocket_accrued="{0:.2f}".format(float(result['carrier_out_of_pocket_accrued'])+float(r['cost'])+float(deductibleexemptaccrued))
			deductible_accrued="{0:.2f}".format(float(result['carrier_deductible_accrued'])+float(r['cost']))
			if out_of_pocket_accrued!=result['out_of_pocket_accrued'] or deductible_accrued!=result['deductible_accrued']:
				log=log.append({'Previous Out of Pocket Accrued':result['out_of_pocket_accrued'],'Updated Out of Pocket Accrued':out_of_pocket_accrued,'Previous Deductible Accrued':result['deductible_accrued'],'Updated Deductible Accrued':deductible_accrued,'Employee Flipt Person ID':result['emp_flipt_person_id'],'Dependent Flipt Person ID':result['dep_flipt_person_id'],'Flipt Accrued Amount':r['cost'],'Update/Insert':'Update'},ignore_index=True)
				result['out_of_pocket_accrued']=out_of_pocket_accrued
				result['deductible_accrued']=deductible_accrued
				if mode.upper().strip()=='FINAL':
					cb.mutate_in(str(res['id']),SD.upsert('out_of_pocket_accrued',str(result['out_of_pocket_accrued'])))
					cb.mutate_in(str(res['id']),SD.upsert('deductible_accrued',str(result['deductible_accrued'])))
		if not recordfound and float(r['cost'])!=0:
			result={}
			result['deductible_accrued']="{0:.2f}".format(float(r['cost']))
			result['carrier_deductible_accrued']="0"
			result['out_of_pocket_accrued']="{0:.2f}".format(float(r['cost']))
			result['carrier_out_of_pocket_accrued']="0"
			result['previous_deductible_sent']="0"
			result['previous_opc_sent']="0"
			result['created_date']=datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat()
			result['updated_date']=datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat()
			result['data_extracted_date']=datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat()
			result['domain_name']=domain_name
			result['type']='deductible'
			query1=N1QLQuery('Select ins_carrier,emp_flipt_person_id from `'+bucket_name+'` where type="flipt_person_hierarchy" and dep_flipt_person_id=$fid and domain_name=$dn',fid=r['rx_flipt_person_id'],dn=domain_name)
			for res in cb.n1ql_query(query1):
				for c in res['ins_carrier']:
					if c['ins_carrier_name']=='Aetna':
						result['coverage_tier']=c['coverage_tier_name']
						result['plan_name']=c['benefit_plan_name']
				result['plan_year']=str(datetime.now().strftime("%Y"))
				result['status']='S'
				result['message']='Person Found Successfully'
				result['emp_flipt_person_id']=res['emp_flipt_person_id']
				result['dep_flipt_person_id']=r['rx_flipt_person_id']
				if mode.upper().strip()=='FINAL':
					cb.upsert(str(cb.counter('docid',delta=1).value),result, format=FMT_JSON)
				log=log.append({'Previous Out of Pocket Accrued':0,'Updated Out of Pocket Accrued':result['out_of_pocket_accrued'],'Previous Deductible Accrued':0,'Updated Deductible Accrued':result['deductible_accrued'],'Employee Flipt Person ID':result['emp_flipt_person_id'],'Dependent Flipt Person ID':result['dep_flipt_person_id'],'Flipt Accrued Amount':r['cost'],'Update/Insert':'Insert'},ignore_index=True)
	except Exception as e:
		print(r)
				

logpath=path+'/'+domain_name+'/'+file_type+'/log/dailydeductibleupdatelog'+str(datetime.now())+'.xlsx'
writer=pd.ExcelWriter(logpath)
log.to_excel(writer,index=False)
req.no_rec_received=len(log)
writer.save()
email_log('noreply@fliptrx.com','FliptIntegration@fliptrx.com','deepthi.gollapudi@nttdata.com,dwagle@fliptrx.com','Flipt Daily Deductible/OutOfPocket Update - Completed',['Deductible/OutOfPocket update','‘Deductible Exception’'],logpath)
print('Update Ends',datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())
req.close()
#if logpath in os.listdir(path+'/'+domain_name+'/'+file_type+'/log/'):
#	os.unlink(logpath)        

