if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
   sys.path.append(rootdir)

# it will changed based on OS
rootdir = rootdir.replace('\\', '/')
path = rootdir + os.environ['CB_DATA']
 
import json
import base64
import pprint
import shutil
import os
import sys
import paramiko
import time
from datetime import datetime
from datetime import timedelta
import dateutil.parser as parser

import pandas as pd
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from couchbase import FMT_JSON

from utils import commandline
from utils.sendgridemail import email_log
from utils.truevault import User_Class
from sclaimintegration.scriptclaimsftp import sftptransfer
from sclaimintegration.scriptclaimsftp import fileexists

#python rxclaimhistoryV2.py -d GWLABS001 -t rx_claim_history -f rx_claim_history_july -m FINAL

cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
# path = os.environ['CB_DATA']
domain,file_type,file_name,mode = commandline.main(sys.argv[1:])
currentdate = datetime.now()
currentdate = currentdate.isoformat()
remotepath = '/cp_drug_price/'+file_name+'.xlsx'
localpath = path+'/'+domain+'/'+file_type+'/'+file_name+'.xlsx'
log = path+'/'+domain+'/'+file_type+'/log/'+file_name+str(currentdate)+'.txt'
err = path+'/'+domain+'/'+file_type+'/log/'+file_name+str(currentdate)+'err.csv'
archivefile = path+'/'+domain+'/'+file_type+'/archive/'+file_name+str(currentdate)+'.xlsx'
transferstatus = ''
loadtype = 'I'
updatecount = 0
def rxclaimhistory():
	
	logfile = open(log,"w")
	errors=pd.DataFrame()
	#errorfile = open(err,"w")
	#errorfile.write("================== Rx Claim History Error File ===================="+"\r\n")
	logfile.write("================== Rx Claim History Log File ===================="+"\r\n")

	email_log('ASriperambuduru@GWLabs.com','dwagle@fliptrx.com','SSubramani@GWLabs.com','Rx Claim History -Initiated',['Processing of Rx Claim History files '],None,False)
	rxfile=pd.read_excel(localpath)
	rxfile.fillna("",inplace=True)
	rxfile.drop_duplicates(inplace=True)

	rx_cols = {'rx_claim_id':'rx_claim_id','prescription_nbr':'prescription_nbr','ee_id':'employee_ssn','ee_last_name':'employee_last_name','ee_first_name':'employee_first_name','subs_zip_cd':'employee_zip','ssn_nbr':'rx_person_ssn','last_name':'rx_person_last_name','first_name':'rx_person_first_name','clm_status':'cliam_status','sort_name':'prescriber_name','prescriber_id':'prescriber_id','spclty_ctg_cd':'prescriber_speciality_category_code','nabp_nbr':'nabp_nbr','process_dt':'cliam_processed_date','disp_dt':'dispensed_date','ndc_cd':'ndc_code','label_nm':'label_name','generic_cd':'brandorgeneric','unts_dispensed_qty':'units_dispensed_qty','days_supply_cnt':'days_of_supply','sub_ing_cost_amt':'sub_ing_cost_amt','prof_fee_amt':'dispensing_fee_amt','awp_amt':'awp_amt','sales_tax_amt':'sales_tax_amt','app_to_per_ded_amt':'app_to_per_ded_amt','srv_copay_amt':'srv_copay_amt','paid_amt':'paid_amt','ahf_paid_amt':'ahf_paid_amt','ahf_bfd_amt':'ahf_bfd_amt','bnft_plan_paid_amt':'bnft_plan_paid_amt','phi_acas_bypass_cd':'phi_acas_bypass_cd','price_type_cd':'price_type_cd','calc_ing_cost_amt':'calc_ing_cost_amt','prescbr_id_qlfy_cd':'prescbr_id_qlfy_cd','prod_distnctn_cd':'prod_distnctn_cd'}
	rxfile.rename(columns=rx_cols,inplace=True)
	rx_cols=list(rxfile)
	#print(rx_cols)
	logfile.write("************ Rx Claim History Record Processing ********** "+"\r\n")
	unitp = ''
	for index,rxrow in rxfile.iterrows():
		flipt_person_id = ''
		emp_flipt_person_id =''
		rxrecs = {}
		#if 'SUPREP' not in rxrow['label_name']: continue
		for rxcols in rx_cols:
			if rxcols in ['employee_ssn','employee_last_name','employee_first_name','employee_zip','rx_person_ssn','rx_person_last_name','rx_person_first_name']:			continue
			elif 'amt' in rxcols:
				rxrecs[rxcols]=str(rxrow[rxcols]/100)
				continue
			elif rxcols=='units_dispensed_qty':
				rxrecs[rxcols]=str(rxrow[rxcols]/1000.0)
				continue
			rxrecs[rxcols]=str(rxrow[rxcols])	
		rxrecs['create_date'] = currentdate
		rxrecs['update_date'] = currentdate
		rxrecs['created_by'] = 'Administrator'
		rxrecs['updated_by'] = 'Administrator'			
		rxrecs['type'] = 'rx_claim_history'
		rv1=cb.counter('docid',delta=1)
		rxrecs['rx_id']=str(rv1.value)
		
	
		rx_person_ssn = str(rxrow['rx_person_ssn']).strip()
		rx_person_ssn = 'xxx-xx-'+rx_person_ssn[-4:]
		rx_person_last_name = rxrow['rx_person_last_name'].strip()
		rx_person_first_name = rxrow['rx_person_first_name'].strip()
		employee_ssn = str(rxrow['employee_ssn']).strip()
		emp_masked_ssn = 'xxx-xx-'+employee_ssn[-4:]
		employee_last_name = rxrow['employee_last_name'].strip()
		employee_first_name = rxrow['employee_first_name'].strip()
		ndc_code = str(rxrow['ndc_code']).strip()
		cliam_processed_date = rxrow['cliam_processed_date']
		filled_dt = datetime.strptime(str(cliam_processed_date),'%Y-%m-%d %H:%M:%S')
		filled_iso = filled_dt.isoformat()
		daysofsupply = rxrow['days_of_supply']
		#filled_dt = cliam_processed_date		
		#print(emp_masked_ssn+':'+rx_person_ssn)
		
		obj=User_Class(None,None)	
		search_option={'full_document':True,'filter':{'employee_ssn':{'type':'eq','value':emp_masked_ssn,'case_sensitive':False},'domain_name':{'type':'eq','value':domain,'case_sensitive':False},'first_name':{'type':'eq','value':employee_first_name,'case_sensitive':False},'last_name':{'type':'eq','value':employee_last_name,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
		att,userid=obj.search_user(search_option)
		if att!=None:
			emp_flipt_person_id = att['flipt_person_id']
			if emp_masked_ssn == rx_person_ssn:
				flipt_person_id = att['flipt_person_id']
			else:
				for dep in att['dependents']:
					if str(dep['dependent_ssn']).strip() == rx_person_ssn:
						flipt_person_id = dep['flipt_person_id']
		

		#print(flipt_person_id)
		rxrecs['flipt_person_id'] = emp_flipt_person_id
		rxrecs['rx_flipt_person_id'] = flipt_person_id
		if mode.upper() == 'FINAL':
			cb.upsert(str(rxrecs['rx_id']),rxrecs)
			logfile.write("Upsert Successful ... "+"\n")		
		
		
		
		if flipt_person_id != None:

			ndctab = N1QLQuery('select gpi, dosage, dosage_strength, ddid, package_qty, package_size, gppc,brand_generic,drug_name,package_quantity,custom_qty from `'+os.environ['CB_INSTANCE']+'` Where type = "ndc_drugs" and ndc = $ndc limit 1',ndc = ndc_code)
			ndctab.adhoc = False
			ndctab.timeout = 100	
			for ndcrow in cb.n1ql_query(ndctab):
				gpi = ndcrow['gpi']
				dosage_strength = ndcrow['dosage_strength']
				dosage = ndcrow['dosage']
				ddid = ndcrow['ddid']
				package_qty = ndcrow['package_qty']
				package_size = ndcrow['package_size']
				gppc = ndcrow['gppc']
				brand_generic = ndcrow['brand_generic']
				drug_name = ndcrow['drug_name'].strip()
				quantity = ndcrow['package_quantity']
				custom_qty=ndcrow['custom_qty']
				if custom_qty=='package_quantity':
					quantity="{0:.1f}".format(float(rxrecs['units_dispensed_qty'])/float(ndcrow['package_size']))
				quantitydf=pd.DataFrame()
				rxcui='nan'
				rxcuitab = N1QLQuery('select rxcui,quantity from `'+os.environ['CB_INSTANCE']+'` Where type = "drug" and drug_name = $drug and brand_generic = $brand and gpi = $gpicode and dosage=$ds limit 1',drug = drug_name, brand = brand_generic, gpicode = gpi, ds=dosage)
				rxcuitab.adhoc = False
				rxcuitab.timeout = 100
				for rxcuirow in cb.n1ql_query(rxcuitab):
					rxcui = rxcuirow['rxcui']
					for r in rxcuirow['quantity']:
						quantitydf=quantitydf.append(r,ignore_index=True)
				#quantity manipulation
				try:
					if custom_qty=='package_size':
						package_size=rxrecs['units_dispensed_qty']
						if str(rxrecs['units_dispensed_qty']) in list(quantitydf['package_size']):
							package_qty=quantitydf.loc[quantitydf['package_size']==str("{0:.1f}".format(float(rxrecs['units_dispensed_qty']))),'package_qty'].values[0]
						else:
							found=False
							quantitydf['package_size']=quantitydf['package_size'].apply(lambda x:float(x))
							quantitydf.sort_values(by=['package_size'],ascending=[True],inplace=True)
							for ind,row in quantitydf.iterrows():
								if float(rxrecs['units_dispensed_qty'])<row['package_size']:
									package_qty=row['package_qty']
									found=True
									break
							if not found:
								package_qty=max(list(quantitydf['package_size']))
							#print(index,rxrecs['units_dispensed_qty'],package_qty,'changed')
							errors=errors.append({'Drug Name':drug_name,'GPI':gpi,'Brand Generic':brand_generic,'Units Dispensed Qty':rxrecs['units_dispensed_qty'],'Changed Quantity':package_qty,'Error':'Manipulated qty'},ignore_index=True)
					rxrec = dict()
					load_type = 'insert'
					startdate = ''
					historytab = N1QLQuery('select meta().id as history_id,start_date from `'+os.environ['CB_INSTANCE']+'` Where type = "rx_history" and drug_name = $drug and brandorgeneric = $brand and gpi = $gpicode and dosage_strength = $dosage and form = $form and flipt_person_id = rx_flipt_id',drug = drug_name, brand = brand_generic, dosage = dosage_strength, form = dosage, rx_flipt_id = flipt_person_id,gpicode = gpi)
					historytab.adhoc = False
					historytab.timeout = 100
					for historyrow in cb.n1ql_query(historytab):
						history_id = historyrow['history_id']								
						load_type = 'update'
						rxrec['type'] = 'rx_history'
						startdate=historyrow['start_date']
					
					if load_type == 'insert':
						rv1=cb.counter('docid',delta=1)
						rx_id= 'rx_history::'+str(rv1.value)
						rxrec['type'] = 'rx_history'
					else:
						rx_id= history_id
						if startdate>filled_iso: continue
					'''
					else:
						continue	
					'''
					rxrec['domain'] = domain
					rxrec['rxcui'] = rxcui
					#rxrec['type'] = 'rx_history_stg'
					rxrec['flipt_person_id'] = flipt_person_id
					rxrec['ddid'] = ddid
					rxrec['drug_name'] = drug_name
					rxrec['gpi'] = gpi
					rxrec['brandorgeneric'] = brand_generic
					rxrec['form'] = dosage
					rxrec['custom_qty'] = custom_qty
					rxrec['dosage_strength'] = dosage_strength
					rxrec['quantity'] = str(quantity)
					rxrec['package_qty'] = str(package_qty)
					rxrec['package_size'] = str(package_size)
					rxrec['start_date'] = filled_iso
					rxrec['daysofsupply'] = str(daysofsupply)								
					filled_dt = filled_dt + timedelta(days= int(daysofsupply))
					rxrec['estimated_stop_date'] = str(filled_dt)
					rxrec['currently_taking_flag'] = 'Y'
					rxrec['created_date'] = filled_iso
					rxrec['updated_date'] = currentdate
					rxrec['created_by'] = flipt_person_id
					rxrec['last_udpated_by'] = flipt_person_id
					
					if mode == 'FINAL':
						cb.upsert(rx_id, rxrec,format=FMT_JSON)
						#print(rx_id)
				except Exception as e:
					print(e)
					continue
	
	errors.to_csv(err,index=False)	
	subject = 'RX Claim History File Processed'
	email_log('ASriperambuduru@GWLabs.com','dwagle@fliptrx.com','SSubramani@GWLabs.com',subject,['Processing of Rx Claim File '+file_name+str(currentdate),'Rx Claim Exception'],log,True)
	subject = 'RX Claim History Error File'
	email_log('ASriperambuduru@GWLabs.com','dwagle@fliptrx.com','SSubramani@GWLabs.com',subject,['Processing of Rx Claim History File '+file_name+str(currentdate)+err,'Rx Claim History Exception'],err,True)		
	#shutil.move(localpath, archivefile)
	
	
			
rxclaimhistory()

