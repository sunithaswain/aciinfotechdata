########################################
# !/usr/bin/env python 

# title : scnewdrugsupdate.py
# description : Update drug database -(update brand generic of cp drug price)
# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  python scnewdrugsupdate.py -d GWLABS001 -t DRUG_DATABASE -f Medispan20181212.csv -m draft
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
   sys.path.append(rootdir)

# it will changed based on OS
rootdir = rootdir.replace('\\', '/')
path = rootdir + os.environ['CB_DATA']

import os, sys, json, re
from datetime import datetime
import pprint
import urllib.request as urllib2
import urllib.error

import pandas as pd
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from couchbase import FMT_JSON
import couchbase.subdocument as SD

from utils.sendgridemail import email_log
from utils import commandline as commandline

cluster = Cluster(os.environ['CB_URL'])
bucket_name=os.environ['CB_INSTANCE']
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(bucket_name)

def customizedchanges():
	
    cb.n1ql_query(N1QLQuery("update `"+os.environ['CB_INSTANCE']+"` set dosage='SOLUTION FOR EARS' where type='drug' and gpi='87100060002010'")).execute()
    cb.n1ql_query(N1QLQuery("update `"+os.environ['CB_INSTANCE']+"` set dosage='SOLUTION FOR EYES' where type='drug' and gpi='86101047002020'")).execute()
    cquery=N1QLQuery("update `"+os.environ['CB_INSTANCE']+"` set generic_rank='999' where type = 'drug' and generic_rank in ['nan','00000000000nan']")
    cquery.timeout=3600
    cb.n1ql_query(cquery).execute()
    cquery=N1QLQuery("update `"+os.environ['CB_INSTANCE']+"` set generic_rank='1' where type = 'drug' and generic_rank in ['1.0','000000000001.0']")
    cquery.timeout=3600
    cb.n1ql_query(cquery).execute()
    cquery=N1QLQuery("update `"+os.environ['CB_INSTANCE']+"` set i.display_rank='999' for i in ARRAY_FLATTEN(quantity,1) WHEN i.display_rank='nan' END where type='drug'")
    cquery.timeout=3600
    cb.n1ql_query(cquery).execute()
	
def changebg(txt):
    return txt.strip().replace('B','Brand').replace('T','Brand').replace('G','Generic')

def findimgname(form,pkgdesc,compareq):
	try:
		imgquery=N1QLQuery("Select dosage_image,quantity from `"+bucket_name+"` where type='drug_images' and form=$form and package_desc=$pdesc limit 1",form=form,pdesc=pkgdesc)
		imgquery.adhoc=False
		imgquery.timeout=3600
		dimg,qimg='',''
		for r in cb.n1ql_query(imgquery):
			dimg=r['dosage_image']
			qimg=r['dosage_image']
			quantitylist=r['quantity']
			for i in quantitylist:
				if i['min']!="" and i['max']!="":
					if float(i['min'])<=float(compareq) and float(i['max'])>=float(compareq):
						qimg=i['quantity_image']
						break
				elif i['min']=="" and i['max']!="":
					if float(i['max'])>=float(compareq):
						qimg=i['quantity_image']
				elif i['max']=="" and i['min']!="":
					if float(i['min'])<=float(compareq):
						qimg=i['quantity_image']
						break
		return dimg,qimg
	except Exception as e:
		print(form,pkgdesc,compareq)
		return "",""
        
    	
def update(pfile_name):
    #email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','SSubramani@GWLabs.com','DrugDatabase(ScriptClaim) Updated - Initiated',['Processing of DrugDatabase (ScriptClaim) file '+file_name+' (cp_drug_price.csv)'],None,False)
    f=open(path+'/'+file_type+'/log/sclog.txt','w')
    f.write('----Drug Database(ScriptClaim) Update----\n')
    f.write(str(datetime.now())+'\n')
      
    query=N1QLQuery('Select gpi,drug_name,brand_generic,meta().id id,dosage from `'+bucket_name+'` where type="drug"')
    drugdf=pd.DataFrame()
    query.timeout=2700
    for r in cb.n1ql_query(query):
        drugdf=drugdf.append(r,ignore_index=True)
    query=N1QLQuery('Select distinct gpi,drug_name,brandorgeneric from `'+bucket_name+'` where type="cp_drug_price"')
    scdf=pd.DataFrame()
    query.timeout=2700
    for r in cb.n1ql_query(query):
        scdf=scdf.append(r,ignore_index=True)
    
    specialty=pd.read_excel(path+'//'+file_type+'//AmberList20180524.xlsx')    
    full_filepath = path+'//'+file_type+'//'+pfile_name
    ms=pd.read_csv(full_filepath)
    # newdrugs=pd.DataFrame()

    # modified by Hari on 27/12/2018
    # ms.columns = [x.lower().strip() for x in ms.columns]
    # ms.drop(['multi_source'],axis=1,inplace=True)
    # ms.drop_duplicates(inplace=True)
    # ms['package_qty'] = [str(x).replace('\r','') for x in ms['package_qty']]
    # ms['gpi'] = [str(x).zfill(14) for x in ms['gpi']]
    # ms['gppc'] = [str(x).zfill(8) for x in ms['gppc']]
    # ms[['generic_rank', 'ddid']]=ms[['generic_rank', 'ddid']].astype(str)
    # digit_pattern = r"[-+]?\d*\.\d+|\d+"
    # ms['strengthnum'] = [float(re.findall(digit_pattern, x)[0])*1000 if 'MG' in x else float(re.findall(digit_pattern, x)[0])/1000 if 'MCG' in x else float(re.findall('[-+]?\d*\.\d+|\d+', x)[0]) if re.findall('[-+]?\d*\.\d+|\d+', x) else float(0.0) for x in ms['strengths'] ]
    # ms.loc[ms.custom_qty != 'package_size', 'strengthnum'] = 0.0
    
    # ms=pd.read_csv(path+'//'+file_type+'//'+filename)
    changedcols={}
    for c in list(ms):
        changedcols[c]=c.lower().replace(' ','_')
    ms.rename(columns=changedcols,inplace=True)
    ms.drop(['multi_source'],axis=1,inplace=True)
    ms.drop_duplicates(inplace=True)
    ms['package_qty']=ms['package_qty'].apply(lambda x: str(x).replace('\r',''))
    ms['gpi']=ms['gpi'].apply(lambda x: str(x).zfill(14))
    ms['gppc']=ms['gppc'].apply(lambda x: str(x).zfill(8))
    ms['generic_rank']=ms['generic_rank'].apply(lambda x: str(x))	
    ms['ddid']=ms['ddid'].apply(lambda x: str(x))
    ms['strengthnum']=""
    specialty['GPICode']=specialty['GPICode'].apply(lambda x: str(x).replace('.0','').zfill(14))
    for i,r in ms.iterrows():
        if r['custom_qty']!='package_size': continue
        if r['strengths']!=' ':
            try:
                strength=float(re.findall(r"[-+]?\d*\.\d+|\d+", r['strengths'])[0])
                #if '/' not in r['strengths'] and '-' not in r['strengths'] and 'X' not in r['strengths']
                if 'GM' in r['strengths']: strength=strength*1000
                elif 'MCG' in r['strengths']: strength=strength/1000
                ms.loc[i,'strengthnum']=strength
            except Exception as e:
                ms.loc[i,'strengthnum']=r['strengths']
        else: ms.loc[i,'strengthnum']=0.0
    
    #print(ms.loc[:,['strengthnum','strengths']])
    ms['dosage_rank']="0"
    ms['dosage_image']=""
    ms['quantity_image']=""
    for k,g in ms.groupby(['drug_name','dosage']):
        dosagerank=0
        customqty="package_quantity"
        if 'package_quantity' in list(g['custom_qty']):
            g.sort_values(by=['strengths','package_size'],ascending=[True,True],inplace=True)
        else: 
            try:
                g.sort_values(by=['strengthnum'],ascending=[True],inplace=True)
            except Exception as e:
                print(g)
                #exit()
            customqty="package_size"
        ps,strnth='',''
        for i,r in g.iterrows():
            if customqty=='package_size':
                if strnth!=r['strengthnum']:
                    dosagerank=dosagerank+1
            else:
                if ps!=r['package_size'] or strnth!=r['strengths']:
                    dosagerank=dosagerank+1
                    ps=r['package_size']
                    strnth=r['strengths']
            ms.loc[i,'dosage_rank']=str(dosagerank)
            
            
    ms.drop(['strengthnum'],axis=1,inplace=True)
    #ms.to_csv('dosageorderedmedispan.csv',index=False)
    #exit()
    # drugdf['drug_name']=drugdf['drug_name'].apply(lambda x:str(x).upper().strip())
    #drugdf['brand_generic']=drugdf['brand_generic'].apply(lambda x:str(x).upper().strip())
    # scdf['drug_name']=scdf['drug_name'].apply(lambda x:str(x).upper().strip())
    drugdf['drug_name'] = drugdf['drug_name'].str.upper()
    scdf['drug_name'] = scdf['drug_name'].str.upper()
    outercols=['ddid','gpi','brand_generic','drug_name','unit_dose','strengths','dosage','generic_rank','otc_indicator']
    newcols=['lm_name','lm_form','lm_strength','drugtype','ddn_name','ddn_form','ddn_strength','lm_updated_by','ddn_updated_by','pda','ddn_update_date','lm_update_date']
    for c in newcols:
        ms[c]='nan'
    ite=-1
    listcols=list(ms)
	
    nestedcols=["dosage_strength","form","package_desc","package_qty","package_quantity","package_size","pkg_desc_cd","pkg_uom","display_rank","gppc","custom_qty","quantity_type","dosage_image","quantity_image","dosage_rank"]
    for k,g in ms.groupby(['ddid','gpi']):
        
        g.reset_index(drop=True,inplace=True)
        #if ((g.loc[0,'gpi']==scdf['gpi']) & (g.loc[0,'drug_name']==scdf['drug_name'])).any()==False:            continue
        if ((g.loc[0,'gpi']==drugdf['gpi']) & (g.loc[0,'drug_name']==drugdf['drug_name']) & (g.loc[0,'dosage']==drugdf['dosage'])).any()==True:
            f.write('-----Drug in Drug Database----\n')
            f.write('Drug Name: '+str(g.loc[0,'drug_name'])+'\n')
            f.write('GPI: '+str(g.loc[0,'gpi'])+'\n')
            f.write('Brand_Generic: '+str(g.loc[0,'brand_generic'])+'\n\n')
            bg='Brand'
            if str(g.loc[0,'brand_generic'])=='G': bg='Generic'
            docid=drugdf.loc[((g.loc[0,'gpi']==drugdf['gpi']) & (g.loc[0,'drug_name']==drugdf['drug_name']) & (g.loc[0,'dosage']==drugdf['dosage'])),'id'].values[0]
            for col in outercols:
                value=str(g.loc[0,col])
                if mode.upper().strip()=='FINAL':
                    try:		
                        cb.mutate_in(docid,SD.upsert(col,value))
                    except Exception as e:
                        print(col,value)
                        continue
            quantitylist=[]
            for i,r in g.iterrows():
                quant={}
                for c in nestedcols:
                    quant[c]=str(r[c]).strip().encode('utf-8').decode('utf-8')
                compareq=r['package_quantity']
                if r['custom_qty']=='package_size': compareq=r['package_size']
                quant['dosage_image'],quant['quantity_image']=findimgname(r['dosage'],quant['package_desc'],compareq)					
                quantitylist.append(quant)
            #print(quantitylist)
            if mode.upper().strip()=='FINAL':            
                cb.mutate_in(docid,SD.upsert('quantity',quantitylist))
                cb.mutate_in(docid,SD.upsert('update_date',str(datetime.now().strftime("%Y-%m-%d"))))
                cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET brandorgeneric = $b_g WHERE type = "cp_drug_price" and drug_name=$dn and gpi=$gpi and brandorgeneric=""',dn=str(g.loc[0,'drug_name']),gpi=g.loc[0,'gpi'],b_g=bg)).execute()
            continue
        print(ite)
        record=dict()
        for c in listcols:
            if c in nestedcols: continue
            record[c]=str(g.loc[0,c]).strip().encode('utf-8').decode('utf-8')
        
        #record['brand_generic']=scdf.loc[(scdf['gpi']==g.loc[0,'gpi']) & (scdf['gpi']==g.loc[0,'gpi']),'brandorgeneric'].values[0][0]
        record['quantity']=[]
        record['maintenance_drug_flag']='N'
        record['lm_ndc']=[]
        record['popularity']='0'
        record['update_date']=str(datetime.now().strftime("%Y-%m-%d"))
        record['load_date']=str(datetime.now().strftime("%Y-%m-%d"))
        for i,r in g.iterrows():
            quant={}
            for c in nestedcols:
                quant[c]=str(r[c]).strip().encode('utf-8').decode('utf-8')
            compareq=r['package_quantity']
            if r['custom_qty']=='package_size': compareq=r['package_size']
            quant['dosage_image'],quant['quantity_image']=findimgname(r['dosage'],quant['package_desc'],compareq)
            record['quantity'].append(quant)
        id1=[]
        #print(record['quantity'])
        record['rxcui']=''        
        record['specialty_flag']='N'
        if ((g.loc[0,'gpi']==specialty['GPICode']) & (g.loc[0,'drug_name']==specialty['ProductNameAbr'])).any()==True:
            record['specialty_flag']='Y'
        '''
        grp=ndcs[(ndcs['drug_name']==str(g.loc[0,'drug_name'])) & (ndcs['gpi']==g.loc[0,'gpi'])]
        for i in set(list(grp['ndc'])):
            ndc=i
            ndcstatus=urllib2.urlopen('https://rxnav.nlm.nih.gov/REST/ndcstatus.json?ndc='+ndc)
            ndcstatus=ndcstatus.read().decode('utf-8')
            ndcstatus=json.loads(ndcstatus)
            if ndcstatus['ndcStatus']['status'].upper()=='ACTIVE':
                rxid=urllib2.urlopen('https://rxnav.nlm.nih.gov/REST/rxcui.json?idtype=NDC&id='+ndc)
                d1=rxid.read().decode('utf-8')
                finaldict1=json.loads(d1)
                if ('idGroup' in finaldict1 and 'rxnormId' in finaldict1['idGroup']):
                    id1=finaldict1['idGroup']['rxnormId']
                    record['rxcui']=str(id1[0])
                    break
        '''
        record['type']='drug'
        record['equivalent']=[]
        record['lm_update_date']=str(datetime.now().strftime("%Y-%m-%d"))
        record['ddn_update_date']=str(datetime.now().strftime("%Y-%m-%d"))
        f.write('-----New Drug in Drug Database----\n')
        f.write('Drug Name: '+str(g.loc[0,'drug_name'])+'\n')
        f.write('GPI: '+str(g.loc[0,'gpi'])+'\n')
        f.write('Brand_Generic: '+str(g.loc[0,'brand_generic'])+'\n\n')
        #print(record)
        if mode.upper().strip()=='FINAL':
            cb.upsert(str(cb.counter('docid',delta=1).value),record, format=FMT_JSON)
        ite=ite+1
    
    customizedchanges()
    sender='DWagle@fliptrx.com'
    receiver=['DWagle@fliptrx.com','SSubramani@fliptrx.com']
    subject='DrugDatabase (ScriptClaim) Updated - Completed'
    body=['Processing of DrugDatabase (ScriptClaim) file '+pfile_name+' (cp_drug_price.csv)','‘DrugDatabase (ScriptClaim) Exception’']
    f.write('\n---DrugDatabase (ScriptClaim) Update Done----\n')
    f.write(str(datetime.now())+'\n')
    f.close()
    email_log(sender,receiver[0],receiver[1],subject,body,path+'/'+file_type+'/log/sclog.txt')

    if mode.strip().upper() == 'FINAL':
        if not os.path.isdir(path+'/'+file_type+'/archive/'): os.makedirs(path+'/'+file_type+'/archive/')
        os.rename(full_filepath, path+'/'+file_type+'/archive/'+pfile_name)

domain,file_type,file_name,mode=commandline.main(sys.argv[1:])
# update()
if file_name:
	print('basic calling function invoked')
	update(file_name)
else:
	print('Automate calling function invoked')
	# Automate Drug Database Load
	from autofile_transfer import multiplefilesftptransfer
	localpath = path+'/'+file_type+'/'
	remotepath = 'uploads'
	multiplefilesftptransfer(remotepath, localpath, 'FLIPT_DRUG_*', "GET")

	for file_name in os.listdir(localpath):
		print(file_name)
		print(os.path.isdir(os.path.join(localpath,file_name)))
		if file_name.startswith("FLIPT_DRUG_") and os.path.isfile(os.path.join(localpath,file_name)):
			print(file_name)
			update(file_name)