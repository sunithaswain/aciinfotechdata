########################################
# !/usr/bin/env python 

# title : drugalternateupdate.py
# description : Drug Alternate data update
# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  python drugalternateupdate.py -d GWLABS001 -t drug_alternative -f drugalt12102018.xlsx -m draft
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
   sys.path.append(rootdir)

# it will changed based on OS
rootdir = rootdir.replace('\\', '/')
path = rootdir + os.environ['CB_DATA']
 
import os
from datetime import datetime
import sys
import pprint
import pandas as pd
import socket

from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from couchbase import FMT_JSON
import couchbase.subdocument as SD

from utils.sendgridemail import email_log
import utils.commandline as commandline

# from app.common.sendgridemail import email_log
# import app.common.commandline as commandline

domain_name,file_type,filename,mode=commandline.main(sys.argv[1:])
cluster = Cluster(os.environ['CB_URL'])
bucket_name=os.environ['CB_INSTANCE']
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(bucket_name)

host = socket.gethostname()
logpath=path+'//'+file_type+'//log//'
log=pd.DataFrame()
alt=pd.read_excel(path+'//'+file_type+'//'+filename)
alt['Alternative Drug Code']=alt['Alternative Drug Code'].apply(lambda x: str(int(x)).strip())
alt['Dosage Code']=alt['Dosage Code'].apply(lambda x: str(int(x)))
#alt=alt.loc[(alt['OTC_INDICATOR']=='R')&(alt['Alternative Drug Code']!='NA')&(alt['Dosage Code']!='NA'),:]
colsneeded=['gpi','drug_name','dosage','strengths','quantity_per_day','ddid','strengths','equivalent_dosage','reward_penalty_per_unit','alternate_drug_reward_per_unit','alternate_drug_penalty_per_unit','alternative_drug_code','dosage_code']

colsdict={}
for c in list(alt):
	colsdict[c]=c.lower().replace(' ','_').replace('qty','quantity').replace('_number','')
alt.rename(columns=colsdict,inplace=True)
#print(list(alt))
alt.drop(list(set(list(alt))-set(colsneeded)),axis=1,inplace=True)
#print(list(alt))
drugcols=['gpi','drug_name','dosage','strengths','quantity_per_day','ddid']
alt.drop_duplicates(inplace=True)
#alt.groupby(['alternative_drug_code','dosage_code','equivalent_dosage'])
#print(alt)
#sys.exit()

def update():
	global log
	ite=0
	hpfmac=pd.DataFrame()
	for key,grp in alt.groupby(['alternative_drug_code','dosage_code','equivalent_dosage']):
		
		
		for i,r in grp.iterrows():
			# if not (r['alternate_drug_reward_per_unit']>0 or r['alternate_drug_penalty_per_unit']>0):
			# if not r['alternate_drug_penalty_per_unit']>0:
				# print('In condition if alternate_drug_penalty_per_unit not gt 0')
				# continue
			record={}
			record['type']='drug_alternative'
			record['update_date']=datetime.now().isoformat()
			record['alt_drug_code']=str(key[0])
			record['alt_dosage_code']=str(key[1])
			record['alt_drug_dosage_code']=str(key[0])+str(key[1])
			record['drug_class']=""
			record['equivalent_dosage']=str(key[2])
			#if r['alternate_drug_reward_per_unit']>0:	record['alternate_drug_reward_per_unit']="{0:.4f}".format(r['alternate_drug_reward_per_unit'])
			#elif r['alternate_drug_penalty_per_unit']>0:	record['alternate_drug_penalty_per_unit']="{0:.2f}".format(r['alternate_drug_penalty_per_unit'])
			#below if to be commented if above if-elif condition is to be kept
			if r['alternate_drug_penalty_per_unit']>0:	record['alternate_drug_penalty_per_unit']="{0:.2f}".format(r['alternate_drug_penalty_per_unit'])
			record['reward_penalty_per_unit']="{0:.2f}".format(r['reward_penalty_per_unit'])
			#print('Record before drugcols',record)
			for c in drugcols:
				record[c]=str(r[c]).strip()
			
			print('Record of c',record)
			drugfound=False
			restricteddrugs=[]
			query=N1QLQuery('Select brand_generic from `'+os.environ['CB_INSTANCE']+'` where type="drug" and drug_name=$dn and gpi=$gpi',dn=record['drug_name'],gpi=record['gpi'])
			print(query)
			query.adhoc=False
			query.timeout=300
			for drugrow in cb.n1ql_query(query):
				drugfound=True
				record['brand_generic']=drugrow['brand_generic']
			if not drugfound:
				log=log.append({'GPI':record['gpi'],'Drug_name':record['drug_name']},ignore_index=True)
				continue
			query=N1QLQuery('Select distinct drug_name from `'+os.environ['CB_INSTANCE']+'` where type="drug" and gpi=$gpi',gpi=record['gpi'])
			query.adhoc=False
			query.timeout=300
			for drugrow in cb.n1ql_query(query):
				restricteddrugs.append(drugrow['drug_name'])
			
			#print('RestrictedDRUGS',restricteddrugs)
			altdrugs=[]
			#loop through all drugs of the group
			print('Record before grouping',record)
			for j,row in grp.iterrows():
				#in case of same drug or another gpi of a drug already found before or the generic/brand equivalent of same drug found then continue
				#print(record)
				if (row['drug_name']==record['drug_name']) or (row['drug_name'] in restricteddrugs) or (row['drug_name'] in altdrugs):
					#print('RECORD',record)
					#print('ROW',row)
					continue
				for c in drugcols:
					record['alt_'+c]=str(row[c]).strip()
				#Just added
				#if row['alternate_drug_reward_per_unit']>0:
				record['alternate_drug_reward_per_unit']="{0:.4f}".format(row['alternate_drug_reward_per_unit'])
				print('RECORD',record)
				query=N1QLQuery('Select ddid,brand_generic from `'+os.environ['CB_INSTANCE']+'` where type="drug" and drug_name=$dn and gpi=$gpi',dn=record['alt_drug_name'],gpi=record['alt_gpi'])
				altdrugfound=False
				query.adhoc=False
				query.timeout=300
				for drugrow in cb.n1ql_query(query):
					altdrugfound=True
					record['alt_ddid']=drugrow['ddid']
					record['alt_brand_generic']=drugrow['brand_generic']
				
				if not altdrugfound:
					log=log.append({'GPI':row['gpi'],'Drug_name':row['drug_name']},ignore_index=True)
					continue
				elif (record['gpi']==record['alt_gpi'] and record['brand_generic']!=record['alt_brand_generic']): continue
				altdrugs.append(row['drug_name'])
				query=N1QLQuery('Select meta().id id,create_date from `'+os.environ['CB_INSTANCE']+'` where type="drug_alternative" and ddid=$drugddid and alt_ddid=$altddid',drugddid=record['ddid'],altddid=record['alt_ddid'])
				query.adhoc=False
				query.timeout=300
				docid=''
				insert=True
				oldrecord={}
				for row in cb.n1ql_query(query):
					insert=False
					record['create_date']=row['create_date']
					docid=row['id']
				#print(record)
				
				hpfmac=hpfmac.append(record,ignore_index=True)
				
				
				if mode.upper().strip()=='FINAL':
					print(ite)
					ite=ite+1
					if insert:
						record['create_date']=datetime.now().isoformat()
						cb.upsert(str(cb.counter('docid',delta=1).value),record)
					else:
						for k1,v1 in record.items():
							cb.mutate_in(docid,SD.upsert(k1,v1))
		
			#print(record)
		hpfmac.to_csv(logpath+"DrugAltLog"+datetime.now().isoformat()+".csv",index=False)	
		print(ite)
				
				#query=N1QLQuery('Update `'+os.environ['CB_INSTANCE']+'` set type="drug_alternative_bkp" where type="drug_alternative" and DATE_FORMAT_STR(update_date,"1111-11-11")!=clock_local("1111-11-11")')
update()
if len(log)>0: log.drop_duplicates(inplace=True)
# log.to_csv(logpath+"DrugAltLog"+datetime.now().isoformat()+".csv",index=False)
# added by Hari on 27/12/2018
if mode.strip().upper() == 'DRAFT':
	log = logpath+"/DrugAltLog_Draft"+datetime.now().isoformat()+".txt"
	logfile = open(log,"w")
	logfile.write(' Drug Alt Log - Draft Mode :'+host+filename)
	print("File run on DRAFT mode")
	subject = 'Drug Alt Log - Draft Mode :'+host
	logfile.close()
	email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','SSubramani@GWLabs.com',subject,['Drug Alt Log File '+log,'Drug Alt Log Exception'],log,True)