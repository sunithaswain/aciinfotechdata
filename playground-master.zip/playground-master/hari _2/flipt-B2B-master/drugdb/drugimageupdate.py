if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
   sys.path.append(rootdir)

# it will changed based on OS
rootdir = rootdir.replace('\\', '/')
path = rootdir + os.environ['CB_DATA']

import pandas as pd
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from couchbase import FMT_JSON
from utils import commandline
import os
from datetime import datetime
import sys
import pprint
from utils.sendgridemail import email_log
import urllib.request as urllib2
import urllib.error
import json
import re
import couchbase.subdocument as SD

domain_name,file_type,filename,mode=commandline.main(sys.argv[1:])
cluster = Cluster(os.environ['CB_URL'])
bucket_name=os.environ['CB_INSTANCE']
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(bucket_name)

df=pd.read_excel(path+'//'+file_type+'//'+filename)
df.fillna("",inplace=True)
for k,g in df.groupby(['FORM','PACKAGE_DESC']):
	di={}
	di['form']=k[0]
	di['package_desc']=k[1]
	di['quantity']=[]
	for i,r in g.iterrows():
		di['dosage_image']=r['DOSAGE_IMAGE']
		quant={}
		if r['QUANTITY_IMAGE']=="":
			quant['quantity_image']=di['dosage_image']
			quant['min']=""
			quant['max']=""
		else:
			quant['quantity_image']=r['QUANTITY_IMAGE']
			quant['min']=str(r['MIN'])
			quant['max']=str(r['MAX'])
		di['quantity'].append(quant)
		

	
	di['type']='drug_images'
	di['create_date']=datetime.now().isoformat()
	di['update_date']=datetime.now().isoformat()
	query=N1QLQuery("select meta().id id,create_date from `"+bucket_name+"` where type='drug_images' and form=$form and package_desc=$pkgdesc",form=di['form'],pkgdesc=di['package_desc'])
	query.adhoc=False
	query.timeout=3600
	docid=''
	for row in cb.n1ql_query(query):
		docid=row['id']
		di['create_date']=row['create_date']
		cb.upsert(docid,di)
	print(i)
	if docid=='':
		cb.upsert(str(cb.counter('docid',delta=1).value),di)
	