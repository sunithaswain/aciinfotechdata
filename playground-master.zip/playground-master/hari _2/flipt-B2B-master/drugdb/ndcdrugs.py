########################################
# !/usr/bin/env python  
# title         : ndcdrugs.py
# description   :Update NDC drugs report
# author        : Disha
# date created  : 20180101
# date last modified    : 20190124 15:06
# version       : 0.1
# maintainer    : haris
# email         : hrajendran@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage         : python ndcdrugs.py -d GWLABS001 -t ndc_drugs -f ndc_drugs01232019.xlsx -m DRAFT
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  0.1							20190118	Header added
#  0.2							20190118	Log file added
# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
   sys.path.append(rootdir)
#    print(rootdir)

# print('this is a root directory',rootdir)
# it will changed based on OS
rootdir = rootdir.replace('\\', '/')
path = rootdir + os.environ['CB_DATA']

# print('this is a path',path)
import json
import os
import sys
import socket
from datetime import datetime
import traceback

import pandas as pd
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery

# from utils import commandline
from utils import commandline
from utils.sendgridemail import email_log

domain,file_type,file_name,mode = commandline.main(sys.argv[1:])

print('---------------------------')
print(os.environ['CB_INSTANCE'])

cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])

def DisplayndcReport(pfile_name):

	# modified by Hari on 27/12/2018
	host = socket.gethostname()
	currentdate = datetime.now()
	currentdate = currentdate.strftime("%m%d%y%H%M%S")
	log = path+'/'+domain+'/'+file_type+'/log/'+"ndcdrug_update"+currentdate+'.txt'

	listDictionary = []
	subject = ''

	file_format = os.path.splitext(pfile_name)[-1]

	full_filepath = path+'/'+domain+'/'+file_type+'/'+pfile_name
	print(full_filepath)
	if file_format == '.csv':
		ndcfile=pd.read_csv(full_filepath)
	else:
		ndcfile=pd.read_excel(full_filepath,converters={'GPI':str,'NDC':str,'GPPC':str})

	logfile = open(log,"w")
	ndcfile.fillna("",inplace=True)
	ndcfile['NDC']=ndcfile['NDC'].apply(lambda x: str(int(x)).zfill(11) if x!="" else x)
	ndcfile['GPI']=ndcfile['GPI'].apply(lambda x: str(x).zfill(14) if x!="" else x)
	ndcfile['GPPC']=ndcfile['GPPC'].apply(lambda x: str(x).zfill(8) if x!="" else x)
	ndcfile.columns = [x.lower().strip() for x in ndcfile.columns]
	ndccols = [x.lower().strip() for x in ndcfile.columns]
	# ndccols=list(ndcfile).apply(lambda x: x.lower().strip())
	required=['brand_generic','custom_qty','ddid','dosage','dosage_strength','drug_name','gpi','gppc','item_status_flag','mfg','multi_source','ndc','otc_indicator','package_desc','package_qty','package_quantity','package_size','pkg_desc_cd','pkg_uom','repackage_code','strengths','unit_dose','unit_price']
	print('file reading')
	lst_missed_columns = [column_name for column_name in required if column_name not in ndccols]

	if set(ndccols)!=set(required):
		print('Missing columns - %s'%(lst_missed_columns))
		logfile.write('Missing columns - %s'%(lst_missed_columns))
		logfile.close()
		subject = 'Error occured on NDC drug update (Missing columns - %s) :%s'%(host, lst_missed_columns)
		email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','FliptIntegration@fliptrx.com',subject,['NDC drug update File '+log,'NDC drug update Exception'],log,True)
		return
	# To  find duplicate records by Hari
	# --------------------------------------------------------------------
	duplicate_records = ndcfile[ndcfile[['gpi', 'ddid', 'brand_generic']].duplicated() == True]
	null_records = ndcfile[ndcfile[['gpi','drug_name','dosage_strength']].isnull().any(axis=1)]
	if duplicate_records.shape[0] > 0:
		print('Duplicate records occured in input file')
		duplicate_records.to_csv(path+'/'+domain+'/'+file_type+'/log/'+'duplicate_records_'+datetime.now().isoformat()+'.csv')

	if null_records.shape[0] > 0:
		print('Null records occured in input file')
		duplicate_records.to_csv(path+'/'+domain+'/'+file_type+'/log/'+'null_records_'+datetime.now().isoformat()+'.csv')
		# ndcfile.fillna('')
	# --------------------------------------------------------------------

	excel_rows_count = ndcfile.shape[0]
	# print('%s rows in ndcfile'%(ndcfile.shape[0]))
	record_count = 0
	tempcount = 0
	for val in ndcfile.itertuples():
		tempcount += 1
		try:
			rev={}
			rev['update_date']=datetime.now().isoformat()
			ndc_number = getattr(val, 'ndc')
			query=N1QLQuery('Select meta().id as id from `'+os.environ['CB_INSTANCE']+'` where type="ndc_drugs" and ndc=$drugndc',drugndc=ndc_number)
			query.adhoc=False
			for res in cb.n1ql_query(query):
				docid=res['id']
				rev['ndc_id']=docid
			for v in ndccols:
				rev[v.lower().strip()]=str(getattr(val, v))
			rev['type']='ndc_drugs'
			if 'ndc_id' not in rev:
				# print('%s no ndc'%(rev[0]))
				rv1=cb.counter('docid',delta=1)
				rev['ndc_id']=str(rv1.value)
			if mode.upper().strip()=='FINAL':
				cb.upsert(rev['ndc_id'],rev)
			else:
				# print(rev)
				listDictionary.append(rev)
			record_count += 1
		except Exception as e:
			print(traceback.format_exc())
			print('NDC %s record not inserted. \n'%(ndc_number))
			logfile.write('NDC %s record not inserted. \n'%(ndc_number))
	# print('tempcount is %s'%tempcount)

	# check all records are updated or not
	print('excel_rows_count - %s'%excel_rows_count)
	print('record_count - %s'%record_count)
	print('tempcount - %s'%tempcount)
	if excel_rows_count != record_count or tempcount != record_count:
		print('Some records are not updated. please check log file.')
		logfile.write('Some records are not updated. please check log file.')
		subject = 'Error occured on NDC drug update :'+host

	if mode.upper().strip()=='FINAL':
		print("%s records updated in database - Final Mode"%(record_count))
		logfile.write("%s records updated in database - Final Mode"%(record_count))
	else:
		print('%s records are to be update - Draft Mode'%(len(listDictionary)))
		logfile.write('%s records are to be update - Draft Mode'%(len(listDictionary)))
		draft_log = pd.DataFrame(listDictionary)
		draft_log.to_csv(path+'/'+domain+'/'+file_type+'/log/'+'draft_log_'+datetime.now().isoformat()+'.csv')

	logfile.close()
	if subject == '':	subject = 'NDC drug update status :'+host
	email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','FliptIntegration@fliptrx.com',subject,['NDC drug update File '+log,'NDC drug update Exception'],log,True)
	# move processed file to archive folder
	
	if mode.strip().upper() == 'FINAL':
		if not os.path.isdir(path+'/'+domain+'/'+file_type+'/archive/'): os.makedirs(path+'/'+domain+'/'+file_type+'/archive/')
		os.rename(full_filepath, path+'/'+domain+'/'+file_type+'/archive/'+pfile_name)

if file_name:
	DisplayndcReport(file_name)
else:
	print('automate file selection called')
	# Automate Drug Database Load
	from utils.autofile_transfer import multiplefilesftptransfer
	localpath = path+'/'+domain+'/'+file_type+'/'
	remotepath = 'uploads'
	multiplefilesftptransfer(remotepath, localpath, 'FLIPT_DRUG_NDC_*', "GET")

	for file_name in os.listdir(localpath):
		print(file_name)
		print(os.path.isfile(os.path.join(localpath,file_name)))
		if file_name.startswith("FLIPT_DRUG_NDC_") and os.path.isfile(os.path.join(localpath,file_name)):
			print(file_name)
			DisplayndcReport(file_name)