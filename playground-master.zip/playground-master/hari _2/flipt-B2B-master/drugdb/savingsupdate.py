

import pandas as pd
from couchbase.n1ql import N1QLQuery
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
import os
from utils import commandline
import sys
from datetime import datetime
from couchbase import FMT_JSON
import couchbase.subdocument as SD
from utils.sendgridemail import email_log

cluster=Cluster(os.environ['CB_URL']+'?operation_timeout=2700')
auth=PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(auth)
bucket_name=os.environ['CB_INSTANCE']
cb=cluster.open_bucket(bucket_name)

def updatesavings(domain):
	query1=N1QLQuery("Select distinct gpi from `"+bucket_name+"` where type='drug'")
	query1.timeout=3600
	for row1 in cb.n1ql_query(query1):
		
		maintenance_drug_flag="N"
		query2=N1QLQuery('Select brand_generic,deductibleexempted,qtytodaysupplyratio_new from `'+bucket_name+'` where type="formulary" and company=$dn and gpi=$g',g=row1['gpi'],dn=domain)
		query2.timeout=60
		formulary=pd.DataFrame()
		for row2 in cb.n1ql_query(query2):
			formulary=formulary.append(row2,ignore_index=True)
		if not formulary.empty:
			if '1' in list(formulary['deductibleexempted']) or '1.0' in list(formulary['deductibleexempted']):
				maintenance_drug_flag="Y"
		query3=N1QLQuery("Select meta().id id, drug_name,brand_generic,ddid from `"+bucket_name+"` where type='drug' and gpi=$g",g=row1['gpi'])
		query3.timeout=100
		drugs=pd.DataFrame()
		for row3 in cb.n1ql_query(query3):
			drugs=drugs.append(row3,ignore_index=True)
		if len(drugs)==1:
			cb.mutate_in(drugs.loc[0,'id'],SD.upsert('equivalent',[]))
			cb.mutate_in(drugs.loc[0,'id'],SD.upsert('maintenance_drug_flag',maintenance_drug_flag))
			cb.mutate_in(drugs.loc[0,'id'],SD.upsert('unit_price',""))
			
		unitprice=0
		qtyperperiod=0
		for i,r in drugs.iterrows():
			if len(drugs)!=1:
				equivalent={}
				
				query4=N1QLQuery("select b.drug_name,b.brandorgeneric,avg(tonumber(cp.unitprice)) unit_price from `"+bucket_name+"` b unnest b.cp_price cp where b.type='cp_drug_price' and b.gpi=$g and b.drug_name=$dn group by b.drug_name,b.brandorgeneric union select b.drug_name,b.brandorgeneric, avg(tonumber(cp.unitprice)) unit_price from `"+bucket_name+"` b unnest b.cp_price cp where b.type='cp_drug_price' and b.gpi=$g and b.drug_name in (select raw b1.drug_name from `"+bucket_name+"` b1 unnest quantity q where b1.type='drug' and b1.gpi=$g and b1.drug_name!=$dn order by b1.generic_rank,q.display_rank limit 1) group by b.drug_name,b.brandorgeneric",g=row1['gpi'],dn=r['drug_name'])
				for row4 in cb.n1ql_query(query4):
					nonmaintenance=False
					if r['drug_name']==row4['drug_name']: 
						cb.mutate_in(r['id'],SD.upsert('unit_price',str(row4['unit_price'])))
						unitprice=row4['unit_price']
						try:
							quantityperperiod=float(formulary.loc[(formulary['brand_generic']==r['brand_generic']),'qtytodaysupplyratio_new'].values[0])*365
						except Exception as e:
							nonmaintenance=True
							maintenance_drug_flag="N"
						cb.mutate_in(r['id'],SD.upsert('maintenance_drug_flag',maintenance_drug_flag))
						continue
					
					try:
						equivalent['equ_ddid']=drugs.loc[(drugs['drug_name']==row4['drug_name']),'ddid'].values[0]
						bg=drugs.loc[(drugs['drug_name']==row4['drug_name']),'brand_generic'].values[0]
						equivalent['equ_drug_name']=row4['drug_name']
						updateequdrugs(equivalent['equ_drug_name'],r['drug_name'],row1['gpi'])
						equivalent['unit_price']=str(row4['unit_price'])
						equivalent['unit_price_difference']=str(unitprice-row4['unit_price'])
						equivalent['rank']="1"
						equivalent['quantity_per_day']="0"
						equivalent['quantity_per_period']="0"
						equivalent['quantity_period']="Year"
						equivalent['cost_difference']="0"
						#equivalent['cost_difference_pct']="0"
						if not formulary.empty or not nonmaintenance or len(formulary)!=0:
							try:
								equivalent['quantity_per_day']=formulary.loc[(formulary['brand_generic']==bg),'qtytodaysupplyratio_new'].values[0]
								equivalent['quantity_per_period']=str(float(equivalent['quantity_per_day'])*365)
								equivalent['cost_difference']=str(float(equivalent['quantity_per_period'])*unitprice-quantityperperiod*row4['unit_price'])
								print(unitprice)
								print(equivalent['unit_price'])
								#equivalent['cost_difference_pct']=str(int(float(equivalent['cost_difference'])/(float(equivalent['quantity_per_period'])*unitprice)))
							except Exception as e1:
								if 'ddid' in r:
									print(r['ddid'])
								print(e1)
								cb.mutate_in(r['id'],SD.upsert('equivalent',[equivalent]))
					except Exception as e:
						print('absent',r)
						continue
					cb.mutate_in(r['id'],SD.upsert('equivalent',[equivalent]))
				#print(equivalent)
				#print(maintenance_drug_flag)
				#print(r['drug_name'])
				
			query5=N1QLQuery("Select meta().id id,alt_gpi, alt_brand_generic,alt_drug_name,quantity_per_day,alt_quantity_per_day from `"+bucket_name+"` where type='drug_alternative' and gpi=$g and drug_name=$dn",dn=r['drug_name'],g=row1['gpi'])
			query5.timeout=100
			for row5 in cb.n1ql_query(query5):
				alternate={}
				alternate['maintenance_drug_flag']=maintenance_drug_flag
				alternate['rank']="1"
				alternate['unit_price']="0"
				alternate['quantity_per_period']="0"
				alternate['alt_unit_price']="0"
				alternate['unit_price_difference']="0"
				alternate['cost_difference']="0"
				alternate['cost_difference_pct']="0"
				alternate['quantity_period']="Year"
				cb.mutate_in(row5['id'],SD.upsert('maintenance_drug_flag',maintenance_drug_flag))
				cb.mutate_in(row5['id'],SD.upsert('rank',"1"))
				cb.mutate_in(row5['id'],SD.upsert('quantity_per_period',"0"))
				cb.mutate_in(row5['id'],SD.upsert('quantity_period',"Year"))
				cb.mutate_in(row5['id'],SD.upsert('unit_price',"0"))
				cb.mutate_in(row5['id'],SD.upsert('alt_unit_price',"0"))
				cb.mutate_in(row5['id'],SD.upsert('unit_price_difference',"0"))
				cb.mutate_in(row5['id'],SD.upsert('cost_difference',"0"))
				cb.mutate_in(row5['id'],SD.upsert('cost_difference_pct',"0"))
				query6=N1QLQuery("Select b.drug_name,b.brandorgeneric,avg(tonumber(cp.unitprice)) unit_price from `"+bucket_name+"` b unnest b.cp_price cp where b.type='cp_drug_price' and b.gpi=$g and b.drug_name=$dn group by b.drug_name,b.brandorgeneric",g=row5['alt_gpi'],dn=row5['alt_drug_name'])
				query6.timeout=100
				for row6 in cb.n1ql_query(query6):
					if unitprice==0:
						query7=N1QLQuery("select b.drug_name,b.brandorgeneric,avg(tonumber(cp.unitprice)) unit_price from `"+bucket_name+"` b unnest b.cp_price cp where b.type='cp_drug_price' and b.gpi=$g and b.drug_name=$dn group by b.drug_name,b.brandorgeneric",g=row1['gpi'],dn=r['drug_name'])
						query7.timeout=100
						for row7 in cb.n1ql_query(query7):
							unitprice=row7['unit_price']
					cb.mutate_in(row5['id'],SD.upsert('unit_price',str(unitprice)))
					cb.mutate_in(row5['id'],SD.upsert('alt_unit_price',str(row6['unit_price'])))
					alternate['unit_price']=str(row6['unit_price'])
					cb.mutate_in(row5['id'],SD.upsert('unit_price_difference',str(unitprice-row6['unit_price'])))
					alternate['unit_price_difference']=str(unitprice*float(row5['quantity_per_day'])-row6['unit_price']*float(row5['alt_quantity_per_day']))
				
					cb.mutate_in(row5['id'],SD.upsert('quantity_per_period',str(float(row5['alt_quantity_per_day'])*365)))
					alternate['quantity_per_period']=str(float(row5['alt_quantity_per_day'])*365)
					cb.mutate_in(row5['id'],SD.upsert('cost_difference',str(unitprice*float(row5['quantity_per_day'])*365-float(row5['alt_quantity_per_day'])*365*float(alternate['unit_price']))))
					alternate['cost_difference']=str(unitprice*float(row5['quantity_per_day'])*365-float(row5['alt_quantity_per_day'])*365*float(alternate['unit_price']))
					try:
						cb.mutate_in(row5['id'],SD.upsert('cost_difference_pct',str(int(float(alternate['cost_difference'])/(unitprice*float(row5['quantity_per_day'])*365)*100))))
					except Exception as e:
						print(row6,'division error')
				#print(alternate)
				#print(row5)
def updateequdrugs(equ_drug_name,drug_name,gpi):

	query=N1QLQuery('Update `'+os.environ['CB_INSTANCE']+'` set equivalent_brand=$eqb where type="rx_history" and drug_name=$dn and gpi=$g',eqb=equ_drug_name,dn=drug_name,g=gpi)
	cb.n1ql_query(query).execute()
	query=N1QLQuery('Update `'+os.environ['CB_INSTANCE']+'` set equivalent_brand=$eqb where type="prescription" and drug_name=$dn and gpi=$g',eqb=equ_drug_name,dn=drug_name,g=gpi)
	cb.n1ql_query(query).execute()
	
				
updatesavings('GWLABS001')
receiver=['DWagle@fliptrx.com','DWagle@gwlabs.com']
subject='Drug Savings Updated - Completed'
body=['Processing of Savings update','‘DrugDatabase (ScriptClaim) Exception’']
email_log('dwagle@fliptrx.com',receiver[0],receiver[1],subject,body,None,False)			