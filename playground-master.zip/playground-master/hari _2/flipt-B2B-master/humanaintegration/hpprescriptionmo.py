
if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
   sys.path.append(rootdir)

# it will changed based on OS
rootdir = rootdir.replace('\\', '/')
path = rootdir + os.environ['CB_DATA']
 
import os
from utils import commandline
import sys
import paramiko
import socket
import time
import zipcode
from datetime import datetime
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from utils.sendgridemail import email_log
from utils.truevault import User_Class
from couchbase.n1ql import N1QLQuery
from hpsftp import sftptransfer,getfilemodifiedtime,multiplefilesftptransfer
import xml.etree.cElementTree as ET

# Command to run the script:

#python hpprescriptionmo.py -d GWLABS001 -t humanaintenttransfer -f IntentRequest -m DRAFT
#python hpprescriptionmo.py -d FLIPT001 -t humanaintenttransfer -f IntentRequest -m DRAFT

#Filename = IntentRequest_HHMMSSss.xml

cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
# path = os.environ['CB_DATA']
inputdomain,file_type,file_name,mode = commandline.main(sys.argv[1:])
updatedate = str(datetime.now())
currentdate = datetime.now()
currentdate = currentdate.strftime("%H%M%S%f")[:-4]
#currentdate = currentdate.strftime("%m%d%y%H%M%S")
#file_name = file_name+'_'+currentdate+'.xml'
fname= file_name
print(file_name)
first_name = ''
last_name = ''
emp_flipt_id = ''
host = socket.gethostname()
Mailorder_flag = 'Y'
localpath = path+'/'+inputdomain+'/'+file_type+'/'
remotepath = '/SUB100016423'+'/'
	
def humanapresciption():
	prescount = 0
	
	
	print('Remote Path : '+remotepath)
	#intentfile = localpath+file_name
	#Appending both the domains
	domainlist=[]
	domainlist.append(inputdomain)
	if 'GWLABS001' in domainlist:
		domainlist.append('FLIPT001')	
	
	#log = path+'/'+inputdomain+'/'+file_type+'/log/'+"humanaintentlog"+'_'+pres_id+'_'+currentdate+'.txt'
	#log = path+'/'+inputdomain+'/'+file_type+'/log/'+"humanaintentlog"+currentdate+'.txt'
	#print('Log Path : '+log)
	#logfile = open(log,"w")
	
	#logfile = open(log,"w")
	carrier = 'FLIPT'
	
	#logfile.write("Pres ID	 Group          CardHolderID   RL Drug Name                     Qty       B/G        Cost    Claim Type"+"\r\n")
	#logfile.write('================================================================================================================'+'\r\n')
	#pulling prescriptions with Routed status where hp_routed_date is not present
	routedtab = N1QLQuery('select flipt_person_id, drug, round(tonumber(rebate_amount),2) as rebate_amount,round(tonumber(drug_cost),2) as drug_cost, rx_status,drug_copay, gpi, tonumber(package_size)*tonumber(quantity) as quantity , rx_flipt_person_id, prescription_id, brand_generic,days_of_supply, routed_date, mo_contact_email, mo_contact_phone, mo_shipto_location, bin, npi, payment_option, round(round(tonumber(drug_cost),2) - round(tonumber(employee_opc),2),2) as employer_cost, round(tonumber(employee_opc),2) as employee_opc,domain from `'+os.environ['CB_INSTANCE']+'` t WHERE type = "prescription" and npi is not missing and bin = "018570" and rx_status = "Routed" and domain in $domain_name and pharmacy IN ["HUMANA MAIL ORDER","HUMANA SPECIALTY"] and (hp_routed_date is missing or hp_routed_date is null or hp_routed_date IS NOT VALUED) and t.flipt_person_id in (select raw dep_flipt_person_id from `'+os.environ['CB_INSTANCE']+'` where type = "flipt_person_hierarchy") order by prescription_id',domain_name = domainlist)
	routedtab.adhoc = False
	routedtab.timeout = 100
	#print(routedtab)
	for routerow in cb.n1ql_query(routedtab):
		
		carrier = 'FLIPT'
		domain=str(routerow['domain'])
		prescription_id = str(routerow['prescription_id'])
		flipt_id = str(routerow['flipt_person_id'])
		pres_id = str(routerow['prescription_id'])
		pres_id = pres_id[14:]
		print("Prescription ID:",pres_id)
		
		prescount = prescount+1
		log = path+'/'+inputdomain+'/'+file_type+'/log/'+"humanaintentlog"+'_'+pres_id+'_'+currentdate+'.txt'
		#print('Log Path : '+log)
		logfile = open(log,"w")
		logfile.write("Pres ID	 Group          CardHolderID   RL Drug Name                     Qty       B/G        Cost    Claim Type"+"\r\n")
		logfile.write('================================================================================================================'+'\r\n')
		
		if 'days_of_supply' in routerow:
			ds = str(routerow['days_of_supply'])
		else:
			ds = ''
		gpi_code = str(routerow['gpi'])
		hp_rx_status = str(routerow['rx_status'])
		#copay = str(routerow['drug_copay'])
		#gppc = str(routerow['gppc'])
		drug_name = str(routerow['drug'])
		pharmacy_npi = str(routerow['npi'])
		pay_option = str(routerow['payment_option'])
		claim_req_date = str(routerow['routed_date'])
		
		bin = str(routerow['bin'])
		#if bin != '018750':
		#	continue		
		qty = float(routerow['quantity'])
		qty = '%.3f' % qty
		if len(str(qty)) > 10:
			qty = 'ERROR'		
		bg = str(routerow['brand_generic'])
		costthreshold=100
		
		try:
			if routerow['rebate_amount']>0:	costthreshold=costthreshold+routerow['rebate_amount']
		except Exception as e:
			costthreshold=100

		
		#deriving brand_generic according to logic 
		bgtab = N1QLQuery('select p.multiscourcecode,cp.pricetype  from `'+os.environ['CB_INSTANCE']+'` p unnest cp_price cp where p.type = "cp_drug_price" and p.gpi = $gpi and p.drug_name = $drug limit 1',gpi = gpi_code, drug = drug_name)
		bgtab.adhoc = False
		bgtab.timeout = 100
		for bgrow in cb.n1ql_query(bgtab):
			if bgrow['pricetype'].upper().strip()=='AWP' and bgrow['multiscourcecode'] in ["N","M","O"]:
				bg='B'
			else:
				bg='G'

		
		if pay_option == 'Pay via Payroll Deduction':
			patient_pay = '0'
			calc_cost = float(routerow['employer_cost'])
		else:
			patient_pay = routerow['employee_opc']
			calc_cost = float(routerow['employer_cost'])
		
		
		
		rx_flipt_person_id = str(routerow['rx_flipt_person_id'])
		claim_type = 'P'


		mo_shipto_location = ''
		mo_contact_phone = ''
		mo_contact_email = ''
		address1 = ''
		address2 = ''
		city = ''
		state = ''
		zip_code = ''
		zip2 = ''
		
		#try check if prescription filled for a mail order pharmacy
		try:
				
			if len(str(routerow['mo_shipto_location'])) > 0:
				mo_shipto_location = str(routerow['mo_shipto_location'])
				mo_contact_phone = str(routerow['mo_contact_phone'])
				chdict={'-':'','.':''}	
				for k,v in chdict.items():
					mo_contact_phone=mo_contact_phone.replace(k,v)				
				mo_contact_email = str(routerow['mo_contact_email'])

				obj=User_Class(None,None)
				search_option={'full_document':True,'filter':{'domain_name':{'type':'eq','value':domain,'case_sensitive':False},'flipt_person_id':{'type':'eq','value':flipt_id,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
				att,userid = obj.search_user(search_option)
				if att!=None:
					
					
					if mo_shipto_location == 'Home':
						address1 = str(att['home_address_1'])
						address2 = ''
						city = str(att['city'])
						state = str(att['state'])
						zip_code = str(att['zip'])
						zip2 = ''
					else:
						for loc in att['locations']:
							if loc['name'].strip().lower() == mo_shipto_location:
								address1 = str(loc['street_address'])
								address2 = ''
								city = str(loc['city'])
								zip_code = str(loc['zip_code'])
								my_zip = zipcode.isequal(zip_code)
								state = my_zip.state
								zip2 = ''
		
		except KeyError:
		
			Mailorder_flag = 'N'
		#derive employee and get attributes of patient based on flipt person id
		fhierarchytab = N1QLQuery('select distinct emp_flipt_person_id,domain_name from `'+os.environ['CB_INSTANCE']+'` where  type = "flipt_person_hierarchy" and domain_name in $domain_name and (emp_flipt_person_id = $rxid or dep_flipt_person_id = $rxid)',domain_name = domainlist, rxid = rx_flipt_person_id)
		fhierarchytab.adhoc = False
		fhierarchytab.timeout = 100
		#print(fhierarchytab)
		l_flipt_flag = 0
		for empfliptrow in cb.n1ql_query(fhierarchytab):
			#print(empfliptrow)
			l_flipt_flag = 1
			emp_flipt_id = str(empfliptrow['emp_flipt_person_id'])
			domain=str(empfliptrow['domain_name'])
			obj=User_Class(None,None)
			search_option={'full_document':True,'filter':{'domain_name':{'type':'eq','value':domain,'case_sensitive':False},'flipt_person_id':{'type':'eq','value':emp_flipt_id,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
			att,userid = obj.search_user(search_option)
			if att!=None and emp_flipt_id == rx_flipt_person_id:
				group = str(att['group'])
				first_name = str(att['first_name'])
				last_name = str(att['last_name'])
				card_holder_id = "FLP" + emp_flipt_id + att['person_code']
				person_code = att['person_code']
				dob = datetime.strptime(str(att['date_of_birth']),"%Y-%m-%d %H:%M:%S")
				dob = dob.strftime('%Y%m%d')
				if 'language' in att and str(att['language'])!= '':
					lang_pref = str(att['language'])
				else:
					lang_pref='EN'
				relationship_code = '1'
				sex = att['gender']
				from_date = datetime.strptime(str(att['coverage_effective_date']),"%Y-%m-%d %H:%M:%S")
				from_date = from_date.strftime('%Y%m%d')
				to_date = datetime.strptime(str(att['coverage_termination_date']),"%Y-%m-%d %H:%M:%S")
				to_date = to_date.strftime('%Y%m%d')
				
				if 'allergy_conditions' in att:
					allergy_condition = ','.join(att['allergy_conditions'])
				else:
					allergy_condition = ''
				
				if 'health_conditions' in att:
					health_condition = ','.join(att['health_conditions'])
				else:
					health_condition = ''
	
				if mode.upper() == 'FINAL':
					cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET hp_routed_date = $rdate WHERE type = "prescription" and prescription_id = $pid',rdate =updatedate,pid = prescription_id)).execute()			
			
				
				
				stat = hppresc_cutomxml(carrier,pres_id,domain,group,card_holder_id,person_code,last_name,first_name,dob,gpi_code,drug_name,ds,qty,bg,patient_pay,calc_cost,claim_req_date,claim_type,pharmacy_npi,mo_contact_phone,address1,address2,city,state,zip_code,zip2,mo_contact_email,lang_pref,allergy_condition,health_condition,relationship_code,sex,from_date,to_date)
				print("Humana Intent File Prescription created in Routed Section "+stat)
				
				
				logfile.write(pres_id.ljust(9)+group.ljust(15)+card_holder_id.ljust(15)+person_code.ljust(3)+drug_name.ljust(30)+qty.ljust(10)+bg.ljust(1)+str(patient_pay).ljust(10)+str(calc_cost).ljust(10)+claim_type.ljust(1)+pharmacy_npi.ljust(10)+mo_contact_phone.ljust(10)+address1.ljust(25)+address2.ljust(15)+city.ljust(20)+state.ljust(2)+zip_code.ljust(5)+zip2.ljust(4)+mo_contact_email.ljust(100)+str(costthreshold).ljust(10)+"\r\n")
				
				if mode.upper() == 'FINAL':
					if stat =='S':
						#os.remove(intentfile)
						logfile.close()
						subject = 'Humana Intent File Transferred Successfully'
						email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','deepthi.gollapudi@nttdata.com,ssubramani@fliptrx.com,akarlis@fliptrx.com,reports@fliptrx.com',subject,['Processing of Humana Intent File '+log,'Humana Intent Exception'],log,True)
					else:
						logfile.write('File transfer failed !!! Please reprocess the File : '+file_name)
						logfile.close()
						subject = 'Humana Intent File Transfer Failed - '+host
						email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','deepthi.gollapudi@nttdata.com,ssubramani@fliptrx.com,akarlis@fliptrx.com,reports@fliptrx.com',subject,['Processing of Humana Intent File '+log,'Humana Intent Exception'],log,True)
						print("Humana Intent File created "+fname+" and successfully uploaded to "+remotepath)	
				else:
				
					logfile.write('Humana Intent File Transfer - Draft Mode :'+host+file_name)
					logfile.close()
					subject = 'Humana Intent File Transfer - Draft Mode:'+host
					email_log('DWagle@fliptrx.com','DWagle@fliptrx.com','deepthi.gollapudi@nttdata.com,ssubramani@fliptrx.com,akarlis@fliptrx.com,reports@fliptrx.com',subject,['Processing of Humana Intent File '+log,'Humana Intent Exception'],log,True)
					email_log('DWagle@fliptrx.com','DWagle@fliptrx.com','deepthi.gollapudi@nttdata.com,akarlis@fliptrx.com,reports@fliptrx.com',subject,['Processing of Humana Intent File '+log,'Humana Intent Exception'],log,True)
					#print(log)
						
					
				
					
				
			elif att!=None and emp_flipt_id != rx_flipt_person_id:
				group = str(att['group'])
				for dep in att['dependents']:
					dep_flipt_id = str(dep['flipt_person_id'])
					if dep_flipt_id == rx_flipt_person_id:
						first_name = str(dep['first_name'])
						last_name = str(dep['last_name'])
						card_holder_id = "FLP" + emp_flipt_id + dep['person_code']
						person_code = dep['person_code']
						dob = datetime.strptime(str(dep['date_of_birth']),"%Y-%m-%d %H:%M:%S")
						dob = dob.strftime('%Y%m%d')						
						if 'language' in att and str(att['language'])!= '':
							lang_pref = str(att['language'])
						else:
							lang_pref='EN'
						if person_code == '02':
							relationship_code = '2'
						else:
							relationship_code = '3'
						
						if 'gender' in dep:
							sex = dep['gender']
						else: sex=' '	
						
						from_date = datetime.strptime(str(att['coverage_effective_date']),"%Y-%m-%d %H:%M:%S")
						from_date = from_date.strftime('%Y%m%d')
						to_date = datetime.strptime(str(att['coverage_termination_date']),"%Y-%m-%d %H:%M:%S")
						to_date = to_date.strftime('%Y%m%d')	
					
						allergy_condition=''
						if 'allergy_conditions' in dep:
							allergy_condition = ','.join(dep['allergy_conditions'])
						else:
							allergy_condition=''
						if 'health_conditions' in att:
							health_condition = ','.join(dep['health_conditions'])
						else:
							health_condition=''

						stat = hppresc_cutomxml(carrier,pres_id,domain,group,card_holder_id,person_code,last_name,first_name,dob,gpi_code,drug_name,ds,qty,bg,patient_pay,calc_cost,claim_req_date,claim_type,pharmacy_npi,mo_contact_phone,address1,address2,city,state,zip_code,zip2,mo_contact_email,lang_pref,allergy_condition,health_condition,relationship_code,sex,from_date,to_date)
						print("Humana Intent File Prescription created in Routed Section for Dep "+stat)
						
						logfile.write(pres_id.ljust(9)+group.ljust(15)+card_holder_id.ljust(15)+person_code.ljust(3)+drug_name.ljust(30)+qty.ljust(10)+bg.ljust(1)+str(patient_pay).ljust(10)+str(calc_cost).ljust(10)+claim_type.ljust(1)+pharmacy_npi.ljust(10)+mo_contact_phone.ljust(10)+address1.ljust(25)+address2.ljust(15)+city.ljust(20)+state.ljust(2)+zip_code.ljust(5)+zip2.ljust(4)+mo_contact_email.ljust(100)+str(costthreshold).ljust(10)+"\r\n")
						
						
						if mode.upper() == 'FINAL':
							cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET hp_routed_date = $rdate WHERE type = "prescription" and prescription_id = $pid',rdate =updatedate,pid = prescription_id)).execute()			
					
							if stat =='S':
								#os.remove(intentfile)
								logfile.close()
								subject = 'Humana Intent File Transferred Successfully'
								email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','deepthi.gollapudi@nttdata.com,ssubramani@fliptrx.com,akarlis@fliptrx.com,reports@fliptrx.com',subject,['Processing of Humana Intent File '+log,'Humana Intent Exception'],log,True)
							else:
								logfile.write('File transfer failed !!! Please reprocess the File : '+file_name)
								logfile.close()
								subject = 'Humana Intent File Transfer Failed - '+host
								email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','deepthi.gollapudi@nttdata.com,ssubramani@fliptrx.com,akarlis@fliptrx.com,reports@fliptrx.com',subject,['Processing of Humana Intent File '+log,'Humana Intent Exception'],log,True)
								print("Humana Intent File created "+fname+" and successfully uploaded to "+remotepath)	
						else:
				
							logfile.write('Humana Intent File Transfer - Draft Mode :'+host+file_name)
							logfile.close()
							subject = 'Humana Intent File Transfer - Draft Mode:'+host
							email_log('DWagle@fliptrx.com','DWagle@fliptrx.com','deepthi.gollapudi@nttdata.com,ssubramani@fliptrx.com,akarlis@fliptrx.com,reports@fliptrx.com',subject,['Processing of Humana Intent File '+log,'Humana Intent Exception'],log,True)
							email_log('DWagle@fliptrx.com','DWagle@fliptrx.com','deepthi.gollapudi@nttdata.com,akarlis@fliptrx.com,reports@fliptrx.com',subject,['Processing of Humana Intent File '+log,'Humana Intent Exception'],log,True)
							#print(log)
						
						
						
						
			else:
				logfile.write('Attributes not found for Flipt Person ID : '+emp_flipt_id)
				continue
		if l_flipt_flag == 0:
			logfile.write('Employee Flipt Person ID not found in Employee Hierarchy for Prescription rx_flipt_person_id : '+rx_flipt_person_id+"\r\n")
	#print(prescount)
	#pull prescriptions with Cancelled status
	
	canceltab = N1QLQuery('select flipt_person_id, drug, round(tonumber(drug_cost),2) as drug_cost, rx_status, gpi,tonumber(package_size)*tonumber(quantity) as quantity , rx_flipt_person_id, prescription_id, brand_generic,cancelled_date,drug_copay,days_of_supply,mo_contact_email, mo_contact_phone, mo_shipto_location,bin,npi,payment_option, round(round(tonumber(drug_cost),2) - round(tonumber(employee_opc),2),2) as employer_cost , round(tonumber(employee_opc),2) as employee_opc,domain from `'+os.environ['CB_INSTANCE']+'` t WHERE type = "prescription" and rx_status = "Cancelled" and bin = "018570" and npi is not missing and domain in $domain_name and pharmacy in ["HUMANA MAIL ORDER","HUMANA SPECIALTY"] and (hp_cancelled_date is missing or hp_cancelled_date is null or hp_cancelled_date IS NOT VALUED) and t.flipt_person_id in (select raw dep_flipt_person_id from `'+os.environ['CB_INSTANCE']+'` where type = "flipt_person_hierarchy") order by prescription_id',domain_name = domainlist )
	canceltab.adhoc = False
	canceltab.timeout = 100
	for cancelrow in cb.n1ql_query(canceltab):
		carrier = 'FLIPT'
		domain=str(cancelrow['domain'])
		prescription_id = str(cancelrow['prescription_id'])	
		pres_id = str(cancelrow['prescription_id'])
		flipt_id = str(cancelrow['flipt_person_id'])
		pres_id = pres_id[14:]
		print("Prescription ID:",pres_id)
		log = path+'/'+inputdomain+'/'+file_type+'/log/'+"humanaintentlog"+'_'+pres_id+'_'+currentdate+'.txt'
		#print('Log Path : '+log)
		logfile = open(log,"w")
		logfile.write("Pres ID	 Group          CardHolderID   RL Drug Name                     Qty       B/G        Cost    Claim Type"+"\r\n")
		logfile.write('================================================================================================================'+'\r\n')
		gpi_code = str(cancelrow['gpi'])
		drug_name = str(cancelrow['drug'])
		drug_name = drug_name[0:99]
		qty = float(cancelrow['quantity'])
		pharmacy_npi = str(cancelrow['npi'])
		pay_option = str(cancelrow['payment_option'])		
		if 'days_of_supply' in cancelrow:
			ds = str(cancelrow['days_of_supply'])
		else:
			ds = ''
		hp_rx_status = str(cancelrow['rx_status'])
		#copay = str(cancelrow['drug_copay'])
		claim_req_date = str(cancelrow['cancelled_date'])
		
		
		
		bin = str(cancelrow['bin'])
		costthreshold=100
		try:
			if routerow['rebate_amount']>0:	costthreshold=costthreshold+routerow['rebate_amount']
		except Exception as e:
			costthreshold=100
		qty = '%.3f' % qty
		if len(str(qty)) > 10:
			qty = 'ERROR'
		bg = str(cancelrow['brand_generic'])
		#derive brand generic according to logic
		bgtab = N1QLQuery('select p.multiscourcecode,cp.pricetype  from `'+os.environ['CB_INSTANCE']+'` p unnest cp_price cp where p.type = "cp_drug_price" and p.gpi = $gpi and p.drug_name = $drug limit 1',gpi = gpi_code, drug = drug_name)
		bgtab.adhoc = False
		bgtab.timeout = 100
		for bgrow in cb.n1ql_query(bgtab):
			if bgrow['pricetype'].upper().strip()=='AWP' and bgrow['multiscourcecode'] in ["N","M","O"]:
				bg='B'
			else:
				bg='G'			
		if pay_option == 'Pay via Payroll Deduction':
			patient_pay = '0'
			calc_cost = float(cancelrow['employer_cost'])
		else:
			patient_pay = cancelrow['employee_opc']
			calc_cost = float(cancelrow['employer_cost'])
			
		rx_flipt_person_id = str(cancelrow['rx_flipt_person_id'])
		claim_type = 'X'

		mo_shipto_location	= ''
		mo_contact_phone = ''
		mo_contact_email = ''
		address1 = ''
		address2 = ''
		city = ''
		state = ''
		zip_code = ''
		zip2 = ''	
		#check if prescription was for mail order pharmacy
		try:
				
			if len(str(cancelrow['mo_shipto_location'])) > 0:
				mo_shipto_location = str(cancelrow['mo_shipto_location'])
				mo_contact_phone = str(cancelrow['mo_contact_phone'])
				chdict={'-':'','.':''}	
				for k,v in chdict.items():
					mo_contact_phone=mo_contact_phone.replace(k,v)				
				mo_contact_email = str(cancelrow['mo_contact_email'])

				obj=User_Class(None,None)
				search_option={'full_document':True,'filter':{'domain_name':{'type':'eq','value':domain,'case_sensitive':False},'flipt_person_id':{'type':'eq','value':flipt_id,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
				att,userid = obj.search_user(search_option)
				if att!=None:
					if mo_shipto_location == 'Home':
						address1 = str(att['home_address_1'])
						address2 = ''
						city = str(att['city'])
						state = str(att['state'])
						zip_code = str(att['zip'])
						zip2 = ''
					else:
						for loc in att['locations']:
							if loc['name'].strip().lower() == mo_shipto_location:
								address1 = str(loc['street_address'])
								address2 = ''
								city = str(loc['city'])
								zip_code = str(loc['zip_code'])
								my_zip = zipcode.isequal(zip_code)
								state = my_zip.state
								zip2 = ''
		
		except KeyError:
		
			Mailorder_flag = 'N'

		#derive employee and patient attributes based on flipt person id
		fhierarchytab = N1QLQuery('select distinct emp_flipt_person_id,domain_name from `'+os.environ['CB_INSTANCE']+'` where  type = "flipt_person_hierarchy" and domain_name in $domain_name and (emp_flipt_person_id = $rxid or dep_flipt_person_id = $rxid)',domain_name = domainlist, rxid = rx_flipt_person_id)
		fhierarchytab.adhoc = False
		fhierarchytab.timeout = 100
		lc_flipt_flag = 0
		for empfliptrow in cb.n1ql_query(fhierarchytab):
			emp_flipt_id = str(empfliptrow['emp_flipt_person_id'])
			domain=str(empfliptrow['domain_name'])
			lc_flipt_flag = 1
			obj=User_Class(None,None)
			search_option={'full_document':True,'filter':{'domain_name':{'type':'eq','value':domain,'case_sensitive':False},'flipt_person_id':{'type':'eq','value':emp_flipt_id,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
			att,userid = obj.search_user(search_option)
			if att!=None and emp_flipt_id == rx_flipt_person_id:
				#group = 'GWALL'
				group = str(att['group'])
				first_name = str(att['first_name'])
				first_name = first_name[0:14]
				last_name = str(att['last_name'])
				last_name = last_name[0:24]
				card_holder_id = "FLP" + emp_flipt_id + att['person_code']
				person_code = att['person_code']
				dob = datetime.strptime(str(att['date_of_birth']),"%Y-%m-%d %H:%M:%S")
				dob = dob.strftime('%Y%m%d')
				if 'language' in att and str(att['language'])!= '':
					lang_pref = str(att['language'])
				else:
					lang_pref='EN'
					
				relationship_code = '1'
				sex = att['gender']
				from_date = datetime.strptime(str(att['coverage_effective_date']),"%Y-%m-%d %H:%M:%S")
				from_date = from_date.strftime('%Y%m%d')
				to_date = datetime.strptime(str(att['coverage_termination_date']),"%Y-%m-%d %H:%M:%S")
				to_date = to_date.strftime('%Y%m%d')
					
				allergy_condition=''
				if 'allergy_conditions' in att:
					allergy_condition = ','.join(att['allergy_conditions'])
				
				health_condition=''
				if 'health_conditions' in att:
					health_condition = ','.join(att['health_conditions'])
						
				if mode.upper() == 'FINAL':
					cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET hp_cancelled_date = $cdate WHERE type = "prescription" and prescription_id = $pid',cdate =updatedate,pid = prescription_id)).execute()	
				
				
				stat = hppresc_cutomxml(carrier,pres_id,domain,group,card_holder_id,person_code,last_name,first_name,dob,gpi_code,drug_name,ds,qty,bg,patient_pay,calc_cost,claim_req_date,claim_type,pharmacy_npi,mo_contact_phone,address1,address2,city,state,zip_code,zip2,mo_contact_email,lang_pref,allergy_condition,health_condition,relationship_code,sex,from_date,to_date)
						
				print("Humana Intent File Prescription created in Cancelled Section "+stat)
				
				logfile.write(pres_id.ljust(9)+group.ljust(15)+card_holder_id.ljust(15)+person_code.ljust(3)+drug_name.ljust(30)+qty.ljust(10)+bg.ljust(1)+str(patient_pay).ljust(10)+str(calc_cost).ljust(10)+claim_type.ljust(1)+pharmacy_npi.ljust(10)+mo_contact_phone.ljust(10)+address1.ljust(25)+address2.ljust(15)+city.ljust(20)+state.ljust(2)+zip_code.ljust(5)+zip2.ljust(4)+mo_contact_email.ljust(100)+str(costthreshold).ljust(10)+"\r\n")
				
				if mode.upper() == 'FINAL':
					if stat =='S':
						#os.remove(intentfile)
						logfile.close()
						subject = 'Humana Intent File Transferred Successfully'
						email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','deepthi.gollapudi@nttdata.com,ssubramani@fliptrx.com,akarlis@fliptrx.com,reports@fliptrx.com',subject,['Processing of Humana Intent File '+log,'Humana Intent Exception'],log,True)
					else:
						logfile.write('File transfer failed !!! Please reprocess the File : '+file_name)
						logfile.close()
						subject = 'Humana Intent File Transfer Failed - '+host
						email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','deepthi.gollapudi@nttdata.com,ssubramani@fliptrx.com,akarlis@fliptrx.com,reports@fliptrx.com',subject,['Processing of Humana Intent File '+log,'Humana Intent Exception'],log,True)
						print("Humana Intent File created "+fname+" and successfully uploaded to "+remotepath)	
				else:
				
					logfile.write('Humana Intent File Transfer - Draft Mode :'+host+file_name)
					logfile.close()
					subject = 'Humana Intent File Transfer - Draft Mode:'+host
					email_log('DWagle@fliptrx.com','DWagle@fliptrx.com','deepthi.gollapudi@nttdata.com,ssubramani@fliptrx.com,akarlis@fliptrx.com,reports@fliptrx.com',subject,['Processing of Humana Intent File '+log,'Humana Intent Exception'],log,True)
					email_log('DWagle@fliptrx.com','DWagle@fliptrx.com','deepthi.gollapudi@nttdata.com,akarlis@fliptrx.com,reports@fliptrx.com',subject,['Processing of Humana Intent File '+log,'Humana Intent Exception'],log,True)
					#print(log)
				
			elif att!=None and emp_flipt_id != rx_flipt_person_id:
				group = str(att['group'])
				for dep in att['dependents']:
					dep_flipt_id = str(dep['flipt_person_id'])
					if dep_flipt_id == rx_flipt_person_id:
						first_name = str(dep['first_name'])
						last_name = str(dep['last_name'])
						card_holder_id = "FLP" + emp_flipt_id + dep['person_code']
						person_code = dep['person_code']
						dob = datetime.strptime(str(dep['date_of_birth']),"%Y-%m-%d %H:%M:%S")
						dob = dob.strftime('%Y%m%d')						
						if 'language' in att and str(att['language'])!= '':
							lang_pref = str(att['language'])
						else:
							lang_pref='EN'
							
						if person_code == '02':
							relationship_code = '2'
						else:
							relationship_code = '3'
						
						if 'gender' in dep:
							sex = dep['gender']
						else: sex=' '	
						
						from_date = datetime.strptime(str(att['coverage_effective_date']),"%Y-%m-%d %H:%M:%S")
						from_date = from_date.strftime('%Y%m%d')
						to_date = datetime.strptime(str(att['coverage_termination_date']),"%Y-%m-%d %H:%M:%S")
						to_date = to_date.strftime('%Y%m%d')	
							
						if 'allergy_conditions' in dep:
							allergy_condition = ','.join(dep['allergy_conditions'])
						else:
							allergy_condition=''
						if 'health_conditions' in att:
							health_condition = ','.join(dep['health_conditions'])
						else:
							health_condition=''

						stat = hppresc_cutomxml(carrier,pres_id,domain,group,card_holder_id,person_code,last_name,first_name,dob,gpi_code,drug_name,ds,qty,bg,patient_pay,calc_cost,claim_req_date,claim_type,pharmacy_npi,mo_contact_phone,address1,address2,city,state,zip_code,zip2,mo_contact_email,lang_pref,allergy_condition,health_condition,relationship_code,sex,from_date,to_date)
						
						print("Humana Intent File Prescription created in Cancelled Section for Dep "+stat)
						
						logfile.write(pres_id.ljust(9)+group.ljust(15)+card_holder_id.ljust(15)+person_code.ljust(3)+drug_name.ljust(30)+qty.ljust(10)+bg.ljust(1)+str(patient_pay).ljust(10)+str(calc_cost).ljust(10)+claim_type.ljust(1)+pharmacy_npi.ljust(10)+mo_contact_phone.ljust(10)+address1.ljust(25)+address2.ljust(15)+city.ljust(20)+state.ljust(2)+zip_code.ljust(5)+zip2.ljust(4)+mo_contact_email.ljust(100)+str(costthreshold).ljust(10)+"\r\n")	
						
						if mode.upper() == 'FINAL':
							cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET hp_cancelled_date = $cdate WHERE type = "prescription" and prescription_id = $pid',cdate =updatedate,pid = prescription_id)).execute()	
						
							if stat =='S':
								#os.remove(intentfile)
								#logfile.close()
								subject = 'Humana Intent File Transferred Successfully'
								email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','deepthi.gollapudi@nttdata.com,ssubramani@fliptrx.com,akarlis@fliptrx.com,reports@fliptrx.com',subject,['Processing of Humana Intent File '+log,'Humana Intent Exception'],log,True)
							else:
								logfile.write('File transfer failed !!! Please reprocess the File : '+file_name)
								logfile.close()
								subject = 'Humana Intent File Transfer Failed - '+host
								email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','deepthi.gollapudi@nttdata.com,ssubramani@fliptrx.com,akarlis@fliptrx.com,reports@fliptrx.com',subject,['Processing of Humana Intent File '+log,'Humana Intent Exception'],log,True)
								print("Humana Intent File created "+fname+" and successfully uploaded to "+remotepath)	
						else:
				
							logfile.write('Humana Intent File Transfer - Draft Mode :'+host+file_name)
							logfile.close()
							subject = 'Humana Intent File Transfer - Draft Mode:'+host
							email_log('DWagle@fliptrx.com','DWagle@fliptrx.com','deepthi.gollapudi@nttdata.com,ssubramani@fliptrx.com,akarlis@fliptrx.com,reports@fliptrx.com',subject,['Processing of Humana Intent File '+log,'Humana Intent Exception'],log,True)
							email_log('DWagle@fliptrx.com','DWagle@fliptrx.com','deepthi.gollapudi@nttdata.com,akarlis@fliptrx.com,reports@fliptrx.com',subject,['Processing of Humana Intent File '+log,'Humana Intent Exception'],log,True)
							#print(log)
					
			else:
				logfile.write('Attributes not found for Flipt Person ID : '+emp_flipt_id)
				continue	
		if lc_flipt_flag == 0:
			logfile.write('Employee Flipt Person ID not found in Employee Hierarchy for Prescription rx_flipt_person_id : '+rx_flipt_person_id+"\r\n")
	
	
	
	
	
def hppresc_cutomxml(carrier,pres_id,domain,group,card_holder_id,person_code,last_name,first_name,dob,gpi_code,drug_name,ds,qty,bg,patient_pay,calc_cost,claim_req_date,claim_type,pharmacy_npi,mo_contact_phone,address1,address2,city,state,zip_code,zip2,mo_contact_email,lang_pref,allergy_condition,health_condition,relationship_code,sex,from_date,to_date):
	
	IntentRequest = ET.Element("IntentRequest")
	ET.SubElement(IntentRequest, "TransactionID").text = pres_id
	ET.SubElement(IntentRequest, "Carrier").text = carrier
	ET.SubElement(IntentRequest, "Account").text = domain
	ET.SubElement(IntentRequest, "Group").text = group
	ET.SubElement(IntentRequest, "RequestType").text = claim_type
	ET.SubElement(IntentRequest, "CardHolderID").text = card_holder_id
	ET.SubElement(IntentRequest, "FirstName").text = first_name
	ET.SubElement(IntentRequest, "LastName").text = last_name
	ET.SubElement(IntentRequest, "DOB").text = dob
	ET.SubElement(IntentRequest, "RelationshipCode").text = relationship_code
	ET.SubElement(IntentRequest, "Gender").text = sex
	ET.SubElement(IntentRequest, "FromDate").text = from_date
	ET.SubElement(IntentRequest, "ToDate").text = to_date	
	ET.SubElement(IntentRequest, "PharmacyNPI").text = pharmacy_npi
	Items = ET.SubElement(IntentRequest, "Items")
	Item = ET.SubElement(Items, "Item")
	ET.SubElement(Item, "Label").text = drug_name
	ET.SubElement(Item, "GPI").text = gpi_code
	ET.SubElement(Item, "DaysSupply").text = ds
	ET.SubElement(Item, "Quantity").text = qty
	ET.SubElement(Item, "CopayCost").text = str(patient_pay)
	ET.SubElement(Item, "PlanCost").text = str(calc_cost)
	ET.SubElement(Item, "ClaimRequestDate").text = claim_req_date
	
	ET.SubElement(Item, "DispenseType").text = bg
	ET.SubElement(Item, "RxNumber").text = None
	ShippingAddress = ET.SubElement(IntentRequest, "ShippingAddress")
	ET.SubElement(ShippingAddress, "AddressLine1").text = address1
	ET.SubElement(ShippingAddress, "AddressLine2").text = address2
	ET.SubElement(ShippingAddress, "City").text = city
	ET.SubElement(ShippingAddress, "State").text = state
	ET.SubElement(ShippingAddress, "Zip").text = zip_code
	ET.SubElement(ShippingAddress, "Zip2").text = zip2
	ET.SubElement(IntentRequest, "Email").text = mo_contact_email
	ET.SubElement(IntentRequest, "Phone").text = mo_contact_phone
	LanguagePreferences = ET.SubElement(IntentRequest, "LanguagePreferences")
	ET.SubElement(LanguagePreferences, "language").text = lang_pref
	Allergies = ET.SubElement(IntentRequest, "Allergies")
	
	if len(allergy_condition)>0 :
		allergy_split = allergy_condition.split(",")	
		for ac in allergy_split:
			ET.SubElement(Allergies, "Allergy").text = ac
	else:
		ET.SubElement(Allergies, "Allergy").text = ''

			
	HealthConditions = ET.SubElement(IntentRequest, "HealthConditions")
	if len(health_condition)>0 :
		hc_split = health_condition.split(",")
		for hc in hc_split:
			ET.SubElement(HealthConditions, "HealthCondition").text = hc
	else:
		ET.SubElement(HealthConditions, "HealthCondition").text = ''
	
	tree = ET.ElementTree(IntentRequest)
	global currentdate,file_name
	print(pres_id,file_name,currentdate)
	fname=file_name+'_'+str(pres_id)+'_'+currentdate+'.xml'
	#intentfile = localpath+str(pres_id)+'_'+file_name
	intentfile = localpath+fname
	tree.write(intentfile)
	
	
	
	if mode.upper() == 'FINAL':
		filesize = os.path.getsize(intentfile)
		print(filesize)
		getfilemodifiedtime('/'+remotepath.split('/')[1])
		
		if filesize > 0:
			status = sftptransfer(intentfile,remotepath+fname,'PUT')
			
			'''
			if status =='S':
				os.remove(intentfile)
				print('Removing intent file from local path')
			'''
			print(status)
			
		else:
			#os.remove(intentfile)
			print("Humana Intent File Transfer  - No Intents found")
			subject = 'Humana Intent File Transfer  - No Intents found :'+host
			email_log('DWagle@fliptrx.com','DWagle@fliptrx.com','deepthi.gollapudi@nttdata.com,ssubramani@fliptrx.com,akarlis@fliptrx.com,reports@fliptrx.com',subject,['Processing of Humana Intent File ','Humana Intent Exception'],'',False)	
	else:
		print("Humana Intent File created and not uploaded in DRAFT Mode")
		status = 'S'
	print(status)
	return status
	
humanapresciption()			
