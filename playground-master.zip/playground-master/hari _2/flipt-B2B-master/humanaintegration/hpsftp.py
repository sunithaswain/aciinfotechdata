import paramiko
import sys, traceback
import sendgrid
import os
import socket
from sendgrid.helpers.mail import Email, Content,Attachment, Substitution, Mail 
import urllib.request as urllib
import base64
from datetime import datetime, timedelta
from utils.sendgridemail import email_log_custom

ftpuser = os.environ['HPFTPUSER']
ftppwd = os.environ['HPFTPPWD']
ftphost = os.environ['HPFTPHOST']
port = int(os.environ['HPFTPPORT'])
status = ''
sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))

class FastTransport(paramiko.Transport):
	def __init__(self, sock):
		super(FastTransport, self).__init__(sock)
		self.window_size = 2147483647
		self.packetizer.REKEY_BYTES = pow(2, 40)
		self.packetizer.REKEY_PACKETS = pow(2, 40)
	
transport = FastTransport((ftphost, port))
try:
	transport.connect(username=ftpuser, password=ftppwd)
except Exception as e:
	type, value, etraceback = sys.exc_info()
	error=""
	x=traceback.format_exception(type, value, etraceback)
	for i in x:
		error=error+i
	content_='Dear Admin Team,\n We are not able to connect to the Humana server while we perform an SFTP transfer. An exception '+str(error)+' stops this process. Kindly look into this issue.\n \n Best regards,\n FLIPT Integration Team'
	content = Content("text/plain", content_)
	mail = Mail(Email('noreply@fliptrx.com'),'ALERT: Humana SFTP Connectivity Failure',Email('SSubramani@FliptRx.com'), content)
	host= socket.gethostname()
	receiver2=['SPal@fliptrx.com','DWagle@fliptrx.com']
	#use instance type environment variable instead of host
	if os.environ['INSTANCE_TYPE'] =='PROD': receiver2=['SPal@fliptrx.com','DWagle@fliptrx.com','hkumar@fliptrx.com','rarabati@humana.com','ET_DevReq@humana.com']
	for i in receiver2:
		mail.personalizations[0].add_to(Email(i))
	response = sg.client.mail.send.post(request_body=mail.get())
	exit()
	
sftp = paramiko.SFTPClient.from_transport(transport)

def sftptransfer(source, destination, mode):
	print(source)
	print(destination)
	transport = paramiko.Transport((ftphost, port))
	print(transport)
	print('trying to connect....')
	transport.connect(username = ftpuser, password = ftppwd)
	print('after transpport.connect...')
	sftp = paramiko.SFTPClient.from_transport(transport)
	
	if mode == 'PUT':
		#fileatt = sftp.lstat(destination)
		#print(fileatt)
		sftp.put(source, destination)
		
		try:
			fileatt = sftp.lstat(destination)
			
			print (fileatt)
			status = 'S'
			print ('Upload Successful.')
		except IOError:
			status = 'E'
			print ('File not Found in Remote')
			
	elif mode == 'GET':
		try:
			sftp.get(source, destination)
			status = 'S'
			print ('Download Successful...')
			#sftp.remove(source)
		except IOError:
			status = 'E'
			print ('File not transferred Successfully')
			
	
	sftp.close()
	transport.close()
	
	return status
	
def fileexists(filepath):
	print('begining of file exists functions....')
	transport = paramiko.Transport((ftphost, port))
	print(transport)
	print('trying to connect....')
	transport.connect(username = ftpuser, password = ftppwd)
	print('after transpport.connect...')
	sftp = paramiko.SFTPClient.from_transport(transport)
	ff=sftp.listdir_attr(path='/')
	for f in ff:
		print(f.filename)
	
	try:
		fileatt = sftp.lstat(filepath)
		print (fileatt)
		status = 'S'
		print ('File Exists')
	except IOError:
		status = 'E'
		print ('File not Found in Local Directory')

	sftp.close()
	transport.close()		
	return status
	
def multiplefilesftptransfer(source, destination, mode):
	status = 'U'
	if mode == 'GET':
		try:
			filelist = sftp.listdir(path=source+'/')
			print(filelist)
			for afile in filelist:
				sftp.get(source+'/'+afile, destination+afile)
				sftp.put(destination+afile, source+'Archive/'+afile)
				sftp.remove(source+'/'+afile)
				status = 'S'	
		except IOError:
			status = 'E'			
			print ('File not Found in Local Directory')
		
	sftp.close()
	transport.close()
	return filelist,status

def multiplefilesftptransfer_noarchive(source, destination, mode):
	status = 'U'
	if mode == 'GET':
		try:
			filelist = sftp.listdir(path=source+'/')
			print(filelist)
			for afile in filelist:
				sftp.get(source+'/'+afile, destination+afile)
				sftp.remove(source+'/'+afile)
				status = 'S'	
		except IOError:
			status = 'E'			
			print ('File not Found in Local Directory')
		
	sftp.close()
	transport.close()
	return filelist,status
	
def getfilemodifiedtime(destination):

	filelist = []
	
	attributes = sftp.listdir_attr(path=destination+'/')
	for f in attributes:
		last_modified = datetime.fromtimestamp(f.st_mtime)
		if (datetime.now()-last_modified)>=timedelta(minutes=5):
			filelist.append(f.filename)
	if len(filelist)>0:
		if os.environ['INSTANCE_TYPE']=='PROD':
			email_log_custom('noreply@fliptrx.com','SSubramani@fliptrx.com','SPal@fliptrx.com,DWagle@fliptrx.com,Deepthi.gollapudi@nttdata.com,mahaboob11.basha@nttdata.com,rarabati@humana.com,ET_DevReq@humana.com','Prescription Files not processed',[str(len(filelist))+' Prescription files uploaded to Humana SFTP server have not been processed yet.'],None,False)
	
	
#print('going to send file humana')
#sftptransfer('/home/gwadmin/FLIPTB2B/data/FLIPT001/humanaeligibilitytransfer/MemberElibility_030211230.txt','/','PUT')
#print('Trying to list files from remote server')
#filestatus =fileexists("/MemberElibility_030211230.txt")
#print(filestatus)
