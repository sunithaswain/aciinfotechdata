########################################
# !/usr/bin/env python  
# title         : humanaeligibility.py
# description   : Sends an eligibilty text file to  Humana,with employee or dependent details that have been modified after the previous execution of this script.
# author        : Deepthi
# date created  : 20181116
# date last modified    : 20190115 
# version       : 0.1
# maintainer    : Deepthi
# email         : deepthi.gollapudi@nttdata.com
# status        : Production
# Python Version: 3.5.2
# usage			: python humanaeligibility.py -d GWLABS001 -t humanaeligibility -f humanaeligibility -m DRAFT
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  
# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
   sys.path.append(rootdir)

# it will changed based on OS
rootdir = rootdir.replace('\\', '/')
path = rootdir + os.environ['CB_DATA']
 
import os
from utils import commandline
import sys
import socket
import time
from datetime import datetime
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from utils.sendgridemail import email_log
from utils.truevault import User_Class
from couchbase.n1ql import N1QLQuery
from hpsftp import sftptransfer,getfilemodifiedtime
from utils.FliptConcurrent import concurrent



cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
# path = os.environ['CB_DATA']
inputdomain,file_type,file_name,mode = commandline.main(sys.argv[1:])
req=concurrent(sys.argv[0],sys.argv[1:])
sysdate = str(datetime.now())
currentdate = datetime.now()
#currentdate = currentdate.strftime("%m%d%y%H%M%S")
currentdate = currentdate.strftime("%H%M%S%f")[:-4]
file_name = file_name+'_'+currentdate+'.txt'
first_name = ''
last_name = ''
subject = 'HUMANA'
host = socket.gethostname()

#sending HUMANA a list of all eligible users of flipt (employee and dependents)
def humanaeligibleusers():
	numusers=0
	textfile = path+'/'+inputdomain+'/'+file_type+'/'+file_name
	log = path+'/'+inputdomain+'/'+file_type+'/log/'+file_name
	remotepath = '/SUB100016423'+'/'+file_name
	print('Remote Path : '+remotepath)
	datafile = open(textfile, "w")
	logfile = open(log,"w")
	domainlist=[]
	domainlist.append(inputdomain)
	if 'GWLABS001' in domainlist: domainlist.append('FLIPT001')
	print('DomainList:',domainlist)
	#pull only modified records from flipt_person_hierarchy and along with other details write to a text file
	
	
	flipttab = N1QLQuery('select emp_flipt_person_id,dep_flipt_person_id,domain_name from `'+os.environ['CB_INSTANCE']+'` WHERE type = "flipt_person_hierarchy" and domain_name in $domain_name and hp_eligibility_updated="Y"',domain_name = domainlist)
	
	#test=[{'emp_flipt_person_id':'1001029','dep_flipt_person_id':'1001030','domain_name':'FLIPT001'},{'emp_flipt_person_id':'1000958','dep_flipt_person_id':'1000958','domain_name':'GWLABS001'}]
	#test=[{'emp_flipt_person_id':'1002713','domain_name':'FLIPT001'},{'emp_flipt_person_id':'1001029','domain_name':'FLIPT001'},{'emp_flipt_person_id':'1000958','domain_name':'GWLABS001'}]
	#test=[{'emp_flipt_person_id':'1001029','domain_name':'FLIPT001'},{'emp_flipt_person_id':'1000958','domain_name':'GWLABS001'},{'emp_flipt_person_id':'1001789','domain_name':'FLIPT001'}]
	
	flipttab.adhoc = False
	flipttab.timeout = 1000
	logfile.write("Carrier  Account   Group         CardHolder ID	   Person Code\n")
	logfile.write("===============================================================\n")
	
	for fliptrow in cb.n1ql_query(flipttab):
	#for fliptrow in test:
		#print(fliptrow)
		dep_flipt_id = str(fliptrow['dep_flipt_person_id'])
		emp_flipt_id = str(fliptrow['emp_flipt_person_id'])
		domain=fliptrow['domain_name']
		obj=User_Class(None,None)
		search_option={'full_document':True,'filter':{'domain_name':{'type':'eq','value':domain,'case_sensitive':False},'flipt_person_id':{'type':'eq','value':emp_flipt_id,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
		att,userid = obj.search_user(search_option)
		if att!=None and att['active'] == True:
			#check if the change is for employee or dependent account
			#If Employee
			if dep_flipt_id == emp_flipt_id:
				#print(emp_flipt_id)
				#print('Employee')
				
				carrier = 'FLIPT'
				#if domain=='FLIPT001': carrier = 'FLIPT2'
				account = domain
				group = str(att['group'])
				first_name = str(att['first_name'])
				last_name = str(att['last_name'])
				card_holder_id = emp_flipt_id + att['person_code']
				person_code = att['person_code']
				relationship_code = '1'
				middle_initial = ' '
				sex = att['gender']
				dob = datetime.strptime(str(att['date_of_birth']),"%Y-%m-%d %H:%M:%S")
				dob = dob.strftime('%Y%m%d')
				ssn = ''
				add1 = att['home_address_1']
				add1 = add1[0:24]
				#print(add1)
				add2 = att['home_address_2']
				add2 = add2[0:14]
				city = att['city']
				city = city[0:19]
				state = att['state']
				zip = att['zip']
				zip2 = ''
				if 'communication_option_phone' in att:
					phone=att['communication_option_phone']
				else: phone = ''
				family_id = emp_flipt_id
				from_date = datetime.strptime(str(att['coverage_effective_date']),"%Y-%m-%d %H:%M:%S")
				from_date = from_date.strftime('%Y%m%d')
				thru_date = datetime.strptime(str(att['coverage_termination_date']),"%Y-%m-%d %H:%M:%S")
				thru_date = thru_date.strftime('%Y%m%d')
				
							
				if 'communication_option_email' in att:
					email_address = str(att['communication_option_email'])
				else:
					email_address= str(att['work_email'])
				if 'language' in att and att['language']!='null':
					language_preference = att['language']
				else:
					language_preference="en"
				if 'allergy_conditions' in att:
					allergies = ','.join(att['allergy_conditions'])
				else:
					allergies=''
				if 'health_conditions' in att:
					health_conditions = ','.join(att['health_conditions'])
				else:
					health_conditions=''
				if att['employment_status'] == 'Active':
					member_status_code ='A'
				else:
					member_status_code ='C'
				
				#numusers=numusers+1
				
				
				
				datafile.write(carrier+"|"+account+"|"+group+"|"+card_holder_id+"|"+person_code+"|"+relationship_code+"|"+last_name+"|"+first_name+"|"+middle_initial+"|"+sex+"|"+dob+"|"+ssn+"|"+add1+"|"+add2+"|"+city+"|"+state+"|"+zip+"|"+zip2+"|"+phone+"|"+family_id+"|"+from_date+"|"+thru_date+"|"+email_address+"|"+member_status_code+"|"+language_preference+"|"+allergies+"|"+health_conditions+"\n")
				
				logfile.write(carrier.ljust(9)+account.ljust(9)+group.ljust(15)+card_holder_id.ljust(18)+person_code.ljust(3)+relationship_code+"\r\n")
				if mode.upper() == 'FINAL':
					cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET hp_extracted_date = $exdate , hp_eligibility_updated="N" WHERE type = "flipt_person_hierarchy" and emp_flipt_person_id = $empfid and dep_flipt_person_id = $depfid',exdate =sysdate,empfid = emp_flipt_id,depfid = emp_flipt_id)).execute()
			else:
				print('Dependent')
				for dep in att['dependents']:
					if dep_flipt_id == str(dep['flipt_person_id']):
						if dep['coverage_termination_date'] >= sysdate:
							carrier = 'FLIPT'
							account = domain
							group = str(att['group'])
							depfliptid = str(dep['flipt_person_id'])
							first_name = str(dep['first_name'])
							last_name = str(dep['last_name'])
							card_holder_id = emp_flipt_id + dep['person_code']
							person_code = dep['person_code']
							if person_code == '02':
								relationship_code = '2'
							else:
								relationship_code = '3'
							middle_initial = ' '
							if 'gender' in dep:
								sex = dep['gender']
							else: sex=' '
							dob = datetime.strptime(str(dep['date_of_birth']),"%Y-%m-%d %H:%M:%S")
							dob = dob.strftime('%Y%m%d')
							ssn = ''
							add1 = att['home_address_1']
							add1 = add1[0:24]
							add2 = att['home_address_2']
							add2 = add2[0:14]
							city = att['city']
							city = city[0:19]
							state = att['state']
							zip = att['zip']
							zip2 = ''
							if 'communication_option_phone' in dep:
								phone=dep['communication_option_phone']
								
							elif 'communication_option_phone' in att:
								phone=att['communication_option_phone']
							
							else:
								phone = ''
							family_id = emp_flipt_id
							from_date = datetime.strptime(str(dep['coverage_effective_date']),"%Y-%m-%d %H:%M:%S")
							from_date = from_date.strftime('%Y%m%d')
							thru_date = datetime.strptime(str(dep['coverage_termination_date']),"%Y-%m-%d %H:%M:%S")
							thru_date = thru_date.strftime('%Y%m%d')
							
							
							if 'communication_option_email' in dep:
								email_address = str(dep['communication_option_email'])
							elif 'email' in dep:
								email_address = str(dep['email'])
							elif 'communication_option_email' in att:
								email_address = str(att['communication_option_email'])
							else:
								email_address= str(att['work_email'])
								
								
							
							if 'language' in att and att['language']!='null':
								language_preference = att['language']
							else:
								language_preference="en"
							
							if 'allergy_conditions' in dep:
								allergies = ', '.join(dep['allergy_conditions'])
							else:
								allergies=''
								
							if 'health_conditions' in dep:
								health_conditions = ', '.join(dep['health_conditions'])
							else:
								health_conditions=''	
											
							if att['employment_status'] == 'Active':
								member_status_code ='A'
							else:
								member_status_code ='C'
							
							
						
							
							
							datafile.write(carrier+"|"+account+"|"+group+"|"+card_holder_id+"|"+person_code+"|"+relationship_code+"|"+last_name+"|"+first_name+"|"+middle_initial+"|"+sex+"|"+dob+"|"+ssn+"|"+add1+"|"+add2+"|"+city+"|"+state+"|"+zip+"|"+zip2+"|"+phone+"|"+family_id+"|"+from_date+"|"+thru_date+"|"+email_address+"|"+member_status_code+"|"+language_preference+"|"+allergies+"|"+health_conditions+"\n")
							
							logfile.write(carrier.ljust(9)+account.ljust(9)+group.ljust(15)+card_holder_id.ljust(18)+person_code.ljust(3)+relationship_code+"\r\n")
							if mode.upper() == 'FINAL':
								cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET hp_extracted_date = $exdate , hp_eligibility_updated="N" WHERE type = "flipt_person_hierarchy" and emp_flipt_person_id = $empfid and dep_flipt_person_id = $depfid',exdate =sysdate,empfid = emp_flipt_id,depfid = depfliptid)).execute()
			numusers=numusers+1		
		
	datafile.close()
	
	# SFTP
	
	if mode.upper() == 'FINAL':
		status = sftptransfer(textfile,remotepath,'PUT')
		#status = 'S'
		print(status)
		if status != 'S':
			logfile.write('File transfer failed !!! Please reprocess the File : '+file_name)
			print('File transfer failed !!! Please reprocess the File : '+file_name)
			logfile.close()
			subject = 'HumanaEligibility File Transfer Failed - '+host
			email_log('DWagle@GWLabs.com','DWagle@fliptrx.com','SSubramani@fliptrx.com,deepthi.gollapudi@nttdata.com',subject,['Processing of Humana Eligibility File '+log,'Humana Eligibility Exception'],log,True)
		else:
			#os.remove(textfile)
			logfile.close()
			print('HumanaEligibility File Transferred Successfully - '+host)
			subject = 'HumanaEligibility File Transferred Successfully - '+host
			email_log('DWagle@GWLabs.com','DWagle@fliptrx.com','SSubramani@fliptrx.com,deepthi.gollapudi@nttdata.com',subject,['Processing of Humana Eligibility File '+log,'Humana Eligibility Exception'],log,True)
	else:
		#os.remove(textfile)
		logfile.write('HumanaEligibility - Draft Mode : '+file_name)
		logfile.close()
		print('HumanaEligibility File Created - Draft Mode : '+file_name)
		subject = 'HumanaEligibility - Draft Mode - '+host
		email_log('DWagle@GWLabs.com','DWagle@fliptrx.com','SSubramani@fliptrx.com,deepthi.gollapudi@nttdata.com',subject,['Processing of Humana Eligibility File '+log,'Humana Eligibility Exception'],log,True)
	
	return numusers
		
	
numusers=humanaeligibleusers()
print('Number of Eligibile users:',numusers)
req.no_rec_received=numusers

req.close()       
