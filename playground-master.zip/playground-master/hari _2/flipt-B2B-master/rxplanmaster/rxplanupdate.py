########################################
# !/usr/bin/env python  
# title         : rxplanupdate.py
# description   : Update rxplan document from file data
# author        : Disha
# date created  : 20180101
# date last modified    : 20190118 12:16
# version       : 0.1
# maintainer    : hari
# email         : hrajendran@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage         : python rxplanupdate_hari.py -d GWLABS001 -t rxplan_master -f rxplan_master01022018.xlsx -m DRAFT
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  1.1            hari         20190118    Added log file, mode support logic to load the data in database
#  
# #######################################
if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
   sys.path.append(rootdir)

# it will changed based on OS
rootdir = rootdir.replace('\\', '/')
path = rootdir + os.environ['CB_DATA']
 
import pandas as pd
import pprint
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.n1ql import N1QLQuery
import os
import codecs
from couchbase import FMT_JSON
from utils import commandline
import sys
from datetime import datetime

domain,filetype,filename,mode=commandline.main(sys.argv[1:])
cluster=Cluster(os.environ['CB_URL'])
auth=PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(auth)
cb=cluster.open_bucket(os.environ['CB_INSTANCE'])

# add log file
logpath=path+'//'+domain+'//'+filetype+'//log//log'+datetime.now().strftime("%Y%m%d%H%M")+'.txt'
logfile = open(logpath,"w")
logfile.write("=============================================================="+"\r\n")
logfile.write("=============== rxplan document Update Log ================="+"\r\n")		
logfile.write("Start time is "+ str(datetime.now()) +"\r\n")

def rxplan():
        
        doc_count = 0
        df=pd.DataFrame()
        rx=pd.read_excel(path+'/'+domain+'/'+filetype+'/'+filename)
        logfile.write("No of records in File "+ str(rx.shape[0]) +"\r\n")
        for i,r in rx.iterrows():
                d=dict()
                for c in list(rx):
                        cnew=c.replace(' ','_').lower()
                        d[cnew]=str(r[c]).encode('utf-8').decode('utf-8')

                d['type']='rxplan_master'
                print(d)
                doc_count += 1
                if mode.upper().strip()=='FINAL':
                        cb.upsert(str(cb.counter('docid',delta=1).value),d, format=FMT_JSON)
        return doc_count
total_records_update = rxplan()
logfile.write('%s records are updated \r\n'%total_records_update)
logfile.write("End time is "+ str(datetime.now()) +"\r\n")

logfile.write("=============================================================="+"\r\n")
logfile.close()
