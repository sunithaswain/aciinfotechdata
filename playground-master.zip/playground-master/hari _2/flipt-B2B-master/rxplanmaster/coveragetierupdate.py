########################################

# !/usr/bin/env python 

# title : coveragetierupdate.py
# description : Update coverage tier mapping update
# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  python coveragetierupdate.py -d GWLABS001 -t coverage_tier -f coverage_tier.xlsx -m DRAFT
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
   sys.path.append(rootdir)

# it will changed based on OS
rootdir = rootdir.replace('\\', '/')
path = rootdir + os.environ['CB_DATA']
 
import pprint
from datetime import datetime
import socket
import os
import codecs
import sys

import pandas as pd
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.n1ql import N1QLQuery
from couchbase import FMT_JSON

from utils.sendgridemail import email_log
from utils import commandline as commandline

# import app.common.commandline as commandline
# from app.common.sendgridemail import email_log

domain,file_type,file_name,mode=commandline.main(sys.argv[1:])
cluster=Cluster(os.environ['CB_URL'])
auth=PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(auth)
cb=cluster.open_bucket(os.environ['CB_INSTANCE'])

# modified by Hari on 27/12/2018
# path = os.environ['CB_DATA']
host = socket.gethostname()
currentdate = datetime.now()
currentdate = currentdate.strftime("%m%d%y%H%M%S")
log = path+'/'+domain+'/'+file_type+'/log/'+"claimproc"+currentdate+'.txt'
logfile = open(log,"w")


def rxplan():
        
        df=pd.DataFrame()
        rx=pd.read_excel(path+'/'+domain+'/'+file_type+'/'+file_name)
        ite = 0
        for i,r in rx.iterrows():
                d=dict()
                for c in list(rx):
                        cnew=c.replace(' ','_').lower()
                        d[cnew]=str(r[c]).encode('utf-8').decode('utf-8')

                d['type']='coverage_tier'
                print(d)
                # modified by Hari  on 27/12/2018
                if mode.strip().upper() == 'FINAL':
                        cb.upsert(str(cb.counter('docid',delta=1).value),d, format=FMT_JSON)

                ite += 1
		
        logfile.write('%s records are updated'%ite)
        # added by Hari on 27/12/2018
        if mode.strip().upper() == 'DRAFT':
                logfile.write('coverage tier update - Draft Mode :'+host+file_name)
                subject = 'coverage tier update - Draft Mode :'+host
        else:
                logfile.write('coverage tier update - Final Mode :'+host+file_name)
                subject = 'coverage tier update - Final Mode :'+host
        
        logfile.close()
        email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','SSubramani@GWLabs.com',subject,['coverage tier update File '+log,'coverage tier update Exception'],log,True)

rxplan()
