########################################
# !/usr/bin/env python 

# title : send_humana_price.py
# description : Humana: Send email product files to pricing team
# author : Hari
# date created : 2019/01/15
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Dev
# Python Version: 3.5.2
# usage         :  python send_humana_price.py -d GWLABS001 -t humanaprice -f humanlog.txt -m DRAFT
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


# #######################################
if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
   sys.path.append(rootdir)

# it will changed based on OS
rootdir = rootdir.replace('\\', '/')
path = rootdir + os.environ['CB_DATA']
 
import boto3
import sys, traceback
import shutil, os
from datetime import datetime
import socket
import base64

from utils.sendgridemail import email_log,email_log_zip
from utils import commandline

from utils.awssftpfileops import copyfile

import boto3
import uuid
import sendgrid
from sendgrid.helpers.mail import Email, Content,Attachment, Substitution, Mail 

domain_name,file_type,filename,mode=commandline.main(sys.argv[1:])

logfilename='SFTPFileOpsLog'+str(datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())+'.txt'

log_path = path+'/'+domain_name+'/'+file_type+'/log/'
if not os.path.isdir(log_path): os.makedirs(log_path)

logfile = open(log_path+logfilename,"w")

logfile.write("Started to download file from S3")
destination = path+'/'+domain_name+'/'+file_type+'/humanaproduct_price/'
zip_filename = path+'/'+domain_name+'/'+file_type+'/humanaproduct_price'

# AWS File location
source_path = 'prodhumanaint/uploads/shipments/'
_PREFIX = source_path+'Specialty_Daily_Status_Report'
_PREFIX2 = source_path+'Traditional_Daily_Status_Report'

ACCESS_KEY = os.environ['AWS_ACCESS_KEY_ID']
SECRET_KEY = os.environ['AWS_SECRET_ACCESS_KEY']
_BUCKET_NAME = os.environ['AMAZON_SFTP_BUCKET']

my_resource = boto3.resource('s3')
bucketname = my_resource.Bucket(os.environ['AMAZON_SFTP_BUCKET'])
bucket = bucketname.name

# print(my_resource)
# print(bucketname)
client = boto3.client('s3', aws_access_key_id=ACCESS_KEY,
                            aws_secret_access_key=SECRET_KEY)

def ListFiles(client):
    """List files in specific S3 URL"""
    response = client.list_objects(Bucket=_BUCKET_NAME, Prefix=_PREFIX)
    response2 = client.list_objects(Bucket=_BUCKET_NAME, Prefix=_PREFIX2)

    for content in response.get('Contents', []):
        yield content.get('Key')
        
    for content in response2.get('Contents', []):
        yield content.get('Key')

def send_files_from_s3():
    try:
        if os.path.isdir(destination) == False:
            os.makedirs(destination)
        file_list = ListFiles(client)
        files_count = sum(1 for x in file_list)
        if files_count <= 0: 
            print("No records to send email")
            return 
        for file in file_list:
            full_file_path = file
            file_path = os.path.split(file)[0]
            file_name = os.path.split(file)[-1]
            # print(destination+file_name)
            client.download_file(_BUCKET_NAME, full_file_path, destination+file_name)
            # print(source_path+'archive')
            # client.copy(copy_source, bucket, source_path+'archive')
            copyfile(file_path,file_name,source_path+'archive')
            logfile.write(destination+file_name)
            if mode.strip().upper() == 'FINAL' and os.environ['INSTANCE_TYPE']=='PROD':
                client.delete_object(Bucket=_BUCKET_NAME, Key=full_file_path)
            
        logfile.write("Downloaded file from S3")

        shutil.make_archive(zip_filename, 'zip', destination)
        shutil.rmtree(destination)

        # ----------------------Send Email code---------------------------------------
        if mode.strip().upper() == 'FINAL' and os.environ['INSTANCE_TYPE']=='PROD':
            receiver1 = "LPeysekhman@fliptrx.com"
            receiver_emails="TPerkins@fliptrx.com,HKumar@fliptrx.com,spal@fliptrx.com,kyang@fliptrx.com,FliptIntegration@fliptrx.com"
        else:
            receiver1 = 'HRajendran@fliptrx.com'
            receiver_emails = "PMuthanai@fliptrx.com"
            
        sender = 'noreply@fliptrx.com'
        email_subject = "Flipt: Humana product price list file"
        email_body = "Hi, \n   Humana product price list file is attached with this mail. \n \n Best regards,\n FLIPT Integration Team"
        print(zip_filename+'.zip')
        email_log_zip(sender,receiver1,receiver_emails,email_subject,email_body,zip_filename+'.zip',True)
        logfile.write("Sent email to price team with file")
    except Exception:
        logfile.write(str(traceback.print_exc()))

    logfile.close()

send_files_from_s3()