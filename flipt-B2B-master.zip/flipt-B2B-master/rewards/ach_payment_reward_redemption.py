########################################
# !/usr/bin/env python

# title : ach_payment_reward_redemption.py
# description : Update Reward Redemption by ACH Payment - Integration Changes
# author : Haripradeep
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  python ach_payment_reward_redemption.py -t ach_payment -m final
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------
# 1.1     Rajesh
# #######################################
from utils import commandline
import logging
from collections import defaultdict
from utils.sendgridemail import email_log
from utils.aws_sftp import *
from utils.helper_functions import *


domain, file_type, file_name, mode = commandline.main(sys.argv[1:])
data_path = os.environ['CB_DATA']


class Ach_Payment_Reward_Redemption:
    def __init__(self):
        from datetime import datetime

        self.proc_env = os.environ['INSTANCE_TYPE']
        self.str_date_now = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.date_now = datetime.now().isoformat()
        self.errored_files = []

        self.logfile = f'ach_payment_log_{self.str_date_now}'
        self.LOG = setup_logging_path('ACH_PAYMENT', self.logfile, 'ACH_PAYMENT')
        self.cb = cb_authenticate()
        self.SFTP = AWS_SFTP(self.proc_env, 'FIRSTDATA')
        self.SFTP.sftp_getfilelist(self.SFTP.sftp_home)
    # end constructor

    def payment_reward_redemption(self):
        from couchbase.n1ql import N1QLQuery
        from couchbase import FMT_JSON
        import pandas as pd
        import traceback

        print('started ach payment_reward_redemption function')
        self.LOG.info('started ach payment_reward_redemption function')
        
        total_records = 0
        failed_records_list = []
        processed_records = 0

        if len(self.SFTP.sftp_file_list) == 0:
            print(f'No input file found in SFTP for {self.proc_env}')
            self.LOG.info(f'No input file found in SFTP for {self.proc_env}')
            sys.exit(1)
        else:
            try:
                localpath = f"{data_path}/{file_type}/"

                for fname in self.SFTP.sftp_file_list:
                    stat, destination_filename = self.SFTP.sftptransfer(None, localpath, 'GET',
                                                                        searchstr=fname,
                                                                        delete=False,
                                                                        loghndl=self.LOG)
                    if stat == 'S':
                        print(f"processing: {localpath}{destination_filename}")
                        self.LOG.info(f"Processing ACH file: {localpath}{destination_filename}")
                        local_fullpth = f"{localpath}{destination_filename}"
                        if self.SFTP.check_inputfiletype(local_fullpth) == 'E':
                            # archive the file
                            stat, _ = self.SFTP.sftptransfer(local_fullpth, self.SFTP.sftp_archive, 'PUT',
                                                             loghndl=self.LOG)
                            stat, _ = self.SFTP.sftpremove(destination_filename)
                            os.unlink(local_fullpth)
                            self.errored_files.append(destination_filename)
                            continue

                        status = 'S'
                        if '.csv' in local_fullpth:
                            try:
                                df_first_data = pd.read_csv(local_fullpth, encoding='utf-8', quotechar='"')
                            except:
                                df_first_data = pd.DataFrame()
                                status = 'E'
                        else:
                            try:
                                df_first_data = pd.read_excel(local_fullpth, encoding='utf-8')
                            except:
                                df_first_data = pd.DataFrame()
                                status = 'E'

                        if status == 'E':
                            self.errored_files.append(destination_filename)
                            stat, _ = self.SFTP.sftptransfer(local_fullpth, self.SFTP.sftp_archive, 'PUT',
                                                             loghndl=self.LOG)
                            stat, _ = self.SFTP.sftpremove(destination_filename)
                            os.unlink(local_fullpth)
                            continue

                        df_first_data.columns = df_first_data.columns.str.lower()
                        df_first_data.columns = df_first_data.columns.str.replace(' ', '_', regex=True)

                        total_records = df_first_data.shape[0]
                        query = N1QLQuery('SELECT META().id as id, payee_record_id, transaction_number FROM `' +
                                          os.environ['CB_INSTANCE'] + '` WHERE type="ach_confirmation"')
                        query.timeout = 7200
                        exists_records = defaultdict(list)
                        for r in self.cb.n1ql_query(query):
                            print(r.get('id'))
                            self.LOG.info(f"Current id: {r.get('id')}")
                            exists_records[r.get('payee_record_id')] = r.get('id')
                            exists_records[r.get('transaction_number')] = r.get('create_date')
                            exists_records['payee_record_id'].append(r.get('payee_record_id'))
                            exists_records['transaction_number'].append(r.get('transaction_number'))

                        df_first_data = df_first_data.fillna('')
                        for row in df_first_data.itertuples():
                            try:
                                d = dict()
                                d['type'] = 'ach_confirmation'
                                d['program_id'] = row.program_id
                                d['payee_record_id'] = row.payeerecordid
                                d['transaction_number'] = row.transaction_number
                                d['payee_email_address'] = str(row.payee_email_address).strip()
                                d['ach_outgoing_file_date'] = str(row.ach_outgoing_file_date).strip()
                                d['payment_status'] = str(row.payment_status).strip()
                                d['payment_reason'] = str(row.payment_reason).strip()
                                d['payment_status_date'] = str(row.payment_status_date).strip()
                                d['payment_date'] = str(row.payment_date).strip()
                                d['payment_amount'] = str(row.payment_amount).strip()
                                d['ach_rejection_reason'] = str(row.ach_rejection_reason).strip()
                                d['control_number'] = str(row.control_number).strip()
                                d['reference_id'] = row.reference_id
                                d['dispersement_date'] = str(row.dispersement_date).strip()
                                str_payee_record_id = d['payee_record_id']
                                str_transaction_number = d['transaction_number']
                                if (str_payee_record_id in exists_records['payee_record_id'] and
                                        str_transaction_number in exists_records['transaction_number']):
                                    meta_id = exists_records[d['payee_record_id']]
                                    create_date_based_id = exists_records[d['transaction_number']]
                                    d['update_date'] = self.date_now
                                    d['create_date'] = create_date_based_id

                                    if str(mode).upper() == 'FINAL':
                                        self.cb.upsert(meta_id, d, format=FMT_JSON)
                                    else:
                                        print(f'updating in draft mode and records are {d}')
                                        self.LOG.info(f'updating in draft mode and records are {d}')
                                else:
                                    d['create_date'] = self.date_now
                                    if str(mode).upper() == 'FINAL':
                                        self.cb.upsert(str(self.cb.counter('docid',delta=1).value), d, format=FMT_JSON)
                                    else:
                                        print(f'new record in draft mode and records are {d}')
                                        self.LOG.info(f'new record in draft mode and records are {d}')

                                if d['payment_status'].lower() == 'disbursed':
                                    rewardtransaction_status = 'confirmed'
                                    if str(mode).upper() == 'FINAL':
                                        cquery = N1QLQuery(f"update `{os.environ['CB_INSTANCE']}` " +
                                                           f"set status='{rewardtransaction_status}' " +
                                                           f"where type='rewardtransaction' " +
                                                           f"and transaction_id = '{str_transaction_number}")

                                        cquery.timeout = 3600
                                        self.cb.n1ql_query(cquery).execute()
                                    else:
                                        print('payment_status is disbursed running in draft mode ' +
                                              f'and records are {d}')
                                        self.LOG.info('payment_status is disbursed running in draft mode and ' +
                                                      f'records are {str_transaction_number}')

                                elif d['payment_status'].lower() == 'void':
                                    rewardtransaction_status = 'error'
                                    error_reason = 'ach_rejection_reason'

                                    if str(mode).upper() == 'FINAL':
                                        cquery = N1QLQuery(f"update `{os.environ['CB_INSTANCE']}` " +
                                                           f"set status='{rewardtransaction_status}', " +
                                                           f"error_reason = '{error_reason}' " +
                                                           "where type='rewardtransaction' " +
                                                           f"and transaction_id = '{str_transaction_number}'")

                                        cquery.timeout = 3600
                                        self.cb.n1ql_query(cquery).execute()
                                    else:
                                        print(f'payment_status is void running in draft mode and records are {d}')
                                        self.LOG.info('payment_status is void running in draft mode ' +
                                                      f'and records are {str_transaction_number}')
                                processed_records += 1
                            except:
                                failed_records_list.append(int(str(row.transaction_number).strip()))
                                print(traceback.format_exc())
                                self.LOG.error(traceback.format_exc())

                        # to move processed input file to downloads folder
                        self.SFTP.sftptransfer(local_fullpth, self.SFTP.sftp_archive, 'PUT')
                        self.SFTP.sftpremove(destination_filename, loghndl=self.LOG)
                        os.unlink(local_fullpth)

                        print(f'ACH process completed for < {destination_filename}> ')
                        self.LOG.info(f"ACH process completed for < {destination_filename} >")

                    else:  # error downloading the file
                        self.errored_files.append(destination_filename)
                        self.SFTP.sftpremove(destination_filename)
                        self.LOG.error(f"Unable to download file < {destination_filename} > to SFTP location")
                        continue
            except:
                print(traceback.format_exc())
                self.LOG.error(traceback.format_exc())

            self.LOG.info('completed ach payment_reward_redemption function')
            failed_records = total_records - processed_records
            self.LOG.info(f'total_records -- {total_records}')
            self.LOG.info(f'processed_records -- {processed_records}')
            if failed_records > 0:
                self.LOG.info(f'failed_records -- {failed_records}')

            if len(failed_records_list) != 0:
                self.LOG.info(f'failed_records_transaction_number_list -- {failed_records_list}')

            print('ach payment_reward_redemption completed')
            sender = 'noreply@fliptrx.com'
            receiver = 'FliptIntegration@fliptrx.com'
            subject = 'Reward Redemption by ACH Payment - Completed'

            if failed_records > 0:
                body = ['\tSome records failed to process and those details are as below \n ' +
                        f'\ttotal records -- {total_records}\n \tprocessed records -- {processed_records} \n ' +
                        f'\tfailed records -- {failed_records} \n ' +
                        f'\tfailed records transaction number list -- {failed_records_list} \n',
                        os.environ['INSTANCE_TYPE']]
            else:
                body = ['\tRecords successfully processed and those details are as below \n ' +
                        f'\ttotal records -- {total_records}\n \tprocessed records -- {processed_records} \n ' +
                        f'\tfailed records -- {failed_records}  \n', os.environ['INSTANCE_TYPE']]
            email_log(sender, receiver, '', subject, body, self.LOG.handlers[0].baseFilename)

            logfile = self.LOG.handlers[0].baseFilename
            #logging.shutdown(self.LOG.handlers)
            #del self.LOG
            return logfile
    # end method
# end class


if __name__ == '__main__':
    # file_path = os.path.join(data_path, file_type, file_name)
    obj = Ach_Payment_Reward_Redemption()
    log_fpath = obj.payment_reward_redemption()

    obj.SFTP.sftptransfer(log_fpath, obj.SFTP.sftp_download, 'PUT')
    os.unlink(log_fpath)
# end main
