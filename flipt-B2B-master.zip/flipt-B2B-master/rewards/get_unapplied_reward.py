
# !/usr/bin/env python
# -*- coding: utf-8 -*-

# title : get_unapplied_reward.py
# description : which would run daily to identify rewards which were not created for filled prescriptions.


# author : Hari
# date created : 28/05/2019
# last  modified : 29/05/2019
# version : 1
# maintainer : Hari
# email : -
# status : Development
# Python Version: 3.5.2
# usage         :  #python get_unapplied_reward.py -d GWLABS001 -t prescription -m DRAFT
# Revisions:
# Version RevisedBy Date Change Jira description  
# ------- --------- -------- ------------------
#  Jira B2B-696
# date format changed for Jira B2B-849
# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import os
import sys, csv
import pandas as pd
from tqdm import tqdm
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
import couchbase.subdocument as SD
from couchbase import FMT_JSON
import requests
import json
import datetime
from utils import commandline
from utils.sendgridemail import email_log_custombody

cluster = Cluster(os.environ['CB_URL'])
bucket_name=os.environ['CB_INSTANCE']
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(bucket_name)


path = os.environ['CB_DATA']
domain,file_type,file_name,mode = commandline.main(sys.argv[1:])

csv_path = path+'/'+domain+'/'+file_type+'/'+'unapplied_rewards.csv'

current_date = datetime.datetime.now()
displaydatetime = current_date.strftime("%Y%m%d%H%M")
iso_current_date = current_date.isoformat()

current_year = datetime.datetime.now().year
query=N1QLQuery("Select * from `"+bucket_name+"` WHERE type='prescription' and rx_status='Filled' and tonumber(rewards)>0"
                " and prescription_id not in (select raw b.prescription_id from `"+bucket_name+"` b "
                "where b.type='rewardtransaction') and date_part_str(update_date,'year')="+str(current_year) )
# print("query")
# print(query)
query.adhoc = False
query.timeout = 7200
listOfDicts = []
for row in cb.n1ql_query(query):
    listOfDicts.append(row[bucket_name])

    prescription_id = row[bucket_name]['prescription_id']
    claim_flipt_person_id = row[bucket_name]['rx_flipt_person_id']
    package_size = row[bucket_name]['package_size']
    package_size = float(package_size) if '.' in package_size else int(package_size)
    quantity = row[bucket_name]['quantity']
    quantity = float(quantity) if '.' in quantity else int(quantity)
    prescription_quantity = package_size * quantity
    reward_amt = row[bucket_name]['rewards']
    domain = row[bucket_name]['domain']
    drug_name = row[bucket_name]['drug']

    rewrec={}
    	
    rewid = cb.counter('rewardtransaction_counter',delta=1).value
    rewardsid = 'rewardtransaction::'+str(rewid)
    
    rewrec['create_date'] = iso_current_date
    rewrec['created_by'] = claim_flipt_person_id
    rewrec['flipt_person_id'] = claim_flipt_person_id
    rewrec['prescription_id'] = str(prescription_id).strip()
    rewrec['id'] = rewardsid
    rewrec['type'] = 'rewardtransaction'
    rewrec['update_date'] = iso_current_date
    rewrec['updated_by'] = claim_flipt_person_id
    rewrec['domain'] = domain
    rewrec['reward_amount'] = reward_amt
    rewrec['reward_date'] = iso_current_date
    rewrec['drug_name'] = drug_name
    
    if mode.upper() == 'FINAL':
        cb.upsert(rewardsid, rewrec,format=FMT_JSON)
        print("Rewards Inserted  %s           : Yes"%rewardsid)
        # rewardsfound=False
        # rewardscheck = N1QLQuery('Select tonumber(reward_amount) reward_amount, id from `'+os.environ['CB_INSTANCE']+'` where type="rewardtransaction" and prescription_id=$pid',pid=str(prescription_id).strip())
        # for rewardscheckrow in cb.n1ql_query(rewardscheck):
        #     rewardsfound=False
        #     if rewardscheckrow['reward_amount']==0:
        #         rewrec['reward_amount']=reward_amt
        #         cb.upsert(rewardsid, rewrec,format=FMT_JSON)
        # if not rewardsfound and updated_reward_amt>0: cb.upsert(rewardsid, rewrec,format=FMT_JSON)
            
#     print(row)

# print(listOfDicts)
keys = [i for s in [d.keys() for d in listOfDicts] for i in s]
# print(keys)
if keys != []:
    # print("key is not empty")
    if os.path.isfile(csv_path): 
        os.remove(csv_path)
    with open(csv_path, 'w', newline='') as output_file:
        dict_writer = csv.DictWriter(output_file, fieldnames=keys, delimiter=',')
        dict_writer.writeheader()
        dict_writer.writerows(listOfDicts)

    send_to = 'noreply@fliptrx.com'
    subject = 'Unapplied rewards prescription details'

    body='Hi,\n There are list of unapplied rewards prescription details attached in this email has started at '+str(current_date)+'. \n \n Best regards,\n FLIPT Integration Team'
    # print(body)
    email_log_custombody(send_to,'fliptintegration@fliptrx.com', send_to, subject, body, csv_path, True)
