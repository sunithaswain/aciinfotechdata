########################################
# !/usr/bin/env python
# title : aetnamemberidupdate.py
# description : Update member details(member ID,relationship code) of
# 				employees/dependents for their corresponding Aetna accounts
# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage: With Filename: python aetnamemberidupdate.py -d GWLABS001 -t Aetna -f Aetnamembers02012019.xlsx -m DRAFT
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------
# 1.1		Rajesh	2/6/2020	Fix existing issues
# #######################################

import re
import os
import sys
import json
import copy
import base64
import pprint
import socket
import requests
from requests.auth import HTTPBasicAuth
from datetime import datetime
import shutil
from pathlib import Path

import pandas as pd
from couchbase.n1ql import N1QLQuery
import couchbase.subdocument as SD
from couchbase import FMT_JSON

from utils import commandline
from utils.sendgridemail import email_log
from utils.truevault import User_Class
from utils.FliptConcurrent import concurrent
from utils.helper_functions import *
from utils.aws_sftp import *

orig_cmdopts = copy.deepcopy(sys.argv)

cmdline_args = process_alt_cmdline(additional=[['-d', '--domain_name', 'domain name for process', True],
											   ['-t', '--file_type', 'type of data being processed', True]])

req = concurrent(orig_cmdopts[0], orig_cmdopts[1:])

domain_list = [cmdline_args['domain_name']]

# modified by Hari on 27/12/2018
path = os.environ['CB_DATA']
host = socket.gethostname()
currentdate = datetime.now()
currentdate = currentdate.strftime("%m%d%y%H%M%S")
log = f"{path}/{cmdline_args['domain_name']}/{cmdline_args['file_type']}/log/"
log += f"Aetna_memberID_update" + currentdate + '.txt'
logger = setup_logging_path('AETNA', 'Aetna_memberID_update' + currentdate, 'memberupdate')

# setup SFTP handler
sftp_hndlr = AWS_SFTP(cmdline_args['domain_name'], 'ELIGIBILITY')
sftp_hndlr.sftp_getfilelist(sftp_hndlr.sftp_home)

if 'GWLABS001' in domain_list:
	domain_list.append('FLIPT001')

localpath = f"{path}/{cmdline_args['domain_name']}/{cmdline_args['file_type']}/"
stat, filename = sftp_hndlr.sftptransfer(None, localpath, 'GET', searchstr='Aetna', loghndl=logger)
if stat == 'E':
    print("No files found or invalid naming convention!!")
    logger.info("Aetna member file not found!!")
    sys.exit(-1)

logger.info(f"Processing data for: {domain_list}")
infile_name = f"{path}/{cmdline_args['domain_name']}/{cmdline_args['file_type']}/{filename}"
logger.info("Reading input file: " + infile_name)
if 'xlsx' in infile_name:
	aetna_dataframe = pd.read_excel(infile_name)
else:
	aetna_dataframe = pd.read_csv(infile_name)

cb = cb_authenticate()
bucket_name = os.environ['CB_INSTANCE']
api_key = os.environ['TV_API_KEY']
error_log = pd.DataFrame()
number_of_members = 0
cols = {"Enrollee Social Security Number": "ee_ssn", "First Name": "first_name",
		"Last Name": "last_name","Birth Date": "birth_date", "Employee CUMB ID": "cumbid",
		"Sequence": "sequence","Relationship Code": "relationship",
		"Original Effective Date": "orig_eff_date", "Dependent CUMB ID": "dep_cumbid",
		"Home Phone Number": "home_phone","Work Phone Number": "work_phone",
		"Gender Code":"gender"}

aetna_dataframe.rename(columns=cols, inplace=True)
current_time = datetime.strptime(str(datetime.now()), "%Y-%m-%d %H:%M:%S.%f").isoformat()
aetna_dataframe = aetna_dataframe.loc[:,['ee_ssn', 'first_name', 'last_name', 'birth_date',
										 'cumbid', 'sequence','relationship', 'orig_eff_date',
										 'dep_cumbid', 'home_phone', 'work_phone', 'gender']]

logger.info("Cleaning up DataFrame details")
aetna_dataframe['orig_eff_date'] = aetna_dataframe['orig_eff_date'].\
	apply(lambda x:  datetime.strptime(str(x), '%Y-%m-%d 00:00:00'))
aetna_dataframe['cumbid'] = aetna_dataframe['cumbid'].apply(lambda x: x.replace('W', ''))
aetna_dataframe['dep_cumbid'] = aetna_dataframe['dep_cumbid'].\
	apply(lambda x: str(int(x)) if pd.isnull(x) == False else '')
aetna_dataframe['sequence'] = aetna_dataframe['sequence'].apply(lambda x: str(x).zfill(2))
aetna_dataframe['ee_ssn'] = aetna_dataframe['ee_ssn'].apply(lambda x: str(x).zfill(9))
aetna_dataframe['home_phone'] = aetna_dataframe['home_phone'].\
	apply(lambda x: str(int(x)) if pd.isnull(x) == False else '')
aetna_dataframe['work_phone'] = aetna_dataframe['work_phone'].\
	apply(lambda x: str(int(x)) if pd.isnull(x) == False else '')
aetna_dataframe['birth_date'] = aetna_dataframe['birth_date'].\
	apply(lambda x: datetime.strftime(datetime.strptime(str(x),'%Y-%m-%d 00:00:00'),
																	  '%Y-%m-%d 00:00:00'))
aetna_dataframe.fillna('', inplace=True)
aetna_dataframe.drop_duplicates(inplace=True)

running_count = 0
req.no_rec_received = aetna_dataframe.shape[0]

for key, member_group in aetna_dataframe.groupby(['ee_ssn']):
	# gather all rows for primary member by employee_ssn
	group_data = pd.DataFrame()
	for seq in set(list(member_group['sequence'])):
		max_date = max(list(member_group[member_group['sequence'] == seq]['orig_eff_date']))
		group_data = group_data.append(member_group.loc[(member_group['sequence'] == seq) &
														(member_group['orig_eff_date'] == max_date),:],
									   ignore_index=True)

	group_data.reset_index(drop=True, inplace=True)
	ordered_group = group_data.loc[group_data['sequence'] == '01', ['birth_date', 'ee_ssn', 'first_name',
											'last_name', 'sequence', 'cumbid',
											'orig_eff_date']]
	ordered_group.reset_index(drop=True, inplace=True)

	searched = False
	attr_list = []
	user_id_list = []
	att_index = 0
	num_errors = 0
	employee_found = False

	for index, row_data in group_data.iterrows():
		if not searched:
			obj = User_Class(None, None, cb_handle=cb)
			for idx, row in ordered_group.iterrows():
				for domain in domain_list:
					search_option = {'full_document': True,
									 'filter':
										 {
											 'employee_ssn':
												 {
													 'type': 'eq',
													 'value': 'xxx-xx-' + str(key)[-4:],
													 'case_sensitive' :False
												 },
											 'domain_name':
												 {
													 'type': 'eq',
													 'value': domain,
													 'case_sensitive': False
												 },
											 'date_of_birth':
												 {
													 'type': 'eq',
													 'value': str(row['birth_date']),
													 'case_sensitive': False
												 },
											 '$tv.status':
												 {
													 'type': 'eq',
													 'value': 'ACTIVATED'
												 }
										 },
									 'filter_type': 'and'
									 }
					# -- using search user.  This function has the code for grabbing the
					# required eligibility attributes and putting at the top level
					# commented the call to search_user_id
					# (attlist1, userid) = obj.search_user_id(search_option)
					(member_attr, user_id) = obj.search_user(search_option)
					if member_attr is not None:
						break
				# end search loop

				# if no truevault record was found after searching both GWLABS and FLIPT domains
				# log the error and go to next record
				if member_attr is None:
					continue

				attr_list.append(member_attr)
				user_id_list.append(user_id)
				if len(attr_list) != 0:
					searched = True
					break
			if searched is False:
				break
		
		if row_data['sequence'] == '01':
			if employee_found:
				continue

			for att_rec in attr_list:
				if (row_data['first_name'] == att_rec['first_name'] and
					row_data['last_name'] == att_rec['last_name']) or \
						(row_data['birth_date'] == att_rec['date_of_birth']):
					employee_found = True

					emp_flipt_person_id = att_rec['flipt_person_id']
					carrier = [{'ins_carrier_name': 'Aetna',
								'ins_carrier_member_id': str(row_data['cumbid']),
								'ins_relationship_code': str(row_data['sequence']),
								'group_number':'865944'}]

					try:
						carrier[0]['coverage_tier_name'] = str(att_rec['coverage_tier_name'])
					except KeyError:
						carrier[0]['coverage_tier_name'] = att_rec['eligibility'][-1]['coverage_tier_name']

					try:
						carrier[0]['benefit_plan_name'] = str(att_rec['benefit_plan_name'])
					except KeyError:
						carrier[0]['benefit_plan_name'] = att_rec['eligibility'][-1]['benefit_plan_name']

					phone_list = []
					
					if row_data['home_phone'].isdigit() and int(row_data['home_phone']) != 0:
						phone_list.append(row_data['home_phone'])

					if row_data['work_phone'].isdigit() and (row_data['home_phone'] != row_data['work_phone']
													  or int(row_data['work_phone']) != 0):
						phone_list.append(row_data['work_phone'])

					logger.debug(f"Member detail before modify: {att_rec}")
					att_rec['carrier_phonenumbers'] = phone_list
				
					query = N1QLQuery('Select meta().id,dep_flipt_person_id from `' + bucket_name +
									  '`where type="flipt_person_hierarchy" ' +
									  'and dep_flipt_person_id=$flipt_id',
									  flipt_id=str(emp_flipt_person_id))

					logger.debug(f"Member detail after modify: {att_rec}")
					for query_res in cb.n1ql_query(query):
						if cmdline_args['mode'].upper().strip() == 'FINAL':
							cb.mutate_in(query_res['id'], SD.upsert('ins_carrier', carrier))

						else:
							logger.debug(f"CARRIER: {carrier}")
					running_count += 1
					continue
				att_index += 1
				
		else:
			dependent_found = False
			name_error = False
			dep_group = pd.DataFrame()

			dep_index = 0
			for dep in member_attr['dependents']:
				if row_data['birth_date'] == dep['date_of_birth']:
					dep_dict = dict(dep)
					dep_dict['dep_index'] = int(dep_index)
					dep_group = dep_group.append(dep_dict, ignore_index=True)
				dep_index += 1

			flipt_id = ''
			dep_group.reset_index(drop=True, inplace=True)
			if len(dep_group) == 1:
				dependent_found = True
				flipt_id = dep_group['flipt_person_id'].values[0]
				member_attr['dependents'][int(dep_group['dep_index'].values[0])]['gender'] = row_data['gender']

			elif len(dep_group) > 1:
				for ind, dep_row in dep_group.iterrows():
					if (dep_row['first_name'] == row_data['first_name'].strip() and
						dep_row['last_name'] == row_data['last_name'].strip()):
						dependent_found = True
						flipt_id = dep_row['flipt_person_id']
						member_attr['dependents'][int(dep_row['dep_index'])]['gender'] = row_data['gender']
						break

			if not dependent_found:
				error_log = error_log.append({'Aetna First Name': row_data['first_name'],
											'Aetna Last Name': row_data['last_name'],
											'TV First Name': '',
											'TV Last Name': '',
											'Aetna Member ID': row_data['dep_cumbid'],
											'Error': 'Dependent Name Not Matching Truevault'},
										   ignore_index=True)
				name_error = True
				num_errors += 1
			# error logging when dependent not found

			if dependent_found:
				carrier = [{'ins_carrier_name': 'Aetna',
							'ins_carrier_member_id': str(row_data['dep_cumbid']),
							'ins_relationship_code': str(row_data['sequence']),
							'group_number':'865944'}]

				try:
					carrier[0]['coverage_tier_name'] = str(member_attr['coverage_tier_name'])
				except KeyError:
					carrier[0]['coverage_tier_name'] = member_attr['eligibility'][-1]['coverage_tier_name']

				try:
					carrier[0]['benefit_plan_name'] = str(member_attr['benefit_plan_name'])
				except KeyError:
					carrier[0]['benefit_plan_name'] = member_attr['eligibility'][-1]['benefit_plan_name']

				query = N1QLQuery('Select meta().id as id, dep_flipt_person_id from `' + bucket_name +
									  '`where type="flipt_person_hierarchy" ' +
									  'and dep_flipt_person_id=$fliptid',
									  fliptid=flipt_id)
					
				for query_res in cb.n1ql_query(query):
					if cmdline_args['mode'].upper().strip() == 'FINAL':
						cb.mutate_in(query_res['id'], SD.upsert('ins_carrier', carrier))

					else:
						logger.debug(f"CARRIER: {carrier}")
					running_count += 1
				continue
			elif (not dependent_found and not name_error) or len(dep_group) == 0:
				error_log = error_log.append({'Aetna First Name': row_data['first_name'],
												'Aetna Last Name': row_data['last_name'],
												'TV First Name':'', 'TV Last Name':'',
												'Aetna Member ID': row_data['dep_cumbid'],
												'Error':'Dependent Not Found'},
											   ignore_index=True)
				num_errors += 1
			# end - !dependent_found and !noeerror or len(gr)==0

	if employee_found:
		updated_att = attr_list[att_index]
		update_userid = user_id_list[att_index]
		new_att = base64.b64encode(str.encode(json.dumps(updated_att)))
		data_rec = {'attributes': new_att}
		number_of_members += 1
		
		if (cmdline_args['mode'].upper().strip() == 'FINAL' and
				employee_found and os.environ['INSTANCE_TYPE'] == 'PROD'):
			r = requests.put('https://api.truevault.com/v1/users/%s' % str(update_userid),
						   auth=HTTPBasicAuth(api_key, ''),
						   data=data_rec)
	else:
		first_name = ordered_group['first_name'][0]
		last_name = ordered_group['last_name'][0]
		if len(attr_list) == 0:
			error_log = error_log.append({'Aetna First Name':first_name,
										'Aetna Last Name': last_name,
										'TV First Name': '',
										'TV Last Name': '',
										'Aetna Member ID': ordered_group['cumbid'][0],
										'Error': 'Employee Not Found in Truevault'},
									   ignore_index=True)
			num_errors += 1
			continue
		else:
			error_log = error_log.append({'Aetna First Name': first_name,
										'Aetna Last Name': last_name,
										'TV First Name': attr_list[att_index]['first_name'],
										'TV Last Name': attr_list[att_index]['last_name'],
										'Aetna Member ID': ordered_group['cumbid'][0],
										'Error': 'Employee Not Matching with Truevault Attributes'},
									   ignore_index=True)
			num_errors += 1
# end outer loop

print(f"{running_count} records were updated in flipt_person_hierarchy table.")
logger.info(f"{running_count} records were updated in flipt_person_hierarchy table.")
errlog = 'error_log' + str(datetime.now()) + '.xlsx'
errlog = re.sub('[\s\-\:]', '', errlog)

outfile = f"{path}/{cmdline_args['domain_name']}/{cmdline_args['file_type']}/log/{errlog}"
logger.info(f"writing error log file: {outfile}")
writer = pd.ExcelWriter(outfile)
if {'Aetna First Name', 'Aetna Last Name', 'TV First Name', 'TV Last Name'}.issubset(error_log.columns):
	error_log.drop(['Aetna First Name', 'Aetna Last Name', 'TV First Name', 'TV Last Name'],
				  axis=1, inplace=True)
error_log.to_excel(writer, index=False)
writer.save()       
sender = 'noreply@fliptrx.com'

receivers = None
receiver = 'FliptIntegration@fliptrx.com'
subject = 'Flipt Person Hierarchy (Aetna Member ID) Updated - '
suject += f'({cmdline_args['mode'].upper()} mode) Completed'
body = ['Processing of Aetna Members file ' + filename,
		'Flipt Person Hierarchy Exception']

email_log(sender, receiver, receivers, subject, body,
		  outfile, attached=True)

req.no_rec_processed = number_of_members
req.no_rec_errored = num_errors
req.close()

if cmdline_args['mode'].lower() == 'final':
	sftp_hndlr.sftptransfer(localpath + filename, sftp_hndlr.sftp_archive, 'PUT')
	sftp_hndlr.sftpremove(filename)
	os.unlink(infile_name)

sftp_hndlr.sftp_close()
print('Program execution completed')


