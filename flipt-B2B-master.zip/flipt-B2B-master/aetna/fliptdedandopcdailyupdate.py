########################################
# !/usr/bin/env python
# title         : fliptdedandopcdailyupdate.py
# description   : Deductible update for Flipt users
# author        : Disha
# date created  : 20180101
# date last modified    : 20190206
# version       : 0.1
# maintainer    : Pal
# email         : pmuthanai@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage         : python fliptdedandopcdailyupdate.py -d GWLABS001 -t deductible -m draft
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#
#
# #######################################

import sys
import os
import re
from datetime import datetime

import copy
import pandas as pd
from couchbase.n1ql import N1QLQuery
import couchbase.subdocument as SD
from couchbase import FMT_JSON

from utils.truevault import User_Class
from utils.sendgridemail import email_log
from utils.FliptConcurrent import concurrent
from utils.helper_functions import *

def query_TV(cb_hndl, dom, flipt_personid):
	search_option = {'full_document': True,
					 'filter':
						 {
							 'flipt_person_id':
								 {
									 'type': 'eq',
									 'value': flipt_personid,
									 'case_sensitive': False
								 },
							 'domain_name':
								 {
									 'type': 'eq',
									 'value': dom,
									 'case_sensitive': False
								 },
							 '$tv.status':
								 {
									 'type': 'eq',
									 'value': 'ACTIVATED'
								 }
						 },
					 'filter_type': 'and'
					 }
	obj = User_Class(None, None, cb_handle=cb_hndl)
	att, userid = obj.search_user(search_option)
	return att

# end function


bucket_name = os.environ['CB_INSTANCE']
orig_cmdline = copy.deepcopy(sys.argv)
datestr = datetime.strptime(str(datetime.now()), "%Y-%m-%d %H:%M:%S.%f")
datestr = str(datestr)[:-7].replace(" ", '_')
logger = setup_logging_path("AETNA", f"fliptdedandopcupdate_{datestr}", "fliptdedandopc")
print(f"Update Began @ {datestr}")

path = os.environ['CB_DATA']
cmdline_args = process_alt_cmdline(additional=[["-d", "--domain_name", 'The domain to accumulate for', True],
											   ['-t', '--file_type', 'type of data being processed', True]])

req = concurrent(orig_cmdline[0], orig_cmdline[1:])
domain_name = cmdline_args['domain_name']

cb = cb_authenticate()

query = N1QLQuery('Select accumulate_flipt_deductible from `' + bucket_name +
				  '` where type="domain" and domain=$dn',
				  dn=domain_name)

logger.debug(query.statement)
query.adhoc = False
res = cb.n1ql_query(query).get_single_result()
if res['accumulate_flipt_deductible'] == 'N':
	logger.debug("Update aborted (accumulate_flipt_deductible Flag set to NO")
	print('Update Stopped (Flag set to NO)',datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())
	exit()

logDF = pd.DataFrame()
query = N1QLQuery('Select CASE WHEN count(patient_paid) > 0 THEN SUM(tonumber(rtrim(patient_paid))) ' +
				  'WHEN count(employee_opc) > 0  THEN SUM(tonumber(employee_opc)) ELSE 0 END cost, ' +
				  'rx_flipt_person_id from `' + bucket_name +
				  '` where type="prescription" and rx_status="Filled" ' +
				  'and tostring(DATE_PART_STR(filled_date, "year"))= $py ' +
				  'and drug_deductible_exempt="false" ' +
				  'and rx_flipt_person_id in (Select raw c.dep_flipt_person_id from `' + bucket_name +
				  '` c where c.type="flipt_person_hierarchy" and c.domain_name=$dn) ' +
				  'group by rx_flipt_person_id',
				  dn=domain_name,
				  py=str(datetime.now().strftime("%Y")))
query.adhoc = False
logger.debug(f"Outer query: {query.statement}")

counter = 0
for r in cb.n1ql_query(query):
	try:
		deductibleexemptaccrued = 0
		innerquery = N1QLQuery('Select CASE WHEN count(patient_paid) > 0 THEN SUM(tonumber(rtrim(patient_paid))) ' +
							   'WHEN count(employee_opc) > 0 THEN SUM(tonumber(employee_opc)) ELSE 0 END cost from `' +
							   bucket_name + '` where type="prescription" ' +
							   'and rx_status="Filled" ' +
							   'and tostring(DATE_PART_STR(filled_date, "year"))=$py ' +
							   'and drug_deductible_exempt="true" ' +
							   'and rx_flipt_person_id in (Select raw c.dep_flipt_person_id from `' +
							   bucket_name + '` c where c.type="flipt_person_hierarchy" ' +
							   'and c.domain_name=$dn) ' +
							   'and rx_flipt_person_id=$rxid ' +
							   'group by rx_flipt_person_id',
							   dn=domain_name,
							   py=str(datetime.now().strftime("%Y")),
							   rxid=r['rx_flipt_person_id'])
		innerquery.adhoc = False
		logger.debug(f"Inner query: {innerquery.statement}")
		for inner_row in cb.n1ql_query(innerquery):
			deductibleexemptaccrued = inner_row['cost']

		query1 = N1QLQuery('Select *,meta().id as id from `' + bucket_name +
						   '` where type="deductible" ' +
						   'and dep_flipt_person_id=$flipt_id ' +
						   'and plan_year=$yr',
						   dn=domain_name,
						   flipt_id=r['rx_flipt_person_id'],
						   yr=str(datetime.now().strftime("%Y")))
		recordfound = False
		query1.adhoc = False
		logger.debug(f"get record from flipt hierarchy for: {r['rx_flipt_person_id']}")
		logger.debug(query1.statement)

		for res in cb.n1ql_query(query1):
			recordfound = True
			result = dict(res[bucket_name])
			out_of_pocket_accrued = "{0:.2f}".format(float(result['carrier_out_of_pocket_accrued']) +
													 float(r['cost']) +
													 float(deductibleexemptaccrued))
			deductible_accrued = "{0:.2f}".format(float(result['carrier_deductible_accrued']) +
												  float(r['cost']))

			if (out_of_pocket_accrued != result['out_of_pocket_accrued'] or
					deductible_accrued != result['deductible_accrued']):
				logDF = logDF.append({'Previous Out of Pocket Accrued': result['out_of_pocket_accrued'],
									'Updated Out of Pocket Accrued': out_of_pocket_accrued,
									'Previous Deductible Accrued': result['deductible_accrued'],
									'Updated Deductible Accrued': deductible_accrued,
									'Employee Flipt Person ID': result['emp_flipt_person_id'],
									'Dependent Flipt Person ID': result['dep_flipt_person_id'],
									'Flipt Accrued Amount': r['cost'],
									'Update/Insert':'Update'},
								   ignore_index=True)
				result['out_of_pocket_accrued'] = out_of_pocket_accrued
				result['deductible_accrued'] = deductible_accrued

				if cmdline_args['mode'].upper().strip() == 'FINAL':
					cb.mutate_in(str(res['id']), SD.upsert('out_of_pocket_accrued',
														   str(result['out_of_pocket_accrued'])))
					cb.mutate_in(str(res['id']), SD.upsert('deductible_accrued',
														   str(result['deductible_accrued'])))
		if not recordfound and float(r['cost']) != 0:
			result = dict()
			result['deductible_accrued'] = "{0:.2f}".format(float(r['cost']))
			result['carrier_deductible_accrued'] = "0"
			result['out_of_pocket_accrued'] = "{0:.2f}".format(float(r['cost']))
			result['carrier_out_of_pocket_accrued'] = "0"
			result['previous_deductible_sent'] = "0"
			result['previous_opc_sent'] = "0"
			result['created_date'] = datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat()
			result['updated_date'] = datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat()
			result['data_extracted_date'] = datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat()
			result['domain_name'] = cmdline_args['domain_name']
			result['type'] = 'deductible'

			# query user from flipt_person_hierarchy
			query1 = N1QLQuery('Select ins_carrier, emp_flipt_person_id, ' +
							   'dep_flipt_person_id from `' + bucket_name +
							   '` where type="flipt_person_hierarchy" ' +
							   'and dep_flipt_person_id=$flipt_id ' +
							   'and domain_name=$dn',
							   flipt_id=r['rx_flipt_person_id'],
							   dn=domain_name)
			res = cb.n1ql_query(query1).get_single_result()

			user_attr = query_TV(cb, cmdline_args['domain_name'], res['emp_flipt_person_id'])
			if user_attr is None:
				try:
					if 'ins_carrier' in res:
						for carrier in res['ins_carrier']:
							if carrier['ins_carrier_name'] == 'Aetna':
								result['coverage_tier'] = carrier['coverage_tier_name']
								result['plan_name'] = carrier['benefit_plan_name']
				except KeyError:
					pass
				result['emp_flipt_person_id'] = res['emp_flipt_person_id']
			else:
				try:
					result['coverage_tier'] = user_attr['coverage_tier_name']
					result['plan_name'] = user_attr['benefit_plan_name']
				except KeyError:
					result['coverage_tier'] = user_attr['eligibility'][-1]['coverage_tier_name']
					result['plan_name'] = user_attr['eligibility'][-1]['benefit_plan_name']
				result['emp_flipt_person_id'] = user_attr['flipt_person_id']

			result['plan_year'] = str(datetime.now().strftime("%Y"))
			result['status'] = 'S'
			result['message'] = 'Person Found Successfully'
			result['dep_flipt_person_id'] = r['rx_flipt_person_id']

			if cmdline_args['mode'].upper().strip() == 'FINAL':
				cb.upsert(str(cb.counter('docid', delta=1).value),
						  result, format=FMT_JSON)
			logDF = logDF.append({'Previous Out of Pocket Accrued': 0,
									'Updated Out of Pocket Accrued': result['out_of_pocket_accrued'],
									'Previous Deductible Accrued': 0,
									'Updated Deductible Accrued': result['deductible_accrued'],
									'Employee Flipt Person ID': result['emp_flipt_person_id'],
									'Dependent Flipt Person ID': result['dep_flipt_person_id'],
									'Flipt Accrued Amount': r['cost'],
									'Update/Insert': 'Insert'},
								   ignore_index=True)
	except Exception as e:
		print(f"Unable to update: {r}")

				
log_time = re.sub("[\s\:\-]", '', str(datetime.now()))
logpath = f"{path}/{domain_name}/{cmdline_args['file_type']}/log/"
logpath += f"{domain_name}_dailydeductibleupdatelog_{log_time}.xlsx"

# check if the path exists - create otherwise
baseflpath = ''
try:
	baseflpath = os.path.dirname(logpath)
	st = os.stat(baseflpath)
except FileNotFoundError:
	# create missing directories
	os.makedirs(baseflpath, exist_ok=True)

logger.info(f"Excel log file: {logpath}")
writer = pd.ExcelWriter(logpath)
logDF.to_excel(writer, index=False)
req.no_rec_received = len(logDF)
req.no_rec_processed = len(logDF)
writer.save()
# email the result log table of status
email_log('noreply@fliptrx.com',
		  'FliptIntegration@fliptrx.com', 'racharya@fliptrx.com',
		  'Flipt Daily Deductible/OutOfPocket Update - Completed',
		  ['Deductible/OutOfPocket update', '‘Deductible Exception’'], logpath)
print('Update Ends', datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())
logger.info(f"Update Ends @{datetime.strptime(str(datetime.now()),'%Y-%m-%d %H:%M:%S.%f').isoformat()}")
req.close()

# email the result log table of status
email_log('noreply@fliptrx.com',
          'FliptIntegration@fliptrx.com', 'racharya@fliptrx.com',
          'Flipt Daily Deductible/OutOfPocket Update - Completed',
          ['Deductible/OutOfPocket update', '‘Deductible Exception’'], logpath)
print('Update Ends', datetime.strptime(
    str(datetime.now()), "%Y-%m-%d %H:%M:%S.%f").isoformat())
logger.info(
    f"Update Ends @{datetime.strptime(str(datetime.now()),'%Y-%m-%d %H:%M:%S.%f').isoformat()}")
req.close()
