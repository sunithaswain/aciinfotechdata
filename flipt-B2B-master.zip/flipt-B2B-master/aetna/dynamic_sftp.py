import paramiko
import sys
import traceback
import sendgrid
import os
import socket
from sendgrid.helpers.mail import Email, Content, Mail


sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))


class FastTransport(paramiko.Transport):
    def __init__(self, sock):
        super(FastTransport, self).__init__(sock)
        self.window_size = 2147483647
        self.packetizer.REKEY_BYTES = pow(2, 40)
        self.packetizer.REKEY_PACKETS = pow(2, 40)


def connect_sftp(ftphost, port, ftpuser, ftppwd):
    transport = FastTransport((ftphost, int(port)))
    try:
        transport.connect(username=ftpuser, password=ftppwd)
        return transport, paramiko.SFTPClient.from_transport(transport)
    except Exception as e:
        type, value, etraceback = sys.exc_info()
        error = ""
        x = traceback.format_exception(type, value, etraceback)
        for i in x:
            error = error + i
        content_ = 'Dear Admin Team,\n We are not able to connect to the Script Claim server while we perform an SFTP transfer. An exception ' + str(
            error) + ' stops this process. Kindly look into this issue.\n \n Best regards,\n FLIPT Integration Team'
        content = Content("text/plain", content_)
        mail = Mail(Email('noreply@fliptrx.com'), 'ALERT: Script Claim SFTP Connectivity Failure',
                    Email('SSubramani@GWLabs.com'), content)
        host = socket.gethostname()
        receiver2 = ['SPal@fliptrx.com', 'DWagle@fliptrx.com']
        hostnameprod = 'newprod-python-e1a'
        if host == hostnameprod: receiver2 = ['SPal@fliptrx.com', 'DWagle@fliptrx.com', 'hkumar@fliptrx.com',
                                              'ehart@script-claim.com', 'mattg@nbfsa.com']
        for i in receiver2:
            mail.personalizations[0].add_to(Email(i))
        response = sg.client.mail.send.post(request_body=mail.get())
        exit()


def sftptransfer(source, destination, mode, ftphost, port, ftpuser, ftppwd):
    transport, sftp = connect_sftp(ftphost, port, ftpuser, ftppwd)
    if mode == 'PUT':
        sftp.put(source, destination)

        try:
            sftp.lstat(destination)
            status = 'S'
            print('Upload Successful.')
        except IOError:
            status = 'E'
            print('File not Found in Remote')

    elif mode == 'GET':
        try:
            sftp.get(source, destination)
            status = 'S'
            print('Download Successful...')
        # sftp.remove(source)
        except IOError:
            status = 'E'
            print('File not transferred Successfully')

    sftp.close()
    transport.close()

    return status
