########################################
# !/usr/bin/env python
# title         : npi_prescriber_cron.py
# description   : monthly update of prescriber info directory
# author        : Alex
# date created  : 20180101
# date last modified    : 20190320 12:16
# version       : 0.1
# maintainer    : Alex
# email         : akarlis@fliptrx.com
# status        : Dev
# Python Version: 3.5.2
# usage1         : python npi_prescriber_cron.py -m final
# usage2         :
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  0.1                          20190204    Type conversion changes
# #######################################

if __name__ == '__main__':
    import os
    import sys

    rootdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import urllib.request
from datetime import datetime
from bs4 import BeautifulSoup
import zipfile
import os, json
import pandas as pd

from utils import commandline
from loguru import logger
import pandas as pd
from tqdm import tqdm
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
import couchbase.subdocument as SD
from couchbase import FMT_JSON
import requests
import socket
# from utils.sendgridemail import email_log

# it will changed based on OS
rootdir = rootdir.replace('\\', '/')
# path = os.environ['CB_DATA']
host = socket.gethostname()

domain,file_type,file_name,mode=commandline.main(sys.argv[1:])
cluster = Cluster(os.environ['CB_URL'])
bucket_name=os.environ['CB_INSTANCE']
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(bucket_name)

today_date = str(datetime.now().date())
filepath = rootdir+"/logs/npi_prescriber"+today_date+".log"
print(filepath)
if not os.path.isfile(filepath):
    logger.add(filepath, backtrace=True)

class NPIMonthlyUpdate:

    def __init__(self, download_type=('monthly', 'weekly')):
        self.download_type = download_type
        # self.cluster = Cluster(os.environ['CB_URL'])
        # self.auth = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
        # self.cluster.authenticate(self.auth)
        # self.cb = self.cluster.open_bucket(os.environ['CB_INSTANCE'])
        pass

    @logger.catch
    def download_unzip_npi(self):
        """

        Downloads precriber file from CMS government website.
        params: None
        :return: path + filename
        """
        if str(self.download_type).lower() == 'monthly':

            self.file_name = f'NPPES_Data_Dissemination_'
            print(self.file_name)
            root = "http://download.cms.gov/nppes/"
            html_pg = urllib.request.urlopen(root + "NPI_Files.html")
            soup = BeautifulSoup(html_pg, "html.parser")
            # print(soup)
            for link in soup.find_all('a'):
                try:
                    if self.file_name in link.get('href') and not None:
                        download_link = link.get('href').replace("./", root)
                        if "week" in download_link.lower() or "deactivation" in download_link.lower(): continue 
                        print(download_link.lower())
                        path, self.file_name = os.path.split(download_link)
                        urllib.request.urlretrieve(download_link, self.file_name)
                        logger.info(f'downloaded {self.file_name} successfully.')
                except TypeError as e:
                    continue


        

        if str(self.download_type).lower() == 'weekly':
            pass

        zippedfile = zipfile.ZipFile(self.file_name, 'r')
        print(zippedfile)
        for name in zippedfile.namelist():
            if 'npidata' in name and "FileHeader" not in name:
                filename = name
                fn = zippedfile.open(filename)
        zippedfile.close()
        print("filename") 
        print(self.file_name)
        return fn
    
    @logger.catch
    def download_and_filter_data(self):
        """
        :params: None

        Function to filter data based on pre-determined specs.
        :return: None; uploads each npi record into */npi_prescribers/* doc type.

        **Note**: Providers(NPI-1's) are different from pharmacies(NPI-2's)

        """
        fn = self.download_unzip_npi()
        df_list = [] # list to hold the batch dataframe

        keep_cols = ['NPI',
                     'Entity Type Code',
                     'Replacement NPI',
                     'Employer Identification Number (EIN)',
                     'Provider Organization Name (Legal Business Name)',
                     'Provider Last Name (Legal Name)',
                     'Provider First Name',
                     'Provider Middle Name',
                     'Provider Name Prefix Text',
                     'Provider Name Suffix Text',
                     'Provider Credential Text',
                     'Provider Other Organization Name',
                     'Provider Other Organization Name Type Code',
                     'Provider Other Last Name',
                     'Provider Other First Name',
                     'Provider Other Middle Name',
                     'Provider Other Name Prefix Text',
                     'Provider Other Name Suffix Text',
                     'Provider Other Credential Text',
                     'Provider Other Last Name Type Code',
                     'Provider First Line Business Mailing Address',
                     'Provider Second Line Business Mailing Address',
                     'Provider Business Mailing Address City Name',
                     'Provider Business Mailing Address State Name',
                     'Provider Business Mailing Address Postal Code',
                     'Provider Business Mailing Address Country Code (If outside U.S.)',
                     'Provider Business Mailing Address Telephone Number',
                     'Provider Business Mailing Address Fax Number',
                     'Provider First Line Business Practice Location Address',
                     'Provider Second Line Business Practice Location Address',
                     'Provider Business Practice Location Address City Name',
                     'Provider Business Practice Location Address State Name',
                     'Provider Business Practice Location Address Postal Code',
                     'Provider Business Practice Location Address Country Code (If outside U.S.)',
                     'Provider Business Practice Location Address Telephone Number',
                     'Provider Business Practice Location Address Fax Number',
                     'Provider Enumeration Date',
                     'Last Update Date',
                     'NPI Deactivation Reason Code',
                     'NPI Deactivation Date',
                     'NPI Reactivation Date',
                     'Provider Gender Code']

        chunksize = 200000
        for df_chunk in tqdm(pd.read_csv(fn, low_memory=False, usecols=keep_cols, chunksize=chunksize)):
            # append the chunk to list and merge all
            df_list.append(df_chunk)
        fn.close()
        os.remove(self.file_name)

        # Merge all dataframes into one dataframe
        df = pd.concat(df_list)

        df.dropna(how='all', inplace=True)
        nonTextList = ['PT','OT', 'SPEECH THERAPIST', 'PTA', 'RD/LMNT', 'PHYSICAL THERAPIST']
        result = df[~((df['Entity Type Code'] != 1.0) & (df['Provider Credential Text'].isin(nonTextList)))]
        # test only for 5 records
        # tempdf = result.head()
        tempdf = result

        update_ite=-1
        insert_ite = -1
        for i,r in tempdf.iterrows():
            jsondata={}
            jsondata['type']='prescriber'
            
            for c in list(tempdf):
                jsondata[c.lower().replace(' ','_')]=str(r[c])                
            print(jsondata)
            # To generate docid
            if mode.strip().upper() == 'FINAL':
                today_date = str(datetime.now())
                print(jsondata['npi'])
                query=N1QLQuery('Select meta().id as id from `'+bucket_name+'`where type="prescriber" and npi=$npi', npi=jsondata['npi'])
                query.timeout=7200 

                for qres in cb.n1ql_query(query):
                    jsondata['update_date']=today_date
                    cb.upsert(qres['id'], jsondata, format=FMT_JSON)
                    update_ite = update_ite+1
                else:
                    jsondata['created_date']=today_date
                    prescriber_npi  = cb.counter('docid',delta=1).value
                    docid = 'prescriber::'+str(prescriber_npi )
                    cb.upsert(docid,jsondata, format=FMT_JSON)
                    insert_ite = insert_ite+1
               
        logger.info('%s records are updated and %s records are inserted \n'%(update_ite, insert_ite))
        print('%s records are updated and %s records are inserted \n'%(update_ite, insert_ite))

        if mode.strip().upper() == 'DRAFT':
            logger.info('NPI prescriber update - Draft Mode : %s'%(host))

# object created and function invoked here 
obj = NPIMonthlyUpdate('monthly')
obj.download_and_filter_data()