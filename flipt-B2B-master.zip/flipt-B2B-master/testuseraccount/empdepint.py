########################################
# !/usr/bin/env python 

# title : empdepintV3.py
# description : update employee and employee-dependent details in truevault
# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  python empdepint.py -d FLIPT001 -t employee -f employeedata_regtest_Testing.xlsx%%dependentdata_regtest_Testing.xlsx  -m draft
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']
 
import os
import sys
import json
import shutil
import socket
import calendar
from pprint import pprint

from datetime import datetime
from pathlib import Path

import pandas as pd
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from couchbase import FMT_JSON


from utils import commandline
from utils.sendgridemail import email_log
from utils.truevault import User_Class
from rxplanmaster.rxplan_validation import validate,getplans

domain_name,file_type,file_name,processing_type=commandline.main(sys.argv[1:])
host=socket.gethostname()
fn=file_name.split('%%')
body=None
hostnameprod = 'newprod-python-e1a'

if len(fn)>1:
    _=1 
    email_log('DWagle@GWLabs.com','FliptIntegration@fliptrx.com',None,'Employee-Dependent Updation-Initiated',['Processing of Employee-Dependent files '+fn[0]+' & '+fn[1]],None,False)

logrecs=pd.DataFrame()
ptime=pd.DataFrame()
writer=pd.ExcelWriter(path+'/'+domain_name+'/'+file_type+'/log/employeeupdatelog.xlsx',engine='xlsxwriter')
ptime.loc[0,'Update Start']=str(datetime.now())
sender='DWagle@GWlabs.com'
receivers=['DWagle@GWLabs.com','SSubramani@GWLabs.com']
subject= 'Employee-Dependent Updation - Completed :'+processing_type+' mode'
if len(fn)>1:body=['Processing of Employee-Dependent files '+fn[0]+' & '+fn[1],'‘Employee Dependent Exception’']
else: body=['Processing of Employee-Dependent file '+fn[0],'‘Employee Dependent Exception’']
if file_type.lower()!='employee': 
    logrecs=logrecs.append({'Error':'Command Filetype Error'},ignore_index=True)
    logrecs.to_excel(writer,index=False,sheet_name='error')
    writer.save()
    email_log(sender,'FliptIntegration@fliptrx.com','DWagle@fliptrx.com',subject,body,path+'/'+domain_name+'/'+file_type+'/log/employeeupdatelog.xlsx')
    sys.exit()
cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
bucket_name=os.environ['CB_INSTANCE']
cb = cluster.open_bucket(bucket_name)
numactive,numinactive=0,0

#derive flipt coverage tier names 
def getCTier_names(domain,ctier):
    
    query=N1QLQuery('Select flipt_coverage_tier from `'+bucket_name+'` where type="coverage_tier" and domain_name=$d and employee_interface=$ei',d=domain,ei=ctier)
    
    for result in cb.n1ql_query(query): 
        return result['flipt_coverage_tier']
    return ""

#update attributes of terminated employees
def TerminatedEmployeeUpdate(r):
      
    search_option={'full_document':True,'filter':{'$tv.username':{'type':'eq','value':str(r['work_email']),'case_sensitive':False},'domain_name':{'type':'eq','value':str(r['domain_name']),'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
    user_obj=User_Class()
    att,userid=user_obj.search_user(search_option)
    lastday=calendar.monthrange(r['termination_date'].year,r['termination_date'].month)[1]
    att['coverage_termination_date']=str(r['termination_date'].replace(day=lastday,hour=23,minute=59,second=59))
    att['employment_status']=str(r['employment_status']).strip()
    att['termination_date']=r['termination_date'].strftime('%Y-%m-%d 23:59:59')
    for s in att['dependents']:
        s['coverage_termination_date']=att['coverage_termination_date']
        
    return att
        
#update employee-dependent details in truevault
def EmployeeDependentConverterUpdation():
    global logrecs,numactive,numinactive
    file1=Path(path+'/'+domain_name+'/'+file_type.lower()+'/'+fn[0])
    file2=Path(path+'/'+domain_name+'/'+file_type.lower()+'/'+fn[1])
    #check if new employee-dependent files exist or not
    if not file1.is_file() or not file2.is_file():
        logrecs=logrecs.append({'Error':'File Does Not Exist Error'},ignore_index=True)
        logrecs.to_excel(writer,index=False,sheet_name='error')
        writer.save()
        email_log(sender,'FliptIntegration@fliptrx.com',None,subject,body,path+'/'+domain_name+'/'+file_type+'/log/employeeupdatelog.xlsx')        
        sys.exit()
    empfile=pd.read_excel(path+'/'+domain_name+'/'+file_type.lower()+'/'+fn[0])
    
    empfile.fillna("",inplace=True)
    employee_cols={"Company Name (Doing Business As)":"domain_name", "Employee ID":"employee_id", "Social Security Number":"employee_ssn", "Benefit Plan Name":"benefit_plan_name", "Coverage Tier Name (No Codes)":"coverage_tier_name", "Last Name":"last_name", "First Name":"first_name", "Date of Birth":"date_of_birth", "Hire Date":"hire_date", "Coverage Effective Date":"coverage_effective_date", "Coverage Termination Date":"coverage_termination_date", "Work mail":"work_email", "Gender":"gender", "Home Address 1":"home_address_1", "Home Address 2":"home_address_2", "City":"city", "State":"state", "Zip":"zip", "Employment Status (No Codes)":"employment_status", "Termination Date":"termination_date", "Location":"location"}
    #empfile.rename(columns=employee_cols,inplace=True)
    empcols=list(empfile)
    empchecklist=['domain_name','employee_id','employee_ssn','benefit_plan_name','coverage_tier_name','last_name','first_name','date_of_birth','hire_date','coverage_effective_date','coverage_termination_date','work_email','gender','home_address_1','home_address_2','city','state','zip','employment_status','termination_date','location']
    depchecklist=['employee_id','dependent_ssn','relationship','last_name','first_name','date_of_birth','coverage_effective_date','coverage_termination_date']
    #check if new employee-dependent files have all the required columns
    for c in empchecklist:
        if c not in list(empcols):
            logrecs=logrecs.append({'Error':'Column '+str(c)+' Missing Error (Employee File)'},ignore_index=True)
            logrecs.to_excel(writer,index=False,sheet_name='error')
            writer.save()
            email_log(sender,'FliptIntegration@fliptrx.com',None,subject,body,path+'/'+domain_name+'/'+file_type+'/log/employeeupdatelog.xlsx')        
            sys.exit()
    #check if domain name is the one we passed as parameter or differs
    domains=['GWLABS001','FLIPT001']
    domainlist=[]
    if domain_name.upper().strip() in domains: domainlist.extend(domains)
    else: domainlist.append(domain_name)
    dquery=N1QLQuery('Select domain from `'+bucket_name+'` where type="domain" and domain in $dn',dn=domainlist)
    dquery.timeout=60
    domaindblist=[]
    for drow in cb.n1ql_query(dquery):
        domaindblist.append(drow['domain'].upper())
		
    if set(domaindblist)!=set(domainlist):
        logrecs=logrecs.append({'Error':'One of the domains does not exist'},ignore_index=True)
        logrecs.to_excel(writer,index=False,sheet_name='error')
        writer.save()
        email_log(sender,'FliptIntegration@fliptrx.com',None,subject,body,path+'/'+domain_name+'/'+file_type+'/log/employeeupdatelog.xlsx')   
        sys.exit()
    depfile=pd.read_excel(path+'/'+domain_name+'/'+file_type.lower()+'/'+fn[1])
    depfile.fillna("",inplace=True)
    dependents_cols={"Employee ID":"employee_id", "Masked SSN":"dependent_ssn", "Relationship (No Codes)":"relationship", "Last Name":"last_name", "First Name":"first_name", "Date of Birth":"date_of_birth", 
"Coverage Effective Date":"coverage_effective_date", "Coverage Termination Date":"coverage_termination_date"}
    #depfile.rename(columns=dependents_cols,inplace=True)
    depcols=list(depfile)
    for c in depchecklist:
        if c not in list(depcols):
            logrecs=logrecs.append({'Error':'Column '+str(c)+' Missing Error (Dependent File)'},ignore_index=True)
            logrecs.to_excel(writer,index=False,sheet_name='error')
            writer.save()
            email_log(sender,'FliptIntegration@fliptrx.com',None,subject,body,path+'/'+domain_name+'/'+file_type+'/log/employeeupdatelog.xlsx')        
            sys.exit()
    #get list of all valid plans for the domain and plan year
    print(list(empfile['domain_name'].unique()))
    #sys.exit()
    rxplans=getplans(list(empfile['domain_name'].unique()),str(datetime.now().strftime('%Y')))
    records=[]
    for c in ['first_name','last_name']:
        empfile[c]=[str(x).strip().upper() for x in empfile[c]]
        depfile[c]=[str(x).strip().upper() for x in depfile[c]]

    empfile['zip']=empfile['zip'].apply(lambda x:str(x).zfill(5) if len(str(x))<=5 else str(x).zfill(9))
    empfile['coverage_termination_date']=empfile['coverage_termination_date'].apply(lambda x: x.strftime('%Y-%m-%d 23:59:59'))
    depfile['coverage_termination_date']=depfile['coverage_termination_date'].apply(lambda x: x.strftime('%Y-%m-%d 23:59:59')) 
    for index,row in empfile.iterrows():
        emprecs={}
        validation1=True
        validation2=True
        validation3=True
        validation4=True
        validation5=True
        validation6=True
        if row['employment_status'].lower().strip()=='terminated':
            termrec=TerminatedEmployeeUpdate(row)
            records.append(termrec)
            numinactive=numinactive+1
            continue
        elif row['employment_status'].lower().strip()!='active':
            logrecs=logrecs.append({'Domain Name':row['domain_name'],'Employee ID':row['employee_id'],'First Name':row['first_name'],'Last Name':row['last_name'],'Coverage Tier Name':'','Dependent-Relationship':'','Plan Name':'','Record Error':'Invalid Employment Status'},ignore_index=True)
            validation5=False
        for remp in empcols:
            emprecs[remp] = str(row[remp])
        numactive=numactive+1
        emprecs['work_email']=emprecs['work_email'].lower()
        if row['domain_name'].upper().strip() not in domaindblist:
            logrecs=logrecs.append({'Domain Name':row['domain_name'],'Employee ID':row['employee_id'],'First Name':row['first_name'],'Last Name':row['last_name'],'Coverage Tier Name':'','Dependent-Relationship':'','Plan Name':'','Record Error':'Invalid Domain'},ignore_index=True)
            validation6=False
        
        
        emprecs['coverage_tier_name']=getCTier_names(domain_name,emprecs['coverage_tier_name'].strip())
        
        emprecs['dependents']=[]
        emprecs['locations']=[]
        plan=None
        #checks whether plan given in new file is valid
        if not rxplans.empty: plan=validate(rxplans,emprecs['benefit_plan_name'])
        
        emprecs['person_code']='01'
        pd.set_option('mode.chained_assignment', None) 
        deps = depfile.loc[depfile['employee_id'] == row['employee_id']]
        deps.sort_values(by=['date_of_birth'],inplace=True)
        child_cntr=3
        for depfiles,val in deps.iterrows():
            d={}
            fid={}
            for rdep in depcols:
                d[rdep] = str(val[rdep])
            # check coverage tier name validity            
            if 'coverage_tier_name' in d:
                d['coverage_tier_name']=getCTier_names(domain_name,d['coverage_tier_name'].strip())    
                if d['coverage_tier_name']=="":
                    logrecs=logrecs.append({'Domain Name':emprecs['domain_name'],'Employee ID':emprecs['employee_id'],'First Name':d['first_name'],'Last Name':d['last_name'],'Coverage Tier Name':val['coverage_tier_name'],'Dependent-Relationship':d['relationship'],'Plan Name':'','Record Error':'Coverage Tier Name Validation Error (Dependent)'},ignore_index=True)
                    validation1=False
            #derive person code of dependents
            if 'spouse' in d['relationship'].strip().lower():
                d['person_code']='02'
            elif 'child' in d['relationship'].strip().lower():
                d['person_code']=str(child_cntr).zfill(2)
                child_cntr=child_cntr+1
            else:
                logrecs=logrecs.append({'Domain Name':emprecs['domain_name'],'Employee ID':emprecs['employee_id'],'First Name':d['first_name'],'Last Name':d['last_name'],'Coverage Tier Name':'','Dependent-Relationship':d['relationship'],'Plan Name':'','Record Error':'Dependent Relationship Validation Error (Dependent)'},ignore_index=True)
                validation4=False
 
            if not (validation1==True and validation4==True): continue
            emprecs['dependents'].append(d)
        #emprecs['active']=True
        emprecs['type']='employee'
        if emprecs['domain_name']=='FLIPT001': emprecs['group']='FLIPTALL'
        else: emprecs['group']='GWALL'
        emprecs['zip']=emprecs['zip'].zfill(5)
        emprecs['benefit_plan_name']=plan
        if emprecs['coverage_tier_name']=="":
            logrecs=logrecs.append({'Domain Name':emprecs['domain_name'],'Employee ID':emprecs['employee_id'],'First Name':emprecs['first_name'],'Last Name':emprecs['last_name'],'Coverage Tier Name':row['coverage_tier_name'],'Dependent-Relationship':'','Plan Name':'','Record Error':'Coverage Tier Name Validation Error'},ignore_index=True)
            validation2=False
        if plan==None or plan=='Error' or emprecs['benefit_plan_name']=="":
            logrecs=logrecs.append({'Domain Name':emprecs['domain_name'],'Employee ID':emprecs['employee_id'],'First Name':emprecs['first_name'],'Last Name':emprecs['last_name'],'Coverage Tier Name':'','Dependent-Relationship':'','Plan Name':emprecs['benefit_plan_name'],'Record Error':'Plan Name Validation Error'},ignore_index=True)
            validation3=False
        emprecs['benefit_plan_name']=plan
        if not validation1 or not validation2 or not validation3 or not validation4 or not validation5 or not validation6: continue
        
        records.append(emprecs)
        
    return records
	
records=EmployeeDependentConverterUpdation()
terminatedlog=pd.DataFrame()
if host!=hostnameprod and processing_type.lower()=='final':
	print("Unable to run the update in Final mode on server ",host)
if processing_type.strip().lower()=='final' and host == hostnameprod:
    if records!=None:
        #go through each record and call truevault program's update user function to update attributes to truevault and flipt_person_hierarchy
        for record in records:
            attribute=json.dumps(record)
            user_obj=User_Class(record['work_email'].lower(),None,record,os.environ['CB_GROUP_ID'])
            termlog=user_obj.update_user()
            terminatedlog=terminatedlog.append(termlog,ignore_index=True)
        terminatedlog.drop(['First Name','Last Name'], axis=1,inplace=True)
        terminatedlog.to_excel(writer,index=False,sheet_name='Terminations')		
        obj=User_Class()
        # obj.update_active_status().to_excel(writer,index=False,sheet_name='AllUsers')

ptime.loc[0,'Processed employee file']=fn[0]
ptime.loc[0,'Processed dependent file']=fn[1]
ptime.loc[0,'# of active employee records processed']=numactive
ptime.loc[0,'# of terminated employee records processed']=numinactive
logrecs.drop(['First Name','Last Name'], axis=1,inplace=True)
logrecs.to_excel(writer,index=False,sheet_name='Errors')
ptime.loc[0,'Update end']=str(datetime.now())
ptime.to_excel(writer,index=False,sheet_name='Log')
writer.save()
email_log(sender,'FliptIntegration@fliptrx.com','dwagle@fliptrx.com',subject,body,path+'/'+domain_name+'/'+file_type+'/log/employeeupdatelog.xlsx')        
