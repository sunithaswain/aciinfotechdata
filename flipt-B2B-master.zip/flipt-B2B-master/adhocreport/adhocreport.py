########################################

# !/usr/bin/env python 

# title : adhocreport.py
# description : generates adhoc report .
# author : Deepthi
# date created : -
# last  modified : -
# version : 1
# maintainer : Deepthi
# email : -
# status : Production
# Python Version: 3.5.2
# usage         : python adhocreport.py -d GWLABS001 -t adhocreport -f "Build Report GwallScriptClaimAllClaimsJanthruMarch.xlsx" -m DRAFT
# Revisions:
# Version RevisedBy Date Change description
#Assumption is all the prescriptions 
# ------- --------- -------- ------------------
# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import os
from utils import commandline
import sys
import time
import socket
import pandas as pd
from datetime import datetime 
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from utils.sendgridemail import email_log
import xlsxwriter

host = socket.gethostname()
print(host)
cluster = Cluster(os.environ['CB_URL'])
print(cluster)
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
path = os.environ['CB_DATA']
sysdate = datetime.now()
domain,file_type,file_name,mode = commandline.main(sys.argv[1:])

out_report=path+'/'+domain+'/'+file_type+'/CustomReport_'+str(sysdate.month)+str(sysdate.day)+str(sysdate.year)+'.xlsx'
workbook = xlsxwriter.Workbook(out_report)
worksheet = workbook.add_worksheet()
def adhocreport():
	
	read_report =  path+'/'+domain+'/'+file_type+'/'+file_name
	print("report read",read_report)
	print("Out read",out_report)
	
	dfrecon = pd.read_excel(read_report, sheet_name="Sheet1")
	dfrecon['AuthorizationNumber']=dfrecon['AuthorizationNumber'].apply(lambda x: str(x).zfill(13)) 
	dfrecon['TransactionID'] = dfrecon['TransactionID'].fillna("NULL")
	
	#dfrecon.fillna("",inplace=True)
	#dfrecon=dfrecon.loc[:,['TransactionResponseStatus', 'IngCostPaid', 'DispFeePaid', 'AdminFeeCollectable', 'SalesTxPd','PatientTableID', 'PatientPay', 'PatientCopayAmt','ClientIngCost', 'ClientDispFee', 'ClientAdminFee', 'ClientDueAmt','ClientPriceRate', 'ClientUnitPrice', 'FamilyID', 'TransactionID','AuthorizationNumber']]
	cols=list(dfrecon)
	#print(cols)
	'''
	dfrecon['NewDate']  = pd.to_datetime(dfrecon['Date'])
	dfrec_grp = dfrecon.groupby(['TransactionID'])
	dfrec_grp.sort_values(by='NewDate')

	#dfrec_grp.sort_values('Date', ascending=False)
	for key,grp in dfrec_grp.iterrows():
		print('Group',grp)
		sys.exit()
		for index,row in grp.iterrows():
			print('Row',row)
			sys.exit()
	'''
	
	li1= ['admin_flipt_person_id','alternative_drug_rewards','application','auth_id','baseline_cost','bin','brand_generic','chaincode','claim_message','claim_status','create_date','created_by','custom_qty','custom_quantity','days_of_supply','daysofsupply','ddid','ddn_form','ddn_name','ddn_strength','deductible_remaining','dispensed_qty','domain','dosage','dosage_image','dosage_strength','dpa','drug','drug_copay','drug_cost','drug_cost_before_rebate','drug_deductible_exempt','drug_name','drug_penalty','drug_type','employee_opc','employer_cost','equivalent_brand','filled_date','flipt_person_id','form','gpi','gppc','group_id','lm_form','lm_name','lm_ndc','lm_strength','location','locationSelected','member_id','npi','out_of_pocket_remaining','pa_flag','pa_form','pa_reason','package_desc','package_qty','package_quantity','package_size','patient_paid','payment_option','pbm_estimated_cost','pbm_price','pcn','penalty_factor','pharmacy','pharmacy_discount','pharmacy_dispensing_fee','pharmacy_rejection_reason','pkg_desc_cd','pkg_uom','prescription_basket_id','prescription_id','preselected_npi','preselected_pharmacy','quantity','quantity_type','rebate_amount','rebate_factor','retail_reward','reward_percentage','reward_share','rewards','routed_date','rx_flipt_person_id','rx_status','saved_date','sc_routed_date','search_location','search_prescription_id','specialty_flag','strengths','total_payment','type','unit_price','unit_price_before_rebate','update_date','updated_by','zipCode','zone','changePharmacy','claimform_extracted_date','fullName','oldNpi','orig_daysofsupply','otc_indicator','other','orig_baseline_cost','orig_drug_cost','orig_employee_opc','orig_employer_cost','orig_package_qty','orig_package_quantity','orig_package_size','orig_pbm_price','orig_rewards','update_by','oldPharmacy','total_reward','cancelled_date','sc_cancelled_date','mo_contact_email','mo_contact_phone','mo_shipto_location','rxcui','hp_routed_date','orig_location','orig_npi','orig_pharmacy','prescriber_npi','rx_number']
	prescdata=pd.DataFrame()
	#print(dfrecon)
	statusmatch = {'P':['filled'],'X':['cancelled','routed']}
	try:
		for key,grp in dfrecon.groupby(['TransactionID']):
			print('Group',grp)
			#print('DateVal',grp['Date'])
			last_claim = grp.iloc[-1:]
			#sys.exit()
			#Not Null Prescriptions
			if (grp['TransactionID']).all()!= "NULL":
				for index,row in last_claim.iterrows():
					d={}
					presc_exists ='N'
					print('PrescID:',str(row['TransactionID']))
					innerquery = N1QLQuery('Select * from `'+os.environ['CB_INSTANCE']+'` where type="prescription" and trim(prescription_id)=$pid',pid='prescription::'+str(int(row['TransactionID'])))
					print('in else')
					innerquery.adhoc = False
					innerquery.timeout = 100
					print('Claim Type',row['TransactionResponseStatus'])
					for rrows in cb.n1ql_query(innerquery):
						presc_exists ='Y'
						d.update(row)
						d.update(rrows[os.environ['CB_INSTANCE']])
						if d['TransactionResponseStatus'].strip().lower() == 'x' :
							if 'baseline_cost' in d:
								d['baseline_cost'] = str(-1*float(d['baseline_cost']))
							if 'drug_copay' in d:
								d['drug_copay'] = str(-1*float(d['drug_copay']))
							if 'drug_cost' in d:
								d['drug_cost'] = str(-1*float(d['drug_cost']))
							if 'drug_cost_before_rebate' in d:
								d['drug_cost_before_rebate'] = str(-1*float(d['drug_cost_before_rebate']))
							if 'employee_opc' in d:
								d['employee_opc'] = str(-1*float(d['employee_opc']))
							if 'employer_cost' in d:
								d['employer_cost'] = str(-1*float(d['employer_cost']))
							if 'patient_paid' in d:
								d['patient_paid'] = str(-1*float(d['patient_paid']))
							if 'pbm_estimated_cost' in d:
								d['pbm_estimated_cost'] = str(-1*float(d['pbm_estimated_cost']))
							if 'pbm_price' in d:
								d['pbm_price'] = str(-1*float(d['pbm_price']))
							if 'total_payment' in d:
								d['total_payment'] = str(-1*float(d['total_payment']))
							if 'unit_price' in d:
								d['unit_price'] = str(-1*float(d['unit_price']))
							if 'unit_price_before_rebate' in d:
								d['unit_price_before_rebate'] = str(-1*float(d['unit_price_before_rebate']))
							if 'orig_baseline_cost' in d:
								d['orig_baseline_cost'] = str(-1*float(d['orig_baseline_cost']))
							if 'orig_drug_cost' in d:
								d['orig_drug_cost'] = str(-1*float(d['orig_drug_cost']))
							if 'orig_employee_opc' in d:
								d['orig_employee_opc'] = str(-1*float(d['orig_employee_opc']))
							if 'orig_employer_cost' in d:
								d['orig_employer_cost'] = str(-1*float(d['orig_employer_cost']))
							if 'orig_pbm_price' in d:
								d['orig_pbm_price'] = str(-1*float(d['orig_pbm_price']))
							if 'total_reward' in d:
								d['total_reward'] = str(-1*float(d['total_reward']))
							if 'pharmacy_dispensing_fee' in d:
								d['pharmacy_dispensing_fee'] = str(-1*float(d['pharmacy_dispensing_fee']))
					#For rows for which prescription does not exist in presctipion table.
					if presc_exists == 'N':
						d.update(row)
					prescdata=prescdata.append(d,ignore_index=True)
			else:
				for index,row in grp.iterrows():
					print('PrescID In Else:',str(row['TransactionID']))
					d={}
					d.update(row)
					prescdata=prescdata.append(d,ignore_index=True)
					print('Prescription ID is Null')
				
			#Append data to dictionary in case of if and else:	
			#prescdata=prescdata.append(d,ignore_index=True)
				
		#print('Value in d',d)
		for x in list(prescdata):
			if x in li1:
				new_name = 'FLIPTRX_'+ x
				prescdata.rename(columns={x:new_name},inplace=True)
		print('Value in prescdata frame',prescdata)		
		#prescdata.fillna("",inplace=True)
		prescdata.to_excel(out_report,index=False)
		print('OutReport',out_report)		
	
	except Exception as e: 
		print('In Exception',e)
	#workbook.close()
	print('email')
	#email_log('dwagle@fliptrx.com','deepthi.gollapudi@nttdata.com',None,'AdHoc report',['Invoicing Purpose ','Exception'],out_report,True)
	email_log('noreply@fliptrx.com','deepthi.gollapudi@nttdata.com','dwagle@fliptrx.com','AdHoc report',['Invoicing Purpose ','Exception'],out_report)
	exit()	
	
adhocreport()
workbook.close()