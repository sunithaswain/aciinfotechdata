########################################
# !/usr/bin/env python 

# title : fliptregisteredusers_withid_combined.py
# description : FliptRx Eligible Users
# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Disha
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  python eligible_users_report.py
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']
 
import requests
from requests.auth import HTTPBasicAuth
import socket
import json
import base64
import pprint
import pandas as pd
from couchbase.cluster import Cluster 
from couchbase.cluster import PasswordAuthenticator
from couchbase.n1ql import N1QLQuery
import sendgrid
import os
import sys, traceback
from sendgrid.helpers.mail import *
from datetime import datetime
from couchbase import FMT_JSON
import sendgrid
from sendgrid.helpers.mail import Email, Content,Attachment, Substitution, Mail 
import urllib.request as urllib
import base64
from pandas import ExcelWriter
from types import SimpleNamespace as Namespace
from utils.FliptConcurrent import concurrent


req=concurrent(sys.argv[0],'')
print('Flipt Eligible Users with ID Begin: ',datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())
api_key=os.environ['TV_API_KEY']
#domain_name,file_type,file_name,mode=commandline.main(sys.argv[1:])
cluster = Cluster(os.environ['CB_URL'])
bucket_name=os.environ['CB_INSTANCE']
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(bucket_name)
df1=pd.DataFrame()
numusers=0


class User_Class(object):

    def __init__(self,username=None,password=None,attributes=None,group_ids=None,status=None):
        self.username=username
        self.password=password
        self.attributes=attributes
        self.group_ids=group_ids
        self.status=status
 
    def search_user(self,search_option):
                 
        
        search_opt=base64.b64encode(str.encode(json.dumps(search_option)))
        data={'search_option':search_opt}
        r=requests.post('https://api.truevault.com/v1/users/search',auth=HTTPBasicAuth(api_key, ''),data=data)
        response=r.json()
        #print(response)
        if 'data' not in response: return None,None
        if len(response['data']['documents'])==0 and r.status_code==200: return None,None
        att=json.loads(str(base64.b64decode(response['data']['documents'][0]['attributes']),'utf-8'))
        #print(att)
        userid=response['data']['documents'][0]['user_id']
        return att,userid
		

    def read_user(self,userid):
    
        params={'full':True}
        try:
            r=requests.get('https://api.truevault.com/v2/users/%s' % str(userid),auth=HTTPBasicAuth(api_key, ''),params=params,timeout=10)
            return r.json()		
        except Exception as e:
            type, value, etraceback = sys.exc_info()
            error=""
            x=traceback.format_exception(type, value, etraceback)
            for i in x:
                error=error+i
        return None
    
    def get_all_users_with_id(self):

        global df1,loginheader,registeredusers
        
        usernum=0
        finaldf=pd.DataFrame()
        df=pd.DataFrame()
        r=requests.get('https://api.truevault.com/v1/users',auth=HTTPBasicAuth(api_key,''),timeout=10)
        response=r.json()
        obj=User_Class()
        totalusers=len(response['users'])
        print("Total Number of Users: ",totalusers)
        for i in response['users']:
            usernum=usernum+1
            if usernum%100==0:
                finaldf=finaldf.append(df,ignore_index=True)
                df=pd.DataFrame()
            result=obj.read_user(i['user_id'])
            try:
                att=result['users'][0]['attributes']
            except Exception as e:
                continue
            
            if ('parent_user_id' in att) or ('active' in att and att['active']!=True) or ('gwlabs' not in i['username']) or ('employee_id' in att and 'TEST' in att['employee_id']) or 'employee_id' not in att: continue
			
            dedopcrem={}
            cl,fn,rel,gender,dob,add1,add2,city,state,zipc,aetnaid,depid,ln,ei,fid,phones,user,active,phonenumbers,opcremain,dedremain,famded,famopc,workloc,ctdate,fmid='','','','','','','','','','','','','','','',[],'Employee','','','','','','','','',''
            if 'location' in att:
                workloc=str(att['location'])			
            if 'family' in dedopcrem:
                famded=dedopcrem['family'][0]
                famopc=dedopcrem['family'][1]
            if 'claimed' in att: 
                cl='Registered'
            if 'gender' in att: 
                gender=str(att['gender'])
            if 'date_of_birth' in att: 
                dob=str(att['date_of_birth'])
            if 'home_address_1' in att: 
                add1=str(att['home_address_1'])
            if 'home_address_2' in att: 
                add2=str(att['home_address_2'])
            if 'city' in att: 
                city=str(att['city'])
            if 'state' in att: 
                state=str(att['state'])
            if 'zip' in att: 
                zipc=str(att['zip'])				
            if 'first_name' in att:
                fn=str(att['first_name'])
            if 'last_name' in att:
                ln=str(att['last_name'])
            if 'employee_id' in att:
                ei=str(att['employee_id'])
            if 'flipt_person_id' in att:
                fid=str(att['flipt_person_id'])
            if 'flipt_person_id' in att and 'person_code' in att:
                fmid=str(att['flipt_person_id'])+str(att['person_code'])
            if 'carrier_phonenumbers' in att:
                if len(att['carrier_phonenumbers'])!=0: phonenumbers=att['carrier_phonenumbers'][0]
            if 'active' in att:
                active=str(att['active'])
            if 'coverage_termination_date' in att:
                ctdate=str(att['coverage_termination_date'])
                
			
            df=df.append({'Username':i['username'],'First Name':fn,'Last Name':ln,'Employee_ID':ei,'Claimed':cl,'User':user,'Flipt Person ID':fid,'Flipt Member ID':fmid,'Gender':gender,'Date of Birth':dob,'Home Address1':add1,'Home Address2':add2,'City':city,'State':state,'Zip':zipc,'Relationship':'','Aetna Member ID':aetnaid,'Aetna Relationship ID':depid,'Phone':phonenumbers,'Active':active,'Individual Deductible Remaining':dedremain,'Individual Out of Pocket Remaining':opcremain,'Family Deductible Remaining':famded,'Family Out of Pocket Remaining':famopc,'Work Location':workloc,'Coverage Termination Date':ctdate},ignore_index=True)
            if 'dependents' in att:
                for d in att['dependents']:
                    user='Dependent'
                    cl,gender,email,active,opcremain,dedremain,ctdate,fmid='','','','','','','',''
                    if 'email' in d: 
                        email=d['email']
                        cl='Registered'
                    if 'date_of_birth' in d: dob=str(d['date_of_birth'])
                    if 'home_address_1' in d: add1=str(d['home_address_1'])
                    if 'home_address_2' in d: add2=str(d['home_address_2'])
                    if 'city' in d: city=str(d['city'])
                    if 'state' in d: state=str(d['state'])
                    if 'zip' in d: zipc=str(d['zip'])
                    if 'first_name' in d: fn=str(d['first_name'])
                    if 'last_name' in d: ln=str(d['last_name'])
                    if 'employee_id' in d: ei=str(d['employee_id'])
                    if 'flipt_person_id' in d: fid=str(d['flipt_person_id'])
                    if 'flipt_person_id' in d and 'person_code' in d: fmid=str(att['flipt_person_id'])+str(d['person_code'])
                    if 'relationship' in d: rel=str(d['relationship'])
                    if 'gender' in d: gender=str(d['gender'])
                    if 'active' in d:
                        active=str(att['active'])					
                    if 'coverage_termination_date' in d:
                        ctdate=str(att['coverage_termination_date'])					
                    
								
                    #Added ctdate on 21stSep    
                    df=df.append({'Username':email,'First Name':fn,'Last Name':ln,'Employee_ID':ei,'Claimed':cl,'User':user,'Flipt Person ID':fid,'Flipt Member ID':fmid,'Gender':gender,'Date of Birth':dob,'Home Address1':add1,'Home Address2':add2,'City':city,'State':state,'Zip':zipc,'Relationship':rel,'Aetna Member ID':aetnaid,'Aetna Relationship ID':depid,'Phone':phonenumbers,'Active':active,'Individual Deductible Remaining':dedremain,'Individual Out of Pocket Remaining':opcremain,'Family Deductible Remaining':famded,'Family Out of Pocket Remaining':famopc,'Work Location':'','Coverage Termination Date':ctdate},ignore_index=True)
            #print(df)
        finaldf=finaldf.append(df,ignore_index=True)		
        finaldf.reset_index(drop=True,inplace=True)
        finaldf.sort_values(by=['Employee_ID','User'],ascending=[True,False],inplace=True)  
        columns=['Relationship','User','Date of Birth','Aetna Member ID','Aetna Relationship ID','Flipt Person ID','Flipt Member ID','Gender','First Name','Last Name','Home Address1','Home Address2','City','State','Zip','Phone','Work Location','Employee_ID','Username','Individual Deductible Remaining','Individual Out of Pocket Remaining','Family Deductible Remaining','Family Out of Pocket Remaining','Claimed','Active','Coverage Termination Date']		
        writer=ExcelWriter(path+'//GWLABS001//employee//EligibleUsers'+str(datetime.strftime(datetime.now(),'%m%d%Y'))+'.xlsx')
        finaldf[columns].to_excel(writer,'Sheet1',index=False)
        writer.save()
		

obj=User_Class()
obj.get_all_users_with_id()
print('Flipt Eligible Users with ID End: ',datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())
req.close()
