########################################
# !/usr/bin/env python  
# title         : fliptdeductibleoutbound.py
# description   : Sends Flipt accumulated deductible to Aetna every two weeks through AWS SFTP (S3 Bucket)
# author        : Deepthi
# date created  : 20181113
# date last modified    : 20190116 
# version       : 0.1
# maintainer    : Deepthi
# email         : deepthi.gollapudi@nttdata.com
# status        : Production
# Python Version: 3.5.2
# usage			: python adhoc_deductible_outbound.py -d GWLABS001 -t adhocreport -m DRAFT
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  
# #######################################
if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']

import json
import sys
import os ,re
from datetime import datetime
from couchbase import FMT_JSON
import dateutil.parser as parser

import pandas as pd
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
import couchbase.subdocument as SD

from utils import commandline
from utils.awssftpfileops import uploadfile
from utils.FliptConcurrent import concurrent
from utils.truevault import User_Class
from utils.sendgridemail import email_log,email_log_custombody


# Command to run the script:
#python fliptdeductibleoutbound_d.py -d GWLABS001 -t deductible -m DRAFT



domain_name,file_type,file_name,mode=commandline.main(sys.argv[1:])
#req=concurrent(sys.argv[0],sys.argv[1:])
sysdate = datetime.now()
cluster = Cluster(os.environ['CB_URL'])
bucket_name=os.environ['CB_INSTANCE']
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(bucket_name)
#logpath=path+'/'+domain_name+'/'+file_type+'/Outbound/log/'
logpath=path+'/'+domain_name+'/'+file_type+'/'
log=pd.DataFrame()
def extractdeductible():
	global log
	df=pd.DataFrame()
	#query=N1QLQuery("Select meta().id as id,deductible_accrued,carrier_deductible_accrued,out_of_pocket_accrued,carrier_out_of_pocket_accrued,previous_deductible_sent,previous_opc_sent,dep_flipt_person_id,emp_flipt_person_id from `"+os.environ['CB_INSTANCE']+"` where type='deductible' and plan_year = $py ", py=str(datetime.now().year))

	query=N1QLQuery("Select meta().id as id,deductible_accrued,carrier_deductible_accrued,out_of_pocket_accrued,carrier_out_of_pocket_accrued,flipt_aetna_deductible,flipt_aetna_out_of_pocket,dep_flipt_person_id,emp_flipt_person_id from `"+os.environ['CB_INSTANCE']+"` where type='deductible' and plan_year = $py ", py=str(datetime.now().year))
	query.timeout=3600
	

	for r in cb.n1ql_query(query):
		
		record={}
		record.update(r)
		if (record['deductible_accrued'] == 'nan' or record['deductible_accrued'] ==''):
			record['deductible_accrued'] = 0.00
			
		if  (record['carrier_deductible_accrued'] =='nan' or record['carrier_deductible_accrued'] ==''):
			record['carrier_deductible_accrued'] = 0.00

		if 'flipt_aetna_deductible' not in record:
			record['flipt_aetna_deductible'] = 0.00
		
		if 'flipt_aetna_out_of_pocket' not in record:
			record['flipt_aetna_out_of_pocket'] = 0.00

		if  (record['flipt_aetna_deductible'] =='nan' or record['flipt_aetna_deductible'] ==''):
			record['flipt_aetna_deductible'] = 0.00

		if  (record['flipt_aetna_out_of_pocket'] =='nan' or record['flipt_aetna_out_of_pocket'] ==''):
			record['flipt_aetna_out_of_pocket'] = 0.00
			
		if  (record['out_of_pocket_accrued'] =='nan' or record['out_of_pocket_accrued'] ==''):
			record['out_of_pocket_accrued'] = 0.00
			
		if  (record['carrier_out_of_pocket_accrued'] =='nan' or record['carrier_out_of_pocket_accrued'] ==''):
			record['carrier_out_of_pocket_accrued'] =0.00
			
		
	
	
		
		record['deductible_amount']="{0:.2f}".format(float(record['deductible_accrued'])-float(record['carrier_deductible_accrued'])-float(record['flipt_aetna_deductible']))
		record['opc_amount'] = "{0:.2f}".format(float(record['out_of_pocket_accrued'])-float(record['carrier_out_of_pocket_accrued'])-float(record['flipt_aetna_out_of_pocket']))
		record['year']=str(datetime.now().year)
		employee=True
		#print('Record of deductible type',record)
		#if the deductible and opc amount is 0,don't post the member details to Aetna
		
		if float(record['deductible_amount'])==0.00 and float(record['opc_amount'])==0.00:
			#print('Deductible and opc are 0 for the flipt person id :',str(record['dep_flipt_person_id']))
			log=log.append({'Deductible Amount':record['deductible_amount'],'OPC Amount':record['opc_amount'],'Flipt Person ID':record['dep_flipt_person_id'],'Message':'Deductible and OPC are 0.0 for this flipt person id '},ignore_index=True)
			continue
		
		#To check if employee exists in flipt person hierarchy. 
		query1=N1QLQuery("Select b.domain_name,ins.ins_carrier_member_id,ins.ins_relationship_code,b.emp_flipt_person_id from `"+os.environ['CB_INSTANCE']+"` b unnest b.ins_carrier ins where b.type='flipt_person_hierarchy' and b.dep_flipt_person_id=$did and ins.ins_carrier_name='Aetna'",did=str(record['dep_flipt_person_id']))
				
		query1.timeout=3600
		query1.adhoc = False
		for r1 in cb.n1ql_query(query1):
			record.update(r1)
		#print('Record',record)
		try:
			#Check employee or dependent
			if record['dep_flipt_person_id']!=record['emp_flipt_person_id']:
				employee=False
				
				empcarrier=N1QLQuery("Select in2.ins_carrier_member_id from `"+os.environ['CB_INSTANCE']+"` c unnest c.ins_carrier in2 where c.type='flipt_person_hierarchy' and c.emp_flipt_person_id=$eid and c.dep_flipt_person_id=$eid and in2.ins_carrier_name='Aetna'",eid=str(record['emp_flipt_person_id']))
				empcarrier.timeout=70
				empcarrier.adhoc = False
				for r2 in cb.n1ql_query(empcarrier):
					record['ins_carrier_member_id'] = r2['ins_carrier_member_id']
				#print('Record',record)
		except Exception as e:
			#if the member not in flipt person hierarchy,don't post the member details to Aetna
			print(e,record['dep_flipt_person_id'],'MemberID missing')
			log=log.append({'Deductible Amount':record['deductible_amount'],'OPC Amount':record['opc_amount'],'Flipt Person ID':record['dep_flipt_person_id'],'Message':'MemberID missing'},ignore_index=True)
			continue
		#check in truevault for employee and dependent attributes
		obj=User_Class()
		search_option={'full_document':True,'filter':{'flipt_person_id':{'type':'eq','value':record['emp_flipt_person_id'],'case_sensitive':False},'domain_name':{'type':'eq','value':record['domain_name'],'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
		att,userid=obj.search_user(search_option)
		#print('Attributes:',att)
		try:
			if att!=None:
				if employee:
					record['first_name']=att['first_name']
					record['last_name']=att['last_name']
					record['date_of_birth']=datetime.strftime(datetime.strptime(att['date_of_birth'],"%Y-%m-%d %H:%M:%S"),"%d/%m/%Y")
					record['gender']=att['gender']
				elif 'dependents' in att:
					for d in att['dependents']:
						if d['flipt_person_id']==record['dep_flipt_person_id']:
							record['first_name']=d['first_name']
							record['last_name']=d['last_name']
							record['date_of_birth']=datetime.strftime(datetime.strptime(d['date_of_birth'],"%Y-%m-%d %H:%M:%S"),"%d/%m/%Y")
							record['gender']=d['gender']
							break
			#Dump the record values to dataframe df
			if 'ins_carrier_member_id' in record and 'first_name' in record:
				record.pop('emp_flipt_person_id',None)
				df=df.append(record,ignore_index=True)
				df['ins_relationship_code']=df['ins_relationship_code'].apply(lambda x: str(x).zfill(6))
				
			else:
				#Since no attributes,df is not filled
				print(record['dep_flipt_person_id'],'Truevault Attributes missing')
				log=log.append({'Deductible Amount':record['deductible_amount'],'OPC Amount':record['opc_amount'],'Flipt Person ID':record['dep_flipt_person_id'],'Message':'Truevault Attributes missing'},ignore_index=True)
				
			
			record.pop('id',None)	
		except Exception as e:
			print(e,record['dep_flipt_person_id'])
	print('Columns in df',list(df))
	
	try:
		cols={'ins_carrier_member_id':'Member Id(Subscriber)','first_name':'Patient First Name','last_name':'Patient Last Name','gender':'Patient Gender','date_of_birth':'Patient Date of Birth','ins_relationship_code':'Patient Relationship Code','deductible_amount':'RX Deductible Dollars','opc_amount':'RX Coinsurance Dollars','year':'Year'}
		df.rename(columns=cols,inplace=True)
		filename='FLIPT_DEDUCTIBLE_AETNA_'+str(sysdate.month)+str(sysdate.day)+str(sysdate.year)+'.xlsx'
		writer=pd.ExcelWriter(path+'/'+domain_name+'/'+file_type+filename,engine='xlsxwriter')
		df.to_excel(writer,index=False,columns=['Member Id(Subscriber)','Patient First Name','Patient Last Name','Patient Gender','Patient Date of Birth','Patient Relationship Code','RX Deductible Dollars','RX Coinsurance Dollars','Year'])
		writer.save()
		#req.no_rec_received=len(f)
		print('Deductible file created: ',filename)
		if mode.lower().strip()=='final' and os.environ['INSTANCE_TYPE']=='PROD':
		#if mode.lower().strip()=='draft' and os.environ['INSTANCE_TYPE']=='DEV':
			#uploadfile(domain,filetype,filename,destination)
			uploadfile(domain_name,file_type,filename,'aetnaintegration/downloads/Flipt')
			subject = 'Flipt Deductible Outbound - Completed : '+mode.lower().strip()
			email_log('DWagle@GWLabs.com','DWagle@fliptrx.com','fliptintegration@fliptrx.com,deepthi.gollapudi@nttdata.com',subject,['Processing of Flipt Deductible Outbound ','Flipt Deductible Outbound Exception'],path+'/'+domain_name+'/'+file_type+'/'+filename,True)
	except Exception as e:
		print(e)
	
	 

extractdeductible()	
date_now = re.sub('[\s\-\:]', '',datetime.now().isoformat() )
log.to_csv(logpath+"FliptDeductibleLog"+date_now+".csv",index=False)
#req.close()       
		
			
