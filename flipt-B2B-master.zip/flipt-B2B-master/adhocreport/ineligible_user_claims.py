########################################
# !/usr/bin/env python 

# title : ineligible_user_claims.py
# description : FliptRx Ineligible Users and Claims
# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Disha
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  python ineligible_user_claims.py -d GWLABS001 -t adhocreport
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


# #######################################

from requests.auth import HTTPBasicAuth
from utils import commandline
if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']
 
import requests

import socket
import json
import base64
import pprint
import pandas as pd
from couchbase.cluster import Cluster 
from couchbase.cluster import PasswordAuthenticator
from couchbase.n1ql import N1QLQuery
import sendgrid
import os
import sys, traceback
from sendgrid.helpers.mail import *
from datetime import datetime
from couchbase import FMT_JSON
import sendgrid
from sendgrid.helpers.mail import Email, Content,Attachment, Substitution, Mail 
import urllib.request as urllib
import base64
from pandas import ExcelWriter
from types import SimpleNamespace as Namespace
from utils.FliptConcurrent import concurrent


req=concurrent(sys.argv[0],'')
api_key=os.environ['TV_API_KEY']
cluster = Cluster(os.environ['CB_URL'])
bucket_name=os.environ['CB_INSTANCE']
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(bucket_name)

path = os.environ['CB_DATA']
sysdate = datetime.now()
domain, file_type, file_name, mode = commandline.main(sys.argv[1:])

out_report = path+'/'+domain+'/'+file_type+'/IneligibleUserClaimsReport_' + \
    str(sysdate.month)+str(sysdate.day)+str(sysdate.year)+'.csv'


class User_Class(object):

    def __init__(self,username=None,password=None,attributes=None,group_ids=None,status=None):
        self.username=username
        self.password=password
        self.attributes=attributes
        self.group_ids=group_ids
        self.status=status
 
    def search_user(self,search_option):
                 
        
        search_opt=base64.b64encode(str.encode(json.dumps(search_option)))
        data={'search_option':search_opt}
        r=requests.post('https://api.truevault.com/v1/users/search',auth=HTTPBasicAuth(api_key, ''),data=data)
        response=r.json()
        #print(response)
        if 'data' not in response: return None,None
        if len(response['data']['documents'])==0 and r.status_code==200: return None,None
        att=json.loads(str(base64.b64decode(response['data']['documents'][0]['attributes']),'utf-8'))
        #print(att)
        userid=response['data']['documents'][0]['user_id']
        return att,userid
		

    def read_user(self,userid):
    
        params={'full':True}
        try:
            r=requests.get('https://api.truevault.com/v2/users/%s' % str(userid),auth=HTTPBasicAuth(api_key, ''),params=params,timeout=10)
            return r.json()		
        except Exception as e:
            type, value, etraceback = sys.exc_info()
            error=""
            x=traceback.format_exception(type, value, etraceback)
            for i in x:
                error=error+i
        return None
    
    def get_user_claims(self):

        
        df = pd.DataFrame()
        now = datetime.now().isoformat()
        r=requests.get('https://api.truevault.com/v1/users',auth=HTTPBasicAuth(api_key,''),timeout=10)
        response=r.json()
        
        for i in response['users']:
           
            result=self.read_user(i['user_id'])
            try:
                att=result['users'][0]['attributes']
            except Exception as e:
                continue
            if ('employee_id' not in att) or ('employee_id' in att and 'parent_id' in att):
                continue
            print(i['username'])
            terminated = False
            terminated_ids = {}
            if 'eligibility' in att:
                for e in att['eligibility']:
                    if e['coverage_termination_date'] < now:
                        terminated = True
                        terminated_ids.update(
                            {att['flipt_person_id'] + '01': e['coverage_termination_date']})
                        break
            if 'dependents' in att and len(att['dependents']) > 0:
                for dep in att['dependents']:
                    if terminated:
                        terminated_ids.update(
                            {att['flipt_person_id'] + dep['person_code']: terminated_ids[att['flipt_person_id'] + '01']})
                    else:
                        if 'eligibility' in dep:
                            for e in dep['eligibility']:
                                if e['coverage_termination_date'] < now:
                                    terminated_ids.update(
                                        {att['flipt_person_id'] + dep['person_code']: e['coverage_termination_date']})
                                    break
            if not terminated_ids:
                continue
            for tid, termdt in terminated_ids.items():
                claims = pd.DataFrame()
                query = N1QLQuery(
                "Select claim_date,auth_id,sequence_number,transaction_id,member_id,claim_type from `" + os.environ['CB_INSTANCE'] + "` where type='scdailyclaim_summary' and member_id=$v1 and claim_date > $v2 and claim_type!='R'", v1=tid, v2=termdt)
                for result in cb.n1ql_query(query):
                    claims = claims.append(result,ignore_index=True)

                
                if claims.empty:
                    continue
                print('Terminated ')
                for k, g in claims.groupby(['auth_id']):
                    g.sort_values(by='sequence_number', ascending=False)
                    for i, r in g.iterrows():
                        
                        if r['claim_type'] == 'P':
                            application = ''
                            pa_rx = ''
                            rxstatus = ''
                            if r['transaction_id'] and r['transaction_id'] != 'prescription::':
                                query = N1QLQuery(
                                    "Select application,pa_override,rx_status from `" + os.environ['CB_INSTANCE'] + "` where type='prescription' and prescription_id=$v1", v1=r['transaction_id'])
                                for result in cb.n1ql_query(query):
                                    if 'application' in result:
                                        application = result['application']
                                    if 'pa_override' in result:
                                        pa_rx = result['pa_override']
                                    if 'rx_status' in result:
                                        rxstatus = result['rx_status']
                    
                            df = df.append({'Prescription ID': r['transaction_id'],
                            'Auth ID': r['auth_id'] ,'Cardholder ID': tid, 'Claim Date': r['claim_date'], 'Termination Date': termdt, 'Application': application, 'PA': pa_rx,'Prescription Status': rxstatus},ignore_index=True)
                        break
        df.to_csv(out_report, index=False)
        
obj = User_Class()
obj.get_user_claims()


                
                    


                
            
            
