import io
import logging
import os
import argparse
from datetime import datetime

import boto3
import couchbase.subdocument as sd
import pandas as pd
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator

# run command: python trackingnumberupdate.py -m FINAL

parser = argparse.ArgumentParser(description='commandline file processing...')
parser.add_argument("-d", "--domain", help="pass in domain (company)", required=False),
parser.add_argument("-t", "--file_type", help="pass in doc type", required=False)
parser.add_argument("-f", "--file_name", help="pass in file name", required=False)
parser.add_argument("-m", "--processing_type", help="final/draft mode", required=True)

args = vars(parser.parse_args())
domain = str(args['domain'])
file_type = str(args['file_type'])
file_name = str(args['file_name'])
MODE = str(args['processing_type'])
print(MODE)

LOG_TIME = datetime.now().strftime('%m_%d_%y')
HOME = os.environ['HOME']

CLUSTER = Cluster(os.environ['CB_URL'])
BUCKET_NAME = os.environ['CB_INSTANCE']
AUTHENTICATOR = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
CLUSTER.authenticate(AUTHENTICATOR)
CB = CLUSTER.open_bucket(BUCKET_NAME)

ACCESS_KEY = os.environ['AWS_ACCESS_KEY_ID']
SECRET_KEY = os.environ['AWS_SECRET_ACCESS_KEY']

MY_CLIENT = boto3.client(
    's3',
    aws_access_key_id=ACCESS_KEY,
    aws_secret_access_key=SECRET_KEY
)

MY_RESOURCE = boto3.resource(
    's3',
    aws_access_key_id=ACCESS_KEY,
    aws_secret_access_key=SECRET_KEY
)

BUCKET_NAME = MY_RESOURCE.Bucket(os.environ['AMAZON_SFTP_BUCKET'])
BUCKET = BUCKET_NAME.name

logging.basicConfig(
    filename=f'{HOME}/FLIPTB2B/data/flipt_concurrent_programs/log/humanatrackingnumber{LOG_TIME}.txt',
    level=logging.INFO
)


class NoTrackingNumberError(Exception):
    pass


def add_tracking_number():
    """
    Simple task to search Humana's dropped files and parse them to find tracking error for specialty + traditional Rx's.
    :return: None
    """

    file_day_stamp = datetime.strftime(datetime.today(), '%Y_%m_%d')
    trad_template = f'FliptRx Trad Mail Daily Fill Report {file_day_stamp}'
    trad_template = f'prodhumanaint/uploads/shipments/{trad_template}'
    spec_template = f'HSP FliptRx Daily Fill Status Specialty {file_day_stamp}'
    spec_template = f'prodhumanaint/uploads/shipments/{spec_template}'

    logging.info(f'Searching for files in s3 bucket {BUCKET}...\n\r')

    response = MY_CLIENT.list_objects(Bucket=BUCKET_NAME.name)

    for file in response['Contents']:
        try:
            if file['Key'].startswith(trad_template):
                trad_file_path = file['Key']
                print(f'trad mail file found {trad_file_path}')
            if file['Key'].startswith(spec_template):
                spec_file_path = file['Key']
                print(f'spec file found: {spec_file_path}')
        except Exception as e:
            raise Exception

    trad_flag = False
    spec_flag = False
    store = BUCKET_NAME.objects.all()

    for obj in store:
        if obj.key == trad_file_path:
            trad_obj = io.BytesIO(obj.get()['Body'].read())
            trad_flag = True
        if obj.key == spec_file_path:
            spec_obj = io.BytesIO(obj.get()['Body'].read())
            spec_flag = True

    if not trad_flag or not spec_flag:
        logging.info(str(FileNotFoundError) + ': No traditional or specialty files found.\n\r')
        raise FileNotFoundError
    else:
        logging.info(f'Found file {spec_file_path}\n\r')
        logging.info(f'Found file {trad_file_path}\n\r')

    # read files directly into memory
    trad_obj = pd.ExcelFile(trad_obj, engine='xlrd')
    spec_obj = pd.ExcelFile(spec_obj, engine='xlrd')

    # move files into archive and delete from current dir
    if MODE.strip().upper() == 'FINAL':
        for file_path in [trad_file_path, spec_file_path]:
            copy_source = {
                'Bucket': BUCKET,
                'Key': file_path
            }

            file_name = file_path.split('/')[-1]
            MY_RESOURCE.meta.client.copy(copy_source, BUCKET, f'prodhumanaint/uploads/shipments/archive/{file_name}')
            MY_CLIENT.delete_object(Bucket=BUCKET_NAME.name, Key=file_path)

    trad_df = pd.read_excel(trad_obj, dtype={'Transaction ID': str})
    spec_df = pd.read_excel(spec_obj)

    trad_tracking = trad_df[['Transaction ID', 'Tracking Number']]
    trad_tracking.rename(columns={'Transaction ID': 'TransactionID',
                                  'Tracking Number': 'TrackingNumber'},
                         inplace=True)
    spec_tracking = spec_df[['TransactionID', 'TrackingNumber']]

    tracking = pd.DataFrame()
    tracking = tracking.append(spec_tracking, ignore_index=True)
    tracking = tracking.append(trad_tracking, ignore_index=True)

    # drop all 'NA' values, either without TransactionID's or Tracking Numbers. Need both to work.
    tracking.dropna(inplace=True)

    tracking['TransactionID'] = tracking['TransactionID'].apply(lambda x: 'prescription::' + str(x))

    # raise user-defined Error class if no tracking numbers are found.
    if True in list(tracking['TrackingNumber'].isnull()):
        logging.info('No tracking numbers found. Stopping program.\n\r')
        raise NoTrackingNumberError('No tracking numbers found. Stopping program.')

    tracking_numbers = {}
    for presc_id in tracking['TransactionID']:
        print(presc_id)

        tracking_number = tracking.loc[tracking['TransactionID'] == presc_id]['TrackingNumber'].values[0]
        tracking_numbers['tracking_number'] = str(tracking_number)
        tracking_numbers['tracking_url'] = 'https://tools.usps.com/go/TrackConfirmAction?qtc_tLabels1=' + \
                                           str(tracking_number)
        CB.mutate_in(str(presc_id).strip(), sd.upsert('tracking_number', str(tracking_number)))
        CB.mutate_in(str(presc_id).strip(), sd.upsert('tracking_url', tracking_numbers['tracking_url']))

    logging.info('Program completed. Please confirm the file has been moved to archive.\n\r')

    return


if __name__ == '__main__':
    logging.info(f'Finding tracking numbers..\n\r')
    print(f'Finding tracking numbers..')
    add_tracking_number()
