########################################
# !/usr/bin/env python 

# title : displaymessagefromjson.py
# description : Update display message from json data
# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  python displaymessagefromjson.py -d GWLABS001 -t displaymessage -f appmessages.json -m DRAFT
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


# #######################################
if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']

import os
import time
import sys
import json
import base64
import json
import socket
from datetime import datetime
import urllib.request as urllib2
import urllib.error

import pandas as pd
from couchbase.n1ql import N1QLQuery
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase import FMT_JSON
import couchbase.subdocument as SD
import sendgrid
from sendgrid.helpers.mail import Email, Content,Attachment, Substitution, Mail 

from pharmacy.updatepharmacydistance import updatedistance
from utils.sendgridemail import email_log
from utils import commandline

updatedistance()

domain_name,file_type,filename,mode=commandline.main(sys.argv[1:])
cluster=Cluster(os.environ['CB_URL']+'?operation_timeout=2700')
auth=PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(auth)
bucket_name=os.environ['CB_INSTANCE']
cb=cluster.open_bucket(bucket_name)

# modified by Hari on 27/12/2018
# path = os.environ['CB_DATA']
host = socket.gethostname()
currentdate = datetime.now()
currentdate = currentdate.strftime("%m%d%y%H%M%S")
log = path+'/'+domain_name+'/'+file_type+'/log/'+"displaymessagejson"+currentdate+'.txt'
logfile = open(log,"w")

data=json.load(open(path+'/GWLABS001/displaymessage/appmessages.json'))
print('file read')
for k,v in data['es'].items():
	print(k,v)
	if mode.strip().upper() == 'FINAL':
		query=N1QLQuery('Update `'+os.environ['CB_INSTANCE']+'` set message=$value where type="displaymessage" and message_type=$key and language="ES"',key=k,value=v)
		cb.n1ql_query(query).execute()
	else:
		logfile.write(str(str(k)+':'+str(v)))

# added by Hari on 27/12/2018
if mode.strip().upper() == 'DRAFT':
	logfile.write(' display message from json update - Draft Mode :'+host+filename)
	print("File run on DRAFT mode")
	subject = 'display message from json update - Draft Mode :'+host
	logfile.close()
	email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','SSubramani@GWLabs.com',subject,['display  message from json File '+log,'display message from json Exception'],log,True)
else:
	logfile.close()