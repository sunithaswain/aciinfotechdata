########################################
# !/usr/bin/env python
# title         : rebategatewaydata.py
#description   : Monthly Outbound file to GHP listing a claim of all the transactions of previous month
# author        : Disha
# date created  : 20190607
# date last modified    : 20190607 08:30
# version       : 0.1
# maintainer    : Disha
# email         : dwagle@fliptrx.com
# status        : Development
# Python Version: 3.5.2
# usage         : python rebategatewaydata.py -d GWLABS001 -t rebate_gateway -m draft
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
# 0.1							20190118	Add header
# #######################################
#import files only
from sqlalchemy import create_engine
from datetime import datetime, timedelta
import traceback
import pandas as pd
if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   from utils.truevault import User_Class
   from utils import commandline as commandline
   from gateway.rebategatewaysftp import sftptransfer
   from utils.sendgridemail import email_log, email_log_custom





domain, file_type, file_name, mode = commandline.main(sys.argv[1:])

engine = create_engine(
    'postgresql://'+os.environ['RDS_USERID']+':'+os.environ['RDS_PWD']+'@'+os.environ['RDS_SERVER']+':'+os.environ['RDS_PORT']+'/'+os.environ['RDS_DBNAME'])

fields=['Gateway Client ID','Gateway Client Type','Numeric Signage','Patient Pay Flag','Filler','Claim ID','Unique Transaction ID','Product ID (NDC)','Product ID Qualifier','Claim Type','Quantity Dispensed','Unit of Measure','Days of Supply','Date of Service','Date Received','Mail/Retail Code','Rx Number','Fill Number','Service Provider ID','Service Provider ID Qualifier','Prescriber ID Number','Prescriber ID Number Qualifier','Plan Basis of Reimbursement Determination','Price Source','MAC Identifier','AWP Unit','Total AWP','Client Ingredient Cost','Client Dispensing Fee','Client Sales Tax','Plan Copay','Deductible Applied','Total Patient Pay Amount','Plan Ingredient Cost','Plan Dispensing Fee','Plan Sales Tax','Pharmacy Ingredient Cost','Pharmacy Dispensing Fee','Pharmacy Sales Tax','Submitted Usual and Customary Cost','Submitted Ingredient Cost','Submitted Dispensing Fee','Submitted Sales Tax','Net Check Amount','Copay Differential','340B Indicator','Claim Indicator','Other Coverage Code','Submission Clarification Code','Brand Generic Indicator','DAW','Compound Code','Formulary Indicator','Prior Authorization Flag','Prior Authorization Description','Member Number','Member State','Relationship Code','Patient Birth Date','Patient First Name','Patient Gender Code','Person Number','Hierarchy Level 1','Hierarchy Level 2','Hierarchy Level 3','Hierarchy Level 4','Line of Business Indicator','Medicaid Indicator','Client Custom Field #1','BIN','PCN','LICS Indicator','Drug Coverage Indicator','Tier Code','CMS Contract Num','PBP Num','Starting Stage of Med D Claim','Ending Stage of Med D Claim','Drug Spend Amount for Deductible Stage','Drug Spend Amount for Initial Coverage Stage','Drug Spend Amount for Coverage Gap Stage','Drug Spend Amount for Catastrophic Stage']


def generate_data():

    time_filter = datetime.now() - timedelta(datetime.now().day)
    timestamp = datetime.strftime(datetime.now(), '%Y%m%d')
    params = "'" + str(time_filter.year) + "-" + str(time_filter.month).zfill(2) + "%%" + "'"
    print(params)
    datafile = open(os.environ['CB_DATA']+'//'+file_type +
                    '//' + 'GTWY_FLIPTRX_' + timestamp + '.txt', 'w')
    line = ''
    for value in fields:
        line = line+str(value)+'|'
    datafile.write(line[:-1] + '\r\n')
    line=''
    logfile = open(os.environ['CB_DATA']+'//'+file_type +
                   '//log//'+'GatewayLog'+timestamp+'.txt', 'w')
    df=pd.DataFrame()
    ite = 0
    resultdf = pd.DataFrame()
    resultdf = pd.read_sql_query(
        f"select t.* from flipt_dw.dw_processedclaims  t where claim_status in ('P','X') and claim_date like {params}", engine)
    
    for i,result1 in resultdf.iterrows():
        try:
            result = {}
            for key, val in result1.items():
                if val:
                    result[key] = val
                elif not val or str(val) == 'nan':
                    result[key] = ''
            data_dict = dict.fromkeys(fields,"")
            data_dict['Gateway Client ID']= '1168'
            data_dict['Gateway Client Type']='R'
            data_dict['Numeric Signage']='Y'
            data_dict['Claim ID'] = result['auth_id']
            data_dict['Unique Transaction ID'] = str(
                result['auth_id'])+result['claim_status']
            if len(df)!=0 and data_dict['Unique Transaction ID'] in list(df['Unique Transaction ID']): continue
            data_dict['Product ID (NDC)']=result['product_id_ndc']
            data_dict['Product ID Qualifier']='03' 
            data_dict['Claim Type'] = result['claim_status'].replace('X', 'R')
            data_dict['Quantity Dispensed']=result['quantity_dispensed']
            data_dict['Unit of Measure'] = 'N/A'
            try:
                ndc_result = pd.read_sql_query(
                    "Select pkg_uom from flipt_dw.dw_ndc_drugs where ndc="+result['product_id_ndc'], engine)
                data_dict['Unit of Measure'] = ndc_result['pkg_uom'].values[0]
            except Exception as e:
                #print(result['product_id_ndc'],e)
                pass
            data_dict['Days of Supply'] = str(int(result['days_supply'])) if result['days_supply'] else ''
            data_dict['Date of Service']=result['date_of_service']
            timestampformats = ["%Y-%m-%dT%H:%M:%S.%f", "%Y-%m-%dT%H:%M:%S",
                                "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M:%S.%f"]
            for tsform in timestampformats:
                try:
                    data_dict['Date Received'] = datetime.strftime(datetime.strptime(result['claim_date'], tsform), '%Y%m%d')
                except Exception as _:
                    continue
            
            data_dict['Mail/Retail Code']='R'
            if result['pharmacy_npi'] in ['1063675684','1780823500','1003001934','1942441886']:
                data_dict['Mail/Retail Code']='M'
            data_dict['Rx Number']=result['rx_number']
            data_dict['Fill Number']=result['fill_number']
            data_dict['Service Provider ID']=result['pharmacy_npi']
            data_dict['Service Provider ID Qualifier']='01'
            data_dict['Prescriber ID Number']=result['prescriber_npi']
            data_dict['Prescriber ID Number Qualifier']='01'
            data_dict['Price Source']='MAC'
            data_dict['MAC Identifier']='Y'
            if result['rx_awp_unit_price'] in ['0.00', '']:
                data_dict['Price Source']='AWP'
                data_dict['MAC Identifier']='N'
            data_dict['AWP Unit'] = str(result['rx_awp_unit_price'])
            sign=''
            if '-' in str(result['rx_awp_unit_price']):
               sign = '-'
            try:
                data_dict['Total AWP'] = sign + \
                    str(float(result['rx_awp_unit_price']) *
                        float(result['quantity_dispensed']))
            except:
                print('Could not determine total awp',
                      result.get('rx_prescription_id', ''))
            data_dict['Client Ingredient Cost']=result['client_ing_cost']
            data_dict['Client Dispensing Fee']=result['client_disp_fee']
            data_dict['Client Sales Tax']='0.00'
            data_dict['Plan Copay']=result['patient_paid']
            data_dict['Deductible Applied']='0'
            try:
                prescription_result = pd.read_sql_query(
                    "Select drug_deductible_exempt from flipt_dw.dw_prescription where prescription_id="+"'"+result['rx_prescription_id']+"'", engine)
                if True in list(prescription_result['drug_deductible_exempt']):
                    data_dict['Deductible Applied']=result['patient_paid']
            except Exception as e:
                logfile.write(result['rx_prescription_id'] + '\r\n')
                logfile.write('Transaction not found---\r\n')
                print(result['rx_prescription_id'], e)
            data_dict['Total Patient Pay Amount']=result['patient_paid']
            data_dict['Submitted Usual and Customary Cost']=result['submitted_uc']
            data_dict['Submitted Ingredient Cost']=result['submitted_ing_cost']
            data_dict['Submitted Dispensing Fee']=result['submitted_disp_fee']
            data_dict['Submitted Sales Tax']=result['submitted_sales_tax']
            data_dict['Net Check Amount']=result['amt_paid_to_pharmacy']
            data_dict['Copay Differential']='N'
            data_dict['Claim Indicator']='11'
            data_dict['Other Coverage Code']='01'
            data_dict['Submission Clarification Code']='01'
            data_dict['DAW']='0'
            data_dict['Formulary Indicator']='Y'
            data_dict['Member Number'] = result['member_id']
            data_dict['Member State'] = ''
            data_dict['Patient First Name'] = ''
            data_dict['Patient Birth Date'] = ''
            data_dict['Patient Gender Code'] = ''
            if len(result['member_id']) < 9: data_dict['Member Number'] = result['member_id'] + result['person_code']
            obj = User_Class(None,None)
            search_option={'full_document':True,'filter':{'flipt_person_id':{'type':'eq','value':str(result['member_id'][:7]),'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
            att,_=obj.search_user(search_option)
            if att!=None:
                data_dict['Member State']=att['state']
                if data_dict['Member Number'][-2:]=='01': 
                    data_dict['Patient First Name'] = att['first_name']
                    data_dict['Patient Birth Date'] = att['date_of_birth'].split(' ')[
                        0].replace('-', '')
                    data_dict['Patient Gender Code'] = att['gender'].replace(
                        'F', '2').replace('M', '1')
                else:
                    for dep in att['dependents']:
                        if dep['person_code']==data_dict['Member Number'][-2:]:
                            data_dict['Patient First Name'] = dep['first_name']
                            data_dict['Patient Birth Date'] = dep['date_of_birth'].split(' ')[
                                0].replace('-', '')
                            data_dict['Patient Gender Code'] = dep['gender'].replace(
                                'F', '2').replace('M', '1')
            
            if result['rel_code'] is None or result['rel_code'].strip()=='':
                if data_dict['Member Number'][-2:]=='01': data_dict['Relationship Code']='01'
                elif data_dict['Member Number'][-2:]=='02': data_dict['Relationship Code']='02'
                else: data_dict['Relationship Code']='03'
            else:
                data_dict['Relationship Code']='0'+result['rel_code']
            data_dict['Person Number']=data_dict['Member Number'][-2:]
            data_dict['Line of Business Indicator']='1'
            data_dict['Medicaid Indicator']='N'
            data_dict['BIN']=result['bin']
            data_dict['PCN']=result['pcn']
            df=df.append(data_dict,ignore_index=True)
            line =''
            for _,value in data_dict.items():
                line=line+str(value)+'|'
            ite=ite+1
            print(ite)
            datafile.write(line[:-1] + '\r\n')
        except Exception as e:
            logfile.write(result['rx_prescription_id'] + '\r\n')
            logfile.write(str(e)+'---\r\n')
            #print(e)
            traceback.print_exc()

    datafile.close()
    logfile.close()
    #print(list(df))
    phi_columns = ['Member Number', 'Member State', 'Relationship Code', 'Patient Birth Date', 'Patient First Name', 'Patient Gender Code', 'Person Number']
    try:
        df.drop(phi_columns, axis=1, inplace=True)
    except Exception as e:
        print(e)
    df.to_csv(os.environ['CB_DATA']+'//'+file_type +
              '//'+'GatewayLog'+timestamp +
              '.csv', index=False, columns=fields)
    if mode.upper().strip() == 'FINAL':
        upload_path = '/uploads'
        #if os.environ['INSTANCE_TYPE'] == 'PROD':
        #upload_path = '/FromFliptRx'
        sftptransfer(os.environ['CB_DATA']+'//'+file_type + '//' + 'GTWY_FLIPTRX_' +
                     timestamp + '.txt', upload_path + '/' + 'GTWY_FLIPTRX_' + timestamp + '.txt', 'PUT')
        email_log('noreply@fliptrx.com', 'fliptintegration@fliptrx.com', 'spal@fliptrx.com', 'Rebate Gateway Monthly Claims', ['Processing of Rebate Gateway File GTWY_FLIPTRX_' + timestamp + '.txt', 'GHP Exception'], os.environ['CB_DATA']+'//'+file_type + '//'+'GatewayLog'+timestamp +'.csv', True)
    os.remove(os.environ['CB_DATA']+'//'+file_type +'//' + 'GTWY_FLIPTRX_' + timestamp + '.txt')
        
generate_data()








