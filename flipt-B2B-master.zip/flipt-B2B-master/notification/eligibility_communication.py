# Usage python
# SCRIPT: eligibility_communication.py

import os
import sys
import traceback
import requests
from utils.helper_functions import *
from requests.auth import HTTPBasicAuth
from utils.sendgridemail import email_template
from utils.sendgridemail import email_log


def user_activation_communication(api_key, cb_hndl, mode='final'):
    def filterusers(username):
        filters = ['test', 'domandtom', 'rey1@company',
                   'nttdata', 'wecare', 'bluelabel', 'admin']
        filtered = False
        for xc in filters:
            if xc in username:
                filtered = True
                break
        return filtered

    def read_user(userid):
        params = {'full': True}
        try:
            r = requests.get('https://api.truevault.com/v2/users/%s' % str(userid),
                             auth=HTTPBasicAuth(api_key, ''),
                             params=params,
                             timeout=10)
            return r.json()

        except Exception as e:
            type, value, etraceback = sys.exc_info()
            error = ""
            x = traceback.format_exception(type, value, etraceback)
            for i in x:
                error = error + i
        return None

    def get_all_users_with_id(domain_mappings):
        import pandas as pd
        from datetime import datetime

        usernum = 0
        finaldf = pd.DataFrame()
        df = pd.DataFrame()
        r = requests.get('https://api.truevault.com/v1/users',
                         auth=HTTPBasicAuth(api_key, ''), timeout=10)
        response = r.json()

        # obj=User_Class()
        totalusers = len(response['users'])
        print("Total Number of Users: ", totalusers)
        for user in response['users']:
            usernum += 1
            result = read_user(user['user_id'])

            # print('Result',result)
            try:
                att = result['users'][0]['attributes']

            except Exception as e:
                continue

            if 'employee_id' not in att:
                continue

            if filterusers(user['username']) or att['active']:
                #print('User', user['username'])
                continue

            difference = (
                datetime.today() - datetime.strptime(att['created_at'], '%Y-%m-%dT%H:%M:%S.%f'))
            # print('User',i['username'])
            #print('Difference in Days',difference.days)
            sender = 'wecare@fliptrx.com'
            receiver = user['username']
            # print('Reciver',receiver)

            ccreceiver = None
            subject = ''
            templateid = ''
            cc_to = []
            params = {'company_name': domain_mappings[att['domain_name']]['cmpny_legalname'],
                      'first_name': att['first_name'],
                      'concierge_phone_number': domain_mappings[att['domain_name']]['phone']}

            if 'personal_email' in att:
                cc_to.extend(att['personal_email'])

            if 'communication_option_email' in att:
                cc_to.append(att['communication_option_email'])

            if cc_to:
                ccreceiver = ','.join(list(cc_to))

            try:
                if difference.days == domain_mappings[att['domain_name']]['emp_register_reminder2']:
                    #print('Difference in Days',difference.days)
                    subject = 'You Need to Register Your Flipt App to Start Getting Your Prescription Benefits'

                    if 'account_type' not in att:
                        templateid = os.environ['EMPLOYEE_REGISTRATION_INSTRUCTIONS_1REMINDER']
                    else:
                        templateid = os.environ['DEPENDENT_REGISTRATION_INSTRUCTIONS_1REMINDER']
                        params['dependent_first_name'] = params['first_name']
                        subject = f"Dear {att['first_name']}, you need to register your Flipt App"

                elif difference.days == domain_mappings[att['domain_name']]['emp_register_reminder3']:
                    subject = 'What Are You Waiting For? Register Your Flipt App TODAY'
                    templateid = os.environ['EMPLOYEE_REGISTRATION_INSTRUCTIONS_2REMINDER']

                elif difference.days == domain_mappings[att['domain_name']]['emp_register_final']:
                    subject = 'Don’t Miss Out – Start Saving with Flipt!'
                    templateid = os.environ['REMINDER_INSTRUCTIONS_30DAYS_WITH_DEPENDENTS']

            except Exception as e:
                type, value, etraceback = sys.exc_info()
                terror = ""
                x = traceback.format_exception(type, value, etraceback)
                # print(x)
                for i in x:
                    terror = terror + i

                email_log('noreply@fliptrx.com', 'fliptintegration@fliptrx.com', None,
                          'EligibilityCommunication Processing Error', [terror], None, False)
                print('Error in catch')
                continue

            if templateid:
                #print ('Email Template')
                if mode.lower() == 'final':
                    email_template(sender, receiver, ccreceiver,
                                   subject, templateid, params, None, False)

    dom_mappings = get_domain_mapping(cb_hndl)
    get_all_users_with_id(dom_mappings)
# end function


if __name__ == '__main__':
    from utils.helper_functions import cb_authenticate

    api_key = os.environ['TV_API_KEY']
    cb = cb_authenticate()

    # print(get_domain_mapping(cb))
    user_activation_communication(api_key, cb)
    print('Eligibility Communication program completed')
# end __main__
