########################################
# !/usr/bin/env python 

# title : twilioSendSMS.py
# description : 
# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  Used in other programs
# Revisions:
# Version RevisedBy Date Change Jira description 
# ------- --------- -------- ------------------

# #######################################
from twilio.rest import Client
import os
import re

def sendSMS(toPhNumber, msgBody):
    try:
        # Account Sid and Auth Token from twilio.com/console
        account_sid = os.environ['TWILIO_SID']
        auth_token = os.environ['TWILIO_AUTH_TOKEN']
        response_phone = os.environ['RESPONSE_PHONENUMBER']
        client = Client(account_sid, auth_token)

        # if no phone number
        if not toPhNumber or toPhNumber == '':
            return 'failed', 'Destination phone number not identified'

        toPhNumber = re.sub('[^0-9]', '', toPhNumber)[-10:]
        if len(toPhNumber) != 10:
            return 'failed', 'Destination phone number is incorrect'
        toPhNumber = '+1'+toPhNumber

        # old response phone num: from_='+12018905255' <-- production response sms server
        message = client.messages.create(body=msgBody, from_=response_phone, to=toPhNumber)
        # print(message.status)
        return 'success', message.sid
    except Exception as e:
        # traceback.print_exc()
        print(e)
        return 'failed', str(e)
    

# ---------------------------------------------------------------
# sample call in another program
# import twilioSendSMS 
# status, msg = twilioSendSMS.sendSMS('', '', +13648889940', "Flipt Test SMS 2nd test.")
# print(status, msg)


# this is only for testing
# if __name__ == "__main__":
#     status, msg = sendSMS('0024344','','', "Flipt Test SMS 3rd disha test.")
#     status, msg = sendSMS('+13648889940', "Flipt Test SMS 2nd test.")
#     print(status, msg)


