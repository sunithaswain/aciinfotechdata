########################################
# !/usr/bin/env python
# title         : scdailyclaimrecon_daterange.py
# description   : This program generates daily claim reconciliation report based on date range given .
# author        : Deepthi
# date created  : 20190122
# date last modified    : 20190122 
# version       : 0.1
# maintainer    : Deepthi
# email         : deepthi.gollapudi@nttdata.com
# status        : Development
# Python Version: 3.5.2
# usage         : python scdailyclaimrecon_daterange.py -d GWLABS001 -t dailyclaim_reconciliation -f sc_recon_report -m DRAFT -s 01-JAN-2019 -e 23-Jan-2019

# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#
# #######################################
if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']
 
import os
import codecs
import sys
from datetime import datetime ,date ,time
import logging
import pandas as pd
import xlsxwriter
import dateutil.parser as parser

from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery

from utils import opccmdline
from utils.sendgridemail import email_log
from utils.FliptConcurrent import concurrent

domain,file_type,file_name,mode,start_text,end_text = opccmdline.main(sys.argv[1:])
cluster = Cluster(os.environ['CB_URL'])
auth = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(auth)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])


filepath = path+'/'+domain+'/'+file_type+'/Daterange/'+file_name+'_'+datetime.now().strftime("%Y%m%d%H%M")+'.xlsx'
print("Filepath:",filepath)

start_date = parser.parse(start_text)
start_date = start_date.isoformat()
end_text = end_text+' 23:59:59'
end_date = parser.parse(end_text)
end_date = end_date.isoformat()

print("Start Date: " ,start_date)
print("End Date: " ,end_date)
req=concurrent(sys.argv[0],sys.argv[1:],2)

def extract_dailyclaimrecon():
	"""
	generate daily claim reconciliation report based on the data range given 

	"""
	
	#Create a workbook and add a worksheet.
	workbook = xlsxwriter.Workbook(filepath)
	print("workbook:",workbook)
	worksheet = workbook.add_worksheet()
	print("worksheet:",worksheet)
	
	# Different Formats for Rows and Columns
	header_format = workbook.add_format({
		'bold': True,
		'text_wrap': True,
		'valign': 'top',
		'fg_color': '#FF0000',
		'border': 1})
	header_format.set_font_color('#FFFFFF')
	header_format.set_border_color('#FF0000')
	print("header format")
	parameter_format = workbook.add_format({
		'bold': True,
		'text_wrap': True,
		'valign': 'top',
		'fg_color': '#FF0000',
		'border': 1})
	parameter_format.set_font_color('#FFFFFF')	
	parameter_format.set_border_color('#FF0000')
	print("parameter format")
	row_format = workbook.add_format({
		'bold': False,
		'text_wrap': True,
		'valign': 'top',
		'fg_color': '#FFFFFF',
		'border': 1})	
	row_format.set_border_color('#FF0000')
	print("row format")
	merge_format = workbook.add_format({
		'bold': True,
		'text_wrap': True,
		'align': 'center',
		'valign': 'vcenter',
		'fg_color': '#FF0000',
		'border': 1})
	merge_format.set_font_size(35)
	merge_format.set_font_color('#FFFFFF')
	print("merge format")	
		
	# Set column Width
	worksheet.set_column('A:A',22)
	worksheet.set_column('B:B',36)
	worksheet.set_column('C:C',23)
	worksheet.set_column('D:D',25)
	worksheet.set_column('E:E',25)
	worksheet.set_column('F:F',25)
	worksheet.set_column('G:G',25)
	worksheet.set_column('H:H',14)
	worksheet.set_column('I:I',14)
	worksheet.set_column('J:J',15)
	worksheet.set_column('K:K',17)
	worksheet.set_column('L:L',17)
	worksheet.set_column('M:M',17)
	worksheet.set_column('N:N',17)
	worksheet.set_column('O:O',17)
	worksheet.set_column('P:P',17)
	worksheet.set_column('Q:Q',17)
	worksheet.set_column('R:R',17)
	worksheet.set_column('S:S',17)
	worksheet.set_column('T:T',17)
	worksheet.set_column('U:U',17)
	worksheet.set_column('V:V',17)		
	excrow ,exccol = 0,0
	print("excrow")
	
	# Report Header
	worksheet.merge_range('D1:F5', 'Script Claim Reconciliation Report', merge_format)
	worksheet.write(7, 0, "Statement Date Range",parameter_format)
	worksheet.write(8, 0, "Domain",parameter_format)
	worksheet.write(7, 1, start_date,row_format)
	worksheet.write(7, 2, end_date,row_format)
	worksheet.write(8, 1, domain,row_format)
	worksheet.write(7, 4, "Report Generated on ",parameter_format)
	worksheet.write(7, 5, datetime.now().isoformat(), row_format)
	#Column Names
	print("Worksheet")
	excrow = 11
	worksheet.write(excrow, 0, "Transaction ID",header_format)
	worksheet.write(excrow, 1, "Authorization ID",header_format)
	worksheet.write(excrow, 2, "SC Claim Type",header_format)
	worksheet.write(excrow, 3, "Flipt Prescription Status",header_format)
	worksheet.write(excrow, 4, "SC Dispensed Quantity",header_format)
	worksheet.write(excrow, 5, "Flipt Prescription Quantity",header_format)
	worksheet.write(excrow, 6, "SC Actual Patient Paid",header_format)
	worksheet.write(excrow, 7, "Flipt Employee OPC",header_format)
	worksheet.write(excrow, 8, "SC Client Due Amount",header_format)
	worksheet.write(excrow, 9, "Flipt Employer Cost",header_format)
	worksheet.write(excrow, 10, "Brand/Generic",header_format)
	worksheet.write(excrow, 11, "Flipt Rebate factor",header_format)
	worksheet.write(excrow, 12, "Flipt Drug Cost",header_format)
	worksheet.write(excrow, 13, "Flipt Drug Cost Before Rebate",header_format)
	worksheet.write(excrow, 14, "SC Unit Price",header_format)
	worksheet.write(excrow, 15, "Flipt Unit Price",header_format)
	worksheet.write(excrow, 16, "Flipt Unit Price Before Rebate",header_format)
	worksheet.write(excrow, 17, "Flipt Pharmacy Discount",header_format)
	worksheet.write(excrow, 18, "Flipt Pharmacy Dispensing Fee",header_format)
	worksheet.write(excrow, 19, "PaymentOption",header_format)
	worksheet.write(excrow, 20, "Message",header_format)
	worksheet.write(excrow, 21, "Analysis",header_format)
	worksheet.write(excrow, 22, "Category",header_format)
	worksheet.write(excrow, 23, "Group",header_format)
	
	print("Before Query")
	claimextract = N1QLQuery('select transaction_id,auth_id,claim_type,rx_status,quantity_dispensed,quantity,patient_paid,employee_opc,client_due_amt,employer_cost,brand_generic,rebate_factor,drug_cost,drug_cost_before_rebate,sc_unit_price,unit_price,unit_price_before_rebate,pharmacy_discount,pharmacy_dispensing_fee,payment_option,message,analysis,category,`group` from `'+os.environ['CB_INSTANCE']+'`  where type="daily_reconciliation_report" and (update_date >= $supdate_date and update_date <= $eupdate_date)',supdate_date = start_date, eupdate_date = end_date)		
	claimextract.adhoc = False
	claimextract.timeout = 600
	excrow = 12
	rec_count = 1
	for record in cb.n1ql_query(claimextract):
		worksheet.write(excrow, 0, record['transaction_id'],row_format)
		worksheet.write(excrow, 1, record['auth_id'],row_format)
		worksheet.write(excrow, 2, record['claim_type'],row_format)
		worksheet.write(excrow, 3, record['rx_status'],row_format)
		worksheet.write(excrow, 4, record['quantity_dispensed'],row_format)
		worksheet.write(excrow, 5, record['quantity'],row_format)
		worksheet.write(excrow, 6, record['patient_paid'],row_format)
		worksheet.write(excrow, 7, record['employee_opc'],row_format)
		worksheet.write(excrow, 8, record['client_due_amt'],row_format)
		worksheet.write(excrow, 9, record['employer_cost'],row_format)
		worksheet.write(excrow, 10, record['brand_generic'],row_format)
		worksheet.write(excrow, 11, record['rebate_factor'],row_format)
		worksheet.write(excrow, 12, record['drug_cost'],row_format)
		worksheet.write(excrow, 13, record['drug_cost_before_rebate'],row_format)
		worksheet.write(excrow, 14, record['sc_unit_price'],row_format)
		worksheet.write(excrow, 15, record['unit_price'],row_format)
		worksheet.write(excrow, 16, record['unit_price_before_rebate'],row_format)
		worksheet.write(excrow, 17, record['pharmacy_discount'],row_format)
		worksheet.write(excrow, 18, record['pharmacy_dispensing_fee'],row_format)
		worksheet.write(excrow, 19, record['payment_option'],row_format)
		worksheet.write(excrow, 20, record['message'],row_format)
		worksheet.write(excrow, 21, record['analysis'],row_format)
		if 'category' in record:
			worksheet.write(excrow, 22, record['category'],row_format)
		else:
			worksheet.write(excrow, 22, "",row_format)
		if 'group' in record:
			worksheet.write(excrow, 23, record['group'],row_format)
		else:
			worksheet.write(excrow, 23, "",row_format)
		excrow=excrow+1
		rec_count = rec_count + 1
		
	req.no_rec_processed=rec_count

	if os.environ['INSTANCE_TYPE'] == 'PROD':
		if rec_count > 0:
			print("No. of records in  File "+ str(rec_count))
			workbook.close()
			#email_log('noreply@fliptrx.com','FliptIntegration@fliptrx.com','dwagle@fliptrx.com,deepthi.gollapudi@nttdata.com,SPal@FliptRx.com,AKarlis@FliptRx.com','Script Claim Reconciliation Report generation - Completed',['Script Claim Reconciliation Report generated ','Script Claim Report Generation Exception'],filepath)
			email_log('noreply@fliptrx.com','FliptIntegration@fliptrx.com','spal@fliptrx.com,deepthi.gollapudi@nttdata.com','Script Claim Reconciliation Report generation - Completed',['Script Claim Reconciliation Report generated ','Script Claim Report Generation Exception'],filepath)
			
			req.close()
			exit()	

		else:
			print("No claims found for this date range")
			
			email_log('noreply@fliptrx.com','deepthi.gollapudi@nttdata.com','fliptintegration@fliptrx.com,spal@fliptrx.com','No claims found for this date range',['Script Claim Reconciliation Report generated','Script Claim Report Generation Exception' ],None,False)
			workbook.close()
			req.close()
			exit()	
	
extract_dailyclaimrecon()
	

