if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']
 
import xlsxwriter
import requests
import os
from utils import opccmdline 
import sys
import dateutil.parser as parser
import socket
import json
import pandas as pd
import base64
import time
from updatepbmprice import pbmpriceupdate
from requests.auth import HTTPBasicAuth
from types import SimpleNamespace as Namespace
from decimal import Decimal
from datetime import datetime ,date 
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from utils.sendgridemail import email_log
from utils.truevault import User_Class
from utils.FliptConcurrent import concurrent

cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
# path = os.environ['CB_DATA']
url = os.environ['GRAPHQL_URL']
domain,file_type,file_name,mode,start_text,end_text = opccmdline.main(sys.argv[1:])
req=concurrent(sys.argv[0],sys.argv[1:],2)
currentdate = datetime.now().isoformat()
filepath = path+'/'+domain+'/'+file_type+'/MonthlyReconciliationReport'+str(currentdate)+'.xlsx'
image_path = path+'/'+domain+'/'+file_type+'/gnw.PNG'
flipt_path = path+'/'+domain+'/'+file_type+'/flipt.PNG'
host = socket.gethostname()
ename = ''
fname = ''
lname = ''
subject = ''
empid = ''

# Create a workbook and add a worksheet.
workbook = xlsxwriter.Workbook(filepath)
worksheet = workbook.add_worksheet()
start_date = parser.parse(start_text)
start_date = start_date.isoformat()
end_text = end_text+' 23:59:59'
end_date = parser.parse(end_text)
end_date = end_date.isoformat()
filled_date = end_date
brand_discount = 0
generic_discount = 0
mheaders = ""
price_type = ''
print(start_date)
print(end_date)

#load invoice data
batchid=str(cb.counter('docid',delta=1).value)
invoice=pd.read_excel(path+'/'+domain+'/'+file_type+'/'+file_name)
invoice.sort_values(by=['Date/Time'],inplace=True)
invoice['Transaction ID']=invoice['Transaction ID'].apply(lambda x: int(x) if pd.isnull(x)==False else '')
invoice['GPI']=invoice['GPI'].apply(lambda x: str(x).replace('.0','').zfill(14))
print(invoice.head())
for i,r in invoice.iterrows():
	d=dict()
	
	for col in list(invoice):
		if col=='Date/Time': continue
		d[col.lower().replace(' ','_')]=str(r[col]).strip()
	
	d['claim_date']=r['Date/Time'].isoformat()
	d['type']='sc_invoice'
	try:
		d['claimdate_millis']=str(datetime.strptime(d['claim_date'],"%Y-%m-%dT%H:%M:%S.%f").timestamp()*1000)
	except Exception as e:
		d['claimdate_millis']=str(datetime.strptime(d['claim_date'],"%Y-%m-%dT%H:%M:%S").timestamp()*1000)
	d['batchid']=batchid
	#print(d)
	entriesToRemove = ('gender','patient_first_name','patient_last_name','date_of_birth','patient_age')
	for k in entriesToRemove:
		d.pop(k, None)
	cb.upsert(str(cb.counter('docid',delta=1).value),d)
	
print(batchid)
time.sleep(10)

# Code to Sign in and Get the Header by Encoding the Access token

# Different Formats for Rows and Columns
header_format = workbook.add_format({
    'bold': True,
    'text_wrap': True,
    'valign': 'top',
	'align':'center',
    'fg_color': '#FF0000',
    'border': 1})
header_format.set_font_color('#FFFFFF')
header_format.set_border_color('#FF0000')
	
parameter_format = workbook.add_format({
    'bold': True,
    'text_wrap': True,
    'valign': 'top',
    'fg_color': '#FF0000',
    'border': 1})
parameter_format.set_font_color('#FFFFFF')	
parameter_format.set_border_color('#FF0000')

row_format = workbook.add_format({
    'bold': False,
    'text_wrap': True,
    'valign': 'top',
	'align':'center',
    'fg_color': '#FFFFFF',
    'border': 1})	
row_format.set_border_color('#FF0000')

merge_format = workbook.add_format({
    'bold': True,
    'text_wrap': True,
	'align': 'center',
    'valign': 'vcenter',
    'fg_color': '#FF0000',
    'border': 1})
merge_format.set_font_size(35)
merge_format.set_font_color('#FFFFFF')
cell_format1 = workbook.add_format({
	'text_wrap': True,
    'valign': 'top',
	'align':'center',
    'fg_color': '#44F737',
    'border': 1})	
cell_format2 = workbook.add_format({
	'text_wrap': True,
    'valign': 'top',
	'align':'center',
    'fg_color': '#FC3912',
    'border': 1})	
merge_cell_format = workbook.add_format({'align': 'center',
                                   'valign': 'vcenter',
                                   'border': 1})
merge_cell_format.set_border_color('#FF0000')

# Start from the first cell. Rows and columns are zero indexed.
row = 0
col = 0
subject = 'Monthly Claims Reconciliation Report - '+host
#worksheet.insert_image('A1', image_path, {'x_scale': 0.5, 'y_scale': 0.5})
worksheet.insert_image('B1', flipt_path, {'x_scale': 0.5, 'y_scale': 0.5})
cancel_date = ''
emp_refund = 0

# Set column Width
worksheet.set_column('A:A',22)
worksheet.set_column('B:B',18)
worksheet.set_column('C:C',23)
worksheet.set_column('D:D',25)
worksheet.set_column('E:E',25)
worksheet.set_column('F:F',25)
worksheet.set_column('G:G',25)
worksheet.set_column('H:H',14)
worksheet.set_column('I:I',14)
worksheet.set_column('J:J',15)
worksheet.set_column('K:K',17)
worksheet.set_column('L:L',17)
worksheet.set_column('M:M',17)
worksheet.set_column('N:N',17)
worksheet.set_column('O:O',17)


# Report Header
worksheet.merge_range('C1:F5', 'Monthly Claims Reconciliation Report', merge_format)

# Report parameters
worksheet.write(7, 0, "Statement Date Range",parameter_format)
worksheet.write(8, 0, "Domain",parameter_format)
worksheet.write(7, 1, start_date,row_format)
worksheet.write(7, 2, end_date,row_format)
worksheet.write(8, 1, domain,row_format)
worksheet.write(7, 4, "Report Generated at ",parameter_format)
worksheet.write(7, 5, currentdate, row_format)
column_names = ['Rx Number','Drug Name','GPI','Brand/Generic','Flipt Drug Cost','Flipt Employer Cost','Flipt Employee OPC','Flipt Unit Price','Flipt Pharmacy Discount','Flipt Unit Price After Discount','Flipt Ing Cost','Flipt Dispensing Fee','Flipt Total Drug Cost','Actual Patient Paid','Flipt Calc. Client Cost','SC Dispensed Qty','SC Ing Cost','SC Dispensing Fee','SC Drug Cost','SC Patient Paid','SC Client Due Amt']
# write it out row by row.
iteration=0
for col in column_names:
	worksheet.write(10, iteration, col,header_format)
	iteration=iteration+1
'''
Rx number,drug name,gpi,b/g,app drug cost,app employer cost,app employee opc,Unit price, pharm disc, unit price after disc (unit price*pharm disc), flip ing cost (unit price aftr disc*disp qty), disp fee, total drug cost (flipt ing cost+disp fee), actual patient paid, calc client cost (total drug cost-actual patient paid),sc disp qty, sc ing cost, sc disp fee, sc drug cost (sc ing cost+sc disp fee),sc patient paid,sc client due amt (sc drug cost-sc patient paid)
'''
scclaimquery = N1QLQuery('Select round(sum(tonumber(client_due_amt)),2) client_due_amt,round(sum(tonumber(patient_pay)),2) patient_pay,round(sum(tonumber(qty)),2) quantity_dispensed,round(sum(tonumber(client_ing_cost)),2) client_ing_cost,round(sum(tonumber(client_disp_fee)),2) client_disp_fee,gpi,product_name,cardholder,transaction_id from `'+os.environ['CB_INSTANCE']+'` where type="sc_invoice" and batchid=$bid and trans_type in ["P","X"] group by gpi,product_name,cardholder,transaction_id',bid=batchid)
scclaimquery.adhoc = False
scclaimquery.timeout = 100
row = 11


for scresult in cb.n1ql_query(scclaimquery):
	start=row+1
	chpone=False
	chptwo=False
	try:
		scdict = {'P':scresult['quantity_dispensed'],'Q':scresult['client_ing_cost'],'R':scresult['client_disp_fee'],'S':scresult['client_ing_cost']+scresult['client_disp_fee'],'T':scresult['patient_pay'],'U':float(scresult['client_ing_cost'])+float(scresult['client_disp_fee'])-float(scresult['patient_pay'])}
	except Exception as e:
		print('1',scresult)
		continue
	fliptquery = N1QLQuery('Select claim_type,claim_date,auth_id,tonumber(patient_paid) patient_paid,transaction_id,tonumber(quantity_dispensed) quantity_dispensed from `'+os.environ['CB_INSTANCE']+'` where type="scdailyclaim" and gpi_code=$gpi and member_id=$ch and claim_date>=$strt and claim_date<=$end and claim_type in ["P","X"] and transaction_id=$tid order by meta().id',strt=start_date,end=end_date,gpi=scresult['gpi'],ch=scresult['cardholder'],tid='prescription::'+scresult['transaction_id'])
	fliptresult=pd.DataFrame()
	transaction_id=scresult['transaction_id']
	authid=''
	for fliptrec in cb.n1ql_query(fliptquery):
		chpone=True
		authid=fliptrec['auth_id']
		fliptresult=fliptresult.append(fliptrec,ignore_index=True)
	if len(fliptresult)>0:
		fliptresult.drop_duplicates(inplace=True)
	end=row+len(fliptresult)+1
	#print('transactionid1',str(scresult['transactionid']).strip())
	prescquery = N1QLQuery('Select prescription_id,drug_name,gpi,brand_generic,tonumber(drug_cost_before_rebate) drug_cost_before_rebate,tonumber(employer_cost) employer_cost,tonumber(employee_opc) employee_opc,tonumber(unit_price_before_rebate) unit_price_before_rebate,tonumber(pharmacy_discount) pharmacy_discount,tonumber(pharmacy_dispensing_fee) pharmacy_dispensing_fee,(tonumber(unit_price_before_rebate)*tonumber(pharmacy_discount)) disc_unit_price from `'+os.environ['CB_INSTANCE']+'` where type="prescription" and prescription_id=$pid',pid="prescription::"+transaction_id)
	
	if str(transaction_id).strip()=="":
		#print('empty transactionid')
		prescquery = N1QLQuery('Select prescription_id,drug_name,gpi,brand_generic,tonumber(drug_cost_before_rebate) drug_cost_before_rebate,tonumber(employer_cost) employer_cost,tonumber(employee_opc) employee_opc,tonumber(unit_price_before_rebate) unit_price_before_rebate,tonumber(pharmacy_discount) pharmacy_discount,tonumber(pharmacy_dispensing_fee) pharmacy_dispensing_fee,(tonumber(unit_price_before_rebate)*tonumber(pharmacy_discount)) disc_unit_price from `'+os.environ['CB_INSTANCE']+'` where type="prescription" and auth_id=$aid',aid=authid)
	start=row+1
	
	prescquery.adhoc=False
	prescquery.timeout=100
	for prescrow in cb.n1ql_query(prescquery):
		chptwo=True
		fliptresultiteration=0
		for i,r in fliptresult.iterrows():
			multiplier=1
			if r['claim_type']=='X': multiplier=-1
			try:
				if fliptresultiteration==0:
					resultlist=[transaction_id,prescrow['drug_name'],prescrow['gpi'],prescrow['brand_generic'],multiplier*prescrow['drug_cost_before_rebate'],multiplier*prescrow['employer_cost'],multiplier*prescrow['employee_opc'],multiplier*prescrow['unit_price_before_rebate'],multiplier*prescrow['pharmacy_discount'],multiplier*prescrow['disc_unit_price'],multiplier*(prescrow['disc_unit_price']*abs(r['quantity_dispensed'])),multiplier*prescrow['pharmacy_dispensing_fee'],multiplier*(prescrow['disc_unit_price']*abs(r['quantity_dispensed'])+prescrow['pharmacy_dispensing_fee']),multiplier*abs(r['patient_paid']),multiplier*(prescrow['disc_unit_price']*abs(r['quantity_dispensed'])+prescrow['pharmacy_dispensing_fee']-abs(r['patient_paid'])),scresult['quantity_dispensed'],scresult['client_ing_cost'],scresult['client_disp_fee'],scresult['client_ing_cost']+scresult['client_disp_fee'],scresult['patient_pay'],float(scresult['client_ing_cost'])+float(scresult['client_disp_fee'])-float(scresult['patient_pay'])]
				else:
					resultlist=[transaction_id,prescrow['drug_name'],prescrow['gpi'],prescrow['brand_generic'],multiplier*prescrow['drug_cost_before_rebate'],multiplier*prescrow['employer_cost'],multiplier*prescrow['employee_opc'],multiplier*prescrow['unit_price_before_rebate'],multiplier*prescrow['pharmacy_discount'],multiplier*prescrow['disc_unit_price'],multiplier*(prescrow['disc_unit_price']*abs(r['quantity_dispensed'])),multiplier*prescrow['pharmacy_dispensing_fee'],multiplier*(prescrow['disc_unit_price']*abs(r['quantity_dispensed'])+prescrow['pharmacy_dispensing_fee']),multiplier*abs(r['patient_paid']),multiplier*(prescrow['disc_unit_price']*abs(r['quantity_dispensed'])+prescrow['pharmacy_dispensing_fee']-abs(r['patient_paid'])),0,0,0,0,0,0]
			except Exception as e:
				#print('2',transaction_id,authid)
				print(scresult['gpi'],scresult['product_name'],scresult['cardholder'])
				if fliptresultiteration==0:
					resultlist=[transaction_id,prescrow['drug_name'],prescrow['gpi'],prescrow['brand_generic'],0,0,0,0,0,0,0,0,0,multiplier*abs(r['patient_paid']),0,scresult['quantity_dispensed'],scresult['client_ing_cost'],scresult['client_disp_fee'],scresult['client_ing_cost']+scresult['client_disp_fee'],scresult['patient_pay'],float(scresult['client_ing_cost'])+float(scresult['client_disp_fee'])-float(scresult['patient_pay'])]
				else:
					resultlist=[transaction_id,prescrow['drug_name'],prescrow['gpi'],prescrow['brand_generic'],0,0,0,0,0,0,0,0,0,multiplier*abs(r['patient_paid']),0,0,0,0,0,0,0]
			fliptresultiteration = fliptresultiteration+1
			iteration=0
			for value in resultlist:
				try:
					worksheet.write(row, iteration, value,row_format)
				except Exception as e1:
					#print('3',transaction_id,authid)
					print(scresult['gpi'],scresult['product_name'],scresult['cardholder'])
					worksheet.write(row, iteration, "",row_format)
				iteration=iteration+1
			
			row=row+1
			
			end=row
	'''
	if len(fliptresult)>1:
		columnalpha='P'
		while columnalpha<'V':
			#worksheet.merge_range(columnalpha+str(row-len(fliptresult)+1)+':'+columnalpha+str(row), scdict[columnalpha], merge_cell_format)
			#worksheet.merge_range(columnalpha+str(start)+':'+columnalpha+str(end), scdict[columnalpha], merge_cell_format)
			columnalpha = chr(ord(columnalpha)+1)
		#worksheet.merge_range('A'+str(row-len(fliptresult)+1)+':'+'A'+str(row), transaction_id, merge_cell_format)
		#worksheet.merge_range('A'+str(start)+':'+'A'+str(end), transaction_id, merge_cell_format)
	'''
	if chpone==False and chptwo==False: print('nothing found',scresult['gpi'],scresult['product_name'],scresult['cardholder'],scresult['transaction_id'])
	elif chpone==False: print('prescinv',scresult['gpi'],scresult['product_name'],scresult['cardholder'],scresult['transaction_id'])
	
	
workbook.close()

if os.environ['INSTANCE_TYPE'] != 'PROD':		
	email_log('DWagle@fliptrx.com','DWagle@fliptrx.com','fliptintegration@fliptrx.com,deepthi.gollapudi@nttdata.com',subject,['Processing of Rx Claims Reconciliation Report '+str(file_name),'Daily Rx Exception'],filepath,True)
else :
	email_log('DWagle@fliptrx.com','DWagle@fliptrx.com','fliptintegration@fliptrx.com,deepthi.gollapudi@nttdata.com',subject,['Processing of Rx Claims Reconciliation Report '+str(file_name),'Daily Rx Exception'],filepath,True)
	#email_log('DWagle@GWLabs.com','LPeysekhman@GWLabs.com','kyang@fliptrx.com',subject,['Processing of Claims Reconciliation Report '+str(file_name),'Daily Rx Exception'],filepath,True)

#os.remove(filepath)
req.close()