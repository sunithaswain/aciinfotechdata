
mutation_for_getDrugPrices = """mutation (
    $term: String, 
	$ndc: String, 
	$npi: String,
	$address: String, 
	$pda: String!, 
	$gpi: String!, 
	$form: String!, 
	$package_size: String!, 
	$package_quantity: String!, 
	$zip_code: String!, 
	$brand_generic: String, 
	$days_of_supply: String, 
	$dosage_strength: String, 
	$flipt_person_id: String, 
	$drug_name: String, 
	$package_qty: String,
	$custom_quantity: Boolean,
	$dosage: String, 
	$gppc: String
	$miles: Int) {
      getDrugPrices(
	  term: $term, 
	  ndc: $ndc, 
	  address: $address, 
	  pda: $pda, 
	  gpi: $gpi, 
	  form: $form, 
	  package_size: $package_size, 
	  package_quantity: $package_quantity, 
	  zip_code: $zip_code, 
	  brand_generic: $brand_generic, 
	  days_of_supply:  $days_of_supply, 
	  dosage_strength: $dosage_strength, 
	  flipt_person_id: $flipt_person_id, 
	  drug_name: $drug_name, 
	  package_qty: $package_qty, 
	  custom_quantity: $custom_quantity
	  dosage: $dosage, 
	  npi: $npi,
	  gppc: $gppc,
	  miles: $miles) {
        pharmacy_name
        pharmacy_city
        pharmacy_address
        pharmacy_zip_code
        drug_price
        drug_baseline_price
        deductible_remaining
        drug_copay
        drug_employer_cost
        drug_out_of_pocket
        drug_reward
        drug_distance
        drug_duration
        provider_id
        pbm_price
        provider_name
        pharmacy_npi
        out_of_pocket_remaining
		pharmacy_location
		drug_penalty
		employee_opc
		reward_percentage
		drug_duration_value
		pbm_estimated_cost
		drug_deductible_exempt
		unit_price_before_rebate
		unit_price
		rebate_factor
		pharmacy_discount
		pharmacy_dispensing_fee
		drug_cost_before_rebate
		rebate_amount
		chaincode
		zone
		reward_share
		retail_reward
		total_payment
		penalty_factor
		pa_flag
		pa_form
		pa_reason
      }
    }"""

mutation_for_save_prescription = """mutation (
      $gpi: String!
      $dpa: String
      $drug: String!
      $form: String!
      $dosage: String!
      $quantity: String!
      $daysofsupply: String
      $locationSelected: String
	    $location: String
      $zipCode: String
      $ddn_form: String
      $ddn_name: String
      $ddn_strength: String
      $strengths: String
      $dosage_strength: String
      $lm_strength: String
      $lm_form: String
      $lm_name: String
      $drug_name: String
      $brand_generic: String
      $ddid: String
      $drug_type: String
      $package_desc: String
      $pkg_desc_cd: String
      $package_qty: String
      $package_quantity: String
      $package_size: String
      $pkg_uom: String
      $lm_ndc: String
      $search_location: String
      $flipt_person_id: String
      $gppc: String
      $search_prescription_id: String
      $custom_quantity: Boolean
      $quantity_type: String
      $custom_qty: String
      $admin_flipt_person_id: String
  	  $rxcui: String
      $days_of_supply: String
      $drug_covered: String
      $drug_notcovered_can_be_dispensed: String
    ) {
      savePrescription(
        gpi: $gpi
        drug: $drug
        form: $form
        dosage: $dosage
        lm_ndc: $lm_ndc
        quantity: $quantity
        dpa: $dpa
        locationSelected: $locationSelected
		location: $location
        zipCode: $zipCode
        ddn_form: $ddn_form
        ddn_name: $ddn_name
        ddn_strength: $ddn_strength
        strengths: $strengths
        dosage_strength: $dosage_strength
        lm_strength: $lm_strength
        lm_form: $lm_form
        lm_name: $lm_name
        drug_name: $drug_name
        brand_generic: $brand_generic
        ddid: $ddid
        drug_type: $drug_type
        package_desc: $package_desc
        pkg_desc_cd: $pkg_desc_cd
        package_qty: $package_qty
        package_quantity: $package_quantity
        package_size: $package_size
        pkg_uom: $pkg_uom
        daysofsupply: $daysofsupply
        search_location: $search_location
        flipt_person_id: $flipt_person_id
        gppc: $gppc
        search_prescription_id: $search_prescription_id
        custom_quantity: $custom_quantity
        quantity_type: $quantity_type
        custom_qty: $custom_qty
        admin_flipt_person_id: $admin_flipt_person_id
        rxcui:$rxcui
        days_of_supply: $days_of_supply
        drug_covered: $drug_covered
        drug_notcovered_can_be_dispensed: $drug_notcovered_can_be_dispensed
      ) {
        prescription_id
      }
    }
"""


mutation_for_route_prescriptions = """mutation (
    $prescription_id: String
    $baseline_cost: String
    $bin: String
    $deductible_remaining: String
    $drug_copay: String
    $drug_cost: String
    $drug_deductible_exempt: Boolean
    $drug_penalty: String
    $employee_opc: String
    $employer_cost: String
    $group_id: String
    $member_id: String
    $npi: String
    $out_of_pocket_remaining: String
    $payment_option: String
    $pbm_estimated_cost: String
    $pbm_price: String
    $pcn: String
    $pharmacy: String
    $reward_percentage: String
    $rewards: String
    $chaincode: String
    $drug_cost_before_rebate: String
    $pharmacy_discount: String
    $pharmacy_dispensing_fee: String
    $rebate_amount: String
    $rebate_factor: String
    $unit_price: String
    $unit_price_before_rebate: String
    $zone: String
    $reward_share: String
    $retail_reward: String
    $total_payment: String
    $penalty_factor: String
    $pa_flag: String
    $pa_form: String
    $pa_reason: String
    $drug_covered: String
    $drug_notcovered_can_be_dispensed: String
    $alternative_drug_rewards: String

    ) {
      v2RoutePrescription(
    prescription_id: $prescription_id
    baseline_cost: $baseline_cost
    bin: $bin
    deductible_remaining: $deductible_remaining
    drug_copay: $drug_copay
    drug_cost: $drug_cost
    drug_deductible_exempt: $drug_deductible_exempt
    drug_penalty: $drug_penalty
    employee_opc: $employee_opc
    employer_cost: $employer_cost
    group_id: $group_id
    member_id: $member_id
    npi: $npi
    out_of_pocket_remaining: $out_of_pocket_remaining
    payment_option: $payment_option
    pbm_estimated_cost: $pbm_estimated_cost
    pbm_price: $pbm_price
    pcn: $pcn
    pharmacy: $pharmacy
    reward_percentage: $reward_percentage
    rewards: $rewards
    chaincode: $chaincode
    drug_cost_before_rebate: $drug_cost_before_rebate
    pharmacy_discount: $pharmacy_discount
    pharmacy_dispensing_fee: $pharmacy_dispensing_fee
    rebate_amount: $rebate_amount
    rebate_factor: $rebate_factor
    unit_price: $unit_price
    unit_price_before_rebate: $unit_price_before_rebate
    zone: $zone
    reward_share: $reward_share
    retail_reward: $retail_reward
    total_payment: $total_payment
    penalty_factor: $penalty_factor
    pa_flag: $pa_flag
    pa_form: $pa_form
    pa_reason: $pa_reason
    drug_covered: $drug_covered
    drug_notcovered_can_be_dispensed: $drug_notcovered_can_be_dispensed
    alternative_drug_rewards: $alternative_drug_rewards
      ) {
        prescription_id
      }
    }
"""
