import os
from couchbase.n1ql import N1QLQuery, N1QLRequest


def getquantity(sclaim_struct, gpi, drug_full_name, dispensed_quantity, ndc):
    """
    Get quantity details from the CouchBase
    :param sclaim_struct:
    :param gpi:
    :param drug_full_name:
    :param dispensed_quantity:
    :param ndc:
    :return: dictionary
    """
    import pandas as pd

    sent_to = ""
    result = dict()
    errorlog = pd.DataFrame()

    rowindex = 0
    gppcfound = False

    # get drug details based on NDC
    sclaim_struct['logger_handle'].info("Using NDC_Drugs to find drug details")
    result['gppc'] = ''
    query = N1QLQuery(
        'Select gppc, drug_name from `' + os.environ['CB_INSTANCE'] + '` where type="ndc_drugs" and ndc=$drugndc',
        drugndc=ndc)
    query.adhoc = False
    drug_name_flag = False
    for res in sclaim_struct['cb_handle'].n1ql_query(query):
        result['gppc'] = res['gppc']
        result['drug_name'] = res['drug_name']
        # Added drug_name flag to initiate different N1Q1 query based on if gppc, ndc found (aka False)
        if result['drug_name'] != '':
            drug_name_flag = True

    # print(result)
    quantitydf = None

    # get drug details based on gpi and full drug name
    if drug_name_flag:
        print('NEW QUERY')
        sclaim_struct['logger_handle'].info('Looking up in drug document using new Query')
        query = N1QLQuery('Select * from `' + os.environ[
            'CB_INSTANCE'] + '` where type="drug" and gpi=$gpicode and drug_name=$drug_name', gpicode=gpi,
                          drug_name=result['drug_name'])
    else:
        print('OLD QUERY')
        sclaim_struct['logger_handle'].info('Looking up in drug document using old Query')
        query = N1QLQuery('Select * from `' + os.environ[
            'CB_INSTANCE'] + '` where type="drug" and gpi=$gpicode and drug_name in (Select raw b.drug_name from `' +
                          os.environ[
                              'CB_INSTANCE'] + '` b where b.type="cp_drug_price" and b.productnamefull=$drug_full_name and gpi=$gpicode limit 1)',
                          gpicode=gpi, drug_full_name=drug_full_name)

    result['lm_ndc'] = ''
    result['equivalent_brand'] = ''
    result['dosage_image'] = ''
    drugfound = False
    gppcindex = -1
    for res in sclaim_struct['cb_handle'].n1ql_query(query):
        print(res)
        sclaim_struct['logger_handle'].info(f'Result: {res}')
        drugfound = True
        try:
            if len(res[os.environ['CB_INSTANCE']]['lm_ndc']) != 0:
                result['lm_ndc'] = res[os.environ['CB_INSTANCE']]['lm_ndc'][0]
        except Exception:
            sclaim_struct['logger_handle'].info('No lm_ndc found')
            print(' no lm_ndc found')
            pass

        result['dpa'] = res[os.environ['CB_INSTANCE']]['pda']
        result['ddn_form'] = res[os.environ['CB_INSTANCE']]['ddn_form']
        result['ddn_name'] = res[os.environ['CB_INSTANCE']]['ddn_name']
        result['ddn_strength'] = res[os.environ['CB_INSTANCE']]['ddn_strength']
        result['strengths'] = 'nan'
        result['lm_strength'] = res[os.environ['CB_INSTANCE']]['lm_strength']
        result['lm_form'] = res[os.environ['CB_INSTANCE']]['lm_form']
        result['lm_name'] = res[os.environ['CB_INSTANCE']]['lm_name']
        result['drug_type'] = res[os.environ['CB_INSTANCE']]['drugtype']
        result['rxcui'] = res[os.environ['CB_INSTANCE']]['rxcui']
        quantitydf = pd.DataFrame(data=res[os.environ['CB_INSTANCE']]['quantity'])
        result['ddid'] = res[os.environ['CB_INSTANCE']]['ddid']
        result['dosage'] = res[os.environ['CB_INSTANCE']]['dosage']
        result['brand_generic'] = res[os.environ['CB_INSTANCE']]['brand_generic']
        result['drug_name'] = res[os.environ['CB_INSTANCE']]['drug_name']
        result['specialty_flag'] = res[os.environ['CB_INSTANCE']]['specialty_flag']
        if 'equivalent' in res[os.environ['CB_INSTANCE']]:
            if len(res[os.environ['CB_INSTANCE']]['equivalent']) > 0: result['equivalent_brand'] = \
                res[os.environ['CB_INSTANCE']]['equivalent'][0]['equ_drug_name']

    if len(result) == 0 or not drugfound:
        sclaim_struct['logger_handle'].error(f'{drug_full_name} not found in drug database')
        errorlog = errorlog.append(
            {'Drug Full Name': drug_full_name, 'GPI': gpi,
             'Pharmacy NPI': '',
             'Dispensed Quantity': dispensed_quantity,
             'MemberID': '',
             'Error': 'Drug Not Found in Drug Database'},
            ignore_index=True)
        return result

    if result['gppc'] in list(quantitydf['gppc']):
        gppcfound = True
        gppcindex = quantitydf[quantitydf['gppc'] == result['gppc']].index[0]
        result['custom_qty'] = quantitydf.loc[gppcindex, 'custom_qty']
    else:
        result['custom_qty'] = quantitydf.loc[rowindex, 'custom_qty']

    quantitydf['package_size'] = quantitydf['package_size'].apply(lambda x: float(x))
    result['custom_quantity'] = False

    # get quantity details based on dispensed quantity
    if result['custom_qty'] == 'package_quantity':
        if float(dispensed_quantity) in list(quantitydf['package_size']):
            if gppcfound and quantitydf.loc[gppcindex, 'package_size'] == float(dispensed_quantity):
                rowindex = gppcindex
            else:
                rowindex = quantitydf[quantitydf['package_size'] == float(dispensed_quantity)].index[0]
            [result['dosage_strength'], result['gppc'], result['package_desc'], result['package_qty'],
             result['package_quantity'], result['package_size'], result['pkg_desc_cd'], result['pkg_uom'],
             result['quantity_type'], result['dosage_image']] = quantitydf.loc[
                rowindex, ['dosage_strength', 'gppc', 'package_desc', 'package_qty', 'package_quantity', 'package_size',
                           'pkg_desc_cd', 'pkg_uom', 'quantity_type', 'dosage_image']]
            result['quantity'] = "1"
        else:
            # calculating new package_qty based on custom dispensed quantity
            psizefound = False
            if gppcfound:
                [result['dosage_strength'], result['gppc'], result['package_desc'], result['package_qty'],
                 result['package_quantity'], result['package_size'], result['pkg_desc_cd'], result['pkg_uom'],
                 result['quantity_type'], result['dosage_image']] = quantitydf.loc[
                    gppcindex, ['dosage_strength', 'gppc', 'package_desc', 'package_qty', 'package_quantity',
                                'package_size', 'pkg_desc_cd', 'pkg_uom', 'quantity_type', 'dosage_image']]
                result['package_quantity'] = str(
                    int(float(dispensed_quantity) / quantitydf.loc[gppcindex, 'package_size']))
                result['package_qty'] = str(result['package_quantity']) + " " + result['quantity_type']
                result['quantity'] = result['package_quantity']
                psizefound = True
            else:
                quantitydf.sort_values(by=['package_size'], ascending=[False], inplace=True)
                for ind, row in quantitydf.iterrows():
                    if float(dispensed_quantity) >= row['package_size']:
                        psizefound = True
                        [result['dosage_strength'], result['package_desc'], result['package_quantity'],
                         result['package_size'], result['pkg_desc_cd'], result['pkg_uom'], result['quantity_type'],
                         result['dosage_image']] = [row['dosage_strength'], row['package_desc'],
                                                    str(int(float(dispensed_quantity) / row['package_size'])),
                                                    row['package_size'], row['pkg_desc_cd'], row['pkg_uom'],
                                                    row['quantity_type'], row['dosage_image']]
                        result['package_qty'] = str(result['package_quantity']) + " " + result['quantity_type']
                        result['quantity'] = result['package_quantity']
                        psizefound = True
                        break
            if not psizefound:
                sclaim_struct['logger_handle'].error(f'Package size cannot be converted for {drug_full_name}')
                errorlog = errorlog.append({'Drug Full Name': drug_full_name, 'GPI': gpi, 'Pharmacy NPI': '',
                                            'Dispensed Quantity': dispensed_quantity, 'MemberID': '',
                                            'Error': 'Package Size(Custom Quantity) cannot be converted using ' +
                                                     'available package sizes in Drug Database'},
                                           ignore_index=True)

            result['custom_quantity'] = True

    if result['custom_qty'] == 'package_size':
        if float(dispensed_quantity) in list(quantitydf['package_size']):
            if gppcfound and quantitydf.loc[gppcindex, 'package_size'] == float(dispensed_quantity):
                rowindex = gppcindex
            else:
                rowindex = quantitydf[quantitydf['package_size'] == float(dispensed_quantity)].index[0]
            [result['dosage_strength'], result['package_desc'], result['package_qty'], result['package_quantity'],
             result['package_size'], result['pkg_desc_cd'], result['pkg_uom'], result['quantity_type'], result['gppc'],
             result['dosage_image']] = quantitydf.loc[
                rowindex, ['dosage_strength', 'package_desc', 'package_qty', 'package_quantity', 'package_size',
                           'pkg_desc_cd', 'pkg_uom', 'quantity_type', 'gppc', 'dosage_image']]
            result['quantity'] = "1"

        else:
            if gppcfound:
                rowindex = gppcindex
            else:
                rowindex = 0
            # updating new package_size based on custom dispensed quantity
            [result['dosage_strength'], result['package_desc'], result['package_quantity'], result['pkg_desc_cd'],
             result['pkg_uom'], result['quantity_type'], result['gppc'], result['dosage_image']] = quantitydf.loc[
                rowindex, ['dosage_strength', 'package_desc', 'package_quantity', 'pkg_desc_cd', 'pkg_uom',
                           'quantity_type', 'gppc', 'dosage_image']]
            result['package_size'] = str(float(dispensed_quantity))
            result['package_qty'] = str(result['package_size']) + " " + result['quantity_type']
            result['quantity'] = "1"
            result['custom_quantity'] = True
    return result
# end function


def create_erxcard(sclaim_dict, claim_id, card_holder_id, person_code):
    """
    Process to create an intent for a prescription
    :param sclaim_dict:
    :param claim_id:
    :param card_holder_id:
    :param person_code:
    :return:
    """
    import json
    import requests
    import couchbase.subdocument as SD
    from datetime import datetime
    from utils.sendgridemail import email_log
    from autoerx import mutations
    from autoerx.get_user_info import FliptUser
    from types import SimpleNamespace as Namespace
    from autoerx.find_best_pharmacy import find_best_pharmacy_option
    from autoerx.sms_notifications import send_sms
    from utils.graphql_authenticate import graphql_connect

    claim = dict()

    sclaim_dict['logger_handle'].debug("Auto eRx card creation started")
    # collect details from scdailyclaim using claim id received as an argument
    query = N1QLQuery('Select * from `' + os.environ['CB_INSTANCE'] + '` where type="scdailyclaim" and meta().id=$cid',
                      cid=claim_id)
    query.adhoc = False
    sclaim_dict['logger_handle'].debug(f"Querying claim table for claim details for the claim: {claim_id}")
    for res in sclaim_dict['cb_handle'].n1ql_query(query):
        claim.update(res[os.environ['CB_INSTANCE']])
    sclaim_dict['logger_handle'].debug("Capturing the claim date : {}".format(claim['claim_date']))

    sclaim_dict['logger_handle'].debug("Identifying the member/patient creating the intent " +
                 f"using card_holder_id: {card_holder_id}, person_code: {person_code}")
    flipt_person_id = rx_flipt_person_id = card_holder_id[:7]

    person_code = card_holder_id[-2:]
    if len(card_holder_id) == 9:
        if card_holder_id[-2:] == '01':
            sclaim_dict['logger_handle'].debug("Primary account holder is trying to create intent")
        else:
            sclaim_dict['logger_handle'].debug("Dependent is trying to create the intent, get dependent flipt person id")
            communication_obj = FliptUser(card_holder_id, person_code, claim['account'], data_struct=sclaim_dict)
            att, user_id = communication_obj.get_user_from_tv(card_holder_id[:7])
            sclaim_dict['logger_handle'].debug(f"{att}|{user_id}") 
            dependent_flipt_person_id = [x for x in att['dependents'] if x['person_code'] == person_code]
            if dependent_flipt_person_id:
                rx_flipt_person_id = dependent_flipt_person_id[0]['flipt_person_id']
                print(dependent_flipt_person_id)

    sclaim_dict['logger_handle'].debug("Checking if any claim is filled before one day using {}, {}, {}".
                                       format(claim['claim_date'], rx_flipt_person_id, claim['gpi_code']))

    query = N1QLQuery('Select filled_date from `' + os.environ[
        'CB_INSTANCE'] + '` where type="prescription" and rx_status="Filled" and DATE_DIFF_STR(DATE_FORMAT_'
                         'STR($cdate,"1111-11-11"),DATE_FORMAT_STR(filled_date,"1111-11-11"),"day")<1 and '
                         'rx_flipt_person_id=$cfid and gpi=$gpi',
                      cdate=claim['claim_date'], cfid=rx_flipt_person_id, gpi=claim['gpi_code'])
    query.timeout = 60
    for fdate in sclaim_dict['cb_handle'].n1ql_query(query):
        sclaim_dict['logger_handle'].warning('Auto eRx not created because eRx got filled ' +
                                             'in the last 24 hours.  Customer service to ' +
                                             'investigate with pharmacy/member.')

        error_msg = "Auto eRx not created because eRx got filled in last 24 hours. " \
                    "Customer service to investigate with pharmacy/ member"
        return 'Error', None, None, None, None, [error_msg]
    
    days_of_supply_num = claim['days_supply'].replace('-', '')
    domain = claim['account']
    bin = claim['bin']
    pcn = claim['pcn']
    group_id = claim['group']
    member_id = claim['member_id'].strip()
    dispensed_quantity = claim['quantity_dispensed'].replace('-', '')
    sclaim_dict['logger_handle'].debug(f"Received days_of_supply: {days_of_supply_num}, domain: {domain}, " +
                                       f"bin: {bin}, pcn: {pcn}, group_id: {group_id}, member_id: {member_id} " +
                                       f"dispensed_quantity: {dispensed_quantity}, " +
                                       f"flipt_person_id: {flipt_person_id}, person_code: {person_code}")
    daysofsupply = ''
    if int(days_of_supply_num) <= 30:
        daysofsupply = 'UP TO 30'
    elif int(days_of_supply_num) > 30 and int(days_of_supply_num) <= 60:
        daysofsupply = 'UP TO 60'
    elif int(days_of_supply_num) > 60 and int(days_of_supply_num) <= 90:
        daysofsupply = 'UP TO 90'
    else:
        daysofsupply = 'OVER 90'

    # go to true vautl and try to get the data
    sclaim_dict['logger_handle'].debug(f"Going to True_vault for user information " +
                                       f"using claim_flipt_person_id: {flipt_person_id}")
    communication_obj = FliptUser(flipt_person_id, person_code, domain, data_struct=sclaim_dict)
    user_communication_info = communication_obj.get_user_details()
    if user_communication_info[0] is None:
        sclaim_dict['logger_handle'].error("Error retrieving account details: Member not found")
        return 'Error', '', '', flipt_person_id, rx_flipt_person_id, "Error: Member not found"

    sclaim_dict['logger_handle'].debug("Received info from the true vault: {}".format(user_communication_info))
    phone_number = user_communication_info[0]

    userid = user_communication_info[1]
    # rx_flipt_person_id = member_id
    payment_option = user_communication_info[2]

    query = N1QLQuery('Select claim_processor from `' +
                      os.environ['CB_INSTANCE'] +
                      '` where type="claim_processor" ' +
                      'and rxpcn=$rxpcn and rxbin=$rxbin',
                      rxpcn=pcn, rxbin=bin)
    claimproc = []
    sclaim_dict['logger_handle'].debug("Selecting the claim processor to process the claim")
    for res in sclaim_dict['cb_handle'].n1ql_query(query):
        claimproc.append(res['claim_processor'].lower().strip())
    sclaim_dict['logger_handle'].debug(f"The claimprocessor for this claim is : {claimproc}")

    # getting pharmacy details based on pharmacy NPI
    npi = claim['pharmacy_npi']
    sclaim_dict['logger_handle'].debug(f"Getting the pharmacy details using the pharmacy NPI: {npi}")
    query = N1QLQuery(
        'Select pharmacyzip1,geo_lat,geo_lng,pharmacyname,cp_pharmacy_info,pharmacytype,wl_name,' +
        'pharmacyaddress1||", "||pharmacycity||", "||pharmacystate||", "||pharmacyzip1 pharmaddr,pharmacynpi from `' +
        os.environ['CB_INSTANCE'] + '` where type="cp_pharmacy" and tonumber(pharmacynpi)=$pnpi', pnpi=int(npi))
    query.adhoc = False
    query.timeout = 3200

    zipcode, searchlocation, locationselected, \
    preselected_pharmacy, cpstatus, pharmacytype, location = '', '', '', '', '', '', ''
    for res in sclaim_dict['cb_handle'].n1ql_query(query):
        preselected_pharmacy = res['wl_name']
        pharmacytype = res['pharmacytype']
        npi = res['pharmacynpi']
        print(preselected_pharmacy, 'pharma 1')
        for row in res['cp_pharmacy_info']:
            if row['claim_processor'].lower().strip() in claimproc:
                cpstatus = row['cp_status']
            if cpstatus == 'inactive':
                error_msg = "Pharmacy is not in Active status"
                sclaim_dict['logger_handle'].error(error_msg)
                email_log('noreply@fliptrx.com', 
                          'FliptIntegration@fliptrx.com', 
                          "SSubramani@fliptrx.com",
                          "Auto eRx Card Creation Error",
                          ['eRx Card Creation Attempt', 'AutoeRx Exception'],
                          sclaim_dict['logger_handle'].handlers[0].baseFilename, True)
                return 'Error', None, None, None, None, error_msg
        zipcode = res['pharmacyzip1']
        searchlocation = res['geo_lat'] + ', ' + res['geo_lng']
        locationselected = 'Current Location'
        location = res['pharmaddr']
        if not res:
            error_msg = ("Pharmacy not foung in data base: {}".format(npi))
            sclaim_dict['logger_handle'].error(error_msg)
            email_log('noreply@fliptrx.com', 
                      'FliptIntegration@fliptrx.com', 
                      "SSubramani@fliptrx.com",
                      "Auto eRx Card Creation Error",
                      ['eRx Card Creation Attempt', 'AutoeRx Exception'], 
                      sclaim_dict['logger_handle'].handlers[0].baseFilename, True)
            return 'Error', None, None, None, None, error_msg

    sclaim_dict['logger_handle'].debug("Checking if pharmacy is active: {}".format(cpstatus))
    if cpstatus == '':
        error_msg = "Pharmacy is not in Active status"
        sclaim_dict['logger_handle'].error(error_msg)
        email_log('noreply@fliptrx.com', 
                  'FliptIntegration@fliptrx.com', 
                  "SSubramani@fliptrx.com",
                  "Auto eRx Card Creation Error",
                  ['eRx Card Creation Attempt', 'AutoeRx Exception'], 
                  sclaim_dict['logger_handle'].handlers[0].baseFilename, True)
        return 'Error', None, None, None, None, error_msg

    ndc = claim['product_id_ndc']
    gpi = claim['gpi_code']
    drug_full_name = claim['product_name_full']
    # call function used to return drug and quantity details
    result = getquantity(sclaim_dict, gpi, drug_full_name, dispensed_quantity, ndc)
    result['pharmacy'] = preselected_pharmacy

    # define and call savePrescription mutation; prescription id returned
    sclaim_dict['logger_handle'].debug("Generating mutations and variables for saving the prescription")
    mutation1 = mutations.mutation_for_save_prescription

    try:
        variables = {"gpi": gpi, "dpa": result["dpa"], "drug": result["drug_name"], "form": result["dosage"],
                 "dosage": result["dosage"], "quantity": str(result["quantity"]), "daysofsupply": days_of_supply_num,
                 "locationSelected": locationselected, "zipCode": zipcode, "ddn_form": result["ddn_form"],
                 "ddn_name": result["ddn_name"], "ddn_strength": result["ddn_strength"], "strengths": "nan",
                 "dosage_strength": result["dosage_strength"], "lm_strength": result["lm_strength"],
                 "lm_form": result["lm_form"], "lm_name": result["lm_name"], "drug_name": result["drug_name"],
                 "brand_generic": result["brand_generic"], "ddid": result["ddid"], "drug_type": result["drug_type"],
                 "package_desc": result["package_desc"], "pkg_desc_cd": result["pkg_desc_cd"],
                 "package_qty": str(result["package_qty"]), "package_quantity": str(result["package_quantity"]),
                 "package_size": str(result["package_size"]), "pkg_uom": result["pkg_uom"], "lm_ndc": result["lm_ndc"],
                 "search_location": searchlocation, "flipt_person_id": flipt_person_id, "gppc": result["gppc"],
                 "custom_quantity": result["custom_quantity"], "quantity_type": result["quantity_type"],
                 "custom_qty": result["custom_qty"], "admin_flipt_person_id": "1001598", "days_of_supply": daysofsupply,
                 "location": location, "drug_covered": sclaim_dict['drug_covered'],
                 "drug_notcovered_can_be_dispensed": sclaim_dict['drug_notcovered_canbe_dispensed']}

    except KeyError:
        return 'Error', None, None, None, None, []

    try:
        user_hdr = graphql_connect(userid, log_hndl=sclaim_dict['logger_handle'])
        if user_hdr is None:
            return 'Error', None, None, None, None, []

        sclaim_dict['user_hdr'] = user_hdr
        start_time = datetime.now()
        print("*********************************************************************************")
        print("Printing the mutation for GraphQL saving prescription")
        print(f"{mutation1}")
        print("*********************************************************************************")
        print("Printing variables for GraphQL saving prescription")
        print(f"{variables}")
        print("*********************************************************************************")
        newpresc = requests.post(sclaim_dict['url'],
                                 json={'query': mutation1, 'variables': variables},
                                 headers=user_hdr)

        decoded = json.loads(newpresc.text, object_hook=lambda d: Namespace(**d))
        end_time = datetime.now() - start_time
        sclaim_dict['logger_handle'].debug(f"Execution time for GraphQL prescription save: {end_time}s")
        sclaim_dict['logger_handle'].debug("Printing the decoded data from graph QL".format(decoded))
        prescid = decoded.data.savePrescription.prescription_id
        prescid = str(prescid)
        # global prescid
        sclaim_dict['logger_handle'].debug("received prescription id from the graph ql: {}".format(prescid))

        # make explicit updates to prescription created
        sclaim_dict['logger_handle'].debug("make explicit updates to prescription created")
        sclaim_dict['cb_handle'].mutate_in(prescid, SD.upsert('domain', str(domain)))
        sclaim_dict['cb_handle'].mutate_in(prescid, SD.upsert('flipt_person_id', str(flipt_person_id)))
        sclaim_dict['cb_handle'].mutate_in(prescid, SD.upsert('rx_flipt_person_id', str(rx_flipt_person_id)))
        sclaim_dict['cb_handle'].mutate_in(prescid, SD.upsert('auth_id', str(claim['auth_id'])))
        sclaim_dict['cb_handle'].mutate_in(prescid, SD.upsert('equivalent_brand', result['equivalent_brand']))
        sclaim_dict['cb_handle'].mutate_in(prescid, SD.upsert('dosage_image', result['dosage_image']))
        sclaim_dict['cb_handle'].mutate_in(prescid, SD.upsert('application', "Auto eRx"))
        if result['strengths'] == 'nan':
            sclaim_dict['cb_handle'].mutate_in(prescid, SD.upsert('strengths', result['lm_strength']))

        if result['specialty_flag'] == 'Y':
            sclaim_dict['cb_handle'].mutate_in(prescid, SD.upsert('specialty_flag', str("Y")))
        else:
            sclaim_dict['cb_handle'].mutate_in(prescid, SD.upsert('specialty_flag', str("N")))
        if pharmacytype != "RETAIL":
            basketquery = """query {user {employee{ prescription_basket }}}"""

            basketid = requests.post(sclaim_dict['url'],
                                     json={'query': basketquery},
                                     headers=user_hdr)
            decoded = json.loads(basketid.text, object_hook=lambda d: Namespace(**d))
            basketprescs = []
            try:
                sclaim_dict['logger_handle'].debug("Trying to update basket prescriptions")
                basketprescs.extend(decoded.data.user.employee.prescription_basket)
                check_new_prescs = N1QLQuery('Select prescription_id from `' + os.environ[
                    'CB_INSTANCE'] + '` where type="prescription" and rx_status="New" and gpi=$gpi and '
                                     'rx_flipt_person_id=$rxid and prescription_id in $prescid',
                                           rxid=str(rx_flipt_person_id), prescid=basketprescs, gpi=variables['gpi'])
                check_new_prescs.timeout = 300
                prescpresent = False
                for r in sclaim_dict['cb_handle'].n1ql_query(check_new_prescs):
                    prescpresent = True
            except Exception as noprescription:
                prescpresent = False

            if not prescpresent:
                basketprescs.append(prescid)
                variables = {"prescriptions_id": ",".join(x for x in basketprescs)}
                updatebasket = """mutation ($prescriptions_id: String!)
                { updateBasket(prescriptions_id: $prescriptions_id) }"""
                basketid = requests.post(sclaim_dict['url'],
                                         json={'query': updatebasket, 'variables': variables},
                                         headers=headers)
                decoded = json.loads(basketid.text, object_hook=lambda d: Namespace(**d))
                sclaim_dict['logger_handle'].debug("Data received from the updateBasket graph ql endpoint".format(decoded))
                # basketprescs = decoded.data
                sclaim_dict['logger_handle'].debug("Script is in basket")
            message = pharmacytype + " Auto eRx is created for " + result[
                "drug_name"] + ". Review your basket to confirm pharmacy " + result[
                          'pharmacy'] + " and shipping address."
            sclaim_dict['logger_handle'].debug("Sending sms to the user")

            # sms_obj = SendNotifications(message, phone_number, flipt_person_id, rx_flipt_person_id)
            sms_notify = send_sms(message, phone_number)
            if sms_notify[0] == 'success':
                sclaim_dict['logger_handle'].info(f"Notification sent to user successfully on {phone_number}")
                print("Notification sent to user successfully on {}".format(phone_number))

            return 'Success', prescid, result, flipt_person_id, rx_flipt_person_id, [
                'Script for Mail Order/Specialty in New Status']
        sclaim_dict['cb_handle'].mutate_in(prescid, SD.upsert('preselected_pharmacy', str(preselected_pharmacy)))
        sclaim_dict['cb_handle'].mutate_in(prescid, SD.upsert('preselected_npi', str(npi)))
    except Exception as e:
        error_msg = ("Not able to save prescription using the grap ql end " +
                     "point save prescription and updateBasket: {}".format(str(e)))
        sclaim_dict['logger_handle'].error(error_msg)
        return 'Error', None, None, None, None, [error_msg]
    routeerrorlog = ''
    try:
        sclaim_dict['logger_handle'].debug("Trying to route the prescription")
        prescrouted = False
        routeerrorlog = []
        savings = 0
        bestoptionname = ""
        result_graphql = ''
        if pharmacytype.upper().strip() == 'RETAIL':
            (prescriptionid, routeerrorlog, savings, bestoptionname,
             savings_text_result, result_graphql, one_res) = route_prescription(sclaim_dict, prescid, user_hdr,
                                                                                domain, bin, pcn, group_id, variables,
                                                                                preselected_pharmacy, npi, ndc,
                                                                                rx_flipt_person_id, member_id, userid,
                                                                                payment_option, flipt_person_id)
            if prescriptionid != "":
                prescrouted = True
                sclaim_dict['logger_handle'].debug("Prescription routed")
            else:
                error_msg = "Could not route prescription check route prescriptionid is empty"
                sclaim_dict['logger_handle'].error(error_msg)
                return 'Error', prescid, result, flipt_person_id, rx_flipt_person_id, routeerrorlog
    except Exception as e:
        sclaim_dict['logger_handle'].error("Could not route the prescription check route prescription: {}".
                                           format(str(routeerrorlog)))
        return 'Error', prescid, result, flipt_person_id, rx_flipt_person_id, ['Could Not Route New Rx']

    # update additional columns in the prescription table
    sclaim_dict['cb_handle'].mutate_in(prescid, SD.upsert('original_baseline_cost', str(one_res.drug_baseline_price)))
    sclaim_dict['cb_handle'].mutate_in(prescid, SD.upsert('original_drug_copay', str(one_res.drug_copay)))
    sclaim_dict['cb_handle'].mutate_in(prescid, SD.upsert('original_drug_cost', str(one_res.drug_price)))
    sclaim_dict['cb_handle'].mutate_in(prescid, SD.upsert('original_employee_opc', str(one_res.employee_opc)))
    sclaim_dict['cb_handle'].mutate_in(prescid, SD.upsert('original_employer_cost', str(one_res.drug_employer_cost)))
    sclaim_dict['cb_handle'].mutate_in(prescid, SD.upsert('original_pbm_price', str(one_res.pbm_price)))
    sclaim_dict['cb_handle'].mutate_in(prescid, SD.upsert('original_rewards', str(one_res.drug_reward)))
    sclaim_dict['cb_handle'].mutate_in(prescid, SD.upsert('original_package_qty', str(result['package_qty'])))
    sclaim_dict['cb_handle'].mutate_in(prescid, SD.upsert('original_package_quantity', str(result['package_quantity'])))
    sclaim_dict['cb_handle'].mutate_in(prescid, SD.upsert('original_package_size', str(result['package_size'])))
    sclaim_dict['cb_handle'].mutate_in(prescid, SD.upsert('original_quantity', str(result['quantity'])))
    sclaim_dict['cb_handle'].mutate_in(prescid, SD.upsert('otc_indicator', str(sclaim_dict['otc_indicator'])))

    (savings, bestoptioncost, bestoptionnpi, bestoptionname,
     result, drugpricestatus, savings_text_result, error_msg) = find_best_pharmacy_option(sclaim_dict, variables,
                                                                                          rx_flipt_person_id, npi,
                                                                                          prescid, domain,
                                                                                          phone_number,
                                                                                          userid_val=userid)
    if error_msg:
        return "Error", None, None, None, None, [error_msg]
    if drugpricestatus == 'Error2':
        return "Error", None, None, None, None [error_msg]

    # if device token found, send push notification to all devices used by user
    status = sclaim_dict['cb_handle'].get(prescid)
    pstatus = status.value['rx_status']
    if pstatus == 'PA':
        routeerrorlog.append('PA status auto eRx')
        message = "Your Prescription for " + variables[
            'drug_name'] + " received at " + preselected_pharmacy + " requires Prior Authorization before it can be " \
                                                                    "filled. Please contact Flipt Concierge " \
                                                                    "(833-354-7879) to initiate approval."

        # sms_obj = SendNotifications(message, phone_number, flipt_person_id, rx_flipt_person_id)
        sms_notify = send_sms(message, phone_number)
        if sms_notify == 'success':
            print("Notification sent to user successfully on {}".format(phone_number))

    else:
        # savings text result from the new_savings autoerx from findbestpharmacy_options
        if not savings_text_result:
            print(prescid)

            reward_query = N1QLQuery('Select * from `' + os.environ[
                'CB_INSTANCE'] + '` where type="prescription" and prescription_id= $prescid',
                                     prescid=prescid)
            reward_query.timeout = 300
            employee_opc1, drug_reward = None, None
            for entry in sclaim_dict['cb_handle'].n1ql_query(reward_query):
                print(entry)
                drug_reward = entry[os.environ['CB_INSTANCE']]['rewards']
                employee_opc1 = entry[os.environ['CB_INSTANCE']]['employee_opc']
                print(f"Drug reward: {drug_reward}")
                print(f"Employee OPC: {employee_opc1}")

            message = 'Your prescription for ' + variables[
                'drug_name'] + ' has been created at ' + preselected_pharmacy + ". Your co-pay=$" + "%.2f" % float(
                employee_opc1) + ' and your reward=$' + "%.2f" % float(drug_reward) + ' for this prescription.'

            sms_notify = send_sms(message, phone_number)
            if sms_notify == 'success':
                print("Notification sent to user successfully on {}".format(phone_number))

    return 'Success', prescid, result, flipt_person_id, rx_flipt_person_id, routeerrorlog
# end function


def route_prescription(sclaim_struct, prescription_id, header, domain, bin, pcn, group_id, variables,
                       preselected_pharmacy, npi, ndc, rx_flipt_person_id, member_id,
                       userid, payment_option, flipt_person_id):
    """
    Route the prescription via GraphQL after getting the getDrugPrices
    :param sclaim_struct:
    :param prescription_id:
    :param header:
    :param domain:
    :param bin:
    :param pcn:
    :param group_id:
    :param variables:
    :param preselected_pharmacy:
    :param npi:
    :param ndc:
    :param rx_flipt_person_id:
    :param member_id:
    :param userid:
    :param payment_option:
    :param flipt_person_id:
    :return:
    """
    import json
    import requests
    from types import SimpleNamespace as Namespace
    import couchbase.subdocument as SD
    from datetime import datetime
    from autoerx import mutations
    from autoerx.getdrugprices_autoerx import get_drugprices

    sclaim_struct['logger_handle'].debug("Inside the route prescription function")
    query = N1QLQuery("Select auto_route_prescription,alternate_effective_date from`" +
                      os.environ['CB_INSTANCE'] + "` where type='domain' and domain=$dn",
                      dn=domain)
    sclaim_struct['logger_handle'].debug("Querying auto_route_prescription, alternate_effective_date from domain table")
    query.timeout = 60

    for row in sclaim_struct['cb_handle'].n1ql_query(query):
        if row['auto_route_prescription'] == 'N':
            sclaim_struct['logger_handle'].debug("Auto route prescription is No for this domain {}".format(domain))
            return "", ["Auto-route flag turned off"], 0, ""

    sclaim_struct['logger_handle'].debug("Querying for min pharmacy savings and switch pharmacy radius")

    domain_query = N1QLQuery("select min_split_pharmacy_savings, switch_pharmacy_radius FROM `"
                             + os.environ['CB_INSTANCE'] + "` where type = 'domain' and domain = $dn", dn=domain)

    single_return = (N1QLRequest(domain_query, sclaim_struct['cb_handle'])).get_single_result()

    drug_radius = single_return['switch_pharmacy_radius']
    sclaim_struct['logger_handle'].debug("Drug radius for the domain {}, {}".format(domain, drug_radius))

    start_time = datetime.now()
    result_graphql = get_drugprices(sclaim_struct, "", ndc.strip(), variables['location'], variables['dpa'], variables['gpi'],
                                    variables['form'], variables['package_size'], variables['package_quantity'],
                                    variables['zipCode'], variables['brand_generic'], variables['daysofsupply'],
                                    variables['dosage_strength'], rx_flipt_person_id, variables['drug_name'],
                                    variables['package_qty'], variables['dosage'], variables['gppc'], npi,
                                    userid, variables['custom_quantity'], drug_radius,
                                    allpharmacies=True)
    end_time = datetime.now() - start_time
    sclaim_struct['logger_handle'].debug(f"GraphQL execution time for getting drug prices: {end_time}s")
    if not result_graphql:
        error_msg = "No data received from graph ql"
        sclaim_struct['logger_handle'].error(error_msg)
        raise Exception(error_msg)

    result = [x for x in result_graphql if x.pharmacy_npi.lstrip('0') == npi]
    if not result:
        error_msg = "Could not find current pharmacy npi {} in received data from Graphql".format(npi)
        sclaim_struct['logger_handle'].error(error_msg)
        raise Exception(error_msg)
    result = result[0]

    mutation = mutations.mutation_for_route_prescriptions
    try:
        prescription_params = ["deductible_remaining", "drug_copay", "drug_penalty", "out_of_pocket_remaining",
                           "pbm_estimated_cost", "pbm_price", "reward_percentage", "chaincode", 
                           "drug_cost_before_rebate", "pharmacy_discount", "pharmacy_dispensing_fee", "rebate_amount", 
                           "rebate_factor", "unit_price", "unit_price_before_rebate", "zone", "reward_share", 
                           "retail_reward", "total_payment", "penalty_factor", "pa_flag", "pa_form", "pa_reason"]
    except Exception as e:
        error_msg = "Error preparing rout_values. ERROR: {}".format(str(e))
        sclaim_struct['logger_handle'].error(error_msg)
        raise Exception(error_msg)
    try:
        sclaim_struct['logger_handle'].debug("Preparing route_values for routing the prescription")
        route_values = {x: str(getattr(result, x)) for x in prescription_params}
        route_values.update({"prescription_id": str(prescription_id),
                             "baseline_cost": str(result.drug_baseline_price),
                             "bin": str(bin),
                             "drug_cost": str(result.drug_price),
                             "employee_opc": str(result.employee_opc),
                             "employer_cost": str(result.drug_employer_cost),
                             "group_id": str(group_id),
                             "member_id": str(member_id),
                             'drug_covered': sclaim_struct['drug_covered'],
                             'drug_notcovered_can_be_dispensed': sclaim_struct['drug_notcovered_canbe_dispensed'],
                             "npi": str(npi),
                             "payment_option": payment_option,
                             "pcn": str(pcn),
                             "pharmacy": str(preselected_pharmacy),
                             "rewards": str(result.drug_reward)})
    except Exception as e:
        error_msg = "Error preparing rout_values. ERROR: {}".format(str(e))
        sclaim_struct['logger_handle'].error(error_msg)
        raise Exception(error_msg)

    sclaim_struct['logger_handle'].debug("Finished preparing the variable for mutation {}".format(route_values))
    try:
        rpresc = requests.post(sclaim_struct['url'],
                               json={'query': mutation, 'variables': route_values},
                               headers=sclaim_struct['user_hdr'])
        # print(newpresc.json())
        decoded = json.loads(rpresc.text, object_hook=lambda d: Namespace(**d))
        sclaim_struct['logger_handle'].debug("Received decoded data from graph QL {}".format(decoded))
        prescid = decoded.data.v2RoutePrescription.prescription_id
        sclaim_struct['logger_handle'].debug("Received prescription id from deoded data {}".format(prescid))
        sclaim_struct['logger_handle'].debug("Upserting the with the flip person id and rx flipt person id {}, {}".
                                           format(flipt_person_id, rx_flipt_person_id))
        sclaim_struct['cb_handle'].mutate_in(prescid, SD.upsert('flipt_person_id', str(flipt_person_id)))
        sclaim_struct['cb_handle'].mutate_in(prescid, SD.upsert('rx_flipt_person_id', str(rx_flipt_person_id)))
        return prescid, [], '', result.pharmacy_name, False, result_graphql, result
    except Exception as e:
        error_msg = ("Could not route the prescription through graph ql {}".format(str(e)))
        sclaim_struct['logger_handle'].error(error_msg)
        return prescription_id, [error_msg], None, None, False, result_graphql, result
# end function
