

def get_drugprices(sclaim_dict, term, ndc, address, pda, gpi, form, package_size, package_quantity,
                   zip_code, brand_generic, days_of_supply, dosage_strength, flipt_person_id, drug_name, package_qty,
                   dosage, gppc, pharmacy_npi, userid, custom_quantity, miles,
                   allpharmacies=False):

    import json
    import os
    from types import SimpleNamespace as Namespace
    from utils.graphql_authenticate import graphql_connect
    from autoerx.mutations import mutation_for_getDrugPrices
    import requests

    # url = os.environ['GRAPHQL_URL']
    url = sclaim_dict['url']

    try:
        if sclaim_dict['user_hdr'] is None:
            sclaim_dict['user_hdr'] = graphql_connect(userid)

        claim = {}
        pharmacy_name = ""
        pharmacy_city = ""
        pharmacy_address = ""
        pharmacy_zip_code = ""
        drug_price = ""
        drug_baseline_price = ""
        deductible_remaining = ""
        drug_copay = ""
        drug_employer_cost = ""
        drug_out_of_pocket = ""
        drug_reward = ""
        drug_distance = ""
        drug_duration = ""
        provider_id = ""
        pbm_price = ""
        provider_name = ""
        out_of_pocket_remaining = ""
        reward_share = ""
        retail_reward = ""
        total_payment = ""
        penalty_factor = ""
        pa_flag = ""
        pa_form = ""
        pa_reason = ""
        alternative_drug_rewards = ""

        mutation = mutation_for_getDrugPrices

        variables = {"address": address, "brand_generic": brand_generic,
                     "days_of_supply": days_of_supply, "dosage": dosage,
                     "dosage_strength": dosage_strength, "drug_name": drug_name,
                     "flipt_person_id": flipt_person_id,
                     "form": form, "gpi": gpi, "gppc": gppc, "ndc": ndc, "package_qty": package_qty,
                     "package_quantity": package_quantity, "package_size": package_size,
                     "pda": pda, "zip_code": zip_code,
                     "custom_quantity": custom_quantity, "npi": pharmacy_npi, "miles": miles}

        print("*********************************************************************************")
        print("Printing the mutation for GraphQL saving prescription")
        print(f"{mutation}")
        print("*********************************************************************************")
        print("Printing variables for GraphQL saving prescription")
        print(f"{variables}")
        print("*********************************************************************************")
        drugprice = requests.post(url, json={'query': mutation, 'variables': variables},
                                  headers=sclaim_dict['user_hdr'])
        decoded = json.loads(
            drugprice.text, object_hook=lambda d: Namespace(**d))

    except Exception as e:
        return "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""

    print(decoded.data.getDrugPrices)
    # returns all pharmacies and corresponding drug costs
    if allpharmacies:
        return decoded.data.getDrugPrices

    try:
        for x in decoded.data.getDrugPrices:
            print('Matched')
    except Exception as e:
        return "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""

    for x in decoded.data.getDrugPrices:
        # print(x.pharmacy_npi)

        if int(x.pharmacy_npi) == int(pharmacy_npi):
            # print('Matched')
            pharmacy_name = x.pharmacy_name
            pharmacy_city = x.pharmacy_city
            pharmacy_address = x.pharmacy_address
            pharmacy_zip_code = x.pharmacy_zip_code
            drug_price = x.drug_price
            drug_baseline_price = x.drug_baseline_price
            deductible_remaining = x.deductible_remaining
            drug_copay = x.drug_copay
            drug_employer_cost = x.drug_employer_cost
            # drug_out_of_pocket  = x.drug_out_of_pocket
            drug_out_of_pocket = x.employee_opc
            drug_reward = x.drug_reward
            drug_distance = x.drug_distance
            drug_duration = x.drug_duration
            provider_id = x.provider_id
            pbm_price = x.pbm_price
            provider_name = x.provider_name
            pharmacy_npi = x.pharmacy_npi
            out_of_pocket_remaining = x.out_of_pocket_remaining
            reward_share = x.reward_share
            retail_reward = x.retail_reward
            total_payment = x.total_payment
            penalty_factor = x.penalty_factor
            pa_flag = x.pa_flag
            pa_form = x.pa_form
            pa_reason = x.pa_reason
    print('after calling graphql')
    print('getdrugprices output')

    return pharmacy_name, pharmacy_city, pharmacy_address, pharmacy_zip_code, drug_price, drug_baseline_price, \
           deductible_remaining, drug_copay, drug_employer_cost, drug_out_of_pocket, drug_reward, drug_distance, \
           drug_duration, provider_id, pbm_price, provider_name, pharmacy_npi, out_of_pocket_remaining, \
           reward_share, retail_reward, total_payment, penalty_factor, pa_flag, pa_form, pa_reason
# end function
