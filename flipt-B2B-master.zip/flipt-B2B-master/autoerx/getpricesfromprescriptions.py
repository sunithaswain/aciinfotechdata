
def get_presc_prices(sclaim_dict, prescription_list, userid=None):
    """

    :param sclaim_dict:
    :param userid:
    :param prescription_list:
    :return:
    """
    import json
    import requests
    import pandas as pd
    from types import SimpleNamespace as Namespace
    from utils.graphql_authenticate import graphql_connect

    # Graphql SignIn Mutation
    # mutation = """mutation {signIn(email: "disha.wagle@nttdata.com", password: "123456789") {access_token}}"""
    url = sclaim_dict['url']
    if sclaim_dict['user_hdr'] is None:
        sclaim_dict['user_hdr'] = graphql_connect(userid)

    presc_list = json.dumps(prescription_list)

    print(presc_list)
    query = """
    query {
      getAutoeRxPrices(prescriptionIds: """ + str(presc_list) + """ ) {
        prescriptionsList 
        {
          admin_flipt_person_id
          alternative_drug_rewards
          application
          baseline_cost
          bin
          brand_generic
          chaincode
          copay_amount
          custom_qty
          custom_quantity
          days_of_supply
          daysofsupply
          ddid
          ddn_form
          ddn_name
          ddn_strength
          deductible_balance
          deductible_remaining
          discount_card_source
          dosage
          dosage_image
          dosage_strength
          dpa
          drug
          drug_copay
          drug_cost
          drug_cost_before_rebate
          drug_deductible_exempt
          drug_name
          drug_penalty
          drug_type
          employee_opc
          employer_cost
          equivalent_brand
          filled_date
          first_name
          flipt_person_id
          form
          gpi
          gppc
          group_id
          hra_transaction_id
          last_name
          lm_form
          lm_name
          lm_ndc
          lm_strength
          location
          locationSelected
          member_id
          mo_contact_email
          mo_contact_phone
          mo_shipto_location
          npi
          otc_indicator
          other
          out_of_pocket_remaining
          pa_flag
          pa_form
          pa_override
          pa_reason
          package_desc
          package_qty
          package_quantity
          package_size
          payment_option
          pbm_price
          pcn
          penalty
          penalty_factor
          pharmacy
          pharmacy_discount
          pharmacy_dispensing_fee
          pkg_desc_cd
          pkg_uom
          prescription_basket_id
          prescription_id
          preselected_npi
          preselected_pharmacy
          quantity
          quantity_image
          quantity_restriction_flag
          quantity_type
          rebate_amount
          rebate_factor
          reconciled
          refill_create_date
          refill_prescription_id
          refills
          retail_reward
          reward_percentage
          reward_share
          rewards
          routed_date
          rx_flipt_person_id
          rxcui
          saved_date
          search_location
          search_prescription_id
          searched_date
          shared_with_flipt_person_id
          specialty_flag
          strengths
          total_payment
          total_reward
          unit_price
          unit_price_before_rebate
          zipCode
          zone
          searchedDrugValue
          track_shipment_url
        }
            pharmaciesList {
              chaincode
              deductible_remaining
              drug_baseline_price
              drug_copay
              drug_cost_before_rebate
              drug_deductible_exempt
              drug_distance
              drug_distance_value
              drug_duration
              drug_duration_value
              drug_employer_cost
              drug_out_of_pocket
              drug_penalty
              drug_price
              drug_reward
              employee_opc
              out_of_pocket_remaining
              pa_flag
              pa_form
              pa_override
              pa_reason
              pbm_estimated_cost
              pbm_price
              penalty_factor
              pharmacy_address
              pharmacy_city
              pharmacy_close_hour
              pharmacy_discount
              pharmacy_dispensing_fee
              pharmacy_location
              pharmacy_name
              pharmacy_npi
              pharmacy_open_hour
              pharmacy_zip_code
              provider_id
              provider_name
              rebate_amount
              rebate_factor
              retail_reward
              reward_percentage
              reward_share
              total_payment
              unit_price
              unit_price_before_rebate
              zone
            }
          }
        }
        """
    # import pdb;pdb.set_trace()
    response = requests.post(
        url, json={'query': query}, headers=sclaim_dict['user_hdr'])
    decoded1 = json.loads(response.text, object_hook=lambda d: Namespace(**d))

    sclaim_dict['logger_handle'].debug(f"{decoded1}")
    return_df = pd.DataFrame()
    update_dict = dict()

    for x in decoded1.data.getAutoeRxPrices.pharmaciesList:
        update_dict.update({'pharmacy_name': x.pharmacy_name,
                            'pharmacy_city': x.pharmacy_city,
                            'pharmacy_address': x.pharmacy_address,
                            'pharmacy_zip_code': x.pharmacy_zip_code,
                            'drug_price': x.drug_price,
                            'drug_baseline_price': x.drug_baseline_price,
                            'deductible_remaining': x.deductible_remaining,
                            'drug_copay': x.drug_copay,
                            'drug_employer_cost': x.drug_employer_cost,
                            'drug_out_of_pocket': x.drug_out_of_pocket,
                            'employee_opc': float(x.employee_opc),
                            'drug_reward': x.drug_reward,
                            'drug_distance': x.drug_distance,
                            'drug_duration': x.drug_duration,
                            'provider_id': x.provider_id,
                            'pbm_price': x.pbm_price,
                            'provider_name': x.provider_name,
                            'pharmacy_npi': x.pharmacy_npi.lstrip('0'),
                            'out_of_pocket_remaining': x.out_of_pocket_remaining,
                            'pharmacy_location': x.reward_share,
                            'drug_penalty': x.retail_reward,
                            'reward_percentage': x.total_payment,
                            'drug_duration_value': x.penalty_factor,
                            'pbm_estimated_cost': x.pa_flag,
                            'drug_deductible_exempt': x.pa_form,
                            'unit_price_before_rebate': x.pa_reason,
                            'unit_price': x.unit_price})

        return_df = return_df.append(update_dict, ignore_index=True)
    sclaim_dict['logger_handle'].debug(
        'after calling graphql: getdrugprices output')
    sclaim_dict['logger_handle'].debug(f"{return_df}")
    return return_df
# end function


# if __name__ == '__main__':
#     get_presc_prices(["prescription::11788", "prescription::10110"])
