
import os
import couchbase.subdocument as SD
from utils.helper_functions import *
from datetime import datetime
from couchbase import FMT_JSON
from notification.twilioSendSMS import sendSMS


def send_sms(message, phone_number):
    """

    :param message: Message which needs to be sent to the user
    :param phone_number: Number to which the sms has to be sent
    :return: success if not Failed
    """
    s, i = sendSMS(phone_number, message)
    return 'success' if 'success' in s else 'Failed'
# end function


def is_applicable_for_process(datetime_str):
    """

    :param datetime_str: Time to check if qualified to send sms
    :return: True if diff greater than 10 mins
    """
    now = datetime.now()
    last_update_time = datetime.strptime(datetime_str, "%Y-%m-%dT%H:%M:%S.%f")
    diff = now - last_update_time
    return True if diff.total_seconds()/60 >= 5 else False
# end function


def process_active_notification(log_handle):
    """

    :return: updates prescription to inactive after sending sms
    """
    log_handle.info("Checking for new savings notifications")
    query = f"select *, meta().id from `{os.environ['CB_INSTANCE']}` " +\
            "where type = 'notification_log' and status='Active' " +\
            "and message_sent is missing" 
    cb = cb_authenticate()
    res = cb.n1ql_query(query)

    try:
        for i in res:
            log_handle.info(f"Checking if SMS needs to be sent to: {i[os.environ['CB_INSTANCE']]['phone_number']}")
            # check if any messages are older than a day - deactivate them and go to the next record
            message_time = i[os.environ['CB_INSTANCE']]['time_message_sent']
            last_message_sent = datetime.strptime(message_time, "%Y-%m-%dT%H:%M:%S.%f")
            time_diff = (datetime.now() - last_message_sent).days
            if time_diff >= 1 and i[os.environ['CB_INSTANCE']]['status'] == 'Active':
               cb.mutate_in(str(i['id']), SD.upsert('status', 'Inactive'))
               continue
            # end - check for message age

            if is_applicable_for_process(i[os.environ['CB_INSTANCE']]['update_date']):
                if send_sms(i[os.environ['CB_INSTANCE']]['message'], i[os.environ['CB_INSTANCE']]['phone_number']):
                    # according to Reynaldo, the API changes the status to 'Inactive'
                    if i[os.environ['CB_INSTANCE']]['awaiting_response'] == 'N':
                        i[os.environ['CB_INSTANCE']]['status'] = 'Inactive'

                    i[os.environ['CB_INSTANCE']]['result'] = 'Success'
                    i[os.environ['CB_INSTANCE']]['time_message_sent'] = datetime.now().isoformat()
                    i[os.environ['CB_INSTANCE']]['update_date'] = datetime.now().isoformat()
                    i[os.environ['CB_INSTANCE']]['message_sent'] = True
                    cb.upsert(i['id'], i[os.environ['CB_INSTANCE']], format=FMT_JSON)
                    log_handle.info("Savings SMS sent to: " +
                                    i[os.environ['CB_INSTANCE']]['phone_number'])

                else:
                    log_handle.error(f"Error wile sending SMS to: {i[os.environ['CB_INSTANCE']]['phone_number']}")

        log_handle.info("Done sending notifications to members with savings.")
    except AttributeError:
        log_handle.debug("No records to process")
        pass
# end function


if __name__ == "__main__":
    logger = setup_logging_path('SCDAILYCLAIM', 'notifier_engine', 'SMS_NOTIFY')
    process_active_notification(logger)

