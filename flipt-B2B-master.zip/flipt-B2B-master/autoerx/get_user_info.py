import logging
from datetime import datetime

from dateutil.relativedelta import relativedelta

from utils.truevault import User_Class


# get phone numbers of the user
# if the account owner is creating the intent:
#) person code == 01
#) go to true vault and get the preferred and verified phone number#
#) if no verified and preferred phone number then#
#) get the communication_option_phone number
#) if the above two are not available then send  no phone number available

#) if dependent is creating the intent
#) person code will be 02
#) go to true vault and get the preferred and verified phone number#
#) if no verified and preferred phone number then#
#) get the communication_option_phone number
#) if both of them are not available, go to the primary account holder and follow above steps


#) if a minor is creating an intent
#) get primary account holder phone number

#) if no profile found in tv with the member id, throw exception

# "personal_phones": [
#         {
#             "phone_number": "8605101122",
#             "verified": true,
#             "date_added": "2019-05-17T05:50:06.160Z",
#             "date_verified": "2019-05-17T05:50:06.160Z",
#             "preferred": true
#         },
#         {
#             "phone_number": "9163042225",
#             "verified": true,
#             "date_added": "2019-07-12T05:29:25.170Z",
#             "date_verified": "2019-07-12T05:29:25.170Z",
#             "preferred": true
#         }
class FliptUser(object):

    def __init__(self, card_holder_id, person_code, domain, data_struct=None):
        from utils.helper_functions import cb_authenticate

        try:
            if data_struct['cb_handle'] is not None:
                self.cb_handle = data_struct['cb_handle']
            else:
                self.cb_handle = cb_authenticate()
        except:
            data_struct['cb_handle'] = cb_authenticate()

        self.data = data_struct
        self.card_holder_id = card_holder_id
        self.person_code = person_code
        self.domain = domain
    # end constructor


    def get_user_details(self):
        """
        Primary/dependent account holder is creating the intent
        :return: phone_num, user_id, '' or att['payment_option']
        """
        phone_num = None
        att, user_id = self.get_user_from_tv(self.card_holder_id)
        if att is not None:
            if not self.is_minor(att['date_of_birth']):
                phone_num = self.extract_phone_num(att)

            if not phone_num and att.get('parent_id'):
                 # this is a dependent user get phone number info from the parent
                parent_id = att['parent_id']
                att, user_id = self.get_user_from_tv(parent_id)
                phone_num = self.extract_phone_num(att)
        else:
            return phone_num, user_id, ''

        try:
           return phone_num, user_id, att['payment_option']
        except KeyError:
           return phome_num, user_id, ''
    # end method


    def get_user_from_tv(self, flipt_person_id):
        """
        retrieve user details from the TrueValue server
        :param flipt_person_id:
        :return:
        """
        try:
            obj = self.data['TV_OBJ']
        except:
            obj = User_Class(None, None, cb_handle=self.data['cb_handle'])

        search_option = {'full_document': True,
                         'filter': {'domain_name':
                                        {'type': 'eq',
                                         'value': self.domain,
                                         'case_sensitive': False
                                         },
                                    'flipt_person_id':
                                        {'type': 'eq',
                                         'value': flipt_person_id,
                                         'case_sensitive': False
                                         },
                                    '$tv.status':
                                        {'type': 'eq',
                                         'value': 'ACTIVATED'
                                         }
                                    },
                         'filter_type': 'and'
                         }
        return obj.search_user(search_option)
    # end method


    def extract_phone_num(self, att):
        """
        Get the phone number for the member
        :param att:
        :return:
        """
        phone_number = ''
        if att.get('personal_phones'):
            # filter the phone numbers which have verified==True and preferred==True
            phone_list = sorted((x for x in att['personal_phones'] if x['verified'] and x['preferred']),
                                key=lambda item: datetime.strptime(item['date_verified'], "%Y-%m-%dT%H:%M:%S.%fZ"))
            if phone_list:
                phone_number = phone_list[-1]['phone_number']

        if not phone_number and att.get('communication_option_phone'):
            phone_number = att['communication_option_phone']
        return phone_number
    # end method


    def is_minor(self, date_of_birth):
        """
        check if the member is a minor that is creating an intent
        :param date_of_birth:
        :return:
        """
        date_of_birth = datetime.strptime(date_of_birth, '%Y-%m-%d %H:%M:%S')
        age = relativedelta(datetime.now(), date_of_birth).years
        return True if age < 18 else False
    # end method
# end class
