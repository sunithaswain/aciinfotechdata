
import os
from datetime import datetime
import couchbase.subdocument as SD
from couchbase import FMT_JSON
from couchbase.n1ql import N1QLQuery, N1QLRequest
from autoerx.getpricesfromprescriptions import get_presc_prices


def find_best_pharmacy_option(sclaim_struct, variables, rx_flipt_person_id, npi, prescid, domain, phone_number,
                              userid_val=None):
    """
    Uses the getAutoeRXPrices to get prices for multiple prescription and best pharmacy
    :param sclaim_struct:
    :param variables:
    :param rx_flipt_person_id:
    :param npi:
    :param prescid:
    :param domain:
    :param phone_number:
    :param flipt_person_id:
    :param ndc_val:
    :param userid_val:
    :param preselected_pharma:
    :return:
    """
    cumm_savings = 0
    savings_send_result = False
    sclaim_struct['logger_handle'].debug("Inside find best pharmacy function")

    sclaim_struct['logger_handle'].debug("Querying DB for getting the min_split_pharmacy_savings, switch_pharmacy_radius")
    domain_query = N1QLQuery("select min_split_pharmacy_savings, switch_pharmacy_radius FROM `"
                             + os.environ['CB_INSTANCE'] + "` where type = 'domain' and domain = $dom",
                             dom=str(domain))
    single_return = (N1QLRequest(domain_query, sclaim_struct['cb_handle'])).get_single_result()

    min_savings = single_return['min_split_pharmacy_savings']
    drug_radius = single_return['switch_pharmacy_radius']
    
    sclaim_struct['logger_handle'].debug("minimum savings and radius for this {} is {} and {}".format(domain, min_savings, drug_radius))

    # # check notification log for existing prescriptions
    notif_query = N1QLQuery("select time_message_sent, status, meta().id, drugs_list, prescription_id, " +
                           "out_of_pocket,savings_amount from `" + os.environ['CB_INSTANCE'] +
                           "`where type='notification_log' and flipt_person_id = $flp and phone_number = $pn " +
                           "and status = 'Active' order by time_message_sent desc",
                           flp=str(variables['flipt_person_id']),
                           pn=str('+1' + str(phone_number)))

    rx_list = [prescid]
    entry = (N1QLRequest(notif_query, sclaim_struct['cb_handle'])).get_single_result()

    if entry is not None:
        last_message_sent = datetime.strptime(entry['time_message_sent'], "%Y-%m-%dT%H:%M:%S.%f")
        time_diff = (datetime.now() - last_message_sent).days
        # time_diff = 2
        if time_diff >= 1 and entry['status'] == 'Active':
            sclaim_struct['cb_handle'].mutate_in(str(entry['id']), SD.upsert('status', 'Inactive'))

        if isinstance(entry['prescription_id'], list):
            if len(entry['prescription_id']) > 0 and entry['status'] == 'Active':
                rx_list.extend(entry['prescription_id'])
        else:
            rx_list.append(entry['prescription_id'])

    print("printing rx list", str(rx_list))
    sclaim_struct['logger_handle'].debug(f"Printing prescription list: {rx_list}")
    pricelist = get_presc_prices(sclaim_struct, rx_list, userid=userid_val)  # call to new getRxPrices

    pricelist.drop(pricelist.loc[(pricelist.pharmacy_name == 'AMBER') |
                                 (pricelist.pharmacy_name == 'HUMANA SPECIALTY') |
                                 (pricelist.pharmacy_name == 'HUMANA MAIL ORDER')].index, inplace=True)
    if len(pricelist) == 0:
        error_msg = "Graph ql price list is empty"
        sclaim_struct['logger_handle'].error(error_msg)
        return '', '', '', '', None, None, 'Error1', error_msg
    elif npi.lstrip('0') not in pricelist['pharmacy_npi'].tolist():
        error_msg = "Selected pharmacy not found in the graph ql price list"
        sclaim_struct['logger_handle'].error(error_msg)
        return '', '', '', '', None, None, 'Error2', error_msg

    for c in ['drug_out_of_pocket', 'drug_reward', 'drug_distance']:
        if c == 'drug_distance':
            pricelist[c] = pricelist[c].apply(
                lambda x: float(x.replace(' mi', '')) if 'mi' in x else float(x.replace(' ft', '')) * 0.000189394)
        else:
            pricelist[c] = pricelist[c].apply(lambda x: float(x))

    current_pharmacy = pricelist.loc[pricelist['pharmacy_npi'] == npi]
    sclaim_struct['logger_handle'].debug("Current pharmacy where the prescription is routed: {}".format(current_pharmacy))
    all_other_pharamcy = pricelist.loc[pricelist['pharmacy_npi'] != npi]
    if len(all_other_pharamcy) == 0:
        error_msg = "Did not found any other pharmacies with better savings in the given radius: {}".format(drug_radius)
        sclaim_struct['logger_handle'].error(error_msg)
        return '', '', '', '', '', 'Failed', savings_send_result, error_msg

    lowest_price_series = all_other_pharamcy.loc[all_other_pharamcy.employee_opc.idxmin()]
    sclaim_struct['logger_handle'].debug("Lowest price in all other pharmacies: {}".format(lowest_price_series))
    lowest_price = lowest_price_series.employee_opc
    sclaim_struct['logger_handle'].debug("Lowest price found: {}".format(lowest_price))

    #------- ADDED: RajeshAcharya - -- 07 / 09 / 2019 - -------------
    # current_drug.drug_out_of_pocket is a pandas <series> datatype -
    # hence was causing the float conversion error.
    # The values attribute of the series is the list representation
    # then we take the min() value in the list
    try:
        curr_pharmacy_oop = current_pharmacy.employee_opc.values.min()
    except:
        curr_pharmacy_oop = 0.0

    new_savings = float(curr_pharmacy_oop).__round__() - float(lowest_price).__round__()
    sclaim_struct['logger_handle'].debug("New savings found through auto erx: {}".format(new_savings))
    sclaim_struct['cb_handle'].mutate_in(prescid, SD.upsert('employee_opc', lowest_price_series['employee_opc']))
    sclaim_struct['cb_handle'].mutate_in(prescid, SD.upsert('drug_reward', lowest_price_series['drug_reward']))
    sclaim_struct['logger_handle'].debug("Updated employee_opc and drug_reward")

    # initialize notification log entry
    notifrec = {}
    notifrec['type'] = "notification_log"
    notifrec['rx_flipt_person_id'] = rx_flipt_person_id
    notifrec['flipt_person_id'] = variables['flipt_person_id']
    notifrec['phone_number'] = '+1' + phone_number
    notifrec['prescription_id'] = prescid
    notifrec['drugs_list'] = [variables['drug_name']]
    notifrec['notification_type'] = 'autoerx'
    notifrec['status'] = 'Active'

    notifrec['response'] = ''
    notifrec['time_message_sent'] = datetime.now().isoformat()
    notifrec['time_reponse_sent'] = ''
    notifrec['awaiting_response'] = 'Y'
    notifrec['savings_amount'] = new_savings
    notifrec['out_of_pocket'] = lowest_price

    # import pdb;pdb.set_trace()
    notifquery = N1QLQuery("select time_message_sent, status, meta().id, drugs_list, " +
                           "prescription_id, create_date, out_of_pocket,savings_amount from `" +
                           os.environ['CB_INSTANCE'] +
                           "`where type='notification_log' and flipt_person_id = $flp and phone_number = $pn " +
                           "and status = 'Active' order by create_date desc",
                           flp=str(variables['flipt_person_id']), pn=str('+1' + str(phone_number)))
    now = datetime.now()
    active_prescription = None
    for row in sclaim_struct['cb_handle'].n1ql_query(notifquery):
        sclaim_struct['logger_handle'].debug("Changing status to Inactive for prescriptions which a day older")
        if savings_send_result:
            sclaim_struct['cb_handle'].mutate_in(str(row['id']), SD.upsert('status', 'Inactive'))

        last_message_sent = datetime.strptime(row['time_message_sent'], "%Y-%m-%dT%H:%M:%S.%f")
        time_diff = (now - last_message_sent).days
        # time_diff = 2
        if time_diff >= 1 and row['status'] == 'Active':
            sclaim_struct['cb_handle'].mutate_in(str(row['id']), SD.upsert('status', 'Inactive'))

        if time_diff == 0:
            # if it is today's active notification
            active_prescription = row
            break

    if active_prescription:
        cumm_savings = active_prescription['savings_amount']

    if new_savings >= int(min_savings) or cumm_savings >= int(min_savings):
        message = ''

        # set all pharmacy to lowest price pharmacy and npi
        for presc_id in rx_list:
            sclaim_struct['cb_handle'].mutate_in(presc_id, SD.upsert('pharmacy', lowest_price_series['pharmacy_name']))
            sclaim_struct['cb_handle'].mutate_in(presc_id, SD.upsert('npi', lowest_price_series['pharmacy_npi']))

        if active_prescription:
            notifrec['create_date'] = active_prescription['create_date']
            notifrec['out_of_pocket'] += active_prescription['out_of_pocket']
            notifrec['savings_amount'] += active_prescription['savings_amount']
            if isinstance(active_prescription['prescription_id'], list):
                if prescid not in active_prescription['prescription_id']:
                    active_prescription['prescription_id'].append(prescid)
                notifrec['prescription_id'] = active_prescription['prescription_id']
            else:
                notifrec['prescription_id'] = [prescid, active_prescription['prescription_id']]

            # keep track of drugs for the current claim id
            if isinstance(active_prescription['drugs_list'], list):
                if variables['drug_name'] not in active_prescription['drugs_list']:
                    active_prescription['drugs_list'][-1] = active_prescription['drugs_list'][-1].replace('and ', '')
                    active_prescription['drugs_list'].append(variables['drug_name'])

            notifrec['drugs_list'] = active_prescription['drugs_list']
            meta_doc_id = active_prescription['id']
            notifrec['update_date'] = datetime.now().isoformat()
            message = generate_message(notifrec, current_pharmacy['pharmacy_name'].values[0],
                                       lowest_price_series['pharmacy_name'],
                                       str(lowest_price_series['drug_distance'].__round__(3)),
                                       float(notifrec['out_of_pocket']),
                                       float(notifrec['savings_amount']),
                                       int(min_savings))  # hot fix
        else:
            notifrec['create_date'] = datetime.now().isoformat()
            message = generate_message(notifrec, current_pharmacy['pharmacy_name'].values[0],
                                       lowest_price_series['pharmacy_name'],
                                       str(lowest_price_series['drug_distance'].__round__(3)),
                                       float(notifrec['out_of_pocket']),
                                       float(notifrec['savings_amount']),
                                       int(min_savings))  # hot fix

            notifrec['update_date'] = datetime.now().isoformat()
            meta_doc_id = str(sclaim_struct['cb_handle'].counter('docid', delta=1).value)

        notifrec['update_date'] = datetime.now().isoformat()
        notifrec['message'] = message
        print(notifrec)
        sclaim_struct['logger_handle'].debug(f"Notification record: {notifrec}")
        sclaim_struct['cb_handle'].upsert(meta_doc_id, notifrec, format=FMT_JSON)
    else:
        notifrec['awaiting_response'] = 'N'
        sclaim_struct['logger_handle'].debug("No savings found with current drug.")

        message = ''
        if active_prescription:
            notifrec['create_date'] = active_prescription['create_date']
            notifrec['out_of_pocket'] += active_prescription['out_of_pocket']
            notifrec['savings_amount'] += active_prescription['savings_amount']
            if isinstance(active_prescription['prescription_id'], list):
                if prescid not in active_prescription['prescription_id']:
                    active_prescription['prescription_id'].append(prescid)
                notifrec['prescription_id'] = active_prescription['prescription_id']
            else:
                notifrec['prescription_id'] = [prescid, active_prescription['prescription_id']]

            # keep track of drugs for the current claim id
            if isinstance(active_prescription['drugs_list'], list):
                if variables['drug_name'] not in active_prescription['drugs_list']:
                    active_prescription['drugs_list'][-1] = active_prescription['drugs_list'][-1].replace('and ', '')
                    active_prescription['drugs_list'].append(variables['drug_name'])

            notifrec['drugs_list'] = active_prescription['drugs_list']
            meta_doc_id = active_prescription['id']
            notifrec['update_date'] = datetime.now().isoformat()
            message = generate_message(notifrec, current_pharmacy['pharmacy_name'].values[0],
                                       current_pharmacy['pharmacy_name'].values[0],
                                       str(current_pharmacy['drug_distance'].values[0].__round__(3)),
                                       float(notifrec['out_of_pocket']),
                                       float(notifrec['savings_amount']),
                                       int(min_savings))  # hot fix
        else:
            notifrec['create_date'] = datetime.now().isoformat()
            message = generate_message(notifrec, current_pharmacy['pharmacy_name'].values[0],
                                       current_pharmacy['pharmacy_name'].values[0],
                                       str(current_pharmacy['drug_distance'].values[0].__round__(3)),
                                       float(notifrec['out_of_pocket']),
                                       float(notifrec['savings_amount']),
                                       int(min_savings))  # hot fix
            notifrec['update_date'] = datetime.now().isoformat()
            meta_doc_id = str(sclaim_struct['cb_handle'].counter('docid', delta=1).value)

        notifrec['update_date'] = datetime.now().isoformat()
        notifrec['message'] = message
        print(notifrec)
        sclaim_struct['logger_handle'].debug(f"Notification record: {notifrec}")
        sclaim_struct['cb_handle'].upsert(meta_doc_id, notifrec, format=FMT_JSON)

    pricelist.sort_values(by=['employee_opc', 'drug_reward', 'drug_distance'], ascending=[True, False, True],
                          inplace=True)
    pricelist.reset_index(drop=True, inplace=True)
    best_option_npi = best_option_name = best_option_cost = ''

    # for i, r in pricelist.iterrows():
    #     best_option_cost = r['drug_out_of_pocket']
    #     best_option_npi = r['pharmacy_npi']
    #     best_option_name = r['pharmacy_name']
    #     break
    # optimized above code - since we are always taking the very first entry from pricelist,
    # rewrite it as below - Rajesh Acharya, 10/5/2019
    row_data = pricelist.loc[0]
    best_option_cost = row_data['drug_out_of_pocket']
    best_option_npi = row_data['pharmacy_npi']
    best_option_name = row_data['pharmacy_name']
    savings = 0

    selected_pharmacy = pricelist.loc[(pricelist['pharmacy_npi'] == str(npi).lstrip('0')), :]
    sclaim_struct['logger_handle'].debug("Getting the selected pharmacy: {}".format(selected_pharmacy))

    selected_cost = selected_pharmacy['employee_opc'].values[0]
    sclaim_struct['logger_handle'].debug("Getting the selected cost: {}".format(selected_cost))
    if int(npi) != int(best_option_npi):
        if float(selected_cost) - float(best_option_cost) > 3:
            savings = float(selected_cost) - float(best_option_cost)
    status = 'Success'
    sclaim_struct['logger_handle'].debug("Status is {}".format(status))

    return int(savings), best_option_cost, best_option_npi, best_option_name, selected_pharmacy, 'Success', \
           savings_send_result, None
# end function


def generate_message(notifrec_dict, pharma_name_curr, pharma_name_lowest,
                     pharma_lowest_dist, out_of_pocket_cost, 
                     savings_amt, min_savings):
    """
    Create the appropriate text message for storing in the notification log
    :param notifrec_dict:
    :param pharma_name_curr:
    :param pharma_name_lowest:
    :param pharma_lowest_dist:
    :param out_of_pocket_cost:
    :param savings_amt:
    :return: message
    """
    message = 'Your prescription for DRUGS_DETAIL was received at PHARMA_CURR with a due of $OUT_OF_POCKET. '
    message += 'Flipt found PHARMA_LOWEST with $SAVINGS savings PHARMA_LOW_DIST miles away. '
    message += 'Reply Y to transfer your Rx and save $SAVINGS.'

    nosavings_message = 'Your prescription for DRUGS_DETAIL has been received at PHARMA_CURR.  Your out-of-pocket cost '
    nosavings_message += 'is $OUT_OF_POCKET for this prescription.'

    multi_message = "We noticed that you have multiple drugs prescribed, and we found PHARMA_LOWEST with "
    multi_message += "$SAVINGS savings PHARMA_LOW_DIST miles away for DRUGS_DETAIL. "
    multi_message += "Reply Y to transfer your Rx and save $SAVINGS."

    drug_list = notifrec_dict['drugs_list']

    # added the check against min_savings for hot-fix
    if savings_amt != 0 and savings_amt > min_savings:
        if len(drug_list) > 1:
            message = multi_message
    else:
        message = nosavings_message

    OUT_OF_POCKET = "{:.2f}".format(out_of_pocket_cost)
    SAVINGS_AMT = "{:.2f}".format(savings_amt)

    if len(drug_list) == 2:
        conjucate = ' and '
    elif len(drug_list) > 2:
        conjucate = ','
        drug_list[-1] = 'and ' + drug_list[-1]

    if len(drug_list) == 1:
        drug_str = drug_list[0]
    else:
        drug_str = conjucate.join(drug_list)

    message = message.replace('DRUGS_DETAIL', drug_str)
    message = message.replace('PHARMA_CURR', pharma_name_curr)
    message = message.replace('OUT_OF_POCKET', OUT_OF_POCKET).replace('SAVINGS', SAVINGS_AMT)
    message = message.replace('PHARMA_LOWEST', pharma_name_lowest)
    message = message.replace('PHARMA_LOW_DIST', pharma_lowest_dist)
    return message
# end function
