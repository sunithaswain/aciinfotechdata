DROP TABLE IF EXISTS flipt_dw.dda_route;
create table flipt_dw.dda_route
(
Route_ID BIGINT,
Transaction_Code VARCHAR(200),
Route_Abbreviation VARCHAR(200),
Route_Description VARCHAR(200),
Reserve VARCHAR(200),
create_date datetime default sysdate,
update_date DATE
);

