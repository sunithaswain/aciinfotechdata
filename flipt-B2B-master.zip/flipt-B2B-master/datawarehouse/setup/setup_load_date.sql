DROP TABLE IF EXISTS flipt_dw.dw_load_date;
create table flipt_dw.dw_load_date
 (table_name varchar(50),
 table_last_load_date timestamp,
 load_date timestamp,
 update_date timestamp);