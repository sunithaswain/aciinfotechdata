DROP TABLE IF EXISTS flipt_dw.dw_mf2sec CASCADE;
create table flipt_dw.dw_mf2sec
 (external_drug_id varchar(50),
 external_drug_id_type_code varchar(40),
 alternate_drug_id varchar(100),
 alternate_drug_id_fomat_code varchar(100),
 transaction_code varchar(50),
 reserve varchar(150));