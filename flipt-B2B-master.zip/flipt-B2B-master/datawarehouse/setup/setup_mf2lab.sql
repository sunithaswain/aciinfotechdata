DROP TABLE IF EXISTS flipt_dw.dw_mf2lab CASCADE;
create table flipt_dw.dw_mf2lab
 (medispan_labeler_id integer,
 manufacturer_name varchar(80),
 manufacturer_abbr_name varchar(50),
 labeler_type_code varchar(40),
 reserve varchar(50),
 transaction_code varchar(200),
 last_change_date varchar(200));