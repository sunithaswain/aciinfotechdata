DROP TABLE IF EXISTS flipt_dw.dw_dtmsReactingDrugs CASCADE;
create table flipt_dw.dw_dtmsReactingDrugs
 (classnum1 varchar(200),
 classnum2 varchar(200),
 kdc1 varchar(200),
 kdc2 varchar(200),
 created_date varchar(200),
 updated_date varchar(200),
 primary key(kdc1,kdc2),
 foreign key(classnum1,classnum2) references flipt_dw.dw_dtmsReaction(classnum1,classnum2));