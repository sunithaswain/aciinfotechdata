DROP TABLE IF EXISTS flipt_dw.dw_mf2idrg CASCADE;
create table flipt_dw.dw_mf2idrg
 (ingredient_drug_id varchar(100),
 transaction_code varchar(50),
 cas_number varchar(20),
 kdc varchar(70),
 reserve1 varchar(30),
 ingredient_drug_name varchar(60),
 generic_id varchar(50),
 reserve2 varchar(100));