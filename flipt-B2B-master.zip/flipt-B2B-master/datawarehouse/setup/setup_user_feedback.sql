DROP TABLE IF EXISTS flipt_dw.dw_user_feedback;
create table flipt_dw.dw_user_feedback
 (action varchar(200),
 comment varchar(2000),
 created_date varchar(200),
 domain varchar(200),
 flipt_person_id varchar(200),
 id varchar(200),
 rating varchar(200),
 type varchar(200));