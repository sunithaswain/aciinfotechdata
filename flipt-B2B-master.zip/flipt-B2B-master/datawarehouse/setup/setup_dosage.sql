DROP TABLE IF EXISTS flipt_dw.dw_dosage CASCADE;
create table flipt_dw.dw_dosage
 (DOSAGEDESCRIPTION varchar(200),
 CODE varchar(200),
 ABBREVIATION varchar(200),
 C6 integer,
 COMMENTS varchar(max));