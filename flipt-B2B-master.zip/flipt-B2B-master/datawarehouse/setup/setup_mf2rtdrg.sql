DROP TABLE IF EXISTS flipt_dw.dw_mf2rtdrg CASCADE;
create table flipt_dw.dw_mf2rtdrg
 (concept_type integer,
 country_code integer,
 concept_id varchar(100),
 transaction_code varchar(40),
 drug_name_id varchar(100),
 route_id varchar(150),
 status varchar(100),
 link_value varchar(100),
 link_date varchar(100),
 reserve varchar(200));