DROP TABLE IF EXISTS flipt_dw.dw_mf2drg CASCADE;
create table flipt_dw.dw_mf2drg
 (concept_type integer,
 country_code integer,
 concept_id varchar(100),
 transaction_code varchar(100),
 routed_drug_id varchar(100),
 dose_form_id varchar(100),
 strength varchar(50),
 strength_unit_of_measure varchar(50),
 name_source_id integer,
 device_flag integer,
 status integer,
 link_value varchar(100),
 link_date varchar(100),
 routed_drug_form_id varchar(100),
 drug_dose_form_id varchar(100),
 str_str_uom_id varchar(100),
 reserve varchar(30));