DROP TABLE IF EXISTS flipt_dw.dw_mf2tcgpi CASCADE;
create table flipt_dw.dw_mf2tcgpi
 (tcgpi_id varchar(150),
 record_type varchar(100),
 tcgpi_name varchar(100),
 tc_level_code varchar(100),
 reserve varchar(100),
 transaction_code varchar(100),
 last_change_date varchar(100));