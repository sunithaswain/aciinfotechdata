DROP TABLE IF EXISTS flipt_dw.dw_mf2ings CASCADE;
create table flipt_dw.dw_mf2ings
 (ingredient_set_id varchar(100),
 ingredient_id varchar(100),
 active_inactive_flag varchar(50),
 transaction_code varchar(200),
 reserve varchar(200));