DROP TABLE IF EXISTS flipt_dw.dw_mf2rnm CASCADE;
create table flipt_dw.dw_mf2rnm
 (concept_type integer,
 country_code integer,
 concept_id varchar(100),
 id_for_generic_named_drug varchar(100),
 transaction_code varchar(50),
 medispan_reference_flag varchar(50),
 reserve varchar(100));