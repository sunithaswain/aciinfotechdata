DROP TABLE IF EXISTS flipt_dw.dda_alternate_unit_measure;
DROP TABLE IF EXISTS flipt_dw.dda_dosing_patient_profile;
DROP TABLE IF EXISTS flipt_dw.dda_gpi_dose_text;
DROP TABLE IF EXISTS flipt_dw.dda_gpi_dose;
DROP TABLE IF EXISTS flipt_dw.dda_route;
DROP TABLE IF EXISTS flipt_dw.dda_unit_of_measure;

create table flipt_dw.dda_alternate_unit_measure
(
Alternate_Unit_of_Measure_ID BIGINT,
Transaction_Code VARCHAR(200),
Unit_of_Measure_ID BIGINT,
Alternate_Unit_of_Measure_Description  VARCHAR(200),
Reserve  VARCHAR(200),
create_date datetime default sysdate,
update_date DATE

);

create table flipt_dw.dda_dosing_patient_profile
(
Profile_ID BIGINT,
Transaction_Code VARCHAR(200),
Indication_Code BIGINT,
Special_Condition_Code BIGINT,
Age_Type_Code VARCHAR(200),
Age_Days_Low BIGINT,
Age_Days_High BIGINT,
Additional_Age_Type_Code VARCHAR(200),
Additional_Age_Days_Low BIGINT,
Additional_Age_Days_High BIGINT,
Renal_Function_Msmt_Type_Code VARCHAR(200),
Renal_Function_Msmt_Low BIGINT,
Renal_Function_Msmt_High BIGINT,
Renal_Function_Msmt_UOM_Code VARCHAR(200),
Weight_Category_Low BIGINT,
Weight_Category_High BIGINT,
Weight_Category_UOM_Code VARCHAR(200),
Reserve VARCHAR(200),
create_date datetime default sysdate,
update_date DATE
);

create table flipt_dw.dda_gpi_dose_text
(
Dose_ID BIGINT,
Text_Type_ID VARCHAR(200),
Level_Code VARCHAR(200),
Sequence_Number BIGINT,
Transaction_Code VARCHAR(200),
Text_ID BIGINT,
Reserve VARCHAR(200),
create_date datetime default sysdate,
Update_date DATE
);

create table flipt_dw.dda_gpi_dose
(
Dose_ID BIGINT,
Transaction_Code VARCHAR(200),
Profile_ID BIGINT,
Generic_Product_ID VARCHAR(200),
Reserve_1 VARCHAR(200),
Route_ID BIGINT,
Dose_Type_Code VARCHAR(200),
Daily_Dose_Low BIGINT,
Daily_Dose_Low_UOM_ID BIGINT,
Daily_Dose_High BIGINT,
Daily_Dose_High_UOM_ID BIGINT,
Daily_Dose_Form_Low BIGINT,
Daily_Dose_Form_Low_UOM_ID BIGINT,
Daily_Dose_Form_High BIGINT,
Daily_Dose_Form_High_UOM_ID BIGINT,
Max_Daily_Dose  BIGINT,
Max_Daily_Dose_UOM_ID BIGINT,
Max_Daily_Dose_Form BIGINT,
Max_Daily_Dose_Form_UOM_ID BIGINT,
Max_Single_Dose BIGINT,
Max_Single_Dose_UOM_ID BIGINT,
Max_Single_Dose_Form BIGINT,
Max_Single_Dose_Form_UOM_ID BIGINT,
Max_Lifetime_Dose BIGINT,
Max_Lifetime_Dose_UOM_ID BIGINT,
Max_Lifetime_Dose_Form BIGINT,
Max_Lifetime_Dose_Form_UOM_ID BIGINT,
Frequency_Low BIGINT,
Frequency_High BIGINT,
Max_Frequency BIGINT,
Duration_Low BIGINT,
Duration_High BIGINT,
MaxDuration BIGINT,
Drug_Half_Life_Low BIGINT,
Drug_Half_Life_High BIGINT,
Drug_Half_Life_UOM_Code BIGINT,
Reserve_2 BIGINT,
create_date datetime default sysdate,
update_date  DATE
);

create table flipt_dw.dda_route
(
Route_ID BIGINT,
Transaction_Code VARCHAR(200),
Route_Abbreviation VARCHAR(200),
Route_Description VARCHAR(200),
Reserve VARCHAR(200),
create_date datetime default sysdate,
update_date DATE
);

create table flipt_dw.dda_unit_of_measure
(
Unit_of_Measure_ID BIGINT,
Transaction_Code VARCHAR(200),
Unit_of_Measure_Description VARCHAR(200),
Unit_of_Measure_Type_Code VARCHAR(200),
Reserve VARCHAR(200),
create_date datetime default sysdate,
update_date DATE
)