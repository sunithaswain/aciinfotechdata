DROP TABLE IF EXISTS flipt_dw.dw_rxplan_master;
create table flipt_dw.dw_rxplan_master
 (annual_deductible_family varchar(200),
 annual_deductible_individual varchar(200),
 annual_out_of_pocket_family varchar(200),
 annual_out_of_pocket_individual varchar(200),
 deductible_exempted varchar(200),
 domain_name varchar(200),
 individual_deductible_embedded varchar(200),
 individual_out_of_pocket_embedded varchar(200),
 plan_end_date varchar(200),
 plan_name varchar(200),
 plan_start_date varchar(200),
 plan_year varchar(200),
 prescriber_restriction_flag varchar(200),
 type varchar(200),
 update_formulary_flag varchar(10));