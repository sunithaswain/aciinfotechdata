DROP TABLE IF EXISTS flipt_dw.dw_notification_log;
create table flipt_dw.dw_notification_log
 (create_date varchar(200),
 device_count varchar(200),
 flipt_person_id varchar(200),
 notification_type varchar(200),
 prescription_id varchar(200),
 result varchar(200),
 type varchar(200),
 update_date varchar(200));