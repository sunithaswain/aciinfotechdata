DROP TABLE IF EXISTS flipt_dw.dw_dtmsRouteOfAdministration;
create table flipt_dw.dw_dtmsRouteOfAdministration
 (route varchar(200),
 route_full_name varchar(200),
 actcode integer,
 created_date varchar(200),
 updated_date varchar(200),
 primary key(route));