DROP TABLE IF EXISTS flipt_dw.dw_mf2dict CASCADE;
create table flipt_dw.dw_mf2dict
 (field_identifier varchar(50),
 field_description varchar(100),
 field_type varchar(50),
 field_length integer,
 implied_decimal_flag varchar(50),
 decimal_places integer,
 field_validation_flag varchar(50),
 field_abbreviation_flag varchar(50),
 reserve varchar(100));