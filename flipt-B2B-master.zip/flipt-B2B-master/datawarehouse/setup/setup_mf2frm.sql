DROP TABLE IF EXISTS flipt_dw.dw_mf2frm CASCADE;
create table flipt_dw.dw_mf2frm
 (concept_type integer,
 country_code integer,
 concept_id varchar(100),
 transaction_code varchar(50),
 status integer,
 link_value varchar(100),
 link_date varchar(100),
 reserve varchar(100));