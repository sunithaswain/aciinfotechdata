########################################
# !/usr/bin/env python  
# title         :dda_runsql_file.py
# description   : Setup-Drop and create redshift tables
# author        : Soujanya Veerubhotla
# date created  : 20190425
# date last modified    : 
# version       : 0.1
# maintainer    : 
# email         : sveerubhotla@fliptrx.com
# status        : Development
# Python Version: 3.5.X
# usage         : python dda_runsql_file.py -t dda_all
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#                          
# #######################################
rootdir = ''
if __name__ == '__main__':
    import os
    import sys
    rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    # print(rootdir)


import os, traceback
import sys
import logging
import psycopg2
import getopt
import dateutil.parser
from datetime import datetime
import sendgrid
import os
from sendgrid.helpers.mail import *

logging.basicConfig(level=logging.INFO)
# logging.basicConfig(format='%(threadName)s:%(levelname)s:%(asctime)s:%(name)s:%(funcName)s:%(message)s', datefmt='%d-%m-%y %H:%M:%S')
LOG = logging.getLogger('Setup-Drop and create tables in redshift')

project_path = os.environ['CB_DATA']

dbname = os.environ['RDS_DBNAME']
host = os.environ['RDS_SERVER']
prt = os.environ['RDS_PORT']
usr = os.environ['RDS_USERID']
passwd = os.environ['RDS_PWD']

doctype = ["dda_all","dda_alternate_unit_measure","dda_dosing_patient_profile","dda_gpi_dose_text",
            "dda_gpi_dose","dda_route","dda_unit_of_measure"]
print("dbname={} host={} port={} user={} password={}".format(dbname, host, prt, usr, passwd))
conn = psycopg2.connect("dbname={} host={} port={} user={} password={}".format(dbname, host, prt, usr, passwd))
cur = conn.cursor()

def send_email(filename):
    sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))
    from_email = Email("noreply@fliptrx.com")
    to_email = Email("fliptintegration@fliptrx.com")
    subject = "ERROR:"+dbname+" :"+host+" :"+ filename+" setup failed"
    content = Content("text/plain", "ERROR:"+dbname+" :"+host+" :"+ filename+" setup failed")
    mail = Mail(from_email, subject, to_email, content)
    response = sg.client.mail.send.post(request_body=mail.get())
    print(response.status_code)
    print(response.body)
    print(response.headers)


def executeScriptsFromFile(filename):
    print("executeScriptsFromFile is called")
    try:
        fd = open(filename, 'r')
        sqlFile = fd.read()
        fd.close()

        sqlCommands = sqlFile.split(';')

        for command in sqlCommands:
            if command != "":
                print(command)
                cur.execute(command)
                conn.commit()
        executionstatus = "Success"		
    except Exception as e:
        print(traceback.format_exc())
        executionstatus = "Failure"
        send_email(filename) 

    print("executionstatus is %s"%executionstatus)       

def main():
    global LOG
    tablename = None
    try:
        opts, args = getopt.getopt(sys.argv[1:], "-t:")
    except getopt.GetoptError:
        print('filetype.py -t <tablename>')
        LOG.info("filetype.py -t <tablename>")
        sys.exit(2)
    for opt, arg in opts:
        if opt in ("-t"):
            tablename = arg
	
    # fformat = logging.Formatter('%(tablename)s:%(levelname)s:%(message)s')
    logpath = os.environ['CB_DATA']+'//datawarehouse//log//log_'+tablename+datetime.now().strftime("%Y%m%d%H%M") +'.txt'
    handler = logging.FileHandler(logpath)
    # handler.setFormatter(fformat)
    LOG.addHandler(handler)

    LOG.info("=========================================================")
    LOG.info("=============== Setup-Drop and create redshift tables ==============")
	
    try: 
        if tablename == 'dda_alternate_unit_measure':
            print("dda_alternate_unit_measure")
            LOG.info("dda_alternate_unit_measure")
            executeScriptsFromFile(rootdir+"/datawarehouse/setup/setup_dda_alternate_unit_measure.sql")

        elif tablename == 'dda_dosing_patient_profile':
            print("dda_dosing_patient_profile")
            LOG.info("dda_dosing_patient_profile")
            executeScriptsFromFile(rootdir+"/datawarehouse/setup/setup_dda_dosing_patient_profile.sql")

        elif tablename == 'dda_gpi_dose_text':
            print("dda_gpi_dose_text")
            LOG.info("dda_gpi_dose_text")
            executeScriptsFromFile(rootdir+"/datawarehouse/setup/setup_dda_gpi_dose_text.sql")		
        elif tablename == 'dda_gpi_dose':
            print("dda_gpi_dose")
            LOG.info("dda_gpi_dose")
            executeScriptsFromFile(rootdir+"/datawarehouse/setup/setup_dda_gpi_dose.sql")

        elif tablename == 'dda_route':
            print("dda_route")
            LOG.info("dda_route")
            executeScriptsFromFile(rootdir+"/datawarehouse/setup/setup_dda_route.sql")
        
        elif tablename == 'dda_unit_of_measure':
            print("dda_unit_of_measure")
            LOG.info("dda_unit_of_measure")
            executeScriptsFromFile(rootdir+"/datawarehouse/setup/setup_dda_unit_of_measure.sql")
        
        elif tablename == 'dda_all':
            print("All tables")
            LOG.info("All tables")
            executeScriptsFromFile(rootdir+"/datawarehouse/setup/setup_dda_final.sql")   
            
        elif tablename not in doctype:
            executionstatus = "Failure"
            send_email(tablename)
    
    except:
        executionstatus = "Failure"
        send_email(tablename)			
    
    LOG.info("=========================================================")

if __name__ == '__main__':
    sys.exit(main())	