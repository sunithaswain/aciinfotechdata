DROP TABLE IF EXISTS flipt_dw.dw_mf2str CASCADE;
create table flipt_dw.dw_mf2str
 (ingredient_id varchar(100),
 reserve_1 varchar(60),
 transaction_code varchar(50),
 ingredient_drug_id varchar(100),
 ingredient_strength_value varchar(100),
 ingredient_stength_uom_comb varchar(100),
 ingredient_strength_uom_indv varchar(101),
 volume_value varchar(130),
 volume_uom varchar(110),
 reserve varchar(126));