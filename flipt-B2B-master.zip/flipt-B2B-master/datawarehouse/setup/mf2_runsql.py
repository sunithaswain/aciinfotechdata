########################################
# !/usr/bin/env python  
# title         :mf2_runsql.py
# description   : Setup-Drop and create redshift tables
# author        : Pal
# date created  : 20190804
# date last modified    : 
# version       : 0.1
# maintainer    : 
# email         : pmuthanai@fliptrx.com
# status        : Development
# Python Version: 3.5.X
# usage         : python mf2_runsql.py -t mf2All
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#                          
# #######################################
rootdir = ''
if __name__ == '__main__':
    import os
    import sys
    rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    # print(rootdir)


import os, traceback
import sys
import logging
import psycopg2
import getopt
import dateutil.parser
from datetime import datetime
import sendgrid
import os
from sendgrid.helpers.mail import *

logging.basicConfig(level=logging.INFO)
# logging.basicConfig(format='%(threadName)s:%(levelname)s:%(asctime)s:%(name)s:%(funcName)s:%(message)s', datefmt='%d-%m-%y %H:%M:%S')
LOG = logging.getLogger('Setup-Drop and create tables in redshift')

project_path = os.environ['CB_DATA']

dbname = os.environ['RDS_DBNAME']
host = os.environ['RDS_SERVER']
prt = os.environ['RDS_PORT']
usr = os.environ['RDS_USERID']
passwd = os.environ['RDS_PWD']


print("dbname={} host={} port={} user={} password={}".format(dbname, host, prt, usr, passwd))
conn = psycopg2.connect("dbname={} host={} port={} user={} password={}".format(dbname, host, prt, usr, passwd))
cur = conn.cursor()

def send_email(filename):
    sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))
    from_email = Email("noreply@fliptrx.com")
    to_email = Email("fliptintegration@fliptrx.com")
    subject = "ERROR:"+dbname+" :"+host+" :"+ filename+" setup failed"
    content = Content("text/plain", "ERROR:"+dbname+" :"+host+" :"+ filename+" setup failed")
    mail = Mail(from_email, subject, to_email, content)
    response = sg.client.mail.send.post(request_body=mail.get())
    print(response.status_code)
    print(response.body)
    print(response.headers)


def executeScriptsFromFile(filename):
    print("executeScriptsFromFile is called")
    try:
        fd = open(filename, 'r')
        sqlFile = fd.read()
        fd.close()

        sqlCommands = sqlFile.split(';')

        for command in sqlCommands:
            if command != "":
                print(command)
                cur.execute(command)
                conn.commit()
        executionstatus = "Success"		
    except Exception as e:
        print(traceback.format_exc())
        executionstatus = "Failure"
        send_email(filename) 

    print("executionstatus is %s"%executionstatus)       

def main():
    global LOG
    tablename = None
    try:
        opts, args = getopt.getopt(sys.argv[1:], "-t:")
    except getopt.GetoptError:
        print('filetype.py -t <tablename>')
        LOG.info("filetype.py -t <tablename>")
        sys.exit(2)
    for opt, arg in opts:
        if opt in ("-t"):
            tablename = arg
	
    # fformat = logging.Formatter('%(tablename)s:%(levelname)s:%(message)s')
    logpath = os.environ['CB_DATA']+'//datawarehouse//log//log_'+tablename+datetime.now().strftime("%Y%m%d%H%M") +'.txt'
    handler = logging.FileHandler(logpath)
    # handler.setFormatter(fformat)
    LOG.addHandler(handler)

    LOG.info("=========================================================")
    LOG.info("=============== Setup-Drop and create redshift tables ==============")
	
    try: 
        if tablename != 'mf2All':
            print(tablename)
            LOG.info(tablename)
            executeScriptsFromFile("datawarehouse/setup/setup_"+tablename+".sql")
		
        elif tablename == 'mf2All':
            print("All mf2 tables")
            LOG.info("All mf2 tables")
            executeScriptsFromFile("datawarehouse/setup/setup_mf2All.sql")
    
    except:
        executionstatus = "Failure"
        send_email(tablename)			
    
    LOG.info("=========================================================")

if __name__ == '__main__':
    sys.exit(main())	