DROP TABLE IF EXISTS flipt_dw.dw_dtmsDrugFormulation;
create table flipt_dw.dw_dtmsDrugFormulation
 (kdc1 integer,
 classnum integer,
 ingred_kdc1 integer,
 ingred_kdc2 integer,
 created_date varchar(200),
 updated_date varchar(200),
 primary key(kdc1));