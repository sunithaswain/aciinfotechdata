DROP TABLE IF EXISTS flipt_dw.dw_dtmsDrugFormulation;
create table flipt_dw.dw_dtmsDrugFormulation
 (kdc1 integer,
 classnum integer,
 ingred_kdc1 integer,
 ingred_kdc2 integer,
 created_date varchar(200),
 updated_date varchar(200),
 primary key(kdc1));

DROP TABLE IF EXISTS flipt_dw.dw_dtmsDrugNameIndex;
create table flipt_dw.dw_dtmsDrugNameIndex
 (kdc1 integer,
 kdc2 integer,
 kdc3 integer,
 actcode integer,
 route varchar(200),
 needname integer,
 nametype varchar(200),
 name varchar(200),
 created_date varchar(200),
 updated_date varchar(200),
 primary key(name));

DROP TABLE IF EXISTS flipt_dw.dw_dtmsDrugNames;
create table flipt_dw.dw_dtmsDrugNames
 (drug_name varchar(200),
 kdc1 integer,
 kdc2 integer,
 created_date varchar(200),
 updated_date varchar(200),
 primary key(kdc1,kdc2));

DROP TABLE IF EXISTS flipt_dw.dw_dtmsNDCIndex;
create table flipt_dw.dw_dtmsNDCIndex
 (kdc1 integer,
 kdc2 integer,
 kdc3 integer,
 actcode integer,
 route varchar(200),
 ndc varchar(200),
 created_date varchar(200),
 updated_date varchar(200),
 primary key(ndc));

DROP TABLE IF EXISTS flipt_dw.dw_dtmsRouteOfAdministration;
create table flipt_dw.dw_dtmsRouteOfAdministration
 (route varchar(200),
 route_full_name varchar(200),
 actcode integer,
 created_date varchar(200),
 updated_date varchar(200),
 primary key(route));

DROP TABLE IF EXISTS flipt_dw.dw_dtmsInteraction CASCADE;
create table flipt_dw.dw_dtmsInteraction
(classnum1 integer,
 duration1 integer,
 schedule1 integer,
 classnum2 integer,
 duration2 integer,
 schedule2 integer,
 interaction_id varchar(100),
 onset integer,
 severity integer,
 documentation integer,
 management integer,
 actcode1 integer,
 actcode2 integer,
 contraindication integer,
 interaction_type varchar(200),
 classname1 varchar(200),
 classname2 varchar(200),
 warning varchar(20000),
 effects varchar(20000),
 mechanism varchar(20000),
 management_txt varchar(20000),
 discussion varchar(60000),
 "references" varchar(20000),
 report_test varchar(200),
 created_date varchar(200),
 updated_date varchar(200),
 primary key(classnum1,classnum2));

DROP TABLE IF EXISTS flipt_dw.dw_dtmsInteractingDrugs CASCADE;
create table flipt_dw.dw_dtmsInteractingDrugs
 (classnum1 varchar(200),
 classnum2 varchar(200),
 reval varchar(200),
 kdc1 varchar(200),
 kdc2 varchar(200),
 created_date varchar(200),
 updated_date varchar(200),
 primary key(kdc1,kdc2),
 foreign key(classnum1,classnum2) references flipt_dw.dw_dtmsInteraction(classnum1,classnum2));

DROP TABLE IF EXISTS flipt_dw.dw_dtmsReaction CASCADE;
create table flipt_dw.dw_dtmsReaction
 (classnum1 varchar(200),
 classnum2 varchar(200),
 symptom varchar(200),
 classname1 varchar(200),
 classname2 varchar(200),
 prior_reaction varchar(200),
 reacting_drug varchar(200),
 discussion varchar(200),
 "references" varchar(200),
 "text" varchar(200),
 created_date varchar(200),
 updated_date varchar(200),
 primary key(classnum1,classnum2)
 );

DROP TABLE IF EXISTS flipt_dw.dw_dtmsReactingDrugs CASCADE;
create table flipt_dw.dw_dtmsReactingDrugs
 (classnum1 varchar(200),
 classnum2 varchar(200),
 kdc1 varchar(200),
 kdc2 varchar(200),
 created_date varchar(200),
 updated_date varchar(200),
 primary key(kdc1,kdc2),
 foreign key(classnum1,classnum2) references flipt_dw.dw_dtmsReaction(classnum1,classnum2));