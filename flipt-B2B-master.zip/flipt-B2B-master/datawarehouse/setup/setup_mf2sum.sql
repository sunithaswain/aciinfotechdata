DROP TABLE IF EXISTS flipt_dw.dw_mf2sum CASCADE;
create table flipt_dw.dw_mf2sum
 (record_type varchar(100),
 reserve_1 varchar(50),
 sequence_number integer,
 reserve_2 varchar(100),
 comment_marker varchar(200),
 data_comment varchar(200));