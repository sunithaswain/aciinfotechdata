DROP TABLE IF EXISTS flipt_dw.dw_mf2val CASCADE;
create table flipt_dw.dw_mf2val
 (field_identifier varchar(100),
 field_value varchar(150),
 language_code integer,
 value_description varchar(100),
 value_abbreviation varchar(150),
 reserve varchar(200));