DROP TABLE IF EXISTS flipt_dw.dw_mf2ndcm CASCADE;
create table flipt_dw.dw_mf2ndcm
 (ndc_upc_hri varchar(100),
 modifier_code varchar(60),
 reserve varchar(100),
 transaction_code varchar(200),
 last_change_date varchar(200));