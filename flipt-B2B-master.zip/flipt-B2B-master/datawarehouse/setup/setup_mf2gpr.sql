DROP TABLE IF EXISTS flipt_dw.dw_mf2gpr CASCADE;
create table flipt_dw.dw_mf2gpr
 (generic_product_pack_code varchar(50),
 gppc_price_code varchar(10),
 effective_date varchar(100),
 unit_price varchar(100),
 reserve varchar(200),
 transaction_code varchar(10),
 last_change_date varchar(100));