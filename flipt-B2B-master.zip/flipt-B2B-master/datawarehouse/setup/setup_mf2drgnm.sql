DROP TABLE IF EXISTS flipt_dw.dw_mf2drgnm CASCADE;
create table flipt_dw.dw_mf2drgnm
 (concept_type varchar(50),
 country_code integer,
 concept_id varchar(100),
 transaction_code varchar(50),
 name_type varchar(100),
 status integer,
 link_value varchar(100),
 link_date varchar(100),
 reserve varchar(100));