DROP TABLE IF EXISTS flipt_dw.dw_dtmsReaction CASCADE;
create table flipt_dw.dw_dtmsReaction
 (classnum1 varchar(200),
 classnum2 varchar(200),
 symptom varchar(200),
 classname1 varchar(200),
 classname2 varchar(200),
 prior_reaction varchar(200),
 reacting_drug varchar(200),
 discussion varchar(200),
 "references" varchar(200),
 "text" varchar(200),
 created_date varchar(200),
 updated_date varchar(200),
 primary key(classnum1,classnum2)
 );