DROP TABLE IF EXISTS flipt_dw.dw_mf2set CASCADE;
create table flipt_dw.dw_mf2set
 (concept_type integer,
 country_code integer,
 concept_id varchar(70),
 ingredient_set_id varchar(100),
 transaction_code varchar(40),
 representative_set_flag varchar(30),
 reserve varchar(75));