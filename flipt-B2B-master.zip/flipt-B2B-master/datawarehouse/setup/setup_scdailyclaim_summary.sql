DROP TABLE IF EXISTS flipt_dw.dw_scdailyclaim_summary;
CREATE TABLE flipt_dw.dw_scdailyclaim_summary(auth_id int,sequence_number int,transaction_id varchar(100),fill_number int,account varchar(100),
            bin varchar(100),pcn varchar(100),carrier varchar(100),"group" varchar(100),claim_date varchar(200),
            claim_type varchar(100),member_id varchar(100),rx_flipt_person_id varchar(100),rx_number varchar(100),date_of_service varchar(200),
            days_supply int,amt_paid_to_pharmacy float,awp_unit varchar(100),client_disp_fee float,client_due_amt float,
            client_ing_cost float,client_mac_price float,submitted_disp_fee float,submitted_gross_due varchar(100),submitted_ing_cost float,
            submitted_sales_tax varchar(100),submitted_uc varchar(100),calculated_disp_fee float,calculated_gross_due varchar(100),calculated_ing_cost float,
            calculated_sales_tax varchar(100),Response_disc_fee float,response_gross_due varchar(100),response_ing_cost float,response_sales_tax varchar(100),
            patient_paid float,disp_fee_paid float,ing_cost_paid float,sales_tax_paid float,formulary_status varchar(100),
            gpi_code varchar(100),quantity_dispensed varchar(100),pharmacy_mac_price float,product_id_ndc varchar(100),product_name_full varchar(100),
            manuf_abr varchar(100),message varchar(100),multisource_code varchar(100),network_id varchar(100),otc_indicator varchar(100),
            person_code varchar(50),pharmacy_name varchar(100),pharmacy_ncpdp varchar(100),pharmacy_npi varchar(100),pharmacy_rejection_reason varchar(2000),
            prescriber_first_name varchar(100),prescriber_last_name varchar(100),prescriber_npi varchar(100),rel_code varchar(50),status varchar(100),
            type varchar(50),create_date varchar(200),created_by varchar(100),update_date varchar(200),updated_by varchar(100),claim_override_flag varchar(200));