DROP TABLE IF EXISTS flipt_dw.dw_mf2stuom CASCADE;
create table flipt_dw.dw_mf2stuom
 (concept_type integer,
 country_code integer,
 concept_id varchar(100),
 transaction_code varchar(60),
 strength varchar(150),
 strength_unit_of_measure varchar(150),
 status integer,
 link_value varchar(100),
 link_date varchar(100),
 reserve varchar(190));