DROP TABLE IF EXISTS flipt_dw.dw_mf2prc CASCADE;
create table flipt_dw.dw_mf2prc
 (ndc_upc_hri varchar(100),
 price_code varchar(50),
 price_effective_date varchar(50),
 unit_price varchar(100),
 extended_unit_price varchar(100),
 package_price varchar(100),
 awp_indicator_code varchar(40),
 transaction_code varchar(30),
 last_change_date varchar(100));