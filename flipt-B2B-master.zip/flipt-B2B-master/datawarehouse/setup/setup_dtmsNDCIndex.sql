DROP TABLE IF EXISTS flipt_dw.dw_dtmsNDCIndex;
create table flipt_dw.dw_dtmsNDCIndex
 (kdc1 integer,
 kdc2 integer,
 kdc3 integer,
 actcode integer,
 route varchar(200),
 ndc varchar(200),
 created_date varchar(200),
 updated_date varchar(200),
 primary key(ndc));