DROP TABLE IF EXISTS flipt_dw.dw_mf2mod CASCADE;
create table flipt_dw.dw_mf2mod
 (modifier_code varchar(60),
 modifier_description varchar(100),
 reserve varchar(70),
 transaction_code varchar(30),
 last_change_date varchar(100));