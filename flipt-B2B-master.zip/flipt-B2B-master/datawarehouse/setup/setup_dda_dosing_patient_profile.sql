DROP TABLE IF EXISTS flipt_dw.dda_dosing_patient_profile;
create table flipt_dw.dda_dosing_patient_profile
(
Profile_ID BIGINT,
Transaction_Code VARCHAR(200),
Indication_Code BIGINT,
Special_Condition_Code BIGINT,
Age_Type_Code VARCHAR(200),
Age_Days_Low BIGINT,
Age_Days_High BIGINT,
Additional_Age_Type_Code VARCHAR(200),
Additional_Age_Days_Low BIGINT,
Additional_Age_Days_High BIGINT,
Renal_Function_Msmt_Type_Code VARCHAR(200),
Renal_Function_Msmt_Low BIGINT,
Renal_Function_Msmt_High BIGINT,
Renal_Function_Msmt_UOM_Code VARCHAR(200),
Weight_Category_Low BIGINT,
Weight_Category_High BIGINT,
Weight_Category_UOM_Code VARCHAR(200),
Reserve VARCHAR(200),
create_date datetime default sysdate,
update_date DATE
);
