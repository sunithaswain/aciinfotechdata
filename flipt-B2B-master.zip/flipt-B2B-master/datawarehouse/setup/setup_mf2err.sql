DROP TABLE IF EXISTS flipt_dw.dw_mf2err CASCADE;
create table flipt_dw.dw_mf2err
 (key_identifier varchar(50),
 unique_key varchar(100),
 data_element_code varchar(40),
 data_element_length varchar(50),
 reserve varchar(50));