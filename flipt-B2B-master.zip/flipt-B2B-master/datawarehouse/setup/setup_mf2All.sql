DROP TABLE IF EXISTS flipt_dw.dw_mf2desc CASCADE;
create table flipt_dw.dw_mf2desc
 (concept_type integer,
 country_code integer,
 concept_id varchar(100),
 type_code integer,
 transaction_code varchar(100),
 description varchar(200),
 reserve varchar(200));

DROP TABLE IF EXISTS flipt_dw.dw_mf2dfdrg CASCADE;
create table flipt_dw.dw_mf2dfdrg
 (concept_type integer,
 country_code integer,
 concept_id varchar(100),
 transaction_code varchar(50),
 drug_name_id varchar(100),
 dose_form_id varchar(50),
 status integer,
 link_value varchar(100),
 link_date varchar(100),
 reserve varchar(200));

DROP TABLE IF EXISTS flipt_dw.dw_mf2dict CASCADE;
create table flipt_dw.dw_mf2dict
 (field_identifier varchar(50),
 field_description varchar(100),
 field_type varchar(50),
 field_length integer,
 implied_decimal_flag varchar(50),
 decimal_places integer,
 field_validation_flag varchar(50),
 field_abbreviation_flag varchar(50),
 reserve varchar(100));

DROP TABLE IF EXISTS flipt_dw.dw_mf2drg CASCADE;
create table flipt_dw.dw_mf2drg
 (concept_type integer,
 country_code integer,
 concept_id varchar(100),
 transaction_code varchar(100),
 routed_drug_id varchar(100),
 dose_form_id varchar(100),
 strength varchar(50),
 strength_unit_of_measure varchar(50),
 name_source_id integer,
 device_flag integer,
 status integer,
 link_value varchar(100),
 link_date varchar(100),
 routed_drug_form_id varchar(100),
 drug_dose_form_id varchar(100),
 str_str_uom_id varchar(100),
 reserve varchar(30));

DROP TABLE IF EXISTS flipt_dw.dw_mf2drgnm CASCADE;
create table flipt_dw.dw_mf2drgnm
 (concept_type varchar(50),
 country_code integer,
 concept_id varchar(100),
 transaction_code varchar(50),
 name_type varchar(100),
 status integer,
 link_value varchar(100),
 link_date varchar(100),
 reserve varchar(100));

DROP TABLE IF EXISTS flipt_dw.dw_mf2err CASCADE;
create table flipt_dw.dw_mf2err
 (key_identifier varchar(50),
 unique_key varchar(100),
 data_element_code varchar(40),
 data_element_length varchar(50),
 reserve varchar(50));

DROP TABLE IF EXISTS flipt_dw.dw_mf2frm CASCADE;
create table flipt_dw.dw_mf2frm
 (concept_type integer,
 country_code integer,
 concept_id varchar(100),
 transaction_code varchar(50),
 status integer,
 link_value varchar(100),
 link_date varchar(100),
 reserve varchar(100));

DROP TABLE IF EXISTS flipt_dw.dw_mf2gppc CASCADE;
create table flipt_dw.dw_mf2gppc
 (generic_product_pack_code varchar(50),
 package_size varchar(100),
 package_size_uom varchar(50),
 package_quantity varchar(50),
 unit_dose_unit_use_pkg_code varchar(50),
 package_description_code varchar(100),
 generic_product_identifier varchar(100),
 reserve varchar(100),
 transaction_code varchar(10),
 last_change_date varchar(100));

DROP TABLE IF EXISTS flipt_dw.dw_mf2gpr CASCADE;
create table flipt_dw.dw_mf2gpr
 (generic_product_pack_code varchar(50),
 gppc_price_code varchar(10),
 effective_date varchar(100),
 unit_price varchar(100),
 reserve varchar(200),
 transaction_code varchar(10),
 last_change_date varchar(100));

DROP TABLE IF EXISTS flipt_dw.dw_mf2idrg CASCADE;
create table flipt_dw.dw_mf2idrg
 (ingredient_drug_id varchar(100),
 transaction_code varchar(50),
 cas_number varchar(20),
 kdc varchar(70),
 reserve1 varchar(30),
 ingredient_drug_name varchar(60),
 generic_id varchar(50),
 reserve2 varchar(100));

DROP TABLE IF EXISTS flipt_dw.dw_mf2ings CASCADE;
create table flipt_dw.dw_mf2ings
 (ingredient_set_id varchar(100),
 ingredient_id varchar(100),
 active_inactive_flag varchar(50),
 transaction_code varchar(200),
 reserve varchar(200));

DROP TABLE IF EXISTS flipt_dw.dw_mf2lab CASCADE;
create table flipt_dw.dw_mf2lab
 (medispan_labeler_id integer,
 manufacturer_name varchar(80),
 manufacturer_abbr_name varchar(50),
 labeler_type_code varchar(40),
 reserve varchar(50),
 transaction_code varchar(200),
 last_change_date varchar(200));

DROP TABLE IF EXISTS flipt_dw.dw_mf2mod CASCADE;
create table flipt_dw.dw_mf2mod
 (modifier_code varchar(60),
 modifier_description varchar(100),
 reserve varchar(70),
 transaction_code varchar(30),
 last_change_date varchar(100));

DROP TABLE IF EXISTS flipt_dw.dw_mf2name CASCADE;
create table flipt_dw.dw_mf2name
 (drug_descriptor_id varchar(60),
 drug_name varchar(100),
 route_of_administration varchar(50),
 dosage_form varchar(50),
 strength varchar(50),
 strength_unit_of_measure varchar(100),
 bioequivalence_code varchar(100),
 controlled_substance_code varchar(100),
 efficacy_code varchar(100),
 legend_indicator_code varchar(100),
 multi_source_code varchar(50),
 brand_name_code varchar(50),
 name_source_code varchar(50),
 generic_product_identifier varchar(100),
 kdc varchar(100),
 new_drug_descriptor_identifier varchar(60),
 screenable_flag varchar(40),
 kdc_flag varchar(40),
 local_systemic_flag varchar(40),
 maintenance_drug_code varchar(40),
 form_type_code varchar(40),
 internal_external_code varchar(40),
 single_combination_code varchar(40),
 representative_gpi_flag varchar(140),
 representative_kdc_flag varchar(40),
 reserve varchar(50),
 transaction_code varchar(100),
 last_change_date varchar(100));

DROP TABLE IF EXISTS flipt_dw.dw_mf2ndc CASCADE;
create table flipt_dw.dw_mf2ndc
 (ndc_upc_hri varchar(50),
 drug_descriptor_id varchar(60),
 tee_code varchar(40),
 dea_class_code varchar(30),
 desi_code varchar(40),
 rx_otc_indicator_code varchar(40),
 generic_product_pack_code varchar(80),
 old_ndc_upc_hri varchar(100),
 new_ndc_upc_hri varchar(100),
 repackaged_code varchar(100),
 id_number_format_code varchar(100),
 third_party_restriction_code varchar(100),
 kdc varchar(100),
 kdc_flag varchar(40),
 medispan_labeler_id integer,
 multi_source_code varchar(40),
 name_type_code varchar(40),
 item_status_flag varchar(40),
 innerpack_code varchar(40),
 clinic_pack_code varchar(40),
 reserve1 varchar(50),
 ppg_indicator_code varchar(50),
 hfpg_indicatory_code varchar(50),
 dispensing_unit_code varchar(50),
 dollar_rank_code varchar(50),
 rx_rank_code varchar(50),
 storage_condition_code varchar(50),
 limited_distribution_coe varchar(50),
 old_effective_date varchar(100),
 new_effective_date varchar(100),
 next_smaller_ndc_suffix varchar(50),
 next_larger_ndc_suffix varchar(50),
 reserve2 varchar(50),
 transaction_code varchar(40),
 last_change_date varchar(100));

DROP TABLE IF EXISTS flipt_dw.dw_mf2ndcm CASCADE;
create table flipt_dw.dw_mf2ndcm
 (ndc_upc_hri varchar(100),
 modifier_code varchar(60),
 reserve varchar(100),
 transaction_code varchar(200),
 last_change_date varchar(200));

DROP TABLE IF EXISTS flipt_dw.dw_mf2prc CASCADE;
create table flipt_dw.dw_mf2prc
 (ndc_upc_hri varchar(100),
 price_code varchar(50),
 price_effective_date varchar(50),
 unit_price varchar(100),
 extended_unit_price varchar(100),
 package_price varchar(100),
 awp_indicator_code varchar(40),
 transaction_code varchar(30),
 last_change_date varchar(100));

DROP TABLE IF EXISTS flipt_dw.dw_mf2rnm CASCADE;
create table flipt_dw.dw_mf2rnm
 (concept_type integer,
 country_code integer,
 concept_id varchar(100),
 id_for_generic_named_drug varchar(100),
 transaction_code varchar(50),
 medispan_reference_flag varchar(50),
 reserve varchar(100));

DROP TABLE IF EXISTS flipt_dw.dw_mf2rtdf CASCADE;
create table flipt_dw.dw_mf2rtdf
 (concept_type integer,
 country_code integer,
 concept_id varchar(100),
 transaction_code varchar(50),
 routed_drug_id varchar(100),
 dose_form_id integer,
 status integer,
 link_value varchar(100),
 link_date varchar(100),
 reserve varchar(200));

DROP TABLE IF EXISTS flipt_dw.dw_mf2rtdrg CASCADE;
create table flipt_dw.dw_mf2rtdrg
 (concept_type integer,
 country_code integer,
 concept_id varchar(100),
 transaction_code varchar(40),
 drug_name_id varchar(100),
 route_id varchar(150),
 status varchar(100),
 link_value varchar(100),
 link_date varchar(100),
 reserve varchar(200));

DROP TABLE IF EXISTS flipt_dw.dw_mf2rte CASCADE;
create table flipt_dw.dw_mf2rte
 (concept_type integer,
 country_code integer,
 concept_id varchar(100),
 transaction_code varchar(50),
 status integer,
 link_value varchar(100),
 link_date varchar(100),
 reserve varchar(110));

DROP TABLE IF EXISTS flipt_dw.dw_mf2sec CASCADE;
create table flipt_dw.dw_mf2sec
 (external_drug_id varchar(50),
 external_drug_id_type_code varchar(40),
 alternate_drug_id varchar(100),
 alternate_drug_id_fomat_code varchar(100),
 transaction_code varchar(50),
 reserve varchar(150));

DROP TABLE IF EXISTS flipt_dw.dw_mf2set CASCADE;
create table flipt_dw.dw_mf2set
 (concept_type integer,
 country_code integer,
 concept_id varchar(70),
 ingredient_set_id varchar(100),
 transaction_code varchar(40),
 representative_set_flag varchar(30),
 reserve varchar(75));

DROP TABLE IF EXISTS flipt_dw.dw_mf2str CASCADE;
create table flipt_dw.dw_mf2str
 (ingredient_id varchar(100),
 reserve_1 varchar(60),
 transaction_code varchar(50),
 ingredient_drug_id varchar(100),
 ingredient_strength_value varchar(100),
 ingredient_stength_uom_comb varchar(100),
 ingredient_strength_uom_indv varchar(101),
 volume_value varchar(130),
 volume_uom varchar(110),
 reserve varchar(126));

DROP TABLE IF EXISTS flipt_dw.dw_mf2stuom CASCADE;
create table flipt_dw.dw_mf2stuom
 (concept_type integer,
 country_code integer,
 concept_id varchar(100),
 transaction_code varchar(60),
 strength varchar(150),
 strength_unit_of_measure varchar(150),
 status integer,
 link_value varchar(100),
 link_date varchar(100),
 reserve varchar(190));

DROP TABLE IF EXISTS flipt_dw.dw_mf2sum CASCADE;
create table flipt_dw.dw_mf2sum
 (record_type varchar(100),
 reserve_1 varchar(50),
 sequence_number integer,
 reserve_2 varchar(100),
 comment_marker varchar(200),
 data_comment varchar(200));

DROP TABLE IF EXISTS flipt_dw.dw_mf2tcgpi CASCADE;
create table flipt_dw.dw_mf2tcgpi
 (tcgpi_id varchar(150),
 record_type varchar(100),
 tcgpi_name varchar(100),
 tc_level_code varchar(100),
 reserve varchar(100),
 transaction_code varchar(100),
 last_change_date varchar(100));

DROP TABLE IF EXISTS flipt_dw.dw_mf2val CASCADE;
create table flipt_dw.dw_mf2val
 (field_identifier varchar(100),
 field_value varchar(150),
 language_code integer,
 value_description varchar(100),
 value_abbreviation varchar(150),
 reserve varchar(200));

DROP TABLE IF EXISTS flipt_dw.dw_dosage CASCADE;
create table flipt_dw.dw_dosage
 (DOSAGEDESCRIPTION varchar(200),
 CODE varchar(200),
 ABBREVIATION varchar(200),
 C6 integer,
 COMMENTS varchar(max));