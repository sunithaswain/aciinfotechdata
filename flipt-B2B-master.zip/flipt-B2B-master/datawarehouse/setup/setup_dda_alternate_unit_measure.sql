DROP TABLE IF EXISTS flipt_dw.dda_alternate_unit_measure;
create table flipt_dw.dda_alternate_unit_measure
(
Alternate_Unit_of_Measure_ID BIGINT,
Transaction_Code VARCHAR(200),
Unit_of_Measure_ID BIGINT,
Alternate_Unit_of_Measure_Description  VARCHAR(200),
Reserve  VARCHAR(200),
create_date datetime default sysdate,
update_date DATE

);

