DROP TABLE IF EXISTS flipt_dw.dw_rewardtransaction;
create table flipt_dw.dw_rewardtransaction
 (create_date varchar(30),
created_by varchar(30),
domain varchar(20),
drug_name varchar(90),
flipt_person_id varchar(30),
id varchar(50),
prescription_id varchar(50),
redeemed varchar(20),
reward_amount varchar(30),
reward_date varchar(30),
type varchar(50),
update_date varchar(30),
updated_by varchar(50),
redemption_request_date varchar(30),
reward_option varchar(150),
redeem_extract_date varchar(30));