DROP TABLE IF EXISTS flipt_dw.dda_gpi_dose_text;
create table flipt_dw.dda_gpi_dose_text
(
Dose_ID BIGINT,
Text_Type_ID VARCHAR(200),
Level_Code VARCHAR(200),
Sequence_Number BIGINT,
Transaction_Code VARCHAR(200),
Text_ID BIGINT,
Reserve VARCHAR(200),
create_date datetime default sysdate,
Update_date DATE
);
