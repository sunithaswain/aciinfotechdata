DROP TABLE IF EXISTS flipt_dw.dw_mf2desc CASCADE;
create table flipt_dw.dw_mf2desc
 (concept_type integer,
 country_code integer,
 concept_id varchar(100),
 type_code integer,
 transaction_code varchar(100),
 description varchar(200),
 reserve varchar(200));