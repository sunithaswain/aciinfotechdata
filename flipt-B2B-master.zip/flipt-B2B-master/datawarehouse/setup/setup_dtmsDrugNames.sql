DROP TABLE IF EXISTS flipt_dw.dw_dtmsDrugNames;
create table flipt_dw.dw_dtmsDrugNames
 (drug_name varchar(200),
 kdc1 integer,
 kdc2 integer,
 created_date varchar(200),
 updated_date varchar(200),
 primary key(kdc1,kdc2));