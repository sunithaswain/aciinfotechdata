DROP TABLE IF EXISTS flipt_dw.dw_mf2gppc CASCADE;
create table flipt_dw.dw_mf2gppc
 (generic_product_pack_code varchar(50),
 package_size varchar(100),
 package_size_uom varchar(50),
 package_quantity varchar(50),
 unit_dose_unit_use_pkg_code varchar(50),
 package_description_code varchar(100),
 generic_product_identifier varchar(100),
 reserve varchar(100),
 transaction_code varchar(10),
 last_change_date varchar(100));