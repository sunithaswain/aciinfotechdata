DROP TABLE IF EXISTS flipt_dw.dw_dtmsDrugNameIndex;
create table flipt_dw.dw_dtmsDrugNameIndex
 (kdc1 integer,
 kdc2 integer,
 kdc3 integer,
 actcode integer,
 route varchar(200),
 needname integer,
 nametype varchar(200),
 name varchar(200),
 created_date varchar(200),
 updated_date varchar(200),
 primary key(name));