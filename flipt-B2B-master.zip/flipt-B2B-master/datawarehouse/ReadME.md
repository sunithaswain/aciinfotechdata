The purpose of the datawarehouse story is to be able to perform full load, incremental load and truncate/insert load  of 24 tables from couchbase to Redshift. For this we copy the data from couchbase to s3 and then from s3 to Redshift.

The folder structure is as given below:
-setup
--setup_final.sql
--setup_domain.sql
--setup_rewardtransaction.sql
--setup_prescription.sql
--runsql.py
-dataload
--cb2s3.py
--load.py
-jsonpaths
--jsonpaths_domain.json
--jsonpaths_rewardtransaction.json
--jsonpaths_prescription.json
-ReadME.md


Setup
-----------------------
This is the setup or creation of tables in Redshift.
All SQL statements to create all tables and individual tables in redshift have been written in setup_final.sql and setup_<tablename>.sql respectively.
The python script runsql.py open the file setup_<tablename>.sql, reads each sql statement and exceutes it. Hence the tables are created.
The python script runsql.py reads the commandline arguments and executes the corresponding sql file.
Usage: python runsql.py -t <tablename/all>
This is a one time effort. This will not be scheduled and would be run on demand only.

jsonpaths
---------------------------------
jsonpaths is the file, one for each table, that defines the route to access even the nested data in the couchbase document.
The order of columns in redshift and that of data heads in jsonpaths must be the same.
This would help to copy the s3 content in json format directly to redshift table using the copy command


dataload
--------------------------
cb2s3.py is the script that copies everything in couchbase to s3 using a n1ql query in json format depending on commandline arguments of tablename and loadtype-fullload or incremental.
load.py is the data load of <tablename/all> tables that will be done after setup. The script loads the data from s3 to redshift based on two arguments <tablename/all> and loadtype-fullload or incremental or truncate/insert(ti)
Usage: 
python cb2s3 -t <tablename/all> -l <loadtype>
python load.py -t <tablename/all> -l <loadtype>
jsonpaths will help in accessing nested data from json format to redshift table.
dw_load_date table is updated with each table load.

