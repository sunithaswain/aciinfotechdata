########################################
# !/usr/bin/env python  
# title         :populate_weekmedspan.py
# description   : load weekly medfile from medispan to redshift table
# author        : Pal
# date created  : 20191007
# date last modified    : 
# version       : 0.1
# maintainer    : 
# email         : -
# status        : Development
# Python Version: 3.5.X
# usage         : python populate_weekmedspan.py -t mf2All
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#                          
# #######################################


from zipfile import ZipFile 
import pandas as pd
import os, traceback, sys, re
import psycopg2
import getopt
import logging
import s3fs
import sendgrid
import boto3, io
from sendgrid.helpers.mail import *
from datetime import datetime

logging.basicConfig(level=logging.INFO)
LOG = logging.getLogger('get records from medispan and insert into tables in redshift')

def send_email(filename, subject='', content=''):
    sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))
    from_email = Email("noreply@fliptrx.com")
    to_email = Email("fliptintegration@fliptrx.com")
    if subject == '': subject = "ERROR:"+dbname+" :"+host+" :"+ filename+" load failed"
    if content == '': content = Content("text/plain", "ERROR:"+dbname+" :"+host+" :"+ filename+" load failed")
    mail = Mail(from_email, subject, to_email, content)
    response = sg.client.mail.send.post(request_body=mail.get())
    print(response.status_code)
    print(response.body)
    print(response.headers)


dbname = os.environ['RDS_DBNAME']
host = os.environ['RDS_SERVER']
prt = os.environ['RDS_PORT']
usr = os.environ['RDS_USERID']
passwd = os.environ['RDS_PWD']
table_prefix = os.environ['RDS_DBNAME_EXTN']
aws_s3_url = os.environ['S3_RDS_URL']
bkt = os.environ['S3_RDS_BUCKET']

aws_access_key=os.environ['S3_RDS_PUB_KEY_ID']
secret_access_key=os.environ['S3_RDS_PRIV_KEY_ID']
tablename = ''
print("dbname={} host={} port={} user={} password={}".format(dbname, host, prt, usr, passwd))
conn = psycopg2.connect("dbname={} host={} port={} user={} password={}".format(dbname, host, prt, usr, passwd))
cur = conn.cursor()
filenamepattern = 'MED-FILE2_0_0_WK_PDU-DELIMT_PRICING_D_'
loadedfilename = ''

path = os.path.join(os.environ['CB_DATA'], 'DRUG_DATABASE', 'MEDISPAN')


def truncate_table(tablename):
    try:
        com_trun = ("TRUNCATE {};".format(table_prefix+".dw_"+tablename))
        cur.execute(com_trun)
        conn.commit()
    except Exception as e: 
        LOG.info(traceback.format_exc())
        executionstatus='Failure'
        send_email(tablename)

def loaddata(tablename):
    try: 
        command_tb = ("copy {} from '{}'\
                    CREDENTIALS 'aws_access_key_id={};aws_secret_access_key={}' \
                     removequotes delimiter ',';"\
                    .format(table_prefix+".dw_"+tablename, aws_s3_url+'MSWEEK/'+tablename+".csv",aws_access_key,secret_access_key))
        
        print(command_tb)
        cur.execute(command_tb)
        conn.commit()
    except Exception as e:
        print(traceback.format_exc())
        executionstatus='Failure'
        send_email(tablename)


def fn_load_weekdatatocsv(zip_files, tablename):
    try:
        
        list_of_all_rows = []
        # MEDFV2\USAENG\DB\DELIMIT
        data=str(zip_files.read('MEDFV2/USAENG/DB/DELIMIT/'+tablename.upper()))[:-1].strip()
        for columns in data.split("\\n"):
            lst_row = []
            columns = columns.replace('b"', '')
            columns = columns.replace('b\'', '')
            if columns == '': continue
            for chunk in columns.split("|"):
                str_field_identifier=chunk
                lst_row.append(str_field_identifier)
            list_of_all_rows.append(lst_row)
            
        else:
            pass
        
        df_DDARTE=pd.DataFrame(list_of_all_rows)
        # print(df_DDARTE)
        
        s3 = s3fs.S3FileSystem(anon=False, key = aws_access_key, secret = secret_access_key)
        with s3.open(bkt+'/MSWEEK/'+tablename+'.csv','w') as f:
            df_DDARTE.to_csv(f, header=False, index =False, encoding ='utf-8')
        loaddata(tablename)
        
        LOG.info("======records inserted successfully")
    except Exception as e: 
        LOG.info(traceback.format_exc())
        executionstatus='Failure'
        return executionstatus


def fn_call_table(zip_files, tablename):
    try:
        LOG.info("======fn_call_table called here=======")
        if tablename == 'mf2dict':
            truncate_table(tablename)
            fn_load_weekdatatocsv(zip_files, tablename)
        elif tablename == 'mf2gppc':
            truncate_table(tablename)
            fn_load_weekdatatocsv(zip_files, tablename)
        elif tablename == 'mf2gpr':
            truncate_table(tablename)
            fn_load_weekdatatocsv(zip_files, tablename)
        elif tablename == 'mf2lab':
            truncate_table(tablename)
            fn_load_weekdatatocsv(zip_files, tablename)
        elif tablename == 'mf2mod':
            truncate_table(tablename)
            fn_load_weekdatatocsv(zip_files, tablename)
        elif tablename == 'mf2name':
            truncate_table(tablename)
            fn_load_weekdatatocsv(zip_files, tablename)
        elif tablename == 'mf2ndc':
            truncate_table(tablename)
            fn_load_weekdatatocsv(zip_files, tablename)
        elif tablename == 'mf2ndcm':
            truncate_table(tablename)
            fn_load_weekdatatocsv(zip_files, tablename)
        elif tablename == 'mf2prc':
            truncate_table(tablename)
            fn_load_weekdatatocsv(zip_files, tablename)
        elif tablename == 'mf2sec':
            truncate_table(tablename)
            fn_load_weekdatatocsv(zip_files, tablename)
        elif tablename == 'mf2sum':
            truncate_table(tablename)
            fn_load_weekdatatocsv(zip_files, tablename)
        elif tablename == 'mf2tcgpi':
            truncate_table(tablename)
            fn_load_weekdatatocsv(zip_files, tablename)
        elif tablename == 'mf2val':
            truncate_table(tablename)
            fn_load_weekdatatocsv(zip_files, tablename)
    except Exception as e: 
        LOG.info(traceback.format_exc())
        executionstatus='Failure'
        return executionstatus

def delete_file_from_medispan(pfile_name):
    # LOG.info("")
    import os
    import ftplib
    from contextlib import closing
    import traceback

    host = os.environ['MEDISPAN_FTP_HOST']
    port = int(os.environ['MEDISPAN_FTP_PORT'])
    login = os.environ['MEDISPAN_FTP_USER']
    passwd = os.environ['MEDISPAN_FTP_PWD']
    try:
        LOG.info("======delete_file_from_medispan called here====")
        S3_path = bkt+'/MSWEEK/'
        with closing(ftplib.FTP()) as ftp:
            try:
                ftp.connect(host, port, 30*5) #5 mins timeout
                ftp.login(login, passwd)
                ftp.set_pasv(True)
                file_path = 'Medispan/'+login+'/'+pfile_name
                ftp.delete(file_path)
                print("%s is deleted successfully."%file_path)
            except Exception as e:
                print(traceback.format_exc())
                LOG.info(traceback.format_exc())
        LOG.info("======delete_file_from_medispan completed successfully====")
    except Exception as e:
        print(traceback.format_exc())
        LOG.info(traceback.format_exc())

def copy_from_medispan_to_S3():
    
    import os
    import ftplib
    from contextlib import closing
    import traceback
    import glob
    import zipfile

    host = os.environ['MEDISPAN_FTP_HOST']
    port = int(os.environ['MEDISPAN_FTP_PORT'])
    login = os.environ['MEDISPAN_FTP_USER']
    passwd = os.environ['MEDISPAN_FTP_PWD']
    try:
        LOG.info("======copy_from_medispan_to_S3 called here====")
        S3_path = bkt+'/MSWEEK/'
        with closing(ftplib.FTP()) as ftp:
            try:
                ftp.connect(host, port, 30*5) #5 mins timeout
                ftp.login(login, passwd)
                ftp.set_pasv(True)
                inner_path = 'Medispan/'+login
                ftp.cwd(inner_path)
                
                dir_list = []
                ftp.dir(dir_list.append)
                # print(dir_list)
                
                rdir_list = [i for i in dir_list if filenamepattern in str(i).upper()]
                
                rdir_list.sort(reverse=True)
                subfile_name = rdir_list[0]
                
                
                for line in rdir_list:
                    orig_filename = line[29:].strip().split(' ')[-1]
                    # print(orig_filename)
                    if re.match('^'+filenamepattern,  str(orig_filename).upper()):
                        print(orig_filename)
                        loadedfilename = orig_filename
                        s3 = s3fs.S3FileSystem(anon=False, key = aws_access_key, secret = secret_access_key)

                        with s3.open(S3_path+orig_filename,'wb') as f:
                            res = ftp.retrbinary('RETR %s' % orig_filename, f.write)

                            if not res.startswith('226 Transfer complete'):
                                print('Downloaded of file {0} is not compile.'.format(orig_filename))
                                # os.remove(orig_filename)
                        break
            except Exception as e:
                print(traceback.format_exc())
                LOG.info(traceback.format_exc())
        LOG.info("======copy_from_medispan_to_S3 end here====")
    except Exception as e: 
        LOG.info(traceback.format_exc())
        executionstatus='Failure'
        return executionstatus
        
def main():
    global LOG
    tablename = None
    print("main called")
    try:
        opts, args = getopt.getopt(sys.argv[1:], "-t:")
    except getopt.GetoptError:
        print('filetype.py -t <tablename>')
        LOG.info("filetype.py -t <tablename>")
        sys.exit(2)
		
    for opt, arg in opts:
        if opt in ("-t"):
            tablename = arg
	
    copy_from_medispan_to_S3()
    
    #fformat = logging.Formatter('%(tablename)s:%(levelname)s:%(message)s')
    logpath = os.environ['CB_DATA']+'//datawarehouse//log//log'+tablename+datetime.now().strftime("%Y%m%d%H%M") +'.txt'
    handler = logging.FileHandler(logpath)
    #handler.setFormatter(fformat)
    LOG.addHandler(handler)

    LOG.info("=========================================================")
    LOG.info("=============== Setup-Drop and create redshift tables ==============")
    file_name = ''
    
    try:
        doctype = ["mf2dict","mf2gppc","mf2gpr","mf2lab","mf2mod","mf2name","mf2ndc","mf2ndcm","mf2prc","mf2sec","mf2sum","mf2tcgpi","mf2val"]	
        
        list_of_all_rows = []
            
        session = boto3.session.Session(
            aws_access_key_id=aws_access_key, 
            aws_secret_access_key=secret_access_key
        )

        s3 = session.resource("s3")
        bucket = s3.Bucket(bkt)

        files_in_s3 = bucket.objects.all() 
        print(files_in_s3)
        # return None
        
        for i in list(files_in_s3):
            print(i)
            
            if re.match('^MSWEEK\/MF2',  str(i.key).upper()) and re.findall('CSV$',  str(i.key).upper()):
                print("inner")
                i.delete()
            
            if re.match('^MSWEEK\/'+loadedfilename.upper(),  str(i.key).upper()):
                # print(i.key)
                obj = bucket.Object(i.key)

                with io.BytesIO(obj.get()["Body"].read()) as tf:

                    # rewind the file
                    tf.seek(0)

                    # Read the file as a zipfile and process the members
                    with ZipFile(tf, mode='r') as zip_files: 
                        #     zip_files.printdir()
                        print("zip file is opened")
                        try: 
                            
                            if tablename == 'mf2All':
                                print("All weekly tables")
                                LOG.info("All weekly tables")
                                for tablename in doctype:
                                    
                                    truncate_table(tablename)
                                    fn_call_table(zip_files, tablename)
                                
                            elif tablename not in doctype:
                                LOG.info("=============== the given table name is incorrect ==============")
                                executionstatus = "Failure"
                                send_email(tablename)
                            elif tablename in doctype:
                                truncate_table(tablename)
                                fn_call_table(zip_files, tablename)
                                
                        except Exception as e:            
                            LOG.info(traceback.format_exc())
                            executionstatus = "Failure"
                            send_email(tablename) 
                        
                        print('Extracting the files now...')
                        print('Done!')
                # copy stuff to your destination here
                copy_source = {
                    'Bucket': bkt,
                    'Key': i.key
                }
                # return None
                file_name = (i.key).split('/')[-1]
                destination_file_path = 'MSWEEK/Archive/'+(i.key).split('/')[-1]
                print(destination_file_path)
                s3.meta.client.copy(copy_source, bkt, destination_file_path)
                # then delete the source key
                # i.delete()
                for i in list(files_in_s3):
                    # delete all files other than archive folder inside DDA( Handle belo line carefully)
                    if re.match('MSWEEK\/',  i.key) and not re.match('MSWEEK\/Archive/',  i.key):
                        print(i.key)
                        i.delete()
                        # pass
                
                if file_name != '':
                    pass
                    # delete_file_from_medispan(file_name)
                
                f_name = 'populate_weekmedspan'
                success_subject = 'Success: Load records from medispan to redshift'
                success_content = Content("text/plain",'Success: Load records from medispan to redshift process completed successfully')
                send_email(f_name, success_subject, success_content) 
               
        else:
            f_name = 'populate_weekmedspan'
            success_subject = 'Failed: No records in medispan'
            success_content = Content("text/plain",'Failed: Input file is not found in medspan ftp location')
            send_email(f_name, success_subject, success_content) 
    
    except Exception as e:            
        LOG.info(traceback.format_exc())
        executionstatus = "Failure"
        send_email(tablename) 

if __name__ == '__main__':
    sys.exit(main())