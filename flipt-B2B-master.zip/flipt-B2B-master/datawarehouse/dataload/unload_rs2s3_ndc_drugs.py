############################################################
#author: Smit Kabrawala
#desc: Unloads the data from Redshift to Amazon S3 bucket.
############################################################
import boto3
import os
import psycopg2
from datetime import datetime

hostname = os.environ['INSTANCE_TYPE'].lower()
schema_name = os.environ['RDS_DBNAME_EXTN']
dbname = os.environ['RDS_DBNAME']
port = os.environ['RDS_PORT']
user = os.environ['RDS_USERID']
password = os.environ['RDS_PWD']
host_url = os.environ['RDS_SERVER']
s3_bucket_name = os.environ['AMAZON_SFTP_BUCKET']
aws_access_key_id = os.environ['AWS_ACCESS_KEY_ID']
aws_secret_access_key = os.environ['AWS_SECRET_ACCESS_KEY']
table = 'dw_ndc_drugs_v'

def main():
    date_time = datetime.now()
    filename = 'FLIPT_DRUG_NDC_' + date_time.strftime("%d%b%Y")

    '''This method will unload redshift table into S3'''
    conn_string = "dbname='{}' port='{}' user='{}' password='{}' host='{}'"\
        .format(dbname,port,user,password,host_url)  

    sql="""UNLOAD ('select * from %s.%s') TO 's3://%s/dataload_%s/uploads/%s.csv' \
        credentials 'aws_access_key_id=%s;aws_secret_access_key=%s' \
        HEADER \
        ALLOWOVERWRITE \
        PARALLEL FALSE \
        CSV;""" \
        % (schema_name,table,s3_bucket_name,hostname,filename,aws_access_key_id,aws_secret_access_key)

    con = psycopg2.connect(conn_string)
    cur = con.cursor()
    cur.execute(sql)

if __name__ == "__main__":
    main()