import base64
import json
import logging
import os
from datetime import datetime
from optparse import OptionParser

import pandas as pd
import psycopg2
import requests
from requests.auth import HTTPBasicAuth
from aetna.dynamic_sftp import sftptransfer


path = os.environ['CB_DATA']
log_path = path + '/log'

now_dt_obj = datetime.now()
now = now_dt_obj.strftime("%d-%m-%Y-%H:%M:%S")



TRUEVAULT_API_KEY = os.environ['TV_API_KEY']
TV_URI = os.environ['TV_URI']


def search_user(flipt_member_id):
    """
    :return: This functions takes the above params as input and creates a curl command and post
              request to true-vault with base64encoding.
    """
    search_option = {
        'full_document': True,
        'filter': {
            'flipt_person_id': {'type': 'eq', 'value': flipt_member_id,
                                'case_sensitive': False},
            '$tv.status': {'type': 'eq', 'value': 'ACTIVATED'}}, 'filter_type': 'and'}

    # print(search_option)
    search_opt = base64.b64encode(str.encode(json.dumps(search_option)))
    search_json = {'search_option': search_opt}
    res = requests.post(TV_URI, auth=HTTPBasicAuth(TRUEVAULT_API_KEY, ''),
                        data=search_json)
    response = res.json()
    if 'error' in response:
        err_msg = str(response['error'])
        return

    if (res.status_code != 200 or 'data' not in response or
            (res.status_code == 200 and not response['data'].get('documents'))):
        return

    att = json.loads(base64.b64decode(response['data']['documents'][0]['attributes']).
                     decode('utf-8'))

    return att


def get_member_details(details, person_code):
    if person_code != '01':
        for dependent_details in details['dependents']:
            if dependent_details['person_code'] == person_code:
                details = dependent_details
                break

    return {'member_dob': details.get('date_of_birth', 'missing DOB'),
            'member_first_name': details.get('first_name', 'Misssing First name'),
            'member_last_name': details.get('last_name', 'Missing last name'),
            'member_gender': details.get('gender', 'Missing gender')}


def rd_conn():
    dbname = os.environ['RDS_DBNAME']
    logger.info(f"Establishing connection with redshift in env {dbname}")
    user = os.environ['RDS_USERID']
    password = os.environ['RDS_PWD']
    host = os.environ['RDS_SERVER']
    port = os.environ['RDS_PORT']
    conn_string = f"dbname='{dbname}' port={port} user='{user}' password='{password}' host='{host}'"
    return psycopg2.connect(conn_string)


# vales in dict are headers

def main(domain, from_date, to_date):
    table_name = "flipt_dw.dw_processedclaims"

    col_map = {"account": "rx_domain",
               "authorization_code": "auth_id",
               "carrier": "carrier",
               "claim_number": "auth_id",
               "claim_status": "claim_status",
               "client_coinsurance": "client_coinsurance",
               "client_copay": "client_copay",
               "client_deductible": "client_deductible",
               "client_disp_fee": "client_disp_fee",
               "client_ing_cost": "client_ing_cost",
               "client_paid_amt": "client_paid_amt",
               "client_sales_tax": "client_sales_tax",
               "cob_ind": "cob_ind",
               "compound_ind": "compound_ind",
               "daw": "daw_code",
               "days_supply": "days_supply",
               "dispensing_fee_paid": "client_disp_fee",
               "drug_name": "drug_name",
               "drug_strength": "drug_strength",
               "fill_date": "fill_date",
               "formulary_ind": "formulary_ind",
               "generic_brand_ind": "generic_brand_ind",
               "gpi": "gpi_code",
               "group": "group",
               "ing_cost_paid": "client_ing_cost",
               "manufacturer": "manuf_abr",
               "member_id": "member_id",
               "member_reimbursement": "member_reimbursement",
               "member_relationship": "member_relationship",
               "ndc": "product_id_ndc",
               "pack_size": "pack_size",
               "patient_paid": "patient_paid",
               "person_code": "member_relationship",
               "pharmacy_chain": "pharmacy_chain",
               "pharmacy_name": "pharmacy_name",
               "pharmacy_npi": "pharmacy_npi",
               "prescriber_dea": "prescriber_dea",
               "prescriber_first_name": "prescriber_first_name",
               "prescriber_last_name": "prescriber_last_name",
               "prescriber_npi": "prescriber_npi",
               "prescriber_submitted_id": "prescriber_submitted_id",
               "price_source": "price_source",
               "quantity_dispensed": "quantity_dispensed",
               "refill_ind": "refill_ind",
               "rx_number": "rx_number",
               "submitted_amt": "submitted_total_amount",
               "submitted_date": "submitted_date",
               "submitted_ing_cost": "submitted_ing_cost",
               "submitted_time": "submitted_time",
               "submitted_usual_and_customary_amy": "submitted_usual_and_customary_ams",
               "submittied_dispensing_fee": "submitted_dispensing_fee",
               "written_date": "written_date",
               "total_amount_paid": "total_amount_paid",
               "rewards": "total_reward"}

    query_cols = ','.join(list(col_map.values()))
    logger.info("Prepared the select columns for query")

    query = (f"select {query_cols} from {table_name} where startdate<='{to_date}' and startdate>='{from_date}' and "
             f"claim_status in ('P', 'X')")
    query = query.replace('group', '\"group\"')
    query = f"{query} and rx_domain='{domain}'" if domain else query
    con = rd_conn()
    cur = con.cursor()
    logger.info(
        f"Select query for extracting claims form dw_claims table: {query}")
    cur.execute(query)
    table_rows = cur.fetchall()
    cached_flipt_members = {}
    res_list = []
    for row in table_rows:
        cur_map = {}
        for col_name, col_val in zip(col_map.keys(), row):
            from decimal import Decimal
            if isinstance(col_val, Decimal):
                col_val = str(col_val)
            cur_map[col_name] = col_val
        member_id = cur_map['member_id'][:-2]
        person_code = cur_map['member_id'][-2:]
        if member_id not in cached_flipt_members:
            cached_flipt_members[member_id] = search_user(member_id)
        if cached_flipt_members[member_id]:
            try:
                member_details = get_member_details(
                    cached_flipt_members[member_id], person_code)
            except Exception as e:

                raise
            cur_map.update(member_details)
        res_list.append(cur_map)
    logger.info("Writing the data to a file")
    if not domain:
        domain = 'ALL'
    filename = os.path.join(path, f'Claims_Report_{domain}_{now_dt_obj.strftime("%Y%m%d")}.csv')
    # with open(f"{filename}.json", 'w') as f:
    #     json.dump(res_list, f, indent=4)
    df = pd.DataFrame(res_list)
    df.to_csv(f'{filename}', index=False)
    if domain != 'ALL':
        upload_file(filename, domain)


def upload_file(file_name, domain):
    DEFAULT_SFTP_PORT = '22'
    destination = f'/l_download/{os.path.basename(file_name)}'
    if domain.upper() == 'ACS001' and run_type.upper() == 'DAILY':
        destination = f'/l_download/accumulator/{os.path.basename(file_name)}'
    if domain.upper() == 'ACS001' and run_type.upper() == 'WEEKLY':
        destination = f'/l_download/invoice/{os.path.basename(file_name)}'
    status = sftptransfer(source=file_name,
                          destination=f'/l_download/{os.path.basename(file_name.json)}',
                          mode='PUT',
                          ftphost=os.environ[f'SFTP_CLAIMS_HOST_{domain}'],
                          ftpuser=os.environ[f'SFTP_CLAIMS_USER_{domain}'],
                          ftppwd=os.environ[f'SFTP_CLAIMS_PASSWORD_{domain}'],
                          port=DEFAULT_SFTP_PORT)
    if status != 'S':
        print(f"Upload failed for {file_name}")
    return True
def get_from_to_dates(domain, run_type):
    from_date, to_date = '', ''
    if domain.upper() == 'ACS001':
        if run_type.upper() == 'DAILY':
            from_date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%dT00:00:00:000000')
            to_date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%dT23:59:59:999999')
        elif run_type.upper() == 'WEEKLY':
            from_date = (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%dT00:00:00:000000')
            to_date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%dT23:59:59:999999')
    return from_date, to_date

if __name__ == '__main__':
    parser = OptionParser()
    parser.add_option("-d", "--domain", dest="domain",
                      help="pass in domain (company)")
    parser.add_option("-f", "--from_date", dest="from_date",
                      help="from date(yyyymmdd)")
    parser.add_option("-t", "--to_date", dest="to_date",
                      help="to date(yyyymmdd)")
    options, args = parser.parse_args()
    if options.domain:
        options.domain = options.domain.upper()
    if options.from_date == options.to_date == None:
        options.from_date, options.to_date = get_from_to_dates(options.domain, options.run_type)
    # add new logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    fh = logging.FileHandler(f'{path}/ETL/log/claims_report_log_{options.domain}-{now}.log')
    fh.setLevel(logging.DEBUG)

    formatter = logging.Formatter('%(name)s - %(asctime)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)

    logger.addHandler(fh)
    logger.info(f"Received input from the user for domain: {options.domain}, from_date:{options.from_date}, to_date{options.to_date}")
    main(options.domain, options.from_date, options.to_date, options.run_type)


