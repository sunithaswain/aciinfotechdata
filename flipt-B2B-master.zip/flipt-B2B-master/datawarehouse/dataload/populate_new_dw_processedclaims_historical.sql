delete from flipt_dw.dw_prescription
where auth_id like '%a%';
delete from flipt_dw.dw_scdailyclaim_summary where awp_unit like '%S%';
drop table if exists flipt_dw.tmp1
;
CREATE table flipt_dw.tmp1 AS
SELECT * 
FROM flipt_dw.dw_scdailyclaim_summary a
WHERE sequence_number = (SELECT distinct MAX(sequence_number) FROM flipt_dw.dw_scdailyclaim_summary WHERE a.auth_id = auth_id)
;
UPDATE flipt_dw.dw_processedclaims 
SET rx_awp_unit_price = convert(numeric(18,2),t2.awp_unit), 
claim_override_flag = t2.claim_override_flag,
member_id = t2.member_id,
network_id = t2.network_id,
quantity_dispensed = convert(numeric(18,2),t2.quantity_dispensed),
claim_date = cast(t2.claim_date as timestamp),
auth_id = t2.auth_id,
rx_number = t2.rx_number,
account = t2.account,
amt_paid_to_pharmacy = t2.amt_paid_to_pharmacy,
awp_unit = t2.awp_unit,
bin = t2.bin,
pcn = t2.pcn,
"group" = t2.group,
carrier = t2.carrier,
claim_type = t2.claim_type,
client_disp_fee = t2.client_disp_fee,
client_due_amt = t2.client_due_amt,
client_ing_cost = t2.client_ing_cost,
client_mac_price = t2.client_mac_price,
date_of_service = CAST(t2.date_of_service as timestamp),
days_supply = t2.days_supply,
disp_fee_paid = t2.disp_fee_paid,
fill_number = t2.fill_number,
formulary_status = t2.formulary_status,
gpi_code = t2.gpi_code,
ing_cost_paid = t2.ing_cost_paid,
manuf_abr = t2.manuf_abr,
message = t2.message,
multisource_code = t2.multisource_code,
otc_indicator = t2.otc_indicator,
patient_paid = t2.patient_paid,
person_code = t2.person_code,
pharmacy_mac_price = t2.pharmacy_mac_price,
pharmacy_name = t2.pharmacy_name,
pharmacy_ncpdp = t2.pharmacy_ncpdp,
pharmacy_npi = t2.pharmacy_npi,
prescriber_first_name = t2.prescriber_first_name,
prescriber_last_name = t2.prescriber_last_name,
prescriber_npi = t2.prescriber_npi,
product_id_ndc = t2.product_id_ndc,
product_name_full = t2.product_name_full,
rel_code = t2.rel_code,
sales_tax_paid = t2.sales_tax_paid,
status = t2.status,
submitted_disp_fee = t2.submitted_disp_fee,
submitted_gross_due = t2.submitted_gross_due,
submitted_ing_cost = t2.submitted_ing_cost,
submitted_sales_tax = t2.submitted_sales_tax,
submitted_uc = t2.submitted_uc,
create_date = t2.create_date 
FROM flipt_dw.tmp1 t2, flipt_dw.dw_processedclaims t1  
WHERE t1.auth_id = t2.auth_id and t2.claim_type = 'P'
;
DELETE FROM flipt_dw.tmp1 
WHERE flipt_dw.tmp1.auth_id IN (SELECT t1.auth_id FROM flipt_dw.dw_processedclaims t1)
;
insert into flipt_dw.dw_processedclaims (rx_awp_unit_price,
claim_override_flag,member_id, 
network_id, 
quantity_dispensed,
claim_date,
auth_id,
rx_number,
account,
amt_paid_to_pharmacy,
awp_unit,
bin,
pcn,
"group",
carrier,
claim_type,
client_disp_fee,
client_due_amt,
client_ing_cost,
client_mac_price,
date_of_service,
days_supply,
disp_fee_paid,
fill_number,
formulary_status,
gpi_code,
ing_cost_paid,
manuf_abr,
message,
multisource_code,
otc_indicator,
patient_paid,
person_code,
pharmacy_mac_price,
pharmacy_name,
pharmacy_ncpdp,
pharmacy_npi,
prescriber_first_name,
prescriber_last_name,
prescriber_npi,
product_id_ndc,
product_name_full,
rel_code,
sales_tax_paid,
status,
submitted_disp_fee,
submitted_gross_due,
submitted_ing_cost,
submitted_sales_tax,
submitted_uc,
create_date) 
SELECT convert(numeric(18,2),t2.awp_unit), 
t2.claim_override_flag,t2.member_id,
t2.network_id,
convert(numeric(18,2),t2.quantity_dispensed),
cast(t2.claim_date as timestamp),
t2.auth_id,
t2.rx_number,
t2.account,
t2.amt_paid_to_pharmacy,
t2.awp_unit,
t2.bin,
t2.pcn,
t2.group,
t2.carrier,
t2.claim_type,
t2.client_disp_fee,
t2.client_due_amt,
t2.client_ing_cost,
t2.client_mac_price,
CAST(t2.date_of_service as timestamp),
t2.days_supply,
t2.disp_fee_paid,
t2.fill_number,
t2.formulary_status,
t2.gpi_code,
t2.ing_cost_paid,
t2.manuf_abr,
t2.message,
t2.multisource_code,
t2.otc_indicator,
t2.patient_paid,
t2.person_code,
t2.pharmacy_mac_price,
t2.pharmacy_name,
t2.pharmacy_ncpdp,
t2.pharmacy_npi,
t2.prescriber_first_name,
t2.prescriber_last_name,
t2.prescriber_npi,
t2.product_id_ndc,
t2.product_name_full,
t2.rel_code,
t2.sales_tax_paid,
t2.status,
t2.submitted_disp_fee,
t2.submitted_gross_due,
t2.submitted_ing_cost,
t2.submitted_sales_tax,
t2.submitted_uc,
t2.create_date
FROM flipt_dw.tmp1 t2
where t2.claim_type = 'P'
;                    
update flipt_dw.dw_processedclaims 
set update_date = GETDATE(),
rx_alternate_drug_reward = t1.alternative_drug_rewards,
rx_penalty = t1.drug_penalty,
rx_domain = t1.domain,
rx_flipt_person_ID = CAST(t1.rx_flipt_person_id as int),
rx_prescription_id = t1.prescription_id,
rx_pa_flag = t1.pa_flag,
rx_employee_opc = t1.employee_opc,
rx_drug_cost = t1.drug_cost,
rx_employer_cost = t1.employer_cost,
rx_unit_price = t1.unit_price,
rx_unit_price_before_rebate = t1.unit_Price_before_rebate,
rx_rewards = t1.rewards,
rx_quantity = convert(numeric(18,2),t1.quantity),
rx_rebate_factor = t1.rebate_factor,
rx_rebate_amount = t1.rebate_amount,
rx_status = t1.rx_status 
FROM flipt_dw.dw_prescription t1, flipt_dw.dw_processedclaims t2  
WHERE cast(t1.auth_id as int) = t2.auth_id
;
update flipt_dw.dw_processedclaims 
set claimsource = 'ScriptClaim'
;
update flipt_dw.dw_processedclaims
set claim_reconciled_flag = case
when rx_status = 'Filled' and claim_type = 'P' then 'Y'
ELSE 'IT Issue' 
END
;
update flipt_dw.dw_processedclaims
set claim_reconciled_flag ='Pricing Issue'
where multisource_code = 'N' and rx_unit_price != CONVERT(numeric(18,2),awp_unit)
;
update flipt_dw.dw_processedclaims
set claim_reconciled_flag ='Pricing Issue'
where multisource_code != 'N' and rx_unit_price != client_mac_price
;
update flipt_dw.dw_processedclaims
set claim_reconciled_flag ='Pricing Issue'
where patient_paid != CONVERT(numeric(18,2),rx_employee_opc)
;
update flipt_dw.dw_processedclaims
set claim_reconciled_flag ='Pricing Issue'
where client_due_amt !=rx_employer_cost
;
UPDATE flipt_dw.dw_processedclaims
SET compound_drug_flag  = CASE 
        WHEN product_id_ndc='00000000000' THEN 'Y' 
        ELSE 'N' 
      END;
update flipt_dw.dw_processedclaims 
set load_date = GETDATE();