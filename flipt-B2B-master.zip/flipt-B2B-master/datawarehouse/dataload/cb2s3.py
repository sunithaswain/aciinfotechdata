########################################
# !/usr/bin/env python  
# title         :cb2s3.py
# description   : Reading the command line arguments and copying data from couchbase to s3 based on the load argument-fullload or incremental
# author        : Soujanya Veerubhotla
# date created  : 20190425
# date last modified    : 
# version       : 0.1
# maintainer    : 
# email         : sveerubhotla@fliptrx.com
# status        : Development
# Python Version: 3.5.X
# usage         : python cb2s3.py -t <table_name> -l <loadtype>
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#                          
# #######################################


import pandas as pd
import os
import sys
import logging
import boto3
import json
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.n1ql import N1QLQuery

import getopt
import dateutil.parser
from datetime import datetime
import sendgrid
import os
from sendgrid.helpers.mail import *

import psycopg2

logging.basicConfig(level=logging.INFO)
LOG = logging.getLogger('Reading the command line arguments and copying data from couchbase to s3 based on the load argument-fullload or incremental')


aws_access_key=os.environ['S3_RDS_PUB_KEY_ID']
secret_access_key=os.environ['S3_RDS_PRIV_KEY_ID']
Reg = os.environ['S3_REGION']
bkt = os.environ['S3_RDS_BUCKET']
s3 = boto3.client('s3',aws_access_key_id =aws_access_key ,aws_secret_access_key=secret_access_key, region_name=Reg)
#print(aws_access_key,secret_access_key) 
doctype = ["domain", "rewardtransaction", "prescription", "cp_pharmacy", "rxplan_master", "deductible","rx_claim_history", "rx_history", "drug", "notification_log", "user_feedback"]

def send_email(filename):
    sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))
    from_email = Email("noreply@fliptrx.com")
    to_email = Email("fliptintegration@fliptrx.com")
    subject = "ERROR: Couchbase to s3 uplaod for :"+ filename+" failed"
    content = Content("text/plain", "ERROR: Couchbase to s3 uplaod for :"+ filename+" failed")
    mail = Mail(from_email, subject, to_email, content)
    response = sg.client.mail.send.post(request_body=mail.get())
    print(response.status_code)
    print(response.body)
    print(response.headers)
    
    
dbname = os.environ['RDS_DBNAME']
host = os.environ['RDS_SERVER']
prt = os.environ['RDS_PORT']
usr = os.environ['RDS_USERID']
passwd = os.environ['RDS_PWD']
table_prefix = os.environ['RDS_DBNAME_EXTN']
aws_s3_url = os.environ['S3_RDS_URL']
aws_access_key=os.environ['S3_RDS_PUB_KEY_ID']
secret_access_key=os.environ['S3_RDS_PRIV_KEY_ID']
conn = psycopg2.connect("dbname={} host={} port={} user={} password={}".format(dbname, host, prt, usr, passwd))
cur = conn.cursor()

def get_date(tablename):
    cmd_getdate = ("select CASE WHEN max(update_date) IS NULL THEN max(load_date) else max(update_date) END from {} where table_name = '{}';".format(table_prefix+".dw_load_date", "dw_"+tablename))
    cur.execute(cmd_getdate)
    gtdt1 = cur.fetchone()[0]
    print("gtdt1=", gtdt1)
    print("gtdt1 in isoformat=", gtdt1.isoformat())
    return gtdt1.isoformat()   
	
    
    
class DataExtraction(object):	
    def __init__(self):
        self.cluster = Cluster(os.environ['CB_URL'])
        self.authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
        self.cluster.authenticate(self.authenticator)
        self.cb = self.cluster.open_bucket(os.environ['CB_INSTANCE'])
        self.path = os.environ['CB_DATA']
        
		
    def _extractdoc(self, tablename, loadtype):
        
        
        if loadtype == "fullload":
            query= N1QLQuery('Select * from `'+os.environ['CB_INSTANCE']+'` where type=$typ ', typ=tablename)
            query.timeout = 3600   
        elif loadtype == "incremental":
            getdate = get_date(tablename)
            #query= N1QLQuery('Select * from `'+os.environ['CB_INSTANCE']+'` where type=$typ and update_date>DATE_ADD_STR(NOW_STR(), -30, "day");', typ=tablename)
            query= N1QLQuery('Select * from `'+os.environ['CB_INSTANCE']+'` where type=$typ and update_date>$gtdt;', typ=tablename, gtdt = getdate)
            query.timeout = 3600

        # print("getdate=", getdate)

        json_file = f"/tmp/dw_{tablename}.json"
        json_outfile = open(json_file, 'w')
        records = []
        for rec in self.cb.n1ql_query(query):
            #print(rec)
            records.append(json.dumps(rec))
            #print("Writing for record", rec)
        # end loop

        json_outfile.write(''.join(records))
        json_outfile.close()
        print("Finished writing to file")
        
        s3.upload_file(json_file, bkt, "dw_" + tablename + ".json")
        print("Finished uploading to s3")
        os.remove(json_file)
    # end function
          

    def extractdocall(self, lst):
        try:
            for elt in lst:
                query= N1QLQuery('Select * from `'+os.environ['CB_INSTANCE']+'` where type=$typ ', typ=elt)
                query.timeout = 3600   
                t= open("dw_"+elt+".json", 'w')
                for rec in self.cb.n1ql_query(query):
                    #print(rec)
                    t.write(json.dumps(rec))
                t.close()
			
                s3.upload_file("dw_"+elt+".json",bkt,"dw_"+elt+".json")
                os.remove("dw_"+elt+".json")
        except:
            executionstatus = "Failure"
            tnm = "all"
            send_email(tnm)
          

		
obj = DataExtraction()

def main():
    global LOG
    tablename = None
	
    try:
        opts, args = getopt.getopt(sys.argv[1:], "t:l:")
    except getopt.GetoptError:
        print('filetype.py -t <tablename> -l <loadtype>')
        LOG.info("filetype.py -t <tablename> -l <loadtype>")
        sys.exit(2)
		
    for opt, arg in opts:
        if opt in ("-t"):
            tablename = arg
        if opt in ("-l"):
            loadtype = arg
	
    #fformat = logging.Formatter('%(tablename)s:%(levelname)s:%(message)s')
    logpath = os.environ['CB_DATA']+'//datawarehouse//log//log'+tablename+datetime.now().strftime("%Y%m%d%H%M") +'.txt'
    handler = logging.FileHandler(logpath)
    #handler.setFormatter(fformat)
    LOG.addHandler(handler)

    LOG.info("=========================================================")
    LOG.info("=============== Reading the command line arguments and copying data from couchbase to s3 based on the load argument-fullload or incremental' ==============")

    if tablename!="all":
        obj._extractdoc(tablename, loadtype)
    elif tablename =="all":
        loadtype = "fullload"
        print(loadtype)
        obj.extractdocall(doctype)
    
	
    LOG.info("=========================================================")
	
if __name__ == '__main__':
    sys.exit(main())	
