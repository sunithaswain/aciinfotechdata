import os
import sys
import logging
import psycopg2
import getopt
import dateutil.parser
from datetime import datetime
import sendgrid
import os
from sendgrid.helpers.mail import *

def send_email(filename):
	sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))
	from_email = Email("noreply@fliptrx.com")
	to_email = Email("fliptintegration@fliptrx.com")
	subject = "ERROR:"+dbname+" :"+host+" :"+ filename+" load failed"
	content = Content("text/plain", "ERROR:"+dbname+" :"+host+" :"+ filename+" load failed")
	mail = Mail(from_email, subject, to_email, content)
	response = sg.client.mail.send.post(request_body=mail.get())
	print(response.status_code)
	print(response.body)
	print(response.headers)



dbname = os.environ['RDS_DBNAME']
host = os.environ['RDS_SERVER']
prt = os.environ['RDS_PORT']
usr = os.environ['RDS_USERID']
passwd = os.environ['RDS_PWD']
table_prefix = os.environ['RDS_DBNAME_EXTN']
aws_s3_url = os.environ['S3_RDS_URL']
#aws_s3_url = "s3://flipt-dwdev/"
aws_access_key=os.environ['S3_RDS_PUB_KEY_ID']
secret_access_key=os.environ['S3_RDS_PRIV_KEY_ID']


conn = psycopg2.connect("dbname={} host={} port={} user={} password={}".format(dbname, host, prt, usr, passwd))
cur = conn.cursor()

try:
    command_tbl = ("COPY {} FROM '{}' \
                    CREDENTIALS 'aws_access_key_id={};aws_secret_access_key={}' \
                    CSV DELIMITER ',' ACCEPTINVCHARS ACCEPTANYDATE;"\
                    .format("flipt_dw.dw_scdailyclaim_summary", aws_s3_url+"claimdf.csv", aws_access_key,secret_access_key))
    print(command_tbl)

    cur.execute(command_tbl)
    conn.commit()
except:
    executionstatus = 'Failure'
    send_email("s3 to redshift-populate scriptclaimsummary")