########################################
# !/usr/bin/env python  
# title         :load.py
# description   : Reading the command line arguments and copying data from s3 to redshift based on the load argument-fullload or incremental/truncateinsert and table name
# author        : Soujanya Veerubhotla
# date created  : 20190425
# date last modified    : 
# version       : 0.1
# maintainer    : 
# email         : sveerubhotla@fliptrx.com
# status        : Development
# Python Version: 3.5.X
# usage         : python load.py -t <table_name> -l <loadtype>
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#                          
# #######################################

import os
import sys
import logging
import psycopg2
import getopt
import dateutil.parser
from datetime import datetime
import sendgrid
import os
from sendgrid.helpers.mail import *


logging.basicConfig(level=logging.INFO)
LOG = logging.getLogger('Reading the command line arguments and copying data from s3 to redshift based on the load argument-fullload or incremental/truncateinsert and table name')


dbname = os.environ['RDS_DBNAME']
host = os.environ['RDS_SERVER']
prt = os.environ['RDS_PORT']
usr = os.environ['RDS_USERID']
passwd = os.environ['RDS_PWD']
table_prefix = os.environ['RDS_DBNAME_EXTN']
aws_s3_url = os.environ['S3_RDS_URL']
aws_access_key=os.environ['S3_RDS_PUB_KEY_ID']
secret_access_key=os.environ['S3_RDS_PRIV_KEY_ID']


conn = psycopg2.connect("dbname={} host={} port={} user={} password={}".format(dbname, host, prt, usr, passwd))
cur = conn.cursor()

doctype = ['domain', 'prescription', 'rewardtransaction', 'cp_pharmacy','rxplan_master', 'deductible','rx_claim_history', 'rx_history', 'drug', 'notification_log', 'user_feedback']

def send_email(filename):
	sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))
	from_email = Email("noreply@fliptrx.com")
	to_email = Email("fliptintegration@fliptrx.com")
	subject = "ERROR:"+dbname+" :"+host+" :"+ filename+" load failed"
	content = Content("text/plain", "ERROR:"+dbname+" :"+host+" :"+ filename+" load failed")
	mail = Mail(from_email, subject, to_email, content)
	response = sg.client.mail.send.post(request_body=mail.get())
	print(response.status_code)
	print(response.body)
	print(response.headers)

def send_email_date(filename):
	sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))
	from_email = Email("noreply@fliptrx.com")
	to_email = Email("fliptintegration@fliptrx.com")
	subject = "ERROR:"+dbname+" :"+host+" :"+ filename+" date load failed"
	content = Content("text/plain", "ERROR:"+dbname+" :"+host+" :"+ filename+" date load failed")
	mail = Mail(from_email, subject, to_email, content)
	response = sg.client.mail.send.post(request_body=mail.get())
	print(response.status_code)
	print(response.body)
	print(response.headers)

def loaddataall(lst):
	try:
		for elt in lst:
			commandall = ("COPY {} FROM '{}' \
					  CREDENTIALS 'aws_access_key_id={};aws_secret_access_key={}' \
					  FORMAT AS JSON '{}' ACCEPTINVCHARS BLANKSASNULL EMPTYASNULL; " \
					  .format(table_prefix+".dw_"+elt, aws_s3_url+"dw_"+elt+".json", aws_access_key,secret_access_key, aws_s3_url+"Test/jsonpaths_"+elt+".json"))

			cur.execute(commandall)
			conn.commit()
			command_loaddate = ("insert into {} values ('{}', NULL, GETDATE(), NULL );".format(table_prefix+".dw_load_date", "dw_"+elt))
			cur.execute(command_loaddate)
			conn.commit()
	except:
		executionstatus = "Failure"
		tnm = "all"
		send_email(tnm)


def loaddata(tablename):
	#try:
		command_tb = ("COPY {} FROM '{}' \
					CREDENTIALS 'aws_access_key_id={};aws_secret_access_key={}' \
					FORMAT AS JSON '{}' ACCEPTINVCHARS BLANKSASNULL EMPTYASNULL;"\
					.format(table_prefix + ".dw_" + tablename,
							aws_s3_url + "dw_" + tablename + ".json",
							aws_access_key,
							secret_access_key,
							aws_s3_url+"Test/jsonpaths_"+tablename+".json"))

		cur.execute(command_tb)
		conn.commit()
	#except:
	#	executionstatus='Failure'
	#	send_email(tablename)


def trun(tablename):
	try:
		com_trun = ("TRUNCATE {};".format(table_prefix+".dw_"+tablename))
		cur.execute(com_trun)
		conn.commit()
	except:
		executionstatus='Failure'
		send_email(tablename)


def loaddate(tablename, loadtype):
	try:
		com_loaddate = ("insert into {} values ('{}', NULL, GETDATE(), NULL );".format(table_prefix+".dw_load_date", "dw_"+tablename))
		cur.execute(com_loaddate)
		conn.commit()
	except:
		executionstatus='Failure'
		send_email_date(tablename)
	
def updatedate(tablename, loadtype):
	try:
		com2_loaddate = ("update {} set table_last_load_date=GETDATE() where table_name = '{}';".format(table_prefix+".dw_load_date", "dw_"+tablename))
		cur.execute(com2_loaddate)
		conn.commit()
		com2_updatedate = ("update {} set update_date=GETDATE() where table_name = '{}';".format(table_prefix+".dw_load_date", "dw_"+tablename))
		cur.execute(com2_updatedate)
		conn.commit()
	except:
		executionstatus='Failure'
		send_email_date(tablename)
	
def main():
	global LOG
	tablename = None	
	try:
		opts, args = getopt.getopt(sys.argv[1:], "t:l:")
	except getopt.GetoptError:
		print('filetype.py -t <tablename> -l <loadtype>')
		LOG.info("filetype.py -t <tablename> -l <loadtype>")
		sys.exit(2)
		
	for opt, arg in opts:
		if opt in ("-t"):
			tablename = arg
		if opt in ("-l"):
			loadtype = arg
	 
	

	#fformat = logging.Formatter('%(tablename)s:%(levelname)s:%(message)s')
	logpath = os.environ['CB_DATA']+'//datawarehouse//log//log'+tablename+datetime.now().strftime("%Y%m%d%H%M") +'.txt'
	handler = logging.FileHandler(logpath)
	#handler.setFormatter(fformat)
	LOG.addHandler(handler)

	LOG.info("=========================================================")
	LOG.info("==== Reading the command line arguments and copying data from s3 to redshift based on the load argument-fullload or incremental/truncateinsert and table name' ==============")

	if tablename=="all":
		print("Only full load enabled for all tables. All dates will be reset and load_date will be populated")
		loaddataall(doctype)
	elif tablename !="all" and loadtype!="ti":
		loaddata(tablename)
		if loadtype == "fullload":
			loaddate(tablename, loadtype)	
		if loadtype == "incremental":
			updatedate(tablename, loadtype)
	elif tablename !="all" and loadtype=="ti":
		trun(tablename)
		loaddata(tablename)
		updatedate(tablename, loadtype)

  
	LOG.info("=========================================================")
	
if __name__ == '__main__':
	sys.exit(main())	
