########################################
# !/usr/bin/env python  
# title         :load_medispan2rs.py
# description   : load the drug dosing records from medispan to redshift table
# author        : Hari
# date created  : 20190503
# date last modified    : 
# version       : 0.1
# maintainer    : 
# email         : -
# status        : Development
# Python Version: 3.5.X
# usage         : python load_medispan2rs.py -t dda_all
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#                          
# #######################################


from zipfile import ZipFile 
import pandas as pd
import os, traceback, sys, re
import psycopg2
import getopt
import logging
import s3fs
import sendgrid
import boto3, io
from sendgrid.helpers.mail import *
from datetime import datetime

logging.basicConfig(level=logging.INFO)
LOG = logging.getLogger('get records from medispan and insert into tables in redshift')

def send_email(filename, subject='', content=''):
    sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))
    from_email = Email("noreply@fliptrx.com")
    to_email = Email("fliptintegration@fliptrx.com")
    if subject == '': subject = "ERROR:"+dbname+" :"+host+" :"+ filename+" load failed"
    if content == '': content = Content("text/plain", "ERROR:"+dbname+" :"+host+" :"+ filename+" load failed")
    mail = Mail(from_email, subject, to_email, content)
    response = sg.client.mail.send.post(request_body=mail.get())
    print(response.status_code)
    print(response.body)
    print(response.headers)



dbname = os.environ['RDS_DBNAME']
host = os.environ['RDS_SERVER']
prt = os.environ['RDS_PORT']
usr = os.environ['RDS_USERID']
passwd = os.environ['RDS_PWD']
table_prefix = os.environ['RDS_DBNAME_EXTN']
aws_s3_url = os.environ['S3_RDS_URL']
bkt = os.environ['S3_RDS_BUCKET']
#aws_s3_url = "s3://flipt-dwdev/"
aws_access_key=os.environ['S3_RDS_PUB_KEY_ID']
secret_access_key=os.environ['S3_RDS_PRIV_KEY_ID']
tablename = ''
print("dbname={} host={} port={} user={} password={}".format(dbname, host, prt, usr, passwd))
conn = psycopg2.connect("dbname={} host={} port={} user={} password={}".format(dbname, host, prt, usr, passwd))
cur = conn.cursor()
# secret_access_key = 'sdfdsf'\\\\\\

def truncate_table(tablename):
    try:
        com_trun = ("TRUNCATE {};".format(table_prefix+"."+tablename))
        print(com_trun)
        LOG.info(com_trun)
        cur.execute(com_trun)
        conn.commit()
    except Exception as e: 
        LOG.info(traceback.format_exc())
        executionstatus='Failure'
        # send_email(tablename)

def loaddata(tablename):
    try: 
        command_tb = ("copy {} from '{}'\
                    CREDENTIALS 'aws_access_key_id={};aws_secret_access_key={}' \
                     removequotes delimiter ',';"\
                    .format(table_prefix+"."+tablename, aws_s3_url+'DDA/'+tablename+".csv",aws_access_key,secret_access_key))
        # print("command_tb")
        # print(command_tb)
        cur.execute(command_tb)
        conn.commit()
        return True
    except Exception as e:
        print(traceback.format_exc())
        executionstatus='Failure'
        send_email(tablename)
        return False

def fn_load_DDADPP(zip_files, tablename):
    try:
        LOG.info("======fn_load_DDADPP is called here =====")
        list_of_all_rows = []
        data=str(zip_files.read('DDADPP'))[:-1].strip()
        for columns in data.split("\\n"):
            lst_row = []
            columns = columns.replace('b\'', '')
            if columns == '': continue
            str_profile_id=int(columns[0:10].strip())
            str_transaction_code=str(columns[10:11].strip())
            str_indication_code=int(columns[11:18].strip())
            str_special_condition_code=int(columns[18:25].strip())
            str_age_type_code=str(columns[25:27].strip())
            str_age_days_low=int(columns[27:32].strip())
            str_age_days_high=int(columns[32:37].strip())
            str_additional_age_type_code=str(columns[37:39].strip())
            str_additional_age_days_low=int(columns[39:44].strip())
            str_additional_age_days_high=int(columns[44:49].strip())
            str_renal_function_msmt_type_code=str(columns[49:51].strip())
            str_renal_function_msmt_low=int(columns[51:59].strip())
            str_renal_function_msmt_high=int(columns[59:67].strip())
            str_renal_function_msmt_uom_code=str(columns[67:69].strip())
            str_weight_category_low=int(columns[69:76].strip())
            str_weight_category_high=int(columns[76:83].strip())
            str_weight_category_uom_code=str(columns[83:85].strip())
            str_reserve=str(columns[85:128].strip())
            str_create_date=datetime.now()
            str_update_date=None

            lst_row.append(str_profile_id)
            lst_row.append(str_transaction_code)
            lst_row.append(str_indication_code)
            lst_row.append(str_special_condition_code)
            lst_row.append(str_age_type_code)
            lst_row.append(str_age_days_low)
            lst_row.append(str_age_days_high)
            lst_row.append(str_additional_age_type_code)
            lst_row.append(str_additional_age_days_low)
            lst_row.append(str_additional_age_days_high)
            lst_row.append(str_renal_function_msmt_type_code)
            lst_row.append(str_renal_function_msmt_low)
            lst_row.append(str_renal_function_msmt_high)
            lst_row.append(str_renal_function_msmt_uom_code)
            lst_row.append(str_weight_category_low)
            lst_row.append(str_weight_category_high)
            lst_row.append(str_weight_category_uom_code)
            lst_row.append(str_reserve)
            lst_row.append(str_create_date)
            lst_row.append(str_update_date)

            list_of_all_rows.append(lst_row)

        df_DDADPP=pd.DataFrame(list_of_all_rows,columns=['profile_id','transaction_code','indication_code','special_condition_code','age_type_code',
        'age_days_low','ge_days_high','additional_age_type_code','additional_age_days_low','additional_age_days_high','renal_function_msmt_type_code',
        'renal_function_msmt_low','renal_function_msmt_high','renal_function_msmt_uom_code','weight_category_low','weight_category_high',
        'weight_category_uom_code','reserve','create_date','update_date'])
        
        
        s3 = s3fs.S3FileSystem(anon=False, key = aws_access_key, secret = secret_access_key)
        with s3.open(bkt+'/DDA/'+tablename+'.csv','w') as f:
            df_DDADPP.to_csv(f, header=False, index =False, encoding ='utf-8')
        status = loaddata(tablename)
        if status:
            LOG.info("======records inserted successfully")
        else:
            LOG.info("======records insert failed")

    except Exception as e: 
        LOG.info(traceback.format_exc())
        executionstatus='Failure'
        return executionstatus

def fn_load_DDADTXT(zip_files, tablename):
    try:
        LOG.info("======fn_load_DDADTXT is called here =====")
        list_of_all_rows = []
        data=str(zip_files.read('DDADTXT'))[:-1].strip()
        for columns in data.split("\\n"):
            lst_row = []
            columns = columns.replace('b\'', '')
            if columns == '': continue
            str_dose_id=int(columns[0:10])
            str_text_type_id=str(columns[10:13])
            str_level_code=str(columns[13:15])
            str_sequence_number=int(columns[15:18])
            str_transaction_code=str(columns[18:19])
            str_text_id=int(columns[19:29])
            str_reserve=str(columns[29:48])
            str_create_date=datetime.now()            
            str_update_date=None

            lst_row.append(str_dose_id)
            lst_row.append(str_text_type_id)
            lst_row.append(str_level_code)
            lst_row.append(str_sequence_number)
            lst_row.append(str_transaction_code)
            lst_row.append(str_text_id)
            lst_row.append(str_reserve)
            lst_row.append(str_create_date)
            lst_row.append(str_update_date)
            list_of_all_rows.append(lst_row)
            
        print('list_of_all_rows is %s'%list_of_all_rows)
        df_DDADTXT=pd.DataFrame(list_of_all_rows,columns=['dose_id','text_type_id','level_code','sequence_number','transaction_code','text_id','reserve','create_date','update_date'])
        s3 = s3fs.S3FileSystem(anon=False, key = aws_access_key, secret = secret_access_key)
        with s3.open(bkt+'/DDA/'+tablename+'.csv','w') as f:
            df_DDADTXT.to_csv(f, header=False, index =False, encoding ='utf-8')
        status = loaddata(tablename)
        if status:
            LOG.info("======records inserted successfully")
        else:
            LOG.info("======records insert failed")

    except Exception as e: 
        LOG.info(traceback.format_exc())
        executionstatus='Failure'
        return executionstatus
def fn_load_DDARTE(zip_files, tablename):
    try:
        LOG.info("======fn_load_DDARTE is called here =====")
        list_of_all_rows = []
        data=str(zip_files.read('DDARTE'))[:-1].strip()
        for columns in data.split("\\n"):
            lst_row = []
            columns = columns.replace('b\'', '')
            if columns == '': continue
            str_Route_ID=int(columns[0:5].strip())
            str_Transaction_Code=str(columns[5:6].strip())
            str_Route_Abbreviation=str(columns[6:9].strip())
            str_Route_Description=str(columns[9:59].strip())
            str_Reserve=str(columns[59:80].strip())
            str_create_date=datetime.now()
            str_update_date=None
            lst_row.append(str_Route_ID)
            lst_row.append(str_Transaction_Code)
            lst_row.append(str_Route_Abbreviation)
            lst_row.append(str_Route_Description)
            lst_row.append(str_Reserve)
            lst_row.append(str_create_date)
            lst_row.append(str_update_date)
            list_of_all_rows.append(lst_row)
        df_DDARTE=pd.DataFrame(list_of_all_rows,columns=['route_id','transaction_code','route_abbreviation','route_description','reserve','create_date','update_date'])
        
        
        s3 = s3fs.S3FileSystem(anon=False, key = aws_access_key, secret = secret_access_key)
        with s3.open(bkt+'/DDA/'+tablename+'.csv','w') as f:
            df_DDARTE.to_csv(f, header=False, index =False, encoding ='utf-8')
        status = loaddata(tablename)
        if status:
            LOG.info("======records inserted successfully")
        else:
            LOG.info("======records insert failed")

    except Exception as e: 
        LOG.info(traceback.format_exc())
        executionstatus='Failure'
        return executionstatus
def fn_load_DDAUOM(zip_files, tablename):
    try:
        LOG.info("======fn_load_DDAUOM is called here =====")
        list_of_all_rows = []
        data=str(zip_files.read('DDAUOM'))[:-1].strip()
        for columns in data.split("\\n"):
            lst_row = []
            columns = columns.replace('b\'', '')
            if columns == '': continue
            str_Unit_of_Measure_ID=int(columns[0:5].strip())
            str_Transaction_Code=str(columns[5:6].strip())
            str_Unit_of_Measure_Description=str(columns[6:56].strip())
            str_Unit_of_Measure_Type_Code=str(columns[56:58].strip())
            str_Reserve=str(columns[58:80].strip())
            str_create_date=datetime.now()
            str_update_date=None
            lst_row.append(str_Unit_of_Measure_ID)
            lst_row.append(str_Transaction_Code)
            lst_row.append(str_Unit_of_Measure_Description)
            lst_row.append(str_Unit_of_Measure_Type_Code)
            lst_row.append(str_Reserve)
            lst_row.append(str_create_date)
            lst_row.append(str_update_date)

            list_of_all_rows.append(lst_row)

        df_DDAUOM = pd.DataFrame(list_of_all_rows, columns=['unit_of_measure_id','transaction_code','unit_of_measure_description',
        'Unit_of_measure_type_code','reserve','create_date','update_date'])
            
        # print(df_DDAUOM)
        s3 = s3fs.S3FileSystem(anon=False, key = aws_access_key, secret = secret_access_key)
        with s3.open(bkt+'/DDA/'+tablename+'.csv','w') as f:
            df_DDAUOM.to_csv(f, header=False, index =False, encoding ='utf-8')
            
        status = loaddata(tablename)
        if status:
            LOG.info("======records inserted successfully")
        else:
            LOG.info("======records insert failed")

    except Exception as e: 
        LOG.info(traceback.format_exc())
        executionstatus='Failure'
        return executionstatus
def fn_load_DDAAUOM(zip_files, tablename):
    try:
        LOG.info("======fn_load_DDAAUOM is called here =====")
        list_of_all_rows = []
        data=str(zip_files.read('DDAAUOM'))[:-1].strip()
        for columns in data.split("\\n"):
            lst_row = []
            columns = columns.replace('b\'', '').strip()
            if columns == '': continue
            str_Alternate_Unit_of_Measure_ID=int(columns[0:5].strip())
            str_Transaction_Code=str(columns[5:6].strip())
            str_Unit_of_Measure_ID=int(columns[6:11].strip())
            str_Alternate_Unit_of_Measure_Description=str(columns[11:61].strip())
            str_Reserve=str(columns[61:80].strip())
            str_create_date=datetime.now()
            str_update_date= None

            lst_row.append(str_Alternate_Unit_of_Measure_ID)
            lst_row.append(str_Transaction_Code)
            lst_row.append(str_Unit_of_Measure_ID)
            lst_row.append(str_Alternate_Unit_of_Measure_Description)
            lst_row.append(str_Reserve)
            lst_row.append(str_create_date)
            lst_row.append(str_update_date)

            list_of_all_rows.append(lst_row)

            
        df_DDAAUOM = pd.DataFrame(list_of_all_rows, columns=['alternate_unit_of_measure_id', 'transaction_code','unit_of_measure_id',
                'alternate_unit_of_measure_description','reserve', 'create_date','update_date'])
           
        # print(df_DDAAUOM)  
        s3 = s3fs.S3FileSystem(anon=False, key = aws_access_key, secret = secret_access_key)

        with s3.open(bkt+'/DDA/'+tablename+'.csv','w') as f:
            df_DDAAUOM.to_csv(f, header=False, index =False, encoding ='utf-8')
            
        status = loaddata(tablename)
        if status:
            LOG.info("======records inserted successfully")
        else:
            LOG.info("======records insert failed")

    except Exception as e: 
        LOG.info(traceback.format_exc())
        executionstatus='Failure'
        return executionstatus
#completed
def fn_load_DDADOSE(zip_files, tablename):
    try:
        LOG.info("======fn_load_DDADOSE is called here =====")
        list_of_all_rows = []
        data=str(zip_files.read('DDADOSE'))[:-1].strip()
        for columns in data.split("\\n"):
            lst_row = []
            columns = columns.replace('b\'', '')
            if columns == '': continue
            str_dose_id=int(columns[0:10].strip())
            str_transaction_code=str(columns[10:11].strip())
            str_profile_id=int(columns[11:21].strip())
            str_generic_product_id=str(columns[21:35].strip())
            str_reserve_1=str(columns[35:41].strip())
            str_route_id=int(columns[41:46].strip())
            str_dose_type_code=str(columns[46:48].strip())
            str_daily_dose_low=int(columns[48:57].strip())
            str_daily_dose_low_uom_id=int(columns[57:62].strip())
            str_daily_dose_high=int(columns[62:71].strip())
            str_daily_dose_high_uom_id=int(columns[71:76].strip())
            str_daily_dose_form_low=int(columns[76:85].strip())
            str_daily_dose_form_low_uom_id=int(columns[85:90].strip())
            str_daily_dose_form_high=int(columns[90:99].strip())
            str_daily_dose_form_high_uom_id=int(columns[99:104].strip())
            str_max_daily_dose=int(columns[104:113].strip())
            str_max_daily_dose_uom_id=int(columns[113:118].strip())
            str_max_daily_dose_form=int(columns[118:127].strip())
            str_max_daily_dose_form_uom_id=int(columns[127:132].strip())
            str_max_single_dose=int(columns[132:141].strip())
            str_max_single_dose_uom_id=int(columns[141:146].strip())
            str_max_single_dose_form=int(columns[146:155].strip())
            str_max_single_dose_form_uom_id=int(columns[155:160].strip())
            str_max_lifetime_dose=int(columns[160:169].strip())
            str_max_lifetime_dose_uom_id=int(columns[169:174].strip())
            str_max_lifetime_dose_form=int(columns[174:183].strip())
            str_max_lifetime_dose_form_uom_id=int(columns[183:188].strip())
            str_frequency_low=int(columns[188:197].strip())
            str_frequency_high=int(columns[197:206].strip())
            str_max_frequency=int(columns[206:215].strip())
            str_duration_low=int(columns[215:224].strip())
            str_duration_high=int(columns[224:233].strip())
            str_maxduration=int(columns[233:242].strip())
            str_drug_half_life_low=int(columns[242:247].strip())
            str_drug_half_life_high=int(columns[247:252].strip())
            str_drug_half_life_uom_code=str(columns[252:255].strip())
            str_reserve_2=str(columns[255:320].strip())
            str_create_date=datetime.now()
            str_update_date=None
            
            lst_row.append(str_dose_id)
            lst_row.append(str_transaction_code)
            lst_row.append(str_profile_id)
            lst_row.append(str_generic_product_id)
            lst_row.append(str_reserve_1)
            lst_row.append(str_route_id)
            lst_row.append(str_dose_type_code)
            lst_row.append(str_daily_dose_low)
            lst_row.append(str_daily_dose_low_uom_id)
            lst_row.append(str_daily_dose_high)
            lst_row.append(str_daily_dose_high_uom_id)
            lst_row.append(str_daily_dose_form_low)
            lst_row.append(str_daily_dose_form_low_uom_id)
            lst_row.append(str_daily_dose_form_high)
            lst_row.append(str_daily_dose_form_high_uom_id)
            lst_row.append(str_max_daily_dose)
            lst_row.append(str_max_daily_dose_uom_id)
            lst_row.append(str_max_daily_dose_form)
            lst_row.append(str_max_daily_dose_form_uom_id)
            lst_row.append(str_max_single_dose)
            lst_row.append(str_max_single_dose_uom_id)
            lst_row.append(str_max_single_dose_form)
            lst_row.append(str_max_single_dose_form_uom_id)
            lst_row.append(str_max_lifetime_dose)
            lst_row.append(str_max_lifetime_dose_uom_id)
            lst_row.append(str_max_lifetime_dose_form)
            lst_row.append(str_max_lifetime_dose_form_uom_id)
            lst_row.append(str_frequency_low)
            lst_row.append(str_frequency_high)
            lst_row.append(str_max_frequency)
            lst_row.append(str_duration_low)
            lst_row.append(str_duration_high)
            lst_row.append(str_maxduration)
            lst_row.append(str_drug_half_life_low)
            lst_row.append(str_drug_half_life_high)
            lst_row.append(str_drug_half_life_uom_code)
            lst_row.append(str_reserve_2)
            lst_row.append(str_create_date)
            lst_row.append(str_update_date)
            
            list_of_all_rows.append(lst_row)
            
        df_DDADOSE = pd.DataFrame(list_of_all_rows,columns=['dose_id','transaction_code','profile_id','generic_product_id','reserve_1',
        'route_id','dose_type_code','daily_dose_low','daily_dose_low_uom_id','daily_dose_high','daily_dose_high_uom_id','daily_dose_form_low',
        'daily_dose_form_low_uom_id','daily_dose_form_high','daily_dose_form_high_uom_id','max_daily_dose','max_daily_dose_uom_id',
        'max_daily_dose_form','max_daily_dose_form_uom_id','max_single_dose','max_single_dose_uom_id','max_single_dose_form',
        'max_single_dose_form_uom_id','max_lifetime_dose','max_lifetime_dose_uom_id','max_lifetime_dose_form','max_lifetime_dose_form_uom_id',
        'frequency_low','frequency_high','max_frequency','duration_low','duration_high','max_duration','drug_half_life_low',
        'drug_half_life_high','drug_half_life_uom_code','reserve_2','create_date','update_date'])
        
        s3 = s3fs.S3FileSystem(anon=False, key = aws_access_key, secret = secret_access_key)
        with s3.open(bkt+'/DDA/'+tablename+'.csv','w') as f:
            df_DDADOSE.to_csv(f, header=False, index =False, encoding ='utf-8')
            
        status = loaddata(tablename)
        if status:
            LOG.info("======records inserted successfully")
        else:
            LOG.info("======records insert failed")

    except Exception as e: 
        LOG.info(traceback.format_exc())
        executionstatus='Failure'
        return executionstatus   
    
def fn_call_table(zip_files, tablename):
    try:
        LOG.info("======fn_call_table called here=======")
        if tablename == 'dda_alternate_unit_measure':
            print("dda_alternate_unit_measure")
            LOG.info("dda_alternate_unit_measure")
            truncate_table(tablename)
            fn_load_DDAAUOM(zip_files, tablename)
        
        elif tablename == 'dda_dosing_patient_profile':
            print("dda_dosing_patient_profile")
            LOG.info("dda_dosing_patient_profile")
            truncate_table(tablename)
            fn_load_DDADPP(zip_files, tablename)
        
        elif tablename == 'dda_gpi_dose_text':
            print("dda_gpi_dose_text")
            LOG.info("dda_gpi_dose_text")
            truncate_table(tablename)
            fn_load_DDADTXT(zip_files, tablename)
        
        elif tablename == 'dda_gpi_dose':
            print("dda_gpi_dose")
            LOG.info("dda_gpi_dose")
            truncate_table(tablename)
            fn_load_DDADOSE(zip_files, tablename)

        elif tablename == 'dda_route':
            print("dda_route")
            LOG.info("dda_route")
            truncate_table(tablename)
            fn_load_DDARTE(zip_files, tablename)
        
        elif tablename == 'dda_unit_of_measure':
            print("dda_unit_of_measure")
            LOG.info("dda_unit_of_measure")
            truncate_table(tablename)
            fn_load_DDAUOM(zip_files, tablename)
            LOG.info("======fn_call_table end here")
    except Exception as e: 
        LOG.info(traceback.format_exc())
        executionstatus='Failure'
        return executionstatus

def delete_file_from_medispan(pfile_name):
    # LOG.info("")
    import os
    import ftplib
    from contextlib import closing
    import traceback

    host = os.environ['MEDISPAN_FTP_HOST']
    port = int(os.environ['MEDISPAN_FTP_PORT'])
    login = os.environ['MEDISPAN_FTP_USER']
    passwd = os.environ['MEDISPAN_FTP_PWD']
    try:
        LOG.info("======delete_file_from_medispan called here====")
        S3_path = bkt+'/DDA/'
        with closing(ftplib.FTP()) as ftp:
            try:
                ftp.connect(host, port, 30*5) #5 mins timeout
                ftp.login(login, passwd)
                ftp.set_pasv(True)
                file_path = 'Medispan/334994/'+pfile_name
                ftp.delete(file_path)
                print("%s is deleted successfully."%file_path)
            except Exception as e:
                print(traceback.format_exc())
                LOG.info(traceback.format_exc())
        LOG.info("======delete_file_from_medispan completed successfully====")
    except Exception as e:
        print(traceback.format_exc())
        LOG.info(traceback.format_exc())


def copy_from_medispan_to_S3():
    # LOG.info("")
    import os
    import ftplib
    from contextlib import closing
    import traceback

    host = os.environ['MEDISPAN_FTP_HOST']
    port = int(os.environ['MEDISPAN_FTP_PORT'])
    login = os.environ['MEDISPAN_FTP_USER']
    passwd = os.environ['MEDISPAN_FTP_PWD']
    try:
        LOG.info("======copy_from_medispan_to_S3 called here====")
        S3_path = bkt+'/DDA/'
        with closing(ftplib.FTP()) as ftp:
            try:
                ftp.connect(host, port, 30*5) #5 mins timeout
                ftp.login(login, passwd)
                ftp.set_pasv(True)
                inner_path = 'Medispan/'+login
                ftp.cwd(inner_path)

                dir_list = []
                ftp.dir(dir_list.append)
                # print(dir_list)
                dir_list
                for line in dir_list:
                    orig_filename = line[29:].strip().split(' ')[-1]
                    if re.match('^DDA',  str(orig_filename).upper()):
                        print(orig_filename)
                        s3 = s3fs.S3FileSystem(anon=False, key = aws_access_key, secret = secret_access_key)

                        with s3.open(S3_path+orig_filename,'wb') as f:
                            res = ftp.retrbinary('RETR %s' % orig_filename, f.write)

                            if not res.startswith('226 Transfer complete'):
                                print('Downloaded of file {0} is not compile.'.format(orig_filename))
                                os.remove(orig_filename)
            except Exception as e:
                print(traceback.format_exc())
                LOG.info(traceback.format_exc())
        LOG.info("======copy_from_medispan_to_S3 end here====")
    except Exception as e: 
        LOG.info(traceback.format_exc())
        executionstatus='Failure'
        return executionstatus
        
def main():
    global LOG
    tablename = None
    print("main called")
    try:
        opts, args = getopt.getopt(sys.argv[1:], "-t:")
    except getopt.GetoptError:
        print('filetype.py -t <tablename>')
        LOG.info("filetype.py -t <tablename>")
        sys.exit(2)
		
    for opt, arg in opts:
        if opt in ("-t"):
            tablename = arg
	
    copy_from_medispan_to_S3()
    #fformat = logging.Formatter('%(tablename)s:%(levelname)s:%(message)s')
    logpath = os.environ['CB_DATA']+'//datawarehouse//log//log_'+tablename+datetime.now().strftime("%Y%m%d%H%M") +'.txt'
    handler = logging.FileHandler(logpath)
    #handler.setFormatter(fformat)
    LOG.addHandler(handler)

    LOG.info("=========================================================")
    LOG.info("=============== Setup-Drop and create redshift tables ==============")
    file_name = ''
    try:
        doctype = ["dda_all","dda_alternate_unit_measure","dda_dosing_patient_profile","dda_gpi_dose_text","dda_gpi_dose","dda_route","dda_unit_of_measure"]	
        list_of_all_rows = []
            
        session = boto3.session.Session(
            aws_access_key_id=aws_access_key, 
            aws_secret_access_key=secret_access_key
        )

        s3 = session.resource("s3")
        bucket = s3.Bucket(bkt)
        print("tablename is %s"%tablename)
        files_in_s3 = bucket.objects.all() 
        is_file_found = False
        for i in list(files_in_s3):
            if re.match('^DDA\/DDA',  str(i.key).upper()):
                print(i.key)
                obj = bucket.Object(i.key)

                with io.BytesIO(obj.get()["Body"].read()) as tf:

                    # rewind the file
                    tf.seek(0)
                    is_file_found = True
                    # Read the file as a zipfile and process the members
                    with ZipFile(tf, mode='r') as zip_files: 
                        #     zip_files.printdir()
                        print("zip file is opened")
                        try: 

                            if tablename == 'dda_all':
                                print("All tables")
                                LOG.info("All tables")
                                for tablename in doctype:
                                    if tablename != 'dda_all':
                                        truncate_table(tablename)
                                        fn_call_table(zip_files, tablename)
                                
                            elif tablename not in doctype:
                                LOG.info("=============== the given table name is incorrect ==============")
                                executionstatus = "Failure"
                                send_email(tablename)
                            else:
                                truncate_table(tablename)
                                fn_call_table(zip_files, tablename)

                                
                        except Exception as e:            
                            LOG.info(traceback.format_exc())
                            executionstatus = "Failure"
                            send_email(tablename) 
                        
                        
                    #     print(df_DDAREAD.head(5))
                        print('Extracting the files now...')
                        print('Done!')
                # copy stuff to your destination here
                copy_source = {
                    'Bucket': bkt,
                    'Key': i.key
                }
                file_name = (i.key).split('/')[-1]
                destination_file_path = 'DDA/Archive/'+(i.key).split('/')[-1]
                print(destination_file_path)
                s3.meta.client.copy(copy_source, bkt, destination_file_path)
                # then delete the source key
                i.delete()
                for i in list(files_in_s3):
                    # delete all files other than archive folder inside DDA( Handle belo line carefully)
                    if re.match('DDA\/',  i.key) and not re.match('DDA\/Archive/',  i.key):
                        i.delete()
                
                if file_name != '':
                    delete_file_from_medispan(file_name)
                
                f_name = 'load_medispan2rs'
                success_subject = 'Success: Load records from medispan to redshift'
                success_content = Content("text/plain",'Success: Load records from medispan to redshift process completed successfully')
                send_email(f_name, success_subject, success_content) 
                

        if is_file_found == False:
            f_name = 'load_medispan2rs'
            print('Failed: No records in medispan')
            LOG.info('Failed: No records in medispan')
            success_subject = 'Failed: No records in medispan'
            success_content = Content("text/plain",'Failed: Input file is not found in medispan ftp location')
            send_email(f_name, success_subject, success_content)
    
    except Exception as e:            
        LOG.info(traceback.format_exc())
        print(traceback.format_exc())
        executionstatus = "Failure"
        send_email(tablename) 

if __name__ == '__main__':
    sys.exit(main())