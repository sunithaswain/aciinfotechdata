import json
import os
import re
import logging
from datetime import datetime, timedelta
import psycopg2
from couchbase.cluster import Cluster, PasswordAuthenticator

path = os.environ['CB_DATA']
log_path = path + '/log'

now = datetime.now().strftime("%d-%m-%Y-%H:%M:%S")

# add new logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

fh = logging.FileHandler(f'{path}/ETL/log/etl_claims_log-{now}.log')
fh.setLevel(logging.DEBUG)

formatter = logging.Formatter('%(name)s - %(asctime)s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)

logger.addHandler(fh)


def cb_authenticate():
    """
    This function returns an handle object to Couchbase bucket for
    a database instance (dev/staging/prod)
    :return: cluster handle to the bucket
    """
    logger.info("Connecting to the couchbase")
    cluster = Cluster(os.environ['CB_URL'])
    auth = PasswordAuthenticator(
        os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
    cluster.authenticate(auth)
    return cluster.open_bucket(os.environ['CB_INSTANCE'])


def redshift_con():
    logger.info("Connecting to the red shift")
    dbname = os.environ['RDS_DBNAME']
    user = os.environ['RDS_USERID']
    password = os.environ['RDS_PWD']
    host = os.environ['RDS_SERVER']
    port = os.environ['RDS_PORT']
    conn_string = f"dbname='{dbname}' port={port} user='{user}' password='{password}' host='{host}'"
    logger.info(f"connected to the database {dbname}")
    return psycopg2.connect(conn_string)


table_columns = ['updatedate', 'type', 'transferresponse_version', 'transferresponse_transaction_response_status',
                 'transferresponse_transaction_count', 'transferresponse_transaction_code',
                 'transferresponse_service_provider_id_qualifier', 'transferresponse_service_provider_id',
                 'transferresponse_reject_count', 'transferresponse_reject_code',
                 'transferresponse_prescription_ref_num',
                 'transferresponse_prescription_number_qualifier', 'transferresponse_message',
                 'transferresponse_date_of_service',
                 'transferresponse_authorization_number', 'transferresponse_additional_message_information',
                 'transferrequest_processor_control_number', 'transferrequest_bin_number', 'transactionid', 'startdate',
                 'sequencenumber', 'response_version', 'response_url', 'response_transaction_response_status',
                 'response_transaction_count', 'response_transaction_code', 'response_total_amount_paid',
                 'response_tax_exempt_indicator', 'response_service_provider_id_qualifier',
                 'response_service_provider_id', 'response_response_status',
                 'response_reject_field_occurrence_indicator', 'response_reject_count', 'response_reject_code',
                 'response_product_incentive', 'response_product_id_qualifier', 'response_product_id',
                 'response_product_description', 'response_product_count', 'response_product_cost_share_incentive',
                 'response_prescription_reference_number_qualifier', 'response_prescription_reference_number',
                 'response_plan_id', 'response_payer_id_qualifier', 'response_payer_id',
                 'response_patient_sales_tax_amount', 'response_patient_pay_amount',
                 'response_other_amount_paid_qualifier', 'response_other_amount_paid_count',
                 'response_other_amount_paid', 'response_network_reimbursement_id', 'response_message',
                 'response_ingredient_cost_paid', 'response_help_desk_phone_number_qualifier',
                 'response_help_desk_phone_number', 'response_group_id', 'response_flat_sales_tax_amount_paid',
                 'response_dispensing_fee_paid', 'response_date_of_service', 'response_date_of_birth',
                 'response_cardholder_id', 'response_basis_of_reimbursement_determination',
                 'response_authorization_number', 'response_amount_of_copay', 'response_amount_attributed_to_sales_tax',
                 'response_additional_message_information_qualifier', 'response_additional_message_information_count',
                 'response_additional_message_information_continuity', 'response_additional_message_information',
                 'request_version', 'request_usual_and_customary_charge', 'request_unit_of_measure',
                 'request_transaction_count', 'request_transaction_code', 'request_submission_clarification_code_count',
                 'request_submission_clarification_code', 'request_special_packaging_indicator',
                 'request_software_vendor', 'request_service_provider_id_qualifier', 'request_service_provider_id',
                 'request_scheduled_prescription_id_number', 'request_route_of_administration',
                 'request_quantity_intended_dispensed', 'request_quantity_dispensed',
                 'request_provider_accept_assignment_indicator', 'request_product_selection_code',
                 'request_product_id_qualifier', 'request_product_id', 'request_processor_control_number',
                 'request_procedure_modifier_code_count', 'request_procedure_modifier_code',
                 'request_prior_authorization_type_code', 'request_prior_authorization_number_submitted',
                 'request_primary_care_provider_last_name', 'request_primary_care_provider_id_qualifier',
                 'request_primary_care_provider_id', 'request_prescription_reference_number_qualifier',
                 'request_prescription_reference_number', 'request_prescription_origin_code',
                 'request_prescriber_zip_code', 'request_prescriber_street_address', 'request_prescriber_state_address',
                 'request_prescriber_phone_number', 'request_prescriber_last_name', 'request_prescriber_id_qualifier',
                 'request_prescriber_id', 'request_prescriber_first_name', 'request_prescriber_city_address',
                 'request_pregnancy_indicator', 'request_plan_id', 'request_place_of_service',
                 'request_pharmacy_service_type', 'request_person_code', 'request_percentage_sales_tax_rate_submitted',
                 'request_percentage_sales_tax_basis_submitted', 'request_percentage_sales_tax_amount_submitted',
                 'request_payment_count', 'request_patient_relationship_code', 'request_patient_paid_amount_submitted',
                 'request_patient_id_qualifier', 'request_patient_id', 'request_patient_gender_code',
                 'request_patient_assignment_indicator', 'request_other_payer_reject_count',
                 'request_other_payer_reject_code', 'request_other_payer_patient_responsibility_amount_qualifier',
                 'request_other_payer_patient_responsibility_amount_count',
                 'request_other_payer_patient_responsibility_amount', 'request_other_payer_id_qualifier',
                 'request_other_payer_id', 'request_other_payer_date', 'request_other_payer_coverage_type',
                 'request_other_payer_amount_paid_qualifier', 'request_other_payer_amount_paid_count',
                 'request_other_payer_amount_paid', 'request_other_coverage_code',
                 'request_other_amount_claimed_submitted_qualifier', 'request_other_amount_claimed_submitted_count',
                 'request_other_amount_claimed_submitted', 'request_originally_prescribed_quantity',
                 'request_originally_prescribed_product_id_qualifier', 'request_originally_prescribed_product_code',
                 'request_number_of_refills_authorized', 'request_medigap_id', 'request_medicaid_indicator',
                 'request_medicaid_id_number', 'request_level_of_service', 'request_internal_control_number',
                 'request_intermediary_authorization_type_id', 'request_intermediary_authorization_id',
                 'request_ingredient_cost_submitted', 'request_ingredient_component_count',
                 'request_incentive_amount_submitted', 'request_home_plan', 'request_group_id',
                 'request_gross_amount_due', 'request_gpi', 'request_flat_sales_tax_amount_submitted',
                 'request_fill_number', 'request_employer_id', 'request_eligibility_clarification_code',
                 'request_dispensing_status', 'request_dispensing_fee_submitted', 'request_delay_reason_code',
                 'request_days_supply_intended_dispensed', 'request_days_supply', 'request_date_prescription_written',
                 'request_date_of_service', 'request_date_of_birth', 'request_compound_type',
                 'request_compound_ingredients', 'request_compound_code',
                 'request_cms_part_d_defined_qualified_facility', 'request_cardholder_id', 'request_bin_number',
                 'request_benefit_stage_qualifier', 'request_benefit_stage_count', 'request_benefit_stage_amount',
                 'request_basis_of_cost_determination', 'request_associated_prescription_reference_number',
                 'request_associated_prescription_date', 'prescription_id', 'overridenumber', 'override_thru',
                 'override_percentage', 'override_from', 'override_amount', 'over_ride', 'enddate', 'createdate',
                 'copay_override', 'autoerx_failure_reason', 'auth_id', 'domain', 'brand_generic', 'baseline_cost',
                 'drug_name', 'drug_dosage', 'drug_penalty', 'gppc', 'drug_strength', 'drug_manufacturer',
                 'package_quantity', 'package_size', 'copay', 'copay_amt', 'copay_type', 'employee_opc',
                 'opc_remaining', 'price_type', 'pharmacy_name', 'pharmacy_chain_code', 'pharmacy_dispensing_fee',
                 'default_payment_option', 'claims_processor', 'plan_year', 'coverage_tier_name',
                 'benefit_plan_name', 'alternative_drug_rewards', 'total_reward', 'rebate_factor',
                 'rebate_amount', 'retail_reward', 'reward_percentage', 'reward_share', 'rewards',
                 'otc_indicator', 'multi_source', 'pa_flag', 'payer_authid',
                 'claim_status', 'submitted_total_amount', 'alternate_penalty', 'client_deductible',
                 'calculated_disp_fee', 'calculated_drug_cost', 'calculated_employee_opc', 'calculated_employer_cost',
                 'calculated_ing_cost', 'calculated_patient_pay_amt', 'client_deductible', 'client_disp_fee_paid',
                 'client_drug_cost_paid', 'client_employee_paid', 'client_employer_cost', 'client_ing_cost',
                 'submitted_disp_fee', 'submitted_drug_cost', 'submitted_employer_cost', 'submitted_ing_cost',
                 'submitted_patient_paid_amount', 'unc_disp_fee', 'unc_drug_cost', 'unc_employer_cost', 'unc_ing_cost',
                 'unc_patient_paid_amount', 'unit_price']



def get_last_load_date(con):
    logger.info("Getting last load date in the claims table")
    cur = con.cursor()
    last_load_date_query = f"select max(table_last_load_date) from flipt_dw.dw_load_date " \
        f"where table_name='flipt_dw.dw_claims';"
    cur.execute(last_load_date_query)
    logger.info(f"last load date query: {last_load_date_query}")
    last_load_date = cur.fetchall()
    if not last_load_date:
        logger.info("Last load date is NONE")
        return None
    last_load_date = last_load_date[0][0]
    logger.info(f"last_load_date: {last_load_date}")
    return last_load_date.isoformat()


def extract_claims_frm_cb(table, cb, from_date, con):
    to_date = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%dT23:59:59.999999")
    query_range = f"startDate<'{to_date}'"
    if not from_date:
        from_date_query = f"select max(startdate) as last_load_date from flipt_dw.dw_claims"
        cur = con.cursor()
        cur.execute(from_date_query)
        from_date = cur.fetchall()[0][0]
        logger.info(f"Got last load date form the dw_claims table {from_date}")
    if from_date:
        query_range = f"{query_range} and startDate>'{from_date}'"
    logger.info(f"Extracting claims from couchbase from '{from_date}' to '{to_date} and table: {table}")
    query = f"select * from `{os.environ['CB_INSTANCE']}` where type='{table}' and {query_range} and claim_status in ['P', 'X']"
    if 'None' in query:
        query = f"select * from `{os.environ['CB_INSTANCE']}` where type='{table}' and claim_status in ['P', 'X']"
    cb.timeout = 7200
    field_transform_map = {'claim_request': 'request',
                           'claim_response': 'response',
                           'claim_transfer_request': 'transferrequest',
                           'claim_transfer_response': 'transferresponse'}

    lm = []

    def _convert2str(k, v):
        if k in ["request_compound_ingredients"]:
            return json.dumps(v)
        elif isinstance(v, list):
            return ','.join(v)
        elif isinstance(v, str) and "'" in v:
            return re.escape(v)
        else:
            return str(v)

    cb_record_count = cb.n1ql_query(query).metrics['resultCount']

    for row in cb.n1ql_query(query):
        row_res = {}
        for row_key, row_val in row[os.environ['CB_INSTANCE']].items():
            if isinstance(row_val, dict):
                for sub_row_key, sub_row_val in row_val.items():
                    key = f'{field_transform_map.get(row_key, row_key)}_{sub_row_key}'
                    if key.lower() not in table_columns:
                        continue
                    row_res[key] = _convert2str(key, sub_row_val)

            else:
                if not row_key.lower() in table_columns:
                    continue
                row_res[row_key] = _convert2str(row_key, row_val)
        lm.append(row_res)

    insert_into_redshift(lm, con)
    rs_record_count = get_inseted_record_count(query_range, con)
    logger.info(f"Received record count from couchbase: {cb_record_count}\n"
                f"Inserted record count to Redshift: {rs_record_count}")

    # write to_date to last_load_date table in Redshift
    # This is used as reference date for next run
    logger.info(f"Updating the last load date in the last load date table")
    insert_query = f"INSERT INTO flipt_dw.dw_load_date (table_name, table_last_load_date) values " \
        f"('flipt_dw.dw_claims', '{to_date}')"
    logger.info(f"Insert query for last load date: {insert_query}")
    cur = con.cursor()
    try:
        cur.execute(insert_query)
        con.commit()
    except Exception as e:
        logger.error(f"Error while updating the last load date: {insert_query}. ERROR: {e}")

    return from_date, to_date


def get_inseted_record_count(query_range, con):
    logger.info("Checking the total records inserted into redshift")
    query = f"select count(*) from flipt_dw.dw_claims where {query_range}"
    cur = con.cursor()
    try:
        logger.info(f"Executing the count query: {query}")
        cur.execute(query)
    except Exception as e:
        logger.error(f"Exception occurred for count query: {query}")
    return cur.fetchall()[0][0]


def insert_into_redshift(row_list, con):
    logger.info("Inserting the data into redshift")
    table_name = 'flipt_dw.dw_claims'
    cur = con.cursor()
    for i, row in enumerate(row_list):
        columns = ','.join(list(row.keys()))
        vals = ','.join(list(map(lambda x: f"'{x}'" if x else "NULL", row.values())))
        insert_stmt = f'INSERT INTO {table_name} ({columns}) VALUES ({vals})'
        try:
            cur.execute(insert_stmt)
            print(i)
            con.commit()
        except Exception as e:
            logger.info(f"auth_id :{row['auth_id']}, {row['sequenceNumber']}")
            logger.info(str(e), insert_stmt)

def move_processed_claims(con, from_date, to_date):
    dest_cols = ['account', 'amt_paid_to_pharmacy', 'auth_id', 'basis_of_cost_determination', 'benefit_plan_name',
                 'bin', 'calculated_disp_fee', 'calculated_gross_due', 'calculated_ing_cost', 'calculated_sales_tax',
                 'carrier', 'claim_date', 'claim_override_flag', 'claim_status', 'claim_type', 'client_copay',
                 'client_deductible', 'client_disp_fee', 'client_due_amt', 'client_employee_paid', 'client_ing_cost',
                 'client_paid_amt', 'client_sales_tax', 'compound_drug_flag', 'compound_ind', 'date_of_prescription',
                 'date_of_service', 'daw_code', 'days_supply', 'disp_fee_paid', 'drug_name', 'drug_strength', 'enddate',
                 'erx_transaction_id', 'fill_date', 'fill_number', 'flipt_auth_id', 'generic_brand_ind', 'gpi_code',
                 '"group"', 'ing_cost_paid', 'load_date', 'manuf_abr', 'member_id', 'member_relationship',
                 'multisource_code', 'otc_indicator', 'other_coverage_code', 'pack_size', 'patient_paid',
                 'payer_auth_id', 'payer_name', 'pcn', 'person_code', 'pharmacy_chain', 'pharmacy_name', 'pharmacy_npi',
                 'preganancy_indicator', 'prescriber_first_name', 'prescriber_last_name', 'prescriber_npi',
                 'prescription_origin_code', 'product_id_ndc', 'product_name_full', 'quantity_dispensed', 'rel_code',
                 'response_disc_fee', 'response_gross_due', 'response_ing_cost', 'response_sales_tax',
                 'rx_alternate_drug_reward', 'rx_alternate_penalty', 'rx_dispensing_fee', 'rx_domain', 'rx_drug_cost',
                 'rx_employee_opc', 'rx_employer_cost', 'rx_number', 'rx_pa_flag', 'rx_penalty', 'rx_prescription_id',
                 'rx_quantity', 'rx_rebate_amount', 'rx_rebate_factor', 'rx_rewards', 'rx_unit_price',
                 'rx_unit_price_before_rebate', 'sales_tax_paid', 'startdate', '"status"',
                 'submission_clarification_code', 'submission_clarification_count', 'submitted_date',
                 'submitted_disp_fee', 'submitted_dispensing_fee', 'submitted_gross_due', 'submitted_ing_cost',
                 'submitted_sales_tax', 'submitted_time', 'submitted_uc', 'submitted_usual_and_customary_ams',
                 'total_amount_paid', 'transfer_bin', 'transfer_pcn', 'written_date', 'submitted_total_amount',
                 'total_reward', 'rx_flipt_person_id', 'sequence_number']

    query_condition = (f"startDate>'{from_date}' and startDate<'{to_date}' and "
                       f"claim_status in ('P', 'X')")
    query = f'''INSERT INTO flipt_dw.dw_processedclaims ({','.join(dest_cols)})
    select "domain", client_employer_cost, CAST (auth_id as int), 
    request_basis_of_cost_determination, benefit_plan_name, request_bin_number, 
    calculated_disp_fee, 
    calculated_employer_cost, calculated_ing_cost, response_flat_sales_tax_amount_paid, 
    'FLIPT' as flipt, TO_DATE(TO_DATE(request_date_of_service, 'YYYYmmDD'),'YYYY-MM-DDT00:00:00.000000'), 
    over_ride, claim_status, request_transaction_code, 
    client_employee_paid, client_deductible, client_disp_fee_paid, client_employer_cost, 
    client_employee_paid, client_ing_cost, client_employer_cost,
    response_patient_sales_tax_amount, request_compound_code, request_compound_code, 
    request_date_prescription_written, 
    TO_DATE(TO_DATE(request_date_of_service,'YYYYmmDD'), 'YYYY-MM-DDT00:00:00.000000'), 
    request_product_selection_code, request_days_supply, 
    client_disp_fee_paid, drug_name, drug_strength, endDate, transactionId, 
    TO_DATE(TO_DATE(request_date_of_service,'YYYYmmDD'), 'YYYY-MM-DDT00:00:00.000000'), 
    request_fill_number, auth_id, brand_generic, request_gpi, request_group_id, 
    client_ing_cost, CURRENT_DATE, drug_manufacturer,
    request_cardholder_id, request_person_code, multi_source, otc_indicator, 
    request_other_coverage_code, package_size, client_employee_paid, payer_authid,
    claims_processor, request_processor_control_number, request_person_code, 
    pharmacy_chain_code, pharmacy_name, request_service_provider_id, 
    request_pregnancy_indicator, request_prescriber_first_name, request_prescriber_last_name, 
    request_prescriber_id, request_prescription_origin_code,
    request_product_id, drug_name, request_quantity_dispensed, request_person_code, 
    client_disp_fee_paid, client_employer_cost, client_ing_cost,
    response_flat_sales_tax_amount_paid, alternative_drug_rewards, alternate_penalty, 
    pharmacy_dispensing_fee, "domain", calculated_drug_cost,
    employee_opc, calculated_employer_cost, prescription_id, pa_flag, drug_penalty, prescription_id, 
    request_quantity_dispensed, rebate_amount, rebate_factor, rewards, unit_price, 
    unit_price_before_rebate, response_flat_sales_tax_amount_paid, 
    startdate, claim_status, request_submission_clarification_code, 
    request_submission_clarification_code_count, request_date_of_service, 
    request_dispensing_fee_submitted, request_dispensing_fee_submitted, submitted_drug_cost, 
    submitted_ing_cost, request_percentage_sales_tax_amount_submitted, 
    startdate, unc_drug_cost, unc_drug_cost, client_employer_cost, transferrequest_bin_number, 
    transferrequest_processor_control_number, request_date_prescription_written, submitted_drug_cost, total_reward, 
    CAST (request_cardholder_id AS INT), sequencenumber
    FROM
    flipt_dw.dw_claims
    WHERE {query_condition};'''
    logger.info(f"Insert statement for processed claims {query}")
    cur = con.cursor()
    try:
        cur.execute(query)
    except Exception as e:
        logger.info(str(e), query)
    con.commit()


cb = cb_authenticate()
con = redshift_con()
last_load_date = get_last_load_date(con)
from_date, to_date = extract_claims_frm_cb('claim', cb, last_load_date, con)
# get_auth_seq = get_final_claims(con, from_date, to_date)
move_processed_claims(con, from_date, to_date)
