########################################
# !/usr/bin/env python  
# title         :populate_dtmsmedspan.py
# description   : load DUR from medispan to redshift table
# author        : Pal
# date created  : 20190704
# date last modified    : 
# version       : 0.1
# maintainer    : 
# email         : -
# status        : Development
# Python Version: 3.5.X
# usage         : python populate_dtmsmedspan.py -t dtms
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#                          
# #######################################


from zipfile import ZipFile 
import pandas as pd
import os, traceback, sys, re
import psycopg2
import getopt
import logging
import s3fs
import sendgrid
import boto3, io
from sendgrid.helpers.mail import *
from datetime import datetime

logging.basicConfig(level=logging.INFO)
LOG = logging.getLogger('get records from medispan and insert into tables in redshift')

def send_email(filename, subject='', content=''):
    sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))
    from_email = Email("noreply@fliptrx.com")
    to_email = Email("fliptintegration@fliptrx.com")
    if subject == '': subject = "ERROR:"+dbname+" :"+host+" :"+ filename+" load failed"
    if content == '': content = Content("text/plain", "ERROR:"+dbname+" :"+host+" :"+ filename+" load failed")
    mail = Mail(from_email, subject, to_email, content)
    response = sg.client.mail.send.post(request_body=mail.get())
    print(response.status_code)
    print(response.body)
    print(response.headers)



dbname = os.environ['RDS_DBNAME']
host = os.environ['RDS_SERVER']
prt = os.environ['RDS_PORT']
usr = os.environ['RDS_USERID']
passwd = os.environ['RDS_PWD']
table_prefix = os.environ['RDS_DBNAME_EXTN']
aws_s3_url = os.environ['S3_RDS_URL']
bkt = os.environ['S3_RDS_BUCKET']

aws_access_key=os.environ['S3_RDS_PUB_KEY_ID']
secret_access_key=os.environ['S3_RDS_PRIV_KEY_ID']
tablename = ''
print("dbname={} host={} port={} user={} password={}".format(dbname, host, prt, usr, passwd))
conn = psycopg2.connect("dbname={} host={} port={} user={} password={}".format(dbname, host, prt, usr, passwd))
cur = conn.cursor()


def truncate_table(tablename):
    try:
        com_trun = ("TRUNCATE {};".format(table_prefix+".dw_"+tablename))
        cur.execute(com_trun)
        conn.commit()
    except Exception as e: 
        LOG.info(traceback.format_exc())
        executionstatus='Failure'
        send_email(tablename)

def loaddata(tablename):
    try: 
        command_tb = ("copy {} from '{}'\
                    CREDENTIALS 'aws_access_key_id={};aws_secret_access_key={}' \
                     removequotes delimiter ',';"\
                    .format(table_prefix+".dw_"+tablename, aws_s3_url+'DTMS/'+tablename+".csv",aws_access_key,secret_access_key))
        
        # print(command_tb)
        cur.execute(command_tb)
        conn.commit()
    except Exception as e:
        print(traceback.format_exc())
        executionstatus='Failure'
        send_email(tablename)

def fn_load_DTMSDrugFormulation(zip_files, tablename):
    try:
        
        list_of_all_rows = []
        data=str(zip_files.read('DTMSV22/USAENG/DB/DTMS'))[:-1].strip()
        for columns in data.split("\\n"):
            lst_row = []
            columns = columns.replace('b\'', '')
            if columns == '': continue
            if (re.match('^D01',  str(columns)) or re.match('^D02',  str(columns))) and columns[3:4].strip() == '1':
                str_kdc1=columns[4:9].strip()
                str_classnum=columns[11:16].strip()
                str_ingred_kdc1=columns[19:24].strip()
                str_ingred_kdc2=columns[24:26].strip()
                
                str_create_date=datetime.now()
                str_update_date=datetime.now()

                lst_row.append(str_kdc1)
                lst_row.append(str_classnum)
                lst_row.append(str_ingred_kdc1)
                lst_row.append(str_ingred_kdc2)
                lst_row.append(str_create_date)
                lst_row.append(str_update_date)

                list_of_all_rows.append(lst_row)
        
        df_DDADPP=pd.DataFrame(list_of_all_rows,columns=['kdc1','classnum','ingred_kdc1','ingred_kdc2','create_date','update_date'])
        
        # print(df_DDADPP)
        s3 = s3fs.S3FileSystem(anon=False, key = aws_access_key, secret = secret_access_key)
        with s3.open(bkt+'/DTMS/'+tablename+'.csv','w') as f:
            df_DDADPP.to_csv(f, header=False, index =False, encoding ='utf-8')
        loaddata(tablename)
        LOG.info("======records inserted successfully")
    except Exception as e: 
        LOG.info(traceback.format_exc())
        executionstatus='Failure'
        return executionstatus

def fn_load_DTMSDrugNameIndex(zip_files, tablename):
    try:
        
        list_of_all_rows = []
        data=str(zip_files.read('DTMSV22/USAENG/DB/DTMS'))[:-1].strip()
        for columns in data.split("\\n"):
            lst_row = []
            columns = columns.replace('b\'', '')
            if columns == '': continue
            if re.match('^I02',  str(columns)):
                str_type=columns[0:3]
                str_stype=columns[3:4]
                str_kdc1=columns[4:9]
                str_kdc2=columns[9:11]
                str_kdc3=columns[11:14]
                str_actcode=columns[14:15]
                str_route=columns[15:17]
                str_needname=columns[28:29]
                str_nametype=columns[29:30]
                str_name=columns[30:80]
                str_create_date=datetime.now()            
                str_update_date=datetime.now() 

                lst_row.append(str_kdc1)

                lst_row.append(str_kdc2)
                lst_row.append(str_kdc3)
                lst_row.append(str_actcode)
                lst_row.append(str_route)
                lst_row.append(str_needname)
                lst_row.append(str_nametype)
                lst_row.append(str_name)
                lst_row.append(str_create_date)
                lst_row.append(str_update_date)
                list_of_all_rows.append(lst_row)
           
        df_DDADTXT=pd.DataFrame(list_of_all_rows,columns=['kdc1','kdc2','kdc3','actcode','route','needname','nametype','name','create_date','update_date'])
        # print(df_DDADTXT)
        s3 = s3fs.S3FileSystem(anon=False, key = aws_access_key, secret = secret_access_key)
        with s3.open(bkt+'/DTMS/'+tablename+'.csv','w') as f:
            df_DDADTXT.to_csv(f, header=False, index =False, encoding ='utf-8')
        loaddata(tablename)
        LOG.info("======records inserted successfully")
    except Exception as e: 
        LOG.info(traceback.format_exc())
        executionstatus='Failure'
        return executionstatus
def fn_load_DTMSDrugNames(zip_files, tablename):
    try:
        
        list_of_all_rows = []
        data=str(zip_files.read('DTMSV22/USAENG/DB/DTMS'))[:-1].strip()
        for columns in data.split("\\n"):
            lst_row = []
            columns = columns.replace('b\'', '')
            if columns == '': continue
            if re.match('^N01',  str(columns)):
                str_drug_name=columns[11:61]
                str_kdc1=columns[3:8]
                str_kdc2=columns[8:10]
                str_create_date=datetime.now()
                str_update_date=datetime.now()

                lst_row.append(str_drug_name)
                lst_row.append(str_kdc1)
                lst_row.append(str_kdc2)
                lst_row.append(str_create_date)
                lst_row.append(str_update_date)

                list_of_all_rows.append(lst_row)
        
        df_DDARTE=pd.DataFrame(list_of_all_rows,columns=['drug_name','kdc1','kdc2','create_date','update_date'])
        # print(df_DDARTE)
        
        s3 = s3fs.S3FileSystem(anon=False, key = aws_access_key, secret = secret_access_key)
        with s3.open(bkt+'/DTMS/'+tablename+'.csv','w') as f:
            df_DDARTE.to_csv(f, header=False, index =False, encoding ='utf-8')
        loaddata(tablename)
        
        LOG.info("======records inserted successfully")
    except Exception as e: 
        LOG.info(traceback.format_exc())
        executionstatus='Failure'
        return executionstatus
def fn_load_DTMSInteractingDrugs(zip_files, tablename):
    try:
        
        list_of_all_rows = []
        data=str(zip_files.read('DTMSV22/USAENG/DB/DTMS'))[:-1].strip()
        datalist = data.split("\\n")
        for idx,columns in enumerate(datalist):
            
            lst_row = []
            columns = columns.replace('b\'', '')
            if columns == '': continue
            if re.match('^M01',  str(columns)) and columns[3:4].strip() == '3':
                
                previndex = idx-1
                prevcolumns = datalist[previndex]
                str_classnum1=''
                str_classnum2=''
                while previndex:
                    if re.match('^M01',str(prevcolumns)) and str(prevcolumns[3:4]).strip() == '1':
                        str_classnum1=str(prevcolumns[4:9]).strip()
                        str_classnum2=str(prevcolumns[23:28]).strip()
                        previndex = False
                    else:
                        previndex = previndex-1
                        prevcolumns = datalist[previndex]
                
                    
                str_reval=str(columns[4:5]).strip()
                str_kdc1=str(columns[5:10]).strip()
                str_kdc2=str(columns[10:12]).strip()
                str_create_date=datetime.now()
                str_update_date=datetime.now()

                lst_row.append(str_classnum1)
                lst_row.append(str_classnum2)
                lst_row.append(str_reval)
                lst_row.append(str_kdc1)
                lst_row.append(str_kdc2)
                lst_row.append(str_create_date)
                lst_row.append(str_update_date)

                list_of_all_rows.append(lst_row)
        
        df_DDAUOM = pd.DataFrame(list_of_all_rows, columns=['classnum1','classnum2','reval',
        'kdc1','kdc2','create_date','update_date'])
            
        # print(df_DDAUOM)
        s3 = s3fs.S3FileSystem(anon=False, key = aws_access_key, secret = secret_access_key)
        with s3.open(bkt+'/DTMS/'+tablename+'.csv','w') as f:
            df_DDAUOM.to_csv(f, header=False, index =False, encoding ='utf-8')
            
        loaddata(tablename)
        LOG.info("======records inserted successfully")
    except Exception as e: 
        LOG.info(traceback.format_exc())
        executionstatus='Failure'
        return executionstatus
def fn_load_DTMSInteraction(zip_files, tablename):
    try:
        
        list_of_all_rows = []
        
        data=str(zip_files.read('DTMSV22/USAENG/DB/DTMS'))[:-1].strip()
        datalist = data.split("\\n")
        for idx,columns in enumerate(datalist):
            # print(columns)
            lst_row = []
            columns = columns.replace('b\'', '').strip()
            if columns == '': continue
            # if re.match('^M01',  str(columns)) and columns[3:4].strip() == '9':
            if re.match('^M01',  str(columns)) and columns[3:4].strip() == '1':
                str_classnum1=columns[4:9].strip()
                str_duration1=columns[9:12].strip()
                str_schedule1=columns[12:15].strip()
                str_classnum2=columns[23:28].strip()
                str_duration2=columns[28:31].strip()
                str_schedule2=columns[31:34].strip()
                str_interaction_id=columns[38:42].strip()
                str_onset=columns[42:43].strip()
                str_severity=columns[43:44].strip()
                str_documentation=columns[44:45].strip()
                str_management=columns[45:46].strip()
                str_actcode1=columns[46:47].strip()
                str_actcode2=columns[47:48].strip()
                str_contraindication=columns[48:49].strip()
                str_interaction_type=columns[74:75].strip()
                
                nextindex = idx+1
                nextcolumns = datalist[nextindex]
                str_classname1=''
                str_classname2=''
                str_warning=''
                str_effects=''
                str_mechanism=''
                str_management_text=''
                str_discussion=''
                str_references=''

                while nextindex:
                    if re.match('^M01',str(nextcolumns)) and str(nextcolumns[3:4]).strip() == '9':
                        
                        if str(nextcolumns[4:7]).strip() == 'CN1':
                            str_classname1=str_classname1+str(nextcolumns[8:80]).strip()
                        elif str(nextcolumns[4:7]).strip() == 'CN2':
                            str_classname2=str_classname2+str(nextcolumns[8:80]).strip()
                        elif str(nextcolumns[4:7]).strip() == 'WAR':
                            str_warning=str_warning+str(nextcolumns[8:80]).strip()
                        elif str(nextcolumns[4:7]).strip() == 'EFF':
                            str_effects=str_effects+str(nextcolumns[8:80]).strip()
                        elif str(nextcolumns[4:7]).strip() == 'MEC':
                            str_mechanism=str_mechanism+str(nextcolumns[8:80]).strip()
                        elif str(nextcolumns[4:7]).strip() == 'MAN':
                            str_management_text=str_management_text+str(nextcolumns[8:80]).strip()
                        elif str(nextcolumns[4:7]).strip() == 'DIS':
                            str_discussion=str(nextcolumns[8:80]).strip()
                        elif str(nextcolumns[4:7]).strip() == 'REF':
                            str_references=str_references+str(nextcolumns[8:80]).strip()
                        
                        textcolumns = datalist[nextindex+1]
                        if re.match('^M01',str(textcolumns)) and str(textcolumns[3:4]).strip() == '9':
                            nextindex = nextindex+1
                            nextcolumns = datalist[nextindex]
                        else:
                            nextindex = False
                    else:
                        nextindex = nextindex+1
                        nextcolumns = datalist[nextindex]
                
                """
                str_classname1=columns[15:17].strip()
                str_classname2=columns[34:36].strip()
                str_warning=columns[50:54].strip()
                str_effects=columns[54:58].strip()
                str_mechanism=columns[58:62].strip()
                str_management_text=columns[62:66].strip()
                str_discussion=columns[66:70].strip()
                str_references=columns[70:74].strip()
                """
                str_report_test=' '

                str_create_date=datetime.now()
                str_update_date=datetime.now()

                lst_row.append(str_classnum1)
                lst_row.append(str_duration1)
                lst_row.append(str_schedule1)
                lst_row.append(str_classnum2)
                lst_row.append(str_duration2)
                lst_row.append(str_schedule2)
                lst_row.append(str_interaction_id)
                lst_row.append(str_onset)
                lst_row.append(str_severity)
                lst_row.append(str_documentation)
                lst_row.append(str_management)
                lst_row.append(str_actcode1)
                lst_row.append(str_actcode2)
                lst_row.append(str_contraindication)
                lst_row.append(str_interaction_type)
                lst_row.append(str_classname1)
                lst_row.append(str_classname2)
                lst_row.append(str_warning)
                lst_row.append(str_effects)
                lst_row.append(str_mechanism)
                lst_row.append(str_management_text)
                lst_row.append(str_discussion)
                lst_row.append(str_references)
                lst_row.append(str_report_test)

                lst_row.append(str_create_date)
                lst_row.append(str_update_date)

                list_of_all_rows.append(lst_row)

        df_DDAAUOM = pd.DataFrame(list_of_all_rows, columns=['classnum1', 'duration1','schedule1','classnum2', 'duration2','schedule2',
                'interaction_id','onset','severity','documentation','management', 'actcode1','actcode2','contraindication','interaction_type',
                'classname1','classname2','warning','effects','mechanism', 'management_txt', 'discussion','references', 'report_test','create_date','update_date'])
           
        # print(df_DDAAUOM)
        s3 = s3fs.S3FileSystem(anon=False, key = aws_access_key, secret = secret_access_key)

        with s3.open(bkt+'/DTMS/'+tablename+'.csv','w') as f:
            df_DDAAUOM.to_csv(f, header=False, index =False, encoding ='utf-8')
            
        loaddata(tablename)
        LOG.info("======records inserted successfully")
    except Exception as e: 
        LOG.info(traceback.format_exc())
        executionstatus='Failure'
        return executionstatus

def fn_load_DTMSNDCIndex(zip_files, tablename):
    try:
        
        list_of_all_rows = []
        data=str(zip_files.read('DTMSV22/USAENG/DB/DTMS'))[:-1].strip()
        for columns in data.split("\\n"):
            lst_row = []
            columns = columns.replace('b\'', '')
            if columns == '': continue
            if re.match('^I01',  str(columns)):
                
                str_type=columns[0:3].strip()
                str_stype=columns[3:4].strip()
                str_kdc1=columns[4:9].strip()
                str_kdc2=columns[9:11].strip()
                str_kdc3=columns[11:14].strip()
                str_actcode=columns[14:15].strip()
                str_route=columns[15:17].strip()
                str_ndc=columns[17:28].strip()
                
                str_create_date=datetime.now()
                str_update_date=datetime.now()
                
                lst_row.append(str_kdc1)
                lst_row.append(str_kdc2)
                lst_row.append(str_kdc3)
                lst_row.append(str_actcode)
                lst_row.append(str_route)
                lst_row.append(str_ndc)
                
                lst_row.append(str_create_date)
                lst_row.append(str_update_date)
                
                list_of_all_rows.append(lst_row)
        
        df_DDADOSE = pd.DataFrame(list_of_all_rows,columns=['kdc1','kdc2','kdc3','actcode','route','ndc','create_date','update_date'])
        # print(df_DDADOSE)
        s3 = s3fs.S3FileSystem(anon=False, key = aws_access_key, secret = secret_access_key)
        with s3.open(bkt+'/DTMS/'+tablename+'.csv','w') as f:
            df_DDADOSE.to_csv(f, header=False, index =False, encoding ='utf-8')
            
        loaddata(tablename)
        LOG.info("======records inserted successfully")
    except Exception as e: 
        LOG.info(traceback.format_exc())
        executionstatus='Failure'
        return executionstatus   

def fn_load_DTMSReactingDrugs(zip_files, tablename):
    try:
        
        list_of_all_rows = []
        data=str(zip_files.read('DTMSV22/USAENG/DB/DTMS'))[:-1].strip()
        datalist = data.split("\\n")
        for idx,columns in enumerate(datalist):
            lst_row = []
            columns = columns.replace('b\'', '')
            if columns == '': continue
            if re.match('^M02',  str(columns)) and columns[3:4].strip() == '2':
                # str_classnum1=columns[0:3].strip()
                # str_classnum2=columns[3:4].strip()

                previndex = idx-1
                prevcolumns = datalist[previndex]
                str_classnum1=''
                str_classnum2=''
                while previndex:
                    if re.match('^M02',str(prevcolumns)) and str(prevcolumns[3:4]).strip() == '1':
                        str_classnum1=str(prevcolumns[4:9]).strip()
                        str_classnum2=str(prevcolumns[9:14]).strip()
                        previndex = False
                    else:
                        previndex = previndex-1
                        prevcolumns = datalist[previndex]
                

                str_kdc1=columns[4:9].strip()
                str_kdc2=columns[9:11].strip()
                
                str_create_date=datetime.now()
                str_update_date=datetime.now()
                
                lst_row.append(str_classnum1)
                lst_row.append(str_classnum2)
                lst_row.append(str_kdc1)
                lst_row.append(str_kdc2)
                
                lst_row.append(str_create_date)
                lst_row.append(str_update_date)
                
                list_of_all_rows.append(lst_row)
           
        df_DDADOSE = pd.DataFrame(list_of_all_rows,columns=['classnum1','classnum2','kdc1','kdc2','create_date','update_date'])
        # print(df_DDADOSE)
        s3 = s3fs.S3FileSystem(anon=False, key = aws_access_key, secret = secret_access_key)
        with s3.open(bkt+'/DTMS/'+tablename+'.csv','w') as f:
            df_DDADOSE.to_csv(f, header=False, index =False, encoding ='utf-8')
            
        loaddata(tablename)
        LOG.info("======records inserted successfully")
    except Exception as e: 
        LOG.info(traceback.format_exc())
        executionstatus='Failure'
        return executionstatus   

def fn_load_DTMSReaction(zip_files, tablename):
    try:
        
        list_of_all_rows = []
        data=str(zip_files.read('DTMSV22/USAENG/DB/DTMS'))[:-1].strip()
        for columns in data.split("\\n"):
            lst_row = []
            columns = columns.replace('b\'', '')
            if columns == '': continue
            # if re.match('^M02',  str(columns)) and columns[3:4].strip() == '9':
            if re.match('^M02',  str(columns)) and columns[3:4].strip() == '1':
                str_classnum1=columns[4:9].strip()
                str_classnum2=columns[9:14].strip()
                str_symptom=columns[36:42].strip()
                str_classname1=columns[14:16].strip()
                str_classname2=columns[16:18].strip()
                str_prior_reaction=columns[18:22].strip()
                str_reacting_drug=columns[22:26].strip()
                str_discussion=columns[26:30].strip()
                str_references=columns[30:34].strip()
                str_text=columns[8:80].strip()
                str_create_date=datetime.now()
                str_update_date=datetime.now()
                
                lst_row.append(str_classnum1)
                lst_row.append(str_classnum2)
                lst_row.append(str_symptom)
                lst_row.append(str_classname1)
                lst_row.append(str_classname2)
                lst_row.append(str_prior_reaction)
                lst_row.append(str_reacting_drug)
                lst_row.append(str_discussion)
                lst_row.append(str_references)
                lst_row.append(str_text)
                
                lst_row.append(str_create_date)
                lst_row.append(str_update_date)
                
                list_of_all_rows.append(lst_row)
            
        df_DDADOSE = pd.DataFrame(list_of_all_rows,columns=['classnum1','classnum2','symptom','classname1','classname2',
        'prior_reaction','reacting_drug','discussion','references','text','create_date','update_date'])
        # print(df_DDADOSE)
        s3 = s3fs.S3FileSystem(anon=False, key = aws_access_key, secret = secret_access_key)
        with s3.open(bkt+'/DTMS/'+tablename+'.csv','w') as f:
            df_DDADOSE.to_csv(f, header=False, index =False, encoding ='utf-8')
            
        loaddata(tablename)
        LOG.info("======records inserted successfully")
    except Exception as e: 
        LOG.info(traceback.format_exc())
        executionstatus='Failure'
        return executionstatus   

def fn_load_DTMSRouteOfAdministration(zip_files, tablename):
    try:
        
        list_of_all_rows = []
        data=str(zip_files.read('DTMSV22/USAENG/DB/DTMS'))[:-1].strip()
        for columns in data.split("\\n"):
            lst_row = []
            columns = columns.replace('b\'', '')
            if columns == '': continue
            if re.match('^R01',  str(columns)):
                
                str_route=columns[7:9].strip()
                str_route_full_name=columns[10:80].strip()
                str_actcode=columns[5:6].strip()
                str_create_date=datetime.now()
                str_update_date=datetime.now()
                
                lst_row.append(str_route)
                lst_row.append(str_route_full_name)
                lst_row.append(str_actcode)
                
                lst_row.append(str_create_date)
                lst_row.append(str_update_date)
                
                list_of_all_rows.append(lst_row)
           
        df_DDADOSE = pd.DataFrame(list_of_all_rows,columns=['route','route_full_name','actcode','create_date','update_date'])
        # print(df_DDADOSE)
        s3 = s3fs.S3FileSystem(anon=False, key = aws_access_key, secret = secret_access_key)
        with s3.open(bkt+'/DTMS/'+tablename+'.csv','w') as f:
            df_DDADOSE.to_csv(f, header=False, index =False, encoding ='utf-8')
            
        loaddata(tablename)
        LOG.info("======records inserted successfully")
    except Exception as e: 
        LOG.info(traceback.format_exc())
        executionstatus='Failure'
        return executionstatus   


def fn_call_table(zip_files, tablename):
    try:
        LOG.info("======fn_call_table called here=======")
        if tablename == 'dtmsDrugFormulation':
            
            truncate_table(tablename)
            fn_load_DTMSDrugFormulation(zip_files, tablename)
        
        elif tablename == 'dtmsDrugNameIndex':
            
            truncate_table(tablename)
            fn_load_DTMSDrugNameIndex(zip_files, tablename)
        
        elif tablename == 'dtmsDrugNames':
            
            truncate_table(tablename)
            fn_load_DTMSDrugNames(zip_files, tablename)
        
        elif tablename == 'dtmsInteractingDrugs':
            
            truncate_table(tablename)
            fn_load_DTMSInteractingDrugs(zip_files, tablename)

        elif tablename == 'dtmsInteraction':
            
            truncate_table(tablename)
            fn_load_DTMSInteraction(zip_files, tablename)
        
        elif tablename == 'dtmsNDCIndex':
            
            truncate_table(tablename)
            fn_load_DTMSNDCIndex(zip_files, tablename)
            LOG.info("======fn_call_table end here")
        elif tablename == 'dtmsRouteOfAdministration':
            
            truncate_table(tablename)
            fn_load_DTMSRouteOfAdministration(zip_files, tablename)
            LOG.info("======fn_call_table end here")
        elif tablename == 'dtmsReactingDrugs':
            
            truncate_table(tablename)
            fn_load_DTMSReactingDrugs(zip_files, tablename)
            LOG.info("======fn_call_table end here")
        elif tablename == 'dtmsReaction':
            
            truncate_table(tablename)
            fn_load_DTMSReaction(zip_files, tablename)
            LOG.info("======fn_call_table end here")
    except Exception as e: 
        LOG.info(traceback.format_exc())
        executionstatus='Failure'
        return executionstatus

def delete_file_from_medispan(pfile_name):
    # LOG.info("")
    import os
    import ftplib
    from contextlib import closing
    import traceback

    host = os.environ['MEDISPAN_FTP_HOST']
    port = int(os.environ['MEDISPAN_FTP_PORT'])
    login = os.environ['MEDISPAN_FTP_USER']
    passwd = os.environ['MEDISPAN_FTP_PWD']
    try:
        LOG.info("======delete_file_from_medispan called here====")
        S3_path = bkt+'/DTMS/'
        with closing(ftplib.FTP()) as ftp:
            try:
                ftp.connect(host, port, 30*5) #5 mins timeout
                ftp.login(login, passwd)
                ftp.set_pasv(True)
                file_path = 'Medispan/'+login+'/'+pfile_name
                ftp.delete(file_path)
                print("%s is deleted successfully."%file_path)
            except Exception as e:
                print(traceback.format_exc())
                LOG.info(traceback.format_exc())
        LOG.info("======delete_file_from_medispan completed successfully====")
    except Exception as e:
        print(traceback.format_exc())
        LOG.info(traceback.format_exc())


def copy_from_medispan_to_S3():
    # LOG.info("")
    import os
    import ftplib
    from contextlib import closing
    import traceback

    host = os.environ['MEDISPAN_FTP_HOST']
    port = int(os.environ['MEDISPAN_FTP_PORT'])
    login = os.environ['MEDISPAN_FTP_USER']
    passwd = os.environ['MEDISPAN_FTP_PWD']
    try:
        LOG.info("======copy_from_medispan_to_S3 called here====")
        S3_path = bkt+'/DTMS/'
        with closing(ftplib.FTP()) as ftp:
            try:
                ftp.connect(host, port, 30*5) #5 mins timeout
                ftp.login(login, passwd)
                ftp.set_pasv(True)
                inner_path = 'Medispan/'+login
                ftp.cwd(inner_path)

                dir_list = []
                ftp.dir(dir_list.append)
                # print(dir_list)
                # print(dir_list)
                for line in dir_list:
                    orig_filename = line[29:].strip().split(' ')[-1]
                    # print(orig_filename)
                    if re.match('^DTMS',  str(orig_filename).upper()):
                        print(orig_filename)
                        s3 = s3fs.S3FileSystem(anon=False, key = aws_access_key, secret = secret_access_key)

                        with s3.open(S3_path+orig_filename,'wb') as f:
                            res = ftp.retrbinary('RETR %s' % orig_filename, f.write)

                            if not res.startswith('226 Transfer complete'):
                                print('Downloaded of file {0} is not compile.'.format(orig_filename))
                                # os.remove(orig_filename)
            except Exception as e:
                print(traceback.format_exc())
                LOG.info(traceback.format_exc())
        LOG.info("======copy_from_medispan_to_S3 end here====")
    except Exception as e: 
        LOG.info(traceback.format_exc())
        executionstatus='Failure'
        return executionstatus
        
def main():
    global LOG
    tablename = None
    print("main called")
    try:
        opts, args = getopt.getopt(sys.argv[1:], "-t:")
    except getopt.GetoptError:
        print('filetype.py -t <tablename>')
        LOG.info("filetype.py -t <tablename>")
        sys.exit(2)
		
    for opt, arg in opts:
        if opt in ("-t"):
            tablename = arg
	
    copy_from_medispan_to_S3()
    #fformat = logging.Formatter('%(tablename)s:%(levelname)s:%(message)s')
    logpath = os.environ['CB_DATA']+'//datawarehouse//log//log'+tablename+datetime.now().strftime("%Y%m%d%H%M") +'.txt'
    handler = logging.FileHandler(logpath)
    #handler.setFormatter(fformat)
    LOG.addHandler(handler)

    LOG.info("=========================================================")
    LOG.info("=============== Setup-Drop and create redshift tables ==============")
    file_name = ''
    try:
        doctype = ["dtmsDrugFormulation","dtmsDrugNameIndex","dtmsDrugNames","dtmsInteraction","dtmsInteractingDrugs","dtmsNDCIndex","dtmsReaction","dtmsReactingDrugs","dtmsRouteOfAdministration"]	
        list_of_all_rows = []
            
        session = boto3.session.Session(
            aws_access_key_id=aws_access_key, 
            aws_secret_access_key=secret_access_key
        )

        s3 = session.resource("s3")
        bucket = s3.Bucket(bkt)

        files_in_s3 = bucket.objects.all() 
        print(files_in_s3)

        for i in list(files_in_s3):
            print(i)
            
            if re.match('^DTMS\/DTMS',  str(i.key).upper()) and re.findall('CSV$',  str(i.key).upper()):
                # print("inner")
                i.delete()
            
            if re.match('^DTMS\/DTMS',  str(i.key).upper()):
                # print(i.key)
                obj = bucket.Object(i.key)

                with io.BytesIO(obj.get()["Body"].read()) as tf:

                    # rewind the file
                    tf.seek(0)

                    # Read the file as a zipfile and process the members
                    with ZipFile(tf, mode='r') as zip_files: 
                        #     zip_files.printdir()
                        print("zip file is opened")
                        try: 
                            
                            if tablename == 'dtmsAll':
                                print("All tables")
                                LOG.info("All tables")
                                for tablename in doctype:
                                    
                                    truncate_table(tablename)
                                    fn_call_table(zip_files, tablename)
                                
                            elif tablename not in doctype:
                                LOG.info("=============== the given table name is incorrect ==============")
                                executionstatus = "Failure"
                                send_email(tablename)
                            elif tablename in doctype:
                                truncate_table(tablename)
                                fn_call_table(zip_files, tablename)
                                
                        except Exception as e:            
                            LOG.info(traceback.format_exc())
                            executionstatus = "Failure"
                            send_email(tablename) 
                        
                        
                    #     print(df_DDAREAD.head(5))
                        print('Extracting the files now...')
                        print('Done!')
                # copy stuff to your destination here
                copy_source = {
                    'Bucket': bkt,
                    'Key': i.key
                }
                file_name = (i.key).split('/')[-1]
                destination_file_path = 'DTMS/Archive/'+(i.key).split('/')[-1]
                print(destination_file_path)
                s3.meta.client.copy(copy_source, bkt, destination_file_path)
                # then delete the source key
                # i.delete()
                for i in list(files_in_s3):
                    # delete all files other than archive folder inside DDA( Handle belo line carefully)
                    if re.match('DTMS\/',  i.key) and not re.match('DTMS\/Archive/',  i.key):
                        print(i.key)
                        i.delete()
                        # pass
                
                if file_name != '':
                    delete_file_from_medispan(file_name)
                
                f_name = 'populate_dtmsmedspan'
                success_subject = 'Success: Load records from medispan to redshift'
                success_content = Content("text/plain",'Success: Load records from medispan to redshift process completed successfully')
                send_email(f_name, success_subject, success_content) 
               
        else:
            f_name = 'populate_dtmsmedspan'
            success_subject = 'Failed: No records in medispan'
            success_content = Content("text/plain",'Failed: Input file is not found in medspan ftp location')
            send_email(f_name, success_subject, success_content) 
    
    except Exception as e:            
        LOG.info(traceback.format_exc())
        executionstatus = "Failure"
        send_email(tablename) 

if __name__ == '__main__':
    sys.exit(main())