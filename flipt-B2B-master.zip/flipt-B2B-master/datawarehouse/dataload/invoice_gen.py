import logging
import os
from datetime import datetime, timedelta
from optparse import OptionParser

import pandas as pd
import psycopg2

from aetna.dynamic_sftp import sftptransfer

path = os.environ['CB_DATA']
log_path = path + '/log'

now_dt_obj = datetime.now()
now = now_dt_obj.strftime("%d-%m-%Y-%H:%M:%S")



def rd_conn():
    dbname = os.environ['RDS_DBNAME']
    logger.info(f"Establishing connection with redshift in env {dbname}")
    user = os.environ['RDS_USERID']
    password = os.environ['RDS_PWD']
    host = os.environ['RDS_SERVER']
    port = os.environ['RDS_PORT']
    conn_string = f"dbname='{dbname}' port={port} user='{user}' password='{password}' host='{host}'"
    return psycopg2.connect(conn_string)

def gen_invoice_num():
    table_name = "flipt_dw.dw_pclaim_invoice"
    con = rd_conn()
    cur = con.cursor()
    get_invoice_num = (f"select max(invoice_number) from {table_name}")
    cur.execute(get_invoice_num)
    invoice_num = cur.fetchall()[0][0]
    invoice_num = invoice_num+1
    return invoice_num
def main(domain, from_date, to_date, invoice_num):
    table_name = "flipt_dw.dw_processedclaims"

    query = (f"select auth_id, sequence_number from {table_name} where startdate>='{from_date}' and startdate<='{to_date}' and "
             f"claim_status in ('P', 'X') and auth_id not in ('1975','1991','1755')")
    query = f"{query} and rx_domain='{domain.upper()}'" if domain else query
    con = rd_conn()
    cur = con.cursor()
    logger.info(f"Select query for extracting claims form dw_claims table: {query}")
    cur.execute(query)
    table_rows = cur.fetchall()
    query_filter = map(lambda x: f"(auth_id={x[0]} and sequence_number={x[1]})", table_rows)
    query_filter = " or ".join(query_filter)
    from datetime import datetime
    now = datetime.strftime(datetime.now(), "%Y%m%d")

    update_processed_clais_query = f"update flipt_dw.dw_processedclaims " \
        f"set invoice_number='{int(str(invoice_num))}', " \
        f"new_startdate='{from_date}', " \
        f"new_enddate='{to_date}', claims_invoice_date='{now}' " \
        f"where {query_filter}"
    cur.execute(update_processed_clais_query)
    con.commit()
    for auth_id, seq_number in table_rows:
        insert_into_invoice = f"insert into flipt_dw.dw_pclaim_invoice " \
        f"(rx_domain, new_startdate, new_enddate, auth_id, sequence_number, invoice_number) values " \
        f"('{domain}', '{from_date}', '{to_date}', '{auth_id}', '{str(seq_number)}',{invoice_num})"
        cur.execute(insert_into_invoice)
        con.commit()
    return invoice_num, from_date, to_date
def generate_invoice_file(domain,invoice_num, from_date, to_date):
    table_name = "flipt_dw.dw_processedclaims"
    con = rd_conn()
    cur = con.cursor()
    headers = ['claims_invoice_date', 'invoice_number', 'claim_start_date', 'claim_end_date', 'claim_date',
            'flipt_auth_id', 'payer_auth_id', 'erx_transaction_id', 'payer_name', 'claim_status',
            'ing_cost_paid', 'disp_fee_paid', 'patient_paid', 'total_reward', 'plan_sponsor_cost',
            'domain']
    query = f"select claims_invoice_date as claims_invoice_date, " \
        f"invoice_number as invoice_number, " \
        f"startdate as claim_start_date, " \
        f"enddate AS claim_end_date," \
        f"startdate AS claim_date," \
        f"auth_id AS flipt_auth_id," \
        f"payer_auth_id as payer_auth_id," \
        f"erx_transaction_id as erx_transaction_id," \
        f"payer_name  as payer_name," \
        f"claim_status as claim_status," \
        f"client_ing_cost as ing_cost_paid," \
        f"client_disp_fee as disp_fee_paid," \
        f"patient_paid as patient_paid," \
        f"total_reward as total_reward," \
        f"client_due_amt as plan_sponsor_cost," \
        f"account as domain from {table_name} where " \
        f"account = '{domain}' and " \
        f"invoice_number = {invoice_num} and " \
        f"new_startdate = '{from_date}' and " \
        f"new_enddate= '{to_date}'"
    cur.execute(query)
    data = cur.fetchall()
    df = pd.DataFrame(data, columns=headers)
    df['claims_invoice_date'] = df['claims_invoice_date'].apply(
        lambda x: datetime.strptime(x, "%Y%m%d").strftime("%m/%d/%Y") if x else x)
    filename = os.path.join(path, f'Claims_Invoice_{domain.upper()}_{datetime.now().strftime("%Y-%m-%d")}.csv')
    df.to_csv(filename, index=False)
    DEFAULT_SFTP_PORT = '22'
    status = sftptransfer(source=filename,
                          destination=f'/l_download/{os.path.basename(filename)}',
                          mode='PUT',
                          ftphost=os.environ['SFTP_ORACLE_HOST'],
                          ftpuser=os.environ['SFTP_ORACLE_USERNAME'],
                          ftppwd=os.environ['SFTP_ORACLE_PASSWORD'],
                          port=DEFAULT_SFTP_PORT)
    if status != 'S':
        print(f"Upload failed for {filename}")
def get_from_to_dates(domain):
    from_date, to_date = '', ''
    if domain.upper() == 'GWLABS001':
        from_date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%dT00:00:00:000000')
        to_date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%dT23:59:59:999999')
    elif domain.upper() == 'FLIPT001':
        from_date = (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%dT00:00:00:000000')
        to_date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%dT23:59:59:999999')
    elif domain.upper() == 'ACS001':
        from_date = (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%dT00:00:00:000000')
        to_date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%dT23:59:59:999999')
    return from_date, to_date

if __name__ == '__main__':
    parser = OptionParser()
    parser.add_option("-d", "--domain", dest="domain", help="pass in domain (company)")
    parser.add_option("-f", "--from_date", dest="from_date", help="from date(yyyy-mm-dd)")
    parser.add_option("-t", "--to_date", dest="to_date", help="to date(yyyy-mm-dd)")
    options, args = parser.parse_args()
    options.domain = options.domain.upper()
    # add new logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    fh = logging.FileHandler(f'{path}/ETL/log/invoice_gen_log_{options.domain}-{now}.log')
    fh.setLevel(logging.DEBUG)

    formatter = logging.Formatter('%(name)s - %(asctime)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)

    logger.addHandler(fh)
    logger.info(f"Received input from the user for domain: {options.domain}, from_date:{options.from_date}, "
                f"to_date{options.to_date}")
    invoice_num = gen_invoice_num()
    if options.from_date == options.to_date == None:
        options.from_date, options.to_date = get_from_to_dates(options.domain)
    main(options.domain, options.from_date, options.to_date, invoice_num)
    generate_invoice_file(options.domain, invoice_num, options.from_date, options.to_date)
