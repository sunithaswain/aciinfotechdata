########################################
# !/usr/bin/env python  
# title         :populate_dosage.py
# description   : load dosage redshift table
# author        : 
# date created  : 20191007
# date last modified    : 
# version       : 0.1
# maintainer    : 
# email         : -
# status        : Development
# Python Version: 3.5.X
# usage         : python populate_dosage.py -t dosage
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#                          
# #######################################

import pandas as pd
import os, traceback, sys, re
import psycopg2
import getopt
import logging
import s3fs
import sendgrid
import boto3, io
from sendgrid.helpers.mail import *
from datetime import datetime

logging.basicConfig(level=logging.INFO)
LOG = logging.getLogger('get records from s3 and insert into dosage table in redshift')

def send_email(filename, subject='', content=''):
    sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))
    from_email = Email("noreply@fliptrx.com")
    to_email = Email("fliptintegration@fliptrx.com")
    if subject == '': subject = "ERROR:"+dbname+" :"+host+" :"+ filename+" load failed"
    if content == '': content = Content("text/plain", "ERROR:"+dbname+" :"+host+" :"+ filename+" load failed")
    mail = Mail(from_email, subject, to_email, content)
    response = sg.client.mail.send.post(request_body=mail.get())
    print(response.status_code)
    print(response.body)
    print(response.headers)

dbname = os.environ['RDS_DBNAME']
host = os.environ['RDS_SERVER']
prt = os.environ['RDS_PORT']
usr = os.environ['RDS_USERID']
passwd = os.environ['RDS_PWD']
table_prefix = os.environ['RDS_DBNAME_EXTN']
aws_s3_url = os.environ['S3_RDS_URL']
bkt = os.environ['S3_RDS_BUCKET']

aws_access_key=os.environ['S3_RDS_PUB_KEY_ID']
secret_access_key=os.environ['S3_RDS_PRIV_KEY_ID']
Reg = os.environ['S3_REGION']
s3 = boto3.client('s3',aws_access_key_id =aws_access_key ,aws_secret_access_key=secret_access_key, region_name=Reg)

tablename = ''
print("dbname={} host={} port={} user={} password={}".format(dbname, host, prt, usr, passwd))
conn = psycopg2.connect("dbname={} host={} port={} user={} password={}".format(dbname, host, prt, usr, passwd))
cur = conn.cursor()


def truncate_table(tablename):
    try:
        com_trun = ("TRUNCATE {};".format(table_prefix+".dw_"+tablename))
        cur.execute(com_trun)
        conn.commit()
    except Exception as e: 
        LOG.info(traceback.format_exc())
        executionstatus='Failure'
        send_email(tablename)

def loaddata(tablename):
    try: 
        command_tb = ("copy {} from '{}'\
                    CREDENTIALS 'aws_access_key_id={};aws_secret_access_key={}' \
                     removequotes delimiter ',';"\
                    .format(table_prefix+".dw_"+tablename, aws_s3_url+'MSDOSAGE/'+tablename+".csv",aws_access_key,secret_access_key))
        
        print(command_tb)
        cur.execute(command_tb)
        conn.commit()
    except Exception as e:
        print(traceback.format_exc())
        executionstatus='Failure'
        send_email(tablename)        

def main():
    global LOG
    tablename = None
    print("main called")
    try:
        opts, args = getopt.getopt(sys.argv[1:], "-t:")
    except getopt.GetoptError:
        print('filetype.py -t <tablename>')
        LOG.info("filetype.py -t <tablename>")
        sys.exit(2)
		
    for opt, arg in opts:
        if opt in ("-t"):
            tablename = arg
    truncate_table(tablename)
    s3.upload_file("datawarehouse/jsonpaths/dev/"+tablename+".csv",bkt,"MSDOSAGE/"+tablename+".csv")
    loaddata(tablename)
    #fformat = logging.Formatter('%(tablename)s:%(levelname)s:%(message)s')
    logpath = os.environ['CB_DATA']+'//datawarehouse//log//log'+tablename+datetime.now().strftime("%Y%m%d%H%M") +'.txt'
    handler = logging.FileHandler(logpath)
    #handler.setFormatter(fformat)
    LOG.addHandler(handler)

    LOG.info("=========================================================")
    LOG.info("=============== Setup-Drop and create redshift tables ==============")        


if __name__ == '__main__':
    sys.exit(main())