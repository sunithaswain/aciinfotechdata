########################################
# !/usr/bin/env python  
# title         :populate_processedclaims.py
# description   : populate the dw_processedClaims  redshift table
# author        : Soujanya Veerubhotla
# date created  : 20190503
# date last modified    : 
# version       : 0.1
# maintainer    : 
# email         : sveerubhotla@fliptrx.com
# status        : Development
# Python Version: 3.5.X
# usage         : python populate_processedclaims.py
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#                          
# #######################################



import os
import sys
import logging
import psycopg2
import getopt
import dateutil.parser
from datetime import datetime
import sendgrid
import os
from sendgrid.helpers.mail import *


logging.basicConfig(level=logging.INFO)
LOG = logging.getLogger('populate the dw_processedClaims  redshift table')


dbname = os.environ['RDS_DBNAME']
host = os.environ['RDS_SERVER']
prt = os.environ['RDS_PORT']
usr = os.environ['RDS_USERID']
passwd = os.environ['RDS_PWD']


conn = psycopg2.connect("dbname={} host={} port={} user={} password={}".format(dbname, host, prt, usr, passwd))
cur = conn.cursor()

def send_email(filename):
    sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))
    from_email = Email("noreply@fliptrx.com")
    to_email = Email("fliptintegration@fliptrx.com")
    subject = "ERROR:"+dbname+" :"+host+" :"+ filename+" setup failed"
    content = Content("text/plain", "ERROR:"+dbname+" :"+host+" :"+ filename+" load failed")
    mail = Mail(from_email, subject, to_email, content)
    response = sg.client.mail.send.post(request_body=mail.get())
    print(response.status_code)
    print(response.body)
    print(response.headers)


def executeScriptsFromFile(filename):
    try:
        fd = open(filename, 'r')
        sqlFile = fd.read()
        fd.close()

        sqlCommands = sqlFile.split(';')

        for command in sqlCommands:
            if command != "":
                print(command)
                cur.execute(command)
                conn.commit()
    except:
        executionstatus = 'Failure'
        send_email("Processedclaims")
        

def main():
    global LOG	
    #fformat = logging.Formatter('%(tablename)s:%(levelname)s:%(message)s')
    logpath = os.environ['CB_DATA']+'//datawarehouse//log//log_dw_processedClaims'+datetime.now().strftime("%Y%m%d%H%M") +'.txt'
    handler = logging.FileHandler(logpath)
    #handler.setFormatter(fformat)
    LOG.addHandler(handler)

    LOG.info("=========================================================")
    LOG.info("=============== populate the dw_processedClaims  redshift table ==============")
	
    try:
        executeScriptsFromFile("datawarehouse/dataload/populate_new_dw_processedclaims.sql")        
    except:
        executionstatus = 'Failure'
        send_email("Processedclaims")
    
    
    LOG.info("=========================================================")

if __name__ == '__main__':
    sys.exit(main())	