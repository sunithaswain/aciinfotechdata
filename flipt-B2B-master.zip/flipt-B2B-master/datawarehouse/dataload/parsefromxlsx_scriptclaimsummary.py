########################################
# !/usr/bin/env python  
# title         : parsefromxlsx_scriptclaimsummary.py
# description   : parse data from xlsx file- scriptclaimsummary and upload to s3
# author        : Soujanya Veerubhotla
# date created  : 20190509
# date last modified    : 
# version       : 0.1
# maintainer    : 
# email         : sveerubhotla@fliptrx.com
# status        : Development
# Python Version: 3.5.X
# usage         : python parsefromxlsx_scriptclaimsummary.py  -d GWLABS001 -t dailyclaim_reconciliation -f dummy -m DRAFT
# usage: -n dummy and -m mode are not used in this code but come with commandline function hence made static
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  1.0           sveerubhotla    12/6/2019   included commandline args      
# #######################################


import os
import sys
import time
import logging
#import re
import dateutil.parser as parser
import pandas as pd
import datetime
import s3fs
import sendgrid
import getopt
import os

import paramiko
rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']

logging.basicConfig(level=logging.INFO)
LOG = logging.getLogger('parse data from xlsx file- scriptclaimsummary and upload to s3')

aws_access_key=os.environ['S3_RDS_PUB_KEY_ID']
secret_access_key=os.environ['S3_RDS_PRIV_KEY_ID']
Reg = os.environ['S3_REGION']
bkt = os.environ['S3_RDS_BUCKET']

from sendgrid.helpers.mail import *
import time
from sclaimintegration.scriptclaimsftp import multiplefilesftptransfer
from utils import commandline


currentdate = datetime.datetime.now()





displaydatetime = currentdate.strftime("%Y%m%d%H%M")
domain,file_type,file_name,mode = commandline.main(sys.argv[1:])
#import pdb;pdb.set_trace()
remotepath = '/DailyReconciliation'
localpath = path+'/'+domain+'/'+file_type+'/'
transferstatus = ''

def send_email(filename):
    sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))
    from_email = Email("noreply@fliptrx.com")
    to_email = Email("fliptintegration@fliptrx.com")
    subject = "ERROR:"+ filename+" load failed"
    content = Content("text/plain", "ERROR:"+filename+" load failed")
    mail = Mail(from_email, subject, to_email, content)
    response = sg.client.mail.send.post(request_body=mail.get())
    print(response.status_code)
    print(response.body)
    print(response.headers)
    
def readfile():
    try:
        files =[]
    #import pdb;pdb.set_trace()
        files,transferstatus = multiplefilesftptransfer(remotepath,localpath, 'GET')
        print("transferstatus", transferstatus)
        print(files)
        return files
    except:
        executionstatus='Failure'
        send_email("Unable to read from excel file-scriptclaimsummary.xlsx")        

def main():
    global LOG	
    
    '''
    try:
        opts, args = getopt.getopt(sys.argv[1:], "d:t:n:m:")
    except getopt.GetoptError:
        print('filetype.py -d <domain> -t <file_type> -n <file_name> -m <mode: final/draft>')
        LOG.info("filetype.py -d <domain> -t <file_type> -n <file_name> -m <mode: final/draft>")
        sys.exit(2)
		
    for opt, arg in opts:
        if opt in ("-d"):
            domain = arg
        if opt in ("-t"):
            file_type = arg
        if opt in ("-n"):
            file_name = arg
        if opt in ("-m"):
            mode = arg    ''' 
    
    #fformat = logging.Formatter('%(tablename)s:%(levelname)s:%(message)s')
    logpath = os.environ['CB_DATA']+'//datawarehouse//log//log_dw_scriptclaimsummary'+currentdate.strftime("%Y%m%d%H%M") +'.txt'
    handler = logging.FileHandler(logpath)
    #handler.setFormatter(fformat)
    LOG.addHandler(handler)

    LOG.info("=========================================================")
    LOG.info("=============== parse data from xlsx file- scriptclaimsummary and upload to s3==============")
    
 
    #try:
    files = readfile()
    claimdf = pd.DataFrame()
    for fnm in files:
        #claimxlsxdf = pd.read_csv(localpath+fnm, sep = '|', header=0, usecols=range(0, 115))
        claimxlsxdf = pd.read_csv(localpath+fnm, sep = '|', header=0)
        print(claimxlsxdf.head(5))        
        claimdf = pd.DataFrame(data = None, index = range(len(claimxlsxdf)), columns = ["update_date","updated_by"])

        claimdf["claim_override_flag"] =  claimxlsxdf["PriorAuthNumber"]
        claimdf["auth_id"] =  claimxlsxdf["AuthorizationNumber"]
        claimdf["sequence_number"] = claimxlsxdf["ClaimSeqNumber"]
        #old claimdf["transaction_id"] = "prescription::"+str(claimxlsxdf["TransactionID"])
        claimdf["transaction_id"] = claimxlsxdf["TransactionID"].apply(lambda x: "prescription::"+str(x))
        claimdf["fill_number"] = claimxlsxdf["FillNumber"]
        claimdf["account"] = claimxlsxdf["AccountID"]
        claimdf["bin"] = claimxlsxdf["BinNumber"].apply(lambda x: str(x).zfill(6))
        claimdf["pcn"] = claimxlsxdf["PCN"]
        claimdf["carrier"] = claimxlsxdf["CarrierID"]
        claimdf["group"] = claimxlsxdf["GroupID"]
        claimdf["claim_date"] = claimxlsxdf["TimeItHappened"]
        claimdf["claim_type"] = claimxlsxdf["TransactionResponseStatus"]
        claimdf["member_id"] = claimxlsxdf["GroupMember"]
        claimdf["rx_number"] = claimxlsxdf["PrescriptionNumber"]
        claimdf["date_of_service"] = claimxlsxdf["DateOfService"]
        claimdf["days_supply"] = claimxlsxdf["DaySupply"]
        claimdf["amt_paid_to_pharmacy"] = claimxlsxdf["TotalCostPaid"]
        claimdf["awp_unit"] = claimxlsxdf["AWPUnit"]
        claimdf["client_disp_fee"] = claimxlsxdf["ClientDispFee"]
        claimdf["client_due_amt"] = claimxlsxdf["ClientDueAmt"]
        claimdf["client_ing_cost"] = claimxlsxdf["ClientIngCost"]
        claimdf["client_mac_price"] = claimxlsxdf["CltMAC"]
        claimdf["submitted_disp_fee"] = claimxlsxdf["SubmittedDispFee"]
        claimdf["submitted_gross_due"] = claimxlsxdf["SubmittedGrossDue"]
        claimdf["submitted_ing_cost"] = claimxlsxdf["SubmittedIngCost"]
        claimdf["submitted_sales_tax"] = claimxlsxdf["SubmittedTaxSales"]
        claimdf["submitted_uc"] = claimxlsxdf["SubmittedUandC"]
        claimdf["patient_paid"] = claimxlsxdf["PatientPay"]
        claimdf["disp_fee_paid"] = claimxlsxdf["DispFeePaid"]
        claimdf["ing_cost_paid"] = claimxlsxdf["IngCostPaid"]
        claimdf["sales_tax_paid"] = claimxlsxdf["SalesTxPd"]
        claimdf["formulary_status"] = claimxlsxdf["FormStatus"]
        claimdf["gpi_code"] = claimxlsxdf["GPICode"]
        claimdf["quantity_dispensed"] = claimxlsxdf["QuantityDispensed"]
        claimdf["pharmacy_mac_price"] = claimxlsxdf["PhrmMac"]
        claimdf["product_id_ndc"] = claimxlsxdf["ProductID"]
        claimdf["product_name_full"] = claimxlsxdf["ProductNameFull"]
        claimdf["manuf_abr"] = claimxlsxdf["ManufactNameAbr"]
        claimdf["multisource_code"] = claimxlsxdf["MultiSourceCode"]
        claimdf["network_id"] = claimxlsxdf["SuperNetworkID"]
        claimdf["otc_indicator"] = claimxlsxdf["OTCIndicator"]
        claimdf["person_code"] = claimxlsxdf["PatientPC"]
        claimdf["pharmacy_name"] = claimxlsxdf["PharmacyName"]
        claimdf["pharmacy_ncpdp"] = claimxlsxdf["PharmacyID"]
        claimdf["pharmacy_npi"] = claimxlsxdf["PharmacyNPI"]
        claimdf["pharmacy_rejection_reason"] = claimxlsxdf["RejectMessage2"]
        claimdf["prescriber_first_name"] = claimxlsxdf["PrescriberNameFirst"]
        claimdf["prescriber_last_name"] = claimxlsxdf["PrescriberNameLast"]
        claimdf["prescriber_npi"] = claimxlsxdf["PrescriberNPI"]
        claimdf["rel_code"] = claimxlsxdf["PatientRC"]
        claimdf["create_date"] = currentdate
        claimdf["message"]=''
        claimdf["status"]=''
        claimdf["Response_disc_fee"]=''
        claimdf["response_gross_due"]=''
        claimdf["response_ing_cost"]=''
        claimdf["response_sales_tax"]=''
        claimdf["calculated_disp_fee"]=''
        claimdf["calculated_gross_due"]=''
        claimdf["calculated_ing_cost"]=''
        claimdf["calculated_sales_tax"]=''
        claimdf["rx_flipt_person_id"]=''
        claimdf["created_by"] = "ScriptClaim"
        claimdf["type"] = "scriptclaimsummary"
        claimdf["updated_by"] = "ScriptClaim"





    claimdf = claimdf[["auth_id","sequence_number","transaction_id","fill_number","account", \
    "bin","pcn","carrier","group","claim_date", \
    "claim_type","member_id","rx_flipt_person_id","rx_number","date_of_service", \
    "days_supply","amt_paid_to_pharmacy","awp_unit","client_disp_fee","client_due_amt", \
    "client_ing_cost","client_mac_price","submitted_disp_fee","submitted_gross_due","submitted_ing_cost", \
    "submitted_sales_tax","submitted_uc","calculated_disp_fee","calculated_gross_due","calculated_ing_cost", \
    "calculated_sales_tax","Response_disc_fee","response_gross_due","response_ing_cost","response_sales_tax", \
    "patient_paid","disp_fee_paid","ing_cost_paid","sales_tax_paid","formulary_status", \
    "gpi_code","quantity_dispensed","pharmacy_mac_price","product_id_ndc","product_name_full", \
    "manuf_abr","message","multisource_code","network_id","otc_indicator", \
    "person_code","pharmacy_name","pharmacy_ncpdp","pharmacy_npi","pharmacy_rejection_reason", \
    "prescriber_first_name","prescriber_last_name","prescriber_npi","rel_code","status", \
    "type","create_date","created_by","update_date","updated_by","claim_override_flag"]]


    s3 = s3fs.S3FileSystem(anon=False, key = aws_access_key, secret = secret_access_key)

    with s3.open(bkt+'/claimdf.csv','w') as f:
        claimdf.to_csv(f, header=False, index =False, encoding ='utf-8')
    #except:
        #executionstatus = 'Failure'
        #send_email("Unable to upload to s3_scriptclaimsummary")
    
    
    LOG.info("=========================================================")

if __name__ == '__main__':
    
    sys.exit(main())	

