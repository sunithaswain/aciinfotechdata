# -*- coding: utf-8 -*-
########################################
# !/usr/bin/env python  
# title         : updateexpiredprescription.py
# description   : Update expired prescription such as rx status and cancel date and send push notifications which are going to expired
# author        : Disha
# date created  : 20180101
# date last modified    : 20190131
# version       : 0.1
# maintainer    : Pal
# email         : pmuthanai@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage         : python updateexpiredprescription.py -d GWLABS001 -t prescription -m DRAFT
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  1.1            Pal         20190131    Added mode support logic to load the data in database
#  
# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']
 
import pandas as pd
from datetime import datetime
import dateutil.parser
import json
from couchbase.n1ql import N1QLQuery
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
import os, re
import time
from utils import commandline
import sys
from couchbase import FMT_JSON
from utils.sendgridemail import email_log
import socket
from notification.pushnotif import send_push_message
from utils.truevault import User_Class
from utils.FliptConcurrent import concurrent

def sendpushnotif(data,days,msg):
	
	if 'flipt_person_id' in data:
		obj=User_Class(None,None)
		search_option={'full_document':True,'filter':{'flipt_person_id':{'type':'eq','value':data['flipt_person_id'],'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
		att,userid = obj.search_user(search_option)
		#print(att)
		if att!=None:
			if 'devices' in att:
				for i in att['devices']:
					extra = {'message':msg}
					#print(i)
					if 'token' in i: send_push_message(i['token'],msg,extra)
	
	else: return


domain,filetype,filename,mode=commandline.main(sys.argv[1:])
req=concurrent(sys.argv[0],sys.argv[1:])
cluster=Cluster(os.environ['CB_URL']+'?operation_timeout=2700')
auth=PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(auth)
bucket_name=os.environ['CB_INSTANCE']
cb=cluster.open_bucket(bucket_name)
query1=N1QLQuery('SELECT tonumber(rx_expiry_days) rx_expiry_days,enable_expiry_notification,tonumber(rx_expiry_notification_days) rx_expiry_notification_days FROM `'+bucket_name+'` WHERE type="domain" and domain=$dn',dn=domain)
query1.timeout=7200
expirydays,enablenotif,notifdays,msg='','','',''
cancelledpresc=pd.DataFrame()
for r in cb.n1ql_query(query1):
	expirydays=r['rx_expiry_days']
	enablenotif=r['enable_expiry_notification']
	notifdays=r['rx_expiry_notification_days']
print('Domain Name           :'+domain)
print('Number of Expiry Days :'+str(expirydays))
print(enablenotif)
if enablenotif.upper().strip()=='Y':
	query1=N1QLQuery('SELECT message FROM `'+bucket_name+'` WHERE type="displaymessage" and message_type="Rx Expiry Notification"')
	query1.timeout=7200

	for r in cb.n1ql_query(query1):
		msg=r['message']

query = N1QLQuery('update `'+bucket_name+'` set rx_status="Cancelled",cancelled_date=tostring(clock_local()) where type="prescription" and rx_status="Routed" and ((pharmacy in (select raw wl_name from `'+bucket_name+'` t1 where t1.type = "cp_pharmacy" and t1.pharmacytype != "RETAIL") and DATE_ADD_STR(routed_date, 14, "day") < clock_local()) or (pharmacy in (select raw wl_name from `'+bucket_name+'` t1 where t1.type = "cp_pharmacy" and t1.pharmacytype = "RETAIL") and DATE_ADD_STR(routed_date, $rxd, "day") < clock_local())) and (cancelled_date is missing or cancelled_date is not valued) returning *',rxd=int(expirydays))
for r in cb.n1ql_query(query):
	cancelledpresc=cancelledpresc.append(r[bucket_name],ignore_index=True)
if enablenotif.strip().upper()=='Y':
	query=N1QLQuery('Select distinct flipt_person_id from `'+bucket_name+'` where type="prescription" and rx_status="Routed" and ((pharmacy in (select raw wl_name from `'+bucket_name+'` t1 where t1.type = "cp_pharmacy" and t1.pharmacytype != "RETAIL") and DATE_FORMAT_STR(DATE_ADD_STR(routed_date, $rx1,"day"),"1111-11-11")=clock_local("1111-11-11")) or  (pharmacy in (select raw wl_name from `'+bucket_name+'` t1 where t1.type = "cp_pharmacy" and t1.pharmacytype = "RETAIL") and DATE_FORMAT_STR(DATE_ADD_STR(routed_date, $rxd, "day"),"1111-11-11")=clock_local("1111-11-11"))) and (cancelled_date is missing or cancelled_date is not valued)',rxd=int(expirydays-notifdays),rx1=int(int(14)-notifdays))
	# print(query)
	for r in cb.n1ql_query(query):
		print(r)
		if os.environ['INSTANCE_TYPE']=='PROD':
			sendpushnotif(r,expirydays-notifdays,msg)
print(str(len(cancelledpresc))+' prescriptions cancelled')
time_now = re.sub('[\s\-\:]', '', str(datetime.now()))
filepath=path+'/'+domain+'/'+filetype+'/cancelledprescriptions'+time_now+'.csv'
cancelledpresc.to_csv(filepath,index=False)
req.no_rec_received=len(cancelledpresc)
send_to='FliptIntegration@fliptrx.com'
host = socket.gethostname()
subject = 'Cancelled Prescriptions Report - '+host
email_log('DWagle@fliptrx.com',send_to,'deepthi.gollapudi@nttdata.com,dwagle@fliptrx.com',subject,['Cancelling expired prescriptions','Expired Prescription Exception'],filepath,True)
#os.remove(filepath)
req.close()


