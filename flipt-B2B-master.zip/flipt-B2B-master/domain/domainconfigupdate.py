
########################################
# !/usr/bin/env python  
# title         : domainconfigupdate.py
# description   : 
# author        : Disha
# date created  : 20180101
# date last modified    : 20190125
# version       : 0.1
# maintainer    : Pal
# email         : pmuthanai@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage         : python domainconfigupdate.py  -t domain_configuration -f DomainConfiguration08132018.xlsx -m DRAFT
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  1.1            Pal         20190125    Added mode support logic to load the data in database
#  
#  
# #######################################
if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']

import pandas as pd
from couchbase.n1ql import N1QLQuery
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
import os
from utils import commandline
import sys
from datetime import datetime
from couchbase import FMT_JSON
import json

dn,filetype,filename,mode=commandline.main(sys.argv[1:])
cluster=Cluster(os.environ['CB_URL']+'?operation_timeout=2700')
auth=PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(auth)
bucket_name=os.environ['CB_INSTANCE']
cb=cluster.open_bucket(bucket_name)


print(path+'/'+filetype+'/'+filename)
file_format = os.path.splitext(filename)[-1]
if file_format == ".csv":
	domain=pd.read_csv(path+'/'+filetype+'/'+filename)
else:
	domain=pd.read_excel(path+'/'+filetype+'/'+filename)
domain.fillna("",inplace=True)
#print(domain.head())
print("No of records in File "+ str(domain.shape[0]))
print(list(domain))
'''
query=N1QLQuery('SELECT * FROM `'+bucket_name+'` WHERE type="client_setting"')
ite=1
csvfile=pd.DataFrame()
query.timeout=360
for row in cb.n1ql_query(query):
	print(ite)
	ite=ite+1
	d=dict(row[os.environ['CB_INSTANCE']])
	if len(d['dropdownOptions'])==0: d['dropdownOptions']=""
	else: d['dropdownOptions']=','.join(x for x in d['dropdownOptions'])
	csvfile=csvfile.append(d,ignore_index=True)
writer = pd.ExcelWriter(os.environ['CB_DATA']+'//'+filetype+'//'+filename)
csvfile.to_excel(writer,'Sheet1',index=False)
writer.save()
'''
for i,r in domain.iterrows():

	docid=''
	'''
	query=N1QLQuery('SELECT META().id as id FROM `'+bucket_name+'` WHERE type="client-setting" and displayName=$dispname',dispname=str(r['displayName']).strip())
	
	query.timeout=300
	for rec in cb.n1ql_query(query):
		docid=rec['id']
	'''
	d={}
	
	for c in list(domain):
		d[c]=str(r[c]).strip()
	d['type']='client_setting'
	if d['dropdownOptions']!="":
		d['dropdownOptions']=d['dropdownOptions'].split(',')
	else: d['dropdownOptions']=[]
	if d['order'].isdigit():
		d['order']=int(d['order'])
	print(d)
	if mode.upper().strip()=='FINAL':
	    if docid=='':
		    docid=str(cb.counter('docid',delta=1).value)
		    print(docid)
		    #cb.upsert(docid,d, format=FMT_JSON)
		
	    else:
		    _=1
		    #cb.upsert(str(docid),d, format=FMT_JSON)
	else:
		print("Domain config update program is running in draft mode")
	
