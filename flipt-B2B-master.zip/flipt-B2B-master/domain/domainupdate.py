########################################
# !/usr/bin/env python
# title         : domainupdate.py
# description   : Update domain type documents
# author        : Disha
# date created  : 20180101
# date last modified    : 20190128
# version       : 0.1
# maintainer    : Pal
# email         : pmuthanai@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage         : python domainupdate.py  -t domain -f domain11122018.csv -m DRAFT
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  1.1            Pal         20190125    Added header
#  1.2			      		  201901	  Added new field additions
# 1.3 			Deepthi		  04292019	  No Code changes.Only input file changes
# #######################################



from couchbase import FMT_JSON
from datetime import datetime
import sys
import os
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Cluster
from couchbase.n1ql import N1QLQuery
from utils.helper_functions import *
import pandas as pd

cmdline_rec = process_cmdline()
bucket_name = os.environ['CB_INSTANCE']
cb = cb_authenticate()

path = os.environ['CB_DATA']
domain = pd.read_excel(f"{path}/{cmdline_rec['file_type']}/{cmdline_rec['file_name']}")
domain.fillna("", inplace=True)
domain['zip'] = domain['zip'].apply(lambda x: str(x).zfill(5))
query = N1QLQuery('SELECT META().id as id,domain,create_date FROM `' +
                  bucket_name+'` WHERE type="domain"')
query.timeout = 7200
meta_ids = []
domains = pd.DataFrame()
for r in cb.n1ql_query(query):
    meta_ids.append(r['id'])
    domains = domains.append(
        {'domain': r['domain'], 'create_date': r['create_date']}, ignore_index=True)

ite = -1
for idx, row in domain.iterrows():
    ite += 1
    domain_data = populate_dict(domain, row)

    domain_data['type'] = 'domain'
    domain_data['price_source'] = domain_data['price_source'].split(',')
    domain_data['payment_options'] = domain_data['payment_options'].split(',')
    domain_data['reward_options'] = domain_data['reward_options'].split(',')
    domain_data['reward_redemption_message'] = domain_data['reward_redemption_message'].split(',')
    domain_data['otc_price_source'] = domain_data['otc_price_source'].split(',')
    domain_data['updated_by'] = 'System'
    domain_data['created_by'] = 'System'
    if 'domain' in list(domains) and domain_data['domain'] in list(domains['domain']):
        domain_data['create_date'] = domains[domains['domain']==domain_data['domain']]['create_date'].values[0]
    else:
        domain_data['create_date'] = str(datetime.strptime(
            str(datetime.now()), "%Y-%m-%d %H:%M:%S.%f").isoformat())
    domain_data['update_date'] = str(datetime.strptime(
        str(datetime.now()), "%Y-%m-%d %H:%M:%S.%f").isoformat())

    if cmdline_rec['mode'].strip().lower() == 'final':
        if ite < len(meta_ids):
            cb.upsert(str(meta_ids[ite]), domain_data, format=FMT_JSON)
            print(f"Update done for domain: {domain_data['domain']}.")

        else:
            cb.upsert(str(cb.counter('docid', delta=1).value),
                      domain_data, format=FMT_JSON)
            print(f"record added for: {domain_data['domain']}")

# end function
