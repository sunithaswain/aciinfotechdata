#!/usr/bin/env python
########################################
# title         : domain_add.py
# description   : Update domain type documents
# author        : Disha
# date created  : 20180101
# date last modified    : 20190128
# version       : 0.1
# maintainer    : Pal
# email         : pmuthanai@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage         : python domain_add.py
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  1.1            Pal         20190125    Added header
#  1.2			      		  201901	  Added new field additions
# 1.3 			Deepthi		  04292019	  No Code changes.Only input file changes
# #######################################

from couchbase import FMT_JSON
from datetime import datetime
import sys
import os

from couchbase.n1ql import N1QLQuery
from utils.helper_functions import *
from pprint import pformat

cmdline_rec = process_alt_cmdline(additional=[['-s', '--source', 'source domain to copy information from', True],
                                              ['-n', '--target', 'new target domain for creation', True]])
bucket_name = os.environ['CB_INSTANCE']
cb = cb_authenticate()

path = os.environ['CB_DATA']
logger = setup_logging_path('DOMAIN', 'domain_add', 'DOMAIN')

query = N1QLQuery('SELECT META().id as id, * FROM `' + bucket_name +'` WHERE type="domain" ' +
                  'and domain="' + cmdline_rec['source'] + '" ')

logger.info(f"Adding new domain information for: {cmdline_rec['target']} - based on {cmdline_rec['source']}")
logger.info(f"1. query for source detail: {query.statement}")
query.timeout = 7200
record = cb.n1ql_query(query).get_single_result()

sub_record = record[bucket_name]

print(f"original source record < {cmdline_rec['source']}>:\n{pformat(sub_record)}\n")
logger.info(f"2. SOURCE record:\n{pformat(sub_record)}")

logger.info("3. update column information: ")
print("modifying fields: alt_penalty_share, alt_reward_share, alternate_penalty_max, alternate_reward_max, ")
print("\t\tcompanylegalname, domain, eligibility_mail_list, employer_penalty_factor, parentcompany, ")
print("\t\tpayment_options, reward_share, rewards_baseline_multiplier, + other fields")
sub_record['alt_penalty_share'] = '0'
sub_record['alt_reward_share'] = '0'
sub_record['alternate_penalty_max'] = '0'
sub_record['alternate_reward_max'] = '0'
sub_record['companylegalname'] = 'Advance Cardio Services'
sub_record['domain'] = 'ACS001'
sub_record['eligibility_mail_list'] = 'fliptintegration@fliptrx.com'
sub_record['employer_penalty_factor'] = '0'
sub_record['parentcompany'] = 'ACS'
sub_record['payment_options'] = ['Pay at Pharmacy']
sub_record['reward_share'] = '0'
sub_record['rewards_baseline_multiplier'] = '0'
sub_record['address1'] = '10800 N Congress Ave'
sub_record['city'] = 'Kansas City'
sub_record['no_alternatives'] = 'N'
sub_record['brand_covered_upto_generic_copay_flag'] = 'N'
sub_record['rewards_baseline_multiplier'] = '0'
sub_record['show_digital_card'] = 'Y'
sub_record['state'] = 'MO'
sub_record['zip'] = '64153'
sub_record['ftp_location'] = ''
sub_record['reward_options'] = ['Redeem Rewards via Amazon Gift Card']

# updated fields
sub_record['otc_drug_covered'] = 'N'
sub_record['otc_price_source'] = ['scriptclaim']
sub_record['phone'] = '866-522-2920'
sub_record['message'] = '866-522-2920'

# new field
sub_record['subscription_invoice_desc_line1'] = 'Base Service Fee'
sub_record['subscription_invoice_desc_line2'] = 'True Up Members'
sub_record['pepm_pmpm'] = 'PEPM'
sub_record['pepm_rate'] = '8'
sub_record['pmpm_rate'] = ''

print(f"4. Updated record information:\n{pformat(sub_record)}")
logger.info(f"4. update record for TARGET insertion:\n{pformat(sub_record)}")

query = N1QLQuery('SELECT count(*) as cnt FROM `' + bucket_name +'` WHERE type="domain" ' +
                  'and domain="' + cmdline_rec['target'] + '" ')
count_rec = cb.n1ql_query(query).get_single_result()['cnt']

if cmdline_rec['mode'].lower() == 'final':
    if count_rec == 0:
        sub_record['create_date'] = str(datetime.strptime(
            str(datetime.now()), "%Y-%m-%d %H:%M:%S.%f").isoformat())
        cb.upsert(str(cb.counter('docid', delta=1).value),
                                  sub_record, format=FMT_JSON)
        print(f"record added for: {cmdline_rec['target']}")

    else:  # record already present - get its metaid for updating
        sub_record['update_date'] = str(datetime.strptime(
            str(datetime.now()), "%Y-%m-%d %H:%M:%S.%f").isoformat())
        query = N1QLQuery('SELECT meta().id as id FROM `' + bucket_name + '` WHERE type="domain" ' +
                          'and domain="' + cmdline_rec['target'] + '" ')
        metaid = cb.n1ql_query(query).get_single_result()['id']

        cb.upsert(str(metaid), sub_record, format=FMT_JSON)
        print(f"Update done for domain: {cmdline_rec['target']}.")
else:
    print("Running in draft mode - no record updated/added")
