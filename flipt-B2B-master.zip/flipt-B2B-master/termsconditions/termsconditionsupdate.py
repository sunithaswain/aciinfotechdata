########################################
# !/usr/bin/env python  
# title         : termsconditionsupdate.py
# description   : Updates terms and conditions and hippa complaince details from input files into termsconditions documents in database
# author        : Disha
# date created  : 20180101
# date last modified    : 20180720 12:16
# version       : 0.1
# maintainer    : Pal
# email         : pmuthanai@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage         : python termsconditionsupdate.py -m DRAFT
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  0.1                          20190109    Add domain validation
# #######################################
 
import os
import codecs
import sys
from datetime import datetime
# import pprint

from couchbase.n1ql import N1QLQuery
from couchbase import FMT_JSON
import pandas as pd
from utils.helper_functions import *

from utils.sendgridemail import email_log

cmdline_rec = process_cmdline()
cb = cb_authenticate()
path = os.environ['CB_DATA']
logger = setup_logging_path('TERMSCONDITIONS', f'log{datetime.now().strftime("%Y%m%d%H%M")}', "TERMSCOND")

logger.info("="*60)
logger.info("=============== Terms and Conditions Update Log =================")
logger.info(f"Start time is {str(datetime.now())}")

def load_tandc():
        tandc_filenm = f"{path}/termsconditions/termsconditions.xlsx"
        tc = pd.read_excel(tandc_filenm)
        logger.info("Number of records in File " + str(tc.shape[0]))
        print("Number of records in File " + str(tc.shape[0]))

        domainlistfile = list(tc["domain_name"].values)
        print("Available domains in File ..." + ", ".join(domainlistfile))
        logger.info(f"Available domains in file: {domainlistfile}")

        domainquery = N1QLQuery('Select domain_name from `' + os.environ['CB_INSTANCE'] +
                                '` where type="termsconditions"')
        missingdomainfile = []
        domain_present = []

        for domainrow in cb.n1ql_query(domainquery):
             if domainrow['domain_name'] in domainlistfile:
                domain_present.append(domainrow['domain_name'])

        missing_in_domain = list(set(domainlistfile) - set(domain_present))
        if len(missing_in_domain) > 0:
                print("These domain entries are missing in the DB: ",", ".join(missing_in_domain))
                logger.info("These domain entries are missing in the DB: ", ", ".join(missing_in_domain))
        
        termscond_file = codecs.open(path+'//termsconditions//termsandconditions.txt', 'r', 'utf-8',
                        errors='replace')
        #print(tc)
        termscond_st = termscond_file.read()
        termscond_file.close()

        hippa_stmt_file = codecs.open(path+'//termsconditions//hippa.txt', 'r', 'utf-8',
                         errors='replace')
        hippa_compliance = hippa_stmt_file.read()
        hippa_stmt_file.close()

        privacy_notice_file = codecs.open(path+'//termsconditions//privacy_policy.txt', 'r', 'utf-8',
                         errors='replace')
        privacy_notice = privacy_notice_file.read()
        privacy_notice_file.close()

        ccpa_policy_file = codecs.open(path+'//termsconditions//ccpa_privacy_notice.html', 'r', 'utf-8',
                         errors='replace')
        ccpa_privacy_notice = ccpa_policy_file.read()
        ccpa_policy_file.close()

        for idx, row in tc.iterrows():
                query = N1QLQuery('Select meta().id as id from `' + os.environ['CB_INSTANCE'] +
                                '` where type="termsconditions" and domain_name=$dn',
                                dn=row['domain_name'])
                domain_value = row['domain_name']

                datarow = populate_dict(tc, row)
                datarow['type'] = 'termsconditions'
                datarow['terms_conditions'] = termscond_st
                datarow['hippa_compliance'] = hippa_compliance
                datarow['ccpa_privacy_policy'] = ccpa_privacy_notice
                datarow['privacy_policy'] = privacy_notice
                datarow['updated_date'] = datetime.now().strftime("%m/%d/%Y %H:%M")

                if cmdline_rec['mode'].upper().strip() == 'FINAL':
                        # print('Final mode')
                        res = cb.n1ql_query(query).get_single_result()
                        if res is not None:
                                print(f"This existing domain in database is updated " + domain_value)
                                logger.debug(f"This existing domain [< {domain_value} >] in database is updated")
                                cb.upsert(res['id'], datarow, format=FMT_JSON)
                                present = True

                        else:
                                print("This new domain is created  in database "+domain_value)
                                logger.debug(f"Adding new details for domain: {domain_value}")
                                cb.upsert(str(cb.counter('docid',delta=1).value), datarow, format=FMT_JSON)
                else:
                        print("Draft mode - Mock update")
load_tandc()
logger.info("End time is " + str(datetime.now()) )

logger.info("="*60)
