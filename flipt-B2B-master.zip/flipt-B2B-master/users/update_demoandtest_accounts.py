#!/usr/bin/env python
########################################
# title         : caryn_user_report.py
# description   : creates the caryn user report in json format the follows the following layout
# author        : Rajesh Acharya
# date created  : 20191120
# date last modified    : 20190206 
# version       : 0.1
# maintainer    :
# email         :
# status        : Production
# Python Version: 3.5.2
# usage			: python caryn_user_report.py -d CARYN001 -t eligibility -m DRAFT
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  
# #######################################


def user_report_gen(cfg_dict):
	import os
	import json
	import copy
	import base64
	import requests
	import pandas as pd
	from requests.auth import HTTPBasicAuth
	from pprint import pformat
	from datetime import datetime
	from utils.truevault import User_Class
	from rxplanmaster.rxplan_validation import validate, getplans

	original_records = []
	modified_records = []

	error_records = 0
	demo_account_count = 0

	plan_year = datetime.now().year

	r = requests.get('https://api.truevault.com/v1/users',
					 auth=HTTPBasicAuth(os.environ['TV_API_KEY'], ''))
	response = r.json()

	# loop through the users list
	total_records = len(response['users'])
	eligibility_log = pd.DataFrame()
	for user in response['users']:
		obj = User_Class(None, None, cb_handle=cfg_dict['cb_handle'])
		search_option = {'full_document': True,
						 'filter':
							 {'$tv.username':
								  {'type': 'eq',
								   'value': user['username'],
								   'case_sensitive': False
								   },
							  '$tv.status':
								  {'type': 'eq',
								   'value': 'ACTIVATED'
								   }
							  },
						 'filter_type': 'and'}
		att, uid = obj.search_tvuser(search_option)

		if att is not None:
			try:
				if att['employee_id'][:4].lower() != 'test':
					continue
			except KeyError:
				logrec = {'User': user['username'],
						  'Primary': '',
						  'Domain': '',
						  'Dependent': '',
						  'Reason': 'Employee_id not present!'}
				print(f"Error: Employee_id not present in record: {user['username']}")
				eligibility_log = eligibility_log.append(logrec, ignore_index=True)
				cfg_dict['logger'].error(f"Record < {user['username']} > doesn't have employee_id attribute.")
				error_records += 1
				continue

			else:  # test present in employee_id
				demo_account_count += 1
				original_records.append(copy.deepcopy(att))
				rxplans = getplans(cfg_dict['cb_handle'], [att['domain_name']], yr=str(plan_year))

				if cfg_dict['mode'].lower() == 'draft':
					print(f"Original record: {pformat(att)}")
				else:
					print(f"Checking user: {user['username']}")

				cfg_dict['logger'].info(f"original record: {pformat(att)}")
				elig_copy = None
				plan_year_present = False
				try:
					for dep in att['dependents']:
						elig_list = []
						for elig in dep['eligibility']:
							elig_copy = copy.deepcopy(elig)
							if 'active' in elig_copy:
								del elig_copy['active']

							if isinstance(elig_copy['plan_year'], int):
								if elig_copy['plan_year'] != plan_year:
									elig_list.append(copy.deepcopy(elig_copy))
								else:
									elig_list.append(copy.deepcopy(elig_copy))
									plan_year_present = True
							else:
								if str(elig_copy['plan_year']) != str(plan_year):
									elig_list.append(copy.deepcopy(elig_copy))
								else:
									elig_list.append(copy.deepcopy(elig_copy))
									plan_year_present = True
						# end for-loop

						try:
							if plan_year_present is True:
								logrec = {'User': user['username'],
										  'Employee ID': f"{att['employee_id']}",
										  'Domain': f"{att['domain_name']}",
										  'Primary': f"{att['first_name']} {att['last_name']}",
										  'Dependent': f"{dep['first_name']} {dep['last_name']}",
										  'Reason': f'plan year present for < {plan_year} >'}
								dep['eligibility'] = copy.deepcopy(elig_list)
								eligibility_log = eligibility_log.append(logrec, ignore_index=True)

							else:
								new_rec = copy.deepcopy(elig_list[-1])
								try:
									if new_rec['benefit_plan_name'] not in list(rxplans['plan_name']):
										if att['domain_name'] in ['GWLABS001', 'FLIPT001']:
											if (new_rec['benefit_plan_name'] == 'HSA Value Plan' and
												str(plan_year) in list(rxplans['plan_year'])):
												new_rec['benefit_plan_name'] = 'HSA Max Value Plan'
								except KeyError:
									if att['domain_name'] in ['GWLABS001', 'FLIPT001']:
										new_rec['benefit_plan_name'] = 'Core Plan'

								try:
									if new_rec['cobra_effective_date'] is None:
										new_rec['cobra_effective_date'] = ''
								except KeyError:
									new_rec['cobra_effective_date'] = ''

								try:
									if new_rec['cobra_termination_date'] is None:
										new_rec['cobra_termination_date'] = ''
								except KeyError:
									new_rec['cobra_termination_date'] = ''

								new_rec['coverage_effective_date'] = new_rec['coverage_effective_date'].\
									replace(str(new_rec['plan_year']), str(plan_year))
								new_rec['coverage_termination_date'] = new_rec['coverage_termination_date']. \
									replace(str(new_rec['plan_year']), str(plan_year))
								new_rec['plan_year'] = str(plan_year)
								elig_list.append(copy.deepcopy(new_rec))

						except IndexError:
							new_rec = copy.deepcopy(elig_copy)
							if new_rec['plan_year'] == str(plan_year):
								elig_list.append(copy.deepcopy(new_rec))

							logrec = {'User': user['username'],
									  'Employee ID': f"{att['employee_id']}",
									  'Domain': f"{att['domain_name']}",
									  'Primary': f"{att['first_name']} {att['last_name']}",
									  'Dependent': f"{dep['first_name']} {dep['last_name']}",
									  'Reason': f'plan year added for < {plan_year} >'}

							eligibility_log = eligibility_log.append(logrec, ignore_index=True)
						dep['eligibility'] = copy.deepcopy(elig_list)
						dep['updated_at'] = datetime.strptime(str(datetime.now()), "%Y-%m-%d %H:%M:%S.%f").isoformat()
					# end eligibility for dependents

				except KeyError:  # dependent who has registered their account won't have dependents
					pass

				# update primary user eligibility
				elig_list = []
				elig_copy = None
				try:
					for elig in att['eligibility']:
						elig_copy = copy.deepcopy(elig)
						if 'active' in elig_copy:
							del elig_copy['active']

						if isinstance(elig['plan_year'], int):
							if elig['plan_year'] != plan_year:
								elig_list.append(copy.deepcopy(elig_copy))
							else:
								elig_list.append(copy.deepcopy(elig_copy))
								plan_year_present = True
						else:
							if str(elig['plan_year']) != str(plan_year):
								elig_list.append(copy.deepcopy(elig_copy))
							else:
								elig_list.append(copy.deepcopy(elig_copy))
								plan_year_present = True

				except KeyError:
					pass

				try:
					if plan_year_present is True:
						logrec = {'User': user['username'],
								  'Employee ID': f"{att['employee_id']}",
								  'Domain': f"{att['domain_name']}",
								  'Primary': f"{att['first_name']} {att['last_name']}",
								  'Dependent': '',
								  'Reason': f'plan year present for < {plan_year} >'}
						eligibility_log = eligibility_log.append(logrec, ignore_index=True)
						att['eligibility'] = copy.deepcopy(elig_list)
						att['updated_at'] = datetime.strptime(str(datetime.now()), "%Y-%m-%d %H:%M:%S.%f").isoformat()

					else:
						new_rec = copy.deepcopy(elig_list[-1])
						try:
							if new_rec['benefit_plan_name'] not in list(rxplans['plan_name']):
								if att['domain_name'] in ['GWLABS001', 'FLIPT001']:
									if (new_rec['benefit_plan_name'] == 'HSA Value Plan' and
											str(plan_year) in list(rxplans['plan_year'])):
										new_rec['benefit_plan_name'] = 'HSA Max Value Plan'
						except KeyError:
							if att['domain_name'] in ['GWLABS001', 'FLIPT001']:
								new_rec['benefit_plan_name'] = 'Core Plan'

						try:
							if new_rec['cobra_effective_date'] is None:
								new_rec['cobra_effective_date'] = ''
						except KeyError:
							new_rec['coverage_effective_date'] = ''

						try:
							if new_rec['cobra_termination_date'] is None:
								new_rec['cobra_termination_date'] = ''
						except KeyError:
							new_rec['cobra_termination_date'] = ''

						new_rec['coverage_effective_date'] = new_rec['coverage_effective_date']. \
							replace(str(new_rec['plan_year']), str(plan_year))
						new_rec['coverage_termination_date'] = new_rec['coverage_termination_date']. \
							replace(str(new_rec['plan_year']), str(plan_year))
						new_rec['plan_year'] = str(plan_year)

						elig_list.append(copy.deepcopy(new_rec))
						att['eligibility'] = copy.deepcopy(elig_list)
						att['updated_at'] = datetime.strptime(str(datetime.now()), "%Y-%m-%d %H:%M:%S.%f").isoformat()
						logrec = {'User': user['username'],
								  'Employee ID': f"{att['employee_id']}",
								  "Domain": f"{att['domain_name']}",
								  'Primary': f"{att['first_name']} {att['last_name']}",
								  'Dependent': '',
								  'Reason': f'plan year added for < {plan_year} >'}
						eligibility_log = eligibility_log.append(logrec, ignore_index=True)

				except IndexError:
					try:
						new_rec = copy.deepcopy(att['eligibility'][-1])
						if new_rec['plan_year'] == str(plan_year):
							elig_list.append(copy.deepcopy(new_rec))

						att['eligibility'] = copy.deepcopy(elig_list)
						att['updated_at'] = datetime.strptime(str(datetime.now()), "%Y-%m-%d %H:%M:%S.%f").isoformat()
						logrec = {'User': user['username'],
								  'Employee ID': f"{att['employee_id']}",
								  "Domain": f"{att['domain_name']}",
								  'Primary': f"{att['first_name']} {att['last_name']}",
								  'Dependent': '',
								  'Reason': f'plan year present for < {plan_year} >'}
						eligibility_log = eligibility_log.append(logrec, ignore_index=True)

					except KeyError:
						print(f"No eligibility records present for: {user['username']}")
						cfg_dict['logger'].info(f"No eligibility records present for: {user['username']}")
						print('record not modified!!')
						logrec = {'User': user['username'],
								  'Employee ID': f"{att['employee_id']}",
								  "Domain": f"{att['domain_name']}",
								  'Primary': f"{att['first_name']} {att['last_name']}",
								  'Dependent': "",
								  'Reason': 'No eligibility present for primary'}
						eligibility_log = eligibility_log.append(logrec, ignore_index=True)
						error_records += 1

				modified_records.append(copy.deepcopy(att))
				cfg_dict['logger'].info(f"Updated record: {pformat(att)}")

				# write record to truevault if oper mode is 'final'
				if cfg_dict['mode'].lower() == 'final':
					new_att_data = base64.b64encode(str.encode(json.dumps(att)))
					data = {'attributes': new_att_data}
					stat = requests.put('https://api.truevault.com/v1/users/%s' % str(uid),
									 auth=HTTPBasicAuth(os.environ['TV_API_KEY'], ''),
									 data=data)

				else:
					if cfg_dict['mode'].lower() == 'draft':
						print("Mock update complete")
						print(f"Updated: {pformat(att)}")

				print("-"*60)
				cfg_dict['logger'].info("-"*60)
			# end test account
	# end loop

	update_dir = os.path.dirname(cfg_dict['run_log'])
	try:
		os.stat(update_dir)
	except:
		os.mkdir(update_dir)

	writer = pd.ExcelWriter(cfg_dict['run_log'], engine='xlsxwriter')
	eligibility_log.to_excel(writer, index=False, sheet_name='Update Log')
	writer.save()
	print(f"Update log: {cfg_dict['run_log']}\n")

	# create final jason files
	fl1 = open(cfg_dict['cmpfl1'], "w")
	fl2 = open(cfg_dict['cmpfl2'], "w")
	json.dump(original_records, fl1, indent=5)
	json.dump(modified_records, fl2, indent=5)
	fl1.close()
	fl2.close()

	print("Compare files created for verification:")
	print(f"\tOriginal record file: {cfg_dict['cmpfl1']}")
	print(f"\tModified record file: {cfg_dict['cmpfl2']}")

	print("Statistics of run:")
	print("\t" + f"Demo accounts - count: {demo_account_count}")
	print('\t' + f"Error record - counts: {error_records}")
	print('\t' + f"Total records in truevault: {total_records}")
# end function


if __name__ == '__main__':
	import os
	import sys
	import socket
	from utils.aws_sftp import *
	from utils.helper_functions import *
	from datetime import datetime

	cmdline_args = process_alt_cmdline(additional=[['-t', '--file_type',
												   'type of data being loaded. (should be userupdate)', True]])

	sysdate = str(datetime.now())
	currentdate = datetime.now().strftime("%m%d%yT%H%M%S")
	pth = os.environ['CB_DATA']

	config_dict = {'path': os.environ['CB_DATA'],
				   'mode': cmdline_args['mode'],
				   'cb_handle': cb_authenticate(),
				   'logger': setup_logging_path('EMPLOYEE', f'update_all_demousers_{currentdate}', 'USERREPORT'),
				   'run_log': f"{pth}/{cmdline_args['file_type']}/update_demoandtest_log.xlsx",
				   'cmpfl1': f"{pth}/{cmdline_args['file_type']}/compare_orig_records.json",
				   'cmpfl2': f"{pth}/{cmdline_args['file_type']}/compare_mods_records.json",
				   'currentdate': currentdate,
				   'file_type': cmdline_args['file_type'],
				   'host': socket.gethostname()
				   }

	user_report_gen(config_dict)
# end main
