import pyx12.segment
import pyx12.params
import pyx12.x12context
import pyx12.x12file
import pyx12
from datetime import datetime
from couchbase.n1ql import N1QLQuery, N1QLRequest
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Cluster
import os, sys,json
import argparse
from cerberus import Validator
import pdb
from utils.helper_functions import setup_logging_path,get_domain_mapping
from pandas import DataFrame, ExcelWriter
from utils.aws_sftp import *
from utils.sendgridemail import email_log
from utils.truevault import User_Class
from utils.file_comp_log import FileComp
#python users/eligibility_834_reader.py -d ACS001 -y 2020 -m draft



class Eligibility834Reader:

    def __init__(self):

        self.src= None
        self.header_data = {}
        self.data = []
        self.coverage_tier_map = {}
        self.plan_map = {}
        self.domain_group_map = {}
        self.mandatory_fields = {}
        self.validation = None
        self.cb= None
        self.bucket_name = os.environ['CB_INSTANCE']
        self.logger = None
        self.fileComp = None
        

    def setup_process(self):

        path = os.environ['CB_DATA']
        currentdate = datetime.now().strftime('%Y%m%d_%H%M%S')
        self.logger = setup_logging_path('ELIGIBILITY', 'ftpemployee', 'FTPEMPLOYEE')
        self.logger.info('Begin eligibility setup')
        localpath = path + '/' + domain + '/' + f'/log/{domain}_eligibilityload_{currentdate}.xlsx'
        self.fileComp = FileComp(path + '/' + domain + '/log/', domain, 'EmpDep')
        writer = ExcelWriter(localpath, engine='xlsxwriter')
        # setup SFTP handler
        sftp_hndlr = AWS_SFTP(domain, 'ELIGIBILITY')
        sftp_hndlr.sftp_getfilelist(sftp_hndlr.sftp_home)

        if len(sftp_hndlr.sftp_file_list) == 0:
            
            print("No files available for processing\n\n")
            self.logger.info("No files available for processing")
            sys.exit(0)

        hostnameprod = os.environ['INSTANCE_TYPE']
        localpath = f"{path}/{domain}/employee/"
        timestamp = datetime.strftime(datetime.now(),'%m%d%y')
        srch_mtrx = 'SNS_FLIPTRX_ELIG_'+timestamp
        print(srch_mtrx,'searching...')        
        stat, filename = sftp_hndlr.sftptransfer(
            None, localpath, 'GET', phrase=None, searchdict=srch_mtrx)
        if stat == 'E':
            print("No files found or invalid naming convention!!")
            self.logger.info("EMP: No files found or invalid naming convention!!")
            sys.exit(-1)

        param = pyx12.params.params()
        errh = pyx12.error_handler.errh_null()
        self.src = pyx12.x12context.X12ContextReader(
            param, errh, localpath + filename)
        
        cluster = Cluster(os.environ['CB_URL'])
        auth = PasswordAuthenticator(
            os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
        cluster.authenticate(auth)
        self.cb = cluster.open_bucket(os.environ['CB_INSTANCE'])

        self.read_segments()

        

        if {'First Name', 'Last Name'}.issubset(terminatedlog.columns):
            terminatedlog.drop(['First Name', 'Last Name'], axis=1, inplace=True)
        if {'First Name', 'Last Name'}.issubset(eligibility_log.columns):
            eligibility_log.drop(['First Name', 'Last Name'], axis=1, inplace=True)

        terminatedlog.to_excel(writer, index=False, sheet_name='Terminations')
        eligibility_log.to_excel(writer, index=False, sheet_name='Eligibility')
        self.fileComp.write('pre')
        self.fileComp.write('post')

        if (self.fileComp.compare_files() is True):
            print(f"Compare file: {self.fileComp.comp_file}" + "\n\n")

        if self.fileComp.filecompared is True:
            res, _ = sftp_hndlr.sftptransfer(path + '/' + domain + '/log/' + os.path.basename(self.fileComp.comp_file),
                                         sftp_hndlr.sftp_download,
                                         'PUT')
            if res == 'S':
                os.unlink(path + '/' + domain + '/log/' + os.path.basename(self.fileComp.comp_file))

        if mode.upper()=='FINAL':
            stat, filename = sftp_hndlr.sftptransfer(
            localpath+filename,sftp_hndlr.sftp_archive ,'PUT')
            _ = sftp_hndlr.sftpremove(filename)
        os.remove(f"{path}/{domain}/employee/" + filename)





    def map_fields(self):

        self.logger.info('Pulling 834 mapping')
        
        mapping = DataFrame()
        query = N1QLQuery('Select `mapping` from `'+self.bucket_name +
                          '` where meta().id="834_transaction_mapping" ')
        for result in self.cb.n1ql_query(query):
            mapping = mapping.append(result['mapping'])

        domain_provider = domain
        if domain in ['ACS001']:
            domain_provider = 'S&S'

        self.logger.info('Pulling domain configuration codes')

        query = N1QLQuery(
            'Select qualifiers,codes from `'+self.bucket_name+'` where type="eligibility_config" and domain=$domain',domain=domain_provider)
        for result in self.cb.n1ql_query(query):
            qualifiers_codes = dict(result)

        return mapping, qualifiers_codes

    def get_validation_data(self):

        self.logger.info('Pulling validation data')

        query = N1QLQuery(
            'Select employee_interface,flipt_coverage_tier from `'+self.bucket_name+'` where type="coverage_tier" and domain_name=$domain', domain=domain)
        for result in self.cb.n1ql_query(query):
            self.coverage_tier_map[result['employee_interface']
                                   ] = result['flipt_coverage_tier']

        query = N1QLQuery(
            'Select plan_code,plan_name from `' + self.bucket_name + '` where type="rxplan_master" and domain_name=$domain', domain=domain)

        for result in self.cb.n1ql_query(query):
            self.plan_map[result['plan_code']
                          ] = result['plan_name']

        query = N1QLQuery(
            'Select domain,groups from `' + self.bucket_name + '` where type="domain" and domain=$domain',domain=domain)
        for result in self.cb.n1ql_query(query):
            self.domain_group_map[result['domain']
                                  ] = result['groups']
        self.domain_mapping = get_domain_mapping(self.cb)

        schema = {"employee_ssn": {"type": "string", "regex": "^[0-9]+$", "maxlength": 9, "minlength": 9},
                  "dependent_ssn": {"type": "string", "regex": "^[0-9]+$", "maxlength": 9, "minlength": 9},
                  "last_name": {"type": "string"},
                  "first_name": {"type": "string"},
                  "date_of_birth": {"type": "datetime", "coerce": lambda s: datetime.strptime(s, '%Y-%m-%d %H:%M:%S')},
                  "gender": {"type": "string", "allowed": ["F", "M"]},
                  "home_address_1": {"type": "string"},
                  "city": {"type": "string"},
                  "state": {"type": "string"},
                  "zip": {"type": "string", "minlength": 5, "maxlength": 9},
                  "employment_status": {"type": "string", "allowed": ["Active", "Cobra", "Terminated"]},
                  "benefit_plan_name": {"type": "string", "allowed": list(self.plan_map.values())},
                  "plan_year": {"type": "string"},
                  "coverage_tier_name": {"type": "string", "allowed": list(self.coverage_tier_map.values())},
                  "coverage_termination_date": {"type": "datetime","coerce": lambda s: datetime.strptime(s, '%Y-%m-%d %H:%M:%S')},
                  "coverage_effective_date": {"type": "datetime", "coerce": lambda s: datetime.strptime(s, '%Y-%m-%d %H:%M:%S')}}

        self.mandatory_fields = {'employee': ["domain_name", "employee_id", "employee_ssn", "last_name", "first_name", "date_of_birth", "hire_date", "work_email", "gender", "home_address_1", "home_address_2", "city", "state", "zip", "employment_status", "termination_date", "group", "person_code", "type", "plan_year", "coverage_termination_date", "coverage_effective_date", "benefit_plan_name",
                                              "coverage_tier_name", "cobra_termination_date", "cobra_effective_date", "dependents"], 'dependent': ["type", "employee_id", "dependent_ssn", "relationship", "last_name", "first_name", "gender", "date_of_birth", "person_code", "plan_year", "coverage_termination_date", "coverage_effective_date", "benefit_plan_name", "coverage_tier_name", "cobra_termination_date", "cobra_effective_date"]}
        
        if domain == 'ACS001':
            self.mandatory_fields['employee'].append('tpa_member_id')
            self.mandatory_fields['dependent'].append('tpa_member_id')

        self.validation = Validator(schema, allow_unknown=True)

    def read_segments(self):

        mapping, qualifiers_codes = self.map_fields()
        self.logger.info('Data read begin')
        users = []
        new_member = {'dependents': [], 'type': 'employee'}
        qualifier = ''
        tpa_member_id = ''
        self.get_validation_data()

        for datatree in self.src.iter_segments(''):

            for seg_node in datatree.iterate_segments():

                for ee in seg_node['segment'].values_iterator():
                    # pdb.set_trace()

                    try:

                        if mapping.loc[(mapping['segment_id'] == ee[0]) & (mapping['loop_name'] == datatree.x12_map_node.name), 'required'].values[0] == 'N':
                            continue
                    except:
                        print(ee, datatree.x12_map_node.name, new_member.get(
                            'ssn', ''), new_member.get('tpa_member_id', ''))
                        self.logger.info('Segment ID/Name not found'+datatree.x12_map_node.name+ new_member.get(
                            'ssn', '')+ new_member.get('tpa_member_id', ''))

                    if ee[0] == 'INS01':
                        new_member = self.format_data(
                            new_member, users[-1] if users else {})
                        if not self.validate_data(new_member):
                            continue
                        if qualifiers_codes['codes'][ee[0]][ee[3]] == 'Subscriber':
                            
                            if new_member.get('type') == 'dependent':
                                users[-1]['dependents'].append(new_member)
                                self.process_record(users[-1])
                            elif new_member.get('type') == 'employee' and new_member.get('employee_ssn', ''):
                                users.append(new_member)
                                self.process_record(new_member)
                            new_member = {'type': 'employee', 'dependents': []}
                            tpa_member_id = ''
                        else:
                            if new_member.get('type') == 'dependent':
                                users[-1]['dependents'].append(new_member)
                            elif new_member.get('type') == 'employee' and new_member.get('employee_ssn', ''):
                                users.append(new_member)
                            new_member = {'type': 'dependent'}
                        continue

                    if ee[0] in qualifiers_codes['qualifiers']:
                        codes = qualifiers_codes['qualifiers'].get(ee[0], '')
                        qualifier = codes.get(ee[3], '')
                    elif qualifier:
                        new_member[qualifier] = ee[3]
                        if qualifier == 'tpa_member_id':
                            tpa_member_id = ee[3]
                        qualifier = ''
                    elif ee[0] in qualifiers_codes['codes']:
                        codes = qualifiers_codes['codes'][ee[0]]
                        if ee[3] not in codes:
                            continue
                        field_name = mapping[mapping['segment_id']
                                             == ee[0]]['flipt_field_name'].values

                        if field_name and '' not in field_name:
                            new_member[field_name[0]] = codes[ee[3]]
                    else:
                        try:
                            new_member[mapping[mapping['segment_id']
                                               == ee[0]]['flipt_field_name'].values[0]] = ee[3]
                        except Exception as e:
                            print(e, ee)
        if users and new_member.get('tpa_member_id', '') == users[-1].get('tpa_member_id', ''):
            if self.validate_data(self.format_data(new_member, users[-1] if users else{})):
                users[-1]['dependents'].append(new_member)
                self.process_record(users[-1])
        else:
            if self.validate_data(self.format_data(new_member, users[-1] if users else{})):
                users.append(new_member)
                self.process_record(new_member)
        
        #print(users)

    def format_data(self, member, employee):


        if not member.get('ssn', ''):
            return member
        
        self.logger.info('Data Format for'+member.get('tpa_member_id',''))

        for attribute, value in member.items():
            if attribute in ['last_name', 'first_name']:
                member[attribute] = value.upper()
            if attribute in ['date_of_birth', 'coverage_effective_date', 'cobra_effective_date']:
                if int(value[:4]) > 2038:
                    member[attribute][:4] = '2038'
                member[attribute] = datetime.strftime(datetime.strptime(
                    value, '%Y%m%d'), '%Y-%m-%d 00:00:00')
            if attribute in ['termination_date', 'coverage_termination_date', 'cobra_termination_date']:
                member[attribute] = datetime.strftime(datetime.strptime(
                    value, '%Y%m%d'), '%Y-%m-%d 23:59:59')
            if attribute == 'coverage_tier_name':
                member[attribute] = self.coverage_tier_map.get(value, '')
            if attribute == 'benefit_plan_name':
                member[attribute] = self.plan_map.get(value, '')

        member[member['type'] + '_ssn'] = member['ssn']
        member['plan_year'] = plan_year
        if member.get('type') == 'employee':
            
            for k, v in self.domain_group_map.items():
                if member.get('group', '') in v:
                    member['domain_name'] = k
            if member.get('domain_name', '') == 'ACS001':
                member['group'] = 'ACSALL'
        if member.get('type') == 'dependent':
            member['coverage_tier_name'] = employee.get(
                'coverage_tier_name', '')
            member['benefit_plan_name'] = employee.get(
                'benefit_plan_name', '')
                
        if member.get('domain_name','')=='ACS001' or employee.get('domain_name','')=='ACS001':
            member['employee_id'] = member.get('tpa_member_id','')
                
        if not member.get('coverage_termination_date', ''):
            if employee.get('employment_status', '') in ['Active', 'Cobra'] or member.get('employment_status', '') in ['Active', 'Cobra']:
                member['coverage_termination_date'] = member['coverage_effective_date'][:5] + '12-31 23:59:59'
        if employee.get('employment_status', '')=='Terminated' or member.get('employment_status', '')=='Terminated':
            member['termination_date'] = member.get('termination_date','') if member.get('termination_date','') else member.get('coverage_termination_date', '')

        if member.get('cobra_effective_date', ''):
            member['coverage_effective_date'] = member['cobra_effective_date']
            member['employment_status'] = 'Cobra'
            if member.get('cobra_termination_date', ''):
                member['coverage_termination_date'] = member['cobra_termination_date']
            else:
                member['cobra_termination_date'] =  member['coverage_termination_date']
       
        add_missing_fields = {'employee':['termination_date', 'hire_date', 'employee_id', 'home_address_2', 'cobra_effective_date', 'cobra_termination_date','work_email','locations'], 'dependent': ['employee_id', 'cobra_effective_date', 'cobra_termination_date']}
        for field in add_missing_fields[member.get('type', '')]:
            if field not in member:
                member[field] = ''
            if field=='locations':
                member[field] = []
        current_fields = list(member.keys())
        for field in current_fields:
            if field not in self.mandatory_fields[member.get('type', '')]:
                member.pop(field)
        
        return member

    def validate_data(self, member):

        if not member.get('employee_ssn', '') and not member.get('dependent_ssn', ''):
            return member


        validation_response = self.validation.validate(member)
        
        if not validation_response:
            print('validation error for', member.get('tpa_member_id'))
            print(self.validation.errors)
            self.logger.info('validation error for '+member.get('tpa_member_id',''))
            self.logger.info(json.dumps(self.validation.errors))
            return False

        for field in self.mandatory_fields[member.get('type', '')]:
            if field not in member:
                print(field + ' is missing for '+member.get('tpa_member_id',''))
                self.logger.info(field + ' is missing for '+member.get('tpa_member_id',''))


        return True


    def process_record(self, user):

        global terminatedlog, eligibility_log

        user_obj = User_Class(user['work_email'].lower(), None, user,
                                      os.environ['CB_GROUP_ID'], cb_handle=self.cb,dom_map=self.domain_mapping)
        (termlog, eligibilityerr, sendgrid_userchanges,_) = user_obj.update_user([], log_hndl=self.logger,
                                                                                mode=mode,
                                                                                hr_email='fliptintegration@fliptrx.com',
                                                                                notify_user='Y',
                                                                                createfile=False,fileComp=self.fileComp)
                        
        terminatedlog = terminatedlog.append(termlog, ignore_index=True)
        eligibility_log = eligibility_log.append(eligibilityerr, ignore_index=True)
                        


parser = argparse.ArgumentParser(description='commandline file processing...')
parser.add_argument("-d", "--domain",
                    help="domain", required=False)
parser.add_argument("-y", "--plan_year",
                    help="eligibility year", required=True)
parser.add_argument("-t", "--filetype",
                    help="pass in doc type", required=False)
parser.add_argument("-m", "--processing_type",
                    help="final/draft mode", required=True)
args = parser.parse_args()
domain, filetype, mode, plan_year = args.domain, args.filetype, args.processing_type, args.plan_year
terminatedlog = DataFrame() 
eligibility_log = DataFrame()
obj = Eligibility834Reader()
obj.setup_process()

