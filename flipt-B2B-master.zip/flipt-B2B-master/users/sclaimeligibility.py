########################################
# !/usr/bin/env python  
# title         : sclaimeligibility.py
# description   : Sends  eligibilty text file to  scriptclaims
# author        : Disha
# date created  : 20180622
# date last modified    : 20190206 
# version       : 0.1
# maintainer    : Deepthi
# email         : deepthi.gollapudi@nttdata.com
# status        : Production
# Python Version: 3.5.2
# usage			: python sclaimeligibility.py -d GWLABS001 -t sceligibility -f scriptclaimeligibility -m DRAFT
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  
# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']
 
import os
import sys
import socket
import time
from datetime import datetime
from dateutil import parser

from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from couchbase.n1ql import N1QLQuery

from utils import commandline
from utils.sendgridemail import email_log
from utils.truevault import User_Class
from sclaimintegration.scriptclaimsftp import sftptransfer
from utils.FliptConcurrent import concurrent

cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
# path = os.environ['CB_DATA']
inputdomain,file_type,file_name,mode = commandline.main(sys.argv[1:])
req=concurrent(sys.argv[0],sys.argv[1:])
sysdate = str(datetime.now())
currentdate = datetime.now()
currentdate = currentdate.strftime("%m%d%y%H%M%S")
extract_yr = str(datetime.now().year)
file_name = file_name+currentdate+'.txt';
first_name = ''
last_name = ''
subject = 'ScriptClaim'
host = socket.gethostname()

#sending scriptclaim a list of all eligible users of flipt (employee and dependents)
def scriptclaim():
	numusers=0
	mismatchusers = 0
	textfile = path+'/'+inputdomain+'/'+file_type+'/'+file_name
	log = path+'/'+inputdomain+'/'+file_type+'/log/'+file_name
	remotepath = '/ScriptClaimEligibility'+'/'+file_name
	datafile = open(textfile, "w")
	logfile = open(log,"w")
	#mm = pd.DataFrame()
	domainlist=[]
	domainlist.append(inputdomain)
	if 'GWLABS001' in domainlist: domainlist.append('FLIPT001')
	#pull all records from flipt_person_hierarchy and process with other details while writing to a text file
	flipttab = N1QLQuery('select distinct emp_flipt_person_id,domain_name from `'+os.environ['CB_INSTANCE']+'` WHERE type = "flipt_person_hierarchy" and domain_name in $domain_name',domain_name = domainlist)
	
	flipttab.adhoc = False
	flipttab.timeout = 1000
	logfile.write("Carrier  Account   Group         CardHolder ID	   Person Code\n")
	logfile.write("===============================================================\n")
	for fliptrow in cb.n1ql_query(flipttab):
		#print(fliptrow)
		domain=fliptrow['domain_name']
		emp_flipt_id = str(fliptrow['emp_flipt_person_id'])
#		print(emp_flipt_id)
		obj=User_Class(None,None)
		search_option={'full_document':True,'filter':{'domain_name':{'type':'eq','value':domain,'case_sensitive':False},'flipt_person_id':{'type':'eq','value':emp_flipt_id,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
		att,userid = obj.search_user(search_option)
		if att!=None:
			if 'TEST' in att['employee_id'].upper():
				continue			
			carrier = 'FLIPT'
			if domain=='FLIPT001': carrier = 'FLIPT2'
			account = domain
			group = str(att['group'])
			first_name = str(att['first_name'])
			last_name = str(att['last_name'])
			card_holder_id = emp_flipt_id + att['person_code']
			person_code = att['person_code']
			relationship_code = '1'
			middle_initial = ' '
			sex = att['gender']
			dob = datetime.strptime(str(att['date_of_birth']),"%Y-%m-%d %H:%M:%S")
			dob = dob.strftime('%Y%m%d')
			ssn = ''
			add1 = att['home_address_1']
			add1 = add1[0:24]
			#print(add1)
			add2 = att['home_address_2']
			add2 = add2[0:14]
			city = att['city']
			city = city[0:19]
			state = att['state']
			zip = att['zip']
			zip2 = ''
			phone = '9999999999'
			family_id = emp_flipt_id
			try:
				from_date = datetime.strptime(str(att['coverage_effective_date']), "%Y-%m-%d %H:%M:%S")
				from_date = from_date.strftime('%Y%m%d')
			except KeyError:
				continue

			if extract_yr not in from_date:
				continue

			try:
				thru_date = datetime.strptime(str(att['coverage_termination_date']), "%Y-%m-%d %H:%M:%S")
				thru_date = thru_date.strftime('%Y%m%d')
			except KeyError:
				continue

			email_address = att['work_email']
			plan = ''
			numusers=numusers+1
			#datafile.write('1234567891234567891234567890123451234567890123456781231123456789012345678901234512345678901234511123456781234567891234567890123456789012345123456789012345123456789012345678901212345123412345678901234567890123456123456781234567812345678901234567890\n')
			datafile.write(carrier.ljust(9)+account.ljust(9)+group.ljust(15)+card_holder_id.ljust(18)+person_code.ljust(3)+relationship_code+last_name.ljust(25)+first_name.ljust(15)+middle_initial+sex+dob.ljust(8)+ssn.ljust(9)+add1.ljust(25)+add2.ljust(15)+city.ljust(20)+state.ljust(2)+zip.ljust(5)+zip2.ljust(4)+phone+family_id.ljust(16)+from_date.ljust(8)+thru_date.ljust(8)+email_address.ljust(100)+"\r\n")
			
			logfile.write(carrier.ljust(9)+account.ljust(9)+group.ljust(15)+card_holder_id.ljust(18)+person_code.ljust(3)+relationship_code+"\r\n")
			if mode.upper() == 'FINAL':
				cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET sc_extracted_date = $exdate WHERE type = "flipt_person_hierarchy" and emp_flipt_person_id = $empfid and dep_flipt_person_id = $depfid',exdate =sysdate,empfid = emp_flipt_id,depfid = emp_flipt_id)).execute()
			for dep in att['dependents']:
				'''
				if dep['coverage_termination_date']!= att['coverage_termination_date'] :
					mismatchusers=mismatchusers+1
					mm=mm.append({'Dep_coverage_termination_date':str(dep['coverage_termination_date']),'Emp_coverage_termination_date':str(att['coverage_termination_date']),'Emp_Flipt_Id':str(att['flipt_person_id']),'Dep_flipt_id':str(dep['flipt_person_id'])},ignore_index=True)
				'''	
					
				#carrier = 'FLIPT'
				account = domain
				group = str(att['group'])
				depfliptid = str(dep['flipt_person_id'])
				first_name = str(dep['first_name'])
				last_name = str(dep['last_name'])
				card_holder_id = emp_flipt_id + dep['person_code']
				person_code = dep['person_code']
				if person_code == '02':
					relationship_code = '2'
				else:
					relationship_code = '3'
				middle_initial = ' '
				sex = ' '
				dob = datetime.strptime(str(dep['date_of_birth']),"%Y-%m-%d %H:%M:%S")
				dob = dob.strftime('%Y%m%d')
				ssn = ''
				add1 = att['home_address_1']
				add1 = add1[0:24]
				add2 = att['home_address_2']
				add2 = add2[0:14]
				city = att['city']
				city = city[0:19]
				state = att['state']
				zip = att['zip']
				zip2 = ''
				phone = '9999999999'
				family_id = emp_flipt_id

				try:
					from_date = datetime.strptime(str(dep['coverage_effective_date']), "%Y-%m-%d %H:%M:%S")
					from_date = from_date.strftime('%Y%m%d')
				except KeyError:
					continue

				if extract_yr not in from_date:
					continue

				try:
					#thru_date = datetime.strptime(str(dep['coverage_termination_date']), "%Y-%m-%d %H:%M:%S")
					thru_date = parser.parse(dep['coverage_termination_date'])
					thru_date = thru_date.strftime('%Y%m%d')
				except KeyError:
					continue

				email_address = att['work_email']
				plan = ''
				numusers=numusers+1
				datafile.write(carrier.ljust(9)+account.ljust(9)+group.ljust(15)+card_holder_id.ljust(18)+person_code.ljust(3)+relationship_code+last_name.ljust(25)+first_name.ljust(15)+middle_initial+sex+dob.ljust(8)+ssn.ljust(9)+add1.ljust(25)+add2.ljust(15)+city.ljust(20)+state.ljust(2)+zip.ljust(5)+zip2.ljust(4)+phone+family_id.ljust(16)+from_date.ljust(8)+thru_date.ljust(8)+email_address.ljust(100)+"\r\n")
				logfile.write(carrier.ljust(9)+account.ljust(9)+group.ljust(15)+card_holder_id.ljust(18)+person_code.ljust(3)+relationship_code+"\r\n")
				if mode.upper() == 'FINAL':
					cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET sc_extracted_date = $exdate WHERE type = "flipt_person_hierarchy" and emp_flipt_person_id = $empfid and dep_flipt_person_id = $depfid',exdate =sysdate,empfid = emp_flipt_id,depfid = depfliptid)).execute()
	datafile.close()
	#mm.to_excel(path+'/'+inputdomain+'/'+file_type+'/log/'+"MismatchUserData"+datetime.now().isoformat()+".xlsx",index=False)
	# SFTP
	if mode.upper() == 'FINAL':
		status = sftptransfer(textfile,remotepath,'PUT')
		print(status)
		if status != 'S':
			logfile.write('File transfer failed !!! Please reprocess the File : '+file_name)
			logfile.close()
			subject = 'ScriptClaimEligibility File Transfer Failed - '+host
			email_log('noreply@fliptrx.com', 'FliptIntegration@fliptrx.com', None,
                                subject,['Processing of ScriptClaim Eligibility File ' + log,
                                    'ScriptClaim Eligibility Exception'], log, True)
		else:
			os.remove(textfile)
			logfile.close()
			subject = 'ScriptClaimEligibility File Transferred Successfully - '+host
			email_log('noreply@fliptrx.com', 'FliptIntegration@fliptrx.com', None,
                                subject, ['Processing of ScriptClaim Eligibility File ' +log,
                                    'ScriptClaim Eligibility Exception'], log, True)
	else:
		#os.remove(textfile)
		logfile.write('ScriptClaimEligibility - Draft Mode : '+file_name)
		logfile.close()
		print('ScriptClaimEligibility - Draft Mode : '+file_name)
		subject = 'ScriptClaimEligibility - Draft Mode - '+host
		email_log('noreply@fliptrx.com', 'FliptIntegration@fliptrx.com', None,
                        subject, ['Processing of ScriptClaim Eligibility File ' + log,
                            'ScriptClaim Eligibility Exception'], log, True)
	return numusers
		
	
numusers=scriptclaim()
req.no_rec_received=numusers

req.close()       
