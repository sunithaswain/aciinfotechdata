get_flipt_person_id_phone = lambda \
        query_params: f"SELECT flipt_member_id, phone, employee_id, cobra_effective_date, cobra_termination_date, " \
                      f"benefit_plan_name, coverage_effective_date, relationship, flipt_person_id, plan_year, " \
                      f"coverage_tier_name, coverage_termination_date  FROM " \
                      f"" \
                      f"{query_params['table_name']} WHERE " \
                      f"plan_year='" \
                      f"{query_params['plan_year']}';"

load_dw_users = lambda query_params: """
    COPY {workspace}.dw_users FROM '{s3_path}'
    CREDENTIALS 'aws_access_key_id={aws_access_key_id};aws_secret_access_key={aws_secret_access_key}'
    CSV DELIMITER ',' ACCEPTINVCHARS ACCEPTANYDATE;
""".format(
    s3_path=query_params['s3_path'], aws_access_key_id=query_params['aws_access_key_id'],
    aws_secret_access_key=query_params['aws_secret_access_key'], workspace=query_params['workspace']
)

number_of_users = lambda query_params: """
    SELECT COUNT(*)  as number_of_users
    FROM {workspace}.dw_users
""".format(workspace=query_params['workspace'])

upsert_dw_users = lambda query_params: """\
    CREATE TABLE {workspace}.dw_users_temp (LIKE {workspace}.dw_users);
    
    COPY flipt_dw.dw_users_temp FROM '{s3_path}'
    CREDENTIALS 'aws_access_key_id={aws_access_key_id};aws_secret_access_key={aws_secret_access_key}'
    CSV DELIMITER ',' ACCEPTINVCHARS ACCEPTANYDATE;
    
    BEGIN;
    LOCK {workspace}.dw_users;
    DELETE FROM {workspace}.dw_users WHERE {join_clause};
    INSERT INTO {workspace}.dw_users SELECT * FROM {workspace}.dw_users_temp;
    DROP TABLE {workspace}.dw_users_temp;
    END
    """.format(s3_path=query_params['s3_path'], aws_access_key_id=query_params['aws_access_key_id'],
               aws_secret_access_key=query_params['aws_secret_access_key'], join_clause=query_params['join_clause'],
               workspace=query_params['workspace'])
