########################################
# !/usr/bin/env python
# title         : employeedependentupdate.py
# description   : User create / update in truevault
# author        : Harikrishna chivukula
# date created  : 20180101
# date last modified    :
# version       : 0.1
# maintainer    : Hari
# email         : -
# status        : Production
# Python Version: 3.5.2
# usage         : TO BE CALLED FROM users/ftpemployeeops.py
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#
# #######################################

###############################################


def record_error(domain_value, rowdetail, other_indicator, error_str, logrec=None):
    if logrec is not None:
        error_dict = {'Domain Name': domain_value,
                      'Employee ID': rowdetail['employee_id'],
                      'First Name': rowdetail['first_name'],
                      'Last Name': rowdetail['last_name'],
                      'Record Error': error_str}

        if other_indicator is not None:
            for rec in other_indicator:
                error_dict[rec['key']] = rec['value']
        # end

        logrec = logrec.append(error_dict, ignore_index=True)
        return(logrec)
    # end logrec not None

    return(logrec)
# end function


def validate_ssn(domain_name, row_rec, log_rec=None):
    error_present = False

    other_error = [{'key': 'SSN',
                    'value': 'Employee SSN number error.  Value: '}]

    try:
        ssn_value = row_rec['employee_ssn'].lower()
        ssn_value = ssn_value.replace("\'", '')

    except KeyError:
        ssn_value = row_rec['dependent_ssn'].lower()
        ssn_value = ssn_value.replace("\'", '')

        other_error[0]['value'] = other_error[0]['value'].replace(
            'Employee', 'Dependent')
    other_error[0]['value'] += ssn_value

    if '-' in ssn_value and len(ssn_value) > 11:
        error_present = True
    elif ('-' not in ssn_value and len(ssn_value) > 9):
        error_present = True

    if error_present is True:
        log_rec = record_error(domain_name, row_rec, other_error, ssn_value, logrec=log_rec)

    return(error_present, log_rec)
# end function


def getCTier_names(cbhndl, bucket, domain, ctier):

    from couchbase.n1ql import N1QLQuery
    query = N1QLQuery('Select flipt_coverage_tier from `' + bucket +
                      '` where type="coverage_tier" and domain_name=$d and employee_interface=$ei',
                      d=domain, ei=ctier)

    for result in cbhndl.n1ql_query(query):
        return result['flipt_coverage_tier']
    return None
# end function


# update attributes of terminated employees
def TerminatedEmployeeUpdate(cb_handle, bucket_nm, r):
    """
    updates the truevault record for terminated user
    :param cb_handle:
    :param r:
    :return:
    """
    import calendar
    from datetime import datetime
    from utils.truevault import User_Class

    user_obj = User_Class(None, None, dict(r), cb_handle=cb_handle)
    search_option = user_obj.set_search_option('employee', {}, log_hndl=None)
    att, userid = user_obj.search_tvuser(search_option)
    if userid is None and 'employee_ssn' in search_option['filter']:
        search_option = user_obj.set_search_option(
            'employee', {}, log_hndl=None, search_param='ssn')
        att, userid = user_obj.search_tvuser(search_option)
    elif userid is None:
        search_option = user_obj.set_search_option(
            'employee', {}, log_hndl=None, search_param='name_dob')
        att, userid = user_obj.search_tvuser(search_option)

    if att is not None:
        print(r['termination_date'])
        lastday = calendar.monthrange(
            r['termination_date'].year, r['termination_date'].month)[1]
        for e in att['eligibility']:
            if e['plan_year'] == str(r['termination_date'].year):
                e['coverage_termination_date'] = str(r['termination_date'].replace(day=lastday,
                                                                                   hour=23,
                                                                                   minute=59,
                                                                                   second=59))

        att['employment_status'] = str(r['employment_status']).strip()
        att['termination_date'] = r['termination_date'].strftime(
            '%Y-%m-%d 23:59:59')
        for s in att['dependents']:
            for e in s['eligibility']:
                if e['plan_year'] == str(r['termination_date'].year):
                    e['coverage_termination_date'] = str(r['termination_date'].replace(day=lastday,
                                                                                       hour=23,
                                                                                       minute=59,
                                                                                       second=59))
            s['coverage_tier_name'] = getCTier_names(cb_handle, bucket_nm, r['domain_name'],
                                                     r['coverage_tier_name'].strip())

            s['coverage_effective_date'] = datetime.strftime(r['coverage_effective_date'],
                                                             '%Y-%m-%d 00:00:00')
            s['coverage_termination_date'] = str(r['termination_date'].replace(day=lastday,
                                                                               hour=23,
                                                                               minute=59,
                                                                               second=59))
    return att
# end function


# update employee-dependent details in truevault
def EmployeeDependentConverterUpdation(cb_hndl, bucketname, domain_name, plan_year, processing_type,
                                       logrecs, numactive, numinactive, empfile, depfile, data_validation):
    """
    Validate the eligibility data files and create record snapshot
    :param cb_hndl:
    :param bucketname:
    :param domain_name:
    :param file_type:
    :param processing_type:
    :param logrecs:
    :param numactive:
    :param numinactive:
    :param empfile:
    :param depfile:
    :param data_validation:
    :return:
    """
    import copy
    import calendar
    import pandas as pd
    from datetime import datetime
    from couchbase.n1ql import N1QLQuery
    from rxplanmaster.rxplan_validation import validate, getplans

    groups = {'GWLABS001': 'GWALL',
              'FLIPT001': 'FLIPTALL',
              'FLIPTRX001': 'FLIPTALL',
              'CARYN001': 'CARYNALL',
              'NOVARTIS001': 'NOVARTISALL',
              'ACS001': 'ACSALL'}

    groupinf_present = False

    updatecarrierflag = False
    data_validation = {'Invalid_employment_status': 0,
                       'Invalid_address_data': 0,
                       'Invalid_domain_value': 0,
                       'Missing_domain': 0,
                       'No_benefit-plan_defined': 0,
                       'Invalid_benefit_plan_name': 0,
                       'Invalid_work_email_address': 0,
                       'Invalid_coverage_tier': 0,
                       'Invalid_emp-to-dep_relation': 0,
                       'Missing_column_(employee_file)': 0,
                       'Missing_column_(dependent_file)': 0,
                       'Invalid_plan_name': 0,
                       'Invalid_SSN_specification': 0,
                       'Invalid_Hire_date': 0,
                       'Total_errors': 0}

    empfile.fillna("", inplace=True)
    empcols = list(empfile)
    #print('COls in empfile',empcols)
    empchecklist = ['domain_name', 'employee_id', 'employee_ssn', 'benefit_plan_name', 'coverage_tier_name',
                    'last_name', 'first_name', 'date_of_birth', 'hire_date', 'coverage_effective_date',
                    'coverage_termination_date', 'work_email', 'gender', 'home_address_1', 'home_address_2',
                    'city', 'state', 'zip', 'employment_status', 'termination_date', 'location']

    if 'display_plan_name' in empcols:
        empchecklist.append('display_plan_name')

    if 'account' in empcols:
        empchecklist.append('account')

    if 'group' in empcols:
        empchecklist.append('group')
        groupinf_present = True

    # if 'ACS001' in domain_name: Disha's change
    if 'tpa_member_id' in empcols:
        empchecklist.append('tpa_member_id')

    # depchecklist=['employee_id','dependent_ssn','relationship','last_name','first_name','date_of_birth',
    # 'coverage_effective_date','coverage_termination_date','UID']
    # check if new employee-dependent files have all the required columns
    for c in empchecklist:
        if c not in list(empcols):
            logrecs = logrecs.append({'Error': 'Column ' + str(c) + ' Missing Error (Employee File)'},
                                     ignore_index=True)
            data_validation['Total_errors'] += 1
            data_validation['Missing_column_(employee_file)'] += 1

    if data_validation['Missing_column_(employee_file)'] > 0:
        return None, logrecs, False, numactive, numinactive, data_validation, None

    # check if domain name is the one we passed as parameter or differs
    empfile.loc[empfile.domain_name == 'FLIPTRX001',
                'domain_name'] = 'FLIPT001'
    domains = ['GWLABS001', 'FLIPT001']
    domainlist = []
    if domain_name.upper().strip() in domains:
        domainlist.extend(domains)
    else:
        domainlist.append(domain_name)

    dquery = N1QLQuery('Select domain from `' + bucketname +
                       '` where type="domain" and domain in $dn', dn=domainlist)
    dquery.timeout = 60
    domaindblist = []
    for drow in cb_hndl.n1ql_query(dquery):
        domaindblist.append(drow['domain'].upper())

    print(domainlist)
    print('Domaindblist', domaindblist)
    if set(domaindblist) != set(domainlist):
        logrecs = logrecs.append(
            {'Error': 'One of the domains does not exist'},
            ignore_index=True)
        data_validation['Missing_domain'] += 1
        data_validation['Total_errors'] += 1
        return None, logrecs, False, numactive, numinactive, data_validation, None

    depfile.fillna("", inplace=True)
    depcols = list(depfile)

    # Check for carrier eligibility
    carrier_query = N1QLQuery('Select ins_carrier_from_eligibility from `' + bucketname +
                              '` where type="domain" and domain in $dn', dn=domainlist)
    carrier_query.timeout = 60
    #carrier_query = [{'ins_carrier_from_eligibility':'N'}]

    for ins_row in cb_hndl.n1ql_query(carrier_query):
        depchecklist = ['employee_id', 'dependent_ssn', 'relationship', 'last_name', 'first_name',
                        'date_of_birth', 'coverage_effective_date', 'coverage_termination_date']
        if ('tpa_member_id' not in depcols and 'tpa_member_id' in empcols):
            depchecklist.append('tpa_member_id')

        if ins_row['ins_carrier_from_eligibility'] == 'N':
            for c in depchecklist:
                if c not in list(depcols):
                    logrecs = logrecs.append({'Error': 'Column ' + str(c) + ' Missing Error (Dependent File)'},
                                             ignore_index=True)
                    data_validation['Missing_column_(dependent_file)'] += 1
                    data_validation['Total_errors'] += 1
            # end loop

            if data_validation['Missing_column_(dependent_file)'] > 0:
                return None, logrecs, False, numactive, numinactive, data_validation, None
        else:
            # If ins_carrier eligibility is 'Y'
            depchecklist.append('UID')
            for c in depchecklist:
                if c not in list(depcols):
                    logrecs = logrecs.append({'Error': 'Column ' +
                                              str(c) + ' Missing Error (Dependent File)'},
                                             ignore_index=True)
                    data_validation['Total_errors'] += 1
                    data_validation['Missing_column_(dependent_file)'] += 1
            # end loop
            updatecarrierflag = True
        # end outer loop

    if data_validation['Missing_column_(dependent_file)'] > 0:
        return None, logrecs, False, numactive, numinactive, data_validation, None

    # get list of all valid plans for the domain and plan year
    # empfile has no column called domain or domain_name
    empfile = empfile.loc[empfile['domain_name'] != '', :]
    print(list(empfile['domain_name'].unique()))

    rxplans = getplans(cb_hndl, list(
        empfile['domain_name'].unique()), yr=plan_year)
    (rx_rows, rx_cols) = rxplans.shape
    plan_years = plan_year.split('-')

    if rx_rows == 0:
        logrecs = logrecs.append({'Error': 'No benefit plan information could be found for ' +
                                           f"{list(empfile['domain_name'].unique())} " +
                                           f"- plan year: {plan_year}"},
                                 ignore_index=True)
        data_validation['No_benefit-plan_defined'] += 1
        return None, logrecs, False, numactive, numinactive, data_validation, None

    records = []
    year_end = (datetime.now().date().replace(month=12,
                                              day=31)).strftime('%Y-%m-%d')

    for c in ['first_name', 'last_name']:
        empfile[c] = [str(x).strip().upper() for x in empfile[c]]
        depfile[c] = [str(x).strip().upper() for x in depfile[c]]

    empfile['zip'] = empfile['zip'].apply(lambda x: str(int(x)).zfill(
        5) if len(str(int(x))) <= 5 else str(int(x)).zfill(9))
    empfile['employment_status'] = empfile['employment_status'].\
        apply(lambda x: "Active" if x.lower().strip() == "on leave" else x)

    # validate coverage_effective_date format
    try:
        empfile['coverage_effective_date'] = empfile['coverage_effective_date'].\
            apply(lambda x: datetime.strptime(x, '%m/%d/%Y') if (empfile['coverage_effective_date'].
                                                                 dtype != 'datetime64[ns]'
                                                                 and '00:00:00' not in str(empfile[
                                                                     'coverage_effective_date']))
                  else x)
    except ValueError:
        empfile['coverage_effective_date'] = empfile['coverage_effective_date']. \
            apply(lambda x: datetime.strptime(x, '%m-%d-%Y') if (empfile['coverage_effective_date'].
                                                                 dtype != 'datetime64[ns]'
                                                                 and '00:00:00' not in
                                                                 str(empfile['coverage_effective_date']))
                  else x)

    # print('Coverage Effective dt',empfile['coverage_effective_date'].dtype)
    # validate coverage_effective_date in dependent file
    try:
        depfile['coverage_effective_date'] = depfile['coverage_effective_date'].\
            apply(lambda x: datetime.strptime(x, '%m/%d/%Y') if (depfile['coverage_effective_date'].
                                                                 dtype != 'datetime64[ns]'
                                                                 and '00:00:00' not in str(depfile[
                                                                     'coverage_effective_date']))
                  else x)
    except ValueError:
        depfile['coverage_effective_date'] = depfile['coverage_effective_date']. \
            apply(lambda x: datetime.strptime(x, '%m-%d-%Y') if (depfile['coverage_effective_date'].
                                                                 dtype != 'datetime64[ns]'
                                                                 and '00:00:00' not in
                                                                 str(depfile['coverage_effective_date']))
                  else x)

    # validate coverage_termination_date in emp file
    try:
        empfile['coverage_termination_date'] = empfile['coverage_termination_date'].\
            apply(lambda x: datetime.strptime(x, '%m/%d/%Y') if (empfile['coverage_termination_date'].
                                                                 dtype != 'datetime64[ns]'
                                                                 and '00:00:00' not in str(empfile[
                                                                     'coverage_termination_date']))
                  else x)
    except ValueError:
        empfile['coverage_termination_date'] = empfile['coverage_termination_date']. \
            apply(lambda x: datetime.strptime(x, '%m-%d-%Y') if (empfile['coverage_termination_date'].
                                                                 dtype != 'datetime64[ns]'
                                                                 and '00:00:00' not in
                                                                 str(empfile['coverage_termination_date']))
                  else x)

    # validate coverage_termination_date in dependent file
    try:
        depfile['coverage_termination_date'] = depfile['coverage_termination_date'].\
            apply(lambda x: datetime.strptime(x, '%m/%d/%Y') if (depfile['coverage_termination_date'].
                                                                 dtype != 'datetime64[ns]'
                                                                 and '00:00:00' not in str(depfile[
                                                                     'coverage_termination_date']))
                  else x)
    except ValueError:
        depfile['coverage_termination_date'] = depfile['coverage_termination_date']. \
            apply(lambda x: datetime.strptime(x, '%m-%d-%Y') if (depfile['coverage_termination_date'].
                                                                 dtype != 'datetime64[ns]'
                                                                 and '00:00:00' not in
                                                                 str(depfile['coverage_termination_date']))
                  else x)

    # Hire Date
    try:
        empfile['hire_date'] = empfile['hire_date'].\
            apply(lambda x: datetime.strptime(x, '%m/%d/%Y') if (empfile['hire_date'].
                                                                 dtype != 'datetime64[ns]'
                                                                 and '00:00:00' not in str(
                                                                     empfile['hire_date'])) else x)
    except ValueError:
        empfile['hire_date'] = empfile['hire_date']. \
            apply(lambda x: datetime.strptime(x, '%m-%d-%Y') if (empfile['hire_date'].
                                                                 dtype != 'datetime64[ns]'
                                                                 and '00:00:00' not in str(
                empfile['hire_date'])) else x)

    # Date of Birth for employee
    try:
        empfile['date_of_birth'] = empfile['date_of_birth'].\
            apply(lambda x: datetime.strptime(x, '%m/%d/%Y') if (empfile['date_of_birth'].
                                                                 dtype != 'datetime64[ns]'
                                                                 and '00:00:00' not in str(
                                                                     empfile['date_of_birth']))
                  else x)
    except ValueError:
        empfile['date_of_birth'] = empfile['date_of_birth']. \
            apply(lambda x: datetime.strptime(x, '%m-%d-%Y') if (empfile['date_of_birth'].
                                                                 dtype != 'datetime64[ns]'
                                                                 and '00:00:00' not in str(
                empfile['date_of_birth'])) else x)

    # validate date_of_birth for dependents
    try:
        depfile['date_of_birth'] = depfile['date_of_birth'].\
            apply(lambda x: datetime.strptime(x, '%m/%d/%Y') if (depfile['date_of_birth'].
                                                                 dtype != 'datetime64[ns]'
                                                                 and '00:00:00' not in str(
                                                                     depfile['date_of_birth']))
                  else x)
    except ValueError:
        depfile['date_of_birth'] = depfile['date_of_birth']. \
            apply(lambda x: datetime.strptime(x, '%m-%d-%Y') if (depfile['date_of_birth'].
                                                                 dtype != 'datetime64[ns]'
                                                                 and '00:00:00' not in str(
                depfile['date_of_birth'])) else x)

    depfile['date_of_birth'] = depfile['date_of_birth'].apply(
        lambda x: x.strftime('%Y-%m-%d 00:00:00'))

    for index, row in empfile.iterrows():
        emprecs = {}

        # name change on validation flags
        tiername_validation = True
        dep_tiername_validation = True
        planname_validation = True
        deprelation_validation = True
        empstatus_validation = True
        domain_validation = True
        demograpic_validation = True
        primaryemail_validation = True
        planretrieve_validation = True
        ssnnumber_validation = False
        hiredate_validation = True

        if (row['hire_date'] < row['date_of_birth']):
            logrecs = record_error(row, [{'key': 'Hire Date',
                                          'value': row['hire_date']}],
                                   f"Hire date is before the employee's date of birth",
                                   logrec=logrecs)
            data_validation['Invalid_Hire_date'] += 1
            data_validation['Total_errors'] += 1
            hiredate_validation = False
            continue
        # invalid hire date

        (ssnnumber_validation, logrecs) = validate_ssn(row['domain_name'], row, log_rec=logrecs)
        if ssnnumber_validation is True:
            data_validation['Invalid_SSN_specification'] += 1
            data_validation['Total_errors'] += 1
            continue

        # check if the benefit plan is available for current year
        benefit_plans = list(rxplans['plan_name'])
        if row['benefit_plan_name'] not in benefit_plans:
            logrecs = record_error(row, [{'key': 'Plan Name',
                                          'value': row['benefit_plan_name']}],
                                   f"Invalid Benefit Plan Name.  Valid values: {benefit_plans}",
                                   logrec=logrecs)
            data_validation['Invalid_benefit_plan_name'] += 1
            data_validation['Total_errors'] += 1
            planname_validation = False
            continue
        # invalid benefit plan name

        if row['employment_status'].lower().strip() not in ['active', 'terminated', 'cobra']:
            valid_values = 'Active/Cobra/Terminated'
            logrecs = record_error(row, [{'key': 'Employment Status',
                                          'value': row['employment_status']}],
                                   f"Invalid Employment Status.  Valid values: {valid_values}",
                                   logrec=logrecs)
            data_validation['Invalid_employment_status'] += 1
            data_validation['Total_errors'] += 1
            empstatus_validation = False
            continue
        # invalid employment status

        if row['domain_name'].upper().strip() not in domaindblist:
            logrecs = record_error(row, [{'key': 'Domain Name',
                                          'value': row['domain_name']}],
                                   "Invalid domain!!",
                                   logrec=logrecs)

            data_validation['Invalid_domain_value'] += 1
            data_validation['Total_errors'] += 1
            domain_validation = False
            continue
        # invalid domain name

        if row['employment_status'].lower().strip() == 'terminated':
            termrec = TerminatedEmployeeUpdate(cb_hndl, bucketname, row)
            if termrec is not None:
                # following attributes were added to avoid KeyError issues
                termrec['benefit_plan_name'] = row['benefit_plan_name']
                termrec['coverage_effective_date'] = datetime.strftime(row['coverage_effective_date'],
                                                                       '%Y-%m-%d 00:00:00')
                termrec['coverage_termination_date'] = termrec['eligibility'][-1]['coverage_termination_date']
                termrec['coverage_tier_name'] = getCTier_names(cb_hndl, bucketname, domain_name,
                                                               row['coverage_tier_name'].strip())
                records.append(termrec)
                numinactive += 1
                # print('Numinactive', numinactive)
            continue

        # do validation on email address for conformity
        email_value = row['work_email'].strip()
        if not email_value:
            logrecs = record_error(row, [{'key': 'Work Email',
                                          'value': row['work_email']}],
                                   "No email address specified for primary",
                                   logrec=logrecs)

            primaryemail_validation = False
            data_validation['Invalid_work_email_address'] += 1
            data_validation['Total_errors'] += 1
            continue
        else:
            import re
            email_regex = re.compile(
                r'^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$')

            if not email_regex.match(email_value):
                logrecs = record_error(row, [{'key': 'Work Email',
                                              'value': row['work_email']}],
                                       "Email doesnt follow know email address convention",
                                       logrec=logrecs)

                primaryemail_validation = False
                data_validation['Invalid_work_email_address'] += 1
                data_validation['Total_errors'] += 1
                continue
        # end loop

        # do data validation
        for col in empcols:
            if col in ('home_address_1', 'home_address_2', 'city', 'state'):
                if (isinstance(row[col], int)):
                    logrecs = record_error(row, [{'key': 'Home Address',
                                                  'value': row[col]}],
                                           f'Home Address: {col} is numeric - value: {row[col]}',
                                           logrec=logrecs)

                    data_validation['Invalid_address_data'] += 1
                    data_validation['Total_errors'] += 1
                    demograpic_validation = False
                    continue

                if col in ['state', 'city'] and len(row[col]) == 0:
                    logrecs = record_error(row, [{'key': 'Home Address', 'value': row[col]}],
                                           f'Home Address: {col} is empty - value: <{row[col]}>',
                                           logrec=logrecs)

                    data_validation['Invalid_address_data'] += 1
                    data_validation['Total_errors'] += 1
                    demograpic_validation = False
                    continue

            if col in ['coverage_effective_date', 'coverage_termination_date']:
                emprecs[col] = row[col]
                continue
            emprecs[col] = str(row[col])
        # end loop for copy

        numactive += 1

        # convert hire_date and date_of_birth to string
        row['hire_date'] = row['hire_date'].strftime('%Y-%m-%d 00:00:00')
        row['date_of_birth'] = row['date_of_birth'].strftime(
            '%Y-%m-%d 00:00:00')

        # if dependent file contains UID column, make sure to sent UID in primary account
        # based on employee_id
        if 'UID' in depchecklist:
            emprecs['UID'] = emprecs['employee_id']

        # below logic supports for getting the plan year if it is in a single rxplan row or
        # across two plan years wit different start and termination
        if len(plan_years) == 1:
            plan_row = None
            if ((row['benefit_plan_name'] == rxplans['plan_name']) &
                    (row['domain_name'] == rxplans['domain_name'])).any() == True:
                plan_row = rxplans.loc[((row['benefit_plan_name'] == rxplans['plan_name']) &
                                        (row['domain_name'] == rxplans['domain_name']))]

            try:
                plan_start = datetime.strptime(
                    plan_row['plan_start_date'].values[0], '%Y-%m-%d %H:%M:%S')
                plan_term = datetime.strptime(
                    plan_row['plan_end_date'].values[0], '%Y-%m-%d %H:%M:%S')
            except:
                logrecs = record_error(row, [{'key': 'Plan Details',
                                              'value': row['benefit_plan_name']}],
                                       f"Unable to retrieve plan details by : <{row['benefit_plan_name']}>",
                                       logrec=logrecs)

                data_validation['Invalid_benefit_plan_name'] += 1
                data_validation['Total_errors'] += 1
                planretrieve_validation = False
                continue
        else:
            if ((row['benefit_plan_name'] == rxplans['plan_name']) &
                (row['domain_name'] == rxplans['domain_name']) &
                    (str(row['coverage_effective_date'].year) == rxplans['plan_year'])).any() == True:
                planstart_row = rxplans.loc[((row['benefit_plan_name'] == rxplans['plan_name']) &
                                             (row['domain_name'] == rxplans['domain_name']) &
                                             (str(row['coverage_effective_date'].year) == rxplans['plan_year']))]

            if ((row['benefit_plan_name'] == rxplans['plan_name']) &
                    (str(row['coverage_termination_date'].year) == rxplans['plan_year'])).any() == True:
                planend_row = rxplans.loc[((row['benefit_plan_name'] == rxplans['plan_name']) &
                                           (str(row['coverage_termination_date'].year) == rxplans['plan_year']))]

            try:
                plan_start = datetime.strptime(
                    planstart_row['plan_start_date'].values[0], '%Y-%m-%d %H:%M:%S')
                plan_term = datetime.strptime(
                    planend_row['plan_end_date'].values[0], '%Y-%m-%d %H:%M:%S')
            except:
                logrecs = record_error(row, [{'key': 'Plan Details',
                                              'value': row['benefit_plan_name']}],
                                       f"Unable to retrieve plan details by : <{row['benefit_plan_name']}>",
                                       logrec=logrecs)

                data_validation['Invalid_benefit_plan_name'] += 1
                data_validation['Total_errors'] += 1
                planretrieve_validation = False
                continue

        # coverage assignment for Active members
        if row['employment_status'].lower() != 'cobra':
            startdate_val = None
            if row['coverage_effective_date'] >= plan_start:
                startdate_val = row['coverage_effective_date']

            else:
                startdate_val = plan_start

            enddate_val = None
            if row['coverage_termination_date'] <= plan_term:
                enddate_val = row['coverage_termination_date']

            else:
                enddate_val = plan_term

            emprecs['coverage_termination_date'] = enddate_val
            emprecs['coverage_effective_date'] = startdate_val
            emprecs['cobra_effective_date'] = ''
            emprecs['cobra_termination_date'] = ''

        else:  # status is COBRA
            startdate_val = None
            enddate_val = None
            if row['coverage_effective_date'] < plan_start:
                startdate_val = plan_start

            elif row['coverage_effective_date'] >= plan_start:
                startdate_val = plan_start

            if row['coverage_termination_date'] > plan_term:
                enddate_val = plan_term

            elif row['coverage_termination_date'] <= plan_term:
                enddate_val = row['coverage_termination_date']

            emprecs['coverage_effective_date'] = startdate_val
            emprecs['coverage_termination_date'] = enddate_val
            emprecs['cobra_effective_date'] = row['coverage_effective_date']
            emprecs['cobra_termination_date'] = row['coverage_termination_date']

            emprecs['cobra_termination_date'] = datetime.strftime(emprecs['cobra_termination_date'],
                                                                  '%Y-%m-%d 23:59:59')
            emprecs['cobra_effective_date'] = datetime.strftime(emprecs['cobra_effective_date'],
                                                                '%Y-%m-%d 00:00:00')
        # end for COBRA

        if emprecs['coverage_termination_date'] is not None:
            emprecs['coverage_termination_date'] = datetime.strftime(emprecs['coverage_termination_date'],
                                                                     '%Y-%m-%d 23:59:59')
        else:
            emprecs['coverage_termination_date'] = f"{plan_term.year}-01-01 00:00:00"

        if emprecs['coverage_effective_date'] is not None:
            emprecs['coverage_effective_date'] = datetime.strftime(emprecs['coverage_effective_date'],
                                                                   '%Y-%m-%d 00:00:00')
        else:
            emprecs['coverage_effective_date'] = f"{plan_start.year}-12-31 23:59:59"

        emprecs['work_email'] = emprecs['work_email'].lower()
        emprecs['coverage_tier_name'] = getCTier_names(cb_hndl, bucketname, domain_name,
                                                       emprecs['coverage_tier_name'].strip())

        if emprecs['coverage_tier_name'] in (None, ''):
            logrecs = record_error(row, [{'key': 'Coverage Tier',
                                          'value': row['coverage_tier_name']}],
                                   'Coverage Tier Name Validation Error (Employee)',
                                   logrec=logrecs)

            data_validation['Invalid_coverage_tier'] += 1
            data_validation['Total_errors'] += 1
            tiername_validation = False
            continue
        # invalid coverage tier

        emprecs['dependents'] = []
        emprecs['locations'] = []
        plan = None

        # checks whether plan given in new file is valid
        if not rxplans.empty:
            plan = validate(rxplans, emprecs['benefit_plan_name'])

        emprecs['person_code'] = '01'
        pd.set_option('mode.chained_assignment', None)
        deps = depfile.loc[depfile['employee_id'] == row['employee_id']]
        deps.sort_values(by=['date_of_birth'], inplace=True)
        child_cntr = 3
        for depfiles, val in deps.iterrows():
            dep = dict()

            for rdep in depcols:
                if rdep in ['coverage_effective_date', 'coverage_termination_date']:
                    dep[rdep] = val[rdep]
                else:
                    dep[rdep] = str(val[rdep]).replace("\'", '')

            # check #ssn for dependents
            (ssnnumber_validation, logrecs) = validate_ssn(row['domain_name'], dep, log_rec=logrecs)
            if ssnnumber_validation is True:
                data_validation['Invalid_SSN_specification'] += 1
                data_validation['Total_errors'] += 1
                continue

            dep['domain_name'] = emprecs['domain_name']
            try:
                dep_status = dep['status']
            except KeyError:
                dep_status = row['employment_status']

            if dep_status.lower() != 'cobra':
                startdate_val = None
                enddate_val = None
                if dep['coverage_effective_date'] >= plan_start:
                    startdate_val = dep['coverage_effective_date']
                else:
                    startdate_val = plan_start

                if dep['coverage_termination_date'] <= plan_term:
                    enddate_val = dep['coverage_termination_date']
                else:
                    enddate_val = plan_term

                dep['coverage_termination_date'] = enddate_val
                dep['coverage_effective_date'] = startdate_val
                dep['cobra_effective_date'] = ''
                dep['cobra_termination_date'] = ''

            else:  # employee's status is COBRA
                startdate_val = None
                enddate_val = None
                if dep['coverage_effective_date'] < plan_start:
                    startdate_val = plan_start

                elif dep['coverage_effective_date'] >= plan_start:
                    startdate_val = plan_start

                if dep['coverage_termination_date'] > plan_term:
                    enddate_val = plan_term

                elif dep['coverage_termination_date'] <= plan_term:
                    enddate_val = dep['coverage_termination_date']

                dep['coverage_effective_date'] = startdate_val
                dep['coverage_termination_date'] = enddate_val
                dep['cobra_effective_date'] = row['coverage_effective_date']
                dep['cobra_termination_date'] = row['coverage_termination_date']

                dep['cobra_termination_date'] = datetime.strftime(dep['cobra_termination_date'],
                                                                '%Y-%m-%d 23:59:59')
                dep['cobra_effective_date'] = datetime.strftime(dep['cobra_effective_date'],
                                                              '%Y-%m-%d 00:00:00')
            # end for COBRA

            if dep['coverage_termination_date'] is not None:
                dep['coverage_effective_date'] = datetime.strftime(dep['coverage_effective_date'],
                                                                 '%Y-%m-%d 00:00:00')

            if dep['coverage_effective_date'] is not None:
                dep['coverage_termination_date'] = datetime.strftime(dep['coverage_termination_date'],
                                                                   '%Y-%m-%d 23:59:59')

            if 'ACS001' in domain_name and 'tpa_member_id' not in d:
                dep['tpa_member_id'] = emprecs['tpa_member_id']

            if 'tpa_member_id' in depchecklist and 'tpa_member_id' not in d:
                dep['tpa_member_id'] = emprecs['tpa_member_id']

            # check coverage tier name validity
            if 'coverage_tier_name' in dep:
                dep['coverage_tier_name'] = getCTier_names(cb_hndl, bucketname, domain_name,
                                                         dep['coverage_tier_name'].strip())
                if dep['coverage_tier_name'] in (None, ''):
                    logrecs = record_error(row, [{'key': 'Dep First Name', 'value': dep['first_name']},
                                                 {'key': 'Dep Last Name',
                                                     'value': dep['last_name']},
                                                 {'key': 'Coverage Tier', 'value': dep['coverage_tier_name']}],
                                           'Coverage Tier name validation error (dependent)',
                                           logrec=logrecs)

                    data_validation['Invalid_coverage_tier'] += 1
                    data_validation['Total_errors'] += 1
                    dep_tiername_validation = False
                    continue
                # invalid coverage tier

            # derive person code of dependents
            if 'spouse' in dep['relationship'].strip().lower():
                dep['person_code'] = '02'
            elif 'child' in dep['relationship'].strip().lower():
                dep['person_code'] = str(child_cntr).zfill(2)
                child_cntr += 1
            else:
                logrecs = record_error(row, [{'key': 'Dep First Name', 'value': dep['first_name']},
                                             {'key': 'Dep Last Name',
                                                 'value': dep['last_name']},
                                             {'key': 'Dependent relationship', 'value': dep['relationship']}],
                                       'Dependent relationship validation error',
                                       logrec=logrecs)

                data_validation['Invalid_emp-to-dep_relation'] += 1
                deprelation_validation = False
                continue
            # invalid relationship value

            if not (tiername_validation is True and deprelation_validation is True):
                continue

            emprecs['dependents'].append(copy.deepcopy(dep))
        # end - processing dependents

        # emprecs['active']=True
        emprecs['type'] = 'employee'
        if groupinf_present is False:
            emprecs['group'] = groups[emprecs['domain_name']]

        emprecs['zip'] = emprecs['zip'].zfill(5)
        emprecs['benefit_plan_name'] = plan

        if plan is None or plan == 'Error' or emprecs['benefit_plan_name'] == "":
            logrecs = record_error(row, [{'key': 'Plan Name', 'value': row['benefit_plan_name']}],
                                   "Plan name validation",
                                   logrec=logrecs)

            data_validation['Invalid_plan_name'] += 1
            data_validation['Total_errors'] += 1
            planname_validation = False
            continue

        if not tiername_validation or not dep_tiername_validation or not planname_validation \
                or not deprelation_validation or not empstatus_validation or not domain_validation \
                or not demograpic_validation or not primaryemail_validation or not planretrieve_validation \
                or not hiredate_validation:
            continue

        records.append(emprecs)

    if len(records) == 0:
        records = None

    return records, logrecs, updatecarrierflag, numactive, numinactive, data_validation, rxplans
# end function
