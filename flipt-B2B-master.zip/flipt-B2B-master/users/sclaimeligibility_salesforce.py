########################################
# !/usr/bin/env python  
# title         : sclaimeligibility_salesforce.py
# description   : generate scriptclaim eligibilty file for salesforce
# author        : Rajesh Acharya
# date created  : 2020-03-04
# date last modified    :
# version       : 0.1
# maintainer    :
# email         :
# status        : Production
# Python Version: 3.7+
# usage			: python sclaimeligibility_salesforce.py -d GWLABS001 -t sceligibility -f scriptclaimeligibility -m DRAFT
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  
# #######################################

 
import os
import sys
import socket
import copy
import time
from datetime import datetime
from dateutil import parser

from utils import commandline
from utils.sendgridemail import email_log, email_log_custombody
from utils.truevault import User_Class
from utils.FliptConcurrent import concurrent
from utils.helper_functions import *



path = os.environ['CB_DATA']
orig_cmdargs = copy.deepcopy(sys.argv)

cmdline_args = process_alt_cmdline(additional=[['-d', '--domain', 'domain to extract report', True],
											   ['-t', '--file_type', 'type of file', True],
											   ['-f', '--file_name', 'name for the extract file', True]])

req = concurrent(orig_cmdargs[0], orig_cmdargs[1:])
sysdate = str(datetime.now())
current_date = datetime.now()
plan_year = str(current_date.year)
current_date = current_date.strftime("%m%d%Y%H%M%S")
cb = cb_authenticate()
if cb is None:
	sys.exit(-1)
	
cmdline_args['cb_handle'] = cb
cmdline_args['host'] = socket.gethostname()
cmdline_args['path'] = path
cmdline_args['currdate'] = datetime.now().strftime("%m/%d/%Y")
cmdline_args['file_name'] = f"{cmdline_args['file_name']}_{current_date}.txt"
subject = 'ScriptClaim'

#sending scriptclaim a list of all eligible users of flipt (employee and dependents)
def scriptclaim(arg_dict):
	from couchbase.n1ql import N1QLQuery

	numusers = 0
	mismatchusers = 0
	log_path = f"{arg_dict['path']}/{arg_dict['domain']}/{arg_dict['file_type']}/log/"
	text_file = f"{arg_dict['path']}/{arg_dict['domain']}/{arg_dict['file_type']}/" + \
				f"{arg_dict['domain']}_{arg_dict['file_name']}"
	
	try:
		stat = os.stat(log_path)
	except FileNotFoundError:
		os.makedirs(log_path, exist_ok=True)
		
	log_name = f"{log_path}/{arg_dict['file_name']}"
	
	piped_datafile = open(text_file, "w")
	log_file = open(log_name, "w")
	#mm = pd.DataFrame()
	domainlist=[]
	domainlist.append(arg_dict['domain'])
	if 'GWLABS001' in domainlist: 
		domainlist.append('FLIPT001')
		
	#pull all records from flipt_person_hierarchy and process with other details while writing to a text file
	flipttab = N1QLQuery('select distinct emp_flipt_person_id,domain_name from `' + 
						 os.environ['CB_INSTANCE'] +
						 '` WHERE type="flipt_person_hierarchy" ' +
						 'and domain_name in $domain_name',
						 domain_name=domainlist)
	
	flipttab.adhoc = False
	flipttab.timeout = 1000
	
	log_file.write("Carrier  Account   Group         CardHolder ID	   Person Code\n")
	log_file.write("===============================================================\n")
	for fliptrow in arg_dict['cb_handle'].n1ql_query(flipttab):
		#print(fliptrow)
		domain = fliptrow['domain_name']
		emp_flipt_id = str(fliptrow['emp_flipt_person_id'])
#		print(emp_flipt_id)
		obj = User_Class(None, None, cb_handle=cb)
		search_option = {
			'full_document': True,
			'filter':
				{
					'domain_name':
						{
							'type': 'eq',
							'value': domain,
							'case_sensitive': False
						},
					'flipt_person_id':
						{
							'type': 'eq',
							'value': emp_flipt_id,
							'case_sensitive': False
						},
					'$tv.status':
						{
							'type': 'eq',
							'value':'ACTIVATED'
						}
				},
			'filter_type': 'and'
		}

		att, userid = obj.search_user(search_option)
		if att is not None:
			if 'TEST' in att['employee_id'].upper():
				continue

			carrier = 'FLIPT'
			if domain=='FLIPT001':
				carrier = 'FLIPT2'

			account = domain
			group = str(att['group'])
			first_name = str(att['first_name'])
			last_name = str(att['last_name'])
			card_holder_id = emp_flipt_id + att['person_code']
			person_code = att['person_code']
			relationship_code = '1'
			middle_initial = ' '
			sex = att['gender']
			dob = datetime.strptime(str(att['date_of_birth']), "%Y-%m-%d %H:%M:%S")
			dob = dob.strftime('%Y%m%d')
			ssn = ''
			address_line1 = att['home_address_1']
			address_line1 = address_line1[0:24]
			#print(add1)
			address_line2 = att['home_address_2']
			address_line2 = address_line2[0:14]
			city = att['city']
			city = city[0:19]
			state = att['state']
			zip = att['zip']
			zip2 = ''
			phone = '9999999999'
			family_id = emp_flipt_id
			try:
				coverage_effective_date = att['coverage_effective_date']
				from_date = datetime.strptime(str(coverage_effective_date), "%Y-%m-%d %H:%M:%S")
				from_date = from_date.strftime('%Y%m%d')
			except KeyError:
				continue

			# if the coverage_effective_date is past year, skip record
			if plan_year not in coverage_effective_date:
				continue

			try:
				coverage_termination_date = att['coverage_termination_date']
				thru_date = datetime.strptime(str(coverage_termination_date), "%Y-%m-%d %H:%M:%S")
				thru_date = thru_date.strftime('%Y%m%d')
			except KeyError:
				continue

			email_address = att['work_email']
			plan = ''
			numusers += 1
			piped_datafile.write(f"{carrier}|{account}|{group}|{card_holder_id}|{person_code}|{relationship_code}|" +
						   f"{last_name}|{first_name}|{middle_initial}|{sex}|{dob}|{ssn}|{address_line1}|" +
						   f"{address_line2}|{city}|{state}|{zip}|{zip2}|{phone}|{family_id}|" +
						   f"{from_date}|{thru_date}|{email_address}\r\n")
			
			log_file.write(carrier.ljust(9) + account.ljust(9) + group.ljust(15) +
						   card_holder_id.ljust(18) + person_code.ljust(3) + relationship_code +
						   "\r\n")

			if arg_dict['mode'].upper() == 'FINAL':
				cb.n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
										'` SET sc_extracted_date=$exdate WHERE ' +
										'type="flipt_person_hierarchy" ' +
										'and emp_flipt_person_id=$empfid ' +
										'and dep_flipt_person_id=$depfid',
										exdate=sysdate,
										empfid=emp_flipt_id,
										depfid=emp_flipt_id)).execute()

			for dep in att['dependents']:
				#carrier = 'FLIPT'
				account = domain
				group = str(att['group'])
				depfliptid = str(dep['flipt_person_id'])
				first_name = str(dep['first_name'])
				last_name = str(dep['last_name'])
				card_holder_id = emp_flipt_id + dep['person_code']
				person_code = dep['person_code']
				if person_code == '02':
					relationship_code = '2'
				else:
					relationship_code = '3'
				middle_initial = ' '
				sex = ' '
				dob = datetime.strptime(str(dep['date_of_birth']), "%Y-%m-%d %H:%M:%S")
				dob = dob.strftime('%Y%m%d')
				ssn = ''

				address_line1 = att['home_address_1']
				address_line1 = address_line1[0:24]
				address_line2 = att['home_address_2']
				address_line2 = address_line2[0:14]
				city = att['city']
				city = city[0:19]
				state = att['state']
				zip = att['zip']
				zip2 = ''
				phone = '9999999999'
				family_id = emp_flipt_id

				try:
					dep_cov_eff_date = dep['coverage_effective_date']
					from_date = datetime.strptime(str(dep_cov_eff_date), "%Y-%m-%d %H:%M:%S")
					from_date = from_date.strftime('%Y%m%d')
				except KeyError:
					continue

				# if the coverage_effective_date is past year, skip record
				if plan_year not in coverage_effective_date:
					continue

        try:
					dep_cov_term_date = dep['coverage_termination_date']
					thru_date = datetime.strptime(str(dep_cov_term_date), "%Y-%m-%d %H:%M:%S")
					thru_date = thru_date.strftime('%Y%m%d')
				except KeyError:
					continue

				email_address = att['work_email']
				plan = ''
				numusers += 1
				piped_datafile.write(f"{carrier}|{account}|{group}|{card_holder_id}|{person_code}|{relationship_code}|" +
							   f"{last_name}|{first_name}|{middle_initial}|{sex}|{dob}|{ssn}|{address_line1}|" +
							   f"{address_line2}|{city}|{state}|{zip}|{zip2}|{phone}|{family_id}|" +
							   f"{from_date}|{thru_date}|{email_address}\r\n")

				log_file.write(carrier.ljust(9) + account.ljust(9) + group.ljust(15) +
							   card_holder_id.ljust(18) + person_code.ljust(3) +
							   relationship_code+"\r\n")

				if arg_dict['mode'].upper() == 'FINAL':
					cb.n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
											'` SET sc_extracted_date=$exdate WHERE ' +
											'type="flipt_person_hierarchy" ' +
											'and emp_flipt_person_id=$empfid ' +
											'and dep_flipt_person_id=$depfid',
											exdate=sysdate,
											empfid=emp_flipt_id,
											depfid=depfliptid)).execute()
			# end loop - for dependents
		# end - att != None
	# end outer-loop

	piped_datafile.close()

	if arg_dict['mode'].upper() == 'FINAL':
		scriptclaim_salesforce_email = os.environ['SCRIPTCLAIM_TO_SALESFORCE']
		email_log_custombody('noreply@fliptrx.com', scriptclaim_salesforce_email,
							 'FliptIntegration@fliptrx.com',
							 "ScriptClaimEligibility Salesforce",
							 "Hello,<br><br>" +
							 f"This is the Flipt Eligibility File as of {arg_dict['currdate']}.<br><br>" +
							 "From Flipt Team", text_file,
							 attached=True,
							 override='Y')
	else:
		#os.remove(textfile)
		log_file.write('ScriptClaimEligibility - Draft Mode : ' + text_file)
		log_file.close()
		print('Salesforce_ScriptClaimEligibility - Draft Mode : '+ text_file)
		subject = 'ScriptClaimEligibility - Salesforce - Draft Mode - ' + arg_dict['host']
		email_log('noreply@fliptrx.com', 'FliptIntegration@fliptrx.com', None,
                        subject, ['Processing of ScriptClaim Eligibility File ' + log_name,
                            'ScriptClaim Eligibility Exception'], log_name, True)
	return numusers
# end function
	
numusers = scriptclaim(cmdline_args)
req.no_rec_received = numusers

req.close()       
