#!/usr/bin/env python
########################################
# title         : 1ftpemployeeops.py
# description   : ftp operations upload/download/archive for employee files
# author        :   Hari
# date created  : 20190813
# date last modified    :
# version       : 0.1
# maintainer    : Hari
# email         : -
# status        : Production
# Python Version: 3.5.2
# usage         : python users/ftpemployeeops.py -d GWLABS001 -t employee -f dummy -m final
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#
# #######################################
from users.emp_dep_fileops import *
from utils.insmemberid_update import *
from utils import commandline
from utils.helper_functions import *
from utils.aws_sftp import *


def check_domain_threshold(data_val, row_count, dom_thresh):
    '''
    Calculates the threshold percentages for keys based on domain threshold limits.
    :param data_val:
    :param row_count:
    :param dom_thresh:
    :return: updated dictionary
    '''
    temp = dict()

    for keys in data_val:
        thresh_val = (data_val[keys] / row_count) * 100
        if thresh_val > dom_thresh:
            temp[f"Threshold_{keys}"] = thresh_val
        temp[keys] = data_val[keys]
    # end loop

    if 'Threshold_Total_errors' not in temp:
        temp['Threshold_Total_errors'] = 0.0

    return temp
# end function


def generate_threshold_message(thresh_dict, domain_threshold, html=None):
    '''
    generates a html/standard text string of calculated threshold values
    :param thresh_dict:
    :param domain_threshold:
    :param html:
    :return: html/normal text string
    '''
    threshold_str = ""
    threshold_str += f"Error threshold limit: < "
    if html is not None:
        threshold_str += f"<strong>{domain_threshold}%</strong>"
    else:
        threshold_str += f"{domain_threshold}" + "%"

    if html is not None:
        threshold_str += "<br>"
        threshold_str += '<table border=0>'
    else:
        threshold_str += "\n"

    for keys in sorted(thresh_dict):
        key_val = keys.replace("_", " ")
        if html is None:
            if key_val[0:9] == 'Threshold':
                threshold_str += f'{key_val}: *{thresh_dict[keys]}%\r\n'
            else:
                threshold_str += f"{key_val}: {thresh_dict[keys]}\r\n"
        else:
            if key_val[0:9] != 'Threshold':
                threshold_str += f"<tr><td>{key_val}</td><td>{thresh_dict[keys]}</td></tr>"
            else:
                threshold_str += f"<tr><td><font color='red'><strong>{key_val}</strong></font></td>"
                threshold_str += f"<td><font color='red'><strong>{thresh_dict[keys]}%</strong></font></td></tr>"
    # end loop
    if html is not None:
        threshold_str += "</table>"
    return threshold_str
# end function


def main():
    import sys
    import os
    import json
    import pandas as pd
    from utils.file_comp_log import FileComp
    from couchbase.n1ql import N1QLQuery
    from utils.sendgridemail import email_log

    currentdate = datetime.now().strftime('%Y%m%d_%H%M%S')
    path = os.environ['CB_DATA']
    cb = cb_authenticate()
    if cb is None:
        sys.exit(-1)

    bucket_name = os.environ['CB_INSTANCE']
    instance_type = os.environ['INSTANCE_TYPE']
    eligibility_mail_list = ''
    override_threshold = None
    files = []

    cmdline_rec = process_alt_cmdline(additional=[['-d', '--domain',
                                                   'Domain for which the eligibility file being loaded', True],
                                                  ['-t', '--file_type',
                                                   'type of data being loaded. (should be employee', True],
                                                  ['-y', '--plan_year',
                                                   'Use specific plan year details for plans', True],
                                                  ['-o', '--override',
                                                      'to over-ride the threshold warnings!!', False],
                                                  ['-c', '--createfile',
                                                   'creates a json file of users for sending email', False],
                                                  ['-w', '--notify_user',
                                                   'Send email to user when plan changes', False],
                                                  ['-s', '--supress_emails', 'Supress sending emails to HR', False],                                                  ['-p', '--maxplans',
                                                                                                                                                                        'How many historical plan years to retain (def: 10)', False]])
    if cmdline_rec['override'] is None:
        override_threshold = 'N'
    else:
        override_threshold = cmdline_rec['override']

    if cmdline_rec['notify_user'] in (None, 'N', 'n'):
        notify_user = 'N'
    else:
        notify_user = 'Y'

    if cmdline_rec['supress_emails'] in [None, 'N', 'n']:
        supress_emails = 'N'
    else:
        supress_emails = 'Y'

    if cmdline_rec['maxplans'] is None:
        cmdline_rec['maxplans'] = 10
    else:
        cmdline_rec['maxplans'] = int(cmdline_rec['maxplans'])

    if cmdline_rec['createfile'] in (None, 'N', 'n'):
        createjson = False
    else:
        createjson = True

    domain = cmdline_rec['domain']
    file_type = cmdline_rec['file_type']
    processing_type = cmdline_rec['mode']
    plan_year = cmdline_rec['plan_year']

    domain_name = domain

    logger = setup_logging_path('ELIGIBILITY', 'ftpemployee', 'FTPEMPLOYEE')
    # get eligibility_mail_list from domain table
    if instance_type in ['DEV', 'STAGE', 'QA']:
        eligibility_mail_list = "fliptintegration@fliptrx.com"
    else:
        query = N1QLQuery('Select eligibility_mail_list from `' + bucket_name +
                          '` where type="domain" and domain=$d',
                          d=domain)

        eligibility_mail_list = cb.n1ql_query(query).get_single_result()[
            'eligibility_mail_list']
    # end check

    # get threshold-limit on eligibility field changes
    query = N1QLQuery('Select eligibility_change_threshold from `' + bucket_name +
                      '` where type="domain" and domain=$d',
                      d=domain)
    eligibility_change_threshold = float(cb.n1ql_query(query).get_single_result()[
                                         'eligibility_change_threshold'])

    sender = 'noreply@fliptrx.com'
    if file_type.lower() != 'employee':
        body = ['Error File Type in Command', 'Employee Dependent Exception']

        subject = 'Employee-Dependent Update - Aborted:' + processing_type + ' mode'
        email_log(sender, eligibility_mail_list, None, subject,
                  body, None, type='eligibility', attached=False)
        sys.exit()

    # setup SFTP handler
    sftp_hndlr = AWS_SFTP(domain, 'ELIGIBILITY')

    sftp_hndlr.sftp_getfilelist(sftp_hndlr.sftp_home)

    if len(sftp_hndlr.sftp_file_list) == 0:
        body = [' No Employee-Dependent files available for processing',
                "Employee Dependent Exception"]

        subject = 'Employee-Dependent Update - Aborted :' + processing_type + ' mode'
        print("No files available for processing\n\n")
        logger.info("No files available for processing")
        # email_log(sender, eligibility_mail_list, None, subject, body, None, type='eligibility', attached=False)
        sys.exit(0)

    body = None
    hostnameprod = 'newprod-python-e1a'

    localpath = f"{path}/{domain}/employee/"
    fileComp = FileComp(localpath, domain_name, 'EmpDep')

    try:
        os.mkdir(localpath)
    except:
        pass

    try:
        os.mkdir(localpath + "log")
    except:
        pass

    srch_mtrx = {
        'EMP': 'DEP',
        'emp': 'dep',
        'Emp': 'Dep'
    }

    stat, empfl1 = sftp_hndlr.sftptransfer(
        None, localpath, 'GET', phrase='employee', searchdict=srch_mtrx)
    if stat == 'E':
        print("No files found or invalid naming convention!!")
        logger.info("EMP: No files found or invalid naming convention!!")
        sys.exit(-1)

    # make sure the use corresponding dependent file
    stat, depfl1 = sftp_hndlr.sftptransfer(
        None, localpath, 'GET', searchstr=srch_mtrx, empfile=empfl1)
    if stat == 'E':
        print("No files found or invalid naming convention!!")
        logger.info("DEP: No files found or invalid naming convention!!")
        sys.exit(-1)

    files.append(empfl1)
    files.append(depfl1)

    if 'xlsx' in empfl1:
        try:
            empfile = pd.read_excel(localpath + empfl1, header=0)
        except:
            print("Downloaded employee file seem to be unreadable/protected!!")
            logger.info(
                "Downloaded employee file seem to be unreadable/protected")
            sys.exit(-1)
    else:
        print("ERROR: Downloaded employee file is not an Excel file!!")
        logger.info("Downloaded employee is not an Excel file")
        sys.exit(-1)

    if 'xlsx' in depfl1:
        try:
            depfile = pd.read_excel(localpath + depfl1, header=0)
        except:
            print("Downloaded dependent file seem to be un-readable/protected!!")
            logger.info(
                "Downloaded dependent file seem to be un-readable/protected")
            sys.exit(-1)
    else:
        print("ERROR: Downloaded dependent file is not an Excel file!!")
        logger.info("Downloaded dependent file is not an Excel file")
        sys.exit(-1)

    # zero fill the zip-code column
    empfile['zip'] = empfile['zip'].apply(lambda x: str(x).zfill(5))
    # replace all 'NaN' values with empty string
    empfile.fillna(value='', inplace=True)

    empfile['employee_ssn'] = empfile['employee_ssn'].apply(lambda x: str(x).zfill(9))
    depfile['dependent_ssn'] = depfile['dependent_ssn'].apply(lambda x: str(x).zfill(9))

    (empfile_row_count, _) = empfile.shape

    print(empfile.columns)

    body = ['Processing of Employee-Dependent files ' +
            empfl1 + ' & ' + depfl1, "Employee Dependent Exception"]

    localpath1 = path + '/' + domain + '/' + file_type + \
        f'/log/{domain}_eligibilityload_{currentdate}.xlsx'
    writer = pd.ExcelWriter(localpath1, engine='xlsxwriter')
    subject = 'Employee-Dependent Update - Completed :' + processing_type + ' mode'

    logrecs = pd.DataFrame()
    ptime = pd.DataFrame()

    ptime.loc[0, 'Update Start'] = str(datetime.now())

    eligibility_mail_list = str(eligibility_mail_list)
    print('Mail List', eligibility_mail_list)

    subject = 'Employee-Dependent Update - Completed :' + processing_type + ' mode'

    numactive, numinactive = 0, 0
    data_validation = dict()
    print("numactive, numinactive: ", numactive, numinactive)

    (records, logrecs, updatecarrierflag,
     numactive, numinactive, data_validation,
     rxplan_data) = EmployeeDependentConverterUpdation(cb, bucket_name,
                                                       domain_name,
                                                       plan_year,
                                                       processing_type,
                                                       logrecs, numactive,
                                                       numinactive, empfile,
                                                       depfile, data_validation)

    if records is not None:
        print("# of valid records = ", len(records))

    threshold_errors = check_domain_threshold(
        data_validation, empfile_row_count, eligibility_change_threshold)
    threshold_metrics = generate_threshold_message(
        threshold_errors, eligibility_change_threshold, html='Y')
    logger.info(generate_threshold_message(
        threshold_errors, eligibility_change_threshold))

    if records is None or threshold_errors['Threshold_Total_errors'] > float(eligibility_change_threshold):
        logrecs.to_excel(writer, index=False, sheet_name='error')
        writer.save()
        subject = 'Employee-Dependent Update - Aborted:' + \
            processing_type + ' mode - Data Validation'

        if supress_emails.lower() == 'n':
            email_log(sender, 'FliptIntegration@fliptrx.com', eligibility_mail_list, subject, body,
                      localpath1, type='eligibility', errors=threshold_metrics)

        stat, _ = sftp_hndlr.sftptransfer(
            localpath1, sftp_hndlr.sftp_download, 'PUT')
        # stat, _ = sftp_hndlr.sftpremove(f"{empfl1}")
        # stat, _ = sftp_hndlr.sftpremove(f"{depfl1}")
        if override_threshold.upper() == 'N':
            sys.exit(-1)

    sftp_hndlr.sftp_close()
    terminatedlog = pd.DataFrame()
    eligibility_log = pd.DataFrame()

    if override_threshold.upper() == 'Y':
        print("\n\nThreshold errors being over-ridden!!")
        if processing_type.lower() == 'final':
            print("Expect flood of emails during updates")

    sendgrid_userchanges = []
    dom_mapping = get_domain_mapping(cb)
    if processing_type.strip().lower() == 'final':
        print(generate_threshold_message(
            threshold_errors, eligibility_change_threshold))
        if records is not None:
            curr_year = datetime.now().year
            # go through each record and call truevault program's update user function to update
            # attributes to truevault and flipt_person_hierarchy
            for record in records:
                attribute = json.dumps(record)
                orig_value = json.loads(attribute)

                if 'coverage_effective_date' in record:
                    curr_year = record['coverage_effective_date'][:4]

                user_obj = User_Class(record['work_email'].lower(), None, record,
                                      os.environ['CB_GROUP_ID'], cb_handle=cb,
                                      maxplans=cmdline_rec['maxplans'],
                                      dom_map=dom_mapping)
                (termlog, eligibilityerr, sendgrid_userchanges, jnk) = user_obj.update_user(sendgrid_userchanges,
                                                                                            log_hndl=logger,
                                                                                            hr_email=eligibility_mail_list,
                                                                                            notify_user=notify_user,
                                                                                            createfile=createjson,
                                                                                            fileComp=fileComp)

                terminatedlog = terminatedlog.append(
                    termlog, ignore_index=True)
                eligibility_log = eligibility_log.append(
                    eligibilityerr, ignore_index=True)
                if updatecarrierflag is True:
                    res = update_ins_carrier_details(cb, orig_value)
                    print('Response from ins carrier update: ', res)
                    if res != 'Success':
                        logrecs = logrecs.append({'Domain Name': orig_value['domain_name'],
                                                  'Employee ID': orig_value['employee_id'],
                                                  'First Name': orig_value['first_name'],
                                                  'Last Name': orig_value['last_name'],
                                                  'Coverage Tier Name': '',
                                                  'Dependent-Relationship': '',
                                                  'Plan Name': orig_value['benefit_plan_name'],
                                                  'Record Error': 'Carrier Member Update Failed'},
                                                 ignore_index=True)

        # end final
    else:
        print(generate_threshold_message(
            threshold_errors, eligibility_change_threshold))
        if records is not None:
            curr_year = datetime.now().year
            # go through each record and call truevault program's update user function to update
            # attributes to truevault and flipt_person_hierarchy
            for record in records:
                attribute = json.dumps(record)
                orig_value = json.loads(attribute)

                if 'coverage_effective_date' in record:
                    curr_year = record['coverage_effective_date'][:4]

                user_obj = User_Class(record['work_email'].lower(), None, record,
                                      os.environ['CB_GROUP_ID'], cb_handle=cb,
                                      maxplans=cmdline_rec['maxplans'],
                                      dom_map=dom_mapping)
                (termlog, eligibilityerr, sendgrid_userchanges, jnk) = user_obj.update_user(sendgrid_userchanges,
                                                                                            mode=processing_type,
                                                                                            log_hndl=logger,
                                                                                            notify_user=notify_user,
                                                                                            createfile=createjson,
                                                                                            fileComp=fileComp)

                terminatedlog = terminatedlog.append(
                    termlog, ignore_index=True)
                eligibility_log = eligibility_log.append(
                    eligibilityerr, ignore_index=True)

                if updatecarrierflag is True:
                    res = update_ins_carrier_details(
                        cb, orig_value, mode=processing_type)
                    print('Response from ins carrier update', res)
                    if res != 'Success':
                        logrecs = logrecs.append({'Domain Name': orig_value['domain_name'],
                                                  'Employee ID': orig_value['employee_id'],
                                                  'First Name': orig_value['first_name'],
                                                  'Last Name': orig_value['last_name'],
                                                  'Coverage Tier Name': '',
                                                  'Dependent-Relationship': '',
                                                  'Plan Name': orig_value['benefit_plan_name'],
                                                  'Record Error': 'Carrier Member Update Failed'},
                                                 ignore_index=True)
        # end draft

    # save file compare files
    fileComp.write('pre')
    fileComp.write('post')

    if (fileComp.compare_files() is True):
        print(f"Compare file: {fileComp.comp_file}" + "\n\n")

    if createjson is True:
        if len(sendgrid_userchanges) > 0:
            datestamp = datetime.strftime(datetime.now(), "%Y_%m_%d-%H%M%S")
            sendgrid_data_flpath = f"/tmp/{domain_name}_sendgridemail_userdata_{datestamp}.json"

            fp = open(sendgrid_data_flpath, "w")
            json.dump(sendgrid_userchanges, fp, indent=True)
            fp.close()

    if {'First Name', 'Last Name'}.issubset(terminatedlog.columns):
        terminatedlog.drop(['First Name', 'Last Name'], axis=1, inplace=True)

    if {'First Name', 'Last Name'}.issubset(eligibility_log.columns):
        eligibility_log.drop(['First Name', 'Last Name'], axis=1, inplace=True)

    terminatedlog.to_excel(writer, index=False, sheet_name='Terminations')
    eligibility_log.to_excel(writer, index=False, sheet_name='Eligibility')

    ptime.loc[0, 'Processed employee file'] = empfl1
    ptime.loc[0, 'Processed dependent file'] = depfl1
    ptime.loc[0, '# of active employee records processed'] = numactive
    ptime.loc[0, '# of terminated employee records processed'] = numinactive
    if {'First Name', 'Last Name'}.issubset(logrecs.columns):
        logrecs.drop(['First Name', 'Last Name'], axis=1, inplace=True)

    logrecs.to_excel(writer, index=False, sheet_name='Errors')
    ptime.to_excel(writer, index=False, sheet_name='Log')
    writer.save()

    if supress_emails.lower() == 'n':
        email_log(sender, 'FliptIntegration@fliptrx.com', eligibility_mail_list, subject, body, localpath1,
                  type='eligibility', attached=True)

    # print(localpath1)
    # print(sftp_hndlr.sftp_download)

    if processing_type.strip().lower() == 'final':
        sftp_hndlr = AWS_SFTP(domain, 'ELIGIBILITY')
        sftp_hndlr.sftptransfer(localpath1, sftp_hndlr.sftp_download, 'PUT')
        os.unlink(localpath1)

        # transfer the data files to /uploads on sftp
        localpath1 = path + "/" + domain + "/" + file_type + "/"

        for fname in files:
            sftp_hndlr.sftptransfer(
                localpath1 + fname, sftp_hndlr.sftp_archive, 'PUT', )
            sftp_hndlr.sftpremove(fname)
            try:
                if processing_type.strip().lower() == 'final':
                    os.unlink(localpath1 + fname)
            except:
                pass
        # end loop

    # transfer the compare file
    if fileComp.filecompared is True:
        res, _ = sftp_hndlr.sftptransfer(localpath1 + os.path.basename(fileComp.comp_file),
                                         sftp_hndlr.sftp_download,
                                         'PUT')
        if res == 'S':
            os.unlink(localpath1 + os.path.basename(fileComp.comp_file))
    # end

    # transfer sendgrid_datafile to l_upload
    if createjson is True:
        try:
            stat = os.stat(sendgrid_data_flpath)
            res, _ = sftp_hndlr.sftptransfer(
                sendgrid_data_flpath, sftp_hndlr.sftp_home, 'PUT')
            if res == 'S':
                os.unlink(sendgrid_data_flpath)
        except:
            logger.error("Could not transfer sendgrid file to ftp location")
            pass

    sftp_hndlr.sftp_close()
    sys.exit(0)
# end main


if __name__ == '__main__':
    sys.exit(main())
