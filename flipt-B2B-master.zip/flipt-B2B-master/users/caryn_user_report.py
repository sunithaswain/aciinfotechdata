########################################
# !/usr/bin/env python  
# title         : caryn_user_report.py
# description   : creates the caryn user report in json format the follows the following layout
# author        : Rajesh Acharya
# date created  : 20191120
# date last modified    : 20190206 
# version       : 0.1
# maintainer    :
# email         :
# status        : Production
# Python Version: 3.5.2
# usage			: python caryn_user_report.py -d CARYN001 -t eligibility -m DRAFT
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  
# #######################################


def output_json(df, users_array):
	df.write("[\n")
	for user in users_array:
		df.write("  {\n")
		for keys in user:
			if keys != 'dependents':
				df.write(f"    {keys}: {user[keys]}\n")
			else:
				df.write(f"    {keys}: \n")
				for dep in user[keys]:
					df.write("      {\n")
					for sub_rec in dep:
						df.write(f"        {sub_rec}: {dep[sub_rec]}\n")
					df.write("      }")

					if len(user[keys]) == 1:
						df.write("\n")
					else:
						df.write(",\n")
				# end dependent loop
		df.write("  }")
		if len(users_array) == 1:
			df.write("\n")
		else:
			df.write(",\n")
	# end outer-loop
	df.write("]\n")
	df.close()
# end function


def user_report_gen(cfg_dict):
	import os
	import json
	from pprint import pprint
	from utils.truevault import User_Class
	from couchbase.n1ql import N1QLQuery
	from utils.sendgridemail import email_log

	datafile_nm = f"{cfg_dict['path']}/{cfg_dict['domain']}/{cfg_dict['file_type']}/{cfg_dict['outfile']}"
	datafile = open(datafile_nm, "w")

	domainlist = []
	domainlist.append(cfg_dict['domain'])
	users_list = []
	records_found = 0
	total_records = 0

	if 'GWLABS001' in domainlist:
		domainlist.append('FLIPT001')

	#pull all records from flipt_person_hierarchy and process with other details while writing to a text file
	flipttab = N1QLQuery('select distinct emp_flipt_person_id,domain_name from `' +
						 os.environ['CB_INSTANCE'] + '` WHERE type = "flipt_person_hierarchy" ' +
						 'and domain_name in $domain_name',domain_name = domainlist)
	flipttab.adhoc = False
	flipttab.timeout = 1000

	# logfile.write("Carrier  Account   Group         CardHolder ID	   Person Code\n")
	# logfile.write("===============================================================\n")
	for fliptrow in cfg_dict['cb_handle'].n1ql_query(flipttab):
		#print(fliptrow)
		domain = fliptrow['domain_name']
		emp_flipt_id = str(fliptrow['emp_flipt_person_id'])

		obj = User_Class(None,None,cb_handle=cfg_dict['cb_handle'])
		search_option = {'full_document': True,
						 'filter': {
							 'domain_name': {
								 'type': 'eq',
								 'value': domain,
								 'case_sensitive': False
							 },
							 'flipt_person_id': {
								 'type': 'eq',
								 'value': emp_flipt_id,
								 'case_sensitive': False
							 },
							 '$tv.status': {
								 'type': 'eq',
								 'value': 'ACTIVATED'
							 }
						 },
						 'filter_type': 'and'
						 }
		att, userid = obj.search_user(search_option)
		if att is not None:
			total_records += 1
			
			if att['employment_status'].lower() in ['active', 'cobra']:
				records_found += 1
				caryn_record = dict()
				try:
					caryn_record['UID'] = att['UID']
				except KeyError:
					continue

				caryn_record['flipt_person_id'] = att['flipt_person_id']
				dep_details = []

				for dep in att['dependents']:
					dep_rec = dict()
					dep_rec['UID'] = dep['UID']
					dep_rec['flipt_person_id'] = dep['flipt_person_id']
					dep_details.append(dep_rec)
				# end for loop

				if len(dep_details) != 0:
					caryn_record['dependents'] = dep_details
				users_list.append(caryn_record)
		# end - att is not None
	# end - for loop to gather users present in flipt_employee_hierarchy

	output_json(datafile, users_list)

	if cfg_dict['mode'].upper() == 'FINAL':
		sftp_conn = AWS_SFTP(cfg_dict['domain'], 'ELIGIBILITY')
		(status, crf) = sftp_conn.sftptransfer(datafile_nm, sftp_conn.sftp_download, 'PUT')

		if status != 'S':
			cfg_dict['logger'].info('File transfer failed !!! Please reprocess the File')
			subject = 'Caryn user report - ' + cfg_dict['host']
			email_log('DWagle@GWLabs.com', 'DWagle@fliptrx.com', 'FliptIntegration@fliptrx.com',
					  subject, ['Processing of Caryn user report file ' +
								cfg_dict['logger'].handlers[0].baseFilename,
								'Caryn Eligibility Exception'],
					  cfg_dict['logger'].handlers[0].baseFilename, True)
		else:
			os.unlink(datafile_nm)
			cfg_dict['logger'].info('File transfer succeeded: ' + datafile_nm)

			subject = 'Caryn User report File Transferred Successfully - ' + cfg_dict['host']
			email_log('DWagle@GWLabs.com', 'DWagle@fliptrx.com', 'FliptIntegration@fliptrx.com',
					  subject, ['Processing of Caryn user report file ' +
								cfg_dict['logger'].handlers[0].baseFilename,
								'Caryn Eligibility Exception'],
					  cfg_dict['logger'].handlers[0].baseFilename, True)
	else:
		# os.remove(datafile_nm)
		cfg_dict['logger'].info('Caryn User Report - Draft Mode')
		cfg_dict['logger'].info(f'json file location: {datafile_nm}')

	return total_records
# end function


if __name__ == '__main__':
	import os
	import sys
	import socket
	from utils.aws_sftp import *
	from utils.helper_functions import *

	cmdline_args = process_cmdline()
	# req = concurrent(sys.argv[0], sys.argv[1:])

	sysdate = str(datetime.now())
	currentdate = datetime.now().strftime("%m%d%yT%H%M%S")

	config_dict = {'path': os.environ['CB_DATA'],
				   'mode': cmdline_args['mode'],
				   'cb_handle': cb_authenticate(),
				   'logger': setup_logging_path('ELIGIBILITY', f'caryn_user_report{currentdate}', 'USERREPORT'),
				   'outfile': f"Caryn_Flipt_User_mapping_{currentdate}.json",
				   'subject': 'Caryn User Report',
				   'currentdate': currentdate,
				   'file_type': cmdline_args['file_type'],
				   'host': socket.gethostname()
				   }

	if cmdline_args['domain'] is None:
		config_dict['domain'] = 'CARYN001'
	else:
		config_dict['domain'] = cmdline_args['domain']

	numusers = user_report_gen(config_dict)

# end main
