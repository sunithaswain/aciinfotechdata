# -*-coding: latin-1
from ast import literal_eval
from base64 import b64encode, b64decode
from copy import deepcopy
from datetime import datetime
from json import dumps, loads
from os import environ
from tempfile import NamedTemporaryFile
from uuid import uuid4

import dw_users_load_query as redshift_query
from boto3 import client
from pandas import DataFrame, concat
from psycopg2 import connect
from requests import get, post
from requests.auth import HTTPBasicAuth
from utilsB2B.Logging.logging import Logger

TRUEVAULT_API_KEY = environ['TV_API_KEY']
AWS_S3_URL = environ['S3_RDS_URL']
AWS_ACCESS_KEY_ID = environ['S3_RDS_PUB_KEY_ID']
AWS_SECRET_ACCESS_KEY = environ['S3_RDS_PRIV_KEY_ID']

REGION_NAME = environ['S3_REGION']
BUCKET_NAME = environ['S3_RDS_BUCKET']
s3 = client('s3', aws_access_key_id=AWS_ACCESS_KEY_ID, aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
            region_name=REGION_NAME)


class User_Class(object):

    def __init__(self, username=None, password=None, attributes=None, group_ids=None, status=None):
        self.username = username
        self.password = password
        self.attributes = attributes
        self.group_ids = group_ids
        self.status = status
        self.dependent_claimed = []
        self.PER_PAGE = 500
        self.logger = Logger()
        self.__job_id = f"dw_users_load_tv_redshift-{datetime.now().date().isoformat()}",
        self.__job_name = 'dw_users_load'
        self.__current_year = str(datetime.now().year)
        self.__connection = connect(
            f"dbname={environ['RDS_DBNAME']} user={environ['RDS_USERID']} password={environ['RDS_PWD']} "
            f"host={environ['RDS_SERVER']} port={environ['RDS_PORT']}")
        self.__cursor = self.__connection.cursor()
        self.__logger_constant = {}

    def get_logger_constants(self):
        return {
            'event_type': "ENTRY",
            'start_time': datetime.now(),
            'job_id': self.__job_id,
            'transaction_id': uuid4().hex,
            'job_name': self.__job_name
        }

    def get_exit_log(self, log):
        log['event_type'] = 'EXIT'
        log['end_time'] = datetime.now()
        log['resp_time'] = (log['end_time'] - log['start_time']).microseconds
        return log

    def search_user(self, search_option):
        search_user_logger = self.get_logger_constants()
        search_user_logger['source'] = 'search_user'
        search_user_logger['destination'] = 'truevault'
        search_user_logger['backend_url'] = 'https://api.truevault.com/v1/users/search'
        self.logger.log(search_user_logger)

        search_option = b64encode(str.encode(dumps(search_option)))
        data = {'search_option': search_option}

        search_user_request = post('https://api.truevault.com/v1/users/search',
                                   auth=HTTPBasicAuth(TRUEVAULT_API_KEY, ''), data=data)
        response = search_user_request.json()
        search_user_logger['event_type'] = 'INFO'
        search_user_logger['http_method'] = 'POST'
        search_user_logger['http_status_code'] = search_user_request.status_code
        search_user_logger['http_status_msg'] = search_user_request.reason
        self.logger.log(search_user_logger)

        if 'data' not in response:
            return None, None

        if len(response['data']['documents']) == 0 and r.status_code == 200:
            return None, None

        search_user_logger = self.get_exit_log(search_user_logger)
        self.logger.log(search_user_logger)

        return response['data']['documents']

    def _get_datetime_from_epoch(self, epoch_time):
        get_datetime_from_epoch_logger = self.get_logger_constants()
        get_datetime_from_epoch_logger['event_type'] = 'INFO'
        get_datetime_from_epoch_logger['source'] = '_get_datetime_from_epoch'
        try:
            
            time_miliseconds = int(epoch_time) / 1000.0
            claimed_time = datetime.fromtimestamp(time_miliseconds)
            if claimed_time.date() == datetime(1970, 1, 1).date():
                claimed_time = datetime.fromtimestamp(int(epoch_time))
            self.logger.log(get_datetime_from_epoch_logger)
            return "-".join([str(claimed_time.year), str(claimed_time.month), str(claimed_time.day)])
        except Exception as ex:
            self.logger.log(get_datetime_from_epoch_logger)
            return ""

    def _get_personal_phone(self, personal_phones):
        get_personal_phone_logger = self.get_logger_constants()
        get_personal_phone_logger['event_type'] = 'INFO'
        get_personal_phone_logger['source'] = '_get_personal_phone'
        try:
            personal_phone = list(filter(lambda phone: phone['preferred'], personal_phones))
        except Exception as ex:
            personal_phone = list(filter(lambda phone: phone['preferred'], literal_eval(personal_phones)))

        if personal_phone:
            self.logger.log(get_personal_phone_logger)
            return personal_phone[0]['phone_number']
        else:
            try:
                verified_personal_phone = list(filter(lambda phone: phone['verified'], personal_phones))
            except Exception as ex:
                verified_personal_phone = list(filter(lambda phone: phone['verified'], literal_eval(personal_phones)))
            if verified_personal_phone:
                self.logger.log(get_personal_phone_logger)
                return verified_personal_phone[0]['phone_number']

        self.logger.log(get_personal_phone_logger)
        return ""

    def _convert_to_datetime(self, date_string):
        if 'T' in date_string:
            try:
                return datetime.strptime(date_string, "%Y-%m-%dT%H:%M:%S")
            except ValueError as _:
                return datetime.strptime(date_string, "%Y-%m-%dT%H:%M:%S.%f")
        elif len(date_string.split(' ')) == 1:
            return datetime.strptime(date_string, "%Y-%m-%d")
        try:
            return datetime.strptime(date_string, "%Y-%m-%d %H:%M:%S")
        except ValueError as _:
            return datetime.strptime(date_string, "%Y-%m-%d %H:%M:%S.%f")

    def _set_eligibility(self, eligibility):
        return {
            'coverage_termination_date': eligibility.get('coverage_termination_date', ''),
            'coverage_effective_date': eligibility.get('coverage_effective_date', ''),
            'benefit_plan_name': eligibility.get('benefit_plan_name', ''),
            'plan_year': eligibility.get('plan_year', ''),
            'coverage_tier_name': eligibility.get('coverage_tier_name', ''),
            'cobra_effective_date': eligibility.get('cobra_effective_date', ''),
            'cobra_termination_date': eligibility.get('cobra_termination_date', '')
        }

    def _get_eligibility(self, user, eligibility, primary):
        eligibility_logger = self.get_logger_constants()
        eligibility_logger['event_type'] = 'INFO'
        eligibility_logger['source'] = '_get_eligibility'
        self.logger.log(eligibility_logger)

        if primary:
            primary_eligibility_logger = self.get_logger_constants()
            primary_eligibility_logger['event_type'] = 'INFO'
            primary_eligibility_logger['message'] = 'Setting elgibility for dependent user'
            primary_eligibility_logger['source'] = '_get_eligibility'
            self.logger.log(primary_eligibility_logger)

            dependent_eligibility = eligibility
            if not eligibility.get('benefit_plan_name'):
                dependent_eligibility_logger = self.get_logger_constants()
                dependent_eligibility_logger['event_type'] = 'INFO'
                dependent_eligibility_logger[
                    'message'] = 'dependent does not have benefit plan name. Trying to match his/her plan name using ' \
                                 'primarys account'
                dependent_eligibility_logger['source'] = '_get_eligibility'
                self.logger.log(dependent_eligibility_logger)
                dependent_primary_eligibility = list(filter(
                    lambda primary_eligibility:
                    self._convert_to_datetime(eligibility['coverage_effective_date']) >= self._convert_to_datetime(
                        primary_eligibility['coverage_effective_date']) and self._convert_to_datetime(
                        eligibility['coverage_effective_date']) <= self._convert_to_datetime(
                        primary_eligibility['coverage_termination_date']), primary['eligibility']))

                if dependent_primary_eligibility:
                    dependent_eligibility = dependent_primary_eligibility[0]
                    dependent_eligibility['coverage_effective_date'] = eligibility['coverage_effective_date']
                    dependent_eligibility['coverage_termination_date'] = eligibility['coverage_termination_date']
                    dependent_eligibility['cobra_effective_date'] = eligibility['cobra_effective_date']
                    dependent_eligibility['cobra_termination_date'] = eligibility['cobra_termination_date']
                    dependent_eligibility['plan_year'] = eligibility['plan_year']

            user.update({
                **self._set_eligibility(dependent_eligibility)
            })
            return user

        user.update({**self._set_eligibility(eligibility)})
        return user

    def _set_flipt_member_id(self, user, primary):
        set_flipt_member_id_logger = self.get_logger_constants()
        set_flipt_member_id_logger['event_type'] = 'INFO'
        set_flipt_member_id_logger['source'] = '_set_flipt_member_id'
        set_flipt_member_id_logger[
            'message'] = 'Setting flipt member id based on the users flipt_person_id and person_code'

        if primary:
            return primary['flipt_person_id'] + user['person_code']
        self.logger.log(set_flipt_member_id_logger)
        return user['flipt_person_id'] + user['person_code']

    def _set_user_attributes(self, user, primary=None):
        set_user_attributes_logs = self.get_logger_constants()
        set_user_attributes_logs['message'] = 'Setting users attributes'
        self.logger.log(set_user_attributes_logs)
        user_by_eligibility = []

        group = user.get('group')
        group = ""
        if user.get('group'):
            group = user.get('group')
        elif  primary and primary.get('group'):
            group = primary.get('group')
            
        domain = user.get('domain_name', '')
       
        user_attributes = {
            'relationship': user.get('relationship').capitalize() if user.get('relationship', False) else 'Self',
            'user_type': user.get('type', ''),
            'flipt_person_id': user.get('flipt_person_id', ''),
            'flipt_member_id': self._set_flipt_member_id(user, primary),
            'employee_id': user.get('employee_id', ''),
            'person_code': user.get('person_code', ''),
            'group': group,
            'parent_id': user.get('parent_id', ''),
            'terms_compliance_accepted_date': user.get('terms_compliance_accepted_date', ''),
            'terms_hipaa_accepted_date': user.get('terms_hipaa_accepted_date', ''),
            'domain_name': domain if domain else primary.get('domain_name'),
            'create_date': user.get('created_at', ''),
            'update_date': user.get('updated_at', ''),
            'tpa_member_id': user.get('tpa_member_id', ''),
            'uid': user.get('UID', ''),
            'employment_status': user.get('employment_status', '').capitalize(),
            'claimed': self._get_datetime_from_epoch(user.get('claimed')),
            'personal_phones': self._get_personal_phone(user.get('personal_phones', []))
        }

        eligibility_logger = self.get_logger_constants()
        eligibility_logger['message'] = 'Breaking down user by eligibility'
        self.logger.log(eligibility_logger)
        for eligibility in user.get('eligibility', []):
            user = deepcopy(user_attributes)

            getting_eligbility_log = self.get_logger_constants()
            getting_eligbility_log['source'] = '_set_user_attributes'
            getting_eligbility_log['destination'] = '_get_eligibility'
            self.logger.log(getting_eligbility_log)
            user_eligibility = self._get_eligibility(user, eligibility, primary)

            getting_eligbility_log = self.get_exit_log(getting_eligbility_log)
            self.logger.log(getting_eligbility_log)

            user_by_eligibility.append(user_eligibility)

        set_user_attributes_logs = self.get_exit_log(set_user_attributes_logs)
        self.logger.log(set_user_attributes_logs)
        return user_by_eligibility

    def get_all_users_with_id(self):
        get_all_users_logger = self.get_logger_constants()
        get_all_users_logger.update({
            'source': 'generate_csv_file method',
            'destination': 'truevault',
            'operation': 'Fetching all active users from truevault'
        })
        self.logger.log(get_all_users_logger)

        fetching_users_logger = self.get_logger_constants()
        fetching_users_logger.update({
            'event_type': 'INFO',
            'source': 'get_all_users_with_id',
            'destination': 'truevault',
            'operation': 'Making call to truevault',
            'http_method': 'GET',
            'backend_url': 'https://api.truevault.com/v1/users'
        })
        self.logger.log(fetching_users_logger)

        get_users_request = get('https://api.truevault.com/v1/users', auth=HTTPBasicAuth(TRUEVAULT_API_KEY, ''))

        fetching_users_logger = self.get_exit_log(fetching_users_logger)
        fetching_users_logger['http_status_code'] = get_users_request.status_code
        fetching_users_logger['http_status_msg'] = get_users_request.reason
        self.logger.log(fetching_users_logger)

        response = get_users_request.json()
        get_all_users_logger['event_type'] = self.get_exit_log(get_all_users_logger)

        return list(map(lambda user: user['username'], response['users']))

    def fetch_user_info_email(self, values):
        fetch_user_info_logger = self.get_logger_constants()
        fetch_user_info_logger['source'] = 'fetch_user_info'
        fetch_user_info_logger['destination'] = 'search_user'
        self.logger.log(fetch_user_info_logger)

        truevault_user_fetch = self.search_user({
            'filter': {
                '$tv.username': {
                    'type': 'in',
                    'value': values
                },
                '$tv.status': {
                    'type': 'eq',
                    'value': 'ACTIVATED'
                }
            },
            'filter_type': 'and',
            'full_document': True,
            'per_page': self.PER_PAGE
        })

        fetch_user_info_logger = self.get_exit_log(fetch_user_info_logger)
        self.logger.log(fetch_user_info_logger)
        return truevault_user_fetch

    def _get_upsert_rows(self, df):
        current_year = df.loc[df['plan_year'] == self.__current_year]

        upsert_rows_logger = self.get_logger_constants()
        upsert_rows_logger['source'] = '_get_upsert_rows'
        self.logger.log(upsert_rows_logger)

        query = redshift_query.get_flipt_person_id_phone({
            'plan_year': self.__current_year,
            'table_name': 'flipt_dw.dw_users'
        })

        redshift_query_logger = self.get_logger_constants()
        redshift_query_logger['event_type'] = 'INFO'
        redshift_query_logger['destination'] = 'Redshift'
        redshift_query_logger['source'] = '_get_upsert_rows'
        redshift_query_logger['message'] = f"Calling Redshift with {query}"
        self.logger.log(redshift_query_logger)

        upsert_rows = []

        self.__cursor.execute(query)
        redshift_query_logger = ''

        new_users = []

        results = self.__cursor.fetchall()
        self.__cursor.close()

        redshift_query_logger = self.get_logger_constants()
        redshift_query_logger['event_type'] = 'INFO'
        redshift_query_logger['operation'] = 'Fetching redshift results'
        self.logger.log(redshift_query_logger)

        flipt_member_ids = []

        redshift_query_results_logger = self.get_logger_constants()
        redshift_query_results_logger['source'] = '_get_upsert_rows'
        redshift_query_results_logger[
            'message'] = 'Iterating over redshift records and verifying if information has changed'
        self.logger.log(redshift_query_results_logger)

        flipt_memeber_ids = current_year['flipt_member_id'].tolist()

        for result in results:
            mapped_result = {
                'flipt_member_id': result[0],
                'personal_phone': result[1],
                'employee_id': result[2],
                'cobra_effective_date': result[3],
                'cobra_termination_date': result[4],
                'plan_name': result[5],
                'coverage_effective_date': result[6],
                'relationship': result[7],
                'flipt_person_id': result[8],
                'plan_year': result[9],
                'coverage_tier_name': result[10],
                'coverage_termination_date': result[11]
            }
            flipt_member_ids.append(result[0])
            row = current_year.loc[(current_year['flipt_member_id'] == mapped_result['flipt_member_id']) & (
                        current_year['employee_id'] == mapped_result['employee_id']) & (
                                               current_year['relationship'] == mapped_result['relationship']) & (
                                               current_year['flipt_person_id'] == mapped_result['flipt_person_id'])]
            if not row.empty:
                personal_phones = row['personal_phones'].tolist()[0]
                cobra_effective_date = row['cobra_effective_date'].tolist()[0]
                cobra_termination_date = row['cobra_termination_date'].tolist()[0]
                plan_names = row['benefit_plan_name'].tolist()[0]
                coverage_effective_dates = row['coverage_effective_date'].tolist()[0]
                coverage_termination_date = row['coverage_termination_date'].tolist()[0]
                plan_year = row['plan_year'].tolist()[0]
                coverage_tier_name = row['coverage_tier_name'].tolist()[0]

                if cobra_termination_date != mapped_result['cobra_termination_date'] or cobra_effective_date != \
                        mapped_result['cobra_effective_date'] or personal_phones != mapped_result[
                    'personal_phone'] or cobra_effective_date != mapped_result['cobra_effective_date'] or plan_names \
                        != \
                        mapped_result['plan_name'] or coverage_effective_dates != mapped_result[
                    'coverage_effective_date'] or coverage_termination_date != mapped_result[
                    'coverage_termination_date'] or plan_year != mapped_result['plan_year'] or coverage_tier_name != \
                        mapped_result['coverage_tier_name']:
                    result_logger = self.get_logger_constants()
                    result_logger['event_type'] = 'INFO'
                    result_logger['source'] = '_get_upsert_row'
                    self.logger.log(result_logger)

                    updated_record = deepcopy(row)
                    updated_record.personal_phones = row.iloc[0].personal_phones
                    updated_record.cobra_effective_date = row.iloc[0].cobra_effective_date
                    updated_record.cobra_termination_date = row.iloc[0].cobra_termination_date
                    updated_record.coverage_effective_date = row.iloc[0].coverage_effective_date
                    updated_record.coverage_termination_date = row.iloc[0].coverage_termination_date
                    updated_record.benefit_plan_name = row.iloc[0].benefit_plan_name
                    updated_record.coverage_tier_name = row.iloc[0].coverage_tier_name
                    updated_record.plan_year = row.iloc[0].plan_year

                    upsert_rows.append({
                        'flipt_member_id': result[0],
                        'employee_id': result[2],
                        'record': updated_record
                    })

        redshift_query_logger = self.get_exit_log(redshift_query_logger)
        self.logger.log(redshift_query_logger)

        new_user_logger = self.get_logger_constants()
        new_user_logger['source'] = '_get_upsert_row'
        new_user_logger['message'] = 'Finding the difference betweeen redshift and TrueVault data'
        self.logger.log(new_user_logger)

        new_users_flipt_ids = list(set(current_year['flipt_member_id'].tolist()).difference(set(flipt_member_ids)))

        for user_id in new_users_flipt_ids:
            new_users.append(current_year.loc[current_year['flipt_member_id'] == user_id])

        new_user_logger = self.get_exit_log(new_user_logger)
        self.logger.log(new_user_logger)

        return {
            'rows_to_upsert': upsert_rows,
            'new_users': new_users
        }

    def _get_update_clause(self, upsert_rows):
        update_clause_logger = self.get_logger_constants()
        update_clause_logger['source'] = '_get_update_clause'
        update_clause_logger['message'] = 'Generating update query clause'
        self.logger.log(update_clause_logger)

        employee_id_in_clause = 'employee_id IN ('
        flipt_memeber_id_clause = 'flipt_member_id IN ('

        for row in upsert_rows['rows_to_upsert']:
            employee_id_in_clause += f"'{row['employee_id']}', "
            flipt_memeber_id_clause += f"'{row['flipt_member_id']}', "

        employee_id_in_clause = employee_id_in_clause[:-2] + ")"
        flipt_memeber_id_clause = flipt_memeber_id_clause[:-2] + ")"

        update_clause_logger = self.get_exit_log(update_clause_logger)
        self.logger.log(update_clause_logger)

        return employee_id_in_clause + " AND " + flipt_memeber_id_clause + f" AND plan_year='" \
                                                                           f"{self.__current_year}'"

    def _get_truevault_user(self, user_emails):
        get_truevault_user_logger = self.get_logger_constants()
        get_truevault_user_logger.update({
            'message': 'splitting emails into chunks of 500'
        })
        self.logger.log(get_truevault_user_logger)

        decoded_users = []
        for index in range(0, len(user_emails), self.PER_PAGE):
            get_truevault_user_logger['event_type'] = 'INFO'
            get_truevault_user_logger['operation'] = 'fetch_user_info_email'
            get_truevault_user_logger['destination'] = 'truevault'
            get_truevault_user_logger['source'] = '_get_truevault_user'
            self.logger.log(get_truevault_user_logger)

            users = self.fetch_user_info_email(user_emails[index:index + self.PER_PAGE])

            for user in users:
                decoded_users.append(loads(b64decode(user['attributes'].encode('utf-8')).decode('utf-8')))

        get_truevault_user_logger = self.get_exit_log(get_truevault_user_logger)
        self.logger.log(get_truevault_user_logger)
        return decoded_users

    def fetch_claimed_date_dependend(self, dependents):
        for dependent in dependents:
            if dependent.get("claimed") and dependent.get('flipt_person_id'):
                self.dependent_claimed.append({
                    'flipt_person_id': dependent['flipt_person_id'],
                    'claimed': self._get_datetime_from_epoch(dependent['claimed'])
                })

        return self.dependent_claimed

    def generate_csv_file(self):
        generate_csv_logging = self.get_logger_constants()
        generate_csv_logging.update({
            'source': 'generate_csv_file method',
            'destination': 'generate_csv_file',
            'operation': 'Inside generate_csv_file method'
        })
        self.logger.log(generate_csv_logging)

        get_all_users_logger = self.get_logger_constants()
        get_all_users_logger.update({
            'source': 'generate_csv_file method',
            'destination': 'get_all_users_with_id',
            'operation': 'Fetching all active users'
        })
        self.logger.log(get_all_users_logger)
        users_ids = self.get_all_users_with_id()
        get_all_users_logger = self.get_exit_log(get_all_users_logger)

        df = DataFrame()

        dependents = []
        fetching_truevault_users_logger = self.get_logger_constants()
        fetching_truevault_users_logger.update({
            'source': 'generate_csv_file method',
            'destination': '_get_truevault_user',
            'operation': 'Fetching active users from truevault by using usersnames'
        })

        self.logger.log(fetching_truevault_users_logger)
        users = self._get_truevault_user(users_ids)
        fetching_truevault_users_logger = self.get_exit_log(fetching_truevault_users_logger)
        self.logger.log(fetching_truevault_users_logger)

        data_transforming_log = self.get_logger_constants()
        data_transforming_log['source'] = 'generate_csv_file'
        data_transforming_log['message'] = 'Iterating over users and preparing data for redshift insertion'
        for user_document in users:
            if user_document.get('person_code', '') == '01':
                setting_primary_user_log = self.get_logger_constants()
                setting_primary_user_log['source'] = 'generate_csv_file'
                setting_primary_user_log['destination'] = '_set_user_attributes'
                self.logger.log(setting_primary_user_log)

                primary_user = self._set_user_attributes(user_document)

                setting_primary_user_log = self.get_exit_log(setting_primary_user_log)
                self.logger.log(setting_primary_user_log)

                primary_user_frame = DataFrame(primary_user)
                df = df.append(primary_user_frame, ignore_index=True)

                dependent_logger = self.get_logger_constants()
                dependent_logger['source'] = 'generate_csv_file'
                dependent_logger[
                    'message'] = 'Iterating over dependents and setting their attributes for redshift insert'
                self.logger.log(dependent_logger)

                for dependent in user_document.get('dependents', []):
                    dependent_logger_attribute = self.get_logger_constants()
                    dependent_logger_attribute['source'] = 'generate_csv_file'
                    dependent_logger_attribute['destination'] = '_set_user_attributes'
                    self.logger.log(dependent_logger_attribute)
                    dependent_user_frame = self._set_user_attributes(dependent, user_document)

                    dependent_logger_attribute = self.get_exit_log(dependent_logger_attribute)
                    self.logger.log(dependent_logger_attribute)

                    df = df.append(dependent_user_frame, ignore_index=True)
            else:
                dependents.append(user_document)

        data_transforming_log = self.get_exit_log(data_transforming_log)
        self.logger.log(data_transforming_log)

        dependend_claimed_logger = self.get_logger_constants()

        dependend_claimed_logger['source'] = 'generate_csv_file'
        dependend_claimed_logger['destination'] = 'fetch_claimed_data_dependend'
        self.logger.log(dependend_claimed_logger)

        dependend_claimed = self.fetch_claimed_date_dependend(dependents)

        dependend_claimed_logger = self.get_exit_log(dependend_claimed_logger)
        self.logger.log(dependend_claimed_logger)

        for dependent in dependend_claimed:
            df.loc[df['flipt_person_id'] == dependent['flipt_person_id'], 'claimed'] = dependent['claimed']

        df = df[['relationship', 'user_type', 'flipt_person_id', 'flipt_member_id', 'personal_phones',
                 'employee_id', 'claimed', 'coverage_termination_date', 'coverage_effective_date', 'benefit_plan_name',
                 'plan_year', 'coverage_tier_name', 'domain_name', 'employment_status',
                 'cobra_effective_date', 'cobra_termination_date', 'person_code', 'group', 'parent_id',
                 'terms_hipaa_accepted_date', 'terms_compliance_accepted_date', 'create_date', 'update_date',
                 'tpa_member_id', 'uid']]

        upsert_rows_logger = self.get_logger_constants()
        upsert_rows_logger['source'] = 'generate_csv_file'
        upsert_rows_logger['destination'] = '_get_upsert_rows'
        self.logger.log(upsert_rows_logger)

        rows_to_upsert = self._get_upsert_rows(df)

        with self.__connection.cursor() as cursor:
            query = redshift_query.number_of_users({
                'workspace': 'flipt_dw',
            })

            cursor.execute(query)
            number_of_users = cursor.fetchone()

            if number_of_users[0] == 0:
                new_users = NamedTemporaryFile(mode='ab')
                df.to_csv(new_users.name, header=False, index=False)
                file_name = uuid4().hex
                upload_to_s3 = s3.upload_file(new_users.name, BUCKET_NAME, file_name, )

                with self.__connection.cursor() as cursor:
                    query = redshift_query.load_dw_users({
                        'workspace': 'flipt_dw',
                        's3_path': f'{AWS_S3_URL}/{file_name}',
                        'aws_access_key_id': AWS_ACCESS_KEY_ID,
                        'aws_secret_access_key': AWS_SECRET_ACCESS_KEY,
                    })
                    cursor.execute(query)
                    self.__connection.commit()
                    new_users.flush()
                    s3.delete_object(Bucket=BUCKET_NAME, Key=file_name)
                    return

        upsert_rows_logger = self.get_exit_log(upsert_rows_logger)
        self.logger.log(upsert_rows_logger)

        update_clause_logger = self.get_logger_constants()
        update_clause_logger['source'] = 'generate_csv_file'
        update_clause_logger['destination'] = '_get_update_clause'
        self.logger.log(update_clause_logger)

        upsert_clause = self._get_update_clause(rows_to_upsert)

        update_clause_logger = self.get_exit_log(update_clause_logger)
        self.logger.log(update_clause_logger)

        frames = []

        uploading_to_s3_logger = self.get_logger_constants()
        uploading_to_s3_logger['source'] = 'generate_csv_file'
        uploading_to_s3_logger['destination'] = 'S3'
        uploading_to_s3_logger['message'] = 'Preparing CSV files to be loaded to S3'
        self.logger.log(uploading_to_s3_logger)

        for row in rows_to_upsert['rows_to_upsert']:
            frames.append(row['record'])

        frames.extend(rows_to_upsert['new_users'])
        if not frames:
            return
        result = concat(frames)
        with NamedTemporaryFile(mode='w') as temp_file:
            result.to_csv(temp_file.name, header=False, index=False)
            file_name = uuid4().hex
            upload_to_s3 = s3.upload_file(temp_file.name, BUCKET_NAME, file_name, )

            query = redshift_query.upsert_dw_users({
                's3_path': f'{AWS_S3_URL}/{file_name}',
                'aws_access_key_id': AWS_ACCESS_KEY_ID,
                'aws_secret_access_key': AWS_SECRET_ACCESS_KEY,
                'join_clause': upsert_clause,
                'workspace': 'flipt_dw'
            })

            uploading_to_s3_logger = self.get_exit_log(uploading_to_s3_logger)
            self.logger.log(uploading_to_s3_logger)
            with self.__connection.cursor() as cursor:
                cursor.execute(query)
                self.__connection.commit()

            temp_file.flush()
            s3.delete_object(Bucket=BUCKET_NAME, Key=file_name)


obj = User_Class()
obj.generate_csv_file()
# result = obj.fetch_users_info()
# import pdb;pdb.set_trace()
# print('Flipt Registered Users with ID End: ',datetime.strptime(str(datetime.now()),"%Y-%m-%dependent
# %H:%M:%S.%f").isoformat())
# req.close()
exit()
