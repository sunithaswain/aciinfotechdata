########################################
# !/usr/bin/env python  
# title         :pullprocessedclaimsrstoftp_dwusers_v.py
# description   : pull the table processedclaims from redshift and put to ftp location
# author        : Harikrishna C
# date created  : 20190831
# date last modified    : 
# version       : 0.1
# maintainer    : 
# email         : hchivukula@fliptrx.com
# status        : Development
# Python Version: 3.5.X
# usage         : python pullprocessedclaimsrstoftpv2.py -d GWLABS001 -t dummy -f dummy -m dummy
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#                          
# #######################################


import pandas as pd
import json
from sqlalchemy import create_engine

import getopt
import dateutil.parser
from datetime import datetime
import sendgrid
import os
from sendgrid.helpers.mail import *
import sys

now = datetime.now()

import paramiko
from sclaimintegration.scriptclaimsftp_oracle import multiplefilesftptransfer
from sclaimintegration.scriptclaimsftp_oracle import sftptransfer


#rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
#sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']



import psycopg2
import numpy as np

#logging.basicConfig(level=logging.INFO)
#LOG = logging.getLogger('pull the table processedclaims from redshift and put to ftp location')

from sclaimintegration.scriptclaimsftp import *  
    
dbname = os.environ['RDS_DBNAME']
host = os.environ['RDS_SERVER']
prt = os.environ['RDS_PORT']
usr = os.environ['RDS_USERID']
passwd = os.environ['RDS_PWD']
#conn = psycopg2.connect("dbname={} host={} port={} user={} password={}".format(dbname, host, prt, usr, passwd))
#cur = conn.cursor()

path = os.environ['CB_DATA']
remotepath = '/I_upload'
localpath = path
	
import sendgrid
from sendgrid.helpers.mail import *
from utils import commandline
domain,file_type,file_name,mode = commandline.main(sys.argv[1:])


def send_email():
    sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))
    from_email = Email("noreply@fliptrx.com")
    to_email = Email("fliptintegration@fliptrx.com")
    subject = "ERROR:processedclaims from REDSHIFT to ftp load failed"
    content = Content("text/plain", "ERROR:processedclaims from REDSHIFT to ftp load failed")
    mail = Mail(from_email, subject, to_email, content)
    response = sg.client.mail.send.post(request_body=mail.get())
    print(response.status_code)
    print(response.body)
    print(response.headers)


def rs2df():
      
    constr = "postgresql://"+usr+":"+passwd+"@"+host+":"+prt+"/"+dbname
    engine = create_engine(constr)
    data_frame = pd.read_sql_query('select * from flipt_dw.dw_users_invoicesummary;', engine)
    print(data_frame.head(4))
    return data_frame



def main():
    
    df = rs2df()
    fnm = (path+"/Plan_Subscription_Invoice_"+domain+"_"+now.strftime("%d%m%Y")+".csv")
    flnm = fnm.split("/")[-1]
    print(flnm)
    df.to_csv(fnm)
    print("df created successfully")
   # if domain == 'CARYN001':
   #    df.to_json(path+"processedclaims.json", orient='records')
        #df.to_csv("/home/fliptrxadmin/processedclaims1.csv")
   # if domain == 'FLIPTRX':
   #     df.to_csv(path+"processedclaims1109.csv")
  #  if domain == 'GWLABS001':
	#print("i am at gwlabs001", domain)
   #     df.to_csv(path+"processedclaims.csv", sep = '|')

##code to put to ftp start
    #try: 
    files=[]
    #fnm = (path+"/Plan_Subscription_Invoice_"+domain+"_"+now.strftime("%Y-%m-%d")+".csv")
    destination = (remotepath+'/'+flnm)
    #files,transferstatus = multiplefilesftptransfer(fnm,destination, 'PUT')
    #localpath1 = path+"processedclaims.json"
    
    status = sftptransfer(fnm, destination, 'PUT')
    print("transferstatus", status)
    
##code to put to ftp end
    ''' 
    except: 
       executionstatus='Failure'
       send_email()
    '''


if __name__ == '__main__':
    sys.exit(main())