#!/usr/bin/env python
########################################
# title         : copy_couchbase_document.py
# description   : Creates a copy of the formulary document with new docid for each entry from original formulary table
# author        : Rajesh A.
# date created  : 20191125
# date last modified :
# version       : 0.1
# maintainer    :
# email         : racharya@fliptrx.com
# status        : Dev
# Python Version: 3.6.8
# usage         : python copy_couchbase_document.py -m DRAFT -s <source_document_type> -t <target_document_type>
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#
# #######################################

import os
import sys
import pandas as pd
from numpy import nan
from utils.helper_functions import *
import couchbase.subdocument as SD
from couchbase.n1ql import N1QLQuery
from datetime import datetime
from couchbase import FMT_JSON

cb = cb_authenticate()

def prompt_user(prompt):
    get_user_resp = input(prompt)
    if len(get_user_resp) == 0:
        get_user_resp = 'Y'

    while get_user_resp.upper() not in ('Y', 'N'):
        print("Invalid response!! reply with [Yy|Nn]")
        get_user_resp = input(prompt)
        if len(get_user_resp) == 0:
            get_user_resp = 'Y'

    return get_user_resp
# end function


def check_doc_exists(cb_handle, doc_name, loghndl=None):
    query = N1QLQuery("select count(*) as count from `" + os.environ['CB_INSTANCE'] +
            "` where type='" + doc_name + "' ")
    query.timeout = 30
    try:
        ret_data = cb_handle.n1ql_query(query).get_single_result()
        if ret_data['count'] != 0:
            if loghndl is not None:
                loghndl.info(f"\nDocument < {doc_name} > exists!!")

            print(f"\nDocument < {doc_name} > exists!!\n")
            return True
    except:
        if loghndl is not None:
            loghndl.info(f"Document < {doc_name} > not present.")

        print(f"Document < {doc_name} > not present.\n")
        return False
# end function


def delete_existing_document(cb_handle, doc_name, mode='final', loghndl=None):

    if mode.upper() == 'FINAL':
        if loghndl is not None:
            loghndl.debug(f"Deleting entries from < {doc_name} >")
        print(f"Deleting entries from < {doc_name} >")
        query = N1QLQuery("delete from `" + os.environ['CB_INSTANCE'] +
                         "` where type='" + doc_name + "' ")
        ret_data = cb_handle.n1ql_query(query).execute()

        if loghndl is not None:
            loghndl.debug(f"Done deleting")
        print("Done deleting\n")
    else:
        if loghndl is not None:
            loghndl.debug(f"\nRunning in draft.  Not truncating < {doc_name} >!!")
        print(f"\nRunning in draft.  Not truncating < {doc_name} >!!\n")
# end function


def read_couchbase_source(cb_handle, doc_name, loghndl=None):
    from datetime import datetime

    # read the source document into the pandas frame
    query_str = f"SELECT META().id as id,* FROM `{os.environ['CB_INSTANCE']}` " + \
                f"WHERE type='{cmdline_rec['source']}' "
    query = N1QLQuery(query_str)
    query.timeout = 7200
    souce_details = pd.DataFrame()

    start_time = datetime.now()
    source_rows = []
    if loghndl is not None:
        loghndl.info(f"Reading data from < {doc_name} > ...")

    print(f"\nReading rows from < {doc_name} > ...", end='', flush=True)
    for row in cb_handle.n1ql_query(query):
        datarow = {'id': row['id'],
                   'datarow': row[os.environ['CB_INSTANCE']]}
        source_rows.append(datarow)
    souce_details = souce_details.append(source_rows, ignore_index=True)
    finish = datetime.now() - start_time
    print("Done\n")

    if loghndl is not None:
        loghndl.info("Done reading rows.")

    print(f"Elapsed time: {finish}s\n")
    return souce_details
# end function


def retrieve_index_details(cb_handle):
    query = N1QLQuery("select condition, index_key, keyspace_id, name from system:indexes")
    query.timeout = 120
    index_table = pd.DataFrame()
    index_rows = []

    for row in cb_handle.n1ql_query(query):
        try:
            data_row = {'condition': row['condition'],
                        'index_key': row['index_key'],
                        'name': row['name'],
                        'keyspace': row['keyspace_id'],
                        'tab_name': row['name'].replace('Index_type_', '')}
            index_rows.append(data_row)
        except:
            pass
            continue
    # end loop

    index_table = index_table.append(index_rows, ignore_index=True)
    return index_table
# end function


def find_index_row(s_value, index_lookup):
    key_row = None
    for k, row in index_lookup.iterrows():
        if row['tab_name'] == s_value:
            key_row = row
            break
    # end loop
    return key_row
# end function


def create_index(cb_handle, s_doc_name, t_doc_name, indexes_lookup,
                 loghndl=None, overwrite='N'):
    s_index_row = find_index_row(s_doc_name, indexes_lookup)
    if s_index_row is None:
        if loghndl is not None:
            loghndl.warning("Unable to find any index details.")
        print("Unable to find index details for creation")
        return False

    t_index_row = find_index_row(t_doc_name, indexes_lookup)
    if t_index_row is not None:
        if loghndl is not None:
            loghndl.warning(f"Index already present for document: {t_doc_name}")

        user_resp = None
        if overwrite.upper() == 'N':
            user_resp = prompt_user(f"Index already present on document < {t_doc_name} >.  Recreate it (Y/N) [default: Y]: ")
        else:
            user_resp = 'Y'

        if user_resp.upper() == 'Y':
            drop_query = N1QLQuery(f"drop index `{t_index_row['keyspace']}`.`{t_index_row['name']}` " +
                                   "using GSI")
            try:
                if loghndl is not None:
                    loghndl.debug(f"QUERY: {drop_query.statement}")
                cb_handle.n1ql_query(drop_query).execute()
            except:
                if loghndl is not None:
                    loghndl.error(f"Unable to drop existing index on document < {t_doc_name} >")

                print(f"Unable to drop existing index on document < {t_doc_name} >")
                return False

    # create new index
    try:
        index_cols = ','.join(t_index_row['index_key'])
        createidx_query = N1QLQuery(f"create index `{t_index_row['name']}` " +
                                f"on `{t_index_row['keyspace']}`({index_cols})" +
                                "using GSI")
        try:
            if loghndl is not None:
                loghndl.debug(f"QUERY: {createidx_query.statement}")
            cb_handle.n1ql_query(createidx_query).execute()
        except:
            if loghndl is not None:
                loghndl.error(f"Unable to re-create the index on document < {t_doc_name} >")

            print(f"Unable to re-create the index on document < {t_doc_name} >")
            return False
    except:
        return False

    return True
# end function


def write_to_backup(cb_handle, doc_name, records_list, mode='final',
                    loghndl=None, recordall='Y'):
    from datetime import datetime

    count_written = {
        'count': 0,
        'failed': []
    }
    print(f"\nwriting in operation state: {mode}")
    if loghndl is not None:
        loghndl.info(f"\nwriting in operation state: {mode}")

    start_time = datetime.now()
    if mode.upper() == 'FINAL':
        for k, recs in records_list.iterrows():
            datarow = recs['datarow']

            if loghndl is not None:
                loghndl.debug(f"Before: type={datarow['type']}")

            datarow['type'] = doc_name

            try:
                cb_handle.upsert(str(cb_handle.counter('docid', delta=1).value),
                                 datarow, format=FMT_JSON)
                count_written['count'] += 1
            except:
                count_written['failed'].append(datarow)
                pass

            if loghndl is not None:
                if recordall.upper() == 'Y':
                    loghndl.debug(f"Row added: {datarow}")
                loghndl.debug(f"After: type={datarow['type']}")
                loghndl.debug("-" * 50)
        # end loop
    else:  # -- draft mode
        for k, recs in records_list.iterrows():
            datarow = recs['datarow']
            #replace the details for the type attribute

            if loghndl is not None:
                loghndl.debug(f"Before: type={datarow['type']}")

            datarow['type'] = doc_name
            count_written['count'] += 1

            if loghndl is not None:
                loghndl.debug(f"After: type={datarow['type']}")
                loghndl.debug("-"*50)
        # end loop
    end_time = datetime.now() - start_time

    if loghndl is not None:
        loghndl.info(f"Elapsed time for copying: {end_time}s")
    print(f"Elapsed time for copying: {end_time}s")

    return count_written
# end function



# -------------------  START MAIN --------------------------------------------------
cmdline_rec = process_cmdline(additional=[['-s', '--source', "source couchbase document", True],
                                          ['-e', '--target', 'target couchbase document', True],
                                          ['-r', '--recordall', 'log all rows written', False],
                                          ['-i', '--index', "create index for new document", False],
                                          ['-o', '--overwrite',
                                           "Don't prompt if target document exists before overwriting", False]])

log_timestamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")
logger = setup_logging_path("COPY_DOCUMENT", f"copy_document_{log_timestamp}", "COPY_DOCUMENT")
src_status = check_doc_exists(cb, cmdline_rec['source'], loghndl=logger)
if src_status == False:
   print("\n" + f"ERROR: < {cmdline_rec['source']} > document does not exist on source CB" + "\n\n")
   logger.error(f"ERROR: < {cmdline_rec['source']} > document does not exist on source CB")
   sys.exit(-1)

trg_status = check_doc_exists(cb, cmdline_rec['target'], loghndl=logger)

if cmdline_rec['recordall'] is None:
    cmdline_rec['recordall'] = 'Y'

if cmdline_rec['overwrite'] is None:
    cmdline_rec['overwrite'] = 'N'

index_table = retrieve_index_details(cb)

if trg_status is True:
    if cmdline_rec['overwrite'].upper() == 'N':
        # if target document type exists, prompt if it should be deleted/truncated
        get_resp = prompt_user(f"Clear/Delete it (Y/N) [default: Y]?: ")
    else:
        get_resp = 'Y'

    if get_resp.upper() == 'Y':
        delete_existing_document(cb, cmdline_rec['target'], mode=cmdline_rec['mode'])
    else:
        print(f"WARNING: You will encounter duplicate records in < {cmdline_rec['target']} > after the copy operation!!\n\n")
# end for target exists

source_document = read_couchbase_source(cb, cmdline_rec['source'], loghndl=logger)
print(f"Records count from source document <{cmdline_rec['source']}>: {source_document.shape[0]} row(s)")

if logger is not None:
    logger.info(f"Records count from source document <{cmdline_rec['source']}>: {source_document.shape[0]} row(s)")

count_saved = write_to_backup(cb, cmdline_rec['target'], source_document, mode=cmdline_rec['mode'],
                loghndl=logger, recordall=cmdline_rec['recordall'])

if count_saved['count'] != source_document.shape[0]:
    print("ERROR: Copy process failed!! Mismatch in total records vs. records written")
    print(f"\t{source_document.shape[0]} <> {count_saved['count']}\n\n")
    print("Manually clear the records from target document and retry!!")
    if logger is not None:
        logger.error("ERROR: Copy process failed!! Mismatch in total records vs. records written")
        logger.error(f"\t{source_document.shape[0]} <> {count_saved['count']}")
        logger.error(f"Failed records: {count_saved['failed']}")
        sys.exit(-1)
else:
    print(f"Copy process completed successfully.  Total records copied to target: {count_saved['count']}")
# end

if cmdline_rec['index'] is None:
    print(f"Request couchbase admin to setup index on {cmdline_rec['target']} for required columns")
    if logger is not None:
        logger.info(f"Request couchbase admin to setup index on {cmdline_rec['target']} for required columns")
    sys.exit(-1)
else:
    status = create_index(cb, cmdline_rec['source'], cmdline_rec['target'], index_table,
                          loghndl=logger, overwrite=cmdline_rec['overwrite'])
    if status is False:
        if logger is not None:
            logger.error("Unable to create index.  Please request couchbase admin to setup index")

        print(f"Request couchbase admin to setup index on {cmdline_rec['target']} document.")
        sys.exit(0)

