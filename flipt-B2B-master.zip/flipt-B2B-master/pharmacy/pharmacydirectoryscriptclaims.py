﻿########################################
# !/usr/bin/env python
# title         : pharmacydirectoryscriptclaims.py
# description   : pharmacy directory update
# author        : Disha
# date created  : 20180101
# date last modified    : 20190118 10:59
# version       : 0.1
# maintainer    : Pal
# email         : pmuthanai@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage1         : python pharmacydirectoryscriptclaims.py -d GWLABS001 -t cp_pharmacy -f Flipt_PharmacyNetwork01142019.csv -m DRAFT
# usage2         : nohub python pharmacydirectoryscriptclaims.py -d GWLABS001 -t cp_pharmacy -f Flipt_PharmacyNetwork01142019.csv -m FINAL > FliptPharmacyNetwork10242018.log 2> FliptPharmacyNetwork10242018.err < /dev/null &
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  0.1                          20190118    Header Added
# #######################################

from utils.sendgridemail import email_log
from couchbase.n1ql import N1QLQuery, N1QLRequest
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Cluster
from couchbase import FMT_JSON
import requests
import pandas as pd
import geocoder
from difflib import SequenceMatcher
from datetime import datetime
import time
import sys
import re
import os
import argparse

if __name__ == '__main__':
    import os
    import sys
    rootdir = os.path.dirname(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))))
    sys.path.append(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))))


path = os.environ['CB_DATA']


class CPPharmacyUpdate(object):

    def __init__(self, location):
        self.cluster = Cluster(location)
        self.auth = PasswordAuthenticator(
            os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
        self.cluster.authenticate(self.auth)
        self.cb = self.cluster.open_bucket(os.environ['CB_INSTANCE'])
        self.bucket_name = os.environ['CB_INSTANCE']
        self.claimprocessor = ''
        self.session = requests.Session()

    def replace_all(self, txt):
        chdict = {"-": "", "'s": "s", ".": "", 'WAL MART': 'WALMART',
                  'HY VEE': 'HYVEE', 'WINNDIXIE': 'WINN DIXIE', }
        for k, v in chdict.items():
            txt = txt.replace(k, v)
        return txt

    def replace_wl(self, txt):

        if txt == 'Giant Eagle':
            return txt

        chdict = {"'s": 's', '-': '', 'Giant': 'Giant Pharmacy', 'Martins': 'Martins Pharmacy', '&': 'and',
                  'H.E. Butt (HEB)': 'Heb Grocery', 'WinnDixie': 'Winn Dixie'}
        for k, v in chdict.items():
            txt = txt.replace(k, v)
        return txt

    def replace_appname(self, whitelist, pharmacyfullname):

        wln = None

        for j, wlr in whitelist.iterrows():
            wln = None
            wln = pharmacyfullname
            if wlr['replaced_name'].strip().upper() in wln.upper():
                wln = wlr['replaced_name']
            elif wlr['name'].strip().upper() in wln.upper():
                wln = wlr['name']

        end_chars = ['PHARMACY', '\(', '\#', '\d', '\$', ' J', 'AND DRUG%%', ' DRUG%%', 'DRUGSTORE%%', 'DRUG STORE%%',
                     'DRUGS%%']
        max_ind = 10000
        wln = wln + '%%'
        for c in end_chars:
            char_index = re.search(c, wln)
            if char_index:
                max_ind = min(max_ind, char_index.start())
                if max_ind not in [-1, 0]:
                    wln = wln[:max_ind].replace('WAL-MART', 'WALMART')
        return wln.replace('%%', '')

    def geocodeAddress(self, pharma_dir):

        cols_dict = {'pharmacynpi': 'npi', 'pharmacyaddress1': 'prov_practice_addr_1',
                     'pharmacyaddress2': 'prov_practice_addr_2', 'pharmacycity': 'prov_practice_city',
                     'pharmacystate': 'prov_practice_state', 'pharmacyzip1': 'prov_practice_zip'}
        pharma_dir['prov_practice_country'] = 'US'
        pharma_dir.rename(columns=cols_dict, inplace=True)
        header_list = ['npi', 'prov_practice_addr_1', 'prov_practice_addr_2', 'prov_practice_city', 'prov_practice_zip',
                       'prov_practice_state', 'prov_practice_country']
        pharma_dir.fillna('', inplace=True)
        address = pd.DataFrame(columns=header_list)
        for i, p in pharma_dir.iterrows():
            if (p['geo_lat'] == '') or (pd.isnull(p['geo_lat'])):
                line_dict = {}
                line_dict['npi'] = str(p['npi']).strip()
                line_dict['prov_practice_addr_1'] = str(
                    p['prov_practice_addr_1']).strip()
                line_dict['prov_practice_addr_2'] = str(
                    p['prov_practice_addr_2']).strip()
                line_dict['prov_practice_city'] = p['prov_practice_city'].strip()
                zip_code = str(p['prov_practice_zip'])[:5].zfill(5)
                if len(zip_code) > 5:
                    zip_code += '-' + zip_code[5:]
                line_dict['prov_practice_zip'] = zip_code
                line_dict['prov_practice_state'] = p['prov_practice_state'].strip()
                line_dict['prov_practice_country'] = 'United States'
                address = address.append(line_dict, ignore_index=True)
        geocodes = self.getGeoCodes(address)
        geocodes.to_csv(path + '//' + filetype +
                        '//log//nongeocodedpharmacies' + str(filename) + '.csv', index=False)

        return geocodes

    def parse_google_fields(self, g, google_fields):
        res = {}
        for f in google_fields.keys():
            gf_type = google_fields[f]['field_type']
            gf_name = google_fields[f]['field_name']

            if gf_type == 'property':
                d = g.json
            elif gf_type == 'raw':
                d = g.raw

            if d is not None and gf_name in d.keys():
                res[f] = d[gf_name]
            else:
                res[f] = ''
        return res

    def split_address(self, addr):
        street_number = ''
        street_name = addr

        flds = addr.split(' ')
        for i, f in enumerate(flds):
            if f.isdigit():
                street_number = f
                street_name = ' '.join(flds[i + 1:])
                break
        return [street_number, street_name]

    def check_addresses(self, i_addr, o_addr,
                        fields=['street_number', 'street', 'city', 'state', 'postal_code', 'country']):
        for f in fields:
            if type(o_addr[f]) == dict and ('short_name' in o_addr[f].keys() or 'long_name' in o_addr[f].keys()):
                if not i_addr[f].upper().replace('.', '') == o_addr[f]['short_name'].upper().replace('.', '') and not \
                        i_addr[f].upper().replace('.', '') == o_addr[f]['long_name'].upper().replace('.', ''):
                    return False
            elif type(o_addr[f]) == str and not i_addr[f].upper() == o_addr[f].upper():
                return False

        return True

    def geocode_data_frame(self, df, new_fields, google_fields, key=None, max_tries=2, geocode_missing=True):
        g_res = {}
        new_cols = [x for x in new_fields]
        new_cols.append('npi')
        geo_df = pd.DataFrame(columns=new_cols)
        geo_errors = pd.DataFrame(columns=new_cols)

        for f in new_fields:
            g_res[f] = []

        for i, p in df.iterrows():
            geo_ok = False
            address = p['prov_practice_addr_1'].strip()
            i_city = p['prov_practice_city'].strip()
            i_state = p['prov_practice_state'].strip()
            i_postal = str(p['prov_practice_zip'])
            i_country = p['prov_practice_country'].strip()

            geocoded = {}
            for f in new_fields:
                geocoded[f] = ''

            addr = address
            addr += ',' + i_city
            addr += ',' + i_state
            addr += ',' + i_postal
            # addr += ',' + i_country

            i_addr = {}
            i_addr['address'] = addr
            i_addr['formatted_address'] = addr
            i_addr['street_number'], i_addr['street'] = self.split_address(
                address)
            i_addr['city'] = i_city
            i_addr['state'] = i_state
            i_addr['postal_code'] = i_postal[:5]
            if len(i_postal) > 5:
                i_addr['postal_code_suffix'] = i_postal[5:]
            else:
                i_addr['postal_code_suffix'] = ''
            i_addr['country'] = i_country
            i_addr['npi'] = p['npi']

            if geocode_missing:

                # use geocoder to get data
                g = geocoder.google(
                    addr, key=key, session=self.session, rate_limit=False)

                if not g.ok:
                    print(g.json['status'])

                    ntries = 0
                    while ntries < max_tries:
                        ntries += 1
                        g = geocoder.google(addr, key=key)
                        # time.sleep(2)
                        if g.ok:
                            geo_ok = True
                            break

                if g.ok:
                    geocoded = self.parse_google_fields(g, google_fields)

                    geocoded['is_same_address'] = 'Y' if self.check_addresses(
                        i_addr, geocoded) else 'N'

                    # save results to json file, in json_path if variable set
                    for f in geocoded.keys():
                        if type(geocoded[f]) == dict and 'short_name' in geocoded[f].keys():
                            i_addr['geo_' + f] = geocoded[f]['short_name']
                        else:
                            i_addr['geo_' + f] = geocoded[f]

                        geo_df = geo_df.append(i_addr, ignore_index=True)
                        if p['npi'] in list(geo_errors['npi']):
                            geo_errors = geo_errors[geo_errors['npi']
                                                    != p['npi']]
                    geo_ok = True

            if geo_ok:
                # add fields to structure
                for f in new_fields:
                    l = g_res[f]
                    if type(geocoded[f]) == dict and 'short_name' in geocoded[f].keys():
                        l.append(geocoded[f]['short_name'])
                    else:
                        l.append(geocoded[f])
                    g_res[f] = l

            else:
                # save results to json file, in json_path if variable set
                for f in new_fields:
                    i_addr['geo_' + f] = ''

                geo_errors = geo_errors.append(i_addr, ignore_index=True)

                # add fields to structure
                for f in new_fields:
                    l = g_res[f]
                    l.append('')
                    g_res[f] = l

        for f in new_fields:
            df['geo_' + f] = g_res[f]

        return df

    def getGeoCodes(self, address):
        API_KEY = 'AIzaSyB_zk3jM6lIpradGijn551UIzzrjv1iwEg'

        google_fields = {'address': {'field_type': 'property', 'field_name': 'address'},
                         'formatted_address': {'field_type': 'raw', 'field_name': 'formatted_address'},
                         'street_number': {'field_type': 'raw', 'field_name': 'street_number'},
                         'street': {'field_type': 'raw', 'field_name': 'route'},
                         'city': {'field_type': 'raw', 'field_name': 'locality'},
                         'state': {'field_type': 'raw', 'field_name': 'administrative_area_level_1'},
                         'county': {'field_type': 'raw', 'field_name': 'administrative_area_level_2'},
                         'postal_code': {'field_type': 'raw', 'field_name': 'postal_code'},
                         'postal_code_suffix': {'field_type': 'raw', 'field_name': 'postal_code_suffix'},
                         'country': {'field_type': 'raw', 'field_name': 'country'},
                         'lat': {'field_type': 'property', 'field_name': 'lat'},
                         'lng': {'field_type': 'property', 'field_name': 'lng'},
                         'confidence': {'field_type': 'property', 'field_name': 'confidence'},
                         'status': {'field_type': 'property', 'field_name': 'status'}}

        new_fields = ['formatted_address', 'street_number', 'street', 'city', 'state', 'county', 'postal_code',
                      'postal_code_suffix', 'country', 'lat', 'lng', 'confidence', 'status', 'is_same_address']
        geocodes = self.geocode_data_frame(
            address, new_fields, google_fields, key=API_KEY, geocode_missing=True)
        return geocodes

    def readnewupdate(self):

        global filename
        pharmacysource = ['cerpass']

        for ps in pharmacysource:
            if ps == 'scriptclaim':
                from sclaimintegration.scriptclaimsftp import multiplefilesftptransfer_noarchive
                from sclaimintegration.scriptclaimsftp import multiplefilesftptransfer
                remotepath = '/monthlyUpdates/'
                localpath = path + '/' + domain + '/' + filetype + '/'
                filelist, transferstatus = multiplefilesftptransfer(
                    remotepath, localpath, 'GET')

                col_names = ['PharmacyID', 'PharmacyNPI', 'ChainCode', 'CorpName', 'PharmacyName', 'PharmacyStoreNumber', 'PharmacyAddress1', 'PharmacyAddress2', 'PharmacyCity', 'PharmacyState', 'PharmacyZip1', 'PharmacyPhone', 'PharmacyFax', 'PharmPrice', 'PharmBrandPriceAmt',
                             'PharmBrandPriceFee', 'PharmMACPriceAmt', 'PharmMACPriceFee', 'PharmNonMACPriceAmt', 'PharmNonMACPriceFee', 'PharmBrandPriceAmtMO', 'PharmBrandPriceFeeMO', 'PharmMACPriceAmtMO', 'PharmMACPriceFeeMO', 'PharmNonMACPriceAmtMO', 'PharmNonMACPriceFeeMO']
                df = pd.read_csv(path + '//' + filetype + '//' + filename, sep='|',
                                 index_col=False, names=col_names, encoding='ISO-8859-1', skiprows=1)
                self.claimprocessor = 'scriptclaim'
            elif ps == 'cerpass':
                from pricing.cerpasssftp import sftptransfer, getfilelist
                remotepath = '/l_upload'
                localpath = path + '/' + filetype + '/'
                filelist = getfilelist(remotepath)
                for i in filelist:
                    if 'pharmacy' in i.lower():
                        filename = i
                if not filelist or not filename:
                    print('Pharmacy File not found')
                    sys.exit()
                localpath = localpath + filename
                remotepath = remotepath + '/' + filename
                transferstatus = sftptransfer(remotepath, localpath, 'GET')
            if transferstatus != 'S':
                sys.exit()
            filesize = os.path.getsize(localpath)
            print(localpath)

            if filesize > 0:
                print("Cerpass Pharmacy Pricing File size is greater than 0 ")

                df = pd.read_csv(localpath, sep='\t', dtype=str)
                self.claimprocessor = 'cerpass'
                column_rename = {'nabp': 'PharmacyID', 'npi': 'PharmacyNPI', 'chain': 'ChainCode', 'chain_name': 'CorpName', 'name': 'PharmacyName', 'STORENUMBER': 'PharmacyStoreNumber', 'address1': 'PharmacyAddress1', 'address2': 'PharmacyAddress2', 'city': 'PharmacyCity', 'state': 'PharmacyState', 'zip': 'PharmacyZip1', 'phone': 'PharmacyPhone', 'fax': 'PharmacyFax', 'PHARM_PRICE': 'PharmPrice',
                                 'PharmBrandPriceAmt': 'PharmBrandPriceAmt', 'PharmBrandPriceFee': 'PharmBrandPriceFee', 'PharmMACPriceAmt': 'PharmMACPriceAmt', 'PharmMACPriceFee': 'PharmMACPriceFee', 'PharmNonMACPriceAmt': 'PharmNonMACPriceAmt', 'PharmNonMACPriceFee': 'PharmNonMACPriceFee', 'PharmBrandPriceAmtMO': 'PharmBrandPriceAmtMO', 'PharmBrandPriceFeeMO': 'PharmBrandPriceFeeMO', 'PharmMACPriceAmtMO': 'PharmMACPriceAmtMO', 'PharmMACPriceFeeMO': 'PharmMACPriceFeeMO', 'PharmNonMACPriceAmtMO': 'PharmNonMACPriceAmtMO', 'PharmNonMACPriceFeeMO': 'PharmNonMACPriceFeeMO'}
                df.rename(columns=column_rename, inplace=True)

            else:

                print(" Pharmacy Pricing File size is 0 ")
                sys.exit()

        return df

    def formatupdate(self):
        fn = self.readnewupdate()

        fn.fillna("", inplace=True)
        colsdict = {}
        for c in list(fn):
            colsdict[c] = c.replace(' ', '_').replace(',', '').lower()
        fn.rename(columns=colsdict, inplace=True)

        add_columns = {'pharmacyname-new': '', 'corpname-new': '', 'wl_name': '', 'geo_lat': '', 'geo_lng': '', 'created_at': '', 'updated_at': '', 'updated_by': '',
                       'npi_status': 'active', 'type': 'cp_pharmacy_stg', 'pharmacytype': 'RETAIL'}
        add_nested_columns = {'claim_processor': self.claimprocessor, 'maclistid': 'nan',
                              'cp_status': 'active', 'sc_pharmbrandpriceamt': '100', 'sc_pharmbrandpriceamtmo': '100', 'pharmacyid': '', 'pharmbrandpriceamt': '100', 'pharmbrandpriceamtmo': '100',
                              'pharmbrandpricefee': '0', 'pharmbrandpricefeemo': '0', 'pharmmacpriceamt': '100', 'pharmmacpriceamtmo': '100', 'pharmmacpricefee': '0', 'pharmmacpricefeemo': '0', 'pharmnonmacpriceamt': '100', 'pharmnonmacpriceamtmo': '100',
                              'pharmnonmacpricefee': '0', 'pharmnonmacpricefeemo': '0', 'sc_pharmbrandpriceamt': '100', 'sc_pharmbrandpriceamtmo': '100', 'chaincode': '', 'pharmacynpi': '', 'compound_discount_pct': '65'}
        nested = pd.DataFrame(
            data=[add_nested_columns for i in range(0, len(fn))])

        for key, value in add_columns.items():
            fn[key] = value

        for key, value in add_nested_columns.items():
            nested[key] = value
            if key in list(fn):
                nested[key] = fn[key]
                if key != 'pharmacynpi':
                    fn.drop(key, axis=1, inplace=True)
                nested.loc[nested[key] == '', key] = value

        pharmacycount = 0
        try:
            pharmacycount = len(fn)
        except:
            pass

        return fn, nested, pharmacycount

    def finalupdate(self):

        filtered, nested, num = self.formatupdate()

        errors = pd.DataFrame()
        maclist = None
        if self.claimprocessor == 'scriptclaim':
            maclist = pd.read_excel(
                path + '/cp_pharmacy/MacListChainCodeKey.xlsx')
            maclist['ChainCode'] = maclist['ChainCode'].apply(lambda x: str(x))
        elif self.claimprocessor == 'cerpass':
            maclist = pd.DataFrame()
            maclist['ChainCode'] = '1'
            maclist['maclistid'] = '1'
        if num == 0:
            print('No pharmacies found in file to process')
            sys.exit()

        whitelist = pd.DataFrame()
        rows = self.cb.n1ql_query(
            N1QLQuery('SELECT * FROM `' + os.environ['CB_INSTANCE'] + '` WHERE type=$t', t='whitelisted_pharmacy'))
        for r in rows:
            xele = r[os.environ['CB_INSTANCE']].pop(
                'type', 'whitelisted_pharmacy')
            whitelist = whitelist.append(
                r[os.environ['CB_INSTANCE']], ignore_index=True)
        whitelist['replaced_name'] = [self.replace_wl(
            str(x)).upper() for x in whitelist['name']]

        for i, r in filtered.iterrows():

            try:

                filtered.loc[i, 'pharmacyname-new'] = self.replace_all(
                    str(r['pharmacyname']).upper())
                filtered.loc[i,
                             'corpname-new'] = self.replace_all(str(r['corpname']).upper())

                if len(str(int(r['pharmacyzip1']))) > 5:
                    filtered.loc[i, 'pharmacyzip1'] = str(
                        int(r['pharmacyzip1'])).zfill(9)
                else:
                    filtered.loc[i, 'pharmacyzip1'] = str(
                        int(r['pharmacyzip1'])).zfill(5)

                totalnpis = filtered[filtered['pharmacynpi']
                                     == r['pharmacynpi']]
                if len(totalnpis) > 1:
                    errors = errors.append({'pharmacynpi': key, 'pharmacyname': r['pharmacyname'],
                                            'pharmacyaddress': r['pharmacyaddress1'], 'previousaddress': '',
                                            'error': 'Duplicate NPIs'}, ignore_index=True)

                filtered.loc[i, 'pharmacynpi'] = str(
                    r['pharmacynpi']).zfill(10)
                query = N1QLQuery('SELECT * FROM `' + os.environ['CB_INSTANCE'] +
                                  '` WHERE type="cp_pharmacy" and pharmacynpi=$npi', npi=r['pharmacynpi'])
                query.adhoc = False
                query.timeout = 7200
                oldpharmacy = {}
                oldcpinfo = []
                for queryresult in self.cb.n1ql_query(query):
                    result = queryresult[os.environ['CB_INSTANCE']]
                    oldcpinfo.extend(result['cp_pharmacy_info'])
                    result.pop('cp_pharmacy_info')
                    oldpharmacy.update(result)
                # print(r)

                nestedindex = nested[nested['pharmacynpi']
                                     == r['pharmacynpi']].index[0]

                if nested.loc[nestedindex, 'maclistid'] == 'nan':
                    if str(index.loc[nestedindex, 'chaincode']) in list(maclist['ChainCode']):
                        filtered.loc[i, 'maclistid'] = str(maclist[maclist['ChainCode'] == str(
                            nested.loc[nestedindex, 'chaincode'])]['MacListID'].values[0]).strip().upper()
                nested.loc[nestedindex, 'sc_pharmbrandpriceamt'] = nested.loc[nestedindex,
                                                                              'pharmbrandpriceamt']
                nested.loc[nestedindex, 'sc_pharmbrandpriceamtmo'] = nested.loc[nestedindex,
                                                                                'pharmbrandpriceamtmo']

                if oldpharmacy:

                    filtered.loc[i,
                                 'pharmacytype'] = oldpharmacy['pharmacytype']

                    if str(r['pharmacyname']).upper().strip() == str(oldpharmacy['pharmacyname']).upper().strip():
                        filtered.loc[i, 'wl_name'] = str(
                            oldpharmacy['wl_name'])
                    else:
                        filtered.loc[i, 'wl_name'] = self.replace_appname(
                            whitelist, r['pharmacyname'].upper().strip())
                    if oldpharmacy['updated_by'] == 'System':
                        filtered.loc[i, ['geo_lat', 'geo_lng', 'created_at']] = [oldpharmacy['geo_lat'],
                                                                                 oldpharmacy['geo_lng'],
                                                                                 oldpharmacy['created_at']]
                        filtered.loc[i, 'updated_by'] = 'System'

                    else:
                        if str(r['pharmacyaddress1']).upper().strip() != str(oldpharmacy['pharmacyaddress1']).upper().strip():
                            errors = errors.append({'pharmacynpi': r['pharmacynpi'], 'pharmacyname': r['pharmacyname'], 'pharmacyaddress': r['pharmacyaddress1'],
                                                    'previousaddress': oldpharmacy['pharmacyaddress1'], 'error': 'NPI in Previous File, Address not matching'}, ignore_index=True)
                    filtered.loc[
                        i, ['pharmacyaddress1', 'pharmacycity', 'pharmacystate', 'pharmacyzip1', 'geo_lat', 'geo_lng',
                            'created_at']] = [oldpharmacy['pharmacyaddress1'],
                                              oldpharmacy['pharmacycity'],
                                              oldpharmacy['pharmacystate'],
                                              oldpharmacy['pharmacyzip1'], oldpharmacy['geo_lat'],
                                              oldpharmacy['geo_lng'], oldpharmacy['created_at']]
                    filtered.loc[i, 'updated_by'] = oldpharmacy['updated_by']
                    for cp in oldcpinfo:
                        if cp['claim_processor'] != self.claimprocessor:
                            cp.update({'pharmacynpi': r['pharmacynpi']})
                            nested = nested.append(cp, ignore_index=True)

                else:

                    filtered.loc[i, 'wl_name'] = self.replace_appname(
                        whitelist, r['pharmacyname'].upper().strip())

                    filtered.loc[i, 'created_at'] = datetime.now().isoformat()
                    errors = errors.append({'pharmacynpi': r['pharmacynpi'], 'pharmacyname': r['pharmacyname'],
                                            'pharmacyaddress': r['pharmacyaddress1'], 'previousaddress': '', 'error': 'New NPI'}, ignore_index=True)
                    print(r['pharmacynpi'])
                    geocodes = self.geocodeAddress(
                        filtered[filtered.index == i])
                    print(r['pharmacynpi'], 'geocoded')
                    filtered.loc[i, ['geo_lat', 'geo_lng', 'updated_by']] = [
                        str(geocodes.loc[0, 'geo_lat']), str(geocodes.loc[0, 'geo_lng']), 'System']
                filtered.loc[i, 'updated_at'] = datetime.now().isoformat()
                self.output(
                    dict(filtered.loc[i]), nested[nested['pharmacynpi'] == r['pharmacynpi']])
                if i % 100 == 0:
                    print(i, 'pharmacies done', datetime.now().isoformat())

            except Exception as e:
                print(e)
                print(r['pharmacynpi'])

        errors.to_csv(path + '//' + filetype + '//log//errors_' +
                      filename + '.csv', index=False)

        return

    def output(self, r, nested):

        global mode
        [r.pop(key) for key in ['corpname-new', 'pharmacyname-new']]

        #cppharma, nested, errors = ob.finalupdate()

        d = dict(r)
        for key, value in d.items():
            d[key] = str(value).strip()
        d['geo'] = {'lat': None, 'lon': None}
        try:
            d['geo']['lat'] = float(d['geo_lat'])
            d['geo']['lon'] = float(d['geo_lng'])
        except:
            pass
        d['cp_pharmacy_info'] = []
        nestedlist = nested[nested['pharmacynpi'] == r['pharmacynpi']]
        for _, s in nestedlist.iterrows():
            temp = dict(s)
            temp.pop('pharmacynpi')
            for key, value in temp.items():
                temp[key] = str(value).strip()
            d['cp_pharmacy_info'].append(temp)

        if mode.lower() == 'final':
            self.cb.upsert(
                str(self.cb.counter('docid', delta=1).value), d, format=FMT_JSON)

    def document_type_updates(self, mode):

        npi_list = []

        query = N1QLQuery("select distinct pharmacynpi from `" +
                          os.environ['CB_INSTANCE'] + "` where type='cp_pharmacy_stg'")
        query.timeout = 3000
        for result in self.cb.n1ql_query(query):
            npi_list.append(result['pharmacynpi'])
        print('distinct pharmacies received')

        query = N1QLQuery("select * from `" +
                          os.environ['CB_INSTANCE'] + "` where type='cp_pharmacy'")
        query.timeout = 3000
        for result in self.cb.n1ql_query(query):
            result = result[os.environ['CB_INSTANCE']]
            if result['pharmacynpi'] in npi_list:
                continue
            for i in range(len(result['cp_pharmacy_info'])):
                if result['cp_pharmacy_info'][i]['claim_processor'] == self.claimprocessor:
                    result['cp_pharmacy_info'][i]['cp_status'] = 'inactive'
            result['type'] = 'cp_pharmacy_stg'
            result['updated_at'] = datetime.now().isoformat()

            if mode.lower() == 'final':
                self.cb.upsert(
                    str(self.cb.counter('docid', delta=1).value), result, format=FMT_JSON)


parser = argparse.ArgumentParser(description='commandline file processing...')
parser.add_argument(
    "-d", "--domain", help="pass in domain (company)", required=False),
parser.add_argument("-t", "--filetype",
                    help="pass in doc type", required=False)
parser.add_argument("-f", "--file_name",
                    help="pass in file name", required=False)
parser.add_argument("-m", "--processing_type",
                    help="final/draft mode", required=True)
args = parser.parse_args()
domain, filetype, filename, mode = args.domain, args.filetype, args.file_name, args.processing_type


print(datetime.now())
location = os.environ['CB_URL']
ob = CPPharmacyUpdate(location)
ob.finalupdate()
ob.document_type_updates(mode)
print(datetime.now())

email_log('noreply@fliptrx.com', 'FliptIntegration@fliptrx.com', None, 'Pharmacy Directory Update - Completed',
          ['Monthly Pharmacy Directory Update', '‘Pharmacy Directory Exception’'],
          path + '//' + filetype + '//log//errors_' +
          filename + '.csv')
