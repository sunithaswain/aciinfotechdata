########################################
# !/usr/bin/env python  
# title         : updatepharmacydistance.py
# description   : 
# author        : Disha
# date created  : 20180101
# date last modified    : 20190129
# version       : 0.1
# maintainer    : Pal
# email         : pmuthanai@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage         : it dependents on other programs (searchprescription)
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  1.1            Pal         20190129    Added header
#  
#  
# #######################################

from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
import os
import pprint
import time
from datetime import datetime
import requests
from couchbase import FMT_JSON

#update distance between pharmacy and search location
cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])

def updatedistance():
	API_KEY='AIzaSyB_zk3jM6lIpradGijn551UIzzrjv1iwEg'

	query=N1QLQuery('select meta().id as id,* from `'+os.environ['CB_INSTANCE']+'` where type = "analytics" and search_location is not missing and pharmacy_distance1 is missing')
	query.adhoc = False
	query.timeout = 7200
	for r in cb.n1ql_query(query):
		rdict=dict(r[os.environ['CB_INSTANCE']])
		destinations=''
		origin=rdict['search_location']
		destinationlist={}
		for k,v in rdict.items():
			if 'pharmacy_address' in k:
				destinationlist[int(k.replace('pharmacy_address',''))]=rdict[k]
		if len(destinationlist)>0:
			for k in sorted(destinationlist):
				try:
					dest=str(destinationlist[k])
				except Exception as e:
					dest=''
				destinations=destinations+dest+'|'
			payload={'origins':origin,'destinations':destinations[:-1],'key':API_KEY,'units':'imperial'}
			response=requests.get('https://maps.googleapis.com/maps/api/distancematrix/json',params=payload)
			result=response.json()
			if result['status']=='OK':
				pnum=1
				for i in result['rows'][0]['elements']:
					if i['status']=='OK':
						distance=i['distance']['text']
					else: distance=''
					rdict['pharmacy_distance'+str(pnum)]=distance.replace(' mi','').replace(',','')
					pnum=pnum+1
			
			
			cb.upsert(r['id'],rdict,format=FMT_JSON)
				
		

