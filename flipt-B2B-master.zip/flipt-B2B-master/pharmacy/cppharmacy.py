########################################
# !/usr/bin/env python  
# title         : cppharmacy.py
# description   : Update pharmacy info into pharmacy (claim processor)
# author        : Disha
# date created  : 20180101
# date last modified    : 20190129
# version       : 0.1
# maintainer    : Pal
# email         : pmuthanai@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage         : python cppharmacy.py -t cp_pharmacy -m draft
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  1.1            Pal         20190129    Added header
#  1.2                        20190129    Added mode
#  
# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']
 
import pandas as pd
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from utils import commandline
import os
from datetime import datetime
import sys
import pprint
import couchbase.subdocument as SD
import pprint

domain_name,file_type,file_name,mode=commandline.main(sys.argv[1:])
cluster = Cluster(os.environ['CB_URL'])
bucket_name=os.environ['CB_INSTANCE']
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(bucket_name)

def load():
	pdir=pd.read_csv(path+'/'+file_type+'/'+file_name)
	pdir.fillna('',inplace=True)
	#maclist=pd.read_excel(path+'/'+file_type+'/MacListChainCodeKey.xlsx',dtype='str')
	
		
	pdir['pharmacynpi']=pdir['pharmacynpi'].apply(lambda x: str(x).zfill(10))
	#pdir['pharmacyzip1']=pdir['pharmacyzip1'].apply(lambda x: str(int(x)).zfill(9) if len(str(int(x)))>5 else str(int(x)).zfill(5))
	outer_cols=["corpname","created_at","geo_lat","geo_lng","npi_status","pharmacyaddress1","pharmacyaddress2","pharmacycity","pharmacyfax",
      "pharmacyname","pharmacynpi","pharmacyphone","pharmacystate","pharmacystorenumber","pharmacytype","pharmacyzip1","pharmprice","type","updated_at",      "updated_by","wl_name"]
	inner_cols=["chaincode","claim_processor","cp_status","maclistid","pharmacyid","pharmbrandpriceamt","pharmbrandpriceamtmo","pharmbrandpricefee",          "pharmbrandpricefeemo","pharmmacpriceamt","pharmmacpriceamtmo","pharmmacpricefee","pharmmacpricefeemo","pharmnonmacpriceamt",         "pharmnonmacpriceamtmo","pharmnonmacpricefee","pharmnonmacpricefeemo","sc_pharmbrandpriceamt","sc_pharmbrandpriceamtmo"]
	
	
	
	ite=0
	for k,g in pdir.groupby(['pharmacynpi']):
		ite=ite+1
		g.reset_index(drop=True,inplace=True)
		d=dict()
		for c in outer_cols:
			d[c.lower().replace(' ','_')]=str(g.loc[0,c]).strip()
		if d['pharmacytype']!='RETAIL': continue
		d['cp_pharmacy_info']=[]
	
		for i,r in g.iterrows():
			d_inner=dict()
			for c in inner_cols:
				d_inner[c.lower().replace(' ','_')]=str(r[c]).strip()
		try:
			if len(str(int(d['pharmacyzip1'])))>5:	d['pharmacyzip1']=str(int(d['pharmacyzip1'])).zfill(9) 
			else: d['pharmacyzip1']=str(int(d['pharmacyzip1'])).zfill(5)
		except Exception as e:
			d['pharmacyzip1']=''
			d['cp_pharmacy_info'].append(d_inner)
		d['updated_at']=datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat()
		d['updated_by']='System'		
		d['created_at']=datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat()
		d['npi_status']='active'
		d['type']='cp_pharmacy_stg'
		print(ite)
		cb.upsert(str(cb.counter('docid',delta=1).value),d)
		#pprint.pprint(d)


def partialupdate(pfile_name):
	print(path)
	print(file_type)
	input_file = path+'/'+file_type+'/'+pfile_name
	pharma=pd.read_csv(input_file,encoding='utf-8',dtype=str)
	# pharma=pd.read_csv(path+'/'+file_type+'/cppharmacy.csv')

	#maclist=pd.read_excel(path+'/'+file_type+'/MacListChainCodeKey.xlsx',dtype='str')
	ite=0
	pharma=pharma[pharma['updated_by']=='Manually']
	pharma.fillna('',inplace=True)
	print(len(pharma))
	
	pharma['PharmacyNPI']=pharma['PharmacyNPI'].apply(lambda x:str(int(x)).zfill(11))
	
	for i,r in pharma.iterrows():
		
		query=N1QLQuery('Select meta().id as id from `'+os.environ['CB_INSTANCE']+'` where type="cp_pharmacy_stg" and pharmacynpi=$npi',npi=r['PharmacyNPI'])
		for res in cb.n1ql_query(query):
			#print(res['id'],r['PharmacyNPI'])
			#exit()
			cb.mutate_in(str(res['id']),SD.upsert('pharmacyaddress1',str(r['PharmacyAddress1']).strip().upper()))
			cb.mutate_in(str(res['id']),SD.upsert('pharmacyaddress2',str(r['PharmacyAddress2']).strip().upper()))
			cb.mutate_in(str(res['id']),SD.upsert('pharmacycity',str(r['PharmacyCity'])))
			cb.mutate_in(str(res['id']),SD.upsert('pharmacystate',str(r['PharmacyState'])))
			cb.mutate_in(str(res['id']),SD.upsert('pharmacyzip1',str(r['PharmacyZip1'])))
			cb.mutate_in(str(res['id']),SD.upsert('geo_lat',str(r['geo_lat'])))
			cb.mutate_in(str(res['id']),SD.upsert('geo_lng',str(r['geo_lng'])))
			cb.mutate_in(str(res['id']),SD.upsert('updated_by',str(r['updated_by'])))
		#maclistname='nan'
		'''
		maclistname='nan'
		#for i,r in df.iterrows():
		if r['chaincode'] in list(maclist['ChainCode']): 
			maclistname=str(maclist[maclist['ChainCode']==r['chaincode']]['MacListID'].values[0]).strip().upper()
		
		for i in r['cp_pharmacy_info']:
			i['sc_pharmbrandpriceamt']=str(i['pharmbrandpriceamt'])
			i['sc_pharmbrandpriceamtmo']=str(i['pharmbrandpriceamtmo'])
			try: i['pharmbrandpriceamt']=str(float(i['pharmbrandpriceamt'])-5.0)
			except ValueError: _=1
			try: i['pharmbrandpriceamtmo']=str(float(i['pharmbrandpriceamtmo'])-5.0)
			except ValueError: _=1
		
		cb.mutate_in(str(r['id']),SD.upsert('maclistid',str(maclistname)))
		cb.mutate_in(str(r['id']),SD.upsert('cp_pharmacy_info',r['cp_pharmacy_info']))
		'''
		ite=ite+1   
		# li=[]
		# li.extend(r['cp_pharmacy_info'])
		# added={}
		# for key,value in li[0].items():
		# 	added[key]=value
		# added['claim_processor']='demo'
		# li.append(added)
		# #print(li)
		# cb.mutate_in(str(r['id']),SD.upsert('cp_pharmacy_info',li))

	print(input_file)		
	print(path+'/'+file_type+'/archive/'+pfile_name)

	if mode.strip().upper() == 'FINAL':
		if not os.path.isdir(path+'/'+file_type+'/archive/'): os.makedirs(path+'/'+file_type+'/archive/')
		os.rename(input_file, path+'/'+file_type+'/archive/'+pfile_name)

if file_name:
	print('basic calling function invoked')
	partialupdate(file_name)
else:
	print('Automate calling function invoked')
	# Automate Drug Database Load
	from utils.autofile_transfer import multiplefilesftptransfer
	localpath = path+'/'+file_type+'/'
	remotepath = 'uploads'
	multiplefilesftptransfer(remotepath, localpath, 'cppharmacy*', mode)

	for file_name in os.listdir(localpath):
		print(file_name)
		print(os.path.isfile(os.path.join(localpath,file_name)))
		if file_name.startswith("cppharmacy") and os.path.isfile(os.path.join(localpath,file_name)):
			print("file is %s"%file_name)
			partialupdate(file_name)
