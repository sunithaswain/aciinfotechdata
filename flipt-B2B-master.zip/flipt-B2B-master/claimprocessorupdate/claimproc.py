########################################

# !/usr/bin/env python 

# title : claimproc.py
# description : Claim Processor details update (PCN, BIN, etc)
# author : Disha
# date created : -python claimproc.py -d GWLABS001 -t claim_processor -f claim_processor04302018.csv -m DRAFT
# last  modified : 20190107
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  python claimproc.py -d GWLABS001 -t claim_processor -f claim_processor04232018.csv -m DRAFT
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------
# 1.1 added log write in draft mode on 20190107

# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']

import socket
import os
import sys
from datetime import datetime

import pandas as pd
from couchbase.n1ql import N1QLQuery
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase import FMT_JSON

from utils.sendgridemail import email_log
from utils import commandline as commandline

# from app.common.sendgridemail import email_log
# import app.common.commandline as commandline

domain,file_type,file_name,mode=commandline.main(sys.argv[1:])
cluster=Cluster(os.environ['CB_URL']+'?operation_timeout=2700')
auth=PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(auth)
bucket_name=os.environ['CB_INSTANCE']
cb=cluster.open_bucket(bucket_name)


# modified by Hari on 27/12/2018
host = socket.gethostname()
currentdate = datetime.now()
currentdate = currentdate.strftime("%m%d%y%H%M%S")
log = path+'//'+file_type+'//'+'/log/'+"claimproc"+currentdate+'.txt'


cp=pd.read_csv(path+'//'+file_type+'//'+file_name,dtype=str)
cp['zip']=cp['zip'].apply(lambda x: str(x).zfill(5))
query=N1QLQuery('SELECT META().id as id,claim_processor,load_date FROM `'+bucket_name+'` WHERE type="claim_processor"')
query.timeout=7200
meta_ids=[]
cpold=pd.DataFrame(columns=['claim_processor','load_date'])
for r in cb.n1ql_query(query):
	meta_ids.append(r['id'])
	cpold=cpold.append({'claim_processor':r['claim_processor'],'load_date':r['load_date']},ignore_index=True)
ite=-1

logfile = open(log,"w")
for i,r in cp.iterrows():
	ite=ite+1
	d={}
	d['type']='claim_processor'
	for c in list(cp):
		d[c.lower().replace(' ','_')]=str(r[c]).strip()
	d['rxbin']=d['rxbin'].zfill(6)
	if d['claim_processor'] in list(cpold['claim_processor']):
		d['load_date']=cpold[cpold['claim_processor']==d['claim_processor']]['load_date'].values[0]  
	else: d['load_date']=str(datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())
	d['update_date']=str(datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())
		
	if ite<len(meta_ids):
		# modified by Hari  on 27/12/2018
		if mode.strip().upper() == 'FINAL':
			cb.upsert(str(meta_ids[ite]),d, format=FMT_JSON)
		
	else:
		if mode.strip().upper() == 'FINAL':
			cb.upsert(str(cb.counter('docid',delta=1).value),d, format=FMT_JSON)

logfile.write('%s records are updated'%(ite+1))
# added by Hari on 27/12/2018
if mode.strip().upper() == 'DRAFT':
	logfile.write('claim process update - Draft Mode :'+host+file_name)
	subject = 'claim process update - Draft Mode :'+host
logfile.close()
email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','HRajendran@fliptrx.com',subject,['claim process File '+log,'claim process Exception'],log,True)

# modified by Hari  on 27/12/2018
if mode.strip().upper() == 'FINAL':
	if ite+1<len(meta_ids):
		for h in range(ite+1,len(meta_ids)):
			cb.remove(meta_ids[h],quiet=True)


print("process completed now")
	
	
