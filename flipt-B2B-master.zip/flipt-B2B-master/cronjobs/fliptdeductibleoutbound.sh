
#!/bin/sh

export DATE=`date +%F-%H%M`
DD=`date +%d-%b-%Y`
SCRIPT=`basename $0`
export LOGFILE=${LOGDIR}/${SCRIPT}-${DATE}.log

# add functionality to get domain passed in
domain_name=${1}

sh ${CRONDIR}/printheader.sh
${PYTHONBIN}  ${BINDIR}/aetna/fliptdeductibleoutbound.py -d ${domain_name} -t deductible -m final  >> ${LOGFILE}
sh ${CRONDIR}/printfooter.sh
