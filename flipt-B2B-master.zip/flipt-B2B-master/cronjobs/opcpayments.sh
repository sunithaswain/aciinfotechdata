
#!/bin/sh

export DATE=`date +%F-%H%M`
DD=`date +%d-%b-%Y`
SCRIPT=`basename $0`
export LOGFILE=${LOGDIR}/${SCRIPT}-${DATE}.log

sh ${CRONDIR}/printheader.sh
${PYTHONBIN}  ${BINDIR}/payrolldeduction/opcpayments.py -d GWLABS001 -t payment -f OPCpaymentsummary.xlsx -m SUMMARY  >> ${LOGFILE}
sh ${CRONDIR}/printfooter.sh
