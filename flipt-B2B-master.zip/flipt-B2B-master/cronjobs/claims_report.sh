#!/bin/sh

export DATE=`date +%F-%H%M`
DD=`date +%d-%b-%Y`
SCRIPT=`basename $0`
export LOGFILE=${LOGDIR}/${SCRIPT}-${DATE}.log

sh ${CRONDIR}/printheader.sh
# -t <tablename/all> -l <fullload/incremental>
${PYTHONBIN}  ${BINDIR}/datawarehouse/dataload/claims_report.py -d $2 -r $4
sh ${CRONDIR}/printfooter.sh
