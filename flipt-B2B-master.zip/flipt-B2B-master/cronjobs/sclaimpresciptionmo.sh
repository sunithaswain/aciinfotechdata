
#!/bin/sh

export DATE=`date +%F-%H%M`
DD=`date +%d-%b-%Y`
SCRIPT=`basename $0`
export LOGFILE=${LOGDIR}/${SCRIPT}-${DATE}.log

sh ${CRONDIR}/printheader.sh
${PYTHONBIN}  ${BINDIR}/sclaimintegration/sclaimpresciptionmo.py -d GWLABS001 -t scprescription -f ScriptClaimPrescription -m final  >> ${LOGFILE}
${PYTHONBIN}  ${BINDIR}/sclaimintegration/sclaimpresciptionmo.py -d FLIPT001 -t scprescription -f ScriptClaimPrescription -m final  >> ${LOGFILE}
sh ${CRONDIR}/printfooter.sh



sh ${CRONDIR}/printheader.sh
${PYTHONBIN}  ${BINDIR}/sclaimintegration/scdailyclaimrewards_autoerx.py -d GWLABS001 -t scdailyclaim -f SCS -m final  >> ${LOGFILE}
sh ${CRONDIR}/printfooter.sh
