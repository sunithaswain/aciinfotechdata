
#!/bin/sh

export DATE=`date +%F-%H%M`
DD=`date +%d-%b-%Y`
SCRIPT=`basename $0`
export LOGFILE=${LOGDIR}/${SCRIPT}-${DATE}.log

sh ${CRONDIR}/printheader.sh
${PYTHONBIN}  ${BINDIR}/users/ftpemployeeops.py -d GWLABS001 -t employee -m draft  >> ${LOGFILE}
if [ $? -ne 0 ]
then
	${PYTHONBIN}  ${BINDIR}/users/ftpemployeeops.py -d GWLABS001 -t employee -m final  >> ${LOGFILE}
fi

sh ${CRONDIR}/printfooter.sh
