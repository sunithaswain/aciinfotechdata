#!/bin/sh
############################################################
#Enhancement author: Smit Kabrawala
############################################################

filename="FLIPT_DRUG_NDC_"
file_format=".csv"
file_extension="000"

export DATE=`date +%F-%H%M`
DD=`date +%d-%b-%Y`
DATE_FORMAT=`date +%d%b%Y`
SCRIPT=`basename $0`
export LOGFILE=${LOGDIR}/${SCRIPT}-${DATE}.log

sh ${CRONDIR}/printheader.sh
echo "Unloading file from redshift to S3 bucket"
${PYTHONBIN}  ${BINDIR}/datawarehouse/dataload/unload_rs2s3_ndc_drugs.py
echo "Executing ndcdrugs.py file"
${PYTHONBIN}  ${BINDIR}/drugdb/ndcdrugs.py -d GWLABS001 -t ndc_drugs_new -f "$filename$DATE_FORMAT$file_format$file_extension" -m final  >> ${LOGFILE}
echo "Creating backup for the ndc_drugs document type"
${PYTHONBIN}  ${BINDIR}/couchbase_utils/copy_couchbase_document.py -s ndc_drugs -e ndc_drugs_bak -o Y
echo "updating original ndc_drugs with ndc_drugs_new data"
${PYTHONBIN}  ${BINDIR}/couchbase_utils/copy_couchbase_document.py -s ndc_drugs_new -e ndc_drugs -o Y
sh ${CRONDIR}/printfooter.sh