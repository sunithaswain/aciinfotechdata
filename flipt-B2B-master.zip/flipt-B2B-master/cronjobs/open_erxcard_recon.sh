

#!/bin/sh

export DATE=`date +%F-%H%M`
DD=`date +%d-%b-%Y`
SCRIPT=`basename $0`
export LOGFILE=${LOGDIR}/${SCRIPT}-${DATE}.log

sh ${CRONDIR}/printheader.sh
${PYTHONBIN}  ${BINDIR}/invoicereconcillation/open_erxcard_recon.py -d GWLABS001 -t open_erx_reconciliation -m final >> ${LOGFILE}
sh ${CRONDIR}/printfooter.sh
