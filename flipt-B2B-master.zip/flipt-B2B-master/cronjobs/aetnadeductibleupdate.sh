

#!/bin/sh

export DATE=`date +%F-%H%M`
DD=`date +%d-%b-%Y`
SCRIPT=`basename $0`
export LOGFILE=${LOGDIR}/${SCRIPT}-${DATE}.log

sh ${CRONDIR}/printheader.sh
${PYTHONBIN}  ${BINDIR}/aetna/aetnadeductibleupdate.py -d GWLABS001 -t deductible -m final -s $DD  >> ${LOGFILE}
sh ${CRONDIR}/printfooter.sh
