#!/bin/sh
. /home/fliptrxadmin/FLIPT_${INSTANCE_TYPE}.env

rm -f  /home/fliptrxadmin/Cronjobs/aetna_claim_form.log
touch /home/fliptrxadmin/Cronjobs/aetna_claim_form.log
cd /home/fliptrxadmin/bin/PYTHON

echo "--------------------------------------------------------------------">> /home/fliptrxadmin/Cronjobs/aetna_claim_form.log
echo " **** Script aetna_claim_form :Start Time  ---$(date +%d%b%Y:%T) ****"  >> /home/fliptrxadmin/Cronjobs/aetna_claim_form.log
echo " ----------------------------------------------------------------------------"$'\n\n'>> /home/fliptrxadmin/Cronjobs/aetna_claim_form.log

/home/fliptrxadmin/anaconda3/bin/python /home/fliptrxadmin/flipt-B2B/aetna/aetna_claim_form.py -d GWLABS001 -t aetna_claim_form >> /home/fliptrxadmin/Cronjobs/aetna_claim_form.log

echo "--------------------------------------------------------------------">> /home/fliptrxadmin/Cronjobs/aetna_claim_form.log
echo " **** Script aetna_claim_form : End Time   ---$(date +%d%b%Y:%T) ****"  >> /home/fliptrxadmin/Cronjobs/aetna_claim_form.log
echo " ----------------------------------------------------------------------------"$'\n\n'>> /home/fliptrxadmin/Cronjobs/aetna_claim_form.log
