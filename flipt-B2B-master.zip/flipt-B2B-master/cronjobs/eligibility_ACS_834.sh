
#!/bin/sh

export DATE=`date +%F-%H%M`
DD=`date +%d-%b-%Y`
SCRIPT=`basename $0`
export LOGFILE=${LOGDIR}/${SCRIPT}-${DATE}.log

sh ${CRONDIR}/printheader.sh
${PYTHONBIN}  ${BINDIR}/users/eligibility_834_reader.py -d ACS001 -y 2020 -m final  >> ${LOGFILE}
sh ${CRONDIR}/printfooter.sh
