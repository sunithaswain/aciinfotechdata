
#!/bin/sh

export DATE=`date +%F-%H%M`
DD=`date +%d-%b-%Y`
SCRIPT=`basename $0`
export LOGFILE=${LOGDIR}/${SCRIPT}-${DATE}.log

sh ${CRONDIR}/printheader.sh
${PYTHONBIN}  ${BINDIR}/rewards/get_unapplied_reward.py -d GWLABS001 -t prescription -m FINAL $DD  >> ${LOGFILE}
sh ${CRONDIR}/printfooter.sh