#!/bin/sh

echo "--------------------------------">> ${LOGFILE}
echo " **** Ending Time  ---${DATE} "  >> ${LOGFILE}
echo " -------------------------------\n\n" >>  ${LOGFILE}
