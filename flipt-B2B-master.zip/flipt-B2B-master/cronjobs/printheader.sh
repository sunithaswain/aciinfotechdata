#!/bin/sh

echo "------------------------------">> ${LOGFILE}
echo " **** Starting Time  ---${DATE} "  >> ${LOGFILE}
echo " -------------------------\n\n">>${LOGFILE}
