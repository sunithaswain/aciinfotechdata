#!/bin/sh

export DATE=`date +%F-%H%M`
DD=`date +%d-%b-%Y`
SCRIPT=`basename $0`
export LOGFILE=${LOGDIR}/${SCRIPT}-${DATE}.log

sh ${CRONDIR}/printheader.sh
set +x
${PYTHONBIN}  ${BINDIR}/autoerx/sms_notifications.py >> ${LOGFILE}
set -x
sh ${CRONDIR}/printfooter.sh

