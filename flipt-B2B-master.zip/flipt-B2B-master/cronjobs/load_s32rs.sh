#!/bin/sh

export DATE=`date +%F-%H%M`
DD=`date +%d-%b-%Y`
SCRIPT=`basename $0`
export LOGFILE=${LOGDIR}/${SCRIPT}-${DATE}.log

sh ${CRONDIR}/printheader.sh
# -t <tablename/all> -l <fullload/incremental/ti>
${PYTHONBIN}  ${BINDIR}/datawarehouse/dataload/load_s32rs.py -t $2 -l $4 
sh ${CRONDIR}/printfooter.sh
