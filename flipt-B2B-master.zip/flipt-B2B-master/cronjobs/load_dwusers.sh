#!/bin/sh

export DATE=`date +%F-%H%M`
DD=`date +%d-%b-%Y`
SCRIPT=`basename $0`
export LOGFILE=${LOGDIR}/${SCRIPT}-${DATE}.log

sh ${CRONDIR}/printheader.sh 
${PYTHONBIN}  ${BINDIR}/users/dw_user_fliptregisteredusers_withid.py  >> ${LOGFILE}
${PYTHONBIN}  ${BINDIR}/users/dw_user_s32rs_populate_truevault_allusers.py  >> ${LOGFILE}
sh ${CRONDIR}/printfooter.sh