#!/bin/sh

export DATE=`date +%F-%H%M`
DD=`date +%d-%b-%Y`
SCRIPT=`basename $0`
export LOGFILE="${LOGDIR}/${SCRIPT}_${DATE}.log"

sh ${CRONDIR}/printheader.sh
# -t <tablename/all>
${PYTHONBIN}  ${BINDIR}/datawarehouse/setup/runsql.py -t $2 
sh ${CRONDIR}/printfooter.sh