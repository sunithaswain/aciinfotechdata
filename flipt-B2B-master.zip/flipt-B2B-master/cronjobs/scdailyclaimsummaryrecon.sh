
#!/bin/sh

export DATE=`date +%F-%H%M`
DD=`date +%d-%b-%Y`
SCRIPT=`basename $0`
export LOGFILE=${LOGDIR}/${SCRIPT}-${DATE}.log

sh ${CRONDIR}/printheader.sh
${PYTHONBIN}  ${BINDIR}/invoicereconcillation/scdailyclaimsummaryrecon.py  -d GWLABS001 -t dailyclaim_reconciliation -m final  >> ${LOGFILE}
sh ${CRONDIR}/printfooter.sh
