#!/bin/sh

export DATE=`date +%F-%H%M`
DD=`date +%d-%b-%Y`
SCRIPT=`basename $0`
export LOGFILE=${LOGDIR}/${SCRIPT}-${DATE}.log

sh ${CRONDIR}/printheader.sh
${PYTHONBIN}  ${BINDIR}/datawarehouse/dataload/populate_monthmedspan.py -t mf2All  >> ${LOGFILE}
sh ${CRONDIR}/printfooter.sh