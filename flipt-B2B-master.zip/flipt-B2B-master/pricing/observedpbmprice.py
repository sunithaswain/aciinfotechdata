# -*- coding: utf-8 -*-
########################################
# !/usr/bin/env python  
# title         : observedpbmprice.py
# description   : update pbm price
# author        : Disha
# date created  : 20180101
# date last modified    : 20190118 14:50
# version       : 0.1
# maintainer    : Pal
# email         : pmuthanai@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage         : python observedpbmprice.py -d GWLABS001 -t pbm_observed_price -f observedprice11022018.xlsx -m draft
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  0.1							20190118	Header added
# #######################################


if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']
 
import pandas as pd
from datetime import datetime
import json
from couchbase.n1ql import N1QLQuery
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
import os,re
import time
from utils import commandline
import sys
from couchbase import FMT_JSON
from utils.sendgridemail import email_log

domain,filetype,filename,mode=commandline.main(sys.argv[1:])
cluster=Cluster(os.environ['CB_URL']+'?operation_timeout=2700')
auth=PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(auth)
bucket_name=os.environ['CB_INSTANCE']
cb=cluster.open_bucket(bucket_name)
time_now=re.sub('[\s\-\:]','',str(datetime.now()))
logpath=path+'//'+domain+'//'+filetype+'//log//'+'//Log'+time_now+'.xlsx'
writer=pd.ExcelWriter(logpath,engine='xlsxwriter')
awp=pd.read_excel(path+'//'+domain+'//'+filetype+'//'+filename,encoding='utf-8')
cols_dict={}
domainlist =[domain]
if domain == 'GWLABS001': domainlist.append('FLIPT001')
for i in list(awp):
	cols_dict[i]=i.lower().replace(' ','_')
awp.rename(columns=cols_dict,inplace=True)
awp['gpi']=awp['gpi'].apply(lambda x:str(x).zfill(14))
query1=N1QLQuery('SELECT pbm_provider,domain FROM `'+bucket_name+'` WHERE type="domain" and domain in $dn',dn=domainlist)
query1.timeout=7200
domainparams={}
for r in cb.n1ql_query(query1):
	domainparams[r['domain']]=r['pbm_provider']
def update():
	log=pd.DataFrame()
	for k,g in awp.groupby(['gpi','brand_generic']):
		g.reset_index(drop=True,inplace=True)
		if len(g)>1:
			log=log.append({'gpi':k[0],'brand_generic':k[1],'Old Unit Price':'','New Unit Price':'','Message':'Multiple Prices Found for this GPI'},ignore_index=True)
		drugnames=[]
		scbg=k[1]
		if scbg=='G': scbg='Generic'
		else: scbg='Brand'
		query=N1QLQuery('SELECT distinct b.drug_name FROM `'+bucket_name+'` b unnest b.cp_price as cp WHERE b.type="cp_drug_price" and b.gpi=$gpi and b.brandorgeneric=$bg',gpi=g.loc[0,'gpi'],bg=scbg)
		query.timeout=7200
		for dn in cb.n1ql_query(query):
			drugnames.append(dn['drug_name'])
		if len(drugnames)==0: 
			log=log.append({'gpi':g.loc[0,'gpi'],'brand_generic':k[1],'Old Unit Price':'','New Unit Price':'','Message':'No MAC Drug with this GPI'},ignore_index=True)
			continue
		docid=''
		drug_name=''
		record={}
		record['provider']=[]
		record['gpi']=str(g.loc[0,'gpi'])
		for dmn,dmnpbm in domainparams.items():
			innerrec={}
			innerrec['observed_unit_price_extended']=str("{0:.5f}".format((g.loc[0,'pbm_price_per_ext._unit'])))
			innerrec['source']=str(g.loc[0,'source'])
			innerrec['domain']=str(dmn)
			innerrec['provider_name']=str(dmnpbm)
			innerrec['active_flag']="Y"
			record['provider'].append(innerrec)
		record['type']='pbm_observed_price_stg'
		record['create_date']=datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat()
		record['update_date']=datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat()
		record['brand_generic']=k[1]
		for i in drugnames:
			record['drug_name']=str(i).upper()
			
			if mode.upper()=='FINAL': cb.upsert(str(cb.counter('docid',delta=1).value),record,format=FMT_JSON)
			'''
			for r in cb.n1ql_query(query):
				query1=N1QLQuery('SELECT distinct brand_generic FROM `'+bucket_name+'` WHERE type="drug" and gpi=$gpi and drug_name=$dn',gpi=record['gpi'],dn=i)
				query1.timeout=7200
				for dr in cb.n1ql_query(query1):
					record['brand_generic']=dr['brand_generic']
			'''
		
			
		query=N1QLQuery('SELECT distinct p.observed_unit_price_extended as unitprice FROM `'+bucket_name+'` b Unnest provider p WHERE b.type="pbm_observed_price" and b.gpi=$gpi and p.domain=$dn and b.brand_generic=$bg',gpi=g.loc[0,'gpi'],dn=domain,bg=k[1])
		query.timeout=7200
		present=False
		for res in cb.n1ql_query(query):
			present=True
			log=log.append({'gpi':g.loc[0,'gpi'],'brand_generic':k[1],'Old Unit Price':res['unitprice'],'New Unit Price':innerrec['observed_unit_price_extended'],'Message':'Price Comparison'},ignore_index=True)
		if not present:
			log=log.append({'gpi':g.loc[0,'gpi'],'brand_generic':k[1],'Old Unit Price':'','New Unit Price':'','Message':'New GPI'},ignore_index=True)
		
	log.to_excel(writer,index=False)
	writer.save()
	subject = 'Observed PBM Price File Processed'
	email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','SSubramani@GWLabs.com',subject,['Processing of Observed PBM Price File'+filename,'Observed PBM Pricing Exception'],logpath,True)
		
update()
