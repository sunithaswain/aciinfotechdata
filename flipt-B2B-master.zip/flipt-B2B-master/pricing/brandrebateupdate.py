########################################
# !/usr/bin/env python 

# title : brandrebateupdate.py
# description : Brand Rebate Integration
# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  python brandrebateupdate.py -d GWLABS001 -t brand_rebate -f Brand_Rebates_v3_1211.xlsx -m DRAFT
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']
 
import pandas as pd
from couchbase.n1ql import N1QLQuery
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
import os
from utils import commandline
import sys
from datetime import datetime
from couchbase import FMT_JSON
from utils.sendgridemail import email_log

dn,filetype,filename,mode=commandline.main(sys.argv[1:])

#email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','SSubramani@GWLabs.com','Brand Rebate Update - Initiated',['Brand Rebate Update Update'],None,False)
cluster=Cluster(os.environ['CB_URL']+'?operation_timeout=2700')
auth=PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(auth)
bucket_name=os.environ['CB_INSTANCE']
cb=cluster.open_bucket(bucket_name)

def updatebrandrebate():
	data=pd.read_excel(path+'//'+dn+'//'+filetype+'//'+filename,skiprows =[0])
	logpath=path+'//'+dn+'//'+filetype+'//log//log'+datetime.now().strftime("%Y%m%d%H%M")+'.txt'
	logfile = open(logpath,"w")
	logfile.write("=============================================================="+"\r\n")
	logfile.write("=============== Brand Rebate Log [New Drugs] ================="+"\r\n")		
	cols_dict={'GPI':'gpi','DRUG_NAME_Medispan':'drug_name','G/T':'brand_generic','Original Rebate %':'original_rebate','# of Substitutes':'num_substitutes','Rebate Buffer':'buffer','Final ratio to be multiplied by AWP':'rebate_factor'}
	newvals=[]
	newvals.extend(cols_dict.values())
	data.rename(columns=cols_dict,inplace=True)
	data=data.loc[:,newvals]
	print(list(data))
	#data.drop(['AWP - 15%','GPI NUMBER','gpi+short name','SHORT NAME','GPI SHORT'],axis=1,inplace=True)	
	data['gpi']=data['gpi'].apply(lambda x: str(x).zfill(14))
	claimprocessors=[]
	query=N1QLQuery('Select claim_processor from `'+bucket_name+'` where type="claim_processor"')
	query.timeout=90
	query.adhoc=False
	for result in cb.n1ql_query(query):
		claimprocessors.append(result['claim_processor'])
	ite=-1
	for i,r in data.iterrows():
		docid=''
		d={}
		
		query=N1QLQuery('Select meta().id id, create_date from `'+bucket_name+'` where type="brand_rebate" and drug_name=$dn and gpi=$gpi and brand_generic=$bg',dn=r['drug_name'],gpi=r['gpi'],bg=r['brand_generic'])
		query.timeout=90
		query.adhoc=False
		for result in cb.n1ql_query(query):
			docid=result['id']
			d['create_date']=result['create_date']
		
		d['type']='brand_rebate'
		d['active_status_flag']='Y'
		d['claim_processor']=[]
		d['claim_processor'].extend(claimprocessors)
		for c in list(data):
			d[c]=str(r[c]).strip()
		d['update_date']=str(datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())
		ite=ite+1
		print(ite)
		#if ite<5600: continue
		if docid!='':
			cb.upsert(str(docid),d, format=FMT_JSON)
		else:
			d['create_date']=str(datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat())
			cb.upsert(str(cb.counter('docid',delta=1).value),d, format=FMT_JSON)
			logfile.write("Drug Name  :"+r['drug_name']+"\r\n")		
			logfile.write("GPI        :"+r['gpi']+"\r\n")	
			logfile.write("--------------------------------------------------------------"+"\r\n")	
	update_query = N1QLQuery('Update `'+bucket_name+'` set active_status_flag="N" where type="brand_rebate" and DATE_FORMAT_STR(update_date,"1111-11-11")!=clock_local("1111-11-11")')	
	update_query.timeout = 1000
	cb.n1ql_query(update_query).execute()
	logfile.write("=============================================================="+"\r\n")
	logfile.close()
	email_log('DWagle@GWLabs.com','DWagle@fliptrx.com','SSubramani@fliptrx.com','Brand Rebate Update - Completed',['Brand Rebate Update Update','Brand Rebate Exception'],logpath)

		
updatebrandrebate()	