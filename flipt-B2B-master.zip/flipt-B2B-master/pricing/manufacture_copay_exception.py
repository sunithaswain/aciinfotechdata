########################################
# !/usr/bin/env python
# title         : domainupdate.py
# description   : Update domain type documents
# author        : Disha
# date created  : 20180101
# date last modified    : 20190128
# version       : 0.1
# maintainer    : Pal
# email         : pmuthanai@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage         : python domainupdate.py  -t domain -f domain11122018.csv -m DRAFT
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  1.1            Pal         20190125    Added header
#  1.2			      		  201901	  Added new field additions
# 1.3 			Deepthi		  04292019	  No Code changes.Only input file changes
# #######################################

from couchbase import FMT_JSON
from datetime import datetime
import os
from couchbase.n1ql import N1QLQuery
from utils.helper_functions import *
import pandas as pd


if __name__ == "__main__":
    cmdline_rec = process_alt_cmdline(additional=[['-d', '--domain', 'pass in the domain name (company)', True],
                                                  ['-t', '--file_type', 'pass in the couchbase document type', True],
                                                  ['-f', '--file_name', 'source file to load data from', True]])
    bucket_name = os.environ['CB_INSTANCE']

    logger = setup_logging_path('PRICING', 'manufacture_copay', 'MANUFACTURE_COPAY')
    cb = cb_authenticate()

    path = os.environ['CB_DATA']
    inputfile = f"{path}/{cmdline_rec['domain']}/{cmdline_rec['file_type']}/{cmdline_rec['file_name']}"

    manufacture_except_df = pd.read_excel(inputfile)
    manufacture_except_df['ndc'] = manufacture_except_df['ndc'].apply(lambda x: str(x).zfill(11))
    manufacture_except_df.fillna("", inplace=True)

    recs_added = 0
    recs_updated = 0

    for index,file_row in manufacture_except_df.iterrows():
        row_dict = populate_dict(manufacture_except_df, file_row)
        row_dict['plan_end_date'] = row_dict['plan_end_date'].replace('00:00:00', '23:59:59')
        row_dict['type'] = 'manufacturer_copay_exceptions'
        row_dict['update_date'] = str(datetime.strptime(
                str(datetime.now()), "%Y-%m-%d %H:%M:%S.%f").isoformat())

        query = N1QLQuery('SELECT META().id as id,* FROM `' +
                          bucket_name +'` WHERE type="manufacture_copay_exception" ' +
                          f"and ndc='{row_dict['ndc']}' ")
        query.timeout = 7200

        result = cb.n1ql_query(query).get_single_result()

        # record is not present in couchbase
        if cmdline_rec['mode'].lower() == 'final':
            if result is None:
                # add new record to the document
                row_dict['create_date'] = str(datetime.strptime(
                str(datetime.now()), "%Y-%m-%d %H:%M:%S.%f").isoformat())

                cb.upsert(str(cb.counter('docid', delta=1).value),
                          row_dict, format=FMT_JSON)
                logger.info(f"record added for: {row_dict['domain']} - NDC: {row_dict['ndc']}")
                recs_added += 1
            else:
                meta_id = result['id']
                cb.upsert(meta_id, row_dict)
                logger.info(f"Update done for: {row_dict['domain']} - NDC: {row_dict['ndc']}.")
                recs_updated += 1
        else:
            logger.info(f"mock insert/update in draft mode for: {row_dict['domain']} - NDC: {row_dict['ndc']}")
    # end loop

    logger.info("Records added: " + str(recs_added))
    logger.info("Records updated: " + str(recs_updated))

    print("Records added: " + str(recs_added))
    print("Records updated: " + str(recs_updated))

# end main
