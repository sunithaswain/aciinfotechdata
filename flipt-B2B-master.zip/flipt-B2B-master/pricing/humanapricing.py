########################################

# !/usr/bin/env python

# title : humanapricing.py
# description : Update Humana Trad & Specialty Pricing
# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Deepthi
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  python humanapricing.py -d GWLABS001 -t cp_drug_price -f FLIPT_HUMANA_TRAD_MAIL_PRICE_LIST_20181218_V3_MAC_prodfile.xlsx%%mailorder -m draft
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------
# 1.1 Hari 02012019 Added draft mode and log file to get update status

# #######################################

from utils.helper_functions import cb_authenticate, process_cmdline
from pricing.send_humana_price import send_files_from_s3
from utils.sendgridemail import email_log
import couchbase.subdocument as SD
from couchbase.n1ql import N1QLQuery
from datetime import datetime
import pandas as pd
if __name__ == '__main__':
    import os
    import sys
    rootdir = os.path.dirname(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))))
    sys.path.append(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))))


arguments = process_cmdline()
domain, file_type, file_name, mode = arguments['domain'], arguments[
    'file_type'], arguments['file_name'], arguments['mode']
bucket_name = os.environ['CB_INSTANCE']
cb = cb_authenticate()
path = os.environ['CB_DATA']


def specialty_price_update(file_path, file_name):

    data = pd.read_csv(file_path, dtype={
                       'NDC': str, 'WAC_Per_Unit_Plus3Per': float})
    currdate = datetime.strftime(datetime.now(), '%m%d%Y_%H%M')
    mac_list_id = 'HPSPECLMAC'
    claim_processor = 'sc_humanas'
    delete_old_pricing(claim_processor)
    data['ndc'] = data['ndc'].apply(lambda x: str(x).strip().zfill(11))
    bg_definition = brand_generic_definition(claim_processor)

    log = path+'/'+domain+'/'+file_type + \
        '/log/humanaspricing'+str(currdate)+'.txt'
    logfile = open(log, "w")
    price_compare_report = pd.DataFrame()
    drugs_processed = 0
    ndc_not_processed = 0
    brand_generic_substitute = {'G': 'Generic', 'T': 'Brand', 'B': 'Brand'}
    ndc_list = []

    for i, r in data.iterrows():

        if r['ndc'] in ndc_list:
            continue

        drug = get_ndc_info(r['ndc'])
        ndc_list.append(r['ndc'])

        if not drug:
            logfile.write('**NDC not found'+r['ndc'])
            ndc_not_processed += 1
            continue

        record = get_db_price(drug, True)
        ndcs = get_ndc_info(
         None, drug['gpi'], drug['drug_name'], drug['brand_generic'], drug['gppc'])
        ndc_price = r['WAC_Per_Unit_Plus3Per']         
        if ndcs:
            ndcs_same_ggpc = list(data[(data['ndc'].isin(ndcs))]['ndc'].values)
            prices_same_gppc = list(data[(data['ndc'].isin(ndcs))]['WAC_Per_Unit_Plus3Per'].values)
            if ndcs_same_ggpc:
                ndc_list.extend(ndcs_same_ggpc)
                ndc_price = min(prices_same_gppc)

        final_unit_price, rebate_factor = get_brand_rebate(
            drug, ndc_price, claim_processor)
        logfile.write('**********************\r\n')
        logfile.write('NDC :' + str(drug['ndc'])+'\r\n')
        logfile.write('Discount Applied :' +
                      str(rebate_factor)+'  '+rebate_factor+'\r\n')
        logfile.write('Final AWP :' + str(final_unit_price) + '\r\n')
        payer_brand_generic = 'G'
        if not bg_definition['payer_generic_def']:
            payer_brand_generic = drug['brand_generic'].replace('B', 'T')
        else:
            for key, value in bg_definition['payer_generic_def'].items():
                if drug.get(key, None) != value:
                    payer_brand_generic = 'T'

        humana_price = {'pricetype': 'MAC', 'claim_processor': claim_processor, 'unitprice': final_unit_price,
                        'unit_price_before_rebate': ndc_price, 'maclistid': mac_list_id, 'rebate_factor': rebate_factor, 'sc_brandorgeneric': brand_generic_substitute[drug['brand_generic']], 'payer_brand_generic': payer_brand_generic}

        if mode.strip().upper() == 'FINAL':
            price_update(humana_price, file_name, drug, record)
            drugs_processed += 1

    logfile.write('Number of drugs processed' + str(drugs_processed)+'\r\n')
    logfile.write('Number of NDCs not processed'+str(ndc_not_processed)+'\r\n')

    report = price_compare(claim_processor)
    price_compare_report = price_compare_report.append(
        report, ignore_index=True)

    price_compare_report.to_csv(path + '/' + domain + '/' + file_type +
                                '/HumanaSpecialtyPriceReport' + str(currdate) + '.csv', index=False)

    if mode.strip().upper() == 'FINAL':
        logfile.write('Humana specialty price update: '+file_name)
        subject = 'Humana specialty price update '
        logfile.close()
        receiver = None
        if os.environ['INSTANCE_TYPE'] == 'PROD':
            receiver = 'pricing@fliptrx.com'
        email_log('noreply@fliptrx.com', 'fliptintegration@fliptrx.com', receiver, subject, [
                  'Humana specialty price update File '+file_name, 'Humana price update Exception'], log, True)
    else:
        logfile.close()


def mailorder_price_update(file_path, file_name):

    data = pd.read_csv(file_path, dtype={
        'NDC': str, 'products_unit_awp': int})
    data['AWP Unit Price'] = data['products_unit_awp']/100.0

    currdate = datetime.strftime(datetime.now(), '%m%d%Y_%H%M')
    mac_list_id = 'HPTRADMAC'
    claim_processor = 'sc_humanam'

    delete_old_pricing(claim_processor)
    bg_definition = brand_generic_definition(claim_processor)
    data['NDC'] = data['NDC'].apply(lambda x: str(x).strip().zfill(11))
    log = path+'/'+domain+'/'+file_type + \
        '/log/humanampricing'+str(currdate)+'.txt'
    logfile = open(log, "w")
    ndc_list = []
    price_compare_report = pd.DataFrame()

    query = N1QLQuery(
        "Select * from `" + os.environ['CB_INSTANCE'] + "` where type='price_source_configuration' and price_source=$cp", cp=claim_processor)
    price_source_configuration = []
    for result in cb.n1ql_query(query):
        price_source_configuration.append(result[os.environ['CB_INSTANCE']])
    brand_generic_substitute = {'G': 'Generic', 'T': 'Brand', 'B': 'Brand'}
    drugs_processed = 0
    ndc_not_processed = 0

    for i, r in data.iterrows():
        print(r)
        if r['NDC'] in ndc_list:
            continue

        drug = get_ndc_info(r['NDC'])

        if not drug:
            logfile.write('**NDC not found'+r['NDC']+'\r\n')
            ndc_not_processed += 1
            continue
        drug_ndcs = []
        mac = False
        top_300 = False

        if drug['brand_generic'] == 'G' and drug['otc_indicator'] == 'R' and drug['multi_source'] == 'Y':
            mac = True

        if mac:

            ndcs = get_ndc_info(
                None, drug['gpi'], drug['drug_name'], drug['brand_generic'], None)
            drug_ndcs.extend(ndcs)
            ndc_list.extend(ndcs)

            awp_prices = list(data[data['NDC'].isin(
                drug_ndcs)]['AWP Unit Price'].values)
            if awp_prices:
                awp_prices = [float(awp) for awp in awp_prices]
                awp_price = sum(awp_prices) / len(awp_prices)/1.0

            query = N1QLQuery("Select count(*) count  from `" +
                              os.environ['CB_INSTANCE'] + "` where type='top_drugs' and $gpi in gpi_12", gpi=drug['gpi_12'])
            for result in cb.n1ql_query(query):
                if result['count']>0:
                    top_300 = True

            record = get_db_price(drug, False)
            discount = [x['discount'] for x in price_source_configuration if (
                x['mac'] == mac and x['top_300'] == top_300)]

        else:
            ndc_list.append(drug['ndc'])
            awp_price = r['AWP Unit Price']
            record = get_db_price(drug, True)
            discount = [x['discount'] for x in price_source_configuration if (
                x['brand_generic'] == drug['brand_generic'] and x['multi_source'] != drug['multi_source'])]
        if discount:
            discount = discount[0]
        else:
            discount = [x['discount']
                        for x in price_source_configuration if x['default']][0]

        discounted_awp_price = float(awp_price) * (1-discount)
        final_unit_price, rebate_factor = get_brand_rebate(
            drug, discounted_awp_price, claim_processor)
        logfile.write('**********************\r\n')
        logfile.write('NDC :' + str(drug['ndc'])+'\r\n')
        logfile.write('Classified price type MAC ? :' + str(mac)+'\r\n')
        logfile.write('Top 300 ? :' + str(top_300)+'\r\n')
        logfile.write('Discount Applied :' + str(discount) +
                      '  '+rebate_factor+'\r\n')
        logfile.write('Final AWP :'+str(final_unit_price)+'\r\n')
        if drug.get('unit_price', ''):
            report_record = {'DDID': drug['ddid'], 'GPI': drug['gpi'], 'DRUG NAME': drug['drug_name'], 'BRAND/GENERIC': drug['brand_generic'], 'GPPC': drug['gppc'],
                             'OLD PRICE/NDC AWP PRICE': drug['unit_price'], 'NEW PRICE/HUMANA AWP PRICE': awp_price, 'OLD PRICE BEFORE REBATE': '', 'NEW PRICE BEFORE REBATE': '', 'Comparison': 'NDC AWP vs HUMANA AWP'}
            price_compare_report = price_compare_report.append(
                report_record, ignore_index=True)

        payer_brand_generic = 'G'
        if not bg_definition['payer_generic_def']:
            payer_brand_generic = drug['brand_generic'].replace('B', 'T')
        else:
            for key, value in bg_definition['payer_generic_def'].items():
                if drug.get(key, None) != value:
                    payer_brand_generic = 'T'

        humana_price = {'pricetype': 'MAC', 'claim_processor': claim_processor, 'unitprice': str(
            final_unit_price), 'unit_price_before_rebate': awp_price, 'maclistid': mac_list_id, 'rebate_factor': rebate_factor, 'sc_brandorgeneric': brand_generic_substitute[drug['brand_generic']], 'payer_brand_generic': payer_brand_generic}

        if mode.strip().upper() == 'FINAL':
            price_update(humana_price, file_name, drug, record)
            drugs_processed += 1

    logfile.write('Number of drugs processed' + str(drugs_processed)+'\r\n')
    logfile.write('Number of NDCs not processed'+str(ndc_not_processed)+'\r\n')

    report = price_compare(claim_processor)
    price_compare_report = price_compare_report.append(
        report, ignore_index=True)

    price_compare_report.to_csv(path+'/'+domain+'/'+file_type +
                                '/HumanaTraditionalPriceReport'+str(currdate)+'.csv', index=False)
    if mode.strip().upper() == 'FINAL':
        logfile.write('Humana traditional price update: '+file_name)
        subject = 'Humana traditional price update '
        logfile.close()
        receiver = None
        if os.environ['INSTANCE_TYPE'] == 'PROD':
            receiver = 'pricing@fliptrx.com'
        email_log('noreply@fliptrx.com', 'fliptintegration@fliptrx.com', receiver, subject, [
                  'Humana traditional price update File '+file_name, 'Humana price update Exception'], log, True)
    else:
        logfile.close()


def get_ndc_info(ndc=None, gpi=None, drug_name=None, brand_generic=None, gppc=None):

    if ndc:
        drug = {}
        query = N1QLQuery(
            "Select * from `" + os.environ['CB_INSTANCE'] + "` where type='ndc_drugs' and ndc=$ndc", ndc=ndc)
        for result in cb.n1ql_query(query):
            drug.update(result[os.environ['CB_INSTANCE']])
            drug.update({'gpi_12': drug['gpi'][:12]})
        return drug
    else:
        ndcs = []
        query_string = "Select ndc from `" + \
            os.environ['CB_INSTANCE'] + \
            "` where type='ndc_drugs' and gpi=$gpi and drug_name=$dn and brand_generic=$bg"
        if gppc:
            query_string = "Select ndc from `" + \
                os.environ['CB_INSTANCE'] + \
                "` where type='ndc_drugs' and gpi=$gpi and drug_name=$dn and brand_generic=$bg and gppc=$gppc"
        query = N1QLQuery(query_string, gpi=gpi, dn=drug_name,
                          bg=brand_generic, gppc=gppc)
        for result in cb.n1ql_query(query):
            ndcs.append(result['ndc'])
        return ndcs


def get_db_price(drug, gppc_include):

    query_string = "Select cp_price,meta().id from `" + \
        os.environ['CB_INSTANCE'] + \
        "` where type='cp_drug_price_stg' and gpi=$gpi and drug_name=$dn"
    if gppc_include:
        query_string = query_string + " and gppc=$gppc"
    query = N1QLQuery(
        query_string, gpi=drug['gpi'], dn=drug['drug_name'], ddid=drug['ddid'], gppc=drug['gppc'])
    result = []
    for record in cb.n1ql_query(query):
        result.append(record)

    return result


def get_brand_rebate(drug, unit_price, claim_processor):

    rebate_factor = ''

    query = N1QLQuery('Select rebate_factor,claim_processor from `' +
                      os.environ['CB_INSTANCE']+'` where type="brand_rebate" and brand_generic=$bg and drug_name=$dn and gpi=$gpi and active_status_flag="Y"', bg=drug['brand_generic'], dn=drug['drug_name'], gpi=drug['gpi'])
    query.timeout = 100
    for record in cb.n1ql_query(query):
        if claim_processor in record['claim_processor']:
            rebate_factor = record['rebate_factor']
        if rebate_factor:
            unit_price = float(unit_price) * float(rebate_factor)

    return unit_price, rebate_factor


def brand_generic_definition(claim_processor):
    bg_definition = {'payer_generic_def': {}}
    query = N1QLQuery('select payer_generic_def from `'+os.environ['CB_INSTANCE'] +
                      '` where type="claim_processor" and claim_processor=$cp', cp=claim_processor)
    for result in cb.n1ql_query(query):
        bg_definition.update(result)

    return bg_definition


def price_update(humana_price, file_name, drug, record):

    brandgeneric_substitute = {'G': 'Generic', 'T': 'Brand', 'B': 'Brand'}

    if record:
        for element in record:
            element['cp_price'].append(humana_price)
            cb.mutate_in(element['id'], SD.upsert(
                'cp_price', element['cp_price']))
            cb.mutate_in(element['id'], SD.upsert('file_name', file_name))
            cb.mutate_in(element['id'], SD.upsert('updated_by', 'humana'))
            cb.mutate_in(element['id'], SD.upsert(
                'update_date', datetime.now().isoformat()))
    else:
        drug['brandorgeneric'] = brandgeneric_substitute[drug['brand_generic']]
        record = {'drug_descriptor_identifier': drug['ddid'], 'drug_name': drug['drug_name'], 'gpi': drug['gpi'], 'brandorgeneric': drug['brandorgeneric'], 'cp_price': [humana_price], 'type': 'cp_drug_price_stg', 'drug_price_id': '', 'create_date': datetime.now().isoformat(), 'created_by': 'humana', 'file_name': file_name, 'gppc': drug['gppc'], 'productnamefull': '', 'update_date': datetime.now().isoformat(
        ), 'updated_by': 'humana', 'dispensingtext': '', 'dosageformid': '', 'item_status_flag': 'A', 'multiscourcecode': drug.get('multi_source', ''), 'otcindicator': drug.get('otc_indicator', ''), 'package_description_code': drug.get('pkg_desc_cd', ''), 'package_quantity': drug.get('package_quantity', ''), 'packsize': drug.get('package_size', ''), 'packuom': drug.get('pkg_uom', ''), 'productstrength': drug.get('strengths', ''), 'unitdose': drug.get('unit_dose', ''), 'unitofmeasure': ''}
        record['drug_price_id'] = str(cb.counter('docid', delta=1).value)
        cb.upsert(record['drug_price_id'], record)


def update_old_pricing():

    if mode.upper() != 'FINAL':
        return

    query = N1QLQuery(
        f'select count(*) count from `{bucket_name}` where type="cp_drug_price_stg"')
    query.timeout = 3600
    for result in cb.n1ql_query(query):
        if result['count'] != 0:
            print('Pricing already present in cp_drug_price_stg')
            return

    query = N1QLQuery('select * from `'+bucket_name +
                      '` where type="cp_drug_price"')
    query.timeout = 3600
    for result in cb.n1ql_query(query):
        record = result[bucket_name]
        record['type'] = 'cp_drug_price_stg'
        record['drug_price_id'] = str(cb.counter('docid', delta=1).value)
        cb.upsert(record['drug_price_id'], record)
    print('Records copied from cp_drug_price to cp_drug_price_stg')
    import time
    time.sleep(600)


def delete_old_pricing(claim_processor):

    query = N1QLQuery('Update `'+bucket_name +
                      '` set cp_price=ARRAY v FOR v IN cp_price WHEN v.claim_processor != $cp END where type="cp_drug_price_stg" ', cp=claim_processor)
    query.timeout = 3600
    cb.n1ql_query(query).execute()
    
    query = N1QLQuery('Delete from `'+bucket_name +
                      '` where type="cp_drug_price_stg" and ARRAY_LENGTH(cp_price)=0 ')
    query.timeout = 3600
    cb.n1ql_query(query).execute()


def price_compare(claim_processor):

    data = pd.DataFrame()
    price_compare_report = pd.DataFrame()

    query = N1QLQuery("Select distinct a.brandorgeneric,a.gpi,a.drug_name,a.gppc,a.drug_descriptor_identifier,cp1.unitprice,cp1.unit_price_before_rebate,'old' type from `" +
                      os.environ['CB_INSTANCE'] + "` a unnest a.cp_price cp1 where a.type='cp_drug_price' and cp1.claim_processor=$cp union Select distinct b.gpi,b.drug_name,b.gppc,b.drug_descriptor_identifier,cp2.unitprice,cp2.unit_price_before_rebate,'new' type from `" + os.environ['CB_INSTANCE'] + "` b unnest b.cp_price cp2 where b.type='cp_drug_price_stg' and cp2.claim_processor=$cp", cp=claim_processor)
    query.timeout = 1500
    for result in cb.n1ql_query(query):
        data = data.append(result, ignore_index=True)

    for key, group in data.groupby(['drug_descriptor_identifier', 'gpi', 'drug_name', 'gppc', 'brandorgeneric']):

        record = {'DDID': key[0], 'GPI': key[1], 'DRUG NAME': key[2], 'BRAND/GENERIC': key[4], 'GPPC': key[3], 'OLD PRICE/AWP PRICE': '',
                  'NEW PRICE/HUMANA PRICE': '', 'OLD PRICE BEFORE REBATE': '', 'NEW PRICE BEFORE REBATE': '', 'Comparison': 'Old vs New'}
        for i, row in group.iterrows():
            if row['type'] == 'old':
                record['OLD PRICE'] = row['unitprice']
                record['OLD PRICE BEFORE REBATE'] = row['unit_price_before_rebate']
            elif row['type'] == 'new':
                record['NEW PRICE'] = row['unitprice']
                record['NEW PRICE BEFORE REBATE'] = row['unit_price_before_rebate']
        price_compare_report = price_compare_report.append(
            record, ignore_index=True)

    return price_compare_report


if __name__ == '__main__':

    files_found_list = send_files_from_s3()
    if files_found_list and len(files_found_list) > 2:
        print('more than 2 files found', ', '.join(files_found_list))
        exit()

    if files_found_list:
        update_old_pricing()
    for file_path in files_found_list:
        filename = file_path.split('/')[-1]
        if 'specialty_daily_status_report' in filename.lower():
            specialty_price_update(file_path, filename)
        if 'traditional_daily_status_report' in filename.lower():
            mailorder_price_update(file_path, filename)

    if mode.lower() == 'final' and files_found_list:
        import shutil
        import os
        shutil.rmtree(os.path.split(files_found_list[0])[0])