########################################
# !/usr/bin/env python
# title         : scriptclaimpricingval.py
# description   : Script Claim AWP/MAC  prices upload
# author        : Disha
# date created  : 20180101
# date last modified    : 20190118 16:28
# version       : 0.1
# maintainer    : Pal
# email         : pmuthanai@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage 1         : python scriptclaimpricingval.py -d GWLABS001 -t cp_drug_price -f cp_awp_price2018-02-22 -m DRAFT
# usage 2         : nohup python scriptclaimpricingval.py -d GWLABS001 -t cp_drug_price -f cp_awp_price2018-02-22 -m FINAL > cp_awp_price2018-02-22.log 2> cp_awp_price2018-02-22.err < /dev/null &
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  0.1							20190118	Add header
# #######################################

from utils.sendgridemail import email_log_custombody, email_log
import couchbase.subdocument as SD
from couchbase import FMT_JSON
from couchbase.n1ql import N1QLQuery
from couchbase.cluster import Bucket
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Cluster
from datetime import datetime
import psycopg2
import sys
import os
import shutil
import pandas as pd
import json
import argparse
if __name__ == '__main__':
    import os
    import sys
    rootdir = os.path.dirname(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))))
    sys.path.append(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']


cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(
    os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])

path = os.environ['CB_DATA']
parser = argparse.ArgumentParser(description='commandline file processing...')
parser.add_argument(
    "-d", "--domain", help="pass in domain (company)", required=False),
parser.add_argument("-t", "--file_type",
                    help="pass in doc type", required=False)
parser.add_argument("-f", "--file_name",
                    help="pass in file name", required=False)
parser.add_argument("-a", "--action",
                    help="refresh/append MAC data", required=False)
parser.add_argument("-m", "--processing_type",
                    help="final/draft mode", required=True)
args = parser.parse_args()
domain, file_type, file_name, mode, action = args.domain, args.file_type, args.file_name, args.processing_type, args.action
currentdate = datetime.now()
currentdate = currentdate.isoformat()
remotepath = ''
localpath = ''
# log = path+'/'+domain+'/'+file_type+'/log/'+file_name+str(currentdate)+'.txt'
err = path+'/'+domain+'/'+file_type+'/log/' + \
    file_name+str(currentdate)+'log'+'.xlsx'
archivefile = ''
writer = pd.ExcelWriter(err, engine='xlsxwriter')

transferstatus = ''
loadtype = 'I'
updatecount = 0
error = pd.DataFrame()


def claimprocessorpricing():

    pricesources = ['scriptclaim', 'cerpass']
    global error, localpath, err, remotepath, archivefile

    if 'AWP' in file_name.upper():
        updatepricing('')
        sys.exit()

    # FTP

    failure = True

    # err = path + '/' + domain + '/' + file_type + '/log/' + 'cp_price' + str(currentdate) + 'Log.xlsx'
    for pr in pricesources:
        if pr == 'scriptclaim':
            from sclaimintegration.scriptclaimsftp import multiplefilesftptransfer
            remotepath = '/cp_drug_price/'
            localpath = path + '/' + domain + '/' + file_type + '/'
            writer = pd.ExcelWriter(err, engine='xlsxwriter')
            filelist, transferstatus = multiplefilesftptransfer(
                remotepath, localpath, 'GET')
            filelist = [i for i in filelist if i != 'archive']
            if not filelist:
                print('Script Claim MAC Pricing not found')
                continue
            transferstatus = 'S'
            localpath = localpath+filelist[0]

        elif pr == 'cerpass':

            from pricing.cerpasssftp import sftptransfer, getfilelist
            remotepath = '/l_upload'
            localpath = path + '/' + domain + '/' + file_type + '/'
            filelist = getfilelist(remotepath)

            filename = ''
            for filen in filelist:
                if 'cerpass_mac' in filen.lower():
                    filename = filen
            if not filelist or not filename:
                print('Cerpass MAC Drug File not found')
                continue
            localpath = localpath + filename
            remotepath = remotepath + '/' + filename
            transferstatus = sftptransfer(remotepath, localpath, 'GET')

        if transferstatus != 'S':
            print(pr+" Drug Pricing File Transfer Failed ")
            continue
        else:
            print(pr + " Drug Pricing File was successfully transferred ")
            filesize = os.path.getsize(localpath)
            if filesize > 0:
                updatepricing(pr)
                exit()
                failure = False
            else:
                print(pr+" Drug Pricing File is empty ")

    if failure:
        sys.exit()
    writer = pd.ExcelWriter(err, engine='xlsxwriter')


def updatepricing(pricesource, initial_data=pd.DataFrame()):

    global error, localpath, err, remotepath, archivefile

    if 'awp' in file_name.lower():

        drugfile, awpfilename = extractawppricing()

        drugfile.drop_duplicates(inplace=True)

        drug_cols = {"GPICode": "gpi", "MultiSourceCode": "multiscourcecode", "UnitPrice": "unitprice", "ProductNameAbr": "drug_name", "ProductNameFull": "productnamefull", "ProductStrength": "productstrength", "DosageFormID": "dosageformid", "UnitOfMeasure": "unitofmeasure", "PriceType": "pricetype", "BrandOrGeneric": "borg", "PackSize": "packsize",
                     "PackUOM": "packuom", "UnitDose": "unitdose", "GPPC": "gppc", "Package_Quantity": "package_quantity", "DispensingText": "dispensingtext", "Package_Description_Code": "package_description_code", "OTCIndicator": "otcindicator", "Drug_Descriptor_Identifier": "drug_descriptor_identifier", "Brand_Name_Code": "brandorgeneric", "Item_Status_Flag": "item_status_flag"}
        drugfile.rename(columns=drug_cols, inplace=True)
        drug_cols = list(drugfile)
        drugfile = drugfile[drugfile['pricetype'] == 'AWP']
        if drugfile.empty:
            print('NO AWP Records Found')
        unitp = ''
        ite = 0
        bg_definition = getbrandgenericdefinition()

        for index, dprow in drugfile.groupby(['gpi', 'drug_name', 'brandorgeneric', 'gppc']):
            dprow.reset_index(drop=True, inplace=True)
            errort = False
            dprecs = {}
            for dpcols in drug_cols:
                if dpcols == 'unitprice':
                    try:
                        unitp = float(str(dprow.loc[0, 'unitprice']).strip())
                    except:
                        error = error.append({'gpi': index[0], 'gppc': index[3], 'drug_name': index[1], 'brand_generic': index[2], 'Medispan brand_generic': '',
                                              'old unit_price': '', 'new unit_price': dprow.loc[0, 'unitprice'], 'Status': 'Error', 'Message': 'Invalid Unit Price', 'MACListID': ''}, ignore_index=True)
                        errort = True
                if dpcols not in ['unitprice', 'pricetype', 'borg']:
                    dprecs[dpcols] = str(dprow.loc[0, dpcols]).strip()
            dprecs['gpi'] = str(dprecs['gpi']).replace('.0', '').rjust(14, '0')
            if len(index[0]) > 14:
                error = error.append({'gpi': index[0], 'gppc': index[3], 'drug_name': index[1], 'brand_generic': index[2], 'Medispan brand_generic': '',
                                      'old unit_price': '', 'new unit_price': '', 'Status': 'Error', 'Message': 'Invalid GPI', 'MACListID': ''}, ignore_index=True)
                errort = True

            if errort:
                continue
            # Update Logic
            otc = str(dprecs['otcindicator']).strip()

            gpi_code = str(dprecs['gpi']).rjust(14, '0')
            gppc_code = str(dprecs['gppc']).rjust(8, '0')
            drug_name = str(dprecs['drug_name']).strip()
            sc_brand_generic = str(dprecs['brandorgeneric']).strip()
            dprecs['brandorgeneric'] = ''
            if str(sc_brand_generic).strip() == 'G':
                sc_brand_generic = 'Generic'
            else:
                sc_brand_generic = 'Brand'

            druginfo = {}
            drugcount = 0
            drugcounttab = N1QLQuery('select distinct multi_source,brand_generic,ddid,drug_full_name,meta().id id from `' +
                                     os.environ['CB_INSTANCE']+'` WHERE type = "drug" and gpi = $gpi and drug_name = $drug', gpi=gpi_code, drug=drug_name)
            drugcounttab.adhoc = False
            drugcounttab.timeout = 100
            b_g = ''
            for drugcountrow in cb.n1ql_query(drugcounttab):
                druginfo.update(drugcountrow)
                dprecs['drug_descriptor_identifier'] = drugcountrow['ddid']
                if 'drug_full_name' in drugcountrow:
                    dprecs['productnamefull'] = drugcountrow['drug_full_name']
                b_g = drugcountrow['brand_generic']
                if b_g == 'G':
                    dprecs['brandorgeneric'] = 'Generic'
                else:
                    dprecs['brandorgeneric'] = 'Brand'

            rebfactor = ''
            rebcp = []
            brebate = N1QLQuery('Select rebate_factor,claim_processor from `' +
                                os.environ['CB_INSTANCE']+'` where type="brand_rebate" and brand_generic=$bg and drug_name=$dn and gpi=$gpi and active_status_flag="Y"', bg=b_g, dn=drug_name, gpi=gpi_code)
            brebate.adhoc = False
            brebate.timeout = 100
            for rebrow in cb.n1ql_query(brebate):
                rebfactor = rebrow['rebate_factor']
                rebcp.extend(rebrow['claim_processor'])

            # print('rebate')
            oldprice = pd.DataFrame()
            updatetab = N1QLQuery('select  cp_price,gppc from `' +
                                  os.environ['CB_INSTANCE'] + '` t WHERE t.type = "cp_drug_price" and t.gpi = $gpi_u and t.drug_name = $drug', gpi_u=gpi_code, drug=drug_name)
            updatetab.adhoc = False
            updatetab.timeout = 100
            unit_price = ''
            for updaterow in cb.n1ql_query(updatetab):
                if not updaterow['gppc'] or updaterow['gppc'] == gppc_code:
                    if isinstance(updaterow['cp_price'], dict):
                        oldprice = pd.DataFrame(data=[updaterow['cp_price']])
                    else:
                        oldprice = pd.DataFrame(data=updaterow['cp_price'])
                    break

            dprecs['cp_price'] = []
            claim_processors = ['scriptclaim', 'sc_walmart', 'cerpass']
            new_awp_price = ''
            druginfo['payer_generic'] = {}
            for key, value in bg_definition.items():
                payer_brand_generic = 'G'
                if not value.get('payer_generic_def', {}):
                    payer_brand_generic = str(
                        dprecs['brandorgeneric']).strip().replace('B', 'T')
                for innerkey, innervalue in value.get('payer_generic_def').items():
                    if druginfo.get(innerkey, None) != innervalue:
                        payer_brand_generic = 'T'
                        break
                druginfo['payer_generic'].update({key: payer_brand_generic})

            for cp in claim_processors:
                pricerecs = {}
                pricerecs['claim_processor'] = cp
                pricerecs['rebate_factor'] = rebfactor
                pricerecs['unit_price_before_rebate'] = str(
                    max(list(dprow['unitprice'])))
                active = dprow[dprow['item_status_flag']
                               == 'A']['unitprice'].values
                if(len(active) > 0):
                    activedict = {}
                    for i in active:
                        activedict[float(i)] = i
                    pricerecs['unit_price_before_rebate'] = "{0:.5f}".format(float(activedict[max(
                        activedict.keys())]))
                    pricerecs['unitprice'] = "{0:.5f}".format(
                        float(pricerecs['unit_price_before_rebate']))
                    if rebfactor != '' and cp in rebcp:
                        pricerecs['unitprice'] = "{0:.5f}".format(
                            float(pricerecs['unitprice'])*float(rebfactor))
                else:
                    inactive = dprow[dprow['item_status_flag']
                                     == 'I']['unitprice'].values
                    inactivedict = {}
                    for i in inactive:
                        inactivedict[float(i)] = i
                    pricerecs['unit_price_before_rebate'] = "{0:.5f}".format(
                        inactivedict[max(inactivedict.keys())])
                    pricerecs['unitprice'] = "{0:.5f}".format(
                        float(pricerecs['unit_price_before_rebate']))
                    if rebfactor != '' and cp in rebcp:
                        pricerecs['unitprice'] = "{0:.5f}".format(
                            float(pricerecs['unitprice']) * float(rebfactor))
                new_awp_price = pricerecs['unitprice']
                pricerecs['pricetype'] = str(dprow.loc[0, 'pricetype'])
                pricerecs['maclistid'] = ''
                pricerecs['sc_brandorgeneric'] = sc_brand_generic
                pricerecs['payer_brand_generic'] = druginfo['payer_generic'][cp]
                dprecs['cp_price'].append(pricerecs)

            for i, r in oldprice.iterrows():
                if r['pricetype'] != 'AWP':
                    dprecs['cp_price'].append(dict(r))
                else:
                    error = error.append({'gpi': gpi_code.ljust(20), 'gppc': gppc_code.ljust(10), 'drug_name': drug_name, 'brand_generic': sc_brand_generic,
                                          'Medispan brand_generic': '', 'old unit_price': r['unitprice'], 'new unit_price': new_awp_price, 'Status': '', 'Message': 'Price Comparison'}, ignore_index=True)

            dprecs['create_date'] = currentdate
            dprecs['update_date'] = currentdate
            dprecs['created_by'] = 'Flipt'
            dprecs['updated_by'] = 'Flipt'
            dprecs['type'] = 'cp_drug_price_stg'
            dprecs['file_name'] = awpfilename
            
            
            if len(dprow) > 1:
                error = error.append({'gpi': gpi_code.ljust(20), 'gppc': gppc_code.ljust(10), 'drug_name': drug_name, 'brand_generic': sc_brand_generic,
                                      'Medispan brand_generic': '', 'old unit_price': '', 'new unit_price': '', 'Status': '', 'Message': 'Multiple AWP Prices Found'}, ignore_index=True)
            # print(dprecs)
            # exit()
            if mode.upper() == 'FINAL':
                rv1 = cb.counter('docid', delta=1)
                dprecs['drug_price_id'] = str(rv1.value)
                cb.upsert(str(dprecs['drug_price_id']),
                          dprecs, format=FMT_JSON)
            error = error.append({'gpi': gpi_code.ljust(20), 'gppc': gppc_code.ljust(10), 'drug_name': drug_name, 'brand_generic': sc_brand_generic,
                                  'Medispan brand_generic': b_g, 'old unit_price': '', 'new unit_price': '', 'Status': 'Success', 'Message': ''}, ignore_index=True)
            # print(ite)
            ite = ite + 1
        
        updateoldpricing('AWP')
        error = validatepricing(error)
        error.drop_duplicates(inplace=True)
        error.to_excel(writer, index=False)
        writer.save()
        subject = 'AWP Drug Pricing File Processed'
        email_log('DWagle@fliptrx.com', 'SPal@fliptrx.com', 'FliptIntegration@fliptrx.com', subject, [
            'Processing of AWP Drug Pricing File '+file_name, 'AWP Drug Pricing Exception'], err, True)

    elif 'mac' in file_name.lower():

        macfile = None
        if action.lower() == 'refresh' and len(initial_data) == 0 and mode.lower() == 'final':
            updateoldpricing(pricesource)
        print(localpath)
        if pricesource == 'scriptclaim':
            print('reading scriptclaim file')
            macfile = pd.read_csv(localpath, sep='|', index_col=False, names=["MacListID", "GPICode", "GPPC", "GenericName", "UnitPrice",
                                                                              "ProductNameAbr", "BrandNameCode", "BrandorGeneric", "DDID"], skiprows=1, dtype={'UnitPrice': float, 'DDID': str, 'GPPC': str})
        elif pricesource == 'cerpass':
            print('reading cerpass file')
            if len(initial_data) == 0:
                macfile = pd.read_csv(localpath, index_col=False, names=["MacListID", "GPICode", "GPPC", "GenericName", "UnitPrice", "ProductNameAbr",
                                                                         "BrandNameCode", "BrandorGeneric", "DDID"], skiprows=1, dtype={'UnitPrice': float, 'DDID': str, 'GPPC': str, 'GPICode': str})
            else:
                macfile = initial_data.copy()
        macfile.fillna("", inplace=True)
        macfile.drop_duplicates(inplace=True)
        mac_cols = {"MacListID": "maclistid", "GPICode": "gpi", "GPPC": "gppc", "GenericName": "productnamefull", "UnitPrice": "unitprice",
                    "ProductNameAbr": "drug_name", "BrandNameCode": "brandorgeneric", "BrandorGeneric": "borg", "DDID": "drug_descriptor_identifier"}
        macfile.rename(columns=mac_cols, inplace=True)
        mac_cols = list(macfile)
        bg_definition = getbrandgenericdefinition().get(pricesource, {})

        ite = 0
        macfile['maclistid'] = macfile['maclistid'].apply(
            lambda x: str(x).strip().upper())
        residual_data = pd.DataFrame()
        
        for index, macrow in macfile.groupby(['gpi', 'drug_name', 'brandorgeneric', 'productnamefull', 'gppc', 'drug_descriptor_identifier']):
            macrow.reset_index(drop=True, inplace=True)
            macrecs = {}
            for maccols in mac_cols:
                if maccols not in ['borg', 'unitprice', 'pricetype', 'maclistid']:
                    macrecs[maccols] = str(macrow.loc[0, maccols]).strip()
            macrecs['gpi'] = str(macrecs['gpi']).rjust(14, '0')
            # Update Logic
            gpi_code = str(macrecs['gpi']).rjust(14, '0')
            gppc_code = str(macrecs['gppc']).rjust(8, '0')
            drug_name = str(macrecs['drug_name']).strip()
            sc_brand_generic = str(macrecs['brandorgeneric']).strip()
            # macrecs['drug_descriptor_identifier'] = str(macrecs['drug_descriptor_identifier']).strip()
            macrecs['productnamefull'] = ''
            pricesource_bg = macrecs['brandorgeneric']
            macrecs['brandorgeneric'] = ''
            if str(sc_brand_generic).strip() == 'G':
                sc_brand_generic = 'Generic'
            else:
                sc_brand_generic = 'Brand'

            if len(gpi_code) > 14:
                error = error.append({'gpi': gpi_code, 'gppc': gppc_code, 'drug_name': drug_name, 'brand_generic': sc_brand_generic, 'Medispan brand_generic': '',
                                      'old unit_price': '', 'new unit_price': '', 'Status': 'Error', 'Message': 'Invalid GPI', 'MACListID': ''}, ignore_index=True)
            
            drugcount = 0
            b_g = ''
            druginfo = {}
            drugfound = False
            select_fields = 'brand_generic,ddid,drug_name'
            additions = ','.join(
                [x for x in bg_definition.get('payer_generic_def', '').keys() if x not in select_fields.split(',')])
            if additions:
                select_fields = select_fields+','+additions
            drugquery = 'select distinct '+select_fields+' from `' + \
                os.environ['CB_INSTANCE'] + \
                '` WHERE type = "drug" and gpi = $gpi and drug_name = $drug '
            if pricesource == 'cerpass':
                
                drugquery = 'select distinct '+select_fields+' from `' + \
                    os.environ['CB_INSTANCE'] + \
                    '` WHERE type = "drug" and gpi = $gpi' + \
                    bg_definition.get('query_condition', '')

            drugcounttab = N1QLQuery(drugquery, gpi=gpi_code,
                                     bg=pricesource_bg, drug=drug_name)
            drugcounttab.adhoc = False
            drugcounttab.timeout = 100
            drugfoundcount = 0
            drug_found_list = {}
            for drugcountrow in cb.n1ql_query(drugcounttab):
                druginfo.update(drugcountrow)
                drugfoundcount = drugfoundcount + 1
                drugfound = True
                macrecs['drug_name'] = drugcountrow['drug_name']
                # drug_name = drugcountrow['drug_name']
                macrecs['drug_descriptor_identifier'] = drugcountrow['ddid']
                drug_found_list[drugcountrow['ddid']
                                ] = drugcountrow['drug_name']
                b_g = drugcountrow['brand_generic']
                if b_g == 'G':
                    macrecs['brandorgeneric'] = 'Generic'
                else:
                    macrecs['brandorgeneric'] = 'Brand'

                if drug_name == drugcountrow['drug_name']:
                    break
                drug_name = drugcountrow['drug_name']

            if not drugfound:
                error = error.append({'gpi': gpi_code, 'gppc': '', 'drug_name': drug_name, 'brand_generic': sc_brand_generic, 'Medispan brand_generic': '',
                                      'Status': 'Warning', 'Message': 'Drug not found in Drug DB', 'MACListID': '', 'old unit_price': '', 'new unit_price': ''}, ignore_index=True)
                continue
            if drugfoundcount > 1 and len(initial_data) == 0:
                error = error.append({'gpi': gpi_code, 'gppc': '', 'drug_name': drug_name, 'brand_generic': sc_brand_generic, 'Medispan brand_generic': '',
                                      'Status': 'Warning', 'Message': 'Multiple drugs match in Drug DB', 'MACListID': '', 'old unit_price': '', 'new unit_price': ''}, ignore_index=True)
                next_drug_data = macrow.copy()
                for did, dn in drug_found_list.items():
                    next_drug_data['drug_name'] = dn
                    next_drug_data['drug_descriptor_identifier'] = did
                    residual_data = residual_data.append(next_drug_data, ignore_index=True)
                continue

            payer_brand_generic = 'T'
            if not bg_definition.get('payer_generic_def', {}):
                payer_brand_generic = sc_brand_generic.replace(
                    'Generic', 'G').replace('Brand', 'T')
            else:
                generic_conditions = True
                for key, value in bg_definition.get('payer_generic_def').items():
                    if druginfo.get(key, None) != value:
                        generic_conditions = False
                if generic_conditions:
                    payer_brand_generic = 'G'

            inserttab = N1QLQuery('select meta().id id,cp_price,gppc from `' +
                                  os.environ['CB_INSTANCE']+'` WHERE type = "cp_drug_price_stg" and gpi = $gpi and drug_name = $drug', gpi=gpi_code, drug=drug_name)
            inserttab.adhoc = False
            inserttab.timeout = 100
            currentprices = []
            for updaterow in cb.n1ql_query(inserttab):
                currentprices.append(updaterow)

            if not currentprices:
                error = error.append({'gpi': gpi_code, 'gppc': '', 'drug_name': drug_name, 'brand_generic': sc_brand_generic, 'Medispan brand_generic': '',
                                      'old unit_price': '', 'new unit_price': '', 'Status': 'Error', 'Message': 'AWP Price Not Found', 'MACListID': ''}, ignore_index=True)

            rebfactor = ''
            rebcp = []

            brebate = N1QLQuery('Select rebate_factor,claim_processor from `' +
                                os.environ['CB_INSTANCE']+'` where type="brand_rebate" and brand_generic=$bg and drug_name=$dn and gpi=$gpi and active_status_flag="Y"', bg=b_g, dn=drug_name, gpi=gpi_code)
            brebate.adhoc = False
            brebate.timeout = 100
            for rebrow in cb.n1ql_query(brebate):
                rebfactor = rebrow['rebate_factor']
                rebcp.extend(rebrow['claim_processor'])

            updatetab = N1QLQuery('select cp_price,gppc from `' +
                                  os.environ['CB_INSTANCE']+'` WHERE type = "cp_drug_price" and gpi = $gpi and drug_name = $drug', gpi=gpi_code, drug=drug_name)
            updatetab.adhoc = False
            updatetab.timeout = 100
            oldprices = []
            for updaterow in cb.n1ql_query(updatetab):
                oldprices.append(updaterow)

            macrecs['cp_price'] = []
            allclaimmacprice = ''
            currentpricelist = {}
            try:
                allclaimmacprice = str(
                    macrow[macrow['maclistid'] == 'ALLCLAIMMAC']['unitprice'].values[0])
            except Exception as e:
                if pricesource == 'scriptclaim':
                    print(1)
                    error = error.append({'gpi': gpi_code, 'gppc': '', 'drug_name': drug_name, 'brand_generic': sc_brand_generic, 'Medispan brand_generic': '',
                                          'old unit_price': '', 'new unit_price': '', 'Status': 'Warning', 'Message': 'ALLCLAIMMAC Unit Price Missing', 'MACListID': ''}, ignore_index=True)
            for id, prow in macrow.iterrows():
                macpricerecs = {}
                try:
                    unitpricevalidation = float(prow['unitprice'])
                except:
                    print(2)
                    error = error.append({'gpi': gpi_code, 'gppc': '', 'drug_name': drug_name, 'brand_generic': sc_brand_generic, 'Medispan brand_generic': '',
                                          'old unit_price': '', 'new unit_price': prow['unitprice'], 'Status': 'Error', 'Message': 'Invalid Unit Price', 'MACListID': ''}, ignore_index=True)
                    continue
                if pricesource == 'scriptclaim' and str(macrow.loc[id, 'unitprice']) == allclaimmacprice and str(macrow.loc[id, 'maclistid']).strip().upper() not in ['ALLCLAIMMAC', 'WALMARTMAC']:
                    continue
                if str(macrow.loc[id, 'maclistid']).strip().upper() == 'WALMARTMAC':
                    macpricerecs['claim_processor'] = 'sc_walmart'
                    macpricerecs['rebate_factor'] = rebfactor
                    macpricerecs['unit_price_before_rebate'] = "{0:.5f}".format(
                        macrow.loc[id, 'unitprice'])
                    if rebfactor != '' and 'sc_walmart' in rebcp:
                        try:
                            macpricerecs['unitprice'] = "{0:.5f}".format(
                                float(macrow.loc[id, 'unitprice']) * float(rebfactor))
                        except Exception as e1:
                            print(3, e1)
                            print(
                                'walmart', macrow.loc[id, 'unitprice'], rebfactor)
                            macpricerecs['unitprice'] = "{0:.5f}".format(
                                macrow.loc[id, 'unitprice'])
                    else:
                        macpricerecs['unitprice'] = "{0:.5f}".format(
                            macrow.loc[id, 'unitprice'])
                else:
                    macpricerecs['claim_processor'] = pricesource
                    macpricerecs['rebate_factor'] = rebfactor
                    macpricerecs['unit_price_before_rebate'] = "{0:.5f}".format(
                        macrow.loc[id, 'unitprice'])
                    if rebfactor != '' and pricesource in rebcp:
                        try:
                            macpricerecs['unitprice'] = "{0:.5f}".format(
                                float(macrow.loc[id, 'unitprice']) * float(rebfactor))
                        except Exception as e1:
                            print(4, e1)
                            print('sc', macrow.loc[id, 'unitprice'], rebfactor)
                            macpricerecs['unitprice'] = "{0:.5f}".format(
                                macrow.loc[id, 'unitprice'])
                    else:
                        macpricerecs['unitprice'] = "{0:.5f}".format(
                            macrow.loc[id, 'unitprice'])
                macpricerecs['pricetype'] = 'MAC'
                macpricerecs['maclistid'] = prow['maclistid'].upper()
                macpricerecs['sc_brandorgeneric'] = sc_brand_generic
                macpricerecs['payer_brand_generic'] = payer_brand_generic
                if macpricerecs['unitprice'] == '' or macpricerecs['maclistid'] == '':
                    continue
                currentpricelist[macpricerecs['maclistid']
                                 ] = macpricerecs['unitprice']
                macrecs['cp_price'].append(macpricerecs)
            if not macrecs['cp_price']:
                error = error.append({'gpi': gpi_code, 'gppc': '', 'drug_name': drug_name, 'brand_generic': sc_brand_generic, 'Medispan brand_generic': '',
                                      'old unit_price': '', 'new unit_price': '', 'Status': 'Error', 'Message': 'No Unit Prices Found', 'MACListID': ''}, ignore_index=True)
                continue

            macrecs['create_date'] = currentdate
            macrecs['update_date'] = currentdate
            macrecs['created_by'] = pricesource
            macrecs['updated_by'] = pricesource
            macrecs['type'] = 'cp_drug_price_stg'
            macrecs['file_name'] = file_name
            pricesources = [pricesource]
            if pricesource == 'scriptclaim':
                pricesources.append('sc_walmart')

            tempprice, newprices = [], []
            newprices.extend(macrecs['cp_price'])
            
            for element in currentprices:
                macrecs['cp_price'] = []
                tempprice = []
                macrecs['gppc'] = element['gppc']
                for price in element['cp_price']:
                    if price['pricetype'] == 'MAC' and price['claim_processor'] in pricesources:
                        continue
                    else:
                        tempprice.append(price)
                    try:

                        compareprice = [
                            i for i in oldprices if i['gppc'] == element['gppc']]
                        comparecpprice = [i for i in compareprice[0]['cp_price'] if i['claim_processor']
                                          in pricesources and i['pricetype'] == 'MAC' and i['maclistid'] == price['maclistid']]
                        error = error.append({'gpi': gpi_code, 'gppc': element['gppc'], 'drug_name': drug_name, 'brand_generic': sc_brand_generic, 'Medispan brand_generic': '',
                                              'old unit_price': comparecpprice[0]['unitprice'], 'new unit_price': price['unitprice'], 'Status': '', 'Message': 'Price Comparison', 'MACListID': price['maclistid']}, ignore_index=True)
                    except Exception as e:
                        # print(5,e)
                        pass
                macrecs['cp_price'].extend(newprices)
                macrecs['cp_price'].extend(tempprice)
                if mode.upper() == 'FINAL':
                    macrecs['drug_price_id'] = str(element['id'])
                    cb.upsert(str(macrecs['drug_price_id']), macrecs)
                    error = error.append({'gpi': gpi_code, 'gppc': element['gppc'], 'drug_name': drug_name, 'brand_generic': sc_brand_generic, 'Medispan brand_generic': '',
                                          'old unit_price': '', 'new unit_price': '', 'Status': 'Success', 'Message': '', 'MACListID': ''}, ignore_index=True)

            print(ite)
            
            ite = ite+1
            if not currentprices and mode.upper() == 'FINAL':
                rv1 = cb.counter('docid', delta=1)
                macrecs['drug_price_id'] = str(rv1.value)
                cb.upsert(str(macrecs['drug_price_id']), macrecs)
                error = error.append({'gpi': gpi_code, 'gppc': macrecs['gppc'], 'drug_name': drug_name, 'brand_generic': sc_brand_generic, 'Medispan brand_generic': '',
                                      'old unit_price': '', 'new unit_price': '', 'Status': 'Success', 'Message': '', 'MACListID': ''}, ignore_index=True)
        if len(residual_data) != 0:
            print('cycle 1 done')
            updatepricing('cerpass', residual_data)
            print('cycle 2 done')
        print('validating data')
        error = validatepricing(error)

        error.drop_duplicates(inplace=True)
        error.to_excel(writer, index=False)
        writer.save()

        subject = 'Script Claim Mac Drug Pricing File Processed'
        email_log('DWagle@fliptrx.com', 'SPal@fliptrx.com', 'FliptIntegration@fliptrx.com', subject, [
                  'Processing of Script Claim Mac Drug Pricing File '+file_name+str(currentdate), 'Script Claim Mac Drug Pricing Exception'], err, True)
        if mode.lower() == 'final' and os.path.exists(localpath):
            os.remove(localpath)


def extractawppricing():

    print('extract awp pricing')

    dbname = os.environ['RDS_DBNAME']
    host = os.environ['RDS_SERVER']
    prt = os.environ['RDS_PORT']
    usr = os.environ['RDS_USERID']
    passwd = os.environ['RDS_PWD']

    conn = psycopg2.connect("dbname={} host={} port={} user={} password={}".format(
        dbname, host, prt, usr, passwd))

    cur = conn.cursor()
    command = "create or replace view flipt_awp_price_agg_v as SELECT  GPI, MULTI_SOURCE, ROUND(AVG(UNIT_PRICE), 4)  UNIT_PRICE, DRUG_NAME,STRENGTH ProductStrength, dosage_form DosageFormID, UnitOfMeasure, 'AWP' PriceType, BrandOrGeneric,package_size, P_UOM PackUOM, UnitDose, GPPC, Package_Quantity, null DispensingText, Package_Description_Code,OTCIndicator, Drug_Descriptor_Identifier, Brand_Name_Code,Item_Status_Flag FROM(select UPPER(drug.drug_name) DRUG_NAME, drug.dosage_form, Brand_Name_Code,case drug.brand_name_code  when 'T' then 'Brand' else 'Generic'  end BrandOrGeneric,drug.strength, drug.STRENGTH_UNIT_OF_MEASURE UnitOfMeasure, prc.NDC_UPC_HRI, prc.UNIT_PRICE, ndc.REPACKAGED_CODE, TRIM(MFG.MANUFACTURER_NAME) MFG, trim(package_size/1000) package_size, trim(package_size_uom) P_UOM, trim(package_quantity) package_quantity, trim(unit_dose_unit_use_pkg_code) UnitDose, trim(package_description_code) p_code, ndc.MULTI_SOURCE_CODE MULTI_SOURCE, ndc.NAME_TYPE_CODE, ndc.GENERIC_PRODUCT_PACK_CODE gppc, ndc.DRUG_DESCRIPTOR_ID Drug_Descriptor_Identifier, ndc.RX_RANK_CODE, ndc.DISPENSING_UNIT_CODE, ndc.RX_OTC_INDICATOR_CODE OTCIndicator, trim(DRUG.generic_product_identifier) gpi, ndc.ITEM_STATUS_FLAG, trim(pkg.PACKAGE_DESCRIPTION_CODE)Package_Description_Code from flipt_dw.dw_mf2prc prc join flipt_dw.dw_mf2ndc ndc on trim(prc.NDC_UPC_HRI)=trim(ndc.NDC_UPC_HRI) join flipt_dw.dw_mf2gppc pkg on trim(ndc.GENERIC_PRODUCT_PACK_CODE)=trim(pkg.GENERIC_PRODUCT_PACK_CODE) join flipt_dw.dw_mf2name drug on trim(drug.DRUG_DESCRIPTOR_ID)=trim(ndc.DRUG_DESCRIPTOR_ID) join flipt_dw.dw_mf2lab MFG on TRIM(ndc.MEDISPAN_LABELER_ID)=TRIM(MFG.MEDISPAN_LABELER_ID) left join flipt_dw.dw_mf2gpr pprc on(ndc.GENERIC_PRODUCT_PACK_CODE=pprc.GENERIC_PRODUCT_PACK_CODE and pprc.gppc_price_code=1) where price_code='A' and ndc.item_status_flag='A' and ndc.id_number_format_code in (1, 2, 3, 6) and nvl(trim(clinic_pack_code), 'N')='N' and ndc.REPACKAGED_CODE='') GROUP BY GPI, MULTI_SOURCE, DRUG_NAME, STRENGTH, dosage_form, P_UOM, BrandOrGeneric,package_size, UnitDose, GPPC, Package_Quantity, Package_Description_Code, OTCIndicator,Drug_Descriptor_Identifier, Brand_Name_Code, Item_Status_Flag, UnitOfMeasure"

    cur.execute(command)
    conn.commit()
    cur.execute("Select GPI,MULTI_SOURCE, UNIT_PRICE/1000000 UNIT_PRICE, DRUG_NAME, '' ProductNameFull, ProductStrength,DosageFormID,UnitOfMeasure,PriceType, BrandOrGeneric, package_size,PackUOM, UnitDose, GPPC, Package_Quantity,DispensingText, Package_Description_Code, OTCIndicator,Drug_Descriptor_Identifier,Brand_Name_Code,Item_Status_Flag from flipt_awp_price_agg_v")
    try:
        rows = cur.fetchall()

        conn.commit()
    except:
        print('No data found')
        pass
    if not rows:
        print('No data found')
        sys.exit()
    print('extract awp pricing done')

    from utils.autofile_transfer import singlefiletransfer
    awpprice = pd.DataFrame(data=rows)
    # print(awpprice.head())

    rename_columns = {0: "GPICode", 1: "MultiSourceCode", 2: "UnitPrice", 3: "ProductNameAbr", 4: "ProductNameFull", 5: "ProductStrength", 6: "DosageFormID", 7: "UnitOfMeasure", 8: "PriceType", 9: "BrandOrGeneric", 10: "PackSize",
                      11: "PackUOM", 12: "UnitDose", 13: "GPPC", 14: "Package_Quantity", 15: "DispensingText", 16: "Package_Description_Code", 17: "OTCIndicator", 18: "Drug_Descriptor_Identifier", 19: "Brand_Name_Code", 20: "Item_Status_Flag"}
    awpprice.rename(columns=rename_columns, inplace=True)
    currentdata = datetime.strftime(datetime.now(), '%m%d%Y')
    # print(awpprice.head())
    filename = 'FLIPT_AWP_PRICE_' + currentdata + '.txt'

    if mode.lower() == 'final':
        awpprice.to_csv(filename, header='	'.join(
            x for x in list(awpprice)), index=None, sep=' ', mode='a')
        status = singlefiletransfer(filename, '/local/', mode)
        os.remove(filename)

        if status != 'S':
            sys.exit()

    return awpprice, filename


def updateoldpricing(pricesource):

    pricesources = [pricesource]
    if pricesource == 'scriptclaim':
        pricesources.append('sc_walmart')
    if 'awp' in file_name:
        outerquery = N1QLQuery('Select distinct drug_name,gpi from `' +
                               os.environ['CB_INSTANCE'] + '` where type="cp_drug_price"')
        for outerresult in cb.n1ql_query(outerquery):
            prices = []
            innerquery = N1QLQuery('Select * from `' +
                                   os.environ['CB_INSTANCE'] + '` where type="cp_drug_price" and drug_name=$dn and gpi=$gpi', dn=outerresult['drug_name'], gpi=outerresult['gpi'])
            oldresult = {}
            for innerresult in cb.n1ql_query(innerquery):
                oldresult = innerresult[os.environ['CB_INSTANCE']]
                if isinstance(oldresult['cp_price'], list):
                    prices.extend(oldresult['cp_price'])
                elif isinstance(oldresult['cp_price'], dict):
                    prices.append(oldresult['cp_price'])
            new_record_found = False
            innerquery = N1QLQuery('Select cp_price,meta().id from `' +
                                   os.environ['CB_INSTANCE'] + '` where type="cp_drug_price_stg" and drug_name=$dn and gpi=$gpi', dn=outerresult['drug_name'], gpi=outerresult['gpi'])
            for innerresult in cb.n1ql_query(innerquery):
                new_record_found = True
                stg_prices_df = pd.DataFrame(data=innerresult['cp_price'])
                stg_prices = innerresult['cp_price']
                for price in prices:
                    if price['pricetype'] != 'AWP' and not ((stg_prices_df['claim_processor'] == price['claim_processor']) & (stg_prices_df['maclistid'] == price['maclistid'])).any():
                        stg_prices.append(price)
                cb.mutate_in(innerresult['id'], SD.upsert(
                    'cp_price', stg_prices))
            if not new_record_found:
                prices_stg = [pr for pr in prices if pr['pricetype'] != 'AWP']
                if len(prices_stg) > 0:
                    oldresult['cp_price'] = prices_stg
                    oldresult['type'] = 'cp_drug_price_stg'
                    if mode.upper() == 'FINAL':
                        oldresult['drug_price_id'] = str(
                            cb.counter('docid', delta=1).value)
                        cb.upsert(oldresult['drug_price_id'], oldresult)
        return

    if 'mac' in file_name:
        outerquery = N1QLQuery('Select b.cp_price,meta(b).id id from `' +
                               os.environ['CB_INSTANCE'] + '` b unnest b.cp_price cp where b.type="cp_drug_price_stg" and  cp.pricetype="MAC" and cp.claim_processor=$cp', cp=pricesource)
        for outerresult in cb.n1ql_query(outerquery):
            pricing = outerresult['cp_price']
            new_pricing = [price for price in pricing if (price['claim_processor']
                                                          not in pricesources and price['pricetype'] == 'MAC') or (price['pricetype'] == 'AWP')]
            if len(new_pricing) > 0:
                outerresult['cp_price'] = new_pricing
                cb.mutate_in(outerresult['id'], SD.upsert(
                    'cp_price', new_pricing))
            elif len(new_pricing) == 0:
                cb.remove(outerresult['id'], quiet=True)


def validatepricing(error):

    # AWP count compare
    query = N1QLQuery('select count(distinct b.drug_descriptor_identifier) count from `' +
                      os.environ['CB_INSTANCE'] + '` b unnest b.cp_price cp where b.type="cp_drug_price" and cp.pricetype="AWP"')
    oldcount = 0
    for result in cb.n1ql_query(query):
        oldcount = result['count']
    query = N1QLQuery('select count(distinct b.drug_descriptor_identifier) count from `' +
                      os.environ['CB_INSTANCE'] + '` b unnest b.cp_price cp where b.type="cp_drug_price_stg" and cp.pricetype="AWP"')
    newcount = 0
    for result in cb.n1ql_query(query):
        newcount = result['count']
    message = "Old AWP Count:" + \
        str(oldcount) + ", New AWP Count:" + str(newcount)

    error = error.append({'gpi': '', 'gppc': '', 'drug_name': '', 'brand_generic': '', 'Medispan brand_generic': '',
                          'old unit_price': '', 'new unit_price': '', 'Status': 'Validation', 'Message': message, 'MACListID': ''}, ignore_index=True)

    # MAC count compare
    query = N1QLQuery('select count(distinct b.drug_descriptor_identifier) count from `' +
                      os.environ['CB_INSTANCE'] + '` b unnest b.cp_price cp where b.type="cp_drug_price" and cp.pricetype="MAC"')
    oldcount = 0
    for result in cb.n1ql_query(query):
        oldcount = result['count']
    query = N1QLQuery('select count(distinct b.drug_descriptor_identifier) count from `' +
                      os.environ['CB_INSTANCE'] + '` b unnest b.cp_price cp where b.type="cp_drug_price_stg" and cp.pricetype="MAC"')
    newcount = 0
    for result in cb.n1ql_query(query):
        newcount = result['count']
    message = "Old MAC Count:"+str(oldcount)+", New MAC Count:"+str(newcount)

    error = error.append({'gpi': '', 'gppc': '', 'drug_name': '', 'brand_generic': '', 'Medispan brand_generic': '',
                          'old unit_price': '', 'new unit_price': '', 'Status': 'Validation', 'Message': message, 'MACListID': ''}, ignore_index=True)

    # Duplicate Check
    query = N1QLQuery('select count(*) count,drug_descriptor_identifier from `' +
                      os.environ['CB_INSTANCE'] + '` where type="cp_drug_price_stg" group by drug_descriptor_identifier,gpi,drug_name,gppc having count(*)>1')
    for result in cb.n1ql_query(query):
        count = result['count']
        message = str(count)+" Duplicate Records Found for DDID:" + \
            str(result['drug_descriptor_identifier'])
        error = error.append({'gpi': '', 'gppc': '', 'drug_name': '', 'brand_generic': '', 'Medispan brand_generic': '',
                              'old unit_price': '', 'new unit_price': '', 'Status': 'Validation', 'Message': message, 'MACListID': ''}, ignore_index=True)
    return error


def getbrandgenericdefinition():

    bg_def = {}

    query = N1QLQuery('select claim_processor,payer_generic_def from `' +
                      os.environ['CB_INSTANCE'] + '` where type="claim_processor"')
    for result in cb.n1ql_query(query):
        query_condition = ''
        if result.get('payer_generic_def', {}):
            for key, value in result['payer_generic_def'].items():
                query_condition = query_condition + \
                    ' and ' + str(key) + '="' + str(value)+'"'
        bg_def.update({result['claim_processor']: {
                      'payer_generic_def': result['payer_generic_def'], 'query_condition': query_condition}})

    return bg_def


def sendpricingalert():

    brandtogeneric = {'G': 'Generic', 'T': 'Brand', 'B': 'Brand'}
    pricing_report = pd.DataFrame()

    query = N1QLQuery("select drug_name,gpi,strengths, dosage, brand_generic, otc_indicator,multi_source from `" +
                      os.environ['CB_INSTANCE'] + "` where type='drug' and otc_indicator='R'")
    query.timeout = 10000
    for result in cb.n1ql_query(query):
        brandgeneric = brandtogeneric[result['brand_generic']]
        pricefound = False
        drugpricequery = N1QLQuery("select drug_descriptor_identifier,cp_price from `" +
                                   os.environ['CB_INSTANCE'] + "` where type='cp_drug_price_stg' and gpi=$gpi and drug_name=$dn and brandorgeneric=$bg limit 1", gpi=result['gpi'], dn=result['drug_name'], bg=brandgeneric)
        for priceresult in cb.n1ql_query(drugpricequery):
            if priceresult.get('cp_price', []):
                try:
                    unitprice = float(priceresult['cp_price'][0]['unitprice'])
                    pricefound = True
                except:
                    pass
        if not pricefound:
            pricing_report = pricing_report.append(result, ignore_index=True)

    sender = 'noreply@fliptrx.com'
    receiver = ['fliptintegration@fliptrx.com', None]
    if os.environ['INSTANCE_TYPE'] == 'PROD':
        receiver = ['pricing@fliptrx.com', 'clinical@fliptrx.com']
    pricing_report_path = path + '/GWLABS001/cp_drug_price/log/Price_Does_Not_Exist.csv'

    if len(pricing_report) > 0:
        subject = 'Missing Pricing Alert'
        body = 'Team,<br><br> The Pricing Data has been refreshed. Please find attachment listing the drugs without pricing details. <br><br>Best regards,<br><strong>FLIPT Integration Team</strong'
        pricing_report.to_csv(pricing_report_path, index=False)
        email_log_custombody(sender, receiver[0], receiver[1], subject,
                             body, file_path=pricing_report_path, attached=True)


claimprocessorpricing()
sendpricingalert()
