########################################
# !/usr/bin/env python
# title         : rxplanupdate.py
# description   : Update rxplan document from file data
# author        : Disha
# date created  : 20180101
# date last modified    : 20190118 12:16
# version       : 0.1
# maintainer    : hari
# email         : hrajendran@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage         : python rxplanupdate.py -d GWLABS001 -t rxplan_master -f rxplan_master01022018.xlsx -m DRAFT
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  1.1            hari         01182019    Added log file, mode support logic to load the data in database
#  1.2            Deepthi      04302019    Added query to check if the row already exists for that planname  and year
#  1.3            Rajesh       03032020    Fix the issue for plan_coverage_days and plan_coverage_per_drug
# #######################################
def rxplan(cb_handle, log_hndlr, cmdline_rec, file_compare):
    import pandas as pd
    from couchbase import FMT_JSON
    from couchbase.n1ql import N1QLQuery

    doc_count = 0
    rx_file = f"{path}/{cmdline_rec['domain']}/{cmdline_rec['file_type']}/{cmdline_rec['file_name']}"

    rx_frame = pd.read_excel(rx_file)
    log_hndlr.info("No of records in File " + str(rx_frame.shape[0]))

    for idx, row in rx_frame.iterrows():
        metaid = ''
        rx_data = populate_dict(rx_frame, row)

        try:
           rx_data['plan_coverage_days'] = int(rx_data['plan_coverage_days'])
        except ValueError:
           rx_data['plan_coverage_days'] = ''
        except KeyError:
           pass

        try:
           rx_data['plan_coverage_per_drug'] = int(rx_data['plan_coverage_per_drug'])
        except ValueError:
           rx_data['plan_coverage_per_drug'] = ''
        except KeyError:
           pass

        try:
           rx_data['transfer_bin'] = int(rx_data['transfer_bin'])
        except ValueError:
           rx_data['transfer_bin'] = ''
        except KeyError:
           pass

        try:
           rx_data['transfer_pcn'] = int(rx_data['transfer_pcn'])
        except ValueError:
           rx_data['transfer_pcn'] = ''
        except KeyError:
           pass


        rx_data['type'] = 'rxplan_master'
        log_hndlr.info(rx_data)
        doc_count += 1
        query = N1QLQuery('SELECT META().id as id, * FROM `' + os.environ['CB_INSTANCE'] +
                          '` WHERE type="rxplan_master" ' +
                          'and domain_name=$dname ' +
                          'and plan_name=$pname ' +
                          'and plan_year=$pyr',
                          dname=cmdline_rec['domain'],
                          pname=rx_data['plan_name'],
                          pyr=rx_data['plan_year'])
        query.timeout = 7200

        create_date = None
        for res in cb_handle.n1ql_query(query):
            record = res[os.environ['CB_INSTANCE']]
            metaid = res['id']
            create_date = record['create_date']
            # print('InLoop',metaid)

        file_compare.append(record, 'pre')
        if create_date is not None:
            rx_data['create_date'] = create_date

        file_compare.append(rx_data, 'post')
        rx_data['update_date'] = str(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

        if cmdline_rec['mode'].upper().strip() == 'FINAL':
            if metaid != '':
                rx_data['update_date'] = str(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                cb_handle.upsert(str(metaid), rx_data, format=FMT_JSON)
            else:
                rx_data['create_date'] = str(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                cb_handle.upsert(str(cb_handle.counter('docid', delta=1).value),
                                 rx_data, format=FMT_JSON)
    return doc_count
# end function


if __name__ == "__main__":
    import os
    from datetime import datetime
    from utils.helper_functions import *
    from utils.file_comp_log import FileComp

    path = os.environ['CB_DATA']
    cmd_line_args = process_cmdline()
    cb = cb_authenticate()
    local_path = f"{path}/"
    file_comp = FileComp(local_path, cmd_line_args['domain'], cmd_line_args['file_type'])

    # add log file
    logpath = "rxplan_master_log" + datetime.now().strftime("%Y%m%d%H%M")
    logfile = setup_logging_path('RXPLAN_MASTER', logpath, 'RXPLANMASTER')
    logfile.info("="*70)
    logfile.info("=============== rxplan document Update Log =================")

    logfile.info("Start time is " + str(datetime.now()))
    total_records_update = rxplan(cb, logfile, cmd_line_args, file_comp)

    file_comp.write('pre')
    file_comp.write('post')
    if (file_comp.compare_files() is True):
        print(f"Compare file: {file_comp.comp_file}" + "\n\n")

    logfile.info('%s records are updated \r\n' % total_records_update)
    logfile.info("End time is " + str(datetime.now()) + "\r\n")
    logfile.info("="*70)
    print("\nDone")
# end function
