########################################
# !/usr/bin/env python 
# title : coveragetierupdate.py
# description : Update coverage tier mapping update
# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  python coveragetierupdate.py -d GWLABS001 -t coverage_tier -f coverage_tier.xlsx -m DRAFT
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------
# #######################################

import socket
from datetime import datetime
import os
import codecs
import sys

import pandas as pd
from couchbase.n1ql import N1QLQuery
from couchbase import FMT_JSON
from utils.helper_functions import *
from utils.sendgridemail import email_log

cmdline_rec =process_cmdline()

cb = cb_authenticate()
path = os.environ['CB_DATA']

# modified by Hari on 27/12/2018
# path = os.environ['CB_DATA']
host = socket.gethostname()
currentdate = datetime.now()
currentdate = currentdate.strftime("%m%d%y%H%M%S")
logger = setup_logging_path('COVERAGE_TIER', f"coverage_tier_{currentdate}", 'COVERAGETIER')


def coverage_tier_plan():

        coverage_tier_file = f"{path}/{cmdline_rec['domain']}/{cmdline_rec['file_type']}/{cmdline_rec['file_name']}"
        logger.info(f"Processing coverage update file for: {cmdline_rec['domain']}")
        logger.info(f"\tCoverage file: {coverage_tier_file}")
        try:
          rx = pd.read_excel(coverage_tier_file)
        except FileNotFoundError:
          print("Unable to find and open requested file: " + coverage_tier_file)
          sys.exit(-1)

        ite = 0
        data_validation = {
                "records_added": 0,
                "records_updated": 0
        }
        for i, r in rx.iterrows():
                metaid = ''
                create_date = ''
                query = N1QLQuery('SELECT META().id as id, create_date FROM `' + os.environ['CB_INSTANCE'] +
                                  '` WHERE type="coverage_tier" ' +
                                  'and domain_name=$dname ' +
                                  'and employee_interface=$e_interface ',
                                  dname=cmdline_rec['domain'],
                                  e_interface=r['employee_interface'])
                query.timeout = 7200

                create_date = None
                for p in cb.n1ql_query(query):
                        metaid = p['id']
                        try:
                            create_date = p['create_date']
                        except KeyError:
                            create_date = str(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                        # print('InLoop',metaid)

                d = populate_dict(rx, r)
                d['type'] = 'coverage_tier'
                d['update_date'] = str(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

                logger.info(f"Excel row: {r}")
                logger.info(f"New change: {d}")

                # modified by Hari  on 27/12/2018
                if cmdline_rec['mode'].strip().upper() == 'FINAL':
                   if metaid != '':
                      cb.upsert(metaid, d, format=FMT_JSON)
                      data_validation['records_updated'] += 1
                   else:
                      d['create_date'] = str(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                      cb.upsert(str(cb.counter('docid',delta=1).value),d, format=FMT_JSON)
                      data_validation['records_added'] += 1
                else:
                   logger.info("Mock update completes")
                   if metaid != '':
                      data_validation['records_updated'] += 1
                   else:
                      data_validation['records_added'] += 1
                ite += 1
        logger.info("-"*50)
        logger.info(f'Validation counts')
        for i in data_validation.keys():
           logger.info(f"{i.replace('_', ' ')}: {data_validation[i]}")

        # added by Hari on 27/12/2018
        if cmdline_rec['mode'].strip().upper() == 'DRAFT':
                logger.info('coverage tier update - Draft Mode :' + host + cmdline_rec['file_name'])
                subject = 'coverage tier update - Draft Mode :' + host
        else:
                logger.info('coverage tier update - Final Mode :' + host + cmdline_rec['file_name'])
                subject = 'coverage tier update - Final Mode :' + host

        email_log('DWagle@GWLabs.com','FliptIntegration@fliptrx.com', None,
                  subject, ['coverage tier update File ' + logger.handlers[0].baseFilename,
                           'coverage tier update Exception'], logger.handlers[0].baseFilename, True)
# end function


coverage_tier_plan()
