########################################
# !/usr/bin/env python  
# title         : rxplan_validation.py
# description   : Get list of plans and plan availability
# author        : Disha
# date created  : 20180101
# date last modified    : 20190118 12:16
# version       : 0.1
# maintainer    : Pal
# email         : pmuthanai@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage         : 
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  0.1							20190118	Added header
# #######################################

import pandas as pd
import os
from datetime import datetime

#get list of plans according to domain (dn) and plan year (yr)
def getplans(cb_hndl, dn, yr=None):
        from couchbase.n1ql import N1QLQuery

        bucket_name = os.environ['CB_INSTANCE']
        df = pd.DataFrame()
        qry_str = 'SELECT plan_name, plan_start_date, plan_end_date, plan_year, domain_name FROM `' + bucket_name +\
                          '` WHERE type="rxplan_master" and domain_name in $domain '

        if yr is not None:
            if '-' in yr:
                plan_list = yr.split('-')
            else:
                plan_list = [yr]

            qry_str += "and plan_year in $planlist"
            
        query = N1QLQuery(qry_str, domain=dn, planlist=plan_list)
        query.adhoc = False
        #query.timeout=7200

        for r in cb_hndl.n1ql_query(query): 		
            df = df.append(r, ignore_index=True)
        
        return df
# end function


#check if parameter "plan" is present in the list of plans "records"
def validate(records, plan):

    pn = None
    plan = plan.upper()

    for i, r in records.iterrows():
        if plan.strip() in r['plan_name'].upper().strip() or r['plan_name'].upper().strip() in plan.strip():
            if pn is None:
                pn = r['plan_name']
    if pn is None:
        return 'Error'

    return pn
# end function

