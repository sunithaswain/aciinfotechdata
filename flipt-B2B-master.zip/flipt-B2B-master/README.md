# flipt-B2B

1.Create new folder

2.Open the cmd prompt and clone repositiry in where you want the location by

    git clone https://github.com/FliptRx/flipt-B2B.git


3.Open flipt-B2B folder

    All programs available inside flipt-B2B folder 


4.Next need to download data file with folder structure by

    4.1 Open WinSCP tool(recommanded)

    4.2 Login AWS Dev with your credential

    4.3 Download FLIPTB2B full folder under /home/fliptrxadmin/ 

    4.4 Please ensure all  the Envirnoment Varible assigned in your current system
        else refer /home/fliptrxadmin/FLIPT_DEV.env from AWS Dev 


5.Install anaconda refer https://docs.anaconda.com/anaconda/install/windows/


6.Install some extra neccesery packages in cmd by
    
    "pip install PyPDF2
    pip install passwordgen
    pip install zipcode==2.0
    pip install rollbar
    pip install exponent_server_sdk
    pip install fpdf
    pip install psycopg2
    pip install geocoder"
    

7.To run any programs

    7.1. open folder where you want to run program available (eg: aetna)

         Inside each .py file, header(in code starting) having executable cmd in line starts with "Usage" keyword

    7.2. in cmd

        change directory to the folder(eg:aetna) containing the program which we want to run and 

        run command as below

        eg: python aetnadeductibleupdate.py -d GWLABS001 -t deductible -f GW_LABORATORIES_12012018.xlsx -m DRAFT -s 01-DEC-2018

                or

            to run in background

            nohup python aetnadeductibleupdate.py -d GWLABS001 -t deductible -f GW_LABORATORIES_12012018.xlsx -m DRAFT -s 01-DEC-2018 > Fliptaetna192019.log 2> Fliptaetna192019.err < /dev/null &

now program will be run successfully.

In case you are getting error regards 

1.Environment variable 

    1.1 please check updated environment variable values.

2.If input file missing error,

    2.1 please ensure those input file available under FLIPTB2B/data with as per required folder structure.


After program run successful.

 please check log file is created in corresponding folder under FLIPTB2B/data/..

Note: Most of programs will generate log file

