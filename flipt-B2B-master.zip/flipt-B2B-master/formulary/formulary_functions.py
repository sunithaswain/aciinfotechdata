import sys
import pandas as pd
from numpy import nan
from couchbase.n1ql import N1QLQuery
from utils.helper_functions import *
from datetime import datetime


def fetch_df(pattern, in_dict):
    filelist = in_dict['xlsx']
    for fname in filelist.keys():
        if pattern in fname:
            return filelist[fname]
# end function


def retrieve_file(sftp_hndl, file_path, srch_str, loghandle=None):

    stat, load_filename = sftp_hndl.sftptransfer(None, file_path + '/', 'GET', searchstr=srch_str,
                                                          loghndl=loghandle)
    if stat == 'E':
        display_error(f'Auxilary file: *{srch_str}_* not found on SFTP server', loghndl=loghandle)

    return load_filename
# end function


def load_groupcond_document(cb_handle, domain_nm=None, log_hndl=None):
    import os
    # load drug database

    if log_hndl is not None:
        log_hndl.info(f"Loading {os.environ['INSTANCE_TYPE']} - drug_group information ...")

    print(f"Loading {os.environ['INSTANCE_TYPE']} - drug_group database rows ...",
          end='', flush=True)
    query_stmt = 'SELECT distinct domain, plan_name, group_condition, group_number FROM `' +\
                      os.environ['CB_INSTANCE'] + '` where type="drug_group" '

    if domain_nm is not None:
        query_stmt += f"and domain='{domain_nm}' "

    query = N1QLQuery(query_stmt)
    query.timeout = 7200
    temp_df = pd.DataFrame()
    groups_list = []

    for row in cb_handle.n1ql_query(query):
        groups_list.append(row)

    if len(groups_list) != 0:
        temp_df = temp_df.append(groups_list, ignore_index=True)
        del groups_list
    else:
        print("Done\n")
        return None

    if log_hndl is not None:
        log_hndl.info(f"Done loading drug_group db. Num recs: {temp_df.size}")
    print("Done\n")

    return temp_df
# end function


def load_drugdocument(cb_handle, log_hndl=None):
    # load drug database
    import os

    if log_hndl is not None:
        log_hndl.info(f"Loading {os.environ['INSTANCE_TYPE']} - drugdb information ...")

    print(f"Loading {os.environ['INSTANCE_TYPE']} - drug database rows ...",
          end='', flush=True)
    query = N1QLQuery('SELECT distinct brand_generic, ddid, gpi, drug_name FROM `' +
                      os.environ['CB_INSTANCE'] + '` where type="drug" ' +
                      'order by gpi asc')
    query.timeout = 7200
    drugdb_df = pd.DataFrame()
    drugsdb_list = []

    for row in cb_handle.n1ql_query(query):
        drugsdb_list.append(row)

    drugdb_df = drugdb_df.append(drugsdb_list, ignore_index=True)
    drugdb_df['gpi'] = drugdb_df['gpi'].apply(lambda x: str(x).zfill(14))
    drugdb_df['brand_generic'] = drugdb_df['brand_generic'].apply(lambda x: brandgen_val(str(x).strip()))
    del drugsdb_list

    if log_hndl is not None:
        log_hndl.info(f"Done loading drug db. Num recs: {drugdb_df.size}")
    print("Done\n")

    return drugdb_df
# end function


def fix_headers(in_df):
    """
    Fixes the headers of the DataFrame by converting them to lower-case and
    replacing the ' ' with '_'.  also any columns conating the gpi info is
    left-padded with zero for length of 14 chars
    :param in_df:
    :return: altered DF
    """
    changedcols = populate_dict2(in_df)
    in_df.rename(columns=changedcols, inplace=True)
    in_df['gpi'] = in_df['gpi'].apply(lambda x: str(x).zfill(14))
    return in_df
# end function


def load_data_files(log_hndl, infile_list, procrecs=None):
    out_dict = {'csv': None,
                'xlsx': dict()}

    for fname in infile_list:
        log_hndl.info(f"Loading data from file: {fname} ...")
        print(f"loading file details from: {fname} ... ", end='', flush=True)
        if '.csv' in fname:
            try:
                tempdf = pd.read_csv(fname, sep=';', quotechar="'")
            except FileNotFoundError:
                log_hndl.info(f"Could not find required datafile: {fname}.")
                sys.exit(1)
        else:
            try:
                tempdf = pd.read_excel(fname)
            except FileNotFoundError:
                log_hndl.info(f"Could not find required datafile: {fname}.")
                sys.exit(1)

        changedcols = populate_dict2(tempdf)
        tempdf.rename(columns=changedcols, inplace=True)

        if procrecs is not None:
            if '_formulary_' in fname:
                tempdf = tempdf.head(int(procrecs))
                print(f"processing only <{procrecs}> records from formulary file")
                log_hndl.info(f"processing only <{procrecs}> records from formulary file")

        print("Done.\n")
        log_hndl.info(f"loading done. Number of entries: {tempdf.shape}")

        if '.csv' in fname:
            out_dict['csv'] = tempdf
        else:
            out_dict['xlsx'][fname] = tempdf

    return out_dict
# end function


def load_lookups(log_hndl, fname, sheetname):
    """
    Load all supporting excel data files that will be used for lookups
    :param log_hndl:
    :param fname:
    :param sheetname:
    :return: loaded DataFrame containing details from the excel file
    """

    try:
        log_hndl.info(f"Reading sheet [{sheetname}] from: {fname}")
        print(f"Reading sheet: [{sheetname}] from {fname} ... ", end="", flush=True)
        tempdf = fix_headers(pd.read_excel(f'{fname}', sheet_name=sheetname))
    except Exception as e:
        print("Error occured!!\n")
        log_hndl.info("Unable to load required sheet.  Aborting.")
        sys.exit(1)

    print("Done\n")
    return tempdf
# end function


def populate_additional_ql_values(quantitylim_df, grp_row, update_dict):
    """
    populate values for actual QL, DOS limit, and fill/year limit
    :param quantitylim_df:
    :param grp_row:
    :param update_dict:
    :param update:
    :return: update_dict with new values
    """
    if quantitylim_df is not None:
        if ((grp_row['gpi'].lower() == quantitylim_df['gpi']) &
            (grp_row['brand_generic'] == quantitylim_df['brand_generic']) &
            (grp_row['ddid'] == quantitylim_df['ddid'])).any() == True:
            ql_detail_row = quantitylim_df.loc[((grp_row['gpi'] == quantitylim_df['gpi']) &
                                                (grp_row['brand_generic'] == quantitylim_df['brand_generic']) &
                                                (grp_row['ddid'] == quantitylim_df['ddid']))]

    # retrieve new values
    try:
        update_dict['ql_ratio'] = ql_detail_row['ql_ratio'].values[0]
    except KeyError:
        pass
    except UnboundLocalError:
        pass

    try:
        update_dict['dos_limit'] = ql_detail_row['dos_limit'].values[0]
    except KeyError:
        update_dict['dos_limit'] = ''
    except UnboundLocalError:
        update_dict['dos_limit'] = ''

    try:
        update_dict['fill_per_year_limit'] = ql_detail_row['fill_per_year_limit'].values[0]
    except KeyError:
        update_dict['fill_per_year_limit'] = ''
    except UnboundLocalError:
        update_dict['fill_per_year_limit'] = ''
    return update_dict
# end function


def populate_qldetails(grp_row, update_dict, update=None):
    """
    Populate the update_dict with information from the group DF (dataFrame)
    :param grp_row:
    :param update_dict:
    :return: update_dict with keys added
    """
    if update is None:
        if grp_row['ql_ratio'] == 'na':
            update_dict['ql_ratio'] = '-'
        else:
            update_dict['ql_ratio'] = str(float(grp_row['ql_ratio']))

        update_dict['ql_per_period'] = '-'
        update_dict['ql_period'] = '-'
        update_dict['ratio'] = '-'
    else:
        try:
            update_dict['ql_ratio'] = float(grp_row['ql_ratio'])
        except KeyError:
            update_dict['ql_ratio'] = 0

        update_dict['ql_per_period'] = '-'
        update_dict['ql_period'] = '-'

        try:
            update_dict['ratio'] = float(grp_row['ratio'])
        except KeyError:
            update_dict['ratio'] = '-'
    return update_dict
# end function


def populate_padetails(grp_row, update_dict, rec=None, update=None):
    """
    Populate the update_dict with information from the rec if it is a DF
    if the value in the DF is null/nan, use 'N' or ''
    :param grp_row:
    :param update_dict:
    :param rec:
    :param update:
    :return: populated update_dict (save information)
    """
    update_dict['pa_flag'] = grp_row['pa_flag']
    if isinstance(rec, pd.DataFrame):
        if update is None:
            try:
                update_dict['pa_clinical'] = rec['clinical'].values[0]
            except KeyError:
                update_dict['pa_clinical'] = 'N'

            update_dict['pa_abuse_misuse'] = rec['abuse_misuse'].values[0]
            update_dict['pa_age'] = rec['age'].values[0]
            update_dict['pa_gender'] = rec['gender'].values[0]

            if rec['quantity'].empty:
                update_dict['pa_quantity'] = 'N'
            else:
                update_dict['pa_quantity'] = rec['quantity'].values[0]

            if rec['cost'].empty:
                update_dict['pa_cost'] = 'N'
            else:
                update_dict['pa_cost'] = rec['cost'].values[0]

            if rec['pa_form'].empty:
                update_dict['pa_form'] = ''
            else:
                update_dict['pa_form'] = rec['pa_form'].values[0]

            if rec['pa_reason'].empty:
                update_dict['pa_reason'] = ''
            else:
                update_dict['pa_reason'] = rec['pa_reason'].values[0]
        else:
            paform_cols = {'clinical': 'pa_clinical', 'pa_reason': 'pa_reason',
                           'abuse_misuse': 'pa_abuse_misuse', 'age': 'pa_age',
                           'gender': 'pa_gender', 'quantity': 'pa_quantity',
                           'cost': 'pa_cost', 'pa_form': 'pa_form'}

            for col in paform_cols.keys():
                val = paform_cols[col]
                try:
                    update_dict[val] = rec[col].values[0]
                except KeyError:
                    if col in ('pa_reason', 'pa_form', 'clinical'):
                        try:
                            update_dict[val] = rec[col].values[0]
                        except KeyError:
                            update_dict[val] = 'N'
                    else:
                       update_dict[val] = 'N'
            # end for-loop
        # end else
    else:
        update_dict['pa_form'] = ''
        update_dict['pa_flag'] = 'N'
        update_dict['pa_override'] = 'N'
        update_dict['pa_reason'] = ''
        update_dict['pa_clinical'] = 'N'
        update_dict['pa_abuse_misuse'] = 'N'
        update_dict['pa_age'] = 'N'
        update_dict['pa_gender'] = 'N'
        update_dict['pa_quantity'] = 'N'
        update_dict['pa_cost'] = 'N'

    if (update_dict['pa_clinical'] == 'Y' or update_dict['pa_abuse_misuse'] == 'Y' or
        update_dict['pa_gender'] == 'Y' or update_dict['pa_quantity'] == 'Y' or
        update_dict['pa_cost'] == 'Y' or update_dict['pa_age'] != 'N'):
            update_dict['pa_flag'] = 'Y'

    if update_dict['pa_flag'] == 'Y':
        update_dict['pa_override'] = 'Y'
    else:
        update_dict['pa_override'] = 'N'

    if update_dict['pa_flag'] != 'Y' and (grp_row['ql_ratio'] != 0.0 or
                                          grp_row['ql_ratio'] != 0):
        update_dict['pa_reason'] = "PA is required for your safety. " + \
                              "Your plans has set quantity limits " + \
                              "on how much you can fill during a specific time period."

    return update_dict
# end function


def remove_old_plandetails(cmpny, grp_row, company_list, data_validate,
                           planyear=None, planname=None,
                           by_type='year'):
    """
    Removes old plan detail for a domain/company from the company_formulary details
    for the specified planyear.
    WARNING: removes all plan types for the specific domain
    :param cmpny:
    :param company_list:
    :param planyear:
    :return: list without the specific company and plan year.
    """
    new_company_list = []
    for row_rec in company_list:
        if cmpny in row_rec['company']:
            if by_type.upper() == 'YEAR':
                if (planyear is not None and planyear in row_rec['plan_year']):
                    data_validate['Records_being_removed'] += 1
                    data_validate['Records_removed'].append((grp_row['gpi'],
                                                             grp_row['brand_generic'],
                                                             row_rec['plan_year']))
                    continue
                else:
                    new_company_list.append(row_rec)
            elif by_type.upper() == 'PLANNAME':
                if (planname is not None and planname in row_rec['plan_name']):
                    data_validate['Records_being_removed'] += 1
                    data_validate['Records_removed'].append((grp_row['gpi'],
                                                             grp_row['brand_generic'],
                                                             row_rec['plan_name']))
                    continue
                else:
                    new_company_list.append(row_rec)

            else:  # by_type = both year and name
                if ((planyear is not None and planyear in row_rec['plan_year']) and
                        (planname is not None and planname in row_rec['plan_name'])):
                    data_validate['Records_being_removed'] += 1
                    data_validate['Records_removed'].append((grp_row['gpi'],
                                                             grp_row['brand_generic'],
                                                             row_rec['plan_name']))
                    continue
                else:
                    new_company_list.append(row_rec)
        else:
            new_company_list.append(row_rec)
    # end loop
    return new_company_list, data_validate
# end function


def company_exists(cmpny, company_list, planyear=None, planname=None, by_type='year'):
    """
    Checks is the current company exists in the embedded company formulary.
    if it is, then checks if the planyear is present. 'Add' if not present,
    otherwise 'Edit'
    :param cmpny:
    :param company_list:
    :return: 'ADD' or 'EDIT'
    """
    for row_rec in company_list:
        if cmpny in row_rec['company']:
            if by_type.upper() == 'YEAR':
                if (planyear is not None and planyear in row_rec['plan_year']):
                    return 'EDIT'

            elif by_type.upper() == 'PLANNAME':
                if (planname is not None and planname in row_rec['plan_name']):
                    return 'EDIT'

            else:  # by_type = both year and name
                if ((planyear is not None and planyear in row_rec['plan_year']) and
                    (planname is not None and planname in row_rec['plan_name'])):
                    return 'EDIT'

    return 'ADD'
# end function


def populate_companydetails(plan_details, grp_row, altbaseline_val,
                            drug_notcovered_df, data_validate,
                            mode='ADD', presentrec=None, update=None,
                            planname=None):
    """
    Populate the company details from the plan details and the mode
    :param plan_details:
    :param grp_row:
    :param altbaseline_val:
    :param drug_not_covered_df
    :param data_validate - for tracking counts
    :param mode:
    :param presentrec:
    :param update:
    :return: update company details list of dictionaries
    """
    company_formulary = []
    savedict_cols = ['ql_ratio', 'ql_per_period', 'ql_period', 'ratio',
                     'pa_flag', 'pa_form', 'pa_override', 'pa_reason',
                     'pa_clinical', 'pa_abuse_misuse', 'pa_age', 'pa_gender',
                     'pa_quantity', 'pa_cost', 'group_number', 'dos_limit',
                     'fill_per_year_limit']

    grp_columns = ['copay_type', 'copay_30daysupply', 'copay_60daysupply', 'copay_90daysupply',
                   'copayabove90daysupply', 'co_ins_min_amount', 'co_ins_max_amount', 'deductibleexempted',
                   'mo_co_ins_min_amount', 'mo_co_ins_max_amount', 'mo_copay_30daysupply',
                   'mo_copay_60daysupply', 'mo_copay_90daysupply',  'mo_copayabove90daysupply',
                   'co_ins_max_amount_60daysupply', 'co_ins_max_amount_90daysupply',
                   'co_ins_max_amount_above90daysupply', 'reward_share', 'penalty_factor',
                   'alt_reward_share', 'alt_penalty_share', 'otc_inclusion',
                   'deductible_accumulator_flag', 'oop_accumulator_flag', 'outofpocket_max_exempt']

    if presentrec is not None:
        if ('deductibe_accumulator_flag' in presentrec or 'oop_accumulator_flag' in presentrec):
            savedict_cols.append('deductible_accumulator_flag')
            savedict_cols.append('oop_accumulator_flag')

        if ('outofpocket_max_exempt' in presentrec):
            savedict_cols.append('outofpocket_max_exempt')

    drug_covered = 'Y'  # default for the drug is 'Y'
    drugnc_row = []

    if ((grp_row['gpi'] == drug_notcovered_df['gpi']) &
        (grp_row['brand_generic'] == drug_notcovered_df['brand_generic'])).any() == True:
            drugnc_row = drug_notcovered_df.loc[
                ((grp_row['gpi'] == drug_notcovered_df['gpi']) &
                 (grp_row['brand_generic'] == drug_notcovered_df['brand_generic']))]

    if mode == 'ADD':
        if presentrec is not None:
            company_formulary = presentrec['company_formulary']

        for n, plan in plan_details.iterrows():
            plans_dict = dict()
            plans_dict['company'] = plan['company']
            plans_dict['plan_year'] = str(plan['plan_year'])
            plans_dict['plan_name'] = plan['plan_name']
            plans_dict['effective_start_date'] = plan['effective_start_date']
            plans_dict['effective_end_date'] = plan['effective_end_date']
            plans_dict['alt_baseline_per_unit'] = altbaseline_val
            if isinstance(drugnc_row, pd.DataFrame):
                if drugnc_row['plan_name'].values[0] == plans_dict['plan_name']:
                    drug_covered = drugnc_row['drug_covered'].values[0]

            plans_dict['drug_covered'] = drug_covered

            # get values from the formulary record
            for col in grp_columns:
                try:
                    plans_dict[col] = str(grp_row[col])
                except KeyError:
                    plans_dict[col] = ''

            # get columns from the saverecord - presentrec
            for col in savedict_cols:
                if col == 'group_number':
                    curgroups = []
                    if (presentrec[col] is not None and
                            presentrec[col] not in curgroups):
                        curgroups.append(presentrec[col])
                    plans_dict[col] = curgroups
                else:
                    try:
                        plans_dict[col] = str(presentrec[col])
                    except KeyError:
                        plans_dict[col] = ''

            # append record to company formulary
            company_formulary.append(plans_dict)
            data_validate['Records_being_added'] += 1
            data_validate['Records_added'].append((grp_row['gpi'], grp_row['brand_generic'], presentrec['drug_name'],
                                                   presentrec['ddid'], plans_dict['company'], plans_dict['plan_name'],
                                                   plans_dict['plan_year']))

        # end loop- for all plans for company
    else:
        # edit existing record
        company_formulary = presentrec['company_formulary']

        for cmpny_row in company_formulary:
            if (cmpny_row['company'] in list(plan_details['company']) and
                cmpny_row['plan_name'] in list(plan_details['plan_name']) and
                cmpny_row['plan_year'] in list(plan_details['plan_year'])):
                    if isinstance(drugnc_row, pd.DataFrame):
                        if (drugnc_row['plan_name'].values[0] == cmpny_row['plan_name'] and
                            str(drugnc_row['ddid'].values[0]) == presentrec['ddid'] and
                            drugnc_row['drug_name'].values[0] == presentrec['drug_name']):
                                drug_covered = drugnc_row['drug_covered'].values[0]

                    cmpny_row['drug_covered'] = drug_covered
                    for col in grp_columns:
                        try:
                            if cmpny_row[col] != str(grp_row[col]):
                                cmpny_row[col] = str(grp_row[col])
                        except KeyError:
                            try:
                                cmpny_row[col] = str(grp_row[col])
                            except KeyError:
                                if col == 'drug_covered':
                                    cmpny_row[col] = 'Y'
                                else:
                                    cmpny_row[col] = ''

                    cmpny_row['alt_baseline_per_unit'] = altbaseline_val
                    # get columns from the saverecord - presentrec
                    for col in savedict_cols:
                        if col == 'group_number':
                            try:
                                curgroups = cmpny_row[col]
                                if presentrec[col] is not None:
                                    if presentrec[col] not in curgroups:
                                        curgroups.append(presentrec[col])

                                if None in curgroups:
                                    curgroups = []
                                cmpny_row['group_number'] = curgroups
                            except KeyError:
                                if presentrec[col] is not None:
                                    cmpny_row[col] = [presentrec['group_number']]
                        else:
                            try:
                                cmpny_row[col] = str(presentrec[col])
                            except KeyError:
                                cmpny_row[col] = ''

                    data_validate['Records_being_updated'] += 1
                    data_validate['Records_updated'].append((grp_row['gpi'], grp_row['brand_generic'],
                                                           presentrec['drug_name'], presentrec['ddid'],
                                                           cmpny_row['company'], cmpny_row['plan_name'],
                                                           cmpny_row['plan_year']))
        # end loop
    presentrec['company_formulary'] = company_formulary

    # remove keys from return dictionary
    for col in savedict_cols:
        try:
            del presentrec[col]
        except KeyError:
            pass

    return presentrec, data_validate
# end function


def initialize_savedict(grp_row, cb_docname):
    """
    Initialize the dictionary used for saving the information.
    :param grp_row:
    :param copyall:
    :return: save_dict with populated information from existing grp_row.
    """
    save_dict = dict()

    date_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    save_dict['type'] = f'{cb_docname}'

    save_dict['create_date'] = date_str
    save_dict['updated_date'] = date_str
    save_dict['company_formulary'] = []

    if isinstance(grp_row, pd.DataFrame):
        cols = list(grp_row)
        save_dict['gpi'] = str(grp_row['gpi'].values[0])
        save_dict['brand_generic'] = grp_row['brand_generic'].values[0]
        save_dict['id'] = f"{save_dict['gpi']}{save_dict['brand_generic']}"

        try:
            save_dict['create_date'] = grp_row['create_date'].values[0]
        except KeyError:
            pass

        try:
            save_dict['updated_date'] = grp_row['updated_date'].values[0]
        except KeyError:
            pass

        try:
            save_dict['company_formulary'] = grp_row['company_formulary'].values[0]
        except KeyError:
            pass

        if 'ddid' in cols:
            save_dict['ddid'] = grp_row['ddid'].values[0]
            save_dict['drug_name'] = grp_row['drug_name'].values[0]
            del cols

    else:  # to retrieve from series
        save_dict['gpi'] = str(grp_row['gpi'])
        save_dict['brand_generic'] = grp_row['brand_generic']
        save_dict['id'] = f"{save_dict['gpi']}{save_dict['brand_generic']}"
        try:
            save_dict['create_date'] = grp_row['create_date']
        except KeyError:
            pass

        try:
            save_dict['updated_date'] = grp_row['updated_date']
        except KeyError:
            pass

        try:
            save_dict['company_formulary'] = grp_row['company_formulary']
        except KeyError:
            pass

        try:
            save_dict['ddid'] = grp_row['ddid']
        except KeyError:
            pass

        try:
            save_dict['drug_name'] = grp_row['drug_name']
        except KeyError:
            pass

    return save_dict
# end function


def brandgen_val(in_brand):
    """
    used for searching the drugdb.  If there is any brand_gen that is a 'B',
    convert to 'T' because all other lookup tables use 'T'
    :param in_brand:
    :return: 'T" if in_brand is 'B' or 'T', in_brand otherwise.
    """
    if str(in_brand) in ('B', 'T'):
        return 'T'
    return str(in_brand)
# end function


def get_altbaselineprice(grp_row, drug_name, lookup_DF):
    """
    Use lookup_DF (ALternate) to retrieve information for the gpi, drug_name, and brand_gen
    :param grp_row:
    :param drug_name:
    :param lookup_DF:
    :return: return the baseline value from the 'gold_dcc_*' column
    """
    # populate value for alt_baseline_per_unit
    if ((grp_row['gpi'] == lookup_DF['gpi']) &
        (drug_name == lookup_DF['drug_name']) &
        (grp_row['brand_generic'] == lookup_DF['g_t'])).any() == True:
        altbaseline_row = lookup_DF.loc[((grp_row['gpi'] == lookup_DF['gpi']) &
             (drug_name == lookup_DF['drug_name']) &
             (grp_row['brand_generic'] == lookup_DF['g_t']))]
        try:
            altbaseline = str(altbaseline_row['gold_ddc_baseline_per_unit'].values[0])
        except KeyError:
            altbaseline = None
    else:
        altbaseline = None

    return altbaseline
# end function


def get_padetails(grp_row, save_dict, lookup_DF, update=None):
    """
    lookup the PA_formulary information from the lookupDF (PAFormulary) by gpi
    drugname, and brand_gen
    :param grp_row:
    :param save_dict:
    :param lookup_DF:
    :param update:
    :return: updated save_dict containing PA information
    """
    if ((grp_row['gpi'] == lookup_DF['gpi']) &
        (grp_row['brand_generic'] == lookup_DF['brand_generic'])).any() == True:
        paform_row = lookup_DF.loc[((grp_row['gpi'] == lookup_DF['gpi']) &
                                    (grp_row['brand_generic'] == lookup_DF['brand_generic']))]
        out_dict = populate_padetails(grp_row, save_dict, rec=paform_row, update=update)
    else:
        out_dict = populate_padetails(grp_row, save_dict)

    return out_dict
# end function


def display_error(str, loghndl=None):
    if loghndl is None:
        print(f"ERROR: {str}")
    else:
        loghndl.error(f'{str}')
    sys.exit(-1)
# end function


def fetch_cf_row(dom_nm, pln_yr, cmpform_list):
    cf_list = cmpform_list
    orig_row = []
    for cf_row in cf_list:
        if dom_nm in cf_row['company'] and pln_yr in cf_row['plan_year']:
            orig_row.append(cf_row)
    # end loop
    return(orig_row)
# end function


def get_Novartis_accum_flags(proton_pump_gpis, grp_row, saverec):
    """
    Function added: Nov 17, 2019 - Rajesh Acharya
    populates the deductible_accumulator_flag and oop_accumulator_flag for
    specific gpi associated with drug_class PROTON PUMP INIHIBITORS in the drug table.
    :param proton_pump_gpis:
    :param grp_row:
    :param saverec:
    :return: saverec
    """
    # if novartis proton pump gpi, get the details from novirtis_gpis
    if proton_pump_gpis is not None:
        if ((grp_row['gpi'] == proton_pump_gpis['gpi']) &
            (saverec['ddid'] == proton_pump_gpis['ddid']) &
            (grp_row['brand_generic'] == proton_pump_gpis[
                     'brand_generic'])).any() == True:
            novartis_row = proton_pump_gpis.loc[((grp_row['gpi'] == proton_pump_gpis['gpi']) &
                                                 (saverec['ddid'] == proton_pump_gpis['ddid']) &
                                                 (grp_row['brand_generic'] == proton_pump_gpis[
                                                     'brand_generic']))]
            saverec['deductible_accumulator_flag'] = novartis_row['deductible_accumulator_flag'].values[0]
            saverec['oop_accumulator_flag'] = novartis_row['oop_accumulator_flag'].values[0]
            saverec['outofpocket_max_exempt'] = novartis_row['outofpocket_max_exempt'].values[0]
        else:
            saverec['deductible_accumulator_flag'] = 'Y'  # change made based on Sonia's advice
            saverec['oop_accumulator_flag'] = 'Y'  # change made based on Sonia's advice
            saverec['outofpocket_max_exempt'] = 'N'
        # end capture
    else:
        # FD-253 - set flags for all domains (excl- Novartis)
        saverec['deductible_accumulator_flag'] = 'Y'  # change made based on Sonia's advice
        saverec['oop_accumulator_flag'] = 'Y'  # change made based on Sonia's advice
    # end for outer condition
    return saverec
# end function


def get_groupnum(grp, gdf, saverec):
    if gdf is not None:
        if (grp['group_type'].lower() == gdf['group_condition']).any() == True:
            grpnum_detail = gdf.loc[(grp['group_type'].lower() == gdf['group_condition'])]
            saverec['group_number'] = grpnum_detail['group_number'].values[0]
            return saverec

    saverec['group_number'] = None
    return saverec
# end function
