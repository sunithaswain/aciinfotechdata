#!/usr/bin/env python
########################################
# title         : update_drugcovered_attrib.py
# description   : Update formulary document with changes from xlsx files
#                 for drugs_not covered for a domain and plan year.
# author        : Rajesh A.
# date created  : 20191205
# date last modified :
# version       : 0.1
# maintainer    :
# email         : racharya@fliptrx.com
# status        : Dev
# Python Version: 3.6.8
# usage         : [python] update_drugcovered_attrib.py -d GWLABS001 -t formulary -m DRAFT -y plan_year
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#
# #######################################

from formulary.formulary_functions import *

cb_formulary_doc = 'formulary'

if __name__ == '__main__':
    import os
    import pandas as pd
    from utils.sendgridemail import email_log
    from utils.helper_functions import *
    from couchbase.n1ql import N1QLQuery
    from utils.aws_sftp import *
    from pprint import *

    # dn, filetype, filename, mode = commandline.main(sys.argv[1:])
    cmdline_rec = process_alt_cmdline(additional=[['-d', '--domain', 'pass in the domain name (company)', True],
                                                  ['-t', '--file_type', 'pass in the couchbase document type', True],
                                                  ['-y', '--plan_year',
                                                   'update specific plan year (can be comma-delimited', True],
                                                  ['-l', '--load_table', 'load an alternate table', False]])

    mode = cmdline_rec['mode']
    dn = cmdline_rec['domain']

    loc_path = os.environ['CB_DATA']
    logpath = os.environ['LOGDIR']

    if cmdline_rec['load_table'] is not None:
        cb_formulary_doc = cmdline_rec['load_table']

    if cmdline_rec['plan_year'] is None:
        plan_year = [datetime.now().strftime("%Y")]
    else:
        plan_year = cmdline_rec['plan_year'].split(',')

    # get Couchbase handle to the bucket
    cb = cb_authenticate()

    # get execution start time
    start_run = datetime.now()
    log_timestamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")

    logger = setup_logging_path('FORMULARY', f'{dn}_{cb_formulary_doc}_{log_timestamp}',
                                cb_formulary_doc.upper())
    logger.info("=================== Formulary Update Log =====================")

    # get files from ftp server
    dest_path = f"{loc_path}/FORMULARY"
    sftp_hndlr = AWS_SFTP(dn, 'FORMULARY')

    drugdb_df = load_drugdocument(cb, log_hndl=logger)

    dest_dn_path = f"{dest_path}/{dn}"
    try:
        os.mkdir(dest_dn_path)  # create directory if not present
    except:
        pass

    search_file = f"Drug_Not_Covered_{dn}"
    stat, drugnotcovered_fl = sftp_hndlr.sftptransfer(None, dest_path + '/', 'GET',
                                                      searchstr=search_file, loghndl=logger)
    if stat == 'E':
        display_error(f'Auxilary file: {drugnotcovered_fl} not found on SFTP server', loghndl=logger)

    OTC_drug_notcovered_df = load_lookups(logger, f'{dest_path}/{drugnotcovered_fl}', 'NOTCOVERED')
    OTC_drug_notcovered_df['brand_generic'] = OTC_drug_notcovered_df['brand_generic'].\
        apply(lambda x: brandgen_val(str(x).strip()))

    OTC_drug_notcovered_df['gpi'] = OTC_drug_notcovered_df['gpi'].apply(lambda x: str(x).zfill(14))
    OTC_drug_notcovered_df['ddid'] = OTC_drug_notcovered_df['ddid'].apply(lambda x: str(x).strip())

    print("Rows for Drugs_NotCovered: ",OTC_drug_notcovered_df.shape)
    logger.info(f"Rows in Drugs_NotCovered: {OTC_drug_notcovered_df.shape}")
    record_count = 0
    failed_count = 0
    subrec_count = 0
    sftp_hndlr.sftp_close()

    # loop through panda NOTCOVERED gpis
    starttime = datetime.now()
    print(f"File processing started at: {starttime}")
    logger.info(f"File processing started at: {starttime}")
    print(f"Plan year(s) provided: {plan_year}")
    logger.info(f"Plan year(s) provided: {plan_year}")
    
    for index, row in OTC_drug_notcovered_df.iterrows():
        query_str = N1QLQuery(f"SELECT META().id as id, * FROM `{os.environ['CB_INSTANCE']}` " +
                    f"WHERE type='{cb_formulary_doc}' and gpi='" + row['gpi'] + "' " +
                    "and ddid='" + row['ddid'] + "' ")

        logger.debug(f"SELECT QUERY: {query_str.statement}")
        rec = cb.n1ql_query(query_str).get_single_result()

        try:
            sub_record = rec[os.environ['CB_INSTANCE']]
            for years in plan_year:
                found_row = pformat(fetch_cf_row(dn, years, sub_record['company_formulary']), indent=5)
                logger.info(f"ORIGINAL RECORD ROW:\n {found_row}")

                # update query
                update_str = N1QLQuery(f"update `{os.environ['CB_INSTANCE']}` set cf.drug_covered='" +
                                       row['drug_covered'] + "' " +
                                       f"for cf in company_formulary when cf.plan_year='{years}' " +
                                       f"and cf.company='{dn}' end where type='{cb_formulary_doc}' " +
                                       "and gpi='" + row['gpi'] + "' and ddid='" + row['ddid'] + "'")

                update_action = cb.n1ql_query(update_str).execute()
                logger.debug(f"UPDATE QUERY: {update_str.statement}")
                subrec_count += 1
            # end loop for multiple plan update

            record_count += 1
            query_str = N1QLQuery(f"SELECT META().id as id, * FROM `{os.environ['CB_INSTANCE']}` " +
                                  f"WHERE type='{cb_formulary_doc}' and gpi='" + row['gpi'] + "' " +
                                  "and ddid='" + row['ddid'] + "' ")

            logger.debug(f"SELECT QUERY: {query_str.statement}")
            rec = cb.n1ql_query(query_str).get_single_result()
            sub_record = rec[os.environ['CB_INSTANCE']]

            for years in plan_year:
                found_row = pformat(fetch_cf_row(dn, years, sub_record['company_formulary']), indent=5)
                logger.info(f"UPDATED RECORD ROW:\n {found_row}")
        except TypeError:
            logger.warning(f"No record found in < {cb_formulary_doc} > for GPI={row['gpi']} and DDID={row['ddid']}!!")
            failed_count += 1
            pass
        logger.info("-"*70)
    # end loop
    finishtime = datetime.now()
    print(f"\nFile processing completed at: {finishtime}")
    logger.info(f"File processing completed at: {finishtime}")

    logger.info(f"Number of sub-records processed: {subrec_count}")
    print(f"Number of sub-records processed: {subrec_count}")
    logger.info(f"Number of records processed: {record_count}")
    print(f"Number of records processed: {record_count}")
    logger.info(f"Number of records failed: {failed_count}")
    print(f"Number of records failed: {failed_count}")
    print(f"Elapsed time for processing: {(finishtime-starttime)}")

    # transfer files to archive if final mode
    # get new sftp handle
    if mode.lower() == 'final':
        sftp_hndlr = AWS_SFTP(dn, 'FORMULARY')
        stat, _ = sftp_hndlr.sftptransfer(drugnotcovered_fl, None, 'PUT', loghndl=logger)
        if stat == 'S':
            # remove file from sftp /local
            stat, _ = sftp_hndlr.sftpremove(os.path.basename(drugnotcovered_fl), loghndl=logger)

            # remove file from local path: ~/FLIPTB2B/data/FORMULARY/
            try:
                os.unlink(fname)
            except FileNotFoundError:
                pass

    # transfer log and error file and delete it
    if mode.lower() == 'final':
        sftp_hndlr.sftptransfer(logger.handlers[0].baseFilename, sftp_hndlr.sftp_download, 'PUT')
        os.unlink(logger.handlers[0].baseFilename)

    # close the sftp connections
    sftp_hndlr.sftp_close()
# end main
