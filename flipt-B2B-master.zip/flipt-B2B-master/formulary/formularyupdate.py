#!/usr/bin/env python
########################################
# title         : formularyupdate.py
# description   : Update formulary document with details from values csv and xlsx files
#                 in conjunction to the new structure change.
# author        : Rajesh A.
# date created  : 20190730
# date last modified :
# version       : 0.1
# maintainer    :
# email         : racharya@fliptrx.com
# status        : Dev
# Python Version: 3.6.8
# usage         : [python] formularyupdate.py -d GWLABS001 -t formulary -m DRAFT
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#
# #######################################

from formulary.formulary_functions import *

# by default, search all DDID for specific GPI-brandgen
# if ddid and drug_name not specified in formulary load data
SEARCH_DDID = True

# base document name for formulary
cb_formulary_doc = 'formulary_DOMAIN_new'

ADDED_REC_COUNT = 0
UPDATED_REC_COUNT = 0
ERRORED_REC_COUNT = 0
DUPLICATE_REC_COUNT = 0


def save_formulary_record(cb_hndl, log_hndl, save_record, mode, metaid=None):
    """
    save the record to the couchbase.  If there was no metaid provided, record is a
    new entry for the specific document.  Otherwise the record in formulary is updated
    for every field present in the record.
    :param cb_hndl:
    :param log_hndl:
    :param save_record:
    :param mode:
    :param metaid:
    :return:
    """
    from couchbase import FMT_JSON
    import couchbase.subdocument as SD

    global ADDED_REC_COUNT
    global ERRORED_REC_COUNT
    global UPDATED_REC_COUNT

    if mode.upper().strip() == 'FINAL':
        if metaid is not None:
            # alternate save method - save each column data
            for col in save_record:
                try:
                    if save_record[col] == nan:
                        save_record[col] = ''
                    cb_hndl.mutate_in(str(metaid), SD.upsert(col, save_record[col]))
                except Exception as e:
                    log_hndl.error(f"Error occured while trying to update: {col} with value {save_record[col]}" +
                                   f" for {save_record['drug_name']}|{save_record['gpi']}|{save_record['ddid']}")
                    ERRORED_REC_COUNT += 1
                    return -1, 'ERROR'

            log_hndl.info(f"Updated the formulary for metaid({metaid})-- ddid: {save_record['ddid']}" +
                        f" | drugname: {save_record['drug_name']} | gpi: {save_record['gpi']} | " +
                        f" brand_generic: {save_record['brand_generic']}")
            UPDATED_REC_COUNT += 1
            return 0, 'OK'
        else:
            new_id = cb_hndl.counter('docid', delta=1).value
            cb_hndl.upsert(str(new_id), save_record, format=FMT_JSON)
            log_hndl.info("Added new entry (" + str(new_id) + ") in the Formulary for ddid: " +
                      save_record['ddid'] + " | drug name: " + save_record['drug_name'] + " | gpi: " +
                      save_record['gpi'] + " | brandgen: " + save_record['brand_generic'])
            ADDED_REC_COUNT += 1
            return new_id, 'OK'
        # end - metaid check
    # end mode check
    return 0, 'OK'
# end function


def write_final_tally(out_file, record_list):
    """
    write the CSV for the processed/Errored records
    :param out_file:
    :param record_list:
    :return: None
    """
    temp_df = pd.DataFrame()

    for rows in record_list:
        rec = record_list[rows]
        (gpi, ddid, brandgen) = rows.split('|')
        rec['GPI'] = gpi
        rec['DDID'] = ddid
        rec['BRAND_GENERIC'] = brandgen

        temp_df = temp_df.append(rec, ignore_index=True)
    # end loop

    temp_df.to_csv(out_file, index=False, sep=';', quotechar="'")
# end function


def check_domain(grp_row, dn_name, recs_unprocessed, log_hndl):
    """
    check if the current row being processed is for the expected domain.
    :param grp_row:
    :param dn_name:
    :param recs_unprocessed:
    :param log_hndl:
    :return: recs_unprocessed and True/False
    """
    global ERRORED_REC_COUNT

    if grp_row['company'] != dn_name:  # check company we are adding info for is same as domain (dn)
        warn_msg = f"Invalid company: {grp_row['company']} != {dn} - the current domain being updated"
        log_hndl.warning(warn_msg)
        recs_unprocessed[f"{grp_row['gpi']}|unknown|{grp_row['brand_generic']}"] = {'STATUS': "WARN",
                                                                                    'REASON_DETAIL': warn_msg,
                                                                                    'DRUG NAME': '-----',
                                                                                    'TIME': "00:00:00"}
        ERRORED_REC_COUNT += 1
        return recs_unprocessed, False

    return records_unprocessed, True
# end function


def checkfor_invalid_gpi(log_hndl, grp_row, unproc_recs):
    """
    Check if the gpi for the current row being processed is valid (doesn't contain 'E+###'
    :param log_hndl:
    :param grp_row:
    :param unproc_recs:
    :return: recs_unprocessed and True/False
    """
    global ERRORED_REC_COUNT

    gpi_val = grp_row['gpi']
    brand_gen = grp_row['brand_generic']
    status = False

    if 'E+' in gpi_val:
        error_str = f"Invalid format for the gpi. Record not found for gpi-brandgen: {gpi_val} - {brand_gen}"
        status = True
        ERRORED_REC_COUNT += 1
        log_hndl.error(error_str)
        unproc_key = f"{gpi_val}|unknown|{brand_gen}"
        unproc_recs[unproc_key] = {'REASON_DETAIL': error_str, 'STATUS': 'ERROR',
                                           'DRUG_NAME': '-------------',
                                           'TIME': '00:00:00'}
    return unproc_recs, status
# end function


def save_information(cb_hndl, log_hndl, save_dict, mode, recs_unproc, meta_id):
    """
    Call the actual save function to update existing record or add new record.
    :param cb_hndl:
    :param log_hndl:
    :param save_dict:
    :param mode:
    :param recs_processed:
    :param recs_unproc:
    :param meta_id:
    :return: new recordid, processed_rec dict, unprocessed dict
    """
    (newrec, stat) = save_formulary_record(cb_hndl, log_hndl, save_dict, mode, metaid=meta_id)
    proc_key = f"{save_dict['gpi']}|{save_dict['ddid']}|{save_dict['brand_generic']}"
    if stat == 'ERROR':
        recs_unproc[proc_key] = {'DRUG_NAME': save_frame['drug_name'],
                                         'STATUS': 'ERROR',
                                         'REASON_DETAIL': "Could not update some cols.",
                                         'TIME': '00:00:00'}
    return newrec, recs_unproc
# end function


def record_duplicate_gpi(log_hndl, formulary_gpi_info, formulary_dups, rec_key,
                         validation_dict, unprocessed_recs):
    global DUPLICATE_REC_COUNT

    formulary_dups[rec_key] += 1
    error_str = "duplicate record for gpi-brand: " + \
               f"{formulary_gpi_info['gpi']} - {formulary_gpi_info['brand_generic']} " + \
               f"count: {formulary_dups[rec_key]}"

    log_hndl.error(error_str)
    DUPLICATE_REC_COUNT += 1
    validation_dict['Duplicate_GPI-BRANDGEN'] = DUPLICATE_REC_COUNT
    unproc_key = f"{formulary_gpi_info['gpi']}|unknown|{formulary_gpi_info['brand_generic']}"
    unprocessed_recs[unproc_key] = {'REASON_DETAIL': error_str,
                                       'DRUG_NAME': '-------------',
                                       'STATUS': 'WARN',
                                       'TIME': '00:00:00'}
    return(formulary_dups, validation_dict, unprocessed_recs)
# end function


if __name__ == '__main__':
    import os
    import pandas as pd
    from numpy import nan
    from utils.sendgridemail import email_log_custombody
    from utils.helper_functions import *
    from couchbase.n1ql import N1QLQuery
    from utils.aws_sftp import *
    from utils.file_comp_log import FileComp

    # dn, filetype, filename, mode = commandline.main(sys.argv[1:])
    cmdline_rec = process_alt_cmdline(additional=[['-r', '--removeold', "removes old domain entries from formulary", False],
                                                  ['-d', '--domain', 'pass in the domain name (company)', True],
                                                  ['-t', '--file_type', 'pass in the couchbase document type', True],
                                                  ['-y', '--plan_year', 'update specific plan year', False],
                                                  ['-p', '--plan_name', 'Update/Add specific plan name', False],
                                                  ['-l', '--load_table', 'load an alternate table', False],
                                                  ['-b', '--both_yearandname',
                                                   'use both plan year and name when updating records', False]])

    mode = cmdline_rec['mode']
    dn = cmdline_rec['domain']

    # changes specific for building formulary specific to a domain
    # set formulary document to use domain specific formulary
    cb_formulary_doc = cb_formulary_doc.replace('DOMAIN', dn)

    loc_path = os.environ['CB_DATA']
    logpath = os.environ['LOGDIR']

    if cmdline_rec['both_yearandname'] is not None:
        search_by = 'both'
    else:
        search_by = 'year'

    if cmdline_rec['load_table'] is not None:
        cb_formulary_doc = cmdline_rec['load_table']

    if cmdline_rec['plan_year'] is None:
        plan_year = datetime.now().strftime("%Y")
    else:
        plan_year = cmdline_rec['plan_year']

    if cmdline_rec['plan_name'] is None:
        a_plan_name = None
    else:
        a_plan_name = cmdline_rec['plan_name']


    # get Couchbase handle to the bucket
    cb = cb_authenticate()
    if cb is None:
        sys.exit(-1)

    localpth = f"{loc_path}/FORMULARY/"
    fileComp = FileComp(localpth, dn, 'formulary')

    # get execution start time
    start_run = datetime.now()
    log_timestamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")

    logger = setup_logging_path('FORMULARY', f'{dn}_{cb_formulary_doc}_{log_timestamp}',
                                cb_formulary_doc.upper())
    logger.info("=================== Formulary Update Log =====================")

    # get files from ftp server
    dest_path = f"{loc_path}/FORMULARY"
    sftp_hndlr = AWS_SFTP(dn, 'FORMULARY')

    group_df = load_groupcond_document(cb, domain_nm=dn, log_hndl=logger)

    errored_records_fn = f"{dest_path}/{dn}_UNPROCESSED_RECORDS_{log_timestamp}.csv"

    dest_dn_path = f"{dest_path}/{dn}"
    try:
        os.mkdir(dest_dn_path)  # create directory if not present
    except:
        pass

    search_file = "Formulary_"
    (stat, fname) = sftp_hndlr.sftptransfer(None, dest_dn_path + '/', 'GET', searchstr=search_file, loghndl=logger)
    if stat == 'E':
        display_error("Exiting script.  No formulary file found for {dn} to update on SFTP server", loghndl=logger)

    dn_data_file = f"{dest_dn_path}/{fname}"
    data_files = []
    excel_files = []

    PA_fname = retrieve_file(sftp_hndlr, dest_path + '/', 'PA_FORMULARY', loghandle=logger)

    Novartis_Inhibitors_fname = retrieve_file(sftp_hndlr, dest_path + '/', 'drug_condition_gpi', loghandle=logger)

    covered_search = f'Drug_Not_Covered'
    Drug_NotCovered_fname = retrieve_file(sftp_hndlr, dest_path + '/', covered_search, loghandle=logger)

    Alt_fname = retrieve_file(sftp_hndlr, dest_path + '/', 'Alternate', loghandle=logger)

    QuantityLimit_fname = retrieve_file(sftp_hndlr, dest_path + '/', 'QuantityLimit', loghandle=logger)

    # keep auxilary files on sftp - don't remove
    excel_files.extend([dn_data_file])
                         
    data_files.append(dn_data_file)

    logger.info("Start time is " + str(datetime.now()) + "\r\n")
    load_details = load_data_files(logger, data_files)

    source_formulary = fetch_df('Formulary_', load_details)
    source_formulary = fix_headers(source_formulary)

    source_headers = list(source_formulary)
    if 'ddid' in source_headers:
        SEARCH_DDID = False
        del source_headers
        drugdb_df = pd.DataFrame()
    else:
        drugdb_df = load_drugdocument(cb, log_hndl=logger)
        print_memusage("DRUG_DB", drugdb_df, loghandle=logger)

    source_formulary['brand_generic'] = source_formulary['brand_generic'].apply(lambda x: brandgen_val(str(x).strip()))
    source_formulary['gpi'] = source_formulary['gpi'].apply(lambda x: str(x).zfill(14))
    try:
        source_formulary['ddid'] = source_formulary['ddid'].apply(lambda x: str(x))
    except KeyError:
        pass
    source_formulary.fillna("", inplace=True)

    print_memusage('Formulary source', source_formulary, loghandle=logger)
    del load_details
    sftp_hndlr.sftp_close()

    logger.info(f"Record in formulary file for domain: {dn}: {source_formulary.shape}")

    drug_notcovered_df = load_lookups(logger, f'{dest_path}/{Drug_NotCovered_fname}', 'NOTCOVERED')
    if not drug_notcovered_df.empty:
        print_memusage('Drug_not_covered', drug_notcovered_df, loghandle=logger)

    altdrugddcbase_df = load_lookups(logger, f'{dest_path}/{Alt_fname}', 'G&W DDC Baselines')
    if not altdrugddcbase_df.empty:
        print_memusage('Alternate_Baseline', altdrugddcbase_df, loghandle=logger)

    quantitylimit_df = load_lookups(logger, f'{dest_path}/{QuantityLimit_fname}', 'Sheet1')
    if not quantitylimit_df.empty:
        quantitylimit_df['dos_limit'] = quantitylimit_df.dos_limit.fillna('')
        quantitylimit_df['fill_per_year_limit'] = quantitylimit_df.fill_per_year_limit.fillna('')
        quantitylimit_df['ddid'] = quantitylimit_df['ddid'].apply(lambda x: str(x))
        quantitylimit_df['brand_generic'] = quantitylimit_df['brand_generic'].apply(
            lambda x: brandgen_val(str(x).strip()))
        print_memusage('Quantity Limit', quantitylimit_df, loghandle=logger)

    if Novartis_Inhibitors_fname is not None:
        novartis_proton_gpis = load_lookups(logger, f'{dest_path}/{Novartis_Inhibitors_fname}',
                                        'NOVARTIS001_drug_condition_gpi')

        novartis_proton_gpis['gpi'] = novartis_proton_gpis['gpi'].apply(lambda x: str(x).zfill(14))
        novartis_proton_gpis['ddid'] = novartis_proton_gpis['ddid'].apply(lambda x: str(x).strip())
        novartis_proton_gpis['brand_generic'] = novartis_proton_gpis['brand_generic'].\
            apply(lambda x: brandgen_val(str(x).strip()))

        print_memusage('Drug Condition', novartis_proton_gpis, loghandle=logger)
    else:
        novartis_proton_gpis = None

    paform_df = load_lookups(logger, f'{dest_path}/{PA_fname}', 'Sheet1')
    if not paform_df.empty:
        print_memusage('PA_FORMULARY', paform_df, loghandle=logger)

    paform_df['ql_ratio'] = paform_df.ql_ratio.fillna('N')
    paform_df['drug'] = paform_df.drug.fillna('')
    paform_df['abuse_misuse'] = paform_df.abuse_misuse.fillna('N')
    paform_df['cost'] = paform_df.cost.fillna('N')
    paform_df['age'] = paform_df.age.fillna('N')
    paform_df['gender'] = paform_df.gender.fillna('N')
    paform_df['quantity'] = paform_df.quantity.fillna('N')
    paform_df['specialty'] = paform_df.specialty.fillna('N')
    paform_df['step_therapy'] = paform_df.step_therapy.fillna('N')
    paform_df['pa_reason'] = paform_df.pa_reason.fillna('')
    paform_df['pa_form'] = paform_df.pa_form.fillna('')

    # update rxplanmaster and set update_formulary_flag to 'N' for all records
    logger.info("Setting the flag for update_formulary_flag='N' for all company in 'rxplan_master")
    cb.n1ql_query(N1QLQuery('update `' + os.environ['CB_INSTANCE'] + '` set update_formulary_flag="N" ' +
                           'WHERE type="rxplan_master" ')).execute()

    # update rxplanmaster and set update_formulary_flag to 'Y' for records with current plan year and given domain
    logger.info("Setting the flag for update_formulary_flag='Y' for current company being updated in 'rxplan_master")
    update_str = 'update `' + os.environ['CB_INSTANCE'] + '` set update_formulary_flag="Y" ' +\
                 'WHERE type="rxplan_master"  and domain_name="' + dn + '" ' +\
                 'and plan_year="' + plan_year + '" '
    if a_plan_name is not None:
        update_str += 'and plan_name="' + a_plan_name + '"'

    cb.n1ql_query(N1QLQuery(update_str)).execute()

    # query to get the plans from rxplan_master
    plan_query = 'SELECT domain_name, plan_name, plan_year, drug_notcovered_can_be_dispensed,' +\
                 f"plan_start_date, plan_end_date FROM `{os.environ['CB_INSTANCE']}` " +\
                 'WHERE type="rxplan_master" and update_formulary_flag ="Y" ' +\
                 'and domain_name=$domain and plan_year="' + plan_year + '" '

    if a_plan_name is not None:
        plan_query += f'and plan_name="{a_plan_name}"'

    check_plan = N1QLQuery(plan_query, domain=dn)
    check_plan.timeout = 7200
    plan_info = pd.DataFrame()
    plan_cnt = 0

    records_processed = dict()
    records_unprocessed = dict()
    bulk_save_records = dict()

    data_validation = {'Bad_GPI': 0,
                       'Invalid_domain': 0,
                       'Drug_not_found': 0,
                       'Records_being_added': 0,
                       'Records_being_updated': 0,
                       'Records_being_removed': 0,
                       'Bad_GPI_list': [],
                       'Duplicate_GPI-BRANDGEN': 0,
                       'Invalid_domain_list': [],
                       'Records_removed': [],
                       'Records_added': [],
                       'Records_updated': []}

    # populate plan information for selected domain
    for plan in cb.n1ql_query(check_plan):
        plan_info = plan_info.append({'plan_name': plan['plan_name'],
                                      'plan_year': plan['plan_year'],
                                      'company': plan['domain_name'],
                                      'effective_start_date': plan['plan_start_date'],
                                      'effective_end_date': plan['plan_end_date'],
                                      'drug_notcovered': plan['drug_notcovered_can_be_dispensed']},
                                     ignore_index=True)
        plan_cnt += 1

    if not plan_info.empty:
        # check if document exists
        document_exists = check_doc_exists(cb, cb_formulary_doc, loghndl=logger)
        meta_ids = dict()

        # load up existing formulary data
        formulary_db = read_couchbase_source(cb, cb_formulary_doc, extra_query=None,
                                             key_cols=['ddid', 'drug_name', 'gpi', 'brand_generic'],
                                             loghndl=logger)

        db_records = formulary_db.shape[0]

        if not formulary_db.empty:
            print_memusage('Formulary_DB', formulary_db, loghandle=logger)
            logger.info(f"Number of formulary records loaded from database: {db_records}\n")

            formulary_db['gpi'] = formulary_db['gpi'].apply(lambda x: str(x).zfill(14))
            formulary_db['brand_generic'] = formulary_db['brand_generic'].apply(lambda x: str(x).strip())
            formulary_db['ddid'] = formulary_db['ddid'].apply(lambda x: str(x).strip())
        else:
            logger.info(f"Document < {cb_formulary_doc} > doesn't exist!!  Will need to be created.")

        # formulary_duplicate tracking
        src_formulary_dups = dict()

        # # no records in formulary_db
        if db_records == 0:
            print(f"In section to add records to the new formulary structure ({cb_formulary_doc}) ...",
                  end='', flush=True)
            logger.info("Adding new records to formulary")
            for k, grp in source_formulary.iterrows():
                save_frame = initialize_savedict(grp, cb_formulary_doc)

                # check company we are adding info for is same as domain (dn)
                (records_unprocessed, stat) = check_domain(grp, dn, records_unprocessed, logger)
                if stat is False:
                    data_validation['Invalid_domain'] += 1
                    data_validation['Invalid_domain_list'].append(grp['company'])
                    continue

                (records_unprocessed, stat) = checkfor_invalid_gpi(logger, grp, records_unprocessed)
                if stat is True:
                    data_validation['Bad_GPI'] += 1
                    data_validation['Bad_GPI_list'].append((grp['gpi'],
                                                            grp['brand_generic']))
                    continue

                record_info = ''
                if SEARCH_DDID is False:
                    record_info = f"{grp['gpi']}|{grp['brand_generic']}|{grp['ddid']}"
                else:
                    record_info = f"{grp['gpi']}|{grp['brand_generic']}"

                if record_info in src_formulary_dups:
                    # log the duplicate record and go to next gpi info
                    (src_formulary_dups, data_validation, 
                     records_unprocessed) = record_duplicate_gpi(logger, grp, src_formulary_dups, record_info,
                                                                 data_validation, records_unprocessed)
                    continue
                else:
                    src_formulary_dups[record_info] = 0

                if SEARCH_DDID is True:
                    if ((grp['gpi'] == drugdb_df['gpi']) &
                        (grp['brand_generic'] == drugdb_df['brand_generic'])).any() == True:
                        drugdf_row = drugdb_df.loc[((grp['gpi'] == drugdb_df['gpi']) &
                                        (grp['brand_generic'] == drugdb_df['brand_generic']))]

                        if drugdf_row.shape[0] == 1:
                            save_frame['ddid'] = str(drugdf_row['ddid'].values[0])
                            grp['ddid'] = save_frame['ddid']
                            save_frame['drug_name'] = drugdf_row['drug_name'].values[0]
                            fileComp.append({'record':'not present'}, "pre")

                        else:  # multiple drugs for the gpi
                            # functionality to do multiple drugs
                            logger.info(f"processing multiple drugs for gpi-brand combo: {grp['gpi']} - " +
                                        f"{grp['brand_generic']}")
                            num_drugs = 0
                            for _, drg_grp in drugdf_row.groupby(['gpi', 'ddid']):
                                save_frame = initialize_savedict(grp, cb_formulary_doc)
                                save_frame['ddid'] = str(drg_grp['ddid'].values[0])
                                grp['ddid'] = save_frame['ddid']
                                save_frame['drug_name'] = drg_grp['drug_name'].values[0]
                                fileComp.append({'record':'not present'},"pre")

                                # if novartis proton pump gpi, get the details from novartis_gpis
                                save_frame = get_Novartis_accum_flags(novartis_proton_gpis, grp, save_frame)
                                save_frame['qtytodaysupplyratio_new'] = str(grp['qtytodaysupplyratio_new'])
                                save_frame = populate_qldetails(grp, save_frame)

                                save_frame = populate_additional_ql_values(quantitylimit_df, grp, save_frame)

                                # build pa_formulary details
                                save_frame = get_padetails(grp, save_frame, paform_df)

                                save_frame = get_groupnum(grp, group_df, save_frame)

                                # populate value for alt_baseline_per_unit
                                altbaseline_value = get_altbaselineprice(grp, save_frame['drug_name'], altdrugddcbase_df)

                                # populate the company formulary
                                logger.info(f"altbase value for gpi:{grp['gpi']} brandgen: " +
                                            f"{grp['brand_generic']} " +
                                            f"drug: {save_frame['drug_name']} " +
                                            f" = {altbaseline_value}")

                                (save_frame, data_validation) = populate_companydetails(plan_info, grp,
                                                                                        altbaseline_value,
                                                                                        drug_notcovered_df,
                                                                                        data_validation,
                                                                                        presentrec=save_frame)

                                fileComp.append(save_frame, 'post')
                                (new_rec, records_unprocessed) = save_information(cb, logger, save_frame, mode,
                                                                                  records_unprocessed, None)
                                num_drugs += 1
                            # end loop for multiple drugs
                            logger.info(f"multi-drug process complete -- {num_drugs} found")
                            continue
                        # end - multiple drug/ddid for a gpi-brand

                        # if novartis proton pump gpi, get the details from novartis_gpis
                        save_frame = get_Novartis_accum_flags(novartis_proton_gpis, grp, save_frame)

                        save_frame['qtytodaysupplyratio_new'] = str(grp['qtytodaysupplyratio_new'])
                        save_frame = populate_qldetails(grp, save_frame)
                        save_frame = populate_additional_ql_values(quantitylimit_df, grp, save_frame)

                        # populate pa_formulary details
                        save_frame = get_padetails(grp, save_frame, paform_df)

                        save_frame = get_groupnum(grp, group_df, save_frame)

                        # populate value for alt_baseline_per_unit
                        altbaseline_value = get_altbaselineprice(grp, save_frame['drug_name'], altdrugddcbase_df)

                        # populate the company formulary
                        logger.info(f"altbase value for gpi:{grp['gpi']} brandgen: " +
                                    f"{grp['brand_generic']} drug: {save_frame['drug_name']}" +
                                    f" = {altbaseline_value}")

                        (save_frame, data_validation) = populate_companydetails(plan_info, grp,
                                                                                altbaseline_value,
                                                                                drug_notcovered_df,
                                                                                data_validation,
                                                                                presentrec=save_frame)

                        fileComp.append(save_frame, 'post')
                        (new_rec, records_unprocessed) = save_information(cb, logger, save_frame, mode,
                                                                          records_unprocessed, None)
                    else:
                        data_validation['Drug_not_found'] += 1
                        error_str="could not find drug details for gpi-brand: " + \
                                  f"{grp['gpi']} - {grp['brand_generic']}"
                        logger.error(error_str)
                        ERRORED_REC_COUNT += 1
                        unproc_key = f"{grp['gpi']}|unknown|{grp['brand_generic']}"
                        records_unprocessed[unproc_key] = {'REASON_DETAIL': error_str,
                                                           'DRUG_NAME': '-------------',
                                                           'STATUS': 'ERROR',
                                                           'TIME': '00:00:00'}
                        continue
                    # drug not found

                else:  # don't search drugdb - ddid and drug name in formulary load file
                    # if novartis proton pump gpi, get the details from novartis_gpis
                    fileComp.append({'record': 'not present'}, "pre")
                    save_frame = get_Novartis_accum_flags(novartis_proton_gpis, grp, save_frame)

                    save_frame['qtytodaysupplyratio_new'] = str(grp['qtytodaysupplyratio_new'])
                    save_frame = populate_qldetails(grp, save_frame)
                    save_frame = populate_additional_ql_values(quantitylimit_df, grp, save_frame)

                    # populate pa_formulary details
                    save_frame = get_padetails(grp, save_frame, paform_df)

                    save_frame = get_groupnum(grp, group_df, save_frame)

                    # populate value for alt_baseline_per_unit
                    altbaseline_value = get_altbaselineprice(grp, save_frame['drug_name'], altdrugddcbase_df)

                    # populate the company formulary
                    logger.info(f"altbase value for gpi:{grp['gpi']} brandgen: " +
                                f"{grp['brand_generic']} drug: {save_frame['drug_name']}" +
                                f" = {altbaseline_value}")

                    (save_frame, data_validation) = populate_companydetails(plan_info, grp,
                                                                            altbaseline_value,
                                                                            drug_notcovered_df,
                                                                            data_validation,
                                                                            presentrec=save_frame)

                    fileComp.append(save_frame, 'post')
                    (new_rec, records_unprocessed) = save_information(cb, logger, save_frame, mode,
                                                                      records_unprocessed, None)
            # end - no records present in the formulary_db

        else:  # modify old records
            print(f"In section to modify existing records in {cb_formulary_doc} ...", end='', flush=True)
            logger.info("Modifying existing records")

            # loop through new formulary input data for adding to existing formulary
            source_formulary_cols = list(source_formulary.columns)
            for k, grp in source_formulary.iterrows():
                # grp.reset_index(drop=True, inplace=True)
                (records_unprocessed, stat) = check_domain(grp, dn, records_unprocessed, logger)
                if stat is False:
                    data_validation['Invalid_domain'] += 1
                    data_validation['Invalid_domain_list'].append(grp['company'])
                    continue

                (records_unprocessed, stat) = checkfor_invalid_gpi(logger, grp, records_unprocessed)
                if stat is True:
                    data_validation['Bad_GPI'] += 1
                    data_validation['Bad_GPI_list'].append((grp['gpi'],
                                                            grp['brand_generic']))
                    continue

                record_info = ''
                if SEARCH_DDID is False:
                    record_info = f"{grp['gpi']}|{grp['brand_generic']}|{grp['ddid']}"
                else:
                    record_info = f"{grp['gpi']}|{grp['brand_generic']}"

                if record_info in src_formulary_dups:
                    # log the duplicate record and go to next gpi info
                    (src_formulary_dups, data_validation,
                     records_unprocessed) = record_duplicate_gpi(logger, grp, src_formulary_dups, record_info,
                                                                 data_validation, records_unprocessed)
                    continue
                else:
                    src_formulary_dups[record_info] = 0

                if SEARCH_DDID is True:
                    if ((grp['gpi'] == formulary_db['gpi']) &
                        (grp['brand_generic'] == formulary_db['brand_generic'])).any() == True:
                        formularynew_row = formulary_db.loc[((grp['gpi'] == formulary_db['gpi']) &
                                                        (grp['brand_generic'] == formulary_db['brand_generic']))]

                        for t, rec_row in formularynew_row.groupby(['gpi', 'ddid', 'brand_generic']):
                            metaids_key = rec_row['id'].values[0]

                            sub_record = rec_row['data_row'].values[0]
                            save_frame = initialize_savedict(sub_record, cb_formulary_doc)

                            # build/update qldetails
                            grp['ddid'] = save_frame['ddid']
                            save_frame = populate_qldetails(grp, save_frame, update=True)
                            save_frame = populate_additional_ql_values(quantitylimit_df, grp, save_frame)

                            # build/update pa_formulary details
                            save_frame = get_padetails(grp, save_frame, paform_df, update=True)

                            # if novartis proton pump gpi, get the details from novartis_gpis
                            save_frame = get_Novartis_accum_flags(novartis_proton_gpis, grp, save_frame)

                            # FD-86: add group_number to formulary
                            save_frame = get_groupnum(grp, group_df, save_frame)


                            altbaseline_value = get_altbaselineprice(grp, save_frame['drug_name'], altdrugddcbase_df)

                            # update company formulary
                            if (len(plan_year) != 0 and a_plan_name is not None):
                                if search_by == 'both':
                                    by_type = search_by
                                else:
                                    by_type = 'planname'
                            else:
                               by_type = 'year'

                            if cmdline_rec['removeold'] is not None and cmdline_rec['removeold'] == 'Y':
                                (save_frame['company_formulary'],
                                 data_validation) = remove_old_plandetails(dn, grp,
                                                                           save_frame['company_formulary'],
                                                                           data_validation,
                                                                           planyear=plan_year,
                                                                           planname=a_plan_name,
                                                                           by_type=by_type)

                            oper = company_exists(dn, save_frame['company_formulary'],
                                                  planyear=plan_year,
                                                  planname=a_plan_name,
                                                  by_type=by_type)

                            (save_frame, data_validation) = populate_companydetails(plan_info, grp,
                                                                                    altbaseline_value,
                                                                                    drug_notcovered_df,
                                                                                    data_validation,
                                                                                    mode=oper,
                                                                                    presentrec=save_frame,
                                                                                    update=True)

                            fileComp.append(save_frame, 'post')
                            date_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                            save_frame['updated_date'] = date_str
                            (newrec, records_unprocessed) = save_information(cb, logger, save_frame, mode,
                                                                             records_unprocessed,
                                                                             metaids_key)

                    else:
                        # record is not present - do processing as a new entry
                        save_frame = initialize_savedict(grp, cb_formulary_doc)

                        record_info = ''
                        if SEARCH_DDID is False:
                            record_info = f"{grp['gpi']}|{grp['brand_generic']}|{grp['ddid']}"
                        else:
                            record_info = f"{grp['gpi']}|{grp['brand_generic']}"

                        if record_info in src_formulary_dups:
                            # log the duplicate record and go to next gpi info
                            (src_formulary_dups, data_validation,
                             records_unprocessed) = record_duplicate_gpi(logger, grp, src_formulary_dups,
                                                                     record_info, data_validation,
                                                                     records_unprocessed)
                            continue
                        else:
                            src_formulary_dups[record_info] = 0

                        if ((grp['gpi'] == drugdb_df['gpi']) &
                            (grp['brand_generic'] == drugdb_df['brand_generic'])).any() == True:
                            drugdf_row = drugdb_df.loc[((grp['gpi'] == drugdb_df['gpi']) &
                                                        (grp['brand_generic'] == drugdb_df['brand_generic']))]
                            if drugdf_row.shape[0] == 1:
                                save_frame['ddid'] = str(drugdf_row['ddid'].values[0])
                                save_frame['drug_name'] = drugdf_row['drug_name'].values[0]
                                fileComp.append({'record': 'not present'}, 'pre')

                            else:  # multiple drugs for the gpi
                                # functionality to do multiple drugs
                                logger.info(f"processing multiple drugs for gpi-brand combo: {grp['gpi']} -' +"
                                            f"{grp['brand_generic']}")
                                num_drugs = 0
                                for _, drg_grp in drugdf_row.groupby(['gpi', 'ddid']):
                                    grp['ddid'] = save_frame['ddid']
                                    save_frame = initialize_savedict(grp, cb_formulary_doc)
                                    save_frame['ddid'] = str(drg_grp['ddid'].values[0])
                                    save_frame['drug_name'] = drg_grp['drug_name'].values[0]
                                    fileComp.append({'record': 'not present'}, 'pre')

                                    # if novartis proton pump gpi, get the details from novartis_gpis
                                    save_frame = get_Novartis_accum_flags(novartis_proton_gpis, grp, save_frame)

                                    save_frame['qtytodaysupplyratio_new'] = str(grp['qtytodaysupplyratio_new'].values[0])
                                    save_frame = populate_qldetails(grp, save_frame)
                                    save_frame = populate_additional_ql_values(quantitylimit_df, grp, save_frame)

                                    # build pa_formulary details
                                    save_frame = get_padetails(grp, save_frame, paform_df)

                                    save_frame = get_groupnum(grp, group_df, save_frame)

                                    # populate value for alt_baseline_per_unit
                                    altbaseline_value = get_altbaselineprice(grp, save_frame['drug_name'],
                                                                             altdrugddcbase_df)

                                    # populate the company formulary
                                    logger.info(f"altbase value for gpi:{grp['gpi']} brandgen: " +
                                                f"{grp['brand_generic']} drug: {save_frame['drug_name']}" +
                                                f" = {altbaseline_value}")

                                    (save_frame, data_validation) = populate_companydetails(plan_info, grp,
                                                                                            altbaseline_value,
                                                                                            drug_notcovered_df,
                                                                                            data_validation,
                                                                                            presentrec=save_frame)
                                    fileComp.append(save_frame, 'post')
                                    (new_rec, records_unprocessed) = save_information(cb, logger, save_frame, mode,
                                                                                      records_unprocessed, None)
                                    num_drugs += 1
                                # end loop for multiple drugs
                                logger.info(f"multi-drug process complete -- {num_drugs} found")
                                continue
                            # end - multiple drug/ddid for a gpi-brand

                            save_frame['qtytodaysupplyratio_new'] = str(grp['qtytodaysupplyratio_new'])
                            save_frame = populate_qldetails(grp, save_frame)
                            save_frame = populate_additional_ql_values(quantitylimit_df, grp, save_frame)

                            # if novartis proton pump gpi, get the details from novirtis_gpis
                            save_frame = get_Novartis_accum_flags(novartis_proton_gpis, grp, save_frame)

                            # populate pa_formulary details
                            save_frame = get_padetails(grp, save_frame, paform_df)

                            # populate value for alt_baseline_per_unit
                            altbaseline_value = get_altbaselineprice(grp, save_frame['drug_name'], altdrugddcbase_df)

                            # populate the company formulary
                            logger.info(f"altbase value for gpi:{grp['gpi']} brandgen: " +
                                        f"{grp['brand_generic']} drug: {save_frame['drug_name']}" +
                                        f" = {altbaseline_value}")

                            (save_frame, data_validation) = populate_companydetails(plan_info, grp,
                                                                                    altbaseline_value,
                                                                                    drug_notcovered_df,
                                                                                    data_validation,
                                                                                    presentrec=save_frame)
                            fileComp.append(dsave_frame, 'post')
                            (new_rec, records_unprocessed) = save_information(cb, logger, save_frame, mode,
                                                                              records_unprocessed, None)
                        else:
                            data_validation['Drug_not_found'] += 1
                            error_str = "could not find drug details for gpi-brand: " + \
                                        f"{grp['gpi']} - {grp['brand_generic']}"
                            ERRORED_REC_COUNT += 1
                            logger.error(error_str)
                            unproc_key = f"{grp['gpi']}|unknown|{grp['brand_generic']}"
                            records_unprocessed[unproc_key] = {'REASON_DETAIL': error_str,
                                                               'DRUG_NAME': '-------------',
                                                               'STATUS': 'ERROR',
                                                               'TIME': '00:00:00'}
                            continue
                    # gpi-brandgen doesn't exist

                else:  # don't search drug_db. use ddid from formulary file and edit existing records
                    if ((grp['gpi'] == formulary_db['gpi']) & (grp['ddid'] == formulary_db['ddid']) &
                            (grp['brand_generic'] == formulary_db['brand_generic']) &
                            (grp['drug_name'] == formulary_db['drug_name'])).any() == True:
                        formularynew_row = formulary_db.loc[((grp['gpi'] == formulary_db['gpi']) &
                                                             (grp['brand_generic'] == formulary_db['brand_generic']) &
                                                             (grp['ddid'] == formulary_db['ddid']) &
                                                             (grp['drug_name'] == formulary_db['drug_name']))]

                        sub_record = formularynew_row['data_row'].values[0]
                        fileComp.append(sub_record, "pre")
                        save_frame = initialize_savedict(grp, cb_formulary_doc)
                        grp['ddid'] = save_frame['ddid']

                        save_frame = get_Novartis_accum_flags(novartis_proton_gpis, grp, save_frame)

                        save_frame['qtytodaysupplyratio_new'] = str(grp['qtytodaysupplyratio_new'])
                        save_frame = populate_qldetails(grp, save_frame)
                        save_frame = populate_additional_ql_values(quantitylimit_df, grp, save_frame)

                        # populate pa_formulary details
                        save_frame = get_padetails(grp, save_frame, paform_df)

                        save_frame = get_groupnum(grp, group_df, save_frame)

                        # populate value for alt_baseline_per_unit
                        altbaseline_value = get_altbaselineprice(grp, save_frame['drug_name'], altdrugddcbase_df)

                        # populate the company formulary
                        logger.info(f"altbase value for gpi:{grp['gpi']} brandgen: " +
                                    f"{grp['brand_generic']} drug: {save_frame['drug_name']}" +
                                    f" = {altbaseline_value}")

                        # update company formulary
                        if (len(plan_year) != 0 and a_plan_name is not None):
                            if search_by == 'both':
                                by_type = search_by
                            else:
                                by_type = 'planname'
                        else:
                            by_type = 'year'

                        if cmdline_rec['removeold'] is not None and cmdline_rec['removeold'] == 'Y':
                            (save_frame['company_formulary'],
                             data_validation) = remove_old_plandetails(dn, grp,
                                                                       save_frame['company_formulary'],
                                                                       data_validation,
                                                                       planyear=plan_year,
                                                                       planname=a_plan_name,
                                                                       by_type=by_type)

                        oper = company_exists(dn, save_frame['company_formulary'],
                                              planyear=plan_year,
                                              planname=a_plan_name,
                                              by_type=by_type)

                        (save_frame, data_validation) = populate_companydetails(plan_info, grp,
                                                                                altbaseline_value,
                                                                                drug_notcovered_df,
                                                                                data_validation,
                                                                                mode=oper,
                                                                                presentrec=save_frame,
                                                                                update=True)

                        fileComp.append(save_frame, 'post')
                        (new_rec, records_unprocessed) = save_information(cb, logger, save_frame, mode,
                                                                          records_unprocessed,
                                                                          formularynew_row['id'].values[0])

                    else:
                        # record was not present in couchbase
                        fileComp.append({'record': 'not present'}, "pre")
                        save_frame = initialize_savedict(grp, cb_formulary_doc)
                        save_frame = get_Novartis_accum_flags(novartis_proton_gpis, grp, save_frame)

                        save_frame['qtytodaysupplyratio_new'] = str(grp['qtytodaysupplyratio_new'])
                        save_frame = populate_qldetails(grp, save_frame)
                        save_frame = populate_additional_ql_values(quantitylimit_df, grp, save_frame)

                        # populate pa_formulary details
                        save_frame = get_padetails(grp, save_frame, paform_df)

                        save_frame = get_groupnum(grp, group_df, save_frame)

                        # populate value for alt_baseline_per_unit
                        altbaseline_value = get_altbaselineprice(grp, save_frame['drug_name'], altdrugddcbase_df)

                        # populate the company formulary
                        logger.info(f"altbase value for gpi:{grp['gpi']} brandgen: " +
                                    f"{grp['brand_generic']} drug: {save_frame['drug_name']}" +
                                    f" = {altbaseline_value}")

                        (save_frame, data_validation) = populate_companydetails(plan_info, grp,
                                                                                altbaseline_value,
                                                                                drug_notcovered_df,
                                                                                data_validation,
                                                                                presentrec=save_frame)

                        fileComp.append(save_frame, 'post')
                        (new_rec, records_unprocessed) = save_information(cb, logger, save_frame, mode,
                                                                          records_unprocessed, None)
                    # end - no records present in the formulary_db
                    continue
                # use ddid from formulary file
            # end loop
            print("Done\n")
        # end - update existing records

        write_final_tally(errored_records_fn, records_unprocessed)
    else:
        print('No Plans to be updated to Couchbase Formulary Document!!')
        logger.warning("No Plans to be updated to Couchbase Formulary Document!!")
        sys.exit(-1)

    # save out the compare files
    fileComp.write('pre')
    fileComp.write('post')

    try:
        del data_validation['changed_rec']
    except KeyError:
        pass

    if (fileComp.compare_files() is True):
        print("\n" + f"Compare file: {fileComp.comp_file}" + "\n\n")


    # update rxplanmaster and set update_formulary_flag to 'N' for all records
    logger.info("Set the update_formulary_flag='N' for all company.")
    cb.n1ql_query(N1QLQuery('update `' + os.environ['CB_INSTANCE'] + '` set update_formulary_flag="N" ' +
                                'WHERE type="rxplan_master" ')).execute()

    logger.info(f'Data validation metrics in {mode} mode.')
    for key in sorted(data_validation):
        tkey = key.replace('_', ' ')
        if isinstance(data_validation[key], int):
            logger.info(f"\t* {tkey}: {data_validation[key]}")
        else:
            logger.info(f"\t* {tkey}:")
            for row in range(len(data_validation[key])):
                logger.info(f"\t\t{data_validation[key][row]}")
            logger.info("\n")

    logger.info("End time is " + str(datetime.now()) + "\n")
    logger.info("==============================================================\n")

    # flush all DF memory
    del drugdb_df
    del source_formulary
    del formulary_db
    del altdrugddcbase_df
    del paform_df

    finish_run = datetime.now()

    s3_loc = ''
    if os.environ['INSTANCE_TYPE'] in ('DEV', 'STAGE', 'QA'):
        s3_loc = 'flipt-xfer-nonprod'
    else:
        s3_loc = 'flipt-xfer-prod'

    subject = f' :Formulary Add/Update for {dn} - Completed'
    body_statement = "Dear Admin Team,<br><br>Processing of Formulary Update file: "
    body_statement += f"{dn_data_file} <br>for domain: {dn} "
    body_statement += f"completed at {str(datetime.now())}.<br><br>  Below are the summary:<br><ul>"
    body_statement += '<li>Number of records inserted/updated: ' + str(UPDATED_REC_COUNT) + "</li>"
    body_statement += "<li>Number of records unprocessed: " + str(ERRORED_REC_COUNT) + "</li>"
    body_statement += "<li>Number of duplicate records: " + str(DUPLICATE_REC_COUNT) + "</li>"
    if ADDED_REC_COUNT > 0:
        body_statement += "<li>New records added: " + str(ADDED_REC_COUNT) + "</li>"

    for key in data_validation:
        if isinstance(data_validation[key], list):
            continue
        else:
            body_statement += f"<li>{key.replace('_', ' ')}: {data_validation[key]}</li>"

    body_statement += f"</ul><br>Total execution time: {(finish_run - start_run)}.<br><br>"
    body_statement += f"Please review the log file on S3 -> {s3_loc} -> {sftp_hndlr.sftp_user} -> archive -> "
    body_statement += f"{os.path.basename(logger.handlers[0].baseFilename)}.<br>"

    # email the results
    email_log_custombody('noreply@fliptrx.com', 'FliptIntegration@fliptrx.com', None,
                    subject, body_statement, '', attached=False)

    # transfer files to archive if final mode
    # get new sftp handle
    if mode.lower() == 'final':
        sftp_hndlr = AWS_SFTP(dn, 'FORMULARY')
        for fname in excel_files:
            stat, _ = sftp_hndlr.sftptransfer(fname, None, 'PUT', loghndl=logger)
            if stat == 'S':
                # remove file from sftp /local
                stat, _ = sftp_hndlr.sftpremove(os.path.basename(fname), loghndl=logger)

                # remove file from local path: ~/FLIPTB2B/data/FORMULARY/
                try:
                    os.unlink(fname)
                except FileNotFoundError:
                    pass
        # end loop

    # transfer log and error file and delete it
    if mode.lower() == 'final':
        sftp_hndlr.sftptransfer(errored_records_fn, sftp_hndlr.sftp_download, 'PUT')
        sftp_hndlr.sftptransfer(logger.handlers[0].baseFilename, sftp_hndlr.sftp_download, 'PUT')
        os.unlink(errored_records_fn)
        os.unlink(logger.handlers[0].baseFilename)
    # close the sftp connections
    sftp_hndlr.sftp_close()
# end main
