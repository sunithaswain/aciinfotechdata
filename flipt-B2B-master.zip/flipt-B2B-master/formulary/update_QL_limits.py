#!/usr/bin/env python
########################################
# title         : update_QL_limits.py
# description   : Update formulary document with changes from xlsx file
#                 for QL_Ratio, DOS_limit, and fill_per_year.
# author        : Rajesh A.
# date created  : 2020-02-14
# date last modified :
# version       : 0.1
# maintainer    :
# email         : racharya@fliptrx.com
# status        : Dev
# Python Version: 3.6.8
# usage         : [python] update_QL_limits.py -d GWLABS001 -t formulary -m DRAFT -y plan_year
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#
# #######################################

from formulary.formulary_functions import *

cb_formulary_doc = 'formulary_DOMAIN_new'


if __name__ == '__main__':
    import os
    import pandas as pd
    from utils.sendgridemail import email_log
    from utils.helper_functions import *
    from utils.file_comp_log import FileComp
    from couchbase.n1ql import N1QLQuery
    from utils.aws_sftp import *

    # dn, filetype, filename, mode = commandline.main(sys.argv[1:])
    cmdline_rec = process_alt_cmdline(additional=[['-d', '--domain', 'pass in the domain name (company)', True],
                                                  ['-t', '--file_type', 'pass in the couchbase document type', True],
                                                  ['-c', '--change_all', 'change for all domains', False],
                                                  ['-y', '--plan_year',
                                                   'update specific plan year (can be comma-delimited', False],
                                                  ['-l', '--load_table', 'load an alternate table', False]])

    mode = cmdline_rec['mode']
    domain_name = cmdline_rec['domain']
    if (cmdline_rec['change_all'] is not None and cmdline_rec['change_all'].upper() == 'Y'):
        cmdline_rec['plan_year'] = ''
    else:
        cmdline_rec['change_all'] = 'N'

    # changes specific for building formulary specific to a domain
    # set formulary document to use domain specific formulary
    cb_formulary_doc = cb_formulary_doc.replace('DOMAIN', domain_name)

    loc_path = os.environ['CB_DATA']
    logpath = os.environ['LOGDIR']

    if cmdline_rec['load_table'] is not None:
        cb_formulary_doc = cmdline_rec['load_table']

    if cmdline_rec['plan_year'] is None:
        plan_year = [datetime.now().strftime("%Y")]
    else:
        plan_year = cmdline_rec['plan_year']

    # get Couchbase handle to the bucket
    cb = cb_authenticate()

    log_timestamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")

    # check if sormulary table exists
    if check_doc_exists(cb, cb_formulary_doc) is False:
        print(f"ERROR: Aborting - < {cb_formulary_doc} > does not exists on the couchbase server")
        sys.exit(-1)

    logger = setup_logging_path('FORMULARY', f'{domain_name}_{cb_formulary_doc}_{log_timestamp}',
                                cb_formulary_doc.upper())
    logger.info("=================== Formulary Update Log =====================")
    start_time = datetime.now()

    # get files from ftp server
    dest_path = f"{loc_path}/FORMULARY"
    sftp_hndlr = AWS_SFTP(domain_name, 'FORMULARY')

    dest_dn_path = f"{dest_path}/{domain_name}/"
    try:
        os.stat(dest_dn_path)  # get directory properties
    except:
        os.mkdir(dest_dn_path)  # create directory if not present
        pass

    search_file = f"QuantityLimit_{domain_name}"
    stat, quantitylimit_fl = sftp_hndlr.sftptransfer(None, dest_dn_path + '/', 'GET',
                                                      searchstr=search_file, loghndl=logger)
    if stat == 'E':
        print("No files available for processing")
        display_error(f'File: {quantitylimit_fl} not found on SFTP server', loghndl=logger)

    quantitylimit_df = load_lookups(logger, f'{dest_dn_path}/{quantitylimit_fl}', 'Sheet1')
    quantitylimit_df['brand_generic'] = quantitylimit_df['brand_generic'].\
        apply(lambda x: brandgen_val(str(x).strip()))

    quantitylimit_df['gpi'] = quantitylimit_df['gpi'].apply(lambda x: str(x).zfill(14))
    quantitylimit_df['ddid'] = quantitylimit_df['ddid'].apply(lambda x: str(x).strip())
    quantitylimit_df['dos_limit'] = quantitylimit_df['dos_limit'].fillna('')
    quantitylimit_df['fill_per_year_limit'] = quantitylimit_df['fill_per_year_limit'].fillna('')
    quantitylimit_df.info()

    # extract columns for query
    gpi_list = list(quantitylimit_df['gpi'])
    ddid_list = list(quantitylimit_df['ddid'])
    brandgen_list = list(quantitylimit_df['brand_generic'])

    record_count = 0
    failed_count = 0
    subrec_count = 0
    sftp_hndlr.sftp_close()

    # loop through panda QL gpis
    print(f"File processing started at: {start_time}")
    logger.info(f"File processing started at: {start_time}")
    print(f"Plan year(s) provided: {plan_year}")
    logger.info(f"Plan year(s) provided: {plan_year}")

    formulary_update_rows = dict()
    source_formulary_document = read_couchbase_source(cb, cb_formulary_doc,
                                                      key_cols=['gpi', 'ddid', 'brand_generic'],
                                                      loghndl=logger)
    source_formulary_document.info()

    process_start = datetime.now()
    print(f"Update processing started @{process_start} ...")
    for index, ql_row in quantitylimit_df.iterrows():
        if ((ql_row['gpi'] == source_formulary_document['gpi']) &
            (ql_row['brand_generic'] == source_formulary_document['brand_generic']) &
            (ql_row['ddid'] == source_formulary_document['ddid'])).any() == True:
            formulary_row = source_formulary_document.loc[((ql_row['gpi'] == source_formulary_document['gpi']) &
                                        (ql_row['brand_generic'] == source_formulary_document['brand_generic']) &
                                        (ql_row['ddid'] == source_formulary_document['ddid']))]

            sub_record = formulary_row['data_row'].values[0]

            try:
                if cmdline_rec['change_all'].upper() == 'Y':
                    found_row = sub_record['company_formulary']
                else:
                    found_row = fetch_cf_row(domain_name, plan_year, sub_record['company_formulary'])
                subrec_count += len(found_row)

                for company_row in found_row:
                    for key_val in ['ql_ratio', 'dos_limit', 'fill_per_year_limit']:
                        company_row[key_val] = ql_row[key_val]
                    # end update keys
                # end company_row

                # end loop for multiple plan update
                date_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                sub_record['updated_date'] = date_time

                formulary_update_rows[formulary_row['id'].values[0]] = sub_record
                record_count += 1

            except TypeError:
               logger.warning(f"No record found in < {cb_formulary_doc} > for GPI={ql_row['gpi']} and DDID={ql_row['ddid']}!!")
               failed_count += 1

    # end loop
    process_finish = datetime.now()
    print(f"Update processing completed at: {process_finish} -  Elapsed time: {process_finish - process_start}")

    if mode.lower() == 'final': 
        if len(formulary_update_rows) > 0:
           couchbase_batch_update(cb, cb_formulary_doc, formulary_update_rows,
                               log_handle=logger)
        else:
           logger.error("Something is wrong! No rows for updated due to some error.")
           print("ERROR: Something is wrong! No rows for updated due to some error.")
           sys.exit(-1)
    else:
        print("Ran in draft mode. Nothing updated in couchbase!")
    # end

    logger.info(f"Number of sub-records processed: {subrec_count}")
    print(f"Number of sub-records processed: {subrec_count}")
    logger.info(f"Number of records processed: {record_count}")
    print(f"Number of records processed: {record_count}")
    logger.info(f"Number of records failed: {failed_count}")
    print(f"Number of records failed: {failed_count}")

    # transfer files to archive if final mode
    # get new sftp handle
    sftp_hndlr = AWS_SFTP(domain_name, 'FORMULARY')
    if mode.lower() == 'final':
        stat, _ = sftp_hndlr.sftptransfer(dest_dn_path + quantitylimit_fl, None, 'PUT', loghndl=logger)
        if stat == 'S':
            # remove file from sftp /local
            stat, _ = sftp_hndlr.sftpremove(quantitylimit_fl, loghndl=logger)

            # remove file from local path: ~/FLIPTB2B/data/FORMULARY/
            try:
                os.unlink(dest_dn_path + quantitylimit_fl)
            except FileNotFoundError:
                pass

    # transfer log and error file and delete it
    if mode.lower() == 'final':
        sftp_hndlr.sftptransfer(logger.handlers[0].baseFilename, sftp_hndlr.sftp_download, 'PUT')
        os.unlink(logger.handlers[0].baseFilename)

    # close the sftp connections
    sftp_hndlr.sftp_close()

    finish_time = datetime.now()
    print(f"\nFile processing completed at: {finish_time}")
    logger.info(f"File processing completed at: {finish_time}")
    print(f"Total elapsed time for job: {(finish_time - start_time)}")
    logger.info(f"Total elapsed time for job: {(finish_time - start_time)}")
# end main
