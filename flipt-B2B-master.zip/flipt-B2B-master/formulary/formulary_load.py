########################################
# !/usr/bin/env python
# title         : formulary_load.py
# description   : Update formulary document from file data
# author        : Disha
# date created  : 20180101
# date last modified    : 20181212
# version       : 0.1
# maintainer    : Pal
# email         : pmuthanai@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage         : python formulary_load.py -d GWLABS001 -t formulary -f Formulary_Load_sample.xlsx -m DRAFT
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
# #######################################


from couchbase import FMT_JSON
from datetime import datetime
import sys
import os
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Cluster
from couchbase.n1ql import N1QLQuery
import pandas as pd

if __name__ == '__main__':
    import os
    import sys
    rootdir = os.path.dirname(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))))
    sys.path.append(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']

from utils import commandline
dn, filetype, filename, mode = commandline.main(sys.argv[1:])
cluster = Cluster(os.environ['CB_URL']+'?operation_timeout=2700')
auth = PasswordAuthenticator(
    os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(auth)
bucket_name = os.environ['CB_INSTANCE']
cb = cluster.open_bucket(bucket_name)
form = pd.read_excel(path+'//'+dn+'//'+filetype+'//' +
                     filename, sheet_name='G&W DDC Baselines')
form.fillna("", inplace=True)

form['GPI'] = form['GPI'].apply(lambda x: str(x).zfill(14))
domainlist = [dn]
if dn == 'GWLABS001':
    domainlist = [dn, 'FLIPT001']
'''
query1 = N1QLQuery('SELECT META().id as id,gpi,brand_generic,create_date FROM `' +
                      os.environ['CB_INSTANCE']+'` WHERE type="formulary" and company in $domain', domain=domainlist)
query1.timeout = 7200
for r in cb.n1ql_query(query1):
    print('GPI value',r['gpi'])
    print('ID',r['id']) 
    sys.exit()
'''
for i, r in form.iterrows():
    d = {}
    for c in list(form):
        d[c.lower().strip().replace(' ', '_')] = str(r[c])
    for dnrow in domainlist:

        print('altbaselinevalue', d["gold_ddc_baseline_per_unit"])
        print('domain name', dnrow)
        print('GPI', d['gpi'])
        print('Brandgeneric', d['g/t'].strip())

        if mode.upper().strip() == 'FINAL':
            query = N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` set alt_baseline_per_unit = $alt_baseline WHERE type="formulary" and company= $dname and gpi=$gpi and brand_generic=$bgnc',
                              dname=dnrow, gpi=d['gpi'], bgnc=d['g/t'].strip(), alt_baseline=d["gold_ddc_baseline_per_unit"])
            query.timeout = 3600
            cb.n1ql_query(query).execute()
            # sys.exit()
        else:
            print('No update done')

print('Formulary Updated')
