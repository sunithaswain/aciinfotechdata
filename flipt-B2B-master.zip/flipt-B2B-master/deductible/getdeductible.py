########################################
# !/usr/bin/env python  
# title         : getdeductible.py
# description   : 
# author        : Disha
# date created  : 20190410
# date last modified    :  
# version       : 0.1
# maintainer    : Hari
# email         : -
# status        : Production
# Python Version: 3.5.2
# usage			: 
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  1.1				Hari		10/04/2019	Code modified based on git folder structure
# #######################################
if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   
import sys
import os
from datetime import datetime
import dateutil.parser as parser
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery

from utils import commandline
from utils.truevault import User_Class

class Deductible(object):

	def __init__(self,rx_flipt_person_id=None,flipt_person_id=None,deductible_amount=0):
		self.rx_flipt_person_id=rx_flipt_person_id
		self.flipt_person_id=flipt_person_id
		self.deductible_amount=deductible_amount

	def get_deductible_remaining(self):

		opc_remaining = 0

		#db connections
		cluster = Cluster(os.environ['CB_URL'])
		authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
		cluster.authenticate(authenticator)
		cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
		path = os.environ['CB_DATA']

		#get employee info
		user_obj=User_Class(None,None)
		search_option={'full_document':True,'filter':{'flipt_person_id':{'type':'eq','value':self.flipt_person_id,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
		att,userid=user_obj.search_user(search_option)

		if att!=None:
			coverage_tier_name=att['coverage_tier_name']
			plan_name=att['benefit_plan_name']
			
			#get rx plan info
			rxplanquery = N1QLQuery("Select * from `"+os.environ['CB_INSTANCE']+"` where type='rxplan_master' and plan_name=$pn and domain_name=$dmn and plan_year=$py",pn=plan_name,dmn=att['domain_name'],py=str(datetime.now().year))
			rxplaninfo = {}
			for result in cb.n1ql_query(rxplanquery):
				rxplaninfo.update(result[os.environ['CB_INSTANCE']])
			#print(rxplaninfo,coverage_tier_name,'---')
			#Core Plan
			if rxplaninfo['deductible_exempted'] == 'Y':
				return 0
				
			#HSA Value Plan
			if rxplaninfo['individual_deductible_embedded'] == 'N':
				
				if 'Employee and' in coverage_tier_name:
					deductiblequery = N1QLQuery("Select sum(tonumber(deductible_accrued)) deductible_accrued from `"+os.environ['CB_INSTANCE']+"` where type='deductible' and emp_flipt_person_id=$efid and plan_year=$py",efid = self.flipt_person_id,py=str(datetime.now().year))
					deductible_accrued = 0
					for result in cb.n1ql_query(deductiblequery):
						deductible_accrued = result['deductible_accrued']-self.deductible_amount
						
					return max(0,int(rxplaninfo['annual_deductible_family'])-deductible_accrued)
					
				else:
					deductiblequery = N1QLQuery("Select tonumber(deductible_accrued) deductible_accrued from `"+os.environ['CB_INSTANCE']+"` where type='deductible' and dep_flipt_person_id=$efid and plan_year=$py",efid=self.flipt_person_id,py=str(datetime.now().year))
					deductible_accrued = 0
					for result in cb.n1ql_query(deductiblequery):
						deductible_accrued = result['deductible_accrued']-self.deductible_amount
						
					return max(0,int(rxplaninfo['annual_deductible_individual'])-deductible_accrued)
			#HSA Max Value Plan		
			else:
				
				if 'Employee and' in coverage_tier_name:
					deductiblequery = N1QLQuery("Select sum(tonumber(deductible_accrued)) deductible_accrued from `"+os.environ['CB_INSTANCE']+"` where type='deductible' and emp_flipt_person_id=$efid and plan_year=$py",efid=self.flipt_person_id,py=str(datetime.now().year))
					deductible_accrued = 0
					for result in cb.n1ql_query(deductiblequery):
						deductible_accrued = result['deductible_accrued']-self.deductible_amount
						
					if int(rxplaninfo['annual_deductible_family'])-deductible_accrued<=0:
						return 0
					else:
						deductiblequery = N1QLQuery("Select tonumber(deductible_accrued) deductible_accrued from `"+os.environ['CB_INSTANCE']+"` where type='deductible' and dep_flipt_person_id=$efid and plan_year=$py",efid=self.rx_flipt_person_id,py=str(datetime.now().year))
						deductible_accrued = 0
						for result in cb.n1ql_query(deductiblequery):
							deductible_accrued = result['deductible_accrued']-self.deductible_amount
							
						return max(0,int(rxplaninfo['annual_deductible_individual'])-deductible_accrued)
					
				else:
					deductiblequery = N1QLQuery("Select tonumber(deductible_accrued) deductible_accrued from `"+os.environ['CB_INSTANCE']+"` where type='deductible' and dep_flipt_person_id=$efid and plan_year=$py",efid=self.flipt_person_id,py=str(datetime.now().year))
					deductible_accrued = 0
					for result in cb.n1ql_query(deductiblequery):
						deductible_accrued = result['deductible_accrued']-self.deductible_amount
						
					return max(0,int(rxplaninfo['annual_deductible_individual'])-deductible_accrued)
					





