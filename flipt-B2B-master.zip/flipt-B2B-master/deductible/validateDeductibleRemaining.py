########################################
# !/usr/bin/env python 

# title : validateDeductibleRemaining.py
# description : Generates report validating deductible remaining calculated by the App for all filled scripts in preveious week
# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  python validateDeductibleRemaining.py -d GWLABS001 -t deductible -s 01-JAN-2019 -e 19-FEB-2019

# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


# #######################################
if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   

import sys
import os, re
import pandas as pd
import dateutil.parser as parser
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
import datetime
from getdeductible import Deductible

from utils import opccmdline
from utils.sendgridemail import email_log

domain,file_type,file_name,mode,start_date,end_date = opccmdline.main(sys.argv[1:])
if start_date!=None:
	start_date = parser.parse(start_date)
	start_date = start_date.isoformat()
	end_date = end_date+' 23:59:59'
	end_date = parser.parse(end_date)
	end_date = end_date.isoformat()
'''
else:
	if datetime.datetime.weekday()!=0: exit()
	start_date=datetime.datetime.now().isoformat()
	end_date=(datetime.datetime.now()-datetime.timedelta(7)).isoformat()
'''
cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
path = os.environ['CB_DATA']


def validation():
	print('Begin')
	df = pd.DataFrame()
	prescquery = N1QLQuery("Select rx_flipt_person_id,tonumber(deductible_remaining) deductible_remaining,out_of_pocket_remaining,prescription_id,routed_date,employee_opc,member_id,filled_date from `"+os.environ['CB_INSTANCE']+"` where type='prescription' and rx_status='Filled' and filled_date>=$sd and filled_date<$ed and drug_deductible_exempt='false' order by routed_date ",sd=start_date,ed=end_date)
	for result in cb.n1ql_query(prescquery):
		#print(result)
		#print(result['prescription_id'])
		try:
			deductible_amount = 0
			prescquery2 = N1QLQuery("Select sum(tonumber(employee_opc)) employee_opc from `"+os.environ['CB_INSTANCE']+"` where type='prescription' and rx_flipt_person_id=$rxid and filled_date>=$sd and filled_date<$ed and drug_deductible_exempt='false' and routed_date>$fd and rx_status='Filled'",sd=start_date,ed=end_date,fd=result['filled_date'],rxid=result['rx_flipt_person_id'])
			for result1 in cb.n1ql_query(prescquery2):
				try:
					deductible_amount = round(result1['employee_opc'])
				except Exception as e:
					deductible_amount = 0
			obj = Deductible(result['rx_flipt_person_id'],result['member_id'][:7],deductible_amount)
			deductible_remaining = obj.get_deductible_remaining()
			#print(deductible_remaining,result['deductible_remaining'])
			if (round(deductible_remaining)==0 and round(result['deductible_remaining'])!=0) or (round(deductible_remaining)!=0 and round(result['deductible_remaining'])==0):
				df=df.append({'Rx ID':result['prescription_id'],'Patient Flipt Person ID':result['rx_flipt_person_id'],'Actual Deductible Remaining':deductible_remaining,'Calc. Deductible Remaining':result['deductible_remaining']},ignore_index=True)
		except Exception as e1:
			print(e1,result)
	if len(df)>0 or not df.empty:
		time_now = re.sub('[\s\-\:]', '', str(datetime.datetime.now()))
		filepath = path+"//"+domain+"//"+file_type+"//log//DeductibleValidationLog"+time_now+".csv"
		df.to_csv(filepath,index=False)
		email_log('DWagle@fliptrx.com','Dwagle@fliptrx.com',None,'Deductible Remaining Validation - Completed',['Validation of Deductible Remaining ','Prescription Exception'],filepath,True)
	else:
		email_log('DWagle@fliptrx.com','Dwagle@fliptrx.com',None,'Deductible Remaining Validation (No Issues)',['Validation of Deductible Remaining ','Prescription Exception'],'',False)
		
validation()	
	
	
	
	
	
	