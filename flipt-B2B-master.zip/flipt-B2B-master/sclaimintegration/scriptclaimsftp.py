import paramiko
import sys
import traceback
import sendgrid
import os
import fnmatch
import socket
from sendgrid.helpers.mail import Email, Content, Attachment, Substitution, Mail
import urllib.request as urllib
import base64
from datetime import datetime, timedelta
from utils.sendgridemail import email_log_custom

ftpuser = os.environ['SCFTPUSER']
ftppwd = os.environ['SCFTPPWD']
ftphost = os.environ['SCFTPHOST']
port = os.environ['SCFTPPORT']
status = ''
sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))


class FastTransport(paramiko.Transport):
    def __init__(self, sock):
        super(FastTransport, self).__init__(sock)
        self.window_size = 2147483647
        self.packetizer.REKEY_BYTES = pow(2, 40)
        self.packetizer.REKEY_PACKETS = pow(2, 40)


transport = FastTransport((ftphost, 22))
try:
    transport.connect(username=ftpuser, password=ftppwd)
except Exception as e:
    type, value, etraceback = sys.exc_info()
    error = ""
    x = traceback.format_exception(type, value, etraceback)
    for i in x:
        error = error+i
    content_ = 'Dear Admin Team,\n We are not able to connect to the Script Claim server while we perform an SFTP transfer. An exception ' + \
        str(error)+' stops this process. Kindly look into this issue.\n \n Best regards,\n FLIPT Integration Team'
    content = Content("text/plain", content_)
    mail = Mail(Email('noreply@fliptrx.com'), 'ALERT: Script Claim SFTP Connectivity Failure',
                Email('SSubramani@GWLabs.com'), content)
    host = socket.gethostname()
    receiver2 = ['SPal@fliptrx.com', 'DWagle@fliptrx.com']
    hostnameprod = 'newprod-python-e1a'
    if host == hostnameprod:
        receiver2 = ['SPal@fliptrx.com', 'DWagle@fliptrx.com',
                     'hkumar@fliptrx.com', 'ehart@script-claim.com', 'mattg@nbfsa.com']
    for i in receiver2:
        mail.personalizations[0].add_to(Email(i))
    response = sg.client.mail.send.post(request_body=mail.get())
    exit()

sftp = paramiko.SFTPClient.from_transport(transport)


def sftptransfer(source, destination, mode):

    if mode == 'PUT':
        sftp.put(source, destination)

        try:
            fileatt = sftp.lstat(destination)

            #print (fileatt)
            status = 'S'
            print('Upload Successful.')
        except IOError:
            status = 'E'
            print('File not Found in Remote')

    elif mode == 'GET':
        try:
            sftp.get(source, destination)
            status = 'S'
            print('Download Successful...')
            # sftp.remove(source)
        except IOError:
            status = 'E'
            print('File not transferred Successfully')

    sftp.close()
    transport.close()

    return status


def fileexists(filepath):

    transport = paramiko.Transport((ftphost, 22))
    transport.connect(username=ftpuser, password=ftppwd)
    sftp = paramiko.SFTPClient.from_transport(transport)

    try:
        fileatt = sftp.lstat(filepath)
        print(fileatt)
        status = 'S'
        print('File Exists')
    except IOError:
        status = 'E'
        print('File not Found in Local Directory')

    sftp.close()
    transport.close()
    return status


def multiplefilesftptransfer(source, destination, mode):
    status = 'U'
    print(source)
    filelist = sftp.listdir(path=source+'/')
    print(filelist)
    print(destination)
    if mode == 'GET':
        try:
            filelist = sftp.listdir(path=source+'/')
            print(filelist)

            for afile in filelist:
                if afile == 'archive':
                    continue
                print(source+'/'+afile)
                print(destination+afile)
                sftp.get(source+'/'+afile, destination+afile)
                # if not os.path.isdir(source+'Archive'):
                # 	os.makedirs(source+'Archive')
                sftp.put(destination+afile, source+'Archive/'+afile)
                sftp.remove(source+'/'+afile)
                status = 'S'
        except Exception as e:
            print(e)
            status = 'E'
            print('File not Found in Local Directory')

    sftp.close()
    transport.close()
    return filelist, status


def multiplefilesftptransfer_noarchive(source, destination, mode):
    status = 'U'
    print(source)
    if mode == 'GET':
        try:
            filelist = sftp.listdir(path=source+'/')
            print(filelist)
            for afile in filelist:
                sftp.get(source+'/'+afile, destination+afile)
                sftp.remove(source+'/'+afile)
                status = 'S'
        except IOError:
            status = 'E'
            print('File not Found in Local Directory')

    sftp.close()
    transport.close()
    return filelist, status


def filesftptransfer_noarchive(source, destination, mode):
    status = 'U'
    print(source)
    if mode == 'GET':
        try:
            filelist = sftp.listdir(path=source+'/')
            print(filelist)
            for afile in filelist:
                sftp.get(source+'/'+afile, destination+afile)
                # sftp.remove(source+'/'+afile)
                status = 'S'
        except IOError:
            status = 'E'
            print('File not Found in Local Directory')

    sftp.close()
    transport.close()
    return filelist, status


def getfilemodifiedtime(destination):

    filelist = []

    attributes = sftp.listdir_attr(path=destination+'/')
    for f in attributes:
        last_modified = datetime.fromtimestamp(f.st_mtime)
        if (datetime.now()-last_modified) >= timedelta(minutes=5):
            filelist.append(f.filename)
    if len(filelist) > 0:
        if os.environ['INSTANCE_TYPE'] == 'PROD':
            email_log_custom('noreply@fliptrx.com', 'SSubramani@fliptrx.com', 'SPal@fliptrx.com,DWagle@fliptrx.com,ehart@script-claim.com,Deepthi.gollapudi@nttdata.com,mahaboob11.basha@nttdata.com',
                             'Prescription Files not processed', [str(len(filelist))+' Prescription files uploaded to ScriptClaim SFTP server have not been processed yet.'], None, False)


def filesftptransfer_witharchive(source, destination, prefix_match, isfinal):
    status = 'U'
    print(source)
    filelist = sftp.listdir(path=source+'/')
    print(filelist)
    print(destination)
    try:
        filelist = sftp.listdir(path=source+'/')
        print(filelist)
        for afile in filelist:
            if fnmatch.fnmatch(afile, prefix_match):
                sftp.get(source+'/'+afile, destination+afile)
                if isfinal.upper().strip() == 'FINAL':
                    if not os.path.isdir(source+'Archive/'):
                        os.makedirs(source+'Archive/')
                    sftp.put(destination+afile, source+'Archive/'+afile)
                    sftp.remove(source+'/'+afile)
            status = 'S'
    except Exception as e:
        print(e)
        status = 'E'
        print('File not Found in Local Directory')

    sftp.close()
    transport.close()
    return filelist, status
