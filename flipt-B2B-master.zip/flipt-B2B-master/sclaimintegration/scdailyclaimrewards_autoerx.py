########################################
# !/usr/bin/env python 

# title : scdailyclaimrewards_autoerx.py
# description : "Inbound file from ScriptClaim getting details 
				# about status of a prescription transaction being
				# filled/reversed/rejected by a pharmacy and 
				# more such processing details."


# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  python scdailyclaimrewards_autoerx.py -d GWLABS001 -t scdailyclaim -f SCS -m DRAFT
# Revisions:
# Version RevisedBy Date Change Jira description 
# ------- --------- -------- ------------------
# 1.1     Hari    19-feb-2019	B2B-288		'Phone number field being pulled from TrueVault is incorrect'
# 1.2	Deepthi		22-May-2019	B2B-651	'Reading an excel file from scriptclaims' 
# #######################################

from utils.helper_functions import *

transferstatus = ''
loadtype = 'I'
updatecount = 0


def couchbasedatarec_from_sclaimdata(row_data):
	sclaim_autoerx_mapping = {
		'AWPUnit': 'awp_unit', 	'AccountID': 'account',	'AccumDeduct': 'accum_deduct',
		'AdminFeeCollectable': 'admin_fee_collectable', 'AttribToDed': 'attrib_to_ded',
		'AuthorizationNumber': 'auth_id', 'BenMaxReset': 'ben_max_reset', 'BenMaxTot': 'ben_max_tot',
		'BenMaxTotFam': 'ben_max_tot_fam', 'BenMaxType': 'ben_max_type', 'BinNumber': 'bin',
		'COBOtherPayerCovType': 'cob_other_payer_covtype', 'COBOtherPaymentCount': 'cob_other_payment_count',
		'COBOtherPayerPatientResAmount': 'cob_other_payer_patient_resamt',
		'COBOtherPayerPatientResAmtCode': 'cob_other_payer_patient_resamt_code',
		'COBOtherPayerPatientResAmtCount': 'cob_other_payer_patient_resamt_count',
		'COBOtherPayerRejectCode': 'cob_other_payer_reject_code', 'CalcIngCost': 'calc_ing_cost',
		'CarrierID': 'carrier', 'ClaimCounter': 'claim_counter', 'ClaimSeqNumber': 'sequence_number',
		'ClaimsMasterCN': 'claims_master_cn', 'ClientAdminFee': 'client_admin_fee', 'ClientDispFee': 'client_disp_fee',
		'ClientDueAmt': 'client_due_amt', 'ClientIngCost': 'client_ing_cost', 'ClientMacListID': 'client_maclist_id',
		'ClientPriceRate': 'client_price_rate', 'ClientPriceTableID': 'client_price_table_id',
		'ClientPriceType': 'client_price_type', 'ClientUnitPrice': 'client_unit_price', 'CltMAC': 'client_mac_price',
		'CompoundCode': 'compound_code', 'ControlNumber': 'control_number', 'TransactionResponseStatus': 'claim_type',
		'CurrentSavings': 'current_savings', 'DAWCode': 'daw_code', 'DateOfService': 'date_of_service',
		'DateWritten': 'date_written', 'DaySupply': 'days_supply', 'DispFeePaid': 'disp_fee_paid',
		'DosageFormID': 'dosage_form_id', 'FamAccumDeduct': 'fam_accum_deduct', 'FamilyID': 'family_id',
		'FillNumber': 'fill_number', 'FormStatus': 'formulary_status', 'Formulary': 'formulary', 'GPICode': 'gpi_code',
		'GPIList': 'gpi_list', 'GPPC': 'gppc', 'GroupID': 'group', 'GroupMember': 'group_member',
		'IngCostPaid': 'ing_cost_paid', 'MacListID': 'mac_list_id', 'ManufactNameAbr': 'manuf_abr',
		'MultiSourceCode': 'multisource_code', 'CardholderID': 'member_id', 'NDCList': 'ndc_list',
		'SuperNetworkID': 'network_id', 'OPAmountPaid': 'op_amount_paid', 'OTCIndicator': 'otc_indicator',
		'OtherCoverageCode': 'other_coverage_code', 'PCN': 'pcn', 'PackSize': 'pack_size',
		'PatientCopayAmt': 'patient_copay_amt', 'PatientPC': 'person_code', 'PatientPay': 'patient_paid',
		'PatientCopayAmt': 'patient_copay_amt', 'PatientRC': 'rel_code', 'PatientTableID': 'patient_table_id',
		'PharmNetID': 'pharmacy_net_id', 'PharmPriceTable': 'pharmacy_price_table', 'PharmacyID': 'pharmacy_ncpdp',
		'PharmacyNPI': 'pharmacy_npi', 'PharmacyName': 'pharmacy_name', 'PharmacyPriceRate': 'pharmacy_price_rate',
		'PharmacyPriceType': 'pharmacy_price_type', 'PharmacyUnitPrice': 'pharmacy_unit_price',
		'PhrmMac': 'pharmacy_mac_price', 'PlanCodeID': 'plan_code_id', 'PrescriberNPI': 'prescriber_npi',
		'PrescriberNameFirst': 'prescriber_first_name', 'PrescriberNameLast': 'prescriber_last_name',
		'PrescriberNetwork': 'prescriber_network', 'PrescriptionNumber': 'rx_number',
		'PriorAuthNumber': 'prior_auth_number', 'ProductID': 'product_id_ndc', 'ProductNameAbr': 'product_name_abr',
		'ProductNameFull': 'product_name_full', 'ProductStrength': 'product_strength', 'ValidateCN': 'validate_cn',
		'QuantityDispensed': 'quantity_dispensed', 'RejectCode': 'reject_code', 'RejectCount': 'reject_count',
		'RouteOfAdmin': 'route_of_admin', 'SalesTxPd': 'sales_tax_paid', 'ScriptOriginCode': 'script_origin_code',
		'SubmittedDispFee': 'submitted_disp_fee', 'SubmittedGrossDue': 'submitted_gross_due',
		'SubmittedIngCost': 'submitted_ing_cost', 'SubmittedTaxSales': 'submitted_sales_tax',
		'SubmittedUandC': 'submitted_uc', 'TPECode': 'tpe_code', 'TotalCostPaid': 'amt_paid_to_pharmacy',
	}

	cb_datarec = {sclaim_autoerx_mapping[rk]: str(row_data[rk]).strip() for rk in sclaim_autoerx_mapping.keys()}
	return cb_datarec
# end function


def scriptclaimdailyclaim(sclaim_dict):
	import os
	import shutil
	import sys
	import traceback
	import pandas as pd
	import couchbase.subdocument as SD
	import dateutil.parser as parser

	from pathlib import Path
	from datetime import datetime
	from datetime import timedelta
	from utils.truevault import User_Class
	from couchbase import FMT_JSON
	from couchbase.n1ql import N1QLQuery
	from notification.twilioSendSMS import sendSMS
	from autoerx.getdrugprices_autoerx import get_drugprices
	from autoerx.autoerxcreation import create_erxcard
	from utils.sendgridemail import email_log
	from utils.sendgridemail import email_log_custom
	from sclaimintegration.scriptclaimsftp import multiplefilesftptransfer

	# FTP
	sclaim_dict['logger_handle'].info("Started scdailyclaimrewards")
	files = []

	# check directories present
	try:
		os.chdir(sclaim_dict['localpath'])
	except FileNotFoundError:
		os.makedirs(sclaim_dict['localpath'], exist_ok=True)
		os.mkdir(f"{sclaim_dict['localpath']}/log")

	try:
		os.chdir(sclaim_dict['archivepath'])
	except FileNotFoundError:
		os.mkdir(f"{sclaim_dict['localpath']}/archive")

	files,transferstatus = multiplefilesftptransfer(sclaim_dict['remotepath'],
													sclaim_dict['localpath'],
													'GET')
	print(transferstatus)
	sclaim_dict['logger_handle'].info(f"Retrieved file: {files}\tStatus: {transferstatus}")
	
	if transferstatus == 'S':
		# email_log('DWagle@fliptrx.com','DWagle@fliptrx.com','SSubramani@fliptrx.com',
		# 'Script Claim Daily Claim -Initiated',['Processing of Script Claim Daily Claim files '],None,False)
		
		for filename in files:
			filepath = f"{sclaim_dict['localpath']}/{filename}"
			sclaim_dict['logger_handle'].info(f"Processing file: {filepath}")
			fname = Path(filename).stem
			claimnum = 1

			daily_claim = pd.read_csv(filepath, sep="|", dtype=str)
			daily_claim['AuthorizationNumber'] = daily_claim['AuthorizationNumber'].apply(lambda x: str(x).zfill(13))
			daily_claim['BinNumber'] = daily_claim['BinNumber'].apply(lambda x: str(x).zfill(6))
			daily_claim.fillna("", inplace=True)

			for index,row in daily_claim.iterrows():
				try:
					archive_status = ''
					error_prescription = ''
					rec_status = 'INSERT'
					rewardsid = ''
					claim_status = ''
					rx_id = ''
					dcrecs = {}
					input_rec = ''
					log = f"{sclaim_dict['localpath']}/log/{fname}_{claimnum}.txt"

					claimnum = claimnum + 1
					logfile = open(log, "w")
					logfile.write("==========================================================" + "\r\n")
					logfile.write("================== Daily Claim Report ====================" + "\r\n")
					logfile.write("==========================================================" + "\r\n")
					prescription_status = ''
					prescount = 0
					rxcui = ''
					buffer_days = ''
					history_id = ''
					customercareactionmsg = set()
					patient_first_name = row["PatientFirstName"]
					patient_last_name = row["PatientLastName"]
					patient_age = row["PatientAge"]
					dob = row["DateOfBirth"]
					gender = row["PatientGenderCode"]
					member_id = row['CardholderID']

					claim_date = str(row["TimeItHappened"])
					if (str(claim_date).strip()) == '':
						continue

					claim_date = parser.parse(claim_date)
					filled_dt = claim_date
					claim_date = claim_date.isoformat()

					dcrecs = couchbasedatarec_from_sclaimdata(row)
					dcrecs['pharmacy_rejection_reason'] = str(row["RejectMessage1"]) + ' ' + str(row["RejectMessage2"])
					dcrecs['claim_date'] = claim_date
					domain = dcrecs['account']

					if row["TransactionID"] == '':
						transaction_id = str(row["TransactionID"]).strip()
					else:
						transaction_id = str(int(row["TransactionID"])).strip()
						print('TransactionID', transaction_id)

					claim_flipt_person_id = ''
					
					#All values from input file and assigned to dictionary dcrecs
					dcrecs['create_date'] = sclaim_dict['currentdate']
					dcrecs['update_date'] = sclaim_dict['currentdate']
					dcrecs['created_by'] = 'ScriptClaim'
					dcrecs['updated_by'] = 'ScriptClaim'
					dcrecs['transaction_id'] = "prescription::"+str(transaction_id).strip()
					prescription_id = dcrecs['transaction_id']
					input_rec = str(dcrecs)
					dcrecs['type'] = 'scdailyclaim'
					dcrecs['status'] = 'NEW'
					dcrecs['message'] = "Imported Successfully"

					member_id = str(member_id).strip().zfill(9)
					e_flipt_person_id = member_id[0:7]
					claim_type = dcrecs['claim_type']
					auth_id = dcrecs['auth_id']

					if str(claim_type).strip() == 'P':
						claim_status = 'Processed'
					elif str(claim_type).strip() == 'X':
						claim_status = 'Cancelled'
					elif str(claim_type).strip() == 'R':
						claim_status = 'Rejected'	
					print('claim type read:', claim_type)

					if str(transaction_id).strip() == "":
						logfile.write("Flipt Prescription ID        : No Transaction # Found"+"\r\n")
					else:
						logfile.write("Flipt Prescription ID        : " + str(transaction_id).strip() + "\r\n")
					
					logfile.write("Claim date                   : " + str(filled_dt).strip() + " EST" + "\r\n")
					logfile.write("Script Claim Authorization # : " + str(auth_id).strip() + "\r\n")
					logfile.write("Pharmacy Rx Number           : " + dcrecs['rx_number'] + "\r\n")
					logfile.write("Claim Status                 : " + str(claim_status).strip() + "\r\n")
					logfile.write("Rejection Reason Code        : " + dcrecs['pharmacy_rejection_reason'] + "\r\n")
					logfile.write("Member ID                    : " + str(member_id).strip() + "\r\n")
					if 'cost exceeds maximum' in dcrecs['pharmacy_rejection_reason'].lower():
						customercareactionmsg.add("Drug cost exceeds tolerance limit. Contact pricing team to " +
												  "investigate and then call script claims with decision.")
					
					query = N1QLQuery("Select otc_indicator from `" + os.environ['CB_INSTANCE'] +
									  "` where type='ndc_drugs' and ndc=$ndc and otc_indicator!='R' " +
									  "and 'N' in (Select raw b.otc_drug_covered from `" +
					                  os.environ['CB_INSTANCE'] + "` b where b.type='domain' " +
									  "and b.domain=$dn )", ndc=dcrecs['product_id_ndc'],
									  dn=dcrecs['account'])
					otcdrugnotcovered = False
					sclaim_dict['otc_indicator'] = 'R'
					for res in sclaim_dict['cb_handle'].n1ql_query(query):
						customercareactionmsg.add("OTC Drug not covered.")
						logfile.close()
						emailreport(pharmacy_npi, customercareactionmsg,
						            claim_type, filepath, filename, log)
						otcdrugnotcovered = True
						sclaim_dict['otc_indicator'] = 'O'
					if otcdrugnotcovered:
						continue
					
					claimtype_p = False
					claim_cdate = ''
					claimtab = N1QLQuery('select status, create_date from `' + os.environ['CB_INSTANCE'] +
										 '` Where type = "scdailyclaim" and trim(transaction_id) = $pres_id',
										 pres_id=str(prescription_id).strip())
					claimtab.adhoc = False
					claimtab.timeout = 100
					for claimcountrow in sclaim_dict['cb_handle'].n1ql_query(claimtab):
						claimstatus = claimcountrow['status']
						claim_cdate = claimcountrow['create_date']
						if claimstatus == 'SUCCESS':
							claimtype_p = True
							
					if claimtype_p: 
						logfile.write('Rx already Processed on      : ' + str(claim_cdate) + "\r\n")
					
					claim_person_code = ''
					if len(member_id) == 9: 
						claim_person_code = member_id[-2:]
					elif person_code != '': 
						claim_person_code = person_code
					claim_flipt_person_id = e_flipt_person_id
					claim_status = ''
					member_status = ''
					member_coverage_end_date = ''
					user_id = ''
					found = True
					obj = User_Class(None, None, cb_handle=sclaim_dict['cb_handle'])
					sclaim_dict['TV_OBJ'] = obj
					mem_id = ''

					search_option = {'full_document': True,
									 'filter': {'domain_name':
													{'type': 'eq',
													 'value': dcrecs['account'],
													 'case_sensitive': False},
												'flipt_person_id':
													{'type': 'eq',
													 'value': e_flipt_person_id,
													 'case_sensitive': False},
												'$tv.status': {'type': 'eq',
															   'value': 'ACTIVATED'
															   }
												},
									 'filter_type': 'and'
									 }
					att, user_id = obj.search_user(search_option)
					if att is not None:
						if not att.get('coverage_effective_date'):
							customercareactionmsg.add('Member not covered')
							logfile.write('Member not covered : ' + claim_flipt_person_id + "\r\n")
							logfile.close()
							emailreport(sclaim_dict, dcrecs['pharmacy_npi'], customercareactionmsg, claim_type,
										filepath, filename, log)
							exit()

						#Check eligibility for Dependent
						if claim_person_code == '01':
							print("Account holder is creating the intent")
						else:
							print("Dependent is creating the intent")
							now = datetime.now().strftime("%Y-%m-%d 00:00:00")
							if 'dependents' in att:
								for dep in att['dependents']:
									if dep['person_code'] == claim_person_code:
										dep_eligibility = list(filter(lambda x: x['coverage_effective_date'] <= now <=
																			x['coverage_termination_date'], dep['eligibility']))
										if dep_eligibility:
											claim_flipt_person_id = dep['flipt_person_id']
											member_coverage_end_date = dep['coverage_termination_date']
											member_coverage_effective_date = dep['coverage_effective_date']
										else:
											customercareactionmsg.add('Dependent not covered')
											logfile.write('Dependent not covered : ' + claim_flipt_person_id + "\r\n")
											logfile.write('Dependent member_coverage_end_date  : ' + member_coverage_end_date + "\r\n")
											logfile.close()
											emailreport(sclaim_dict, dcrecs['pharmacy_npi'], customercareactionmsg,
														claim_type, filepath, filename, log)

						if 'parent_id' not in att:
							mem_id = 'Valid'
							search_success = False
							if att['active'] is True:
								member_status = 'Active'
							else:
								member_status = 'Inactive'

							# match based on name
							if patient_first_name.lower().strip() == att['first_name'].lower().strip() \
									and patient_last_name.lower().strip() == att['last_name'].lower().strip():
								claim_flipt_person_id = att['flipt_person_id']
								member_coverage_end_date = att['coverage_termination_date']
								search_success = True
							else:
								for dep in att['dependents']:
									if patient_first_name.lower().strip() == dep['first_name'].lower().strip() \
											and patient_last_name.lower().strip() == dep['last_name'].lower().strip():
										claim_flipt_person_id = dep['flipt_person_id']
										member_coverage_end_date = dep['coverage_termination_date']
										search_success = True

							# match based on person_code if name match was unsuccessful
							if search_success == False:
								customercareactionmsg.add("Patient First Name/Last Name not found in employee's family")
								if claim_person_code.strip() == att['person_code']:
									claim_flipt_person_id = att['flipt_person_id']
									member_coverage_end_date = att['coverage_termination_date']
									search_success = True

						else:
							logfile.write('Invalid Employee Member Id : '+ member_id + "\r\n")
							print('Invalid Member ID')
							mem_id = 'Invalid'
					else:
						logfile.write('Unable to Find Member Flipt Person Id : '+ e_flipt_person_id + "\r\n")	
					logfile.write("Member Status                : " + str(member_status).strip() + "\r\n")
					logfile.write("Coverage End Date            : " + str(member_coverage_end_date).strip() + "\r\n")
					logfile.write("Pharmacy                     : " + dcrecs['pharmacy_name'] + "\r\n")
					logfile.write("Pharmacy NPI                 : " + dcrecs['pharmacy_npi'] + "\r\n")
					logfile.write("Pharmacy Drug Name           : " + dcrecs['product_name_full'] + "\r\n")
					logfile.write("Pharmacy Quantity            : " + dcrecs['quantity_dispensed'] + "\r\n")
					logfile.write("Claim Processor              : Script Claim"+"\r\n")
					if member_status == 'Inactive':
						print('Patient/Employee is inactive')
						logfile.close()
						customercareactionmsg.add('Member Not Covered')
						emailreport(sclaim_dict, dcrecs['pharmacy_npi'], customercareactionmsg,
									claim_type, filepath, filename, log)
						continue
					
					if mem_id == 'Invalid':
						print('Employee member Id Invalid')
						customercareactionmsg.add('Member ID Invalid')
						emailreport(sclaim_dict, dcrecs['pharmacy_npi'], customercareactionmsg,
									claim_type, filepath, filename, log)
						
					#patient flipt person id in scdailyclaim
					dcrecs['rx_flipt_person_id'] = claim_flipt_person_id
					autorecs = dict()
					auto_prescription_id = ""
					autoerx_status = ""
					f_id = ""
					rx_f_id = ""
					gpi = ""

					try:
					   plan_year = att['plan_year']
					   plan_name = att['benefit_plan_name']
					except:
					   continue

					# operation mode is FINAL
					if sclaim_dict['mode'].upper() == 'FINAL':
						rv1 = sclaim_dict['cb_handle'].counter('docid', delta=1)
						rx_id = 'scdailyclaim::'+str(rv1.value)
						sclaim_dict['cb_handle'].upsert(rx_id, dcrecs)
						# Check if the drug is covered or not
						query = (f"select * from `{os.environ['CB_INSTANCE']}` b unnest b.company_formulary cf " +
								 f"where b.type='formulary' and cf.company='{domain}' and cf.plan_year='{plan_year}' " +
								 f"and cf.plan_name='{plan_name}' and " +
								 f"b.gpi = '{dcrecs['gpi_code'].strip()}'")

						sclaim_dict['logger_handle'].debug(query)
						sclaim_dict['drug_covered'] = 'Y'  # default value
						sclaim_dict['drug_notcovered_canbe_dispensed'] = 'Y'  # default value
						drug_covered_res = sclaim_dict['cb_handle'].n1ql_query(query).get_single_result()
						if not drug_covered_res:
							print("Drug is not in formulary")
							logfile.write(f"Drug is not in formulary {dcrecs['gpi_code']}\r\n")
							customercareactionmsg.add('Drug is not in formulary')
							emailreport(sclaim_dict, dcrecs['pharmacy_npi'], customercareactionmsg,
										claim_type, filepath, filename, log)
							continue

						if drug_covered_res['cf']['drug_covered'] == 'N':
							sclaim_dict['drug_covered'] = 'N'  # set according to query result
							logfile.write('Drug is not covered : ' + dcrecs['gpi_code'] + "\r\n")
							sclaim_dict['logger_handle'].warning(f"Drug is not covered: {dcrecs['gpi_code']}")
							query = (f"select drug_notcovered_can_be_dispensed from  `{os.environ['CB_INSTANCE']}`" +
									 f"where type='rxplan_master'  and plan_year='{plan_year}' and " +
									 f"domain_name = '{domain}' and plan_name = '{plan_name}'")

							sclaim_dict['logger_handle'].debug(query)
							domain_covered_res = sclaim_dict['cb_handle'].n1ql_query(query).get_single_result()

							if domain_covered_res['drug_notcovered_can_be_dispensed'] == 'N':
								sclaim_dict['drug_notcovered_canbe_dispensed'] = 'N'  # after query
								logfile.write(f"Drug is not covered and cannot be dispensed: {dcrecs['gpi_code']}\r\n")
								sclaim_dict['logger_handle'].\
									warning(f"Drug is not covered and cannot be dispensed: {dcrecs['gpi_code']}")
								logfile.close()
								customercareactionmsg.add('Drug is not covered and cannot be dispensed')
								emailreport(sclaim_dict, dcrecs['pharmacy_npi'], customercareactionmsg,
											claim_type, filepath, filename, log)
								continue

						# Call Auto eRx Function to create an eRx when eRx not Found
						if str(transaction_id).strip() == "":
							pcounttab = N1QLQuery('select count(gpi) as prescription_count from `'
												  +os.environ['CB_INSTANCE']+'` t where t.type = "prescription" ' +
												  'and t.gpi = $gpi_c and ((t.rx_status="Routed") ' +
												  'or (t.rx_status="PA")) ' +
												  'and t.rx_flipt_person_id=$flipt_id',
												  gpi_c=dcrecs['gpi_code'],
												  flipt_id=claim_flipt_person_id)
							pcounttab.adhoc = False
							pcounttab.timeout = 100
							sclaim_dict['logger_handle'].debug(pcounttab)
							prescription_count = 0
							print("*"*70)
							print(pcounttab)
							print("*"*70)
							for pcountrow in sclaim_dict['cb_handle'].n1ql_query(pcounttab):
								prescription_count = pcountrow['prescription_count']

							if prescription_count == 0 and str(claim_type).strip() in ['R', 'P']:
								(autoerx_status, auto_prescription_id,
								autorecs, f_id, rx_f_id, errormsg) = create_erxcard(sclaim_dict,
																					rx_id,
																					row["CardholderID"],
																					row["PatientPC"])

								if autoerx_status == "Success":
									if 'Script for Mail Order/Specialty in New Status' in errormsg:
										logfile.write("AutoeRx created in New Status: " +
													  str(auto_prescription_id).strip() + "\r\n")
										sclaim_dict['logger_handle'].info("AutoeRx created with New Status" +
																		  str(auto_prescription_id).strip())
										customercareactionmsg.add('Mail/Specialty Auto eRx created in a basket. ' +
																  'Follow-up with member ASAP to confirm shipping ' +
																  'address, contact details and route it to ' +
																  autorecs['pharmacy'])

									elif 'PA status auto eRx' in errormsg:
										logfile.write("AutoeRx created in PA Status: " +
													  str(auto_prescription_id).strip() + "\r\n")
										sclaim_dict['logger_handle'].info("AutoeRx created in PA Status: " +
													  str(auto_prescription_id).strip())
										customercareactionmsg.add("AutoeRx created in PA status : " +
																  str(auto_prescription_id).strip() +
																  ". Follow-up with member to initiate approval.")
									else:
										logfile.write("AutoeRx created in Routed Status: " +
													  str(auto_prescription_id).strip() + "\r\n")
										sclaim_dict['logger_handle'].info("AutoeRx created in Routed Status: " +
													  str(auto_prescription_id).strip())
										customercareactionmsg.add("AutoeRx created : " +
																  str(auto_prescription_id).strip() + ". Follow-up " +
																  "with member to pick up the rX at the pharmacy.")
								else:
									customercareactionmsg.add("Unable to create AutoeRx : " + ",".join(errormsg))
									logfile.write("Unable to create AutoeRx : " + ",".join(errormsg) + "\r\n")
									sclaim_dict['logger_handle'].error("Unable to create AutoeRx : " +
																	   ",".join(errormsg))
									continue

								dcrecs['transaction_id'] = auto_prescription_id
								prescription_id = auto_prescription_id
								sclaim_dict['cb_handle'].upsert(rx_id, dcrecs)
							else:
								msgtab = N1QLQuery('select prescription_id, rx_status from `' +
												   os.environ['CB_INSTANCE'] + '` t where t.type = "prescription" ' +
												   'and t.gpi = $gpi_c and (t.rx_status="Routed" or ' +
												   't.rx_status="PA") and ' +
												   't.rx_flipt_person_id=$flipt_id ' +
												   'order by create_date desc limit 1',
												   gpi_c=dcrecs['gpi_code'],
												   flipt_id=claim_flipt_person_id,)
								msgtab.adhoc = False
								msgtab.timeout = 100
								for msgrow in sclaim_dict['cb_handle'].n1ql_query(msgtab):
									auto_p_id = msgrow['prescription_id']
									auto_rx_status = msgrow['rx_status']												
									dcrecs['status'] = 'WARNING' 
									
									logfile.write("Claim Status                 : "+"WARNING"+ "\r\n")
									if auto_rx_status == 'Routed':
										if str(claim_type).strip() == 'P':
											sclaim_dict['cb_handle'].n1ql_query(N1QLQuery('UPDATE `' +
															os.environ['CB_INSTANCE'] + '` SET rx_status="Filled",' +
															'auth_id=$last_auth_id,dispensed_qty=$dispensed_qty,' +
															'patient_paid=$p_paid, filled_date=$filled_date, ' +
															'update_date=$update_date, updated_by=$updated_by,' +
															'claim_status="SUCCESS", ' +
															'claim_message="Pharmacy Filled the eRx" ' +
															'WHERE type="prescription" and ' +
															'prescription_id=$pres_id',
															p_paid=dcrecs['patient_paid'],
															pres_id=dcrecs[auto_p_id].strip(),
															update_date=str(sclaim_dict['currentdate']),
															updated_by='ScriptClaim',
															filled_date=str(claim_date),
															dispensed_qty=dcrecs['quantity_dispensed'],
															last_auth_id=dcrecs['auth_id'])).execute()
											dcrecs['message'] = "Already Routed Auto erx# " + auto_p_id +\
																" is used to fill the prescription."
											customercareactionmsg.add("Already Routed Auto erx# " + auto_p_id +
																	  " is used to fill the prescription.")
										else:
											customercareactionmsg.add("New eRx# " + auto_p_id +
																	  " already routed to script claims. " +
																	  "Follow-up with script claims.")
											print('unsetting sc_routed_date - prescription already routed')
											sclaim_dict['cb_handle'].n1ql_query(N1QLQuery('UPDATE `' +
															os.environ['CB_INSTANCE'] + '` UNSET sc_routed_date ' +
															'WHERE type="prescription" and ' +
															'prescription_id=$pres_id and ' +
															'rx_status="Routed"',
															pres_id=str(auto_p_id).strip())).execute()
											
											dcrecs['message'] = "New eRx# " + auto_p_id + " already routed to " +\
																"script claims. Follow-up with script claims."
									elif auto_rx_status == 'PA':
										dcrecs['message'] = "New eRx# " + auto_p_id + " already present in PA Status."
										customercareactionmsg.add("New eRx# " + auto_p_id +
																  " already present in PA Status.")
								continue

					# processing steps after autoerx is created
					disp_qty = float(dcrecs['quantity_dispensed'])
					reward_amt = 0
					rx_flipt_person_id = ''
					prescription_status = ''
					prescription_quantity = 0
					updated_drug_penalty = 0
					original_rewards = ""
					original_daysofsupply = ""
					new_employee_opc = ""
					term = ""
					ndc= ""
					pda = "" 
					form = ""
					zip_code = ""
					pharmacy_npi = dcrecs['pharmacy_npi']
					package_quantity = ""
					gppc = ""
					address = ""
					pda = ""
					dosage_image = ""
					equivalent_brand = ""
					daysofsupply = "0"
					original_employee_opc = ""
					original_drug_cost= "" 
					original_baseline_cost = "" 
					original_pbm_price = "" 
					original_package_qty = "" 
					original_package_quantity = "" 
					original_package_size = ""
					original_employer_cost = ""					
					f_auth_id = ""
					plocation = ""
					pharmacyname=""
					filled_date=""
					selectednpi=""
					newprescfound=False

					# Check if Prescriptions Exists or Not and get the original prescription details
					prescounttab = N1QLQuery('select npi,filled_date,pharmacy,location as pharmalocation,' +
											 'dosage_image,equivalent_brand,prescription_id,rx_status,' +
											 'tonumber(rewards) as rewards,flipt_person_id, rx_flipt_person_id,' +
											 'ddid, drug_name, gpi, brand_generic, dosage,' +
											 'to_number(quantity) as quantity, package_qty,drug_cost,pbm_price,' +
											 'employer_cost, package_quantity, ' +
											 'to_number(package_size) as package_size, daysofsupply,' +
											 'dosage_strength ,orig_rewards ,employee_opc ,deductible_remaining,' +
											 'drug_penalty, gppc,search_location as location, dpa, form, ' +
											 'zipCode, orig_employee_opc, orig_drug_cost, baseline_cost, ' +
											 'orig_baseline_cost , orig_pbm_price , orig_package_qty, ' +
											 'orig_package_quantity , orig_package_size,' +
											 'orig_employer_cost,auth_id,preselected_npi from `' +
											 os.environ['CB_INSTANCE'] + '` where type="prescription" and ' +
											 '(prescription_id=$pres_id)',
											 pres_id=prescription_id)

					if prescription_id == "":
						prescounttab = N1QLQuery('select filled_date,pharmacy,location as pharmalocation, ' +
												 'dosage_image,equivalent_brand,prescription_id,rx_status,' +
												 'tonumber(rewards) as rewards,flipt_person_id, rx_flipt_person_id, ' +
												 'ddid, drug_name, gpi, brand_generic, dosage, ' +
												 'to_number(quantity) as quantity, package_qty,drug_cost,pbm_price, ' +
												 'employer_cost, package_quantity,' +
												 'to_number(package_size) as package_size, daysofsupply ,' +
												 'dosage_strength ,orig_rewards ,employee_opc ,' +
												 'deductible_remaining , drug_penalty, gppc,' +
												 'search_location as location, dpa, form, zipCode, ' +
												 'orig_employee_opc, orig_drug_cost, baseline_cost, ' +
												 'orig_baseline_cost , orig_pbm_price , orig_package_qty , ' +
												 'orig_package_quantity , orig_package_size ,orig_employer_cost,' +
												 'auth_id,preselected_npi from `' + os.environ['CB_INSTANCE'] +
												 '` Where type="prescription" and (auth_id=$authid)',
												 authid=dcrecs['auth_id'])
						
					prescounttab.adhoc = False
					prescounttab.timeout = 100
					
					for prescountrow in sclaim_dict['cb_handle'].n1ql_query(prescounttab):
						print(prescountrow)
						# prescount = prescountrow['prescount']
						prescription_status = prescountrow['rx_status']
						if prescription_status.lower().strip()=='new':
							newprescfound=True
							print("Prescription not Routed. Skipping the record.")
							break
						if 'rewards' in prescountrow:
							reward_amt = prescountrow['rewards']
						if 'orig_rewards' in prescountrow:
							original_rewards = prescountrow['original_rewards']
						if 'original_employee_opc' in prescountrow:
							original_employee_opc = prescountrow['original_employee_opc']
							
						if 'original_drug_cost' in prescountrow:
							original_drug_cost = prescountrow['original_drug_cost']
						if 'original_baseline_cost' in prescountrow:
							original_baseline_cost = prescountrow['original_baseline_cost']
						if 'original_pbm_price' in prescountrow:
							original_pbm_price = prescountrow['original_pbm_price']
						if 'original_package_qty' in prescountrow:
							original_package_qty = prescountrow['original_package_qty']
						if 'original_package_quantity' in prescountrow:
							original_package_quantity = prescountrow['original_package_quantity']
						if 'original_package_size' in prescountrow:
							original_package_size = prescountrow['original_package_size']
						if 'original_employer_cost' in prescountrow:
							original_employer_cost = prescountrow['original_employer_cost']
						if 'auth_id' in prescountrow:
							f_auth_id = prescountrow['auth_id']			
						if "filled_date" in prescountrow:
							filled_date = prescountrow['filled_date']
						rx_flipt_person_id = prescountrow['rx_flipt_person_id']
						ddid = prescountrow['ddid']
						drug_name = prescountrow['drug_name']
						gpi = prescountrow['gpi']
						brand_generic = prescountrow['brand_generic']
						dosage = prescountrow['dosage']
						drug_cost = prescountrow['drug_cost']
						if 'pbm_price' in prescountrow:
							pbm_price = prescountrow['pbm_price']
						quantity = prescountrow['quantity']
						package_qty = prescountrow['package_qty']
						package_size = prescountrow['package_size']
						daysofsupply = prescountrow['daysofsupply']
						dosage_strength = prescountrow['dosage_strength']
						flipt_person_id = prescountrow['flipt_person_id']
						employee_opc = prescountrow['employee_opc']
						employer_cost = prescountrow['employer_cost']
						baseline_cost = prescountrow['baseline_cost']
						package_quantity = prescountrow['package_quantity']
						gppc = prescountrow['gppc']
						pda = prescountrow['dpa']
						form = prescountrow['form']
						if 'location' in prescountrow:
							address = prescountrow['location']
						else:
							address = 'Home'
						
						if 'zipCode' in prescountrow:
							zip_code = prescountrow['zipCode']
						else:
							zip_code = ''
						
						if 'location' in prescountrow:
							plocation = prescountrow['location']
						else:
							plocation = 'Home'
						pharmacyname = prescountrow['pharmacy']
						selectednpi = prescountrow['npi']
						if 'dosage_image' in prescountrow:
							dosage_image = prescountrow['dosage_image']
						if 'equivalent_brand' in prescountrow:
							equivalent_brand = prescountrow['equivalent_brand']
						prescription_id=prescountrow['prescription_id']
						print('presc found',prescountrow['prescription_id'],prescription_status)
						
						prescription_quantity = package_size * quantity
						logfile.write("eRx Drug Name                : " + str(drug_name + " " + dosage +
																			" " + dosage_strength) + "\r\n")
						logfile.write("eRx Quantity                 : " + str(float(package_size)*float(quantity)) +
									  "\r\n")
						logfile.write("Current Prescription Status  : " + prescription_status + "\r\n")
					
					if newprescfound==True:
						print('New Status prescription')
						logfile.close()
						emailreport(sclaim_dict, pharmacy_npi, customercareactionmsg,
									claim_type, filepath, filename, log)
						continue

					print('Continuing Ahead')
					emp_flipt_person_id = ''
					print(e_flipt_person_id)
					print(emp_flipt_person_id)
					emptab = N1QLQuery('select distinct emp_flipt_person_id from `' + os.environ['CB_INSTANCE'] +
									   '` Where type = "flipt_person_hierarchy" ' +
									   'and dep_flipt_person_id = $person_id',
									   person_id=str(rx_flipt_person_id[0:7]).strip())

					emptab.adhoc = False
					emptab.timeout = 100
					for emprow in sclaim_dict['cb_handle'].n1ql_query(emptab):
						emp_flipt_person_id = emprow['emp_flipt_person_id']
						print('Employee Flipt Person ID', emp_flipt_person_id)

					if prescription_status != "":
						print('EMP', emp_flipt_person_id)
						if emp_flipt_person_id != e_flipt_person_id:
							logfile.write("Claim Status                 : " + "ERROR" + "\r\n")
							logfile.close()
							print("Employee Name doesn't match with Prescription Employee")
							customercareactionmsg.\
								add("Employee Name doesn't match with Prescription Employee. Contact member.")
							emailreport(sclaim_dict, pharmacy_npi, customercareactionmsg,
										claim_type, filepath, filename, log)
							continue
							
						if gpi != dcrecs['gpi_code']:
							logfile.write("Claim Status                 : " + "ERROR" + "\r\n")
							logfile.close()
							print("Drug Name Doesn't match with Prescription Drug Name.")
							customercareactionmsg.\
								add("Drug Name Doesn't match with Prescription Drug Name. Contact ScriptClaim. ")
							emailreport(sclaim_dict, pharmacy_npi, customercareactionmsg,
										claim_type, filepath, filename, log)
							continue
					
					# Calculate Days of Supply based on Actual Days of Supply
					updated_days_of_supply = 0
					updated_employee_opc = 0
					if dcrecs['days_supply'] != daysofsupply.strip() and \
							claim_type == 'P' and prescription_status != 'Filled':
						if float(dcrecs['days_supply']) >= 0 and float(dcrecs['days_supply']) <= 30:
							updated_days_of_supply = 30
						elif float(dcrecs['days_supply']) >= 31 and float(dcrecs['days_supply']) <= 60:
							updated_days_of_supply = 60
						elif float(dcrecs['days_supply']) >= 61 and float(dcrecs['days_supply']) <= 90:
							updated_days_of_supply = 90
						elif float(str(days_supply).strip()) >= 91:
							updated_days_of_supply = 90
						else:
							updated_days_of_supply = float(daysofsupply)
					else:
						updated_days_of_supply = float(daysofsupply)

					print('Updated Days of Supply', updated_days_of_supply)
					# logfile.write("Updated Days of Supply       : " + str(updated_days_of_supply) + "\r\n")
					pharmacy_name = ""
					pharmacy_city = ""
					pharmacy_address = ""
					pharmacy_zip_code = ""
					drug_price = ""
					drug_baseline_price = ""
					deductible_remaining = ""
					drug_copay = ""
					drug_employer_cost = ""
					drug_out_of_pocket = ""
					drug_reward = ""
					drug_distance = ""
					drug_duration = ""
					provider_id = ""
					pbm_price = ""
					provider_name = ""
					out_of_pocket_remaining	= ""
					actual_package_qty = ""
					actual_package_quantity = ""
					actual_package_size = ""	
					actual_quantity = ""
					actual_custom_quantity = ""
					quantities = dict()
					l_update_flag = "N"
					
					if prescription_status != "": 
						# logfile.write('Prescription Found for : ' + str(prescription_id).strip() +
						# ' with status :' + str(prescription_status) + "\r\n")
						print('rx qty',prescription_quantity,'dispensed qty', disp_qty)
						if prescription_quantity != disp_qty and claim_type == 'P' and prescription_status != 'Filled':						
							# print('Quantity Mismatch')
							# print("Product Name Full : " + product_name_full.strip())
							# Call Quantities Function for Recalculating Quantities Based on Dispensed Quantity
							quantities = getquantity(sclaim_dict, gpi, product_name_full.strip(),
													 disp_qty, str(product_id_ndc).strip())
							try:
								actual_package_qty = quantities['package_qty']
								actual_package_quantity = quantities['package_quantity']
								actual_package_size = str(quantities['package_size'])
								actual_quantity = quantities['quantity']
								actual_custom_quantity = quantities['custom_quantity']
							except Exception as e:
								print('cannot get quantity')
								sclaim_dict['logger_handle'].debug("Cannot get quantity")

							(pharmacy_name, pharmacy_city, pharmacy_address, pharmacy_zip_code, drug_price,
							 drug_baseline_price, deductible_remaining, drug_copay, drug_employer_cost,
							 drug_out_of_pocket, drug_reward, drug_distance, drug_duration, provider_id,
							 pbm_price, provider_name, pharmacy_npi, out_of_pocket_remaining, reward_share,
							 retail_reward,total_payment,penalty_factor,pa_flag,
							 pa_form,pa_reason) = get_drugprices(sclaim_dict, term, dcrecs['product_id_ndc'],
																 address, pda, gpi, form, actual_package_size,
																 actual_package_quantity, zip_code, brand_generic,
																 updated_days_of_supply, dosage_strength,
																 claim_flipt_person_id, dcrecs['drug_name'],
																 actual_package_qty,
																 dosage, gppc,pharmacy_npi,user_id,
																 actual_custom_quantity,False)
							if drug_price != " ":
								l_update_flag = "Y"
								
							if drug_price == "":
								logfile.write("Price Recalculation Error !!!!!" + "\r\n")
								logfile.write("Claim Status                 : " + "WARNING" + "\r\n")
								customercareactionmsg.\
									add("Pharmacy Qty and eRx Qty doesn't match - " +
										"Unable to calculate price for pharmacy quantity. Contact IT.")
								dcrecs['status'] = 'WARNING'
								dcrecs['message'] = "WARNING : Price Recalculation Error !!!!!"

								if sclaim_dict['mode'].upper() == 'FINAL':
									sclaim_dict['cb_handle'].upsert(rx_id, dcrecs)
								email_log_custom('DWagle@fliptrx.com', 'FliptIntegrations@fliptrx.com',
												 'DWagle@fliptrx.com', 'Price Recalculation Error',
												 ["There was a price recalculation error for the prescription " +
												  dcrecs['transaction_id'] + ". Please look into the issue."],
												 None,False)

							
						if reward_amt > 0 and claim_type == 'P':
							rewrec=dict()
							rewcounttab = N1QLQuery('select count(prescription_id) as rewcount, id reward_id from `' +
													os.environ['CB_INSTANCE'] +
													'` Where type = "rewardtransaction" ' +
													'and prescription_id=$pres_id ' +
													'group by id',
													pres_id=dcrecs['transaction_id'])

							rewcounttab.adhoc = False
							rewcounttab.timeout = 100
							for rewcountrow in sclaim_dict['cb_handle'].n1ql_query(rewcounttab):
								rewcount = rewcountrow['rewcount']
								reward_id = rewcountrow['reward_id']
								rec_status = 'UPDATE'
								
							if rec_status == 'UPDATE':
								rewardsid = reward_id
								print('RewardsID', rewardsid)
							else:	
								rewid = sclaim_dict['cb_handle'].counter('rewardtransaction_counter', delta=1).value
								rewardsid = 'rewardtransaction::'+str(rewid)
								print('In ELse RewardsID', rewardsid)
							
							# Calculating Rewards if Dispensed Quantity is not equals to eRx Quantity.
							
							updated_reward_amt = 0
							if prescription_quantity != disp_qty:
								try:
									updated_reward_amt = float(drug_reward)
									#print('Updated reward In If block',updated_reward_amt)
								except Exception as e:
									try:
										updated_reward_amt = int(drug_reward)
										#print('Integer updated reward',updated_reward_amt)
									except Exception as e:
										updated_reward_amt = reward_amt
										#print('Exception updated reward',updated_reward_amt)
							else:
								updated_reward_amt = reward_amt
								#print('Updated reward',updated_reward_amt)
							
							rewrec['create_date'] = sclaim_dict['currentdate']
							rewrec['created_by'] = rx_flipt_person_id
							rewrec['flipt_person_id'] = claim_flipt_person_id
							rewrec['prescription_id'] = dcrecs['transaction_id']
							rewrec['id'] = rewardsid
							rewrec['type'] = 'rewardtransaction'
							rewrec['update_date'] = sclaim_dict['currentdate']
							rewrec['updated_by'] = rx_flipt_person_id
							rewrec['domain'] = dcrecs['account']
							rewrec['reward_amount'] = updated_reward_amt
							rewrec['reward_date'] = sclaim_dict['currentdate']
							rewrec['drug_name'] = drug_name
							
							if sclaim_dict['mode'].upper() == 'FINAL':
								print('Rewards Record', rewrec)
								sclaim_dict['cb_handle'].upsert(rewardsid, rewrec, format=FMT_JSON)
								logfile.write("Rewards Inserted             : Yes" + "\r\n")
								rewardsfound = False
								rewardscheck = N1QLQuery('Select tonumber(reward_amount) reward_amount, id from `' +
														 os.environ['CB_INSTANCE'] +
														 '` where type="rewardtransaction" ' +
														 'and prescription_id=$pid',
														 pid=dcrecs['transaction_id'])

								for rewardscheckrow in sclaim_dict['cb_handle'].n1ql_query(rewardscheck):
									rewardsfound = False
									if rewardscheckrow['reward_amount'] == 0:
										rewrec['reward_amount'] = reward_amt
										sclaim_dict['cb_handle'].upsert(rewardsid, rewrec, format=FMT_JSON)

								if not rewardsfound and updated_reward_amt > 0:
									sclaim_dict['cb_handle'].upsert(rewardsid, rewrec, format=FMT_JSON)
									
								# Updating "Prescription" Document with Updated Reward Amount and Orig Reward Amount 
								if prescription_quantity != disp_qty and l_update_flag == "Y":
									sclaim_dict['cb_handle'].\
										n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
															 '` SET rewards = $rewards WHERE type="prescription" ' +
															 'and prescription_id=$pres_id',
															 rewards=str(updated_reward_amt),
															 pres_id=dcrecs['transaction_id'])).execute()

									sclaim_dict['cb_handle'].\
										n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
															 '` SET orig_rewards=$orig_rewards ' +
															 'WHERE type="prescription" ' +
															 'and prescription_id=$pres_id ' +
															 'and orig_rewards is missing',
															 orig_rewards=reward_amt,
															 pres_id=dcrecs['transaction_id'])).execute()

									r_reward_amt = round(float(reward_amt))
									r_u_reward_amt = round(float(updated_reward_amt))
									logfile.write("Rewards Inserted             : Yes" + "\r\n")
									logfile.write("Rewards Recalculated         : from $" +
												  str(r_reward_amt) +
												  " to $" + str(r_u_reward_amt) + "\r\n")

						#print('claim_type:',claim_type)
						if claim_type == 'P':							
							print(prescription_status)
							if prescription_status == "Cancelled":
								dcrecs['status'] = 'SUCCESS'
								dcrecs['message'] = "Previously Cancelled eRx Got Filled."
								logfile.write("New Prescription Status      : " + "Filled" + "\r\n")
								logfile.write("Claim Status                 : " + "SUCCESS" + "\r\n")
								logfile.write("Claim Message                : " +
											  "Previously Cancelled eRx Got Filled." + "\r\n")
								
								if sclaim_dict['mode'].upper() == 'FINAL':
									sclaim_dict['cb_handle'].upsert(rx_id, dcrecs)

									if claim_flipt_person_id == rx_flipt_person_id:
										sclaim_dict['cb_handle'].\
											n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
																 '` SET rx_status="Filled",auth_id=$last_auth_id,'
																 'dispensed_qty=$dispensed_qty, ' +
																 'patient_paid=$p_paid, filled_date=$filled_date,' +
																 'update_date=$update_date, updated_by=$updated_by,' +
																 'claim_status="SUCCESS", ' +
																 'claim_message="Previously Cancelled eRx Got Filled." ' +
																 'WHERE type="prescription" ' +
																 'and prescription_id=$pres_id',
																 p_paid=dcrecs['patient_paid'],
																 pres_id=dcrecs['transaction_id'],
																 update_date=str(sclaim_dict['currentdate']),
																 updated_by='ScriptClaim',
																 filled_date=str(claim_date),
																 dispensed_qty=str(disp_qty),
																 last_auth_id=dcrecs['auth_id'])).execute()
									else:
										sclaim_dict['cb_handle'].\
											n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
																 '` SET rx_status="Filled",auth_id=$last_auth_id,' +
																 'dispensed_qty=$dispensed_qty,patient_paid=$p_paid,' +
																 'filled_date=$filled_date, update_date=$update_date,' +
																 'updated_by=$updated_by,' +
																 'rx_flipt_person_id=$c_flipt_per_id,' +
																 'claim_status="SUCCESS", ' +
																 'claim_message="Previously Cancelled eRx Got Filled."' +
																 ' WHERE type="prescription" ' +
																 'and prescription_id=$pres_id',
																 p_paid=dcrecs['patient_paid'],
																 pres_id=dcrecs['transaction_id'],
																 update_date=str(sclaim_dict['currentdate']),
																 updated_by='ScriptClaim',
																 filled_date=str(claim_date),
																 c_flipt_per_id=claim_flipt_person_id,
																 dispensed_qty=dcrecs['quantity_dispensed'],
																 last_auth_id=dcrecs['auth_id'])).execute()

										rx_flipt_person_id = claim_flipt_person_id
										logfile.write("Updated RX Flipt Person Id   : " + claim_flipt_person_id + "\r\n")
									
									if prescription_quantity != disp_qty and l_update_flag == "Y":
										sclaim_dict['cb_handle'].\
											n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
																 '` SET employee_opc = $emp_opc, drug_cost=$drug, '
																 'baseline_cost=$base, pbm_price=$pbm, ' +
																 'package_qty=$p_qty, package_quantity=$pack_qty, ' +
																 'package_size=$p_size, employer_cost=$employer ' +
																 'WHERE type="prescription" ' +
																 'and prescription_id=$pres_id',
																 emp_opc=str(drug_out_of_pocket),
																 drug=drug_price,base=drug_baseline_price,
																 employer=drug_employer_cost,pbm=pbm_price,
																 p_qty=actual_package_qty,
																 pack_qty=actual_package_quantity,
																 p_size=actual_package_size,
																 pres_id=dcrecs['transaction_id'])).execute()
															
										
										sclaim_dict['cb_handle'].\
											n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
																 '` SET orig_employee_opc=$orig_opc,' +
																 'orig_drug_cost=$drug,orig_baseline_cost=$base,' +
																 'orig_pbm_price=$pbm,orig_package_qty=$p_qty,' +
																 'orig_package_quantity=$pack_qty,' +
																 'orig_package_size=$p_size,' +
																 'orig_employer_cost=$employer ' +
																 'WHERE type="prescription" ' +
																 'and prescription_id=$pres_id ' +
																 'and orig_employee_opc is missing',
																 orig_opc=employee_opc, drug= drug_cost,
																 base=baseline_cost, employer=employer_cost,
																 pbm=pbm_price, p_qty=package_qty,
																 pack_qty=package_quantity, p_size=package_size,
																 pres_id=dcrecs['transaction_id'])).execute()
									
										sclaim_dict['logger_handle'].debug('updating new prices')

										#send push notif, send sms when copay/rewards is recalculated
										try:
											if float(employee_opc) != float(drug_out_of_pocket) or \
													float(drug_reward) != float(reward_amt):
												message = "The quantity dispensed for " +drug_name
												message += " is different than the quantity selected in your eRx. "
												message += "Your reward and co-pay has been adjusted accordingly. "
												message += "Your reward = $" + str(drug_reward) + ", Your Co-Pay = $"
												message += str(drug_out_of_pocket)
												send_notifications(sclaim_dict, dcrecs['account'], message,
																   e_flipt_person_id, rx_flipt_person_id, att)
										except Exception as e:
											pass
										
									if dcrecs['days_supply'] != daysofsupply.strip():
										sclaim_dict['cb_handle'].\
											n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
																 '` SET daysofsupply=$dos ' +
																 'WHERE type="prescription" ' +
																 'and prescription_id=$pres_id',
																 dos=str(updated_days_of_supply),
																 pres_id=dcrecs['transaction_id'])).execute()
										
										sclaim_dict['cb_handle'].\
											n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
																 '` SET orig_daysofsupply=$orig_dos ' +
																 'WHERE type="prescription" ' +
																 'and prescription_id=$pres_id ' +
																 'and orig_daysofsupply is missing',
																 orig_dos=daysofsupply,
																 pres_id=dcrecs['transaction_id'])).execute()
										
									sclaim_dict['cb_handle'].\
										mutate_in(dcrecs['transaction_id'],
												  SD.upsert('prescriber_npi', dcrecs['prescriber_npi']))
									sclaim_dict['cb_handle'].\
										mutate_in(dcrecs['transaction_id'],
												  SD.upsert('rx_number', dcrecs['rx_number']))
									
									# update if pharmacy selected in the app is different from pharmacy at which script is filled
									if str(pharmacy_npi) != str(selectednpi):
										pharmacyquery = N1QLQuery('Select pharmacyname,pharmacyaddress1||", "' +
																  '||pharmacycity||", "||pharmacystate||", "' +
																  '||pharmacyzip1 pharmaddr from `' +
																  os.environ['CB_INSTANCE'] +
																  '` where type="cp_pharmacy" ' +
																  'and pharmacynpi=$pnpi',
																  pnpi=str(pharmacy_npi))
										pharmacyquery.timeout=3200
										for pharmarow in sclaim_dict['cb_handle'].n1ql_query(pharmacyquery):
											sclaim_dict['cb_handle'].\
												n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
																	 '` SET orig_location=location, orig_npi=npi, ' +
																	 'orig_pharmacy=pharmacy ' +
																	 'WHERE type="prescription" ' +
																	 'and prescription_id=$pres_id',
																	 pres_id=dcrecs['transaction_id'])).execute()
											sclaim_dict['cb_handle'].\
												n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
																	 '` SET location=$loc, npi=$npi, ' +
																	 'pharmacy=$pharmacy ' +
																	 'WHERE type="prescription" ' +
																	 'and prescription_id=$pres_id',
																	 loc=pharmarow['pharmaddr'],
																	 npi=str(pharmacy_npi),
																	 pharmacy=pharmarow['pharmacyname'],
																	 pres_id=dcrecs['transaction_id'])).execute()

							# if Prescription Status is Routed or Filled	
							else:
								dcrecs['status'] = 'SUCCESS'
								dcrecs['message'] = "Pharmacy Filled the eRx"
								logfile.write("New Prescription Status      : " + "Filled" + "\r\n")
								logfile.write("Claim Status                 : " + "SUCCESS"+ "\r\n")
								logfile.write("Claim Message                : " + "Pharmacy Filled the eRx" + "\r\n")
								
								if sclaim_dict['mode'].upper() == 'FINAL':
									sclaim_dict['cb_handle'].upsert(rx_id, dcrecs)
									# logfile.write("New Prescription Status      : "+"Filled"+ "\r\n")
									
									
									if claim_flipt_person_id == rx_flipt_person_id:
										sclaim_dict['cb_handle'].\
											n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
																 '` SET rx_status="Filled",auth_id=$last_auth_id,' +
																 'dispensed_qty=$dispensed_qty, patient_paid=$p_paid,' +
																 'filled_date=$filled_date, update_date=$update_date,' +
																 'updated_by=$updated_by,claim_status="SUCCESS",' +
																 'claim_message="Pharmacy Filled the eRx" ' +
																 'WHERE type="prescription" ' +
																 'and prescription_id=$pres_id',
																 p_paid=dcrecs['patient_paid'],
																 pres_id=dcrecs['transaction_id'],
																 update_date=str(sclaim_dict['currentdate']),
																 updated_by='ScriptClaim',
																 filled_date=str(claim_date),
																 dispensed_qty=str(disp_qty),
																 last_auth_id=dcrecs['auth_id'])).execute()
									else:
										sclaim_dict['cb_handle'].\
											n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
																 '` SET rx_status="Filled",auth_id=$last_auth_id,' +
																 'dispensed_qty=$dispensed_qty,patient_paid=$p_paid,' +
																 'filled_date=$filled_date, update_date=$update_date,' +
																 'updated_by=$updated_by,rx_' +
																 'flipt_person_id=$c_flipt_per_id,' +
																 'claim_status="SUCCESS", ' +
																 'claim_message="Pharmacy Filled the eRx" ' +
																 'WHERE type="prescription" ' +
																 'and prescription_id=$pres_id',
																 p_paid=dcrecs['patient_paid'],
																 pres_id=dcrecs['transaction_id'],
																 update_date=str(sclaim_dict['currentdate']),
																 updated_by='ScriptClaim',
																 filled_date=str(claim_date),
																 c_flipt_per_id=claim_flipt_person_id,
																 dispensed_qty=str(disp_qty),
																 last_auth_id=dcrecs['auth_id'])).execute()

										rx_flipt_person_id = claim_flipt_person_id
										logfile.write("Updated RX Flipt Person Id   : " + claim_flipt_person_id + "\r\n")
									
									if prescription_quantity != disp_qty and l_update_flag == "Y":
										sclaim_dict['cb_handle'].\
											n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
																 '` SET employee_opc=$emp_opc, drug_cost=$drug, ' +
																 'baseline_cost=$base, pbm_price=$pbm, ' +
																 'package_qty=$p_qty, package_quantity=$pack_qty, ' +
																 'package_size=$p_size,employer_cost=$employer ' +
																 'WHERE type="prescription" ' +
																 'and prescription_id=$pres_id',
																 emp_opc=str(drug_out_of_pocket),
																 drug=drug_price, base=drug_baseline_price,
																 employer=drug_employer_cost, pbm=pbm_price,
																 p_qty=actual_package_qty,
																 pack_qty=actual_package_quantity,
																 p_size=actual_package_size,
																 pres_id=dcrecs['transaction_id'])).execute()
															
										
										sclaim_dict['cb_handle'].\
											n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
																 '` SET orig_employee_opc=$orig_opc,' +
																 'orig_drug_cost=$drug, orig_baseline_cost=$base, ' +
																 'orig_pbm_price=$pbm, orig_package_qty=$p_qty, ' +
																 'orig_package_quantity=$pack_qty, ' +
																 'orig_package_size=$p_size,' +
																 'orig_employer_cost=$employer ' +
																 'WHERE type="prescription" ' +
																 'and prescription_id=$pres_id ' +
																 'and orig_employee_opc is missing',
																 orig_opc=employee_opc,
																 dru=drug_cost, base=baseline_cost,
																 employer=employer_cost, pbm=pbm_price,
																 p_qty=package_qty, pack_qty=package_quantity,
																 p_size=package_size,
																 pres_id=dcrecs['transaction_id'])).execute()
										
										print('updating new prices')
										#send push notif, send sms when copay/rewards is recalculated
										try:
											print('recalculation sms', employee_opc, drug_out_of_pocket,
												  drug_reward, reward_amt)
											if float(employee_opc) != float(drug_out_of_pocket) or \
													float(drug_reward) != float(reward_amt):
												message = "The quantity dispensed for " + drug_name
												message += " is different than the quantity selected in your eRx. "
												message += "Your reward and co-pay has been adjusted accordingly. "
												message += "Your reward = $" + str(drug_reward)
												message += ", Your Co-Pay = $" + str(drug_out_of_pocket)
												send_notifications(sclaim_dict, account, message,
																   e_flipt_person_id, rx_flipt_person_id, att)
										except Exception as e:
											sclaim_dict['logger_handle'].debug(e)
											pass
										
									if dcrecs['days_supply'] != daysofsupply.strip():
										sclaim_dict['cb_handle'].\
											n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
																 '` SET daysofsupply=$dos ' +
																 'WHERE type="prescription" ' +
																 'and prescription_id=$pres_id',
																 dos=str(updated_days_of_supply),
																 pres_id=dcrecs['transaction_id'])).execute()
										
										sclaim_dict['cb_handle'].\
											n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
																 '` SET orig_daysofsupply=$orig_dos ' +
																 'WHERE type="prescription" ' +
																 'and prescription_id=$pres_id ' +
																 'and orig_daysofsupply is missing',
																 orig_dos=daysofsupply,
																 pres_id=dcrecs['transaction_id'])).execute()
										
									sclaim_dict['cb_handle'].mutate_in(dcrecs['transaction_id'],
																	   SD.upsert('prescriber_npi',
																				 str(dcrecs['prescriber_npi'])))
									sclaim_dict['cb_handle'].mutate_in(dcrecs['transaction_id'],
																	   SD.upsert('rx_number',
																				 str(dcrecs['rx_number'])))
									
									#update if pharmacy selected in the app is different from pharmacy at which script is filled
									if str(pharmacy_npi) != str(selectednpi):
										pharmacyquery = N1QLQuery('Select pharmacyname, pharmacyaddress1||", ' +
																  '"||pharmacycity||", "||pharmacystate||", ' +
																  '"||pharmacyzip1 pharmaddr from `' +
																  os.environ['CB_INSTANCE'] +
																  '` where type="cp_pharmacy" ' +
																  'and pharmacynpi=$pnpi',
																  pnpi=str(pharmacy_npi))
										pharmacyquery.timeout=3200
										for pharmarow in sclaim_dict['cb_handle'].n1ql_query(pharmacyquery):
											sclaim_dict['cb_handle'].\
												n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
																	 '` SET orig_location=location, orig_npi=npi,' +
																	 'orig_pharmacy=pharmacy ' +
																	 'WHERE type="prescription" ' +
																	 'and prescription_id=$pres_id',
																	 pres_id=dcrecs['transaction_id'])).execute()
											sclaim_dict['cb_handle'].\
												n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
																	 '` SET location=$loc, npi=$npi, '+
																	 'pharmacy=$pharmacy ' +
																	 'WHERE type="prescription" ' +
																	 'and prescription_id=$pres_id',
																	 loc=pharmarow['pharmaddr'],
																	 npi=str(pharmacy_npi),
																	 pharmacy=pharmarow['pharmacyname'],
																	 pres_id=dcrecs['transaction_id'])).execute()

							# send push notif, send sms when drug is filled
							if filled_date == "":
								message = "Your prescription for " + drug_name + " is being processed at "
								message += dcrecs['pharmacy_name'] + ". Your eRx card will move "
								message += "from Pending to Filled section."
								send_notifications(sclaim_dict, dcrecs['account'], message,
												   e_flipt_person_id, rx_flipt_person_id, att)
										
							# Code Added for Rx History
							if claim_type == 'P':
								rxcuitab = N1QLQuery('select rxcui from `' + os.environ['CB_INSTANCE'] +
													 '` Where type="drug" and drug_name=$drug ' +
													 'and brand_generic=$brand ' +
													 'and gpi=$gpicode limit 1',
													 drug=dcrecs['product_name_abr'], brand=brand_generic,
													 gpicode=dcrecs['gpi_code'])

								rxcuitab.adhoc = False
								rxcuitab.timeout = 100
								for rxcuirow in sclaim_dict['cb_handle'].n1ql_query(rxcuitab):
									rxcui = rxcuirow['rxcui']
								
								#Retrive bufferdays from domain type
								buffquery = N1QLQuery('select quantity_restriction_buffer from `' +
													  os.environ['CB_INSTANCE'] + '` Where type="domain" ' +
													  'and domain=$domainname',
													  domainname=dcrecs['account'])
								for buffrow in sclaim_dict['cb_handle'].n1ql_query(buffquery):
									buffer_days = buffrow['quantity_restriction_buffer']
								print('Buffer Days:', buffer_days)
								
								rxrec = dict()
								load_type = 'insert'
								# historytab = N1QLQuery('select meta().id as history_id from `'+
								# os.environ['CB_INSTANCE']+'` Where type = "rx_history" and
								# drug_name = "ROSUVASTATIN CALCIUM" and gpi = "39400060100310"
								# and flipt_person_id = "1000981"',drug = drug_name.strip(),
								# gpicode = str(gpi).strip(), rx_flipt_id = str(claim_flipt_person_id).strip())
								historytab = N1QLQuery('select meta().id as history_id from `' +
													   os.environ['CB_INSTANCE'] +'` Where type="rx_history" ' +
													   'and drug_name=$drug ' +
													   'and gpi=$gpicode ' +
													   'and flipt_person_id=$rx_flipt_id',
													   drug=dcrecs['product_name_abr'],
													   gpicode=dcrecs['gpi_code'],
													   rx_flipt_id=claim_flipt_person_id)
								historytab.adhoc = False
								historytab.timeout = 100
								
								for historyrow in sclaim_dict['cb_handle'].n1ql_query(historytab):
									print(historyrow)
									history_id = historyrow['history_id']								
									load_type = 'update'
								#print(load_type)

								if load_type == 'insert':
									rv1 = sclaim_dict['cb_handle'].counter('docid', delta=1)
									rx_id = 'rx_history::' + str(rv1.value)
								else:
									rx_id = history_id	
								
								if prescription_quantity != disp_qty:
									rxrec['package_qty'] = actual_package_qty
									rxrec['package_size'] = actual_package_size
									rxrec['quantity'] = actual_quantity
								else:
									rxrec['package_qty'] = package_qty
									rxrec['package_size'] = package_size								
									rxrec['quantity'] = quantity
								
								rxrec['domain'] = str(dcrecs['account']).strip()
								rxrec['rxcui'] = rxcui
								rxrec['type'] = 'rx_history'
								rxrec['flipt_person_id'] = claim_flipt_person_id
								rxrec['ddid'] = ddid
								rxrec['drug_name'] = drug_name
								rxrec['gpi'] = gpi
								rxrec['brandorgeneric'] = brand_generic
								rxrec['form'] = dosage
								rxrec['dosage_strength'] = dosage_strength
								rxrec['dosage_image'] = dosage_image
								rxrec['equivalent_brand'] = equivalent_brand
								rxrec['npi'] = str(pharmacy_npi).zfill(10)
								# rxrec['quantity'] = quantity
								# rxrec['package_qty'] = package_qty
								# rxrec['package_size'] = package_size
								days_supply = dcrecs['days_supply']
								rxrec['start_date'] = str(filled_dt.isoformat())
								rxrec['daysofsupply'] = days_supply
								
								# filled_dt = filled_dt + timedelta(days= (int(days_supply)
								# rxrec['estimated_stop_date'] = str(filled_dt.isoformat())
								
								filled_dt = filled_dt + timedelta(days=(int(days_supply) - int(buffer_days)))
								rxrec['estimated_stop_date'] = str(filled_dt.isoformat())
								rxrec['currently_taking_flag'] = 'Y'
								rxrec['pharmacy_name'] = pharmacyname
								rxrec['location'] = plocation
								rxrec['ready_to_refill'] = 'N'
								rxrec['created_date'] = sclaim_dict['currentdate']
								rxrec['updated_date'] = sclaim_dict['currentdate']
								rxrec['created_by'] = rx_flipt_person_id
								rxrec['last_udpated_by'] = rx_flipt_person_id

								if sclaim_dict['mode'].upper() == 'FINAL':
									sclaim_dict['cb_handle'].upsert(rx_id, rxrec, format=FMT_JSON)
									if load_type == 'insert':
										logfile.write("Rx History Inserted          : Yes"+"\r\n")
									else:
										logfile.write("Rx History Updated           : Yes"+"\r\n")
							
						elif claim_type == 'X':
							# Delete the Rewards , if Exists for the Prescription
							sclaim_dict['cb_handle'].\
								n1ql_query(N1QLQuery('delete from `' + os.environ['CB_INSTANCE'] +
													 '` WHERE type="rewardtransaction" ' +
													 'and prescription_id=$pres_id',
													 pres_id=dcrecs['transaction_id'])).execute()
							
							# print('X',prescription_status)
							if prescription_status == 'Filled': 
							
								# print('presc auth id:',f_auth_id)
								# print('claim auth id:',auth_id.strip())
								
								if f_auth_id == "" or f_auth_id == None:
									f_auth_id = str(auth_id).strip()
								
								if f_auth_id != str(auth_id).strip():
									logfile.write("Original Filled Authorization: " + f_auth_id + "\r\n")
									logfile.write("Authorization # and Prescription ID don't match. " +
												  "Prescription not CANCELLED." + "\r\n")
									dcrecs['status'] = 'WARNING'
									dcrecs['message'] = "Authorization # and Prescription ID don't match. "
									dcrecs['message'] += 'Prescription not CANCELLED.'
									sclaim_dict['cb_handle'].upsert(rx_id,dcrecs)
									# print('continue',auth_id,f_auth_id)
									custombody = 'Script Claim tried to cancel erx # ' + prescription_id +\
												 ' in filled status using authorization ID ' + auth_id +\
												 ' . The eRx was originally filled with authorization ID ' +\
												 f_auth_id + '. Contact Script claims to resolve the issue.'
									# print(custombody)
									customercareactionmsg.add(custombody)
									email_log_custom('DWagle@fliptrx.com','FliptIntegration@fliptrx.com',
													 'DWagle@fliptrx.com,FliptIntegration@fliptrx.com',
													 'Authorization Number and Prescription ID do not match',
													 [custombody], None, False)
									logfile.close()
									emailreport(sclaim_dict, pharmacy_npi, customercareactionmsg,
												claim_type, filepath, filename, log)
									continue
									
								dcrecs['status'] = 'WARNING'
								dcrecs['message'] = "Pharmacy Reversed the eRx"
								logfile.write("New Prescription Status      : "+"Routed"+ "\r\n")
								logfile.write("Claim Status                 : "+"WARNING"+ "\r\n")
								logfile.write("Claim Message                : "+"Pharmacy Reversed the eRx"+ "\r\n")
								

								if sclaim_dict['mode'].upper() == 'FINAL':
									sclaim_dict['cb_handle'].upsert(rx_id, dcrecs)
									# Retrive bufferdays from domain type
									buffquery = N1QLQuery('select quantity_restriction_buffer from `' +
														  os.environ['CB_INSTANCE'] +
														  '` Where type="domain" ' +
														  'and domain=$domainname',
														  domainname=dcrecs['account'])

									for buffrow in sclaim_dict['cb_handle'].n1ql_query(buffquery):
										buffer_days = buffrow['quantity_restriction_buffer']
									print('Buffer Days:',buffer_days)
																		
									# Hari added below code for B2B-688 in 30/05/2019										
									strcreate_date = ''
									previous_prescrioption = N1QLQuery('select create_date, daysofsupply, ' +
																	   'filled_date, location, npi, pharmacy from `' +
																	   os.environ['CB_INSTANCE'] +
																	   '` Where type="prescription" ' +
																	   'and drug_name=$drug ' +
																	   'and gpi=$gpicode ' +
																	   'and flipt_person_id=$rx_flipt_id ' +
																	   'and rx_status="Filled" ' +
																	   'order by filled_date desc limit 1',
																	   drug=dcrecs['drug_name'],
																	   gpicode=dcrecs['gpi'],
																	   rx_flipt_id=claim_flipt_person_id)

									# print("previous_prescrioption query")
									# print(previous_prescrioption)
									for prescrioptionrow in sclaim_dict['cb_handle'].n1ql_query(previous_prescrioption):
										strcreate_date = prescrioptionrow['create_date']
										strdaysofsupply = int(prescrioptionrow['daysofsupply'])
										filled_date = prescrioptionrow['filled_date']
										location = prescrioptionrow['location']
										npi = prescrioptionrow['npi']
										pharmacy = prescrioptionrow['pharmacy']
										#filled_date = datetime.strptime(filled_date, "%Y-%m-%dT%H:%M:%S")
										filled_date = datetime.strptime(filled_date, "%Y-%m-%dT%H:%M:%S.%f")
										days_count = strdaysofsupply - int(buffer_days)
										estimated_stop_date = filled_date + timedelta(days=days_count)
										estimated_stop_date = str(estimated_stop_date)
										filled_date = str(filled_date)
										# print("strcreate_date %s"%strcreate_date)

									if strcreate_date == '':
										# print("delete query called here")
										sclaim_dict['cb_handle'].\
											n1ql_query(N1QLQuery('DELETE FROM `' + os.environ['CB_INSTANCE'] +
																 '` Where type="rx_history" and drug_name=$drug ' +
																 'and gpi=$gpicode and flipt_person_id=$rx_flipt_id',
																 created_date=strcreate_date,
																 drug=dcrecs['drug_name'],
																 gpicode=dcrecs['gpi'],
																 rx_flipt_id=claim_flipt_person_id)).execute()
									else:
										# print("update query called here")
										sclaim_dict['cb_handle'].\
											n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
																 '` SET daysofsupply=$daysofsupply ' +
																 'and start_date=$filled_date ' +
																 'and location=$location and npi=$npi ' +
																 'and pharmacy=$pharmacy and ' +
																 'estimated_stop_date=$estimated_stop_date ' +
																 'Where type="rx_history" and drug_name=$drug ' +
																 'and gpi=$gpicode and flipt_person_id=$rx_flipt_id',
																 daysofsupply=strdaysofsupply,
																 filled_date=filled_date,
																 location=location, npi=npi,
																 pharmacy=pharmacy,
																 estimated_stop_date=estimated_stop_date,
																 drug=dcrecs['drug_name'],
																 gpicode = dcrecs['gpi'],
																 rx_flipt_id=claim_flipt_person_id)).execute()
									# --------------------------------------------------------------------------------

									if claim_flipt_person_id == rx_flipt_person_id:
										sclaim_dict['cb_handle'].\
											n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
																 '` SET rx_status="Routed",' +
																 'dispensed_qty=$dispensed_qty, patient_paid="0",' +
																 'update_date=$update_date, updated_by=$updated_by,' +
																 'claim_status="WARNING", ' +
																 'claim_message="Pharmacy Reversed the eRx!"  ' +
																 'WHERE type="prescription" ' +
																 'and (prescription_id=$pres_id ' +
																 'or auth_id=$authid)',p_paid='0',
																 pres_id=dcrecs['transaction_id'],
																 update_date=sclaim_dict['currentdate'],
																 updated_by='ScriptClaim',
																 cancelled_date=str(claim_date),
																 dispensed_qty=str(disp_qty),
																 authid=dcrecs['auth_id'])).execute()
									else:
										sclaim_dict['cb_handle'].\
											n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
																 '` SET rx_status="Routed",' +
																 'dispensed_qty=$dispensed_qty, patient_paid="0",' +
																 'update_date=$update_date, updated_by=$updated_by,' +
																 'rx_flipt_person_id=$c_flipt_per_id,' +
																 'claim_status="WARNING", ' +
																 'claim_message= "Pharmacy Reversed the eRx!" '+
																 'WHERE type="prescription" ' +
																 'and (prescription_id=$pres_id ' +
																 'or auth_id=$authid)',p_paid='0',
																 pres_id=dcrecs['transaction_id'],
																 c_flipt_per_id=claim_flipt_person_id,
																 update_date=sclaim_dict['currentdate'],
																 updated_by='ScriptClaim',
																 cancelled_date=str(claim_date),
																 dispensed_qty=str(disp_qty),
																 authid=dcrecs['auth_id'])).execute()
										
									if original_rewards != "":
										sclaim_dict['cb_handle'].\
											n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
																 '` SET rewards=$orig_rewards ' +
																 'WHERE type="prescription" ' +
																 'and prescription_id=$pres_id',
																 pres_id=dcrecs['transaction_id'],
																 orig_rewards=original_rewards)).execute()

									'''
									if original_employee_opc != "":
										print('Original OPC : '+original_employee_opc)
										
										sclaim_dict['cb_handle'].
										n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+
										'` SET employee_opc = orig_employee_opc, drug_cost = orig_drug_cost, 
										baseline_cost = orig_baseline_cost, pbm_price = orig_pbm_price, 
										package_qty = orig_package_qty, package_quantity = orig_package_quantity, 
										package_size = orig_package_size,employer_cost = orig_employer_cost 
										WHERE type = "prescription" and prescription_id = $pres_id',
										pres_id = str(prescription_id).strip())).execute()
									'''
							
							elif prescription_status == 'Cancelled': 
								dcrecs['status'] = 'SUCCESS'
								dcrecs['message'] = "Prescription was already Cancelled"
								logfile.write("Claim Status                 : " + "SUCCESS" + "\r\n")
								logfile.write("Claim Message                : " +
											  "Prescription was already Cancelled" + "\r\n")
							
							# Else Condition for Routed Status
							else:
								dcrecs['status'] = 'SUCCESS'
								dcrecs['message'] = "Prescriptions Cancelled Successfully"
								logfile.write("New Prescription Status      : " + "Cancelled" + "\r\n")
								logfile.write("Claim Status                 : " + "SUCCESS" + "\r\n")
								logfile.write("Claim Message                : " + "Prescription Cancelled" + "\r\n")

								if sclaim_dict['mode'].upper() == 'FINAL':
									sclaim_dict['cb_handle'].upsert(rx_id,dcrecs)
									# logfile.write("New Prescription Status      : "+"Cancelled"+ "\r\n")
									
									if claim_flipt_person_id == rx_flipt_person_id:
										sclaim_dict['cb_handle'].\
											n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
																 '` SET rx_status="Cancelled",' +
																 'dispensed_qty=$dispensed_qty,patient_paid=$p_paid,' +
																 'cancelled_date=$cancelled_date, ' +
																 'update_date=$update_date, ' +
																 'updated_by=$updated_by,' +
																 'claim_status="SUCCESS", ' +
																 'claim_message="Prescriptions Cancelled Successfully" ' +
																 'WHERE type="prescription" ' +
																 'and prescription_id=$pres_id',
																 p_paid='0',
																 pres_id=dcrecs['transaction_id'],
																 update_date=sclaim_dict['currentdate'],
																 updated_by='ScriptClaim',
																 cancelled_date=str(claim_date),
																 dispensed_qty=str(disp_qty))).execute()
									else:
										sclaim_dict['cb_handle'].\
											n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
																 '` SET rx_status="Cancelled",' +
																 'dispensed_qty=$dispensed_qty,patient_paid=$p_paid,'+
																 'cancelled_date=$cancelled_date,' +
																 'update_date=$update_date, updated_by=$updated_by,' +
																 'rx_flipt_person_id=$c_flipt_per_id,' +
																 'claim_status="SUCCESS", ' +
																 'claim_message="Prescriptions Cancelled" '
																 '"WHERE type="prescription" ' +
																 'and prescription_id=$pres_id',
																 p_paid='0', pres_id=dcrecs['transaction_id'],
																 c_flipt_per_id=claim_flipt_person_id,
																 update_date=sclaim_dict['currentdate'],
																 updated_by='ScriptClaim',
																 cancelled_date=str(claim_date),
																 dispensed_qty=str(disp_qty))).execute()

								
						elif claim_type == 'R':
							rejection_reason = dcrecs['pharmacy_rejection_reason']
							# print('prescription got in')
							if prescription_status in ['Filled', 'Cancelled']:
								if sclaim_dict['mode'].upper() == 'FINAL':
									sclaim_dict['cb_handle'].upsert(rx_id, dcrecs)
									
									# Call Auto eRx Function to create an eRx when eRx not Found
									if auto_prescription_id == "":
										#print(product_name_full.strip())
										#print(pharmacy_npi.strip())
										#print(gpi_code.strip())
										#print(e_flipt_person_id)
										pcounttab = N1QLQuery('select count(gpi) as prescription_count from `' +
															  os.environ['CB_INSTANCE'] +
															  '` t where t.type="prescription" ' +
															  'and t.gpi=$gpi_c ' +
															  'and ((t.rx_status="Routed") or (t.rx_status="PA")) ' +
															  'and t.rx_flipt_person_id=$flipt_id ' +
															  'and t.drug_name in (Select raw b.drug_name from `' +
															  os.environ['CB_INSTANCE']+ '` b ' +
															  'where b.type="cp_drug_price" ' +
															  'and b.productnamefull=$drug_full ' +
															  'and b.gpi=$gpi_c limit 1)',
															  gpi_c=dcrecs['gpi_code'],
															  flipt_id=claim_flipt_person_id,
															  drug_full=dcrecs['product_name_full'],
															  pnpi=int(str(pharmacy_npi).strip()))
										pcounttab.adhoc = False
										pcounttab.timeout = 100
										for pcountrow in sclaim_dict['cb_handle'].n1ql_query(pcounttab):
											prescription_count = pcountrow['prescription_count']
											print('count : '+str(prescription_count))
											if prescription_count == 0:									
												print(rx_id,'rxid')
												(autoerx_status,auto_prescription_id,
												 autorecs,f_id,rx_f_id,errormsg) = create_erxcard(sclaim_dict, rx_id,
																								claim_flipt_person_id,
																								row["PatientPC"])
												#print(autoerx_status)
												#print(auto_prescription_id)
												if autoerx_status == "Success":
													if 'Script for Mail Order/Specialty in New Status' in errormsg:
														logfile.write("AutoeRx created in New Status: " +
																	  str(auto_prescription_id).strip() + "\r\n")
														customercareactionmsg.\
															add('Mail/Specialty Auto eRx created in a basket. ' +
																'Follow-up with member ASAP to confirm ' +
																'shipping address, contact details and route it to ' +
																autorecs['pharmacy'])
													elif 'PA status auto eRx' in errormsg:
														logfile.write("AutoeRx created in PA Status: " +
																	  str(auto_prescription_id).strip() + "\r\n")
														customercareactionmsg.\
															add("AutoeRx created in PA status : " +
																str(auto_prescription_id).strip() +
																". Follow-up with member to initiate approval.")
													else:
														logfile.write("AutoeRx created in Routed Status: " +
																	  str(auto_prescription_id).strip() + "\r\n")
														customercareactionmsg.\
															add("AutoeRx created : " + str(auto_prescription_id).strip()+
																". Follow-up with member to pick up " +
																"the rX at the pharmacy.")
												else:
													customercareactionmsg.add("Unable to create AutoeRx : " +
																			  ",".join(errormsg))
													logfile.write("Unable to create AutoeRx : " +
																  ",".join(errormsg) + "\r\n")
													sclaim_dict['logger_handle'].error("Unable to create AutoeRx" +
																					   ",".join(errormsg) + "\r\n")
													dcrecs['transaction_id'] = auto_prescription_id
													dcrecs['transaction_id'] = auto_prescription_id
													prescription_id = auto_prescription_id
													sclaim_dict['cb_handle'].upsert(rx_id, dcrecs)
												
												#logfile.write("Daily Claim Document upserted with Auto Prescription ID "+"\r\n")
											else:
												msgtab = N1QLQuery('select prescription_id, rx_status from `' +
																   os.environ['CB_INSTANCE'] +
																   '` t where t.type="prescription" ' +
																   'and t.gpi=$gpi_c ' +
																   'and (t.rx_status="Routed" or t.rx_status="PA") ' +
																   'and t.rx_flipt_person_id=$flipt_id ' +
																   'and t.drug_name in (Select raw b.drug_name from `'+
																   os.environ['CB_INSTANCE'] +
																   '` b where b.type="cp_drug_price" ' +
																   'and b.productnamefull=$drug_full ' +
																   'and b.gpi=$gpi_c limit 1) ' +
																   'order by create_date desc limit 1',
																   gpi_c=dcrecs['gpi_code'],
																   flipt_id=claim_flipt_person_id,
																   drug_full=dcrecs['product_name_full'],
																   pnpi=int(str(pharmacy_npi).strip()))
												msgtab.adhoc = False
												msgtab.timeout = 100
												for msgrow in sclaim_dict['cb_handle'].n1ql_query(msgtab):
													auto_p_id = msgrow['prescription_id']
													auto_rx_status = msgrow['rx_status']												
													dcrecs['status'] = 'WARNING'
													dcrecs['message'] = "WARNING: Script claims is using an already " +\
																		"filled/cancelled eRx #. Correct eRx # is" + \
																		auto_p_id + " in " + auto_rx_status + " status"
													logfile.write("Claim Status                 : " +
																  "WARNING" + "\r\n")
													
													if auto_rx_status == 'Routed':
														customercareactionmsg.\
															add("Script claims is using an already filled/cancelled " +
																"eRx #. New eRx# " + auto_p_id +
																" already routed to script claims. " +
																"Follow-up with script claims.")
														print('unsetting sc_routed_date - prescription already Routed')
														sclaim_dict['cb_handle'].\
															n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE']+
																				 '` UNSET sc_routed_date ' +
																				 'WHERE type="prescription" ' +
																				 'and prescription_id=$pres_id ' +
																				 'and rx_status="Routed"',
																				 pres_id=str(auto_p_id))).execute()
													elif auto_rx_status=='PA':
														customercareactionmsg.\
															add("New eRx# " + auto_p_id +
																" already present in PA Status.")
													'''
													else:
														customercareactionmsg.add("Script claims is using an already 
														filled/cancelled eRx #. Auto eRx# "+auto_p_id+
														" awaiting in app for member to confirm pick up. 
														Follow-up with member to confirm pickup in app.")
													'''
									sclaim_dict['cb_handle'].\
										n1ql_query(N1QLQuery('UPDATE `' +
															 os.environ['CB_INSTANCE'] +
															 '` SET pharmacy_rejection_reason=$reason,' +
															 'update_date=$update_date, updated_by=$updated_by,' +
															 'claim_status="WARNING: Pharmacy tried to refill or ' +
															 'reprocess an already Filled/Cancelled eRx. ' +
															 'Auto eRx created!" ' +
															 'WHERE type="prescription" ' +
															 'and prescription_id=$pres_id',
															 reason=dcrecs['pharmacy_rejection_reason'],
															 pres_id=dcrecs['transaction_id'],
															 update_date=sclaim_dict['currentdate'],
															 updated_by='ScriptClaim')).execute()
									
							# If Prescription Status is Routed
							elif prescription_status == 'Routed':
								dcrecs['status'] = 'WARNING'
								dcrecs['message'] = "eRx# " + prescription_id + " already routed to script claims."
								logfile.write("Claim Status                 : "+"WARNING"+ "\r\n")
								
								#customercareactionmsg.add("eRx# "+prescription_id+
								# " already routed to script claims. Follow-up with script claims.")
								
								if sclaim_dict['mode'].upper() == 'FINAL':
									sclaim_dict['cb_handle'].upsert(rx_id,dcrecs)
									sclaim_dict['cb_handle'].\
										n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
															 '` SET pharmacy_rejection_reason=$reason,' +
															 'update_date=$update_date, updated_by=$updated_by,' +
															 'claim_status="WARNING", ' +
															 'claim_message="Pharmacy Rejected the eRx. ' +
															 'Please Investigate" ' +
															 'WHERE type="prescription" ' +
															 'and prescription_id=$pres_id',
															 reason=dcrecs['pharmacy_rejection_reason'],
															 pres_id=prescription_id,
															 update_date=sclaim_dict['currentdate'],
															 updated_by='ScriptClaim')).execute()

						else:
							dcrecs['status'] = 'ERROR'
							dcrecs['message'] = "Invalid Claim Type"
							logfile.write("Claim Status   			    : "+"ERROR"+ "\r\n")
							logfile.write("Claim Message                : "+"Invalid Claim Type"+ "\r\n")							
							if sclaim_dict['mode'].upper() == 'FINAL':
								sclaim_dict['cb_handle'].upsert(rx_id,dcrecs)
								#logfile.write("Invalid Claim Type           : "+claim_type+ "\r\n")							
					
					else:
						dcrecs['status'] = 'ERROR'
						dcrecs['message'] = "No Prescriptions Found"
						logfile.write("Claim Status                 : "+"ERROR"+ "\r\n")
						logfile.write("Claim Message                : "+"No eRx card Found"+ "\r\n")						
						if sclaim_dict['mode'].upper() == 'FINAL':
							sclaim_dict['cb_handle'].upsert(rx_id, dcrecs)
							# Call Auto eRx Function to create an eRx when eRx not Found
							if auto_prescription_id == "":
								pcounttab = N1QLQuery('select count(gpi) as prescription_count from `' +
													  os.environ['CB_INSTANCE'] +
													  '` t where t.type="prescription" and t.gpi=$gpi_c ' +
													  'and ((t.rx_status="Routed") or (t.rx_status="PA")) ' +
													  'and t.rx_flipt_person_id=$flipt_id and t.drug_name in ' +
													  '(Select raw b.drug_name from `' + os.environ['CB_INSTANCE'] +
													  '` b where b.type="cp_drug_price" ' +
													  'and b.productnamefull=$drug_full and b.gpi=$gpi_c limit 1)',
													  gpi_c=dcrecs['gpi_code'],
													  flipt_id=claim_flipt_person_id,
													  drug_full=dcrecs['product_name_full'],
													  pnpi=int(dcrecs['pharmacy_npi']))
								pcounttab.adhoc = False
								pcounttab.timeout = 100
								for pcountrow in sclaim_dict['cb_handle'].n1ql_query(pcounttab):
									prescription_count = pcountrow['prescription_count']
									if prescription_count == 0:							
										# print(rx_id)
										# claim_flipt_person_id,
										(autoerx_status, auto_prescription_id,
										autorecs, f_id, rx_f_id, errormsg) = create_erxcard(sclaim_dict, rx_id,
																						   row["CardholderID"],
																						   row["PatientPC"])
										#print(autoerx_status)
										#print(auto_prescription_id)
										'''
										if autoerx_status == "Success":
											if len(errormsg)==0:
												logfile.write("AutoeRx created in Routed Status: "+
												str(auto_prescription_id).strip()+"\r\n")
												customercareactionmsg.add("AutoeRx created : "+
												str(auto_prescription_id).strip()+
												". Follow-up with member to pick up the rX at the pharmacy.")
											else:
												logfile.write("AutoeRx created in Routed Status: "+
												str(auto_prescription_id).strip()+"\r\n")
												customercareactionmsg.add("AutoeRx created in New Status: "+
												str(auto_prescription_id).strip()+
												". Follow-up with member to confirm pick up.")
											else:
											customercareactionmsg.add("Unable to create AutoeRx : "+",".join(errormsg))
										'''
										if autoerx_status == "Success":
											if 'Script for Mail Order/Specialty in New Status' in errormsg:
												logfile.write("AutoeRx created in New Status: " +
															  str(auto_prescription_id).strip() + "\r\n")
												sclaim_dict['logger_handle'].info("AutoeRx created in New Status: " +
															  str(auto_prescription_id).strip())
												customercareactionmsg.add('Mail/Specialty Auto eRx created in a ' +
																		  'basket. Follow-up with member ASAP to ' +
																		  'confirm shipping address, contact details ' +
																		  'and route it to ' + autorecs['pharmacy'])

											elif 'PA status auto eRx' in errormsg:
												logfile.write("AutoeRx created in PA Status: " +
															  str(auto_prescription_id).strip() + "\r\n")
												sclaim_dict['logger_handle'].info("AutoeRx created in PA Status: " +
															  str(auto_prescription_id).strip())
												customercareactionmsg.add("AutoeRx created in PA status : " +
																		  str(auto_prescription_id).strip() +
																		  ". Follow-up with member to " +
																		  "initiate approval.")
											else:
												logfile.write("AutoeRx created in Routed Status: " +
															  str(auto_prescription_id).strip() + "\r\n")
												sclaim_dict['logger_handle'].info("AutoeRx created in Routed Status: " +
															  str(auto_prescription_id).strip())
												customercareactionmsg.add("AutoeRx created : " +
																		  str(auto_prescription_id).strip() +
																		  ". Follow-up with member to pick " +
																		  "up the rX at the pharmacy.")
										else:
											customercareactionmsg.add("Unable to create AutoeRx : "+",".join(errormsg))
											logfile.write("Unable to create AutoeRx : "+",".join(errormsg)+"\r\n")
											dcrecs['transaction_id'] = auto_prescription_id
											prescription_id = auto_prescription_id
											sclaim_dict['cb_handle'].upsert(rx_id,dcrecs)
										
										#logfile.write("Daily Claim Document upserted with Auto Prescription ID "+"\r\n")
									else:
										msgtab = N1QLQuery('select prescription_id, rx_status from `' +
														   os.environ['CB_INSTANCE'] +
														   '` t where t.type="prescription" ' +
														   'and t.gpi=$gpi_c ' +
														   'and (t.rx_status="Routed" or t.rx_status="PA") ' +
														   'and t.rx_flipt_person_id=$flipt_id ' +
														   'and t.drug_name in (Select raw b.drug_name from `' +
														   os.environ['CB_INSTANCE'] +
														   '` b where b.type="cp_drug_price" ' +
														   'and b.productnamefull=$drug_full ' +
														   'and b.gpi=$gpi_c limit 1) ' +
														   'order by create_date desc limit 1',
														   gpi_c=dcrecs['gpi_code'],flipt_id=claim_flipt_person_id,
														   drug_full=dcrecs['product_name_full'],
														   pnpi=int(str(pharmacy_npi).strip()))
										msgtab.adhoc = False
										msgtab.timeout = 100
										for msgrow in sclaim_dict['cb_handle'].n1ql_query(msgtab):
											auto_p_id = msgrow['prescription_id']
											auto_rx_status = msgrow['rx_status']												
											dcrecs['status'] = 'WARNING'
											# auto_p_id + " in "+auto_rx_status+" status"
											logfile.write("Claim Status                 : " + "WARNING" + "\r\n")
											if auto_rx_status == 'Routed':
												customercareactionmsg.\
													add("New eRx# " + auto_p_id +
														" already routed to script claims. " +
														"Follow-up with script claims.")
												print('unsetting sc_routed_date - prescription already routed')
												sclaim_dict['cb_handle'].\
													n1ql_query(N1QLQuery('UPDATE `' + os.environ['CB_INSTANCE'] +
																		 '` UNSET sc_routed_date ' +
																		 'WHERE type="prescription" ' +
																		 'and prescription_id=$pres_id ' +
																		 'and rx_status="Routed"',
																		 pres_id=str(auto_p_id).strip())).execute()
												dcrecs['message'] = "New eRx# " + auto_p_id +\
																	" already routed to script claims. " +\
																	"Follow-up with script claims."
											elif auto_rx_status == 'PA':
												customercareactionmsg.\
													add("New eRx# " + auto_p_id +
														" already present in PA Status.")
											
											'''
											else:
												customercareactionmsg.add("Auto eRx# "+auto_p_id+
												" awaiting in app for member to confirm pick up. 
												Follow-up with member to confirm pickup in app.")
												dcrecs['message'] = "Auto eRx# "+auto_p_id+" awaiting in app 
												for member to confirm pick up. Follow-up with 
												member to confirm pickup in app."
											'''
					if dcrecs['status'] != 'SUCCESS':
						error_prescription = error_prescription + ' , ' + str(prescription_id).strip()
					
					if dcrecs['status'] == 'ERROR':
						archive_status = 'ERROR'
					
					
					print('going to the next record',auth_id,f_auth_id)
					logfile.close()
					emailreport(sclaim_dict, pharmacy_npi, customercareactionmsg,
								claim_type, filepath, filename, log)
		

				except Exception as e:
					type, value, etraceback = sys.exc_info()
					#error=dcrow+'\r\n\r\n\r\n'
					error = input_rec + '\r\n\r\n\r\n'
					x = traceback.format_exception(type, value, etraceback)
					for i in x:
						error = error + i

					email_log_custom('noreply@fliptrx.com', 'FliptIntegration@fliptrx.com',
									 'FliptIntegration@fliptrx.com',
									 'Daily Claim Processing Error', [error],
									 None,False)
					# print('email')
					sclaim_dict['logger_handle'].error(error)

			#shutil.move(filepath,archivefile+filename+'.txt')
			shutil.move(filepath, sclaim_dict['archivepath'] + filename)
	else:
		sys.exit()
# end function

		
def emailreport(sclaim_dict, pharmacy_npi, customercareactionmsg, claim_type, filepath, filename, log):
	"""

	:param sclaim_dict:
	:param pharmacy_npi:
	:param customercareactionmsg:
	:param claim_type:
	:param filepath:
	:param filename:
	:param log:
	:return:
	"""
	from couchbase import FMT_JSON
	from couchbase.n1ql import N1QLQuery
	from utils.sendgridemail import email_log

	logfile = open(log, "a")
	print(log)
	logfile.write("Pharmacy Address and Phone Number : "+"https://npiregistry.cms.hhs.gov/api?number="+
				  str(pharmacy_npi).lstrip('0').strip()+"&pretty=true"+"\r\n")
	
	errormessage = ''
	status = ''
	archive_status = ''
	if claim_type =='P':
		status = "Filled :"
	elif claim_type =='X':
		status = "Reversed :"
	elif claim_type =='R':
		status = "Rejected :"

	if len(customercareactionmsg) > 0:
		logfile.write("**************CUSTOMER CONCIERGE ACTION ITEM**************"+"\r\n")
		for i in customercareactionmsg:
			logfile.write('• ' + i + "\r\n")
			if 'Drug cost exceeds tolerance limit' in i: 
				errormessage = 'Error: Exceeds price tolerance'
				archive_status = 'ERROR'
			if "Employee Name doesn't match with Prescription Employee" in i: 
				errormessage = "Error: Employee Name Doesn't match"
				archive_status = 'ERROR'
				status = ''
			if "Drug Name Doesn't match with Prescription Drug Name" in i: 
				errormessage = "Error: Drug name doesn't match"
				archive_status = 'ERROR'
				status = ''
			if "Pharmacy Qty and eRx Qty doesn't match" in i: 
				errormessage = "Error: Price Recalculation Error due to Qty Difference"
				archive_status = 'ERROR'
				status = ''
			if "Script claims is using an already filled/canceled eRx #" in i: 
				errormessage = "Error: ScriptClaim using Old Transaction ID"
				archive_status = 'ERROR'
				status = ''
			if "Script Claim tried to cancel erx # " in i: 
				errormessage = "Error: ScriptClaim using different Auth ID to Reverse"
				archive_status = 'ERROR'
				status = ''
			if 'Unable to create AutoeRx' in i:
				errormessage = "Error: Unable to Create Auto eRx"
				archive_status = 'ERROR'
				status = ''

			if 'AutoeRx created in PA status' in i:
				errormessage = 'Auto eRx in PA status created'
			if ('AutoeRx created :' in i or 'Already Routed' in i or 'New eRx#' in i) and ('PA status' not in i):
				errormessage = 'AutoeRx created'
			if 'Mail/Specialty Auto eRx created in a basket' in i:
				errormessage = 'Mail/Specialty Auto eRx created'
			
	
	prescounttab = N1QLQuery('select x.heading, x.prescount from ' +
							 '(select "1. Total no of Prescriptions Filled from Day 1" as heading, ' +
							 f"COUNT(prescription_id) as prescount from `{os.environ['CB_INSTANCE']}` t " +
							 'where t.type = "prescription" and t.rx_status = "Filled" and t.flipt_person_id in ' +
							 f"(select raw dep_flipt_person_id from `{os.environ['CB_INSTANCE']}` where " +
							 'type="flipt_person_hierarchy") ' +
							 'union select "2. Rx transactions Received from Script Claims Today" as heading, ' +
							 f"COUNT(transaction_id) as prescount from `{os.environ['CB_INSTANCE']}` t " +
							 'where t.type = "scdailyclaim" and claim_date >= DATE_TRUNC_STR(CLOCK_LOCAL(), "day")  ' +
							 'and claim_date <= CLOCK_LOCAL("1111-11-11")||"T23:59:59" ' +
							 'union select "3. Rx Transactions Filled by Pharmacy Today" as heading, ' +
							 f"COUNT(transaction_id) as prescount from `{os.environ['CB_INSTANCE']}` t where " +
							 't.type = "scdailyclaim" and claim_date >= DATE_TRUNC_STR(CLOCK_LOCAL(), "day") and ' +
							 'claim_date <= CLOCK_LOCAL("1111-11-11")||"T23:59:59" and ' +
							 'claim_type = "P" ' +
							 'union select "4. Rx Transactions Reversed by Pharmacy Today" as heading, ' +
							 f"COUNT(transaction_id) as prescount from `{os.environ['CB_INSTANCE']}` t where " +
							 't.type = "scdailyclaim" and claim_date >= DATE_TRUNC_STR(CLOCK_LOCAL(), "day") ' +
							 'and claim_date <= CLOCK_LOCAL("1111-11-11")||"T23:59:59" and claim_type = "X" ' +
							 'union select "Rejected Due to - "||pharmacy_rejection_reason as heading, ' +
							 f"COUNT(transaction_id) as prescount from `{os.environ['CB_INSTANCE']}` t where " +
							 't.type="scdailyclaim" and pharmacy_rejection_reason is not missing and ' +
							 'claim_date >= DATE_TRUNC_STR(CLOCK_LOCAL(), "day") and ' +
							 'claim_date <= CLOCK_LOCAL("1111-11-11")||"T23:59:59" ' +
							 'and claim_type = "R" group by pharmacy_rejection_reason) x order by  x.heading asc')

	prescounttab.adhoc = False
	prescounttab.timeout = 100
	logfile.write("=========================================================="+"\r\n")
	logfile.write("==================== Rx statistics ======================="+"\r\n")
	logfile.write("=========================================================="+"\r\n")
	for prescountrow in sclaim_dict['cb_handle'].n1ql_query(prescounttab):
		prescount = prescountrow['prescount']
		heading = prescountrow['heading']
		logfile.write(str(heading).ljust(54)+":" + str(prescount)+ "\r\n")

	logfile.write("=========================================================="+"\r\n")
	subject = status+' Rx Claim Status Report ' + errormessage
	if archive_status != 'ERROR':
		#shutil.move(filepath,archivefile+filename+'.txt')
		#logfile.write('Archived File                : '+ archivefile+filename+'.txt' + "\r\n")
		logfile.write('Archived File                : '+ sclaim_dict['archivepath'] + filename + "\r\n")
		logfile.close()
		
		if os.environ['INSTANCE_TYPE'] != 'PROD':
			email_log('','FliptIntegration@FliptRx.com','',
				  subject, ['Processing of Daily Claim File ' +
				  filename + str(sclaim_dict['currentdate']),
				  'Daily Claim Exception'], log, True)

		elif os.environ['INSTANCE_TYPE'] == 'PROD':
			email_log('DWagle@fliptrx.com', 'FliptIntegration@fliptrx.com', None,
				  subject, ['Processing of Daily Claim File ' + filename + 
				  str(sclaim_dict['currentdate']),
				  'Daily Claim Exception'], log, True)
			send_to = 'SPAL@fliptrx.com, DWagle@fliptrx.com, racharya@fliptrx.com'
			email_log('DWagle@fliptrx.com', 'FliptIntegration@fliptrx.com', send_to, subject,
				  ['Processing of Daily Claim File ' + filename + 
				  str(sclaim_dict['currentdate']),
				  'Daily Claim Exception'], log, True)
		else:
			email_log('DWagle@fliptrx.com', 'FliptIntegration@fliptrx.com',
				  'SSubramani@fliptrx.com,SuKumar@FliptRx.com,SHKumar@FliptRx.com',
				  subject,
				  ['Processing of Daily Claim File ' + filename + 
				  str(sclaim_dict['currentdate']),
				  'Daily Claim Exception'], log, True)
	else:
		#.write('Failed to Process Prescriptions : ' + error_prescription + "\r\n")
		logfile.close()

# end function


def getquantity(sclaim_dict, gpi, drugfullname, dispensedquantity, ndc):
	result = {}
	gppcfound = False
	rowindex = 0

	# get drug details based on NDC
	result['gppc'] = ''
	query = N1QLQuery('Select gppc from `' + os.environ['CB_INSTANCE'] +
					  '` where type="ndc_drugs" and ndc=$drugndc',
					  drugndc=ndc)
	query.adhoc = False
	for res in sclaim_dict['cb_handle'].n1ql_query(query):
		result['gppc'] = res['gppc']

	# print(result)
	quantitydf = None
	
	# get drug details based on gpi and full drug name
	
	query = N1QLQuery('Select * from `' + os.environ['CB_INSTANCE'] +
					  '` where type="drug" and gpi=$gpicode and ' +
					  'drug_name in (Select raw b.drug_name from `' +
					  os.environ['CB_INSTANCE'] + '` b where ' +
					  'b.type="cp_drug_price" and ' +
					  'b.productnamefull=$drugfullname and ' +
					  'gpi=$gpicode limit 1)',
					  gpicode=gpi,
					  drugfullname=drugfullname)
	result['lm_ndc'] = ''
	gppcfound = False
	gppcindex = -1
	drugfound = False
	for res in sclaim_dict['cb_handle'].n1ql_query(query):
		drugfound = True
		if len(res[os.environ['CB_INSTANCE']]['lm_ndc']) != 0:
			result['lm_ndc'] = res[os.environ['CB_INSTANCE']]['lm_ndc'][0]

		result['dpa'] = res[os.environ['CB_INSTANCE']]['pda']
		result['ddn_form'] = res[os.environ['CB_INSTANCE']]['ddn_form']
		result['ddn_name'] = res[os.environ['CB_INSTANCE']]['ddn_name']
		result['ddn_strength'] = res[os.environ['CB_INSTANCE']]['ddn_strength']
		result['strengths'] = 'nan'
		result['lm_strength'] = res[os.environ['CB_INSTANCE']]['lm_strength']
		result['lm_form'] = res[os.environ['CB_INSTANCE']]['lm_form']
		result['lm_name'] = res[os.environ['CB_INSTANCE']]['lm_name']
		result['drug_type'] = res[os.environ['CB_INSTANCE']]['drugtype']
		result['rxcui'] = res[os.environ['CB_INSTANCE']]['rxcui']

		quantitydf = pd.DataFrame(data=res[os.environ['CB_INSTANCE']]['quantity'])
		result['ddid'] = res[os.environ['CB_INSTANCE']]['ddid']
		result['dosage'] = res[os.environ['CB_INSTANCE']]['dosage']
		result['brand_generic'] = res[os.environ['CB_INSTANCE']]['brand_generic']
		result['drug_name'] = res[os.environ['CB_INSTANCE']]['drug_name']
		result['specialty_flag'] = res[os.environ['CB_INSTANCE']]['specialty_flag']
		
	if len(result) == 0 or not drugfound:
		#errorlog=errorlog.append({'Drug Full Name':drugfullname,'GPI':gpi,'Pharmacy NPI':'',
		# 'Dispensed Quantity':dispensedquantity,'MemberID':'',
		# 'Error':'Drug Not Found in Drug Database'},ignore_index=True)
		return result
	
	if result['gppc'] in list(quantitydf['gppc']):
		gppcfound = True
		gppcindex = quantitydf[quantitydf['gppc']==result['gppc']].index[0]
		result['custom_qty'] = quantitydf.loc[gppcindex, 'custom_qty']
	else:
		result['custom_qty'] = quantitydf.loc[rowindex, 'custom_qty']
		
	
	quantitydf['package_size'] = quantitydf['package_size'].apply(lambda x:float(x))
	result['custom_quantity'] = False
	
	#get quantity details based on dispensed quantity 

	if result['custom_qty'] == 'package_quantity':
		if float(dispensedquantity) in list(quantitydf['package_size']):
			if gppcfound and quantitydf.loc[gppcindex,'package_size']== float(dispensedquantity):
				rowindex = gppcindex
			else:
				rowindex = quantitydf[quantitydf['package_size']==float(dispensedquantity)].index[0]

			[result['dosage_strength'], result['gppc'], result['package_desc'], result['package_qty'],
			 result['package_quantity'], result['package_size'], result['pkg_desc_cd'], result['pkg_uom'],
			 result['quantity_type']] = quantitydf.loc[rowindex, ['dosage_strength', 'gppc', 'package_desc',
																  'package_qty', 'package_quantity',
																  'package_size', 'pkg_desc_cd',
																  'pkg_uom', 'quantity_type']]
			result['quantity'] = "1"
		else:
			#calculating new package_qty based on custom dispensed quantity
			psizefound=False
			if gppcfound:
				[result['dosage_strength'], result['gppc'], result['package_desc'],
				 result['package_qty'], result['package_quantity'], result['package_size'],
				 result['pkg_desc_cd'], result['pkg_uom'], result['quantity_type']] = quantitydf.loc[gppcindex,
																									 ['dosage_strength',
																									  'gppc',
																									  'package_desc',
																									  'package_qty',
																									  'package_quantity',
																									  'package_size',
																									  'pkg_desc_cd',
																									  'pkg_uom',
																									  'quantity_type']]
				result['package_quantity'] = str(float(dispensedquantity) / quantitydf.loc[gppcindex,'package_size'])
				result['package_qty'] = str(result['package_quantity'])+" "+result['quantity_type']
				result['quantity'] = result['package_quantity']
				psizefound = True
			else:
				quantitydf.sort_values(by=['package_size'], ascending =[False], inplace=True)
				for ind,row in quantitydf.iterrows():
					if float(dispensedquantity) >= row['package_size']:
						psizefound=True
						[result['dosage_strength'], result['package_desc'], result['package_quantity'],
						 result['package_size'], result['pkg_desc_cd'], result['pkg_uom'],
						 result['quantity_type']] = [row['dosage_strength'], row['package_desc'],
													 str(float(dispensedquantity)/row['package_size']),
													 row['package_size'],
													 row['pkg_desc_cd'],
													 row['pkg_uom'],
													 ['quantity_type']]
						result['package_qty'] = str(result['package_quantity']) + " " + result['quantity_type']
						result['quantity'] = result['package_quantity']
						psizefound = True
						break

			result['custom_quantity'] = True
		
	if result['custom_qty'] == 'package_size':
		if float(dispensedquantity) in list(quantitydf['package_size']):
			if gppcfound and quantitydf.loc[gppcindex,'package_size'] == float(dispensedquantity):
				rowindex = gppcindex
			else:
				rowindex = quantitydf[quantitydf['package_size'] == float(dispensedquantity)].index[0]
			[result['dosage_strength'], result['package_desc'], result['package_qty'], result['package_quantity'],
			 result['package_size'], result['pkg_desc_cd'], result['pkg_uom'],
			 result['quantity_type'], result['gppc']]=quantitydf.loc[rowindex, ['dosage_strength',
																				'package_desc',
																				'package_qty',
																				'package_quantity',
																				'package_size',
																				'pkg_desc_cd',
																				'pkg_uom',
																				'quantity_type',
																				'gppc']]
			result['quantity']="1"
			
		else:
			if gppcfound:
				rowindex=gppcindex
			else:
				rowindex=0
			#updating new package_size based on custom dispensed quantity 
			[result['dosage_strength'], result['package_desc'], result['package_quantity'], result['pkg_desc_cd'],
			 result['pkg_uom'], result['quantity_type'], result['gppc']] = quantitydf.loc[rowindex,
																						  ['dosage_strength',
																						   'package_desc',
																						   'package_quantity',
																						   'pkg_desc_cd',
																						   'pkg_uom',
																						   'quantity_type',
																						   'gppc']]
			result['package_size'] = str(float(dispensedquantity))
			result['package_qty'] = str(result['package_size']) + " " + result['quantity_type']
			result['quantity'] = "1"
			result['custom_quantity'] = True
	return result
# end function

	
def send_notifications(sclaim_dict, domain,message, flipt_person_id, rx_flipt_person_id, employeeatt):
	phonenumbers = []
	flipt_id = ''
	if flipt_person_id != rx_flipt_person_id:
		obj = User_Class(None, None, cb_handle=sclaim_dict['cb_handle'])
		search_option = {'full_document': True,
						 'filter':
							 {
								 'flipt_person_id':
									 {
										 'type': 'eq',
										 'value': rx_flipt_person_id,
										 'case_sensitive': False
									  },
								 '$tv.status':
									 {
										 'type': 'eq',
										 'value': 'ACTIVATED'
									 }
							 },
						 'filter_type': 'and'}

		att, user_id = obj.search_user(search_option)
		if att is not None:
			flipt_id = rx_flipt_person_id
			if "communication_option_phone" in att:
				phonenumbers.append(att['communication_option_phone'])

			# Hari modified on 19-feb-2019
			if "personal_phones" in att:
				for row in att['personal_phones']:
					if str(row['verified']).lower() == 'true' and str(row['preferred']).lower() == 'true': 
						if isinstance(row['phone_number'],list):
							phonenumbers.extend(row['phone_number'])
						if isinstance(row['phone_number'],str):
							phonenumbers.append(row['phone_number'])

	elif flipt_person_id == rx_flipt_person_id or len(phonenumbers) == 0:
		if "communication_option_phone" in employeeatt:
			phonenumbers.append(employeeatt['communication_option_phone'])

		# Hari modified on 19-feb-2019
		if "personal_phones" in employeeatt:
			for row in employeeatt['personal_phones']:
				if str(row['verified']).lower() == 'true' and str(row['preferred']).lower() == 'true': 
					if isinstance(row['phone_number'],list):
						phonenumbers.extend(row['phone_number'])
					if isinstance(row['phone_number'],str):
						phonenumbers.append(row['phone_number'])

	sendresult=False

	#send Twilio sms
	for pn in phonenumbers:
		result,info = sendSMS(flipt_person_id, rx_flipt_person_id, pn, message)
		if result.lower() == 'success':
			sendresult = True
			break

	#if Twilio sms failure, insert message in message center
	messagecenter = {}
	action = {}
	if not sendresult:
		messageid = str(sclaim_dict['cb_handle'].counter('docid', delta=1).value)
		action['notification_id'] = messageid
		action['sub_title'] = message
		action['title'] = ""
		action['type'] = 'message'
		messagecenter['action'] = action
		messagecenter['create_date'] = str(datetime.now().isoformat())
		messagecenter['created_by'] = "System"
		messagecenter['domain'] = domain

		if flipt_id != '':
			messagecenter['flipt_person_id'] = rx_flipt_person_id
		else:
			messagecenter['flipt_person_id'] = flipt_person_id

		messagecenter['message'] = ""
		messagecenter['message_id'] = messageid
		messagecenter['message_method'] = "in-app"
		messagecenter['status'] = "New"
		messagecenter['sub_message'] = message
		messagecenter['type'] = "message_center"
		sclaim_dict['cb_handle'].upsert(messagecenter['message_id'], messagecenter)
# end function


cmdline_dict = process_cmdline()

sc_datastruct = dict()
sc_datastruct['mode'] = cmdline_dict['mode']
sc_datastruct['url'] = os.environ['GRAPHQL_URL']
sc_datastruct['flipt_phone'] = os.environ['RESPONSE_PHONENUMBER']
sc_datastruct['cb_handle'] = cb_authenticate()
sc_datastruct['currentdate'] = datetime.now()
sc_datastruct['displaydatetime'] = sc_datastruct['currentdate'].strftime("%Y%m%d%h%M")
sc_datastruct['currentdate'] = sc_datastruct['currentdate'].isoformat()
sc_datastruct['remotepath'] = '/DailyClaimFile'
sc_datastruct['remarchivepath'] = '/DailyClaimFileArchive'
sc_datastruct['path'] = os.environ['CB_DATA']
sc_datastruct['localpath'] = f"{sc_datastruct['path']}/SCDAILYCLAIM/{cmdline_dict['domain']}/{cmdline_dict['file_type']}/"
sc_datastruct['archivepath'] = f"{sc_datastruct['localpath']}/archive/"
sc_datastruct['logger_handle'] = setup_logging_path('SCDAILYCLAIM', f"{cmdline_dict['domain']}_scdailyclaimrewards_" +
													f"{sc_datastruct['currentdate']}",
													'SCDAILYREWARDS')
scriptclaimdailyclaim(sc_datastruct)
