########################################
# !/usr/bin/env python  
# title         : recalcbaselinecost.py
# description   : Recalculates costs in case of recalculation error
# author        : Disha
# date created  : 20180101
# date last modified    : 20190118 12:22
# version       : 0.1
# maintainer    : Pal
# email         : pmuthanai@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage         :  python recalcbaselinecost.py -m DRAFT
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  0.1							20190118	Header Added
#  0.2							20190118	Mode added
# #######################################
if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']
 
import os
from datetime import datetime
import sys
from utils import commandline

from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
# from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
import couchbase.subdocument as SD
import pandas as pd

from opcrewardscalculation.getdrugprices import get_drugprices
from utils.truevault import User_Class

domain,filetype,filename,mode=commandline.main(sys.argv[1:])
cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
# path = os.environ['CB_DATA']

def getquantity(gpi,drugfullname,dispensedquantity,ndc):

	
	sent_to = ""
	result={}
	
	#print(gpi,drugfullname)
	rowindex=0
	gppcfound=False
	#get drug details based on NDC
	result['gppc']=''
	query=N1QLQuery('Select gppc from `'+os.environ['CB_INSTANCE']+'` where type="ndc_drugs" and ndc=$drugndc',drugndc=ndc)
	query.adhoc=False
	for res in cb.n1ql_query(query):
		result['gppc']=res['gppc']
	#print(result)
	quantitydf=None
	#get drug details based on gpi and full drug name 
	
	query=N1QLQuery('Select * from `'+os.environ['CB_INSTANCE']+'` where type="drug" and gpi=$gpicode and drug_name in (Select raw b.drug_name from `'+os.environ['CB_INSTANCE']+'` b where b.type="cp_drug_price" and b.productnamefull=$drugfullname and gpi=$gpicode limit 1)',gpicode=gpi,drugfullname=drugfullname)
	result['lm_ndc']=''
	drugfound=False
	gppcindex=-1
	result['specialty_flag']=''
	for res in cb.n1ql_query(query):
		drugfound=True
		if len(res[os.environ['CB_INSTANCE']]['lm_ndc'])!=0: result['lm_ndc']=res[os.environ['CB_INSTANCE']]['lm_ndc'][0]
		result['dpa']=res[os.environ['CB_INSTANCE']]['pda']
		result['ddn_form']=res[os.environ['CB_INSTANCE']]['ddn_form']
		result['ddn_name']=res[os.environ['CB_INSTANCE']]['ddn_name']
		result['ddn_strength']=res[os.environ['CB_INSTANCE']]['ddn_strength']
		result['strengths']='nan'
		result['lm_strength']=res[os.environ['CB_INSTANCE']]['lm_strength']
		result['lm_form']=res[os.environ['CB_INSTANCE']]['lm_form']
		result['lm_name']=res[os.environ['CB_INSTANCE']]['lm_name']
		result['drug_type']=res[os.environ['CB_INSTANCE']]['drugtype']
		result['rxcui']=res[os.environ['CB_INSTANCE']]['rxcui']
		quantitydf=pd.DataFrame(data=res[os.environ['CB_INSTANCE']]['quantity'])
		result['ddid']=res[os.environ['CB_INSTANCE']]['ddid']
		result['dosage']=res[os.environ['CB_INSTANCE']]['dosage']
		result['brand_generic']=res[os.environ['CB_INSTANCE']]['brand_generic']
		result['drug_name']=res[os.environ['CB_INSTANCE']]['drug_name']
		try:
			result['specialty_flag']=res[os.environ['CB_INSTANCE']]['specialty_flag']
		except Exception as e:
			_=1
	
	if len(result)==0 or not drugfound:
		return result
	
	if result['gppc'] in list(quantitydf['gppc']):
		gppcfound=True
		gppcindex=quantitydf[quantitydf['gppc']==result['gppc']].index[0]
		result['custom_qty']=quantitydf.loc[gppcindex,'custom_qty']
	else:
		result['custom_qty']=quantitydf.loc[rowindex,'custom_qty']
		
	
	quantitydf['package_size']=quantitydf['package_size'].apply(lambda x:float(x))
	result['custom_quantity']=False
	
	#get quantity details based on dispensed quantity 
	
	
	if result['custom_qty']=='package_quantity':
		if float(dispensedquantity) in list(quantitydf['package_size']):
			if gppcfound and quantitydf.loc[gppcindex,'package_size']==float(dispensedquantity):
				rowindex=gppcindex
			else:
				rowindex=quantitydf[quantitydf['package_size']==float(dispensedquantity)].index[0]
			[result['dosage_strength'],result['gppc'],result['package_desc'],result['package_qty'],result['package_quantity'],result['package_size'],result['pkg_desc_cd'],result['pkg_uom'],result['quantity_type']]=quantitydf.loc[rowindex,['dosage_strength','gppc','package_desc','package_qty','package_quantity','package_size','pkg_desc_cd','pkg_uom','quantity_type']]
			result['quantity']="1"
		else:
			#calculating new package_qty based on custom dispensed quantity
			psizefound=False
			if gppcfound:
				[result['dosage_strength'],result['gppc'],result['package_desc'],result['package_qty'],result['package_quantity'],result['package_size'],result['pkg_desc_cd'],result['pkg_uom'],result['quantity_type']]=quantitydf.loc[gppcindex,['dosage_strength','gppc','package_desc','package_qty','package_quantity','package_size','pkg_desc_cd','pkg_uom','quantity_type']]
				result['package_quantity']=str(float(dispensedquantity)/quantitydf.loc[gppcindex,'package_size'])
				result['package_qty']=str(result['package_quantity'])+" "+result['quantity_type']
				result['quantity']=result['package_quantity']
				psizefound=True
			else:
				quantitydf.sort_values(by=['package_size'],ascending=[False],inplace=True)
				for ind,row in quantitydf.iterrows():
					if float(dispensedquantity)>=row['package_size']:
						psizefound=True
						[result['dosage_strength'],result['package_desc'],result['package_quantity'],result['package_size'],result['pkg_desc_cd'],result['pkg_uom'],result['quantity_type']]=[row['dosage_strength'],row['package_desc'],str(float(dispensedquantity)/row['package_size']),row['package_size'],row['pkg_desc_cd'],row['pkg_uom'],row['quantity_type']]
						result['package_qty']=str(result['package_quantity'])+" "+result['quantity_type']
						result['quantity']=result['package_quantity']
						psizefound=True
						break
			
				
			result['custom_quantity']=True
		
	if result['custom_qty']=='package_size':
		
		if float(dispensedquantity) in list(quantitydf['package_size']):
			if gppcfound and quantitydf.loc[gppcindex,'package_size']==float(dispensedquantity):
				rowindex=gppcindex
			else:
				rowindex=quantitydf[quantitydf['package_size']==float(dispensedquantity)].index[0]
			[result['dosage_strength'],result['package_desc'],result['package_qty'],result['package_quantity'],result['package_size'],result['pkg_desc_cd'],result['pkg_uom'],result['quantity_type'],result['gppc']]=quantitydf.loc[rowindex,['dosage_strength','package_desc','package_qty','package_quantity','package_size','pkg_desc_cd','pkg_uom','quantity_type','gppc']]
			result['quantity']="1"
			
		else:
			if gppcfound:
				rowindex=gppcindex
			else:
				rowindex=0
			#updating new package_size based on custom dispensed quantity 
			[result['dosage_strength'],result['package_desc'],result['package_quantity'],result['pkg_desc_cd'],result['pkg_uom'],result['quantity_type'],result['gppc']]=quantitydf.loc[rowindex,['dosage_strength','package_desc','package_quantity','pkg_desc_cd','pkg_uom','quantity_type','gppc']]
			result['package_size']=str(float(dispensedquantity))
			result['package_qty']=str(result['package_size'])+" "+result['quantity_type']
			result['quantity']="1"
			result['custom_quantity']=True
	return result		
			
print("reclacbaselinecost start here")			
query=N1QLQuery('Select domain,quantity,locationSelected,rewards,drug_cost, location,routed_date, orig_baseline_cost,auth_id, search_location, dpa, gpi, form, package_size, package_quantity, zipCode, brand_generic, days_of_supply, dosage_strength, rx_flipt_person_id, flipt_person_id, drug_name, package_qty, dosage, gppc, npi, prescription_id, dispensed_qty, lm_ndc from `'+os.environ['CB_INSTANCE']+'` where type="prescription" and tonumber(dispensed_qty)!=(tonumber(package_size)*tonumber(quantity)) and rx_status="Filled" and date_part_str(filled_date,"year")=$yr and date_part_str(filled_date,"month")=$mth',yr=(datetime.now().year),mth=(datetime.now().month))
#query=N1QLQuery('Select domain,quantity,locationSelected,rewards,drug_cost, location,routed_date, orig_baseline_cost,auth_id, search_location, dpa, gpi, form, package_size, package_quantity, zipCode, brand_generic, days_of_supply, dosage_strength, rx_flipt_person_id, flipt_person_id, drug_name, package_qty, dosage, gppc, npi, prescription_id, dispensed_qty, lm_ndc from `'+os.environ['CB_INSTANCE']+'` where type="prescription" and tonumber(dispensed_qty)!=(tonumber(package_size)*tonumber(quantity)) and rx_status="Filled" and date_part_str(filled_date,"year")=$yr and date_part_str(filled_date,"month")=$mth',yr=2018,mth=12)
query.timeout=100
for r in cb.n1ql_query(query):
	print("select query value %s"%r)
	d=dict(r)
	#custom_quantity=True
	query1=N1QLQuery('Select distinct tonumber(days_supply) days_supply, product_id_ndc, product_name_full from `'+os.environ['CB_INSTANCE']+'` where type="scdailyclaim" and auth_id like $pid order by claim_date desc limit 1',pid="%"+r['auth_id']+"%")
	for s in cb.n1ql_query(query1):
		if 'days_of_supply' not in d:
			if s['days_supply']>90: d['days_of_supply']="OVER 90"
			elif s['days_supply']<60 and s['days_supply']<=90: d['days_of_supply']="UP TO 90"
			elif s['days_supply']<30 and s['days_supply']<=60: d['days_of_supply']="UP TO 60"
			else: d['days_of_supply']="UP TO 30"
		d['ndc']=s['product_id_ndc']
		d['product_name_full']=s['product_name_full']
	
	print(d['prescription_id'])
	result=getquantity(r['gpi'],d['product_name_full'],r['dispensed_qty'],d['ndc'])
	#print(result)
	obj=User_Class()
	search_option={'full_document':True,'filter':{'domain_name':{'type':'eq','value':d['domain'],'case_sensitive':False},'flipt_person_id':{'type':'eq','value':d['flipt_person_id'],'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
	att,userid = obj.search_user(search_option)
	d['search_location']=d['locationSelected']
	d['search_location']=d['location']
	if att!=None:
		#pharmacy_name,pharmacy_city,pharmacy_address,pharmacy_zip_code,drug_price,drug_baseline_price,deductible_remaining,drug_copay,drug_employer_cost,drug_out_of_pocket,drug_reward,drug_distance,drug_duration,provider_id,pbm_price,provider_name,pharmacy_npi,out_of_pocket_remaining = get_drugprices("", d['ndc'].strip(), d['search_location'], d['dpa'], d['gpi'], d['form'], result['package_size'], result['package_quantity'], d['zipCode'], d['brand_generic'], d['days_of_supply'].replace("UP TO ","").replace("OVER ",""), d['dosage_strength'], d['rx_flipt_person_id'], d['drug_name'], result['package_qty'], d['dosage'], d['gppc'],d['npi'],'"'+userid+'"',result['custom_quantity'],False)
		try:
			pharmacy_name,pharmacy_city,pharmacy_address,pharmacy_zip_code,drug_price,drug_baseline_price,deductible_remaining,drug_copay,drug_employer_cost,drug_out_of_pocket,drug_reward,drug_distance,drug_duration,provider_id,pbm_price,provider_name,pharmacy_npi,out_of_pocket_remaining,reward_share,retail_reward,total_payment,penalty_factor,pa_flag,pa_form,pa_reason = get_drugprices("", d['ndc'].strip(), d['search_location'], d['dpa'], d['gpi'], d['form'], result['package_size'], result['package_quantity'], d['zipCode'], d['brand_generic'], d['days_of_supply'].replace("UP TO ","").replace("OVER ",""), d['dosage_strength'], d['rx_flipt_person_id'], d['drug_name'], result['package_qty'], d['dosage'], d['gppc'],d['npi'],'"'+userid+'"',result['custom_quantity'],False)
			#print(d)
			if drug_price=="":
				print(d['prescription_id'],'not found')
				continue
			print(drug_copay)
			print('recalc',drug_price,'current',d['drug_cost'],r['dispensed_qty'],float(d['package_size'])*float(d['quantity']),drug_reward,d['rewards'])
			print('--------------------------------------------')
			
			rewardsfound=False
			if mode.upper() == 'FINAL':
			    cb.n1ql_query(N1QLQuery('UPDATE `'+os.environ['CB_INSTANCE']+'` SET orig_rewards=rewards,orig_employee_opc = employee_opc,orig_drug_cost = drug_cost, orig_baseline_cost = baseline_cost, orig_pbm_price = pbm_price, orig_package_qty = package_qty, orig_package_quantity = package_quantity, orig_package_size = package_size,orig_employer_cost = employer_cost WHERE type = "prescription" and prescription_id = $pres_id',pres_id = str(d['prescription_id']).strip())).execute()
			    cb.mutate_in(d['prescription_id'],SD.upsert('employee_opc',str(drug_out_of_pocket)))
			    cb.mutate_in(d['prescription_id'],SD.upsert('drug_cost',str(drug_price)))
			    cb.mutate_in(d['prescription_id'],SD.upsert('drug_cost_before_rebate',str(drug_price)))
			    cb.mutate_in(d['prescription_id'],SD.upsert('pbm_price',str(pbm_price)))
			    cb.mutate_in(d['prescription_id'],SD.upsert('package_qty',str(result['package_qty'])))
			    cb.mutate_in(d['prescription_id'],SD.upsert('package_quantity',str(result['package_quantity'])))
			    cb.mutate_in(d['prescription_id'],SD.upsert('package_size',str(result['package_size'])))
			    cb.mutate_in(d['prescription_id'],SD.upsert('employer_cost',str(drug_employer_cost)))
			    cb.mutate_in(d['prescription_id'],SD.upsert('baseline_cost',str(drug_baseline_price)))
			    cb.mutate_in(d['prescription_id'],SD.upsert('rewards',str(drug_reward)))
			    cb.mutate_in(d['prescription_id'],SD.upsert('update_date',datetime.now().isoformat()))
			    cb.mutate_in(d['prescription_id'],SD.upsert('update_by',"Cost Recalculation"))
			
			    for rewres in cb.n1ql_query(N1QLQuery('update `'+os.environ['CB_INSTANCE']+'` set reward_amount=$ra where type="rewardtransaction" and prescription_id=$pid returning meta().id',ra=float(drug_reward),pid=d['prescription_id'])):
				    rewardsfound=True
			if not rewardsfound and float(drug_reward)>0:
				rewrec={}
				if mode.upper() == 'FINAL':
				    rewid = cb.counter('rewardtransaction_counter',delta=1).value
				    rewrec['id'] = 'rewardtransaction::'+str(rewid)
				rewrec['create_date'] = datetime.now().isoformat()
				rewrec['created_by'] = d['flipt_person_id']
				rewrec['flipt_person_id'] = d['rx_flipt_person_id']
				rewrec['prescription_id'] = str(d['prescription_id']).strip()
				rewrec['type'] = 'rewardtransaction'
				rewrec['update_date'] = datetime.now().isoformat()
				rewrec['updated_by'] = d['flipt_person_id']
				rewrec['domain'] = d['domain'].strip()
				rewrec['reward_amount'] = float(drug_reward)
				rewrec['reward_date'] = datetime.now().isoformat()
				rewrec['drug_name'] = d['drug_name']
				#print(str(d['prescription_id']).strip(),'rew')
				if mode.upper() == 'FINAL':
				    cb.upsert(rewrec['id'], rewrec)
		except Exception as e:
			print(e)
			continue
			
	else:
		print(d['flipt_person_id'],'person not found',d['prescription_id'])
	
print("reclacbaselinecost end here")			
