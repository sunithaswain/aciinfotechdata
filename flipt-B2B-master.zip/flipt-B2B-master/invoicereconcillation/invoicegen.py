
if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']
 
import os
#from utils import commandline
import sys, traceback
import time
import socket
import requests
from requests.auth import HTTPBasicAuth
import datetime 
import calendar
from dateutil.relativedelta import relativedelta 
import dateutil.parser as parser
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from couchbase import FMT_JSON
from utils.sendgridemail import email_log
from fpdf import FPDF, HTMLMixin
from utils.FliptConcurrent import concurrent
from utils.truevault import User_Class
from utils import opccmdline

#Command to Execute
#Automated: python invoicegen.py  -d GWLABS001 -t invoice -m DRAFT
#Manual:  python invoicegen.py  -d GWLABS001 -t invoice -m DRAFT -s 01-AUG-2018 

host = socket.gethostname()
print(host)

domain,file_type,file_name,mode,start_text,end_text = opccmdline.main(sys.argv[1:])

#Concurrent call assignment
req=concurrent(sys.argv[0],sys.argv[1:],2)
#print('Started')
if start_text != None:
	run_date = parser.parse(start_text)	
	mon=run_date.strftime('%Y-%b-%d').split('-')[1]
	yyyy=run_date.strftime('%Y-%b-%d').split('-')[0]
	#print(mon+yyyy)
	invmon=run_date + relativedelta(months=1)
	invdate = invmon.strftime("%d-%b-%Y")
	print("Invoice date: ",invdate)
	#print("Day in case of ManualRun: ",run_date.day)
else:
	run_date=datetime.date.today()
	t=run_date.replace(day=1)-datetime.timedelta(days=1)
	mon=t.strftime('%Y-%b-%d').split('-')[1]
	yyyy=t.strftime('%Y-%b-%d').split('-')[0]
	#print(mon+yyyy)
	invmon = run_date
	invdate = run_date.strftime("%d-%b-%Y")
	print("Invoice date: ",invdate)
	#print("Day in case of Automated Run: ",run_date.day)

	
if run_date.day == 1:
	# path = os.environ['CB_DATA']
	localpath = path+'/invoice'+'/'
	invfile = localpath+'FliptInvoice_'+invdate+'.pdf'


	#To initiate the Couch base connection
	cluster = Cluster(os.environ['CB_URL'])
	authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
	cluster.authenticate(authenticator)
	cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
	# path = os.environ['CB_DATA']



	#Function to filter usersdef filterusers(self,username):

	pdf=FPDF()
	pdf.add_page()
	pdf.line(5, 5, 5, 200)
	pdf.line(5, 5, 200, 5)
	pdf.line(200, 5, 200, 200)
	pdf.line(200, 200, 5, 200)
	pdf.image(path+"/invoice/flipt.PNG", x=10, y=10, w=20)
	pdf.ln(30)
	pdf.set_font("Arial", size=8, style='B')

	#retrieve data from fliptcompanyinfo type
	query = N1QLQuery("select address1,address2,billing_contact_person,billing_email,billing_phone,city,company_name,federal_tax_id,mailing_address1,mailing_address2,mailing_city,mailing_state,mailing_zip,state,type,updated_date,wire_ABA,wire_ACCT,wire_bank_name,zip from `"+os.environ['CB_INSTANCE']+"` where type ='flipt_company_info'")
	query.adhoc = False
	query.timeout = 600
	flipt_company_info={}
	for l in cb.n1ql_query(query):
		flipt_company_info.update(l)

	#retrieve data from domain type
	domquery = N1QLQuery("select companylegalname,address1,address2,city,state,zip from `"+os.environ['CB_INSTANCE']+"` where type ='domain' and domain=$dn",dn=domain)
	domquery.adhoc = False
	domquery.timeout = 600
	domain_details={}
	for d in cb.n1ql_query(domquery):
		domain_details.update(d)

	#Retreive Users from truevault

	#get the number of users from flipt_person_hierarchy table and truevault
	userQuery = N1QLQuery("select distinct emp_flipt_person_id from `"+os.environ['CB_INSTANCE']+"` where type ='flipt_person_hierarchy' and domain_name= $dn",dn=domain)
	userQuery.adhoc = False
	userQuery.timeout = 600
	usernum = 0
	for i in  cb.n1ql_query(userQuery):
		flipt_person_id =i['emp_flipt_person_id']
		print(i['emp_flipt_person_id'])
		#TrueVault Call
		obj=User_Class(None,None)	
		search_option={'full_document':True,'filter':{'domain_name':{'type':'eq','value':domain,'case_sensitive':False},'flipt_person_id':{'type':'eq','value':flipt_person_id,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
		att,userid=obj.search_user(search_option)
		if att!=None:
			if 'employee_id' in att and 'parent_user_id' not in att:
				if 'domain_name' in att and 'active' in att and 'TEST' not in att['employee_id'] :
					if att['active']==True:
						usernum=usernum+len(att['dependents'])
						usernum=usernum+1
						print('Dependents',len(att['dependents']))					
						
		
		
		
	print(usernum)

	#retrieve data from subscription contract type	
	query2 = N1QLQuery("select description,domain,end_date,payment_terms,payment_terms_days,po_number,rate_per_life,tax from `"+os.environ['CB_INSTANCE']+"` where type ='cust_subscription_contract'")
	query2.adhoc = False
	query2.timeout = 600
	x=1
	cntrec=0
	for row in cb.n1ql_query(query2):
		payment_days = int(row['payment_terms_days'])
		dd = invmon + datetime.timedelta(days = payment_days )
		duedate = dd.strftime("%d-%b-%Y")
		invcounter = str(cb.counter('invoicecounter',delta=1).value)
		pdf.cell(4, 4, txt=flipt_company_info['company_name'], ln=1, align="L")
		pdf.set_font("Arial", size=8)
		pdf.cell(4, 4, txt=flipt_company_info['address1'], ln=1, align="L")
		pdf.cell(4, 4, txt=flipt_company_info['city']+', '+flipt_company_info['state']+' '+flipt_company_info['zip'], ln=1, align="L")
		pdf.ln(20)
		pdf.set_font("Arial", size=8, style='B')
		pdf.cell(4, 4, txt="BILL TO", ln=1, align="L")
		pdf.set_font("Arial", size=8)
		pdf.cell(4, 4, txt=domain_details['companylegalname'], ln=1, align="L")
		pdf.cell(4, 4, txt=flipt_company_info['billing_contact_person'], ln=1, align="L")
		pdf.cell(4, 4, txt=domain_details['address1'], ln=1, align="L")
		pdf.cell(4, 4, txt=domain_details['city']+", "+domain_details['state']+' '+domain_details['zip'], ln=1, align="L")
		pdf.ln(20)
		pdf.set_font("Arial", size=8, style='B')
		pdf.cell(4, 4, txt="FOR BILLING QUESTIONS, CALL", ln=1, align="L")
		pdf.set_font("Arial", size=8)
		pdf.cell(4, 4, txt=flipt_company_info['billing_phone'], ln=1, align="L")
		pdf.cell(4, 4, txt="OR EMAIL:", ln=1, align="L")
		pdf.cell(4, 4, txt=flipt_company_info['billing_email'], ln=1, align="L")
		pdf.cell(80)
		pdf.ln(-110)
		pdf.set_font("Arial", size=8)	
		pdf.cell(150, 0, txt="Page : "+str(x)+'/'+str(x), ln=0, align="R")
		x=x+1

		pdf.ln(10)
		pdf.cell(-10)
		pdf.set_font("Arial", size=20, style='B')
		pdf.cell(170, 30, txt="INVOICE", ln=0, align="R")
		pdf.ln(20)
		pdf.cell(120)
		pdf.set_font("Arial", size=8)
		pdf.multi_cell(65, 4, txt='Federal Tax ID: '+flipt_company_info['federal_tax_id']+'\nInvoice number:'+invcounter+'\nInvoice Date: '+invdate+'\nYour PO# : '+row['po_number']+'\nPayment Terms : '+row['payment_terms']+'\nDue Date: '+duedate, align="L",border=1)
		pdf.ln(20)
		pdf.cell(120)
		pdf.set_font("Arial", size=8)
		pdf.multi_cell(65, 4, txt='PAYMENT INSTRUCTIONS:\nREFERENCE '+invcounter+' ON YOUR REMITTANCE\nMAIL CHECKS TO: '+flipt_company_info['company_name']+'\n'+flipt_company_info['address1']+'\n'+flipt_company_info['city']+','+flipt_company_info['state']+' '+flipt_company_info['zip'], align="L",border=1)
		#pdf.ln(-15)
		#pdf.ln(20)
		pdf.cell(120)
		pdf.set_font("Arial", size=8)
		pdf.multi_cell(65, 4, txt='WIRE TRANSFERS TO: '+flipt_company_info['wire_bank_name']+'\n\n\n\n', align="L",border=1)
		pdf.cell(120)
		pdf.set_font("Arial", size=8)
		pdf.multi_cell(65, 4, txt='ABA: '+flipt_company_info['wire_ABA'], align="L",border=1)
		pdf.cell(120)
		pdf.set_font("Arial", size=8)
		pdf.multi_cell(65, 4, txt='ACCT: '+flipt_company_info['wire_ACCT'], align="L",border=1)
		pdf.ln(10)
		pdf.set_font("Arial", size=7, style='B')
		pdf.cell(10, 15, txt="Item#", ln=0, align="C",border=1)
		pdf.cell(60, 15, txt="DESCRIPTION", ln=0, align="C",border=1)
		pdf.cell(35, 15, txt="QTY/NO. OF USERS", align="C",border=1)
		pdf.cell(20, 15, txt="UNIT PRICE", ln=0, align="C",border=1)
		pdf.cell(20, 15, txt="TAX", ln=0, align="C",border=1)
		pdf.cell(40, 15, txt="AMOUNT IN US$", ln=1, align="C",border=1)
		pdf.set_font("Arial", size=7)
		pdf.cell(10, 15, txt="1", ln=0, align="R",border=1)
		pdf.cell(60, 15, txt="Flipt member subscription charges for "+mon+"-"+yyyy, align="R",border=1,ln=0)

		pdf.cell(35, 15, txt=str(usernum), align="R",border=1,ln=0)
		pdf.cell(20, 15, txt=row['rate_per_life'], ln=0, align="R",border=1)
		pdf.cell(20, 15, txt=row['tax'], ln=0, align="R",border=1)
		pdf.cell(40, 15, txt=str(usernum * int(row['rate_per_life'][1:])) , ln=1, align="R",border=1)
		pdf.cell(40)
		pdf.set_font("Arial", size=7, style='B')
		pdf.cell(30, 8, txt="Total", ln=0, align="L",border=1)
		pdf.set_font("Arial", size=7)
		pdf.cell(55, 8, txt="", ln=0, align="L",border=1)
		pdf.cell(20, 8, txt="0", ln=0, align="R",border=1)
		pdf.cell(40, 8, txt=str(usernum * int(row['rate_per_life'][1:])), ln=0, align="R",border=1)
		pdf.output(invfile)
		cntrec=cntrec+1
	
	if mode.strip().lower()=='draft':
		print('Inv generation completeted in DRAFT Mode')
		email_log('noreply@fliptrx.com','dwagle@fliptrx.com','deepthi.gollapudi@nttdata.com','Invoice Generation Completed: '+mode+' mode',['Processing of Invoice ','Daily Rx Exception'],invfile,True)

	elif mode.strip().lower()=='final' and os.environ['INSTANCE_TYPE'] == 'PROD':
		print('Inv generation completeted in FINAL Mode')
		email_log('noreply@fliptrx.com','dwagle@fliptrx.com','deepthi.gollapudi@nttdata.com','Invoice Generation Completed: '+mode+' mode',['Processing of Invoice ','Daily Rx Exception'],invfile,True)

		
else:
	print('End of code: Not the 1st of the month')
	req.close()
	sys.exit()
	
req.no_rec_received=cntrec
req.close()
