
from utils.helper_functions import *

if __name__ == "__main__":
    from datetime import datetime
    from pprint import pprint, pformat
    from couchbase import FMT_JSON
    from couchbase.n1ql import N1QLQuery

    cmdline_rec = process_alt_cmdline()
    bucket_name = os.environ['CB_INSTANCE']
    logger = setup_logging_path('PRODSCRIPTS', 'generic_pricing_setup', 'generic_pricing')
    cb = cb_authenticate()


    data_block = dict()
    data_block['domain'] = 'NOVARTIS001'
    data_block['plan_name'] = 'HSA Plan'
    data_block['plan_year'] = '2020'
    data_block['type'] = 'generic_pricing'
    price_source=[{
        "dispensing_fee": 1.75,
        "mac_list_id": "ALLCLAIMMAC"
        },
        {"dispensing_fee": 1.25,
         "mac_list_id": "1"
         }]
    data_block['price_sources'] = price_source
    data_block['create_date'] = str(datetime.strptime(
            str(datetime.now()), "%Y-%m-%d %H:%M:%S.%f").isoformat())
    data_block['update_date'] = str(datetime.strptime(
            str(datetime.now()), "%Y-%m-%d %H:%M:%S.%f").isoformat())

    logger.info(f"Adding record: {pformat(data_block)}")
    print("Record to be inserted:")
    pprint(data_block)

    if cmdline_rec['mode'].lower() == 'final':
        logger.info(f"Adding record: {pformat(data_block)}")

        cb.upsert(str(cb.counter('docid', delta=1).value),
                  data_block, format=FMT_JSON)
        print(f"Done")
    else:
        logger.info("running in draft mode. Nothing updated")