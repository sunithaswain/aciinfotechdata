from utils.helper_functions import *
from couchbase.n1ql import N1QLQuery
from datetime import datetime

cb = cb_authenticate()
logger = setup_logging_path('PRODSCRIPTS', f"document_updates", 'document_update')

update_time = str(datetime.strptime(str(datetime.now()), "%Y-%m-%d %H:%M:%S.%f").isoformat())

# # ----------------------------------------
# # EXCLUSION DOCUMENT UPDATES - FD-321 - on hold
# # ----------------------------------------
# update_str = N1QLQuery(f"update `{os.environ['CB_INSTANCE']}` set co_insurance_type='fixed'," +
#                        f"co_insurance=0, update_date='{update_time}' " +
#                        "where type='exclusions' ")
#
# print("Update statement: " + update_str.statement)
# logger.info("Update statement: \n" + update_str.statement)
# resp = cb.n1ql_query(update_str).execute()
#
# print(f"STATUS: {resp.meta['status']}")
# logger.debug(f"STATUS: {resp.meta['status']}")

# ----------------------------------------
# domain DOCUMENT UPDATES - all domains
# FD-605, FD-286 and FD-288
# ----------------------------------------
update_str = N1QLQuery(f"update `{os.environ['CB_INSTANCE']}` " +
                        "set emp_registration_reminder2=7," +
                        "emp_registration_reminder3=14, " +
                        "emp_registration_reminder_final=30," +
                        "dependent_registration_email_reminder=7," +
                        "invoicing_fields='payer', " +
                        "enable_quantity_restriction=enable_quantity_resctriction, " +
                       f"update_date='{update_time}' " +
                       "where type='domain' ")

print("Update statement: " + update_str.statement)
logger.info("Update statement: \n" + update_str.statement)
resp = cb.n1ql_query(update_str).execute()

print(f"STATUS: {resp.meta['status']}")
logger.debug(f"STATUS: {resp.meta['status']}")


update_str = N1QLQuery(f"update `{os.environ['CB_INSTANCE']}` " +
                        "unset enable_quantity_resctriction " +
                       "where type='domain' ")

print("Update statement: " + update_str.statement)
logger.info("Update statement: \n" + update_str.statement)
resp = cb.n1ql_query(update_str).execute()

print(f"STATUS: {resp.meta['status']}")
logger.debug(f"STATUS: {resp.meta['status']}")


