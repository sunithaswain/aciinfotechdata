########################################
# !/usr/bin/env python
# title         : ndcdrugs.py
# description   :Update NDC drugs report
# author        : Disha
# date created  : 20180101
# date last modified    : 20190124 15:06
# version       : 0.1
# maintainer    : haris
# email         : hrajendran@fliptrx.com
# status        : Production
# Python Version: 3.5.2
# usage         : python ndcdrugs.py -d GWLABS001 -t ndc_drugs_new -f FLIPT_DRUG_NDC_26FEB2020.csv -m DRAFT
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  0.1							20190118	Header added
#  0.2							20190118	Log file added
# #######################################

from utils.sendgridemail import email_log
from utils import commandline
from utils.helper_functions import populate_dict
from couchbase.n1ql import N1QLQuery
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Cluster
import pandas as pd
import boto3
from datetime import datetime
import traceback
import sys
import socket
import os
import json
from couchbase.exceptions import CouchbaseTransientError
import logging
#this is an utility class to capture the no of records/logs
from utils.FliptConcurrent import concurrent
if __name__ == '__main__':
    import os
    import sys

    rootdir = os.path.dirname(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))))
    sys.path.append(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']
domain, file_type, file_name, mode = commandline.main(sys.argv[1:])
dest_dir = os.path.join(os.path.join(path, domain), file_type)

# print('this is a path',path)
# concurrent object
req=concurrent(sys.argv[0],sys.argv[1:])
log_location = path + '/' + domain + '/' + file_type + '/log/ndclog.log'
if os.path.exists(log_location) is False:
    os.makedirs(path + '/' + domain + '/' + file_type + '/log')
logging.basicConfig(filename=log_location, filemode='w',
                    format='%(name)s - %(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger()
logger.setLevel(logging.INFO)
log = 'ndclog.log'

print('---------------------------')
print(os.environ['CB_INSTANCE'])

cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(
    os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])

def display_ndc_report(pfile_name, file_type, domain, mode):
    host = socket.gethostname()
    currentdate = datetime.now()
    currentdate = currentdate.strftime("%m%d%y%H%M%S")

    list_ndc_drugs_updated = []
    subject = ''
    # file format
    # pfile_name - file from S3 which needs to be read
    file_format = os.path.splitext(pfile_name)[-1]
    logging.info("file format", str(file_format))
    # create full file path
    full_filepath = path + '/' + domain + '/' + file_type + '/' + pfile_name
    #read_file_from_S3(pfile_name, full_filepath)
    logger.info("File full path", str(full_filepath))
    # read file based on type
    if file_format == '.csv':
        #ndc_file is the dataframe
        ndc_file = pd.read_csv(full_filepath)
        columns = ndc_file.columns
        columns = [column.strip() for column in columns]
        ndc_file.columns = columns
    else:
        ndc_file = pd.read_excel(full_filepath, converters={
                                'GPI': str, 'NDC': str, 'GPPC': str})
    ndc_file.fillna("", inplace=True)
    # validations - NDC, GPI and GPPC
    ndc_file['ndc'] = ndc_file['ndc'].apply(
        lambda x: str(int(x)).zfill(11) if x != "" else x)
    ndc_file['gpi'] = ndc_file['gpi'].apply(
        lambda x: str(x).zfill(14) if x != "" else x)
    ndc_file['gppc'] = ndc_file['gppc'].apply(
        lambda x: str(x).zfill(8) if x != "" else x)
    ndc_file.columns = [x.lower().strip() for x in ndc_file.columns]
    ndc_columns = [x.lower().strip() for x in ndc_file.columns]
    # ndc_columns=list(ndc_file).apply(lambda x: x.lower().strip())
    # Fields names as per FD-562
    required = ['strengths','package_desc','pkg_desc_cd','package_size','pkg_uom','package_quantity','gppc','dosage',
			'form','dosage_strength','package_qty','custom_qty','quantity_type','ndc','maintenance_drug_code',
			'drug_class','drug_group','drug_subclass','drug_name','ddid','gpi','brand_generic','multi_source','drug_name',
            'otc_indicator','unit_dose','awp_price','mfg']
    logger.info("reading the file")
    missed_columns = [
        column_name for column_name in required if column_name not in ndc_columns]
    logger.info("Listing the missed columns", str(missed_columns))
    if len(missed_columns) > 0:
        logger.info('Missing columns - %s' % str(missed_columns))
        # Hari edited code on 20 Feb 2019
        subject = 'Error occured on NDC drug update (Missing columns - %s) :%s' % (host, missed_columns)
        email_log('noreply@fliptrx.com', 'fliptintegration@fliptrx.com', None, subject,
                  ['NDC drug update File ' + log_location, 'NDC drug update Exception'], log_location, True)
        sys.exit(1)

    # To find duplicate records
    # --------------------------------------------------------------------
    duplicate_records = ndc_file[ndc_file[[
        'gpi', 'ddid', 'brand_generic']].duplicated() == True]
    null_records = ndc_file[ndc_file[['gpi', 'drug_name',
                                    'dosage_strength']].isnull().any(axis=1)]
    if duplicate_records.shape[0] > 0:
        logger.info('Duplicate records occured in input file')
        duplicate_records.to_csv(
            path + '/' + domain + '/' + file_type + '/log/' + 'duplicate_records_' + datetime.now().isoformat() + '.csv')

    if null_records.shape[0] > 0:
        logger.info('Null records occured in input file')
        duplicate_records.to_csv(
            path + '/' + domain + '/' + file_type + '/log/' + 'null_records_' + datetime.now().isoformat() + '.csv')
    # ndc_file.fillna('')
    # --------------------------------------------------------------------

    excel_rows_count = ndc_file.shape[0]
    #1024 * 256 by default (should be less than 1 mb for successfull operation: https://docs.couchbase.com/python-sdk/2.5/batching-operations.html)
    BYTES_PER_BATCH = 1024 * 256 
    ndc_file.insert(25,'type','ndc_drugs_new')

    all_data = ndc_file.set_index(ndc_file.ndc).T.to_dict()
    batches = []
    cur_batch = {}
    cur_size = 0
    batches.append(cur_batch)
    for key,value in all_data.items():
        date_time = datetime.now()
        additional_fields = {'ndc_id':key,
                             'update_date':date_time.strftime("%Y-%m-%d %H-%M-%S.%f")}
        value.update(additional_fields)
        cur_batch[key]=value
        cur_size += len(key) + len(value) + 24
        if cur_size > BYTES_PER_BATCH:
            cur_batch = {}
            batches.append(cur_batch)
            cur_size = 0
    print("There are {} batches".format(len(batches)))
    num_completed = 0
    while batches:
        batch = batches[-1]
        try:
            cb.upsert_multi(batch)
            num_completed += len(batch)
            batches.pop()
        except CouchbaseTransientError as e:
            ok, fail = e.split_results()
            new_batch = {}
            for key in fail:
                new_batch[key] = all_data[key]
            batches.pop()
            batches.append(new_batch)
            num_completed += len(ok)
            print("Retrying {}/{} items".format(len(new_batch),len(ok)))
        print("Completed {}/{} items".format(num_completed,len(all_data)))
    
    if subject == '':
        subject = 'NDC drug update status :' + host
    email_log('noreply@fliptrx.com', 'FliptIntegration@fliptrx.com', 'FliptIntegration@fliptrx.com', subject,
              ['NDC drug update File ' + log_location, 'NDC drug update Exception'], log_location, False)

    #move processed file to archive folder
    if mode.strip().upper() == 'FINAL':
        if not os.path.isdir(path + '/' + domain + '/' + file_type + '/archive/'):
            os.makedirs(
                path + '/' + domain + '/' + file_type + '/archive/')
        os.rename(full_filepath, path + '/' + domain +
                  '/' + file_type + '/archive/' + pfile_name)
    move_file_to_archive(file_name)
    print("File moved to archive")
    return num_completed

def parse_args():
    return commandline.main(sys.argv[1:])


def process(file_name, file_type, domain, mode):
    if file_name:
        logger.info("Received file name as ", str(file_name))
        return display_ndc_report(file_name, file_type, domain, mode)


def read_file_from_S3(dest_dir, file_name=None):
    # AWS File location
    _BUCKET_NAME = os.environ['AMAZON_SFTP_BUCKET']
    s3_resource = boto3.resource('s3')
    s3_bucket = s3_resource.Bucket(_BUCKET_NAME)
    modified_date = None
    source_file_name = ''
    for obj in s3_bucket.objects.filter(Prefix="dataload_{}/uploads/{}".
                                        format(os.environ['INSTANCE_TYPE'].lower(), file_name or 'FLIPT_DRUG_NDC_')):
        if os.path.basename(obj.key).startswith('FLIPT_DRUG_NDC_') and ((modified_date and modified_date < obj.last_modified) or not modified_date):
            source_file_name = os.path.basename(obj.key)
            modified_date = obj.last_modified

    if not source_file_name:
        logger.info("No files found with pattern FLIPT_DRUG_NDC_")
        sys.exit(1)
    source_file_name = source_file_name.split('000')[0]
    source_path = 'dataload_{}/uploads/{}'.format(os.environ['INSTANCE_TYPE'].lower(),
                                                  source_file_name + '000')
    boto3.client(
        's3',
        aws_access_key_id=os.environ['AWS_ACCESS_KEY_ID'],
        aws_secret_access_key=os.environ['AWS_SECRET_ACCESS_KEY']
    )
    dest_path = os.path.join(dest_dir, source_file_name)
    s3_bucket.download_file(source_path, dest_path)
    return source_file_name, dest_path


def move_file_to_archive(source_file_name):
    bucket_name = os.environ['AMAZON_SFTP_BUCKET']
    upload_path = 'dataload_{}/uploads'.format(
        os.environ['INSTANCE_TYPE'].lower())
    source_path = '{}/{}'.format(upload_path, source_file_name)
    dest_path = '{}/Archive/{}'.format(upload_path, source_file_name)

    boto3.client(
        's3',
        aws_access_key_id=os.environ['AWS_ACCESS_KEY_ID'],
        aws_secret_access_key=os.environ['AWS_SECRET_ACCESS_KEY']
    )
    s3_resource = boto3.resource('s3')
    copy_source = {'Bucket': bucket_name,
                   'Key': source_path}
    s3_resource.Bucket(bucket_name).copy(copy_source, dest_path)
    s3_resource.Object(bucket_name, source_path).delete()


def main():
    global dest_dir
    logger.info("Started the process working as intended")
    domain, file_type, file_name, mode = parse_args()
    # for custom filename -f <file-name> else -f ''
    file_name = file_name.split('000')[0]
    file_name, dest_dir = read_file_from_S3(dest_dir, file_name=file_name)

    record_count = process(file_name, file_type, domain, mode)
    # to handle job tracking
    req.no_rec_received = record_count
    req.close()

main()