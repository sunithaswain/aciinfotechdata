########################################
# !/usr/bin/env python

# title : drug_alt.py
# description : Drug Alternate data update
# author : Alex
# date created : 1/30/2019
# last  modified : 2/5/2019
# version : 1
# maintainer : Alex
# email : -
# status : Dev
# Python Version: 3.5.2
# usage         :   python drug_alt.py -d GWLABS001 -t drug_alternative -f Drug_Alternative01282019.xlsx -m draft
#                   python drug_alt.py -d GWLABS001 -t drug_alternative -f Drug_Alternative01282019.xlsx -m final
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


#########################################


if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']
import os
import sys
import socket
from datetime import datetime
import json
import pandas as pd
import numpy as np
import socket

from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from couchbase import FMT_JSON
import couchbase.subdocument as SD

from utils.sendgridemail import email_log
from utils import commandline

# import pdb;pdb.set_trace()

domain_name, file_type, filename, mode = commandline.main(sys.argv[1:])
cluster = Cluster(os.environ['CB_URL'])
bucket_name = os.environ['CB_INSTANCE']
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(bucket_name)

host = socket.gethostname()
# logpath=path+'/'+str(file_type)+'/log/'
# log = pd.DataFrame()
#
# logfile = open(os.environ['CB_DATA']+ '/' + str(file_type) + '/log/log_test.txt' , 'w')
# logfile.write('------------------Drug Alternate------------------' + '\r\n\r\n')

df = pd.read_excel(os.environ['CB_DATA'] + '/' + str(file_type) + '/' + str(filename),
                   header=2)

col_dict = {
    'DDC Code': 'ddc_code',
    'GPI Number': 'gpi',
    'DDID': 'ddid',
    'Name': 'drug_name',
    'Brand/Generic (B/G)': 'brand_generic',
    'Equivalent Dosage (GPI)': 'equivalent_dosage'
}
df.rename(columns=col_dict, inplace=True)

df['ddc_code'] = df[df['ddc_code'].map(lambda x: str(x) != 'No Interchange')]
df['gpi'] = df['gpi'].apply(lambda x: str(x))
df['ddid'] = df['ddid'].apply(lambda x: str(x)[:-2])

ddc_values = [x for x in df['ddc_code'].unique()]
ddc_values.remove(np.nan)
# print(ddc_values)

# group by ddc
ddc_grp = df.groupby(df['ddc_code'])

# iterate through each drug in ddc

if str(mode).upper() == 'FINAL':
    delete_query = N1QLQuery('DELETE from `' + os.environ['CB_INSTANCE'] + '` where type="drug_alternative_stg"')
    cb.n1ql_query(delete_query).execute()


def alt_drug_update():

    """
    This function processes drug alternate data and loads into couchbase.
    Takes in no arguments.
    """

    #global logfile
    master = dict()
    alternate_drugs = pd.DataFrame()
    for key, grp in ddc_grp:
        # import pdb
        # pdb.set_trace()
        
        # add dict logic
        brand_generic_list = list(grp['brand_generic'])
        try:
            brand_generic_list.remove('G')
        except ValueError:
            pass
        generic_flag = False
        if 'G' in brand_generic_list:
            generic_flag = True

        print('number of drugs with ddc code {0}: {1}'.format(key, len(grp)))
        
        for i, r in grp.iterrows():

            drug_record = dict()
            drug_record['type'] = 'drug_alternative_stg'
            drug_record['update_date'] = datetime.now().isoformat()
            drug_record['create_date'] = datetime.now().isoformat()

            for col in df.columns:
                drug_record[col] = str(r[col]).strip()

            query = N1QLQuery('Select dosage, strengths from `' + os.environ[
                'CB_INSTANCE'] + '` where type="drug" and drug_name=$dn and gpi=$gpi', dn=drug_record['drug_name'],
                              gpi=drug_record['gpi'])
            query.adhoc = False
            query.timeout = 300
        
            for drug_row in cb.n1ql_query(query):
                drug_record['dosage'] = drug_row['dosage']
                drug_record['strengths'] = drug_row['strengths']
                continue
           
            alt_counter = 0
            for j, entry in grp.iterrows():

                # if current drug EQ dosage divided by the iterated drug's EQ dosage does not equal 0, skip                  
                if float(drug_record['equivalent_dosage']) / float(entry['equivalent_dosage']) != 1:
                    continue
                # if current drug is a generic, skip branded drugs. Else if drug is brand, return all alt drugs. 
                if drug_record['brand_generic'] == 'G' and entry['brand_generic'] != 'G':
                    continue
                # if gpi of current drug and iterated drug are the same, skip
                if drug_record['gpi'] == entry['gpi']:
                    continue

                alt_counter += 1

                drug_record['equivalent_ratio'] = float(drug_record['equivalent_dosage']) / float(entry['equivalent_dosage'])
                for c in df.columns:
                    drug_record['alt_' + c] = entry[c]
                
                alt_query = N1QLQuery('Select dosage, strengths from `' + os.environ[
                    'CB_INSTANCE'] + '` where type="drug" and drug_name=$dn and gpi=$alt_gpi', dn=entry['drug_name'],
                     alt_gpi=str(entry['gpi']))
                alt_query.adhoc = False
                alt_query.timeout = 300
                
                for alt_drug_row in cb.n1ql_query(alt_query):
                    # print(alt_drug_row)
                    drug_record['alt_dosage'] = alt_drug_row['dosage']
                    drug_record['alt_strengths'] = alt_drug_row['strengths']
                    continue
                # print(json.dumps(drug_record, indent=4))

                if str(mode).upper() == 'FINAL':
                    cb.upsert(str(cb.counter('docid', delta=1).value), drug_record, format=FMT_JSON)
                alternate_drugs = alternate_drugs.append(drug_record, ignore_index=True)

            print('Alt Counter for {0} (GPI={1}): {2}'.format(drug_record['drug_name'], drug_record['gpi'], alt_counter))
        print(alternate_drugs.head())
        
        # break mechanism in order to stop after first DDC group
        # if True:
        #     break
    
    alternate_drugs.to_excel(os.path.join(os.environ['CB_DATA'], file_type, 'alternate_drugs{0}.xlsx'.format(datetime.today().isoformat())))
    if str(mode).upper() != 'FINAL':
        print('Records not upserted; mode not final.')


if __name__ == '__main__':
    alt_drug_update()
