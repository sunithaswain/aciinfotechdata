########################################
# !/usr/bin/env python
# title : drugdb_update.py
# description : Update drug database -(update brand generic of cp drug price)
# author : Rajesh Acharya
# date created : July 15, 2019
# last  modified : Sep 3, 2019
# version : 1
# maintainer : 
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  python drugdb_update.py -d GWLABS001 -t DRUG_DATABASE -f '' -m draft
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------
#
#
# # #######################################
import os
import re
import sys
import boto3

import pandas as pd
from datetime import datetime

import couchbase.subdocument as subdoc
from couchbase import FMT_JSON
from couchbase.n1ql import N1QLQuery

from drugdb.updatedrugdisplayrank import update_displayrank
from utils import commandline as commandline
from utils.sendgridemail import email_log_custombody
from utils.helper_functions import *
from utils.aws_s3_functions import *

path = os.environ['CB_DATA']
log_path = os.environ['LOGDIR']


def save_data(cb_hndl, record_set, tr_mode, log_hndl):
    # log_hndl.info(f"Updating record for: {record_set}")
    if tr_mode.upper().strip() == 'FINAL':
        for doc_id in record_set:
            for upd_flds in ['speciality_flag', 'price_status', 'update_date']:
                try:
                    cb_hndl.mutate_in(doc_id, subdoc.upsert(upd_flds, record_set[doc_id][upd_flds]))
                except Exception as e:
                    log_hndl.error(f"Error updating record for: {record_set}")
                    log_hndl.error(f"Exception occurred {upd_flds}, {record_set[doc_id][upd_flds]}", exc_info=True)
                    continue
            # fields to update
        # doc_ids to update
    # end tr_mode
# end function


def create_pandasdf(in_set, in_str, log_hndl):
    log_hndl.info(f"Create - pandas dataframe for: {in_str}")
    print(f'creating pandas df for: {in_str} ... ', end='', flush=True)
    temp_df = pd.DataFrame()
    temp_list = []
    for row in in_set:
        (ddid, gpi, brandgen, drugname) = row
        temp = {'ddid': ddid, 'gpi': gpi, 'brandgen': brandgen, 'drug_name': drugname}
        temp_list.append(temp)

    temp_df = temp_df.append(temp_list, ignore_index=True)
    log_hndl.info("DF completed.")
    print("Done\n")
    return temp_df
# end function


def save_records(in_data_pth, outfilename, records):
    try:
        os.chdir(in_data_pth)
    except FileNotFoundError:
        os.mkdir(in_data_pth)

    date_str = datetime.now().strftime("%Y%m%d")
    output_filename = f"{in_data_pth}/DRUGDB_{outfilename}_{date_str}.csv"
    output = open(output_filename, 'w')
    headerline = "ddid;gpi;brand_generic;drug_name;status;price_status;speciality_flag"
    with output as of:
        of.write(headerline + "\n")
        for row in records:
            line_str = "%s;%s;%s;%s;%s;'%s';%s\n" %(records[row]['ddid'], records[row]['gpi'],
                                                    records[row]['brand_generic'],
                                                    records[row]['drug_name'],
                                                    records[row]['status'],
                                                    records[row]['price_status'],
                                                    records[row]['speciality_flag'])
            of.write(line_str)
        # end for-loop
    # end with-context
# end function


def update_drugdb(cb_hndl, bucket_val, mode, datafp, medispan, drug_df, cpprice_df, log_hndl):
    import itertools


    def determine_priceavailability(cp_price_lst):
        """
        function to determine if the unitprice column is populated for
        all entries of 'claim_processor'.  if the price is available for
        a claim_processor, the incr the avail_prices.
        Finally, if the avail_prices != len(cp_price_list) return appropriate result.
        :param cp_price_lst:
        :return: "price does not exist","active" | "price exists","inactive"
        """
        avail_prices = 0

        # check if the cp_price_list passed in is a string,
        # if so convert it to a list
        if '[' in cp_price_lst:
            cp_price_lst = convertstr(cp_price_lst)

        for rows in cp_price_lst:
            if rows['unitprice'] not in ('nan', ''):
                avail_prices += 1

        if avail_prices != len(cp_price_lst):
            return "price does not exist", 'inactive'
        else:
            return "price exists", 'active'
    # end function


    def is_humanas(cp_price_lst):
        """
        Check each entry of the cp_price_list.  if 'sc_humanas' is an
        available 'claim_processor', return 'Y'
        :param cp_price_lst:
        :return: 'N' if 'sc_humanas' not present.
        """
        if '[' in cp_price_lst:
            cp_price_lst = convertstr(cp_price_lst)

        for rows in cp_price_lst:
            if rows['claim_processor'] == 'sc_humanas':
                return "Y"
        return "N"
    # end function


    def process_DF(main_dataframe, drugdb_dataframe, cpprices_dataframe, cbhndl, loghndl, op_mode):
        """
        This function process the dataframe passed-in and returns a dictionary of active and inactive drugs
        :param main_dataframe: (data frame being processed)
        :param drugdb_dataframe:
        :param cpprices_dataframe:
        :param cbhndl:
        :param loghndl:
        :param op_mode:
        :return: active_drug_hash, inactive_drug_hash
        """
        active_drug_hash = dict()
        inactive_drug_hash = dict()

        changebg = lambda txt: txt.strip().replace('B', 'Brand').replace('T', 'Brand').replace('G', 'Generic')

        for key, grp in main_dataframe.groupby(['ddid', 'gpi', 'brandgen', 'drug_name']):
            save_rec = dict()
            working_hash = dict()

            grp.reset_index(drop=True, inplace=True)
            if ((grp['gpi'].values[0] == drugdb_dataframe['gpi']) &
                (grp['drug_name'].values[0] == drugdb_dataframe['drug_name']) &
                (grp['brandgen'].values[0] == drugdb_dataframe['brand_generic']) &
                (grp['ddid'].values[0] == drugdb_dataframe['ddid'])).any() == True:
                drugdb_docid = drugdb_dataframe.loc[((grp['gpi'].values[0] == drugdb_dataframe['gpi']) &
                                    (grp['ddid'].values[0] == drugdb_dataframe['ddid']) &
                                    (grp['drug_name'].values[0] == drugdb_dataframe['drug_name']) &
                                    (grp['brandgen'].values[0] == drugdb_dataframe['brand_generic'])), 'id'].values[0]

                update_date = datetime.now().strftime("%Y-%m-%d")
                working_hash[drugdb_docid] = {'ddid': grp['ddid'].values[0],
                                                    'gpi': grp['gpi'].values[0],
                                                    'brand_generic': grp['brandgen'].values[0],
                                                    'drug_name': grp['drug_name'].values[0],
                                                    'speciality_flag': 'N',
                                                    'status': 'active',
                                                    'update_date': update_date,
                                                    'price_status': 'price does not exist'}

                if grp['gpi'].values[0] == '00000000000000':
                    working_hash[drugdb_docid]['status'] = 'active'
                    working_hash[drugdb_docid]['price_status'] = 'price exists'
                    save_rec[drugdb_docid] = working_hash[drugdb_docid]
                    active_drug_hash[drugdb_docid] = working_hash[drugdb_docid]
                else:
                    if ((grp['gpi'].values[0] == cpprices_dataframe['gpi']) &
                        (grp['drug_name'].values[0] == cpprices_dataframe['drug_name']) &
                        (changebg(grp['brandgen'].values[0]) == cpprices_dataframe['brandorgeneric'])).any() == True:
                        cp_price = cpprices_dataframe.loc[((grp['gpi'].values[0] == cpprice_df['gpi']) &
                                               (grp['drug_name'].values[0] == cpprice_df['drug_name']) &
                                               (changebg(grp['brandgen'].values[0]) == cpprice_df['brandorgeneric'])),
                                              'cp_price'].values[0]
                        (price_status, drug_status) = determine_priceavailability(cp_price)
                        if (price_status == 'price does not exists' and status == 'active'):
                            drug_status = 'active'

                        working_hash[drugdb_docid]['price_status'] = price_status
                        working_hash[drugdb_docid]['status'] = drug_status
                        working_hash[drugdb_docid]['speciality_flag'] = is_humanas(cp_price)
                        active_drug_hash[drugdb_docid] = working_hash[drugdb_docid]

                    else:  # drug not in cpprice
                        inactive_drug_hash[drugdb_docid] = working_hash[drugdb_docid]

                    save_rec[drugdb_docid] = working_hash[drugdb_docid]
                save_data(cbhndl, save_rec, op_mode, loghndl)
                continue
        # end outer loop
        return active_drug_hash, inactive_drug_hash
    # end function - process_DF


    # # update all drugs in drugdb as 'active' and price_status as 'price exists'
    '''
    if mode.upper() == 'FINAL':
        log_hndl.info("Setting 'active' on all drugs in drugDB")
        print("Setting 'active' status on all drugs in drugDB ... ", end='', flush=True)
        query = N1QLQuery('UPDATE `' + bucket_val + '` ' +
                                     'SET status = $status, ' +
                                     'price_status="price exists" ' +
                                     'WHERE type = "drug"',
                                 status=str('active'))
        query.timeout = 3600
        cb_hndl.n1ql_query(query).execute()
        print('Done.\n')
    '''
    # end condition

    changedcols = populate_dict2(medispan)
    medispan.rename(columns=changedcols, inplace=True)

    # remove un-needed columns for this check process
    medispan.drop(['multi_source', 'unit_dose', 'strengths', 'package_desc', 'pkg_desc_cd',
                   'package_size', 'pkg_uom', 'package_quantity', 'dosage', 'form', 'dosage_strength',
                   'package_qty', 'display_rank', 'generic_rank', 'otc_indicator', 'custom_qty',
                   'quantity_type', 'drug_class', 'drug_group', 'drug_subclass', 'created_date',
                   'updated_date', 'drug_full_name', 'maintenance_drug_flag'], axis=1, inplace=True)

    medispan.drop_duplicates(inplace=True)
    medispan['gppc'] = medispan['gppc'].apply(lambda x: str(x).zfill(8))
    medispan['gpi'] = medispan['gpi'].apply(lambda x: str(x).zfill(14))
    medispan['ddid'] = medispan['ddid'].apply(lambda x: str(x))

    active_drugs = dict()
    other_active_dbdrugs = dict()
    inactive_drugs = dict()
    other_inactive_dbdrugs = dict()

    drug_df['drug_name'] = drug_df['drug_name'].str.upper()
    cpprice_df['drug_name'] = cpprice_df['drug_name'].str.upper()

    # create a set with unique items for medispan drugs
    ms_brandgen = list(medispan['brand_generic'])
    ms_ddid = list(medispan['ddid'])
    ms_gpi = list(medispan['gpi'])
    ms_drugname = list(medispan['drug_name'])
    medispan_set = set([rows for rows in itertools.zip_longest(ms_ddid, ms_gpi, ms_brandgen, ms_drugname)])

    # create a set with unique items from drug_db
    drugdb_gpi = list(drug_df['gpi'])
    drugdb_ddid = list(drug_df['ddid'])
    drugdb_dname = list(drug_df['drug_name'])
    drugdb_brandgen = list(drug_df['brand_generic'])
    drugdb_set = set([rows for rows in itertools.zip_longest(drugdb_ddid, drugdb_gpi,
                                                             drugdb_brandgen, drugdb_dname)])

    # calculate set differences: NOT IN MEDISPAN and OTHER_ACTIVE_DRUGS (in drugdb)
    not_in_medispan = sorted(drugdb_set - medispan_set)
    other_active_drugs = sorted(drugdb_set - set(not_in_medispan))
    log_hndl.info("Total drugs not in medispan: %s" % (len(not_in_medispan)))
    log_hndl.info("Total other active drugs: %s" % (len(other_active_drugs)))

    # panda dataframes
    drug_notin_medispan_df = create_pandasdf(not_in_medispan, 'drugs not in medispan', log_hndl)
    active_drugs_df = create_pandasdf(other_active_drugs, 'other active drugs', log_hndl)

    # delete variables
    del ms_drugname
    del ms_brandgen
    del ms_gpi
    del ms_ddid
    del drugdb_ddid
    del drugdb_gpi
    del drugdb_brandgen
    del drugdb_dname
    del medispan
    del medispan_set
    del not_in_medispan

    # loop thru drugs_notin_medispan DF
    log_hndl.info("checking and updating status: for drugs not in medispan ...")
    print("Updating records for drugs not in medispan... ", end='', flush=True)
    active_drugs, inactive_drugs = process_DF(drug_notin_medispan_df, drug_df, cpprice_df,
                                              cb_hndl, log_hndl, mode)
    print("Done\n")
    log_hndl.info("Number of active drugs (not in medispan) with updates: %s" % (len(active_drugs)))
    log_hndl.info("Number of records marked inactive in drugdb (not in medispan): %s" % (len(inactive_drugs)))

    save_records(datafp, "ACTIVE_DRUGS_NOT-IN_MEDISPAN", active_drugs)
    save_records(datafp, "INACTIVE_DRUGS_NOT-IN_MEDISPAN", inactive_drugs)

    # loop thru active_drugs DF
    log_hndl.info("checking and updating status: for other active drugs ...")
    print("Updating records for other active drugs... ", end='', flush=True)
    other_active_dbdrugs, other_inactive_dbdrugs = process_DF(active_drugs_df, drug_df, cpprice_df,
                                                              cb_hndl, log_hndl, mode)
    print("Done\n")

    log_hndl.info("Number of other active drugs for updates: %s" % (len(other_active_dbdrugs)))
    log_hndl.info("Number of records marked inactive for other active drugs: %s" %(len(other_inactive_dbdrugs)))

    save_records(datafp, "ACTIVE_DRUGS_IN_DRUGDB", other_active_dbdrugs)
    save_records(datafp, "INACTIVE_DRUGS_IN_DRUGDB", other_inactive_dbdrugs)
# end function


def parse_args():
    return commandline.main(sys.argv[1:])
# end function


def load_lookups(cb_handle, in_query, db_doc, log_hndl, log=True, returndf=True):
    query = N1QLQuery(in_query)
    temp_df = pd.DataFrame()
    temp_list = []
    query.timeout = 2700

    if log is True:
        log_hndl.info(f"querying {db_doc} table and storing the data in {db_doc}df data frame")
        print(f"\nAdding rows to {db_doc} dataframe ... ", end='', flush=True)

    for row in cb_handle.n1ql_query(query):
        temp_list.append(row)

    if returndf is True:
        temp_df = temp_df.append(temp_list, ignore_index=True)
    else:
        return temp_list

    if log is True:
        print("Done")
        log_hndl.info(f"Number of rows in {db_doc} dataframe: {temp_df.shape}")
    return temp_df
# end function


def generate_table(in_list):
    table_str = ""

    table_str += "\tNum Recs\tPrice Status         \t\tStatus\n"
    table_str += "\t--------\t---------------------\t\t------\n"
    for row in in_list:
        try:
            price_status = row['price_status']
        except KeyError:
            price_status = '-- unknown -----'
        table_str += "\t%-5d\t\t%-25s\t%-10s\n" % (row['num_recs'], price_status, row['status'])

    return table_str
# end function


def load_medispan(cb_hndl, bucket_val, pfile_name, file_type, mode, log_hndl,
                  drug_df, cpprice_df):
    log_hndl.info(f"Inside updated function received {file_type}, {pfile_name}, \nmode as {mode}")
    log_hndl.info("Starting reading the drug update file")
    try:
        medispan_df = pd.read_csv(pfile_name, dtype='unicode')
    except FileNotFoundError:
        log_hndl.error("Unable to read DRUG update file: %s" % pfile_name)
        return

    datalog_pth = os.path.dirname(pfile_name) + "/log"
    update_drugdb(cb_hndl, bucket_val, mode, datalog_pth, medispan_df, drug_df, cpprice_df, log_hndl)

    log_hndl.info('---DrugDatabase (ScriptClaim) Update Done----')
    log_hndl.info("Querying counts")
    query = f"select status, price_status, count(*) as num_recs from `{bucket_val}`"
    query += "where type='drug' group by status, price_status order by status asc"
    countdf = load_lookups(cb_hndl, query, 'drug', log_hndl, log=False, returndf=False)

    log_hndl.info("==============================================================\n")

    body_statement = f"Dear Admin Team,\n\nDrug Database (ScriptClaim) file : {pfile_name}\n"
    body_statement += f"completed at {str(datetime.now())}.  All relevant files moved to S3.\n\n"
    body_statement += generate_table(countdf)

    body_statement += f"\nPlease review the log file on S3."
    body_statement += f"\nAlso run Couchbase DrugDatabase (ScriptClaim) Exception SQL "
    body_statement += "to find more information.\n\nBest regards,\nFLIPT Integration Team"

    print("Sending completion email")
    sender = 'DWagle@fliptrx.com'
    receiver = ['DWagle@fliptrx.com', 'sukuamr@fliptrx.com', 'FliptIntegration@fliptrx.com']
    subject = 'DrugDatabase (ScriptClaim) Update - Completed'
    email_log_custombody('noreply@fliptrx.com', 'FliptIntegration@fliptrx.com', receiver,
                  subject, body_statement, '', attached=False)

    logger.info("Sent completion email.")

    return datalog_pth
# end function


def main(cb_hndl, bucket_nm, log_hndlr):
    log_hndlr.info("Started the process. working as intended")
    domain, file_type, file_name, mode = parse_args()
    # for custom filename -f <file-name> else -f ''
    dest_dir = os.path.join(path, file_type)
    try:
        os.chdir(dest_dir)
    except FileNotFoundError:
        os.mkdir(dest_dir)
        os.mkdir(dest_dir + "/log")

    # read_file_from_S3(pfile_name, full_filepath)
    print("Getting datafiles from S3 folder ... ", end='', flush=True)
    file_name = read_file_from_S3(log_hndlr, dest_dir)
    print("Done\n")

    data_dir = os.path.dirname(file_name)

    # drugdb query and cpprice query definition
    drugdb_query = f'Select meta().id id, ddid, gpi, brand_generic, drug_name, status from `{bucket_nm}` '
    drugdb_query += 'where type="drug"'
    drug_df = load_lookups(cb_hndl, drugdb_query, 'drug', log_hndlr)

    cpprice_query = f'Select distinct gpi, drug_name, brandorgeneric, cp_price from `{bucket_nm}` '
    cpprice_query += 'where type="cp_drug_price"'
    cpprice_df = load_lookups(cb_hndl, cpprice_query, 'cp_price', log_hndlr)

    drug_df['gpi'] = drug_df['gpi'].apply(lambda x: str(x).zfill(14))
    drug_df['ddid'] = drug_df['ddid'].apply(lambda x: str(x))
    cpprice_df['gpi'] = cpprice_df['gpi'].apply(lambda x: str(x).zfill(14))

    datalog_path = load_medispan(cb_hndl, bucket_nm, file_name, file_type, mode, log_hndlr,
                  drug_df, cpprice_df)

    if mode.strip().upper() == 'FINAL':
        logger.info("Moving the file to archive folder")
        move_file_to_archive(file_name)

        logger.info("Moving run_files to downloads")
        move_file_to_S3(logger, datalog_path)

        logger.info("Updating drug display rank")
        update_displayrank()
# end function


if __name__ == "__main__":
    # get Couch-base handle
    cb_handle = cb_authenticate()
    

    # add new logger
    logger = setup_logging_path('DRUG_DATABASE', 'drugdb_update', 'DRUGUPDATE')

    bucket_name = os.environ['CB_INSTANCE']
    main(cb_handle, bucket_name, logger)

    logpth = os.path.dirname(logger.handlers[0].baseFilename)
    move_file_to_S3(logger, logpth, erase=False)
    logger.shutdown()
# end main

