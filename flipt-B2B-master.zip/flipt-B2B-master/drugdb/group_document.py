########################################
# !/usr/bin/env python
# title         : group_document.py
# description   : Update retail drugs that have allowance for being refilled
# author        : RRajesh Acharya
# date created  : 2020-01-16
# date last modified    :
# version       : 0.1
# maintainer    : Rajesh
# email         :
# status        :
# Python Version: 3.7.3
# usage         : python group_document -d GWLABS001 -t groups -f Group_Document.xlsx -m DRAFT
# Notes         : keep the xlsx at this location \FLIPTB2B\data\<DOMAIN>/groups
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#
# #######################################

import os
import sys
from formulary.formulary_functions import load_drugdocument

import pandas as pd
from couchbase.n1ql import N1QLQuery
from utils.helper_functions import *

path = os.environ['CB_DATA']
# add new logger
logger = setup_logging_path('GROUP_DB', 'group_doc_update', 'group_doc')

cmdline_args = process_alt_cmdline([['-d', '--domain', 'Domain for the group details', True],
                                    ["-t", "--file_type", "pass in doc type", True],
                                    ["-f", "--file_name", "pass in file name", True]])

domain_nm = cmdline_args['domain']
file_type = cmdline_args['file_type']
file_name = cmdline_args['file_name']
mode = cmdline_args['mode']

bucket_name = os.environ['CB_INSTANCE']
cb = cb_authenticate()

file_format = os.path.splitext(file_name)[-1]
file_path = f"{path}/{domain_nm}/{file_type}/{file_name}"
try:
    if file_format == ".csv":
        data = pd.read_csv(file_path)
    else:
        data = pd.read_excel(file_path)
except FileNotFoundError:
    print(f"ERROR: File specified does not exist at location: {os.path.dirname(file_path)}")
    sys.exit(-1)

data.fillna("", inplace=True)
logger.debug(f"Number of records in File {str(data.shape[0])}")

# read in the drugdb
records_added = 0
records_updated = 0

print(f"Running in < {os.environ['INSTANCE_TYPE']} >")
print(f"Processing started for file: {file_path}")
logger.info(f"Processing started for file: {file_path}")
for index, row in data.iterrows():
    metaid = ''
    data_dict = populate_dict(data, row)
    data_dict['type'] = 'drug_group'

    df = pd.DataFrame()

    try:
        start_date = str(datetime.strptime(data_dict['effective_start_date'], "%Y-%m-%d %H:%M:%S"))
    except KeyError:
        pass

    try:
        end_date = str(datetime.strptime(data_dict['effective_end_date'], "%Y-%m-%d %H:%M:%S"))
    except KeyError:
        pass

    data_dict['updated_at'] = datetime.strptime(str(datetime.now()), "%Y-%m-%d %H:%M:%S.%f").isoformat()

    query = N1QLQuery('SELECT META().id as id FROM `' + bucket_name + '`WHERE type="group" and domain=' +
                      '$domainname  effective_start_date=$startdate ' +
                      'and effective_end_date=$enddate and ' +
                      'plan_name = $planname',
                      domainname=data_dict['domain'],
                      planname=data_dict['plan_name'],
                      startdate=start_date,
                      enddate=end_date)

    query.timeout = 7200
    try:
        query_result = cb.n1ql_query(query).get_single_result()
        metaid = query_result['id']
    except:
        metaid = ''

    if mode.upper().strip() == 'FINAL':
        if metaid != '':
            logger.info(f"Updated existing information for {data_dict['group_condition']}:" +
                        f"{data_dict['drug_name']}")
            records_updated += 1
            cb.upsert(str(metaid), data_dict)
            logger.debug(f"updated the record {metaid} with the data {data_dict}")
        else:
            records_added += 1
            logger.info(f"New entry created for {data_dict['group_condition']}")
            data_dict['created_at'] = datetime.strptime(str(datetime.now()),
                                                        "%Y-%m-%d %H:%M:%S.%f").isoformat()
            cb.upsert(str(cb.counter('docid', delta=1).value), data_dict)

    else:
        logger.debug("group update program is running in draft mode")
# end for-loop

print("\n\n")
print(f"      Records added: {records_added}")
print(f"    Records updated: {records_updated}")
print(f"Log file: {logger.handlers[0].baseFilename}")
