########################################
# !/usr/bin/env python
# title         : retailrefill_update.py
# description   : Update retail drugs that have allowance for being refilled
# author        : RRajesh Acharya
# date created  : 2020-01-16
# date last modified    :
# version       : 0.1
# maintainer    : Rajesh
# email         :
# status        :
# Python Version: 3.7.3
# usage         : python retailrefill_update.py -d GWLABS001 -t DRUG_DATABASE -f rra_drugs.xlsx -m DRAFT
# Notes         : keep the data.xlsx at this location \FLIPTB2B\data\DRUG_DATABASE
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#
# #######################################

import os
import sys
from formulary.formulary_functions import load_drugdocument, brandgen_val

import pandas as pd
from couchbase.n1ql import N1QLQuery
from utils.helper_functions import *


def load_ndcdrugdocument(cb_handle, log_hndl=None):
    # load drug database

    if log_hndl is not None:
        log_hndl.info("Loading drugdb information ...")

    print("Loading ndc_drugs database rows ...", end='', flush=True)
    query = N1QLQuery('SELECT distinct mfg, gpi, ddid, drug_name, ndc, brand_generic, gppc FROM `' +
                      os.environ['CB_INSTANCE'] + '` where type="ndc_drugs" ')
    query.timeout = 7200
    temp_df = pd.DataFrame()
    ndcdrug_list = []

    for row in cb_handle.n1ql_query(query):
        ndcdrug_list.append(row)

    temp_df = temp_df.append(ndcdrug_list, ignore_index=True)
    temp_df['gpi'] = temp_df['gpi'].apply(lambda x: str(x).zfill(14))
    temp_df['brand_generic'] = temp_df['brand_generic'].apply(lambda x: brandgen_val(str(x).strip()))
    del ndcdrug_list

    if log_hndl is not None:
        log_hndl.info(f"Done loading ndc_drugs db. Num recs: {temp_df.size}")
    print("Done\n")

    return temp_df
# end function


path = os.environ['CB_DATA']
# add new logger
logger = setup_logging_path('DRUG_DATABASE', 'rra_drugs_update', 'rra_drugs')

cmdline_args = process_alt_cmdline([["-t", "--file_type", "pass in doc type", True],
                                    ["-f", "--file_name", "pass in file name", True]])

file_type = cmdline_args['file_type']
file_name = cmdline_args['file_name']
mode = cmdline_args['mode']

bucket_name = os.environ['CB_INSTANCE']
cb = cb_authenticate()

file_format = os.path.splitext(file_name)[-1]
try:
    if file_format == ".csv":
        data = pd.read_csv(path + '/' + file_type + '/' + file_name)
    else:
        data = pd.read_excel(path + '/' + file_type + '/' + file_name)
except FileNotFoundError:
    print(f"ERROR: File specified does not exist at location: {path}/{file_type}")
    sys.exit(-1)

data.fillna("", inplace=True)
logger.debug(f"Number of records in File {str(data.shape[0])}")

# read in the drugdb
drug_db = load_drugdocument(cb, log_hndl=logger)
ndcdrug_db = load_ndcdrugdocument(cb, log_hndl=logger)

records_added = 0
records_updated = 0
records_errored = 0

print(f"Running in < {os.environ['INSTANCE_TYPE']} >")
print(f"Processing started for file: {path}/{file_type}/{file_name}")
logger.info(f"Processing started for file: {path}/{file_type}/{file_name}")
for index, row in data.iterrows():
    metaid = ''
    data_dict = populate_dict(data, row)
    data_dict['type'] = 'rra_drugs'

    df = pd.DataFrame()

    try:
        start_date = str(datetime.strptime(data_dict['coverage_effective_date'], "%Y-%m-%d %H:%M:%S"))
    except KeyError:
        try:
           start_date = str(datetime.strptime(data_dict['start_date'], "%Y-%m-%d %H:%M:%S"))
        except ValueError:
           start_date = str(datetime.strptime(data_dict['start_date'], "%Y-%m-%d %H:%M:%S.%f"))

    try:
        end_date = str(datetime.strptime(data_dict['coverage_end_date'], "%Y-%m-%d %H:%M:%S"))
    except KeyError:
        try:
           end_date = str(datetime.strptime(data_dict['end_date'], "%Y-%m-%d %H:%M:%S"))
        except ValueError:
           end_date = str(datetime.strptime(data_dict['end_date'], "%Y-%m-%d %H:%M:%S.%f"))
           end_date = end_date.replace(':58.995000', ':59')

    data_dict['updated_at'] = datetime.strptime(str(datetime.now()), "%Y-%m-%d %H:%M:%S.%f").isoformat()

    # lookup GPI and brand_gen from drug-db DataFrame
    if ((data_dict['ddid'] == drug_db['ddid']) & (data_dict['drug_name'] == drug_db['drug_name'])).any() == True:
        drugdb_row = drug_db.loc[((data_dict['ddid'] == drug_db['ddid']) &
                                  (data_dict['drug_name'] == drug_db['drug_name']))]

        if drugdb_row.empty is False:
            logger.info(f"Saving info for DDID:DRUGNAME:: {data_dict['ddid']}:{data_dict['drug_name']}")
            data_dict['gpi'] = drugdb_row['gpi'].values[0]
            data_dict['brand_generic'] = drugdb_row['brand_generic'].values[0]
        else:
            logger.debug(f"No info available for DDID:DRUGNAME:: {data_dict['ddid']}:{data_dict['drug_name']}")
            records_errored += 1
            data_dict['gpi'] = ''
            data_dict['brand_generic'] = ''

    # lookup NDC info by ddid from ndcdrug-db DataFrame
    if ((data_dict['ddid'] == ndcdrug_db['ddid']) & (data_dict['drug_name'] == ndcdrug_db['drug_name'])).any() == True:
            ndcdrugdb_row = ndcdrug_db.loc[((data_dict['ddid'] == ndcdrug_db['ddid']) &
                                  (data_dict['drug_name'] == ndcdrug_db['drug_name']))]

            if ndcdrugdb_row.empty is False:
                logger.info(f"Saving info for DDID:DRUGNAME:: {data_dict['ddid']}:{data_dict['drug_name']}")
                data_dict['ndc'] = list(ndcdrugdb_row['ndc'])

            else:
                logger.debug(f"No info available for DDID:DRUGNAME:: {data_dict['ddid']}:{data_dict['drug_name']}")
                records_errored += 1
                data_dict['ndc'] = []

    query = N1QLQuery('SELECT META().id as id FROM `' + bucket_name + '`WHERE type="rra_drugs" and domain=' +
                      '$domainname and ddid=$did and ' +
                      'benefit_plan_name = $planname',
                      did=data_dict['ddid'],
                      domainname=data_dict['domain'],
                      planname=data_dict['benefit_plan_name'])
    # print(query)
    query.timeout = 12200

    try:
        query_result = cb.n1ql_query(query).get_single_result()
        metaid = query_result['id']
    except:
        metaid = ''

    logger.debug(f'Out Loop, {metaid}')

    if mode.upper().strip() == 'FINAL':
        if metaid != '':
            logger.info(f"Updated existing information for {data_dict['ddid']}:" +
                        f"{data_dict['drug_name']}")
            records_updated += 1
            cb.upsert(str(metaid), data_dict)
            logger.debug(f"updated the record {metaid} with the data {data_dict}")
        else:
            records_added += 1
            logger.info(f"New entry created for {data_dict['ddid']}:{data_dict['drug_name']}")
            data_dict['created_at'] = datetime.strptime(str(datetime.now()),
                                                        "%Y-%m-%d %H:%M:%S.%f").isoformat()
            cb.upsert(str(cb.counter('docid', delta=1).value), data_dict)

    else:
        logger.debug("retailrefill update program is running in draft mode")
# end for-loop

print("\n\n")
print(f"      Records added: {records_added}")
print(f"    Records updated: {records_updated}")
print(f"Records with issues: {records_errored}")
print(f"Log file: {logger.handlers[0].baseFilename}")
