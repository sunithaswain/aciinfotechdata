########################################
# !/usr/bin/env python 

# title : drugimageupdate.py
# description : Update drug images in drug image doc type
# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  python drugimageupdate.py -d GWLABS001 -t drug_images -f DRUG_IMAGES0927.xlsx -m draft
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']

import pandas as pd
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from couchbase import FMT_JSON
from utils import commandline
import os, socket
from datetime import datetime
import sys
import pprint
from utils.sendgridemail import email_log
import urllib.request as urllib2
import urllib.error
import json
import re
import couchbase.subdocument as SD

domain_name,file_type,filename,mode=commandline.main(sys.argv[1:])
cluster = Cluster(os.environ['CB_URL'])
bucket_name=os.environ['CB_INSTANCE']
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(bucket_name)

# modified by Hari on 27/12/2018
path = path
host = socket.gethostname()
currentdate = datetime.now()
currentdate = currentdate.strftime("%m%d%y%H%M%S")
log = path+'//'+file_type+'/log/'+"drugimageupdate"+currentdate+'.txt'
logfile = open(log,"w")


df=pd.read_excel(path+'//'+file_type+'//'+filename)
df.fillna("",inplace=True)
for k,g in df.groupby(['FORM','PACKAGE_DESC']):
	di={}
	di['form']=k[0]
	di['package_desc']=k[1]
	di['quantity']=[]
	for i,r in g.iterrows():
		di['dosage_image']=r['DOSAGE_IMAGE']
		quant={}
		if r['QUANTITY_IMAGE']=="":
			quant['quantity_image']=di['dosage_image']
			quant['min']=""
			quant['max']=""
		else:
			quant['quantity_image']=r['QUANTITY_IMAGE']
			quant['min']=str(r['MIN'])
			quant['max']=str(r['MAX'])
		di['quantity'].append(quant)
		

	
	di['type']='drug_images'
	di['create_date']=datetime.now().isoformat()
	di['update_date']=datetime.now().isoformat()
	query=N1QLQuery("select meta().id id,create_date from `"+bucket_name+"` where type='drug_images' and form=$form and package_desc=$pkgdesc",form=di['form'],pkgdesc=di['package_desc'])
	query.adhoc=False
	query.timeout=3600
	docid=''
	for row in cb.n1ql_query(query):
		docid=row['id']
		di['create_date']=row['create_date']
		if mode.upper().strip()=='FINAL':
			cb.upsert(docid,di)
		else:
			logfile.write(str(di))
	print(i)
	if docid=='':
		if mode.upper().strip()=='FINAL':
			cb.upsert(str(cb.counter('docid',delta=1).value),di)
		else:
			logfile.write(str(di))

# added by Hari on 27/12/2018
if mode.strip().upper() == 'DRAFT':
	logfile.write(' drug image update - Draft Mode :'+host+filename)
	print("File run on DRAFT mode")
	subject = 'drug image update - Draft Mode :'+host
	logfile.close()
	email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','SSubramani@GWLabs.com',subject,['drug image update File '+log,'drug image updatee Exception'],log,True)
else:
	logfile.close()