########################################
# !/usr/bin/env python

# title : scnewdrugsupdate.py
# description : Update drug database -(update brand generic of cp drug price)
# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  python scnewdrugsupdate.py -d GWLABS001 -t DRUG_DATABASE -f '' -m draft
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


# #######################################

from utils.sendgridemail import email_log_custombody, email_log
from utils import commandline as commandline
from drugdb.updatedrugdisplayrank import update_displayrank
from couchbase.n1ql import N1QLQuery
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Cluster
from couchbase import FMT_JSON
import pandas as pd
import couchbase.subdocument as SD
import boto3
from datetime import datetime
import sys
import re
import os
import logging
if __name__ == '__main__':
    import os
    import sys

    rootdir = os.path.dirname(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))))
    sys.path.append(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']
log_path = path + '/log'


now = datetime.now().strftime("%d-%m-%Y-%H:%M:%S")

# add new logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

fh = logging.FileHandler(f'{path}/DRUG_DATABASE/log/sc_log-{now}.log')
fh.setLevel(logging.DEBUG)

formatter = logging.Formatter(
    '%(name)s - %(asctime)s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)

logger.addHandler(fh)

log_file = (f"{path}/DRUG_DATABASE/log/sc_log-{now}.log")
cluster = Cluster(os.environ['CB_URL'])
bucket_name = os.environ['CB_INSTANCE']
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'],
                                      os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(bucket_name)


def customizedchanges():
    cb.n1ql_query(
        N1QLQuery("update `" + os.environ['CB_INSTANCE'] + "` set dosage='SOLUTION FOR EARS' where type='drug' "
                                                           "and gpi='87100060002010'")).execute()
    cb.n1ql_query(
        N1QLQuery("update `" + os.environ['CB_INSTANCE'] + "` set dosage='SOLUTION FOR EYES' where type='drug' "
                                                           "and gpi='86101047002020'")).execute()
    cquery = N1QLQuery(
        "update `" + os.environ['CB_INSTANCE'] +
        "` set generic_rank='999' where type = 'drug' and generic_"
        "rank in ['nan','00000000000nan']")
    cquery.timeout = 3600
    cb.n1ql_query(cquery).execute()
    cquery = N1QLQuery(
        "update `" + os.environ['CB_INSTANCE'] +
        "` set generic_rank='1' where type = 'drug' and generic_"
        "rank in ['1.0','000000000001.0']")
    cquery.timeout = 3600
    cb.n1ql_query(cquery).execute()
    cquery = N1QLQuery(
        "update `" + os.environ['CB_INSTANCE'] +
        "` set i.display_rank='999' for i in ARRAY_FLATTEN(quantity,1)"
        " WHEN i.display_rank='nan' END where type='drug'")
    cquery.timeout = 3600
    cb.n1ql_query(cquery).execute()


def update_status_flag(ms):

    pricing_report = pd.DataFrame()
    formulary_report = pd.DataFrame()

    query = N1QLQuery('update `' + os.environ['CB_INSTANCE'] +
                      '` set status="active",price_status="price exists" where type="drug"')
    query.timeout = 3600
    cb.n1ql_query(query).execute()

    domain_list = []
    query = N1QLQuery('select distinct domain from `' +
                      os.environ['CB_INSTANCE'] + '` where type="domain"')
    for result in cb.n1ql_query(query):
        domain_list.append(result['domain'])

    iterator = 0
    drugs = ms.loc[:, ['drug_name', 'gpi', 'brand_generic']]
    drugs.drop_duplicates(inplace=True)
    query = N1QLQuery("select meta().id,drug_name,gpi,strengths, dosage, brand_generic, otc_indicator,multi_source from `" +
                      os.environ['CB_INSTANCE'] + "` where type='drug'")
    query.timeout = 10000
    for result in cb.n1ql_query(query):
        iterator += 1
        if iterator % 10000 == 0:
            print(iterator)
        if not ((drugs['drug_name'] == result['drug_name']) & (drugs['gpi'] == result['gpi']) & (drugs['brand_generic'] == result['brand_generic'])).any():
            cb.mutate_in(result['id'], SD.upsert('status', 'inactive'))
        brandgeneric = changebg(result['brand_generic'])
        pricefound = False
        drugpricequery = N1QLQuery("select drug_descriptor_identifier,cp_price from `" +
                                   os.environ['CB_INSTANCE'] + "` where type='cp_drug_price' and gpi=$gpi and drug_name=$dn and brandorgeneric=$bg limit 1", gpi=result['gpi'], dn=result['drug_name'], bg=brandgeneric)
        for priceresult in cb.n1ql_query(drugpricequery):
            if priceresult.get('cp_price', []):
                try:
                    unitprice = float(priceresult['cp_price'][0]['unitprice'])
                    pricefound = True
                except:
                    pass
        if not pricefound:
            cb.mutate_in(result['id'], SD.upsert(
                'price_status', 'price does not exist'))
            if result['otc_indicator'] != 'R':
                continue
            pricing_report = generate_report('pricing', pricing_report, result)
        formularyfound = {domain: False for domain in domain_list}
        for domain, value in formularyfound.items():
            formularyquery = N1QLQuery("select ddid,company_formulary from `" +
                                       os.environ['CB_INSTANCE'] + "` where type=$type and gpi=$gpi and drug_name=$dn and brand_generic=$bg limit 1", gpi=result['gpi'], dn=result['drug_name'], bg=result['brand_generic'], type='formulary_'+domain)
            for formularyresult in cb.n1ql_query(formularyquery):
                if formularyresult.get('company_formulary', []):
                    formularyfound.update({domain: True})
        if False in formularyfound.values():
            formulary_report = generate_report(
                'formulary', formulary_report, result, formularyfound)

    sender = 'noreply@fliptrx.com'
    receiver = ['fliptintegration@fliptrx.com', 'dwagle@fliptrx.com']
    if os.environ['INSTANCE_TYPE'] == 'PROD':
        receiver = ['pricing@fliptrx.com', 'clinical@fliptrx.com']
    pricing_report_path = path + '/DRUG_DATABASE/log/Price_Does_Not_Exist.csv'
    formulary_report_path = path + '/DRUG_DATABASE/log/Missing_in_formulary.csv'

    if len(pricing_report) > 0:
        subject = 'Missing Pricing Alert'
        body = 'Team,<br><br> The Medispan Drug Data has been refreshed. Please find attachment listing the drugs without pricing details. <br><br>Best regards,<br><strong>FLIPT Integration Team</strong'
        pricing_report.to_csv(pricing_report_path, index=False)
        email_log_custombody(sender, receiver[0], receiver[1], subject,
                             body, file_path=pricing_report_path, attached=True)

    if len(formulary_report) > 0:
        subject = 'Missing Formulary Alert'
        body = 'Team,<br><br> The Medispan Drug Data has been refreshed. Please find attachment listing the drugs without formulary details. <br><br>Best regards,<br><strong>FLIPT Integration Team</strong'
        formulary_report.to_csv(formulary_report_path, index=False)
        email_log_custombody(
            sender, receiver[0], receiver[1], subject, body, file_path=formulary_report_path, attached=True)


def generate_report(report_type, report, drug_attributes, domains={}):

    drug_values = dict(drug_attributes)
    drug_values.pop('id', '')

    if report_type == 'pricing':
        report = report.append(drug_values, ignore_index=True)
        return report

    elif report_type == 'formulary':
        for domain, value in domains.items():
            drug_value_by_domain = dict(drug_values)
            if value is False:
                drug_value_by_domain.update({'domain': domain})
                report = report.append(drug_value_by_domain, ignore_index=True)
        return report


def changebg(txt):
    return txt.strip().replace('B', 'Brand').replace('T', 'Brand').replace('G', 'Generic')


def findimgname(form, pkgdesc, compareq):
    try:
        imgquery = N1QLQuery(
            "Select dosage_image,quantity from `" + bucket_name +
            "` where type='drug_images' and form=$form and package"
            "_desc=$pdesc limit 1",
            form=form, pdesc=pkgdesc)
        imgquery.adhoc = False
        imgquery.timeout = 3600
        dimg, qimg = '', ''
        for r in cb.n1ql_query(imgquery):
            dimg = r['dosage_image']
            qimg = r['dosage_image']
            quantitylist = r['quantity']
            for i in quantitylist:
                if i['min'] != "" and i['max'] != "":
                    if float(i['min']) <= float(compareq) and float(i['max']) >= float(compareq):
                        qimg = i['quantity_image']
                        break
                elif i['min'] == "" and i['max'] != "":
                    if float(i['max']) >= float(compareq):
                        qimg = i['quantity_image']
                elif i['max'] == "" and i['min'] != "":
                    if float(i['min']) <= float(compareq):
                        qimg = i['quantity_image']
                        break
        return dimg, qimg
    except Exception as e:
        logger.error("Exception occurred for ", str(form),
                     str(pkgdesc), str(compareq), exc_info=True)
        return "", ""


def update(pfile_name, file_type, domain, mode):

    logger.info(
        f"Inside updated function received file_type, file_name, mode as {mode}")
    specialty = pd.read_excel(
        path + '//' + file_type + '//AmberList20180524.xlsx')
    logger.info("Starting reading the speciality file")

    logger.info("Starting reading the drug update file")
    ms = pd.read_csv(pfile_name)

    changedcols = {}
    for c in list(ms):
        changedcols[c] = c.strip().lower().replace(' ', '_')
    ms.rename(columns=changedcols, inplace=True)

    ms.drop_duplicates(inplace=True)
    ms['package_qty'] = ms['package_qty'].apply(
        lambda x: str(x).replace('\r', ''))
    ms['gpi'] = ms['gpi'].apply(lambda x: str(x).zfill(14))
    ms['gppc'] = ms['gppc'].apply(lambda x: str(x).zfill(8))
    ms['generic_rank'] = ms['generic_rank'].apply(lambda x: str(x))
    ms['ddid'] = ms['ddid'].apply(lambda x: str(x))
    ms['strengthnum'] = ""
    specialty['GPICode'] = specialty['GPICode'].apply(
        lambda x: str(x).replace('.0', '').zfill(14))
    logger.info(
        "Finished renaming columns, removing duplicates, updating gpi, gppc to 14, 8 chars")
    logger.info(
        "Entering the for loop of ms.iterrows to verify package size and strength")

    for i, r in ms.iterrows():
        if r['custom_qty'] != 'package_size':
            continue
        if r['strengths'] != ' ':
            try:
                strength = float(re.findall(
                    r"[-+]?\d*\.\d+|\d+", r['strengths'])[0])
                # if '/' not in r['strengths'] and '-' not in r['strengths'] and 'X' not in r['strengths']
                if 'GM' in r['strengths']:
                    strength = strength * 1000
                elif 'MCG' in r['strengths']:
                    strength = strength / 1000
                ms.loc[i, 'strengthnum'] = strength
            except Exception as e:
                ms.loc[i, 'strengthnum'] = r['strengths']
        else:
            ms.loc[i, 'strengthnum'] = 0.0
    logger.info("Outside of the for loop ms.iterrows")
    ms['dosage_rank'] = "0"
    ms['dosage_image'] = ""
    ms['quantity_image'] = ""
    logger.info("Entering the second for loop group by")
    for k, g in ms.groupby(['drug_name', 'dosage']):
        dosagerank = 0
        customqty = "package_quantity"
        if 'package_quantity' in list(g['custom_qty']):
            g.sort_values(by=['strengths', 'package_size'],
                          ascending=[True, True], inplace=True)
        else:
            try:
                g.sort_values(by=['strengthnum'], ascending=[
                              True], inplace=True)
            except Exception as e:
                logger.error(f"Exception occurred for {g}", exc_info=True)
            customqty = "package_size"
        ps, strnth = '', ''
        for i, r in g.iterrows():
            if customqty == 'package_size':
                if strnth != r['strengthnum']:
                    dosagerank = dosagerank + 1
            else:
                if ps != r['package_size'] or strnth != r['strengths']:
                    dosagerank = dosagerank + 1
                    ps = r['package_size']
                    strnth = r['strengths']
            ms.loc[i, 'dosage_rank'] = str(dosagerank)
    logger.info("Out of second for loop")
    ms.drop(['strengthnum'], axis=1, inplace=True)

    outercols = ['ddid', 'gpi', 'brand_generic', 'drug_name', 'unit_dose', 'strengths', 'dosage', 'generic_rank',
                 'otc_indicator', 'maintenance_drug_flag', 'drug_class', 'drug_group', 'drug_subclass',
                 'drug_full_name', 'multi_source']
    newcols = ['lm_name', 'lm_form', 'lm_strength', 'drugtype', 'ddn_name', 'ddn_form', 'ddn_strength', 'lm_updated_by',
               'ddn_updated_by', 'pda', 'ddn_update_date', 'lm_update_date']
    for c in newcols:
        ms[c] = 'nan'
    ite = -1
    listcols = list(ms)

    nestedcols = ["dosage_strength", "form", "package_desc", "package_qty", "package_quantity", "package_size",
                  "pkg_desc_cd", "pkg_uom", "display_rank", "gppc", "custom_qty", "quantity_type", "dosage_image",
                  "quantity_image", "dosage_rank"]
    for k, g in ms.groupby(['ddid', 'gpi']):

        g.reset_index(drop=True, inplace=True)
        drugdbquery = N1QLQuery('Select meta().id id from `'+bucket_name+'` where type="drug" and gpi=$gpi and drug_name=$drugname and brand_generic=$bg limit 1',
                                gpi=g.loc[0, 'gpi'], drugname=g.loc[0, 'drug_name'], bg=g.loc[0, 'brand_generic'])
        docid = ''
        drugdbquery.timeout = 100
        for result in cb.n1ql_query(drugdbquery):
            docid = result['id']
        if docid:
            logger.info("-----Drug in Drug Database----\n")
            logger.info(f"Drug Name: {(g.loc[0, 'drug_name'])} \n")
            logger.info(f"GPI: {(g.loc[0, 'gpi'])} \n")
            logger.info(f"Brand_Generic: {(g.loc[0, 'brand_generic'])} \n\n")
            bg = 'Brand'
            if str(g.loc[0, 'brand_generic']) == 'G':
                bg = 'Generic'

            for col in outercols:
                value = str(g.loc[0, col])
                if mode.upper().strip() == 'FINAL':
                    try:
                        cb.mutate_in(docid, SD.upsert(col, value))
                    except Exception as e:
                        logger.error(
                            f"Exception occurred {col}, {value}", exc_info=True)
                        continue
            quantitylist = []
            for i, r in g.iterrows():
                quant = {}
                for c in nestedcols:
                    quant[c] = str(r[c]).strip().encode(
                        'utf-8').decode('utf-8')
                compareq = r['package_quantity']
                if r['custom_qty'] == 'package_size':
                    compareq = r['package_size']
                quant['dosage_image'], quant['quantity_image'] = findimgname(r['dosage'], quant['package_desc'],
                                                                             compareq)
                quantitylist.append(quant)
            # print(quantitylist)
            if mode.upper().strip() == 'FINAL':
                logger.info(f"Running in final mode, udating for : {quantitylist}, {g.loc[0, 'drug_name']},"
                            f"{(g.loc[0, 'gpi'])}, {bg} ")
                cb.mutate_in(docid, SD.upsert('quantity', quantitylist))
                cb.mutate_in(docid, SD.upsert('update_date', str(
                    datetime.now().strftime("%Y-%m-%d"))))
            continue
        logger.info(f"Iteration counter {ite}")
        record = dict()
        for c in listcols:
            if c in nestedcols:
                continue
            record[c] = str(g.loc[0, c]).strip().encode(
                'utf-8').decode('utf-8')

        record['quantity'] = []

        record['lm_ndc'] = []
        record['popularity'] = '0'
        record['update_date'] = str(datetime.now().strftime("%Y-%m-%d"))
        record['load_date'] = str(datetime.now().strftime("%Y-%m-%d"))
        for i, r in g.iterrows():
            quant = {}
            for c in nestedcols:
                quant[c] = str(r[c]).strip().encode('utf-8').decode('utf-8')
            compareq = r['package_quantity']
            if r['custom_qty'] == 'package_size':
                compareq = r['package_size']
            quant['dosage_image'], quant['quantity_image'] = findimgname(
                r['dosage'], quant['package_desc'], compareq)
            record['quantity'].append(quant)
        id1 = []
        # print(record['quantity'])
        record['rxcui'] = ''
        record['specialty_flag'] = 'N'
        if ((g.loc[0, 'gpi'] == specialty['GPICode']) & (g.loc[0, 'drug_name'] == specialty['ProductNameAbr'])).any() \
                == True:
            record['specialty_flag'] = 'Y'

        record['type'] = 'drug'
        record['equivalent'] = []
        record['lm_update_date'] = str(datetime.now().strftime("%Y-%m-%d"))
        record['ddn_update_date'] = str(datetime.now().strftime("%Y-%m-%d"))
        logger.info('-----New Drug in Drug Database----\n')
        logger.info(f"Drug Name: {str(g.loc[0, 'drug_name'])} \n")
        logger.info(f"GPI: {str(g.loc[0, 'gpi'])} \n")
        logger.info(f"Brand_Generic: {str(g.loc[0, 'brand_generic'])} \n\n")
        # print(record)
        if mode.upper().strip() == 'FINAL':
            cb.upsert(str(cb.counter('docid', delta=1).value),
                      record, format=FMT_JSON)
        ite = ite + 1

    customizedchanges()
    update_status_flag(ms)

    sender = 'noreply@fliptrx.com'
    receiver = ['FliptIntegration@fliptrx.com']
    subject = 'DrugDatabase (ScriptClaim) Updated - Completed'
    body = ["Processing of DrugDatabase (ScriptClaim) file " + pfile_name + "(cp_drug_price.csv), "
                                                                            "DrugDatabase (ScriptClaim) Exception", ""]
    logger.info('\n---DrugDatabase (ScriptClaim) Update Done----\n')
    logger.info(str(datetime.now()) + '\n')

    email_log(sender, receiver[0], None,
              subject, body, file_path=None, attached=False)

    if mode.strip().upper() == 'FINAL':
        logger.info("Moving the file to archive folder")
        move_file_to_archive(pfile_name)
        logger.info("Updating drug display rank")
        try:
            update_displayrank()
        except Exception as e:
            print(e, 'drug display rank error')
            logger.info('drug display rank update errored out: ')


def parse_args():
    return commandline.main(sys.argv[1:])


def read_file_from_S3(dest_dir, file_name=None):
    # AWS File location

    _BUCKET_NAME = os.environ['AMAZON_SFTP_BUCKET']
    s3_resource = boto3.resource('s3')
    s3_bucket = s3_resource.Bucket(_BUCKET_NAME)
    modified_date = None
    source_file_name = ''
    for obj in s3_bucket.objects.filter(Prefix="dataload_{}/uploads/{}".
                                        format(os.environ['INSTANCE_TYPE'].lower(), file_name or 'DRUG_DATABASE_')):
        if os.path.basename(obj.key).startswith('DRUG_DATABASE_') and ((modified_date and modified_date < obj.last_modified) or not modified_date):
            source_file_name = os.path.basename(obj.key)
            modified_date = obj.last_modified

    if not source_file_name:
        logger.info("No files found with pattern")
        sys.exit(1)

    source_path = 'dataload_{}/uploads/{}'.format(os.environ['INSTANCE_TYPE'].lower(),
                                                  source_file_name)
    boto3.client(
        's3',
        aws_access_key_id=os.environ['AWS_ACCESS_KEY_ID'],
        aws_secret_access_key=os.environ['AWS_SECRET_ACCESS_KEY']
    )
    dest_path = os.path.join(dest_dir, source_file_name)
    s3_bucket.download_file(source_path, dest_path)
    return dest_path


def move_file_to_archive(source_file_name):
    source_file_name = os.path.basename(source_file_name)
    bucket_name = os.environ['AMAZON_SFTP_BUCKET']
    upload_path = 'dataload_{}/uploads'.format(
        os.environ['INSTANCE_TYPE'].lower())
    source_path = '{}/{}'.format(upload_path, source_file_name)
    dest_path = '{}/Archive/{}'.format(upload_path, source_file_name)

    boto3.client(
        's3',
        aws_access_key_id=os.environ['AWS_ACCESS_KEY_ID'],
        aws_secret_access_key=os.environ['AWS_SECRET_ACCESS_KEY']
    )
    s3_resource = boto3.resource('s3')
    copy_source = {'Bucket': bucket_name,
                   'Key': source_path}
    s3_resource.Bucket(bucket_name).copy(copy_source, dest_path)
    s3_bucket = s3_resource.Bucket(bucket_name)
    s3_bucket.Object(source_path).delete()


def main():

    logger.info("Started the process working as intended")
    domain, file_type, file_name, mode = parse_args()
    # for custom filename -f <file-name> else -f ''
    dest_dir = os.path.join(path, file_type)
    # read_file_from_S3(pfile_name, full_filepath)
    file_name = read_file_from_S3(dest_dir, file_name=file_name)

    update(file_name, file_type, domain, mode)


main()
