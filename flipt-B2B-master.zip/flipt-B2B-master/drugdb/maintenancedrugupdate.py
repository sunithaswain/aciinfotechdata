########################################
# !/usr/bin/env python  
# title         : maintenancedrugupdate.py
# description   : Maintenance Drug Updates -Update
# author        : Disha
# date created  : 20181113
# date last modified    :  
# version       : 0.1
# maintainer    : Hari
# email         : -
# status        : Production
# Python Version: 3.5.2
# usage			: python maintenancedrugupdate.py -m NOTIFY
# 				  python maintenancedrugupdate.py -m UPDATE
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  1.1				Hari		14/03/2019	Code modified based on git folder structure
# #######################################

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']

import pandas as pd
import os
import sqlalchemy
from sqlalchemy import create_engine
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
import couchbase.subdocument as SD
import dateutil.parser
import os
import datetime
from utils.truevault import User_Class
from notification.pushnotif import send_push_message
from utils import commandline
import sys
from utils.FliptConcurrent import concurrent

domain,file_type,file_name,mode = commandline.main(sys.argv[1:])
req=concurrent(sys.argv[0],sys.argv[1:])
cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
# path = os.environ['CB_DATA']

def findmaintenancedrugs():
	mlog=pd.DataFrame()
	domainq=N1QLQuery("Select distinct (100-tonumber(maintenance_drug_refill_pct))/100 maintenance_drug_refill_pct from `"+os.environ['CB_INSTANCE']+"` where type='domain'")
	refillpct=0
	ite=0
	for drec in cb.n1ql_query(domainq):
		refillpct=drec['maintenance_drug_refill_pct']
	rxhistoryq=N1QLQuery("Select npi,flipt_person_id,drug_name,gpi,meta().id id from `"+os.environ['CB_INSTANCE']+"` where type='rx_history' and clock_local()>start_date and clock_local()<=DATE_ADD_STR(estimated_stop_date,ceil(tonumber(replace(daysofsupply,' ',''))*$gpct),'day')",gpct=refillpct)
	rxhistoryq.timeout=3600
	for rxhist in cb.n1ql_query(rxhistoryq):
		maintenance_drug_flag='N'
		try:
			if rxhist['flipt_person_id']=='': continue
			print(ite)
			ite=ite+1
			
			print(rxhist['id'])
			df=pd.DataFrame()
			
			
			ndcq=N1QLQuery("Select ndc from `"+os.environ['CB_INSTANCE']+"` where type='ndc_drugs' and gpi=$gpi and drug_name=$dn",gpi=rxhist['gpi'],dn=rxhist['drug_name'])
			ndclist=[]
			for ndcs in cb.n1ql_query(ndcq):
				ndclist.append(str(int(ndcs['ndc'])))
			if len(ndclist)>0:
				
				rxclaimhistq=N1QLQuery("Select dispensed_date start_date,DATE_ADD_STR(dispensed_date,tonumber(days_of_supply),'day') stop_date,tonumber(days_of_supply) days_of_supply from `"+os.environ['CB_INSTANCE']+"` where type='rx_claim_history' and rx_flipt_person_id=$rxid and ndc_code in $nlist",rxid=rxhist['flipt_person_id'],nlist=ndclist)
				for rxclaim in cb.n1ql_query(rxclaimhistq):
					
					df=df.append({'startdate':pd.to_datetime(str(dateutil.parser.parse(rxclaim['start_date']))),'stopdate':pd.to_datetime(str(dateutil.parser.parse(rxclaim['stop_date']))),'days_supply':rxclaim['days_of_supply']},ignore_index=True)
			presclist=[]
			
			prescq=N1QLQuery("Select prescription_id from `"+os.environ['CB_INSTANCE']+"` where type='prescription' and gpi=$gpi and drug_name=$dn and rx_flipt_person_id=$rxid and rx_status='Filled'",gpi=rxhist['gpi'],dn=rxhist['drug_name'],rxid=rxhist['flipt_person_id'])
			for presc in cb.n1ql_query(prescq):
				presclist.append(presc['prescription_id'])
			
			scdailyclaimq=N1QLQuery('Select tonumber(trim(days_supply)) days_supply, date_of_service start_date from `'+os.environ['CB_INSTANCE']+'` where type="scdailyclaim" and replace(replace(meta().id,"prescription::",""),"scdailyclaim::","") in (select raw max(replace(replace(meta(b).id,"prescription::",""),"scdailyclaim::","")) from `'+os.environ['CB_INSTANCE']+'` b where trim(b.transaction_id) in $prescli and b.claim_type="P" and b.type="scdailyclaim" group by trim(b.transaction_id))',prescli=presclist)
			for scclaim in cb.n1ql_query(scdailyclaimq):
				df=df.append({'startdate':pd.to_datetime(str(dateutil.parser.parse(scclaim['start_date']))),'stopdate':pd.to_datetime(str(dateutil.parser.parse(scclaim['start_date'])))+datetime.timedelta(scclaim['days_supply']),'days_supply':scclaim['days_supply']},ignore_index=True)
			
			if len(df)==0 or datetime.datetime.today()>max(list(df['stopdate']))+datetime.timedelta(max(list(df['days_supply']))*refillpct): continue
			df.drop_duplicates(inplace=True)
			df.sort_values(by=['stopdate'],ascending=[False],inplace=True)
			df.reset_index(drop=True,inplace=True)
			pstdate=''
			brkdays=0
			mlog=mlog.append({'flipt_person_id':rxhist['flipt_person_id'],'drug_name':rxhist['drug_name'],'gpi':rxhist['gpi'],'filled date':'','estimated stop date':'','maintenance drug flag':'','days of supply':'','cycle count':'','break days':''},ignore_index=True)
			for i,r in df.iterrows():
				try:
					brkdays=(pstdate-r['stopdate']).days
				except Exception as e:
					brkdays=0
				mlog=mlog.append({'flipt_person_id':'','drug_name':'','gpi':'','filled date':r['startdate'],'estimated stop date':r['stopdate'],'maintenance drug flag':'','days of supply':r['days_supply'],'cycle count':'','break days':brkdays},ignore_index=True)
				pstdate=r['startdate']
				
			#print(df)
			if len(df)<2:
				print('N')
				mlog=mlog.append({'flipt_person_id':'','drug_name':'','gpi':'','filled date':'','estimated stop date':'','maintenance drug flag':'N','days of supply':'','cycle count':len(df),'break days':''},ignore_index=True)
				
				continue
			
			cycles=0
			prev_startdate=None
			for i,r in df.iterrows():
				if cycles!=0:
					if r['stopdate']+datetime.timedelta(int(r['days_supply']*refillpct))<prev_startdate:
						break
				prev_startdate=r['startdate']
				cycles=cycles+1
			if cycles>1:
				#print('Y')
				mlog=mlog.append({'flipt_person_id':'','drug_name':'','gpi':'','filled date':'','estimated stop date':'','maintenance drug flag':'Y','days of supply':'','cycle count':cycles,'break days':''},ignore_index=True)
				maintenance_drug_flag='Y'
			else:
				#print('N')
				mlog=mlog.append({'flipt_person_id':'','drug_name':'','gpi':'','filled date':'','estimated stop date':'','maintenance drug flag':'N','days of supply':'','cycle count':cycles,'break days':''},ignore_index=True)
			#print(df)
			if maintenance_drug_flag=="Y":
				notifrec={}
				notifday=int((df.loc[0,'stopdate']-df.loc[0,'startdate']).days*refillpct)
				notifrec['rxhistory_id']=str(rxhist['id'])
				notifrec['type']="notification_log"
				notifrec['drug_name']=rxhist['drug_name']
				notifrec['gpi']=rxhist['gpi']
				notifrec['flipt_person_id']=rxhist['flipt_person_id']
				notifrec['notification_type']='refill_reminder'
				notifrec['create_date']=datetime.datetime.today().isoformat()
				notifrec['update_date']=datetime.datetime.today().isoformat()
				print(df.loc[0,'stopdate']+datetime.timedelta(notifday))
				if df.loc[0,'stopdate']-datetime.timedelta(notifday)<datetime.datetime.today()+datetime.timedelta(8) and df.loc[0,'stopdate']-datetime.timedelta(notifday)>datetime.datetime.today():
					notifrec['notification_date']=(df.loc[0,'stopdate']-datetime.timedelta(notifday)).isoformat()
				
				#if df.loc[0,'stopdate']-datetime.timedelta(notifday)<datetime.datetime.today() and df.loc[0,'stopdate']+datetime.timedelta(notifday)>datetime.datetime.today():
				#notifrec['notification_date']=(datetime.datetime.today()).isoformat()
				if 'notification_date' not in notifrec: continue
				notifq=N1QLQuery('Select meta().id id from `'+os.environ['CB_INSTANCE']+'` where type="notification_log" and notification_type="refill_reminder" and drug_name=$dn and gpi=$gpi and DATE_FORMAT_STR(notification_date,"1111-11-11")=DATE_FORMAT_STR($nd,"1111-11-11") and flipt_person_id=$fid and result is missing',dn=notifrec['drug_name'],gpi=notifrec['gpi'],fid=notifrec['flipt_person_id'],nd=notifrec['notification_date'])
				notificationfound=False
				for nrec in cb.n1ql_query(notifq):
					notificationfound=True
				if not notificationfound:
					print(notifrec)
					cb.upsert(str(cb.counter('docid',delta=1).value),notifrec)
					cb.mutate_in(str(rxhist['id']),SD.upsert('ready_to_refill','Y'))
		except Exception as e:
			print(e)
			print(rxhist)
			continue
			
	#mlog.to_csv('mflag.csv',index=False,columns = ['drug_name','gpi','flipt_person_id','filled date','days of supply','estimated stop date','break days','cycle count','maintenance drug flag'])

def sendnotification():
	rxids=N1QLQuery("Select distinct flipt_person_id from `"+os.environ['CB_INSTANCE']+"` where type='notification_log' and notification_type='refill_reminder' and DATE_FORMAT_STR(notification_date,'1111-11-11')=DATE_FORMAT_STR(clock_local(),'1111-11-11') and notification_send_date is missing")
	#fidlist=[]
	for rid in cb.n1ql_query(rxids):
		
		notifq=N1QLQuery("Select *,meta().id id from `"+os.environ['CB_INSTANCE']+"` where type='notification_log' and notification_type='refill_reminder' and DATE_FORMAT_STR(notification_date,'1111-11-11')=DATE_FORMAT_STR(clock_local(),'1111-11-11') and notification_send_date is missing and flipt_person_id=$rxid and gpi||drug_name||flipt_person_id not in (Select raw b.gpi||b.drug_name||b.rx_flipt_person_id from `"+os.environ['CB_INSTANCE']+"` b where b.type='prescription' and b.rx_status='Routed' and b.rx_flipt_person_id=$rxid)",rxid=rid['flipt_person_id'])
		#notifq=N1QLQuery("Select *,meta().id id from `"+os.environ['CB_INSTANCE']+"` where type='notification_log' and notification_type='refill_reminder' and DATE_FORMAT_STR(notification_date,'1111-11-11')=DATE_FORMAT_STR(clock_local(),'1111-11-11') and notification_send_date is missing ")
		notifq.timeout=3600
		rxhistids=[]
		drugnames=[]
		metaids=[]
		nrec={}
		for record in cb.n1ql_query(notifq):
			#print(record)
			nrec.update(record[os.environ['CB_INSTANCE']])
			rxhistids.append(nrec['rxhistory_id'])
			drugnames.append(nrec['drug_name'])
			metaids.append(record['id'])
			#print(record)
		messagecenter={}
		if 'rxhistory_id' not in nrec: continue
		
		message={'title':'Refill Reminder!','body':'You may have refill for '+', '.join(x for x in drugnames)+". Click here to refill."}
		extra={'rx_history_meta_id':nrec['rxhistory_id'],'message':'You may have refill for '+', '.join(x for x in drugnames)+". Click here to refill."}
		messagecenter['message']=message['title']
		messagecenter['sub_message']=message['body']
		messagecenter['flipt_person_id']=nrec['flipt_person_id']
		messagecenter['message_id']=str(cb.counter('docid',delta=1).value)
		messagecenter['type']="message_center"
		messagecenter['status']="New"
		messagecenter['created_by']="System"
		messagecenter['create_date']=datetime.datetime.now().isoformat()
		action={"type": "refill", "title": message['title'], "sub_title": message['body'], "notification_id": messagecenter['message_id'], "rx_history_meta_id": nrec['rxhistory_id']}
		if len(rxhistids)>1:
			action['rx_history_meta_list']=[]
			action['rx_history_meta_list'].extend(rxhistids)
			action.pop('rx_history_meta_id')
			extra['rx_history_meta_list']=[]
			extra['rx_history_meta_list'].extend(rxhistids)
			extra.pop('rx_history_meta_id')
			
		messagecenter['action']=action
		messagecenter['message_method']="in-app"
		for mid in metaids:
			cb.mutate_in(mid,SD.upsert('result','Failure'))
		obj=User_Class(None,None)
		search_option={'full_document':True,'filter':{'flipt_person_id':{'type':'eq','value':nrec['flipt_person_id'],'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
		att,userid = obj.search_user(search_option)
		tokenpresent=False
		print(nrec['flipt_person_id'])
		#if nrec['flipt_person_id']=='28129': print(att)
		if att!=None:
			if 'domain_name' in att: messagecenter['domain']=att['domain_name']
			cb.upsert(messagecenter['message_id'],messagecenter)				
			if 'active' in att:
				if not att['active']: continue
			if 'devices' in att:
				#print(att['devices'])
				for i in att['devices']:
					if 'token' in i:
						print(i['token'])	
						if os.environ['INSTANCE_TYPE']=='PROD':
							response=send_push_message(i['token'],message['body'],extra,message['title'])
							if response==True:
								for mid in metaids:
									cb.mutate_in(mid,SD.upsert('notification_send_date',datetime.datetime.now().isoformat()))
									cb.mutate_in(mid,SD.upsert('result','Success'))
		if att==None:
			flipthierarchyq=N1QLQuery("select emp_flipt_person_id from `"+os.environ['CB_INSTANCE']+"` where type='flipt_person_hierarchy' and dep_flipt_person_id=$fid",fid=nrec['flipt_person_id'])
			flipthierarchyq.timeout=100
			empfliptid=''
			for fidrec in cb.n1ql_query(flipthierarchyq):
				empfliptid=fidrec['emp_flipt_person_id']
			search_option={'full_document':True,'filter':{'flipt_person_id':{'type':'eq','value':empfliptid,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
			att,userid = obj.search_user(search_option)
			tokenpresent=False
			if att!=None:
				if 'domain_name' in att: messagecenter['domain']=att['domain_name']
				cb.upsert(messagecenter['message_id'],messagecenter)				
				if 'active' in att:
					if not att['active']: continue
				if 'devices' in att:
					for i in att['devices']:
						if 'token' in i:
							print(i['token'])
							if os.environ['INSTANCE_TYPE']=='PROD':
								response=send_push_message(i['token'],message['body'],extra,message['title'])
								if response==True:
									for mid in metaids:
										cb.mutate_in(mid,SD.upsert('notification_send_date',datetime.datetime.now().isoformat()))
										cb.mutate_in(mid,SD.upsert('result','Success'))
		

if mode.upper().strip()=='UPDATE' and datetime.datetime.now().weekday()==2:				
	findmaintenancedrugs()
if mode.upper().strip()=='NOTIFY':				
	sendnotification()
req.close()       