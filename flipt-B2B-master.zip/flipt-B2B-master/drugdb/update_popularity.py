import logging
import os
from collections import Counter
import json
from datetime import datetime

from couchbase.n1ql import N1QLQuery
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator

path = os.environ['CB_DATA']
now = datetime.now().strftime("%d-%m-%Y-%H:%M:%S")

# add new logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

fh = logging.FileHandler(f'{path}/DRUG_DATABASE/log/popularity_log-{now}.log')
fh.setLevel(logging.DEBUG)

formatter = logging.Formatter('%(name)s - %(asctime)s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)

logger.addHandler(fh)

cluster = Cluster(os.environ['CB_URL'])
bucket_name = os.environ['CB_INSTANCE']
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'],
                                      os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(bucket_name)

def drug_popularity() -> dict:
    """
    Updates popularity of each drug by percentage points (0 to 1, 1 being the highest). 0 if the drug has never been
    filled.
    :return: sorted_drug_popularity --> dict
    """
    # select counts of each filled drug in Prescription table
    query = N1QLQuery(f'SELECT drug, gpi FROM `{bucket_name}` WHERE type = "prescription" and rx_status="Filled"')
    query_res = cb.n1ql_query(query)
    total_filled_drugs = int(query_res.metrics['resultCount']) + int(query_res.metrics['resultCount'])
    drug_list = map(lambda result: result['drug'], query_res)
    drug_pop = Counter(drug_list)
    sorted_drug_popularity = dict(sorted(drug_pop.items(), key=lambda x: x[1], reverse=True))

    for key, value in sorted_drug_popularity.items():
        rx_hisory_query = f'SELECT count(1) FROM `{bucket_name}` WHERE type = "rx_history" and drug_name="{key}"'
        for i in cb.n1ql_query(rx_hisory_query):
            sorted_drug_popularity[key] = (int(value) + int(i['$1'])) / int(total_filled_drugs)  # drug popularity by percentage
    print(json.dumps(sorted_drug_popularity, indent=2))
    print(f"Print the total count {total_filled_drugs}")
    return sorted_drug_popularity


def update_cb_popularity() -> None:
    """
    Update drug popularity.
    :return: None
    """
    logging.info("Inside the update popularity functiuon")
    # print(drug_popularity())
    exclude_list = [str(x) for x in drug_popularity().keys()]
    logging.info(f"exluide list, length of list {len(exclude_list)}", exclude_list)
    for key, value in drug_popularity().items():

        drug_query = N1QLQuery(
            'UPDATE `' + bucket_name + '` SET popularity = $value WHERE type = "drug" and drug_name = $drugname',
            value=value, drugname=str(key))
        cb.n1ql_query(drug_query).execute()
        print('Mutation Count: ', cb.n1ql_query(drug_query).metrics['mutationCount'], f' for {key}')

    drug_exclusion_query = N1QLQuery(
        f'UPDATE `{bucket_name}` SET popularity = 0 WHERE type = "drug" and drug_name not in {exclude_list}')
    cb.n1ql_query(drug_exclusion_query).execute()
    logging.info(f'Mutation Count: {cb.n1ql_query(drug_exclusion_query).metrics["mutationCount"]}')

    return

