import boto3
import unittest
import os
from datetime import datetime

class S3_sendTo_archive_test(unittest.TestCase):
    def setUp(self):
        self.date_time=datetime.now()
        bucket_name = os.environ['AMAZON_SFTP_BUCKET']
        s3_resource = boto3.resource('s3')
        self.s3_connection = boto3.client(
            's3',
            aws_access_key_id=os.environ['AWS_ACCESS_KEY_ID'],
            aws_secret_access_key=os.environ['AWS_SECRET_ACCESS_KEY']
        )
        self.file_name = 'FLIPT_DRUG_NDC_11Mar2020.csv000'
        file_part_number = self.file_name.split('000')
        self.archive_filename = file_part_number[0].split('.')
        self.upload_path = 'dataload_{}/uploads'.format(os.environ['INSTANCE_TYPE'].lower())
        source_path = '{}/{}'.format(self.upload_path, self.file_name)
        self.dest_path = '{}/Archive/{}{}.{}'.format(self.upload_path, self.archive_filename[0],str(self.date_time.strftime("%d%b%Y")),self.archive_filename[1])
        self.copy_source = {'Bucket': bucket_name,
                    'Key': source_path}
        #s3_resource.Bucket(bucket_name).copy(self.copy_source, self.dest_path)
        #s3_resource.Object(bucket_name, source_path).delete()
        
    def test_s3_connection(self):
        self.assertTrue(self.s3_connection,True)
    def test_fileformat(self):
        self.assertEqual(self.archive_filename[1],'csv')
    def test_s3_copy_source_exists(self):
        self.assertTrue(self.copy_source)
    def test_dest_path_exists(self):
        self.assertTrue(self.dest_path)

if __name__ == "__main__":
    unittest.main()