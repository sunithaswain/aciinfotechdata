import boto3
import unittest
import os
import sys
import tracemalloc

class download_from_s3(unittest.TestCase):
    def setUp(self):
        self.s3_connection = boto3.client(
            's3',
            aws_access_key_id=os.environ['AWS_ACCESS_KEY_ID'],
            aws_secret_access_key=os.environ['AWS_SECRET_ACCESS_KEY']
        )
        path = os.environ['CB_DATA']
        _BUCKET_NAME = os.environ['AMAZON_SFTP_BUCKET']
        s3_resource = boto3.resource('s3')
        s3_bucket = s3_resource.Bucket(_BUCKET_NAME)
        modified_date = None
        file_name='FLIPT_DRUG_NDC_11Mar2020.csv000'
        file_part_extension = file_name.split('000')
        self.file_format = file_part_extension[0].split('.')
        self.dest_dir='/Users/Sbrawala/DEV_ENV/'
        self.source_file_name = ''
        for obj in s3_bucket.objects.filter(Prefix="dataload_{}/uploads/{}".
                                        format(os.environ['INSTANCE_TYPE'].lower(), file_name or 'FLIPT_DRUG_NDC_')):
            if os.path.basename(obj.key).startswith('FLIPT_DRUG_NDC_') and ((modified_date and modified_date < obj.last_modified) or not modified_date):
                self.source_file_name = os.path.basename(obj.key)
                modified_date = obj.last_modified
        if not self.source_file_name:
            sys.exit(1)
        self.source_file_name = self.source_file_name.split('000')[0]
        self.source_path = 'dataload_{}/uploads/{}'.format(os.environ['INSTANCE_TYPE'].lower(),
                                                    self.source_file_name + '000')
        self.dest_path = os.path.join(self.dest_dir, self.source_file_name)
        self.download_file_on_local = s3_bucket.download_file(self.source_path, self.dest_path)
        
        
    def test_fileformat(self):
        self.assertEqual(self.file_format[1],'csv')
    def test_s3_connection(self):
        self.assertTrue(self.s3_connection,True)
    def test_if_destdir_exists(self):
        self.assertTrue(self.dest_dir,True)
    def test_source_file(self):
        self.assertTrue(self.source_file_name,True)
    def test_download_s3file(self):
        self.assertTrue(self.download_file_on_local,True)
    
if __name__ == "__main__":
    unittest.main()