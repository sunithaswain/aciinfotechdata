########################################
# !/usr/bin/env python 

# title : awppriceupdate.py
# description : Medispan AWP price update program
# author : Disha
# date created : -
# last  modified : -
# version : 1
# maintainer : Hari
# email : -
# status : Production
# Python Version: 3.5.2
# usage         :  python awppriceupdate.py -d GWLABS001 -t awp_price -f FliptDrugFileApril2019.csv -m DRAFT
# Revisions:
# Version RevisedBy Date Change description
# ------- --------- -------- ------------------


# #######################################
# -*- coding: utf-8 -*-

if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']

import os
import time
import sys
from datetime import datetime
import json
import socket

import pandas as pd
from couchbase.n1ql import N1QLQuery
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase import FMT_JSON

from utils.sendgridemail import email_log
from utils import commandline

# from app.common.sendgridemail import email_log
# import app.common.commandline as commandline

# Automate Drug Database Load
# from autofile_transfer import multiplefilesftptransfer
# localpath = "D://Users//HRajendran//Documents//Python_127//Latest//test2//"
# remotepath = 'local'
# multiplefilesftptransfer(remotepath, localpath, 'FLIPT_DRUG_*', "GET")

domain,file_type,file_name,mode=commandline.main(sys.argv[1:])

cluster=Cluster(os.environ['CB_URL']+'?operation_timeout=2700')
auth=PasswordAuthenticator(os.environ['CB_APPS_USER'],os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(auth)
bucket_name=os.environ['CB_INSTANCE']
cb=cluster.open_bucket(bucket_name)

# modified by Hari on 27/12/2018
# path = os.environ['CB_DATA']
host = socket.gethostname()
currentdate = datetime.now()
currentdate = currentdate.strftime("%m%d%y%H%M%S")
log = path+'/'+domain+'/'+file_type+'/log/'+"awp_price_update"+currentdate+'.txt'

def update(pfile_name):
	input_file = path+'/'+domain+'/'+file_type+'/'+pfile_name
	awp=pd.read_csv(input_file,encoding='utf-8',dtype=str)
		
	# modified log by Hari on 27/12/2018
	logfile = open(log,"w")
	logfile.write("Input file is %s \n"%input_file)

	cols_dict={}
	for i in list(awp):
		cols_dict[i]=i.lower().replace(' ','_')
	awp.rename(columns=cols_dict,inplace=True)
	awp['package_qty']=awp['package_qty'].apply(lambda x: x.replace('\r','').replace('\n',''))
	awp['gpi']=awp['gpi'].apply(lambda x:str(x).zfill(14))
	query=N1QLQuery('SELECT distinct gpi FROM `'+bucket_name+'` WHERE type="drug"')
	query.timeout=7200
	gpi_list=[]
	for r in cb.n1ql_query(query):
		gpi_list.append(r['gpi'])

	logfile.write("Total %s GPIs are already exists in DB(Drug datatype). \n "%len(gpi_list))
	print("%s GPIs are found "%len(gpi_list))

	query=N1QLQuery('SELECT META().id as id,create_date,gpi,drug_name FROM `'+bucket_name+'` WHERE type="awp_price"')
	query.timeout=7200
	meta_ids=[]
	old_awp_drug=pd.DataFrame()
	isError = ''
	ite=0
	new_ite=0
	for r in cb.n1ql_query(query):
		meta_ids.append(r['id'])
		ele=r.pop('id')
		old_awp_drug=old_awp_drug.append(r,ignore_index=True)


	for k,g in awp.groupby(['gpi','ddid']):
		
		try:
			g.reset_index(drop=True,inplace=True)
			if k[0] in gpi_list:
				d=dict()
				for c in ['gpi','drug_name','brand_generic','dosage']:
					d[c]=str(g.loc[0,c])
				d['quantities']=[]
				for i,r in g.iterrows():
					quant={}
					for c in ['dosage_strength','unit_dose','multi_source','package_qty','package_size','package_quantity','awp_package_price','unit_price_extended','awp_price']:
						quant[c]=str(r[c])
					d['quantities'].append(quant)
				d['type']='awp_price'
				temp=old_awp_drug.loc[(old_awp_drug['gpi']==d['gpi']) & (old_awp_drug['drug_name']==d['drug_name']),'create_date'].values
				if len(temp)!=0: d['create_date']=str(old_awp_drug.loc[(old_awp_drug['gpi']==d['gpi']) & (old_awp_drug['drug_name']==d['drug_name']),'create_date'].values[0])
				else:  d['create_date']=datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat()
				d['update_date']=datetime.strptime(str(datetime.now()),"%Y-%m-%d %H:%M:%S.%f").isoformat()
				d['created_by']='System'
				d['updated_by']='System'
				if ite<len(meta_ids):
					# modified by Hari  on 27/12/2018
					if mode.strip().upper() == 'FINAL':
						cb.upsert(str(meta_ids[ite]),d, format=FMT_JSON)
					
					ite=ite+1
				else:
					if mode.strip().upper() == 'FINAL':
						cb.upsert(str(cb.counter('docid',delta=1).value),d, format=FMT_JSON)
					new_ite += 1

		except:
			# modified by Hari  on 27/12/2018
			logfile.write("Error occured on update row %s \n"%g[0])
			isError = "Error occured on update some records"
				
	# added by Hari on 27/12/2018
	logfile.write('%s records are updated and %s records are inserted \n'%(ite, new_ite))
	print('%s records are updated and %s records are inserted \n'%(ite, new_ite))

	subject = 'AWP price update - Final Mode :'+host+isError

	if mode.strip().upper() == 'DRAFT':
		logfile.write('awp price update - Draft Mode : %s, File: %s'%(host,pfile_name))
		subject = 'awp price update - Draft Mode :'+host
	logfile.close()
	email_log('DWagle@GWLabs.com','DWagle@GWLabs.com','HRajendran@fliptrx.com',subject,['AWP price update File '+log,'AWP price update Exception'],log,True)

	print(input_file)		
	print(path+'/'+domain+'/'+file_type+'/archive/'+pfile_name)			

	if meta_ids[ite-1]!=meta_ids[-1]:
		for h in meta_ids[ite:]:
			cb.remove(str(h),quiet=True)

	if mode.strip().upper() == 'FINAL':
		if not os.path.isdir(path+'/'+domain+'/'+file_type+'/archive/'): os.makedirs(path+'/'+domain+'/'+file_type+'/archive/')
		os.rename(input_file, path+'/'+domain+'/'+file_type+'/archive/'+pfile_name)
		
if file_name:
	print('basic calling function invoked')
	update(file_name)
else:
	print('Automate calling function invoked')
	# Automate Drug Database Load
	from utils.autofile_transfer import multiplefilesftptransfer
	localpath = path+'/'+domain+'/'+file_type+'/'
	remotepath = 'MonthlyUpdates'
	multiplefilesftptransfer(remotepath, localpath, 'FLIPT_AWP_PRICE_*', mode)

	for file_name in os.listdir(localpath):
		print(file_name)
		print(os.path.isdir(os.path.join(localpath,file_name)))
		if file_name.startswith("FLIPT_AWP_PRICE_") and os.path.isfile(os.path.join(localpath,file_name)):
			print("file is %s"%file_name)
			update(file_name)
