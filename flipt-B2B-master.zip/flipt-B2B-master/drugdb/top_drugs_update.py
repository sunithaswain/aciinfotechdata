import pandas as pd
from datetime import datetime
from couchbase.n1ql import N1QLQuery
from utils.sendgridemail import email_log
from utils.helper_functions import cb_authenticate, process_cmdline
import os

arguments = process_cmdline([("-a", "--action", "insert/refresh mode", True)])
domain, file_type, file_name, mode, action = arguments['domain'], arguments[
    'file_type'], arguments['file_name'], arguments['mode'], arguments['action']
bucket_name = os.environ['CB_INSTANCE']
cb = cb_authenticate()
path = os.environ['CB_DATA']

data = pd.read_excel(path+'/'+file_type+'/'+file_name)
data['GPI_12'] = data['GPI_12'].apply(lambda x: str(x).zfill(12))
result = []
record = {}
docid = 'top_drugs'
result = cb.get(docid, quiet=True)
if not (result and result.value):
    record = {'create_date': datetime.now().isoformat()}
if action.upper() == 'INSERT':
    result.extend(list(data['GPI_12']))
else:
    result = list(data['GPI_12'])
record.update({'type': 'top_drugs',
               'update_date': datetime.now().isoformat(), 'gpi_12': result})
cb.upsert(docid, record)
