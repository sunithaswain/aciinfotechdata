########################################
# !/usr/bin/env python
# title         : noswitchdrug.py
# description   : Update no_switch_drug document from file data
# author        : Shweta
# date created  : 20190926
# date last modified    :
# version       : 0.1
# maintainer    : Shweta
# email         : syennawar@fliptrx.com
# status        :
# Python Version: 3.7.3
# usage         : python noswitchdrug.py -d GWLABS001 -t DRUG_DATABASE -f data.xlsx -m DRAFT
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#
# #######################################

#keep the data.xlsx at this location \FLIPTB2B\data\DRUG_DATABASE
if __name__ == '__main__':
    import os
    import sys
    rootdir = os.path.dirname(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))))
    sys.path.append(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']
import argparse
import logging
import os
import ast
from datetime import datetime

import pandas as pd
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.n1ql import N1QLQuery

now = datetime.now().strftime("%d-%m-%Y-%H:%M")

# add new logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

fh = logging.FileHandler(f'{path}/DRUG_DATABASE/log/switch_drug_log-{now}.log')
fh.setLevel(logging.DEBUG)

formatter = logging.Formatter('%(name)s - %(asctime)s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)

logger.addHandler(fh)

# run command:python noswitchdrug.py -d GWLABS001 -t DRUG_DATABASE -f data.xlsx -m DRAFT
parser = argparse.ArgumentParser(description='commandline file processing...')
parser.add_argument("-d", "--domain", help="pass in domain (company)", required=True),
parser.add_argument("-t", "--file_type", help="pass in doc type", required=True)
parser.add_argument("-f", "--file_name", help="pass in file name", required=True)
parser.add_argument("-m", "--processing_type", help="final/draft mode", required=True)

args = vars(parser.parse_args())
domain = str(args['domain'])
file_type = str(args['file_type'])
file_name = str(args['file_name'])
mode = str(args['processing_type'])
logger.debug(mode)

cluster = Cluster(os.environ['CB_URL'] + '?operation_timeout=2700')
auth = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(auth)
bucket_name = os.environ['CB_INSTANCE']
cb = cluster.open_bucket(bucket_name)

logger.debug((os.path.join(path, file_type, file_name)).replace('\\', '/'))

file_format = os.path.splitext(file_name)[-1]
if file_format == ".csv":
    data = pd.read_csv(path + '/'  + file_type + '/' + file_name)
else:
    data = pd.read_excel(path + '/' + file_type + '/' + file_name)
data.fillna("", inplace=True)
logger.debug(f"No of records in File {str(data.shape[0])}")

for index, row in data.iterrows():
    data_dict = dict()
    metaid = ''
    data_dict['type'] = 'no_switch_drug'
    df = pd.DataFrame()
    for col in list(data):
        data_dict[col.lower().replace(' ', '_')] = str(row[col])

    startdate = str(datetime.strptime(str(data_dict['start_date']), "%Y-%m-%d %H:%M:%S"))
    enddate = str(datetime.strptime(str(data_dict['end_date']), "%Y-%m-%d %H:%M:%S"))
    query = N1QLQuery('SELECT META().id as id FROM `' + bucket_name + '`WHERE type = "no_switch_drug" and domain = '
                      '$domainname and ddid = $did and start_date = $startdate and end_date = $enddate and '
                                                                      'benefit_plan_name = $planname',
                      did=data_dict['ddid'], domainname=data_dict['domain'], planname=data_dict['benefit_plan_name'],
                      startdate=data_dict['start_date'],
                      enddate=data_dict['end_date'])

    query.timeout = 7200
    query_result = cb.n1ql_query(query)
    for p in query_result:
        metaid = p['id']
        logger.debug(f'InLoop, {metaid}')

    logger.debug(f'OutLoop, {metaid}')

    if mode.upper().strip() == 'FINAL':
        if metaid != '':
            #data_dict['filter_alternatives'] = ast.literal_eval(data_dict['filter_alternatives'])
            #data_dict['filter_generics'] = ast.literal_eval(data_dict['filter_generics'])
            cb.upsert(str(metaid), data_dict)
            logger.debug(f"updated the record {metaid} with the data {data_dict}")
        else:
            cb.upsert(str(cb.counter('docid', delta=1).value), data_dict)
            logger.debug(f"updated the record {metaid} with the data {data_dict}")
    else:
        logger.debug("Domain config update program is running in draft mode")
