import os
import sys
import boto3
import botocore


def read_file_from_S3(log_hndl, dest_dir, file_name=None):
    # AWS File location
    _BUCKET_NAME = os.environ['AMAZON_SFTP_BUCKET']
    s3_resource = boto3.resource('s3')
    s3_bucket = s3_resource.Bucket(_BUCKET_NAME)
    for obj in s3_bucket.objects.filter(Prefix="dataload_{}/uploads/{}".
            format(os.environ['INSTANCE_TYPE'].lower(), file_name or 'DRUG_DATABASE_')):
        source_file_name = os.path.basename(obj.key)
        if file_name is not None and source_file_name.startswith(file_name):
           break
        elif file_name is None and source_file_name.startswith('DRUG_DATABASE_'):
            break
    else:
        log_hndl.info("No files found with pattern")
        sys.exit(1)

    source_path = 'dataload_{}/uploads/{}'.format(os.environ['INSTANCE_TYPE'].lower(),
                                                  source_file_name)
    boto3.client(
        's3',
        aws_access_key_id=os.environ['AWS_ACCESS_KEY_ID'],
        aws_secret_access_key=os.environ['AWS_SECRET_ACCESS_KEY']
    )
    dest_path = os.path.join(dest_dir, source_file_name)
    s3_bucket.download_file(source_path, dest_path)
    return dest_path
# end function


def move_file_to_archive(source_file_name):
    source_file_name = os.path.basename(source_file_name)
    _bucket_name = os.environ['AMAZON_SFTP_BUCKET']
    upload_path = 'dataload_{}/uploads'.format(os.environ['INSTANCE_TYPE'].lower())
    source_path = '{}/{}'.format(upload_path, source_file_name)
    dest_path = '{}/Archive/{}'.format(upload_path, source_file_name)

    boto3.client(
        's3',
        aws_access_key_id=os.environ['AWS_ACCESS_KEY_ID'],
        aws_secret_access_key=os.environ['AWS_SECRET_ACCESS_KEY']
    )
    s3_resource = boto3.resource('s3')
    copy_source = {'Bucket': _bucket_name,
                   'Key': source_path}
    s3_resource.Bucket(_bucket_name).copy(copy_source, dest_path)
    s3_bucket = s3_resource.Bucket(_bucket_name)
    s3_bucket.Object(source_path).delete()
# end function


def move_file_to_S3(log_hndlr, datapath, erase=True):
    from botocore.exceptions import ClientError

    s3_client = boto3.client(
        's3',
        aws_access_key_id=os.environ['AWS_ACCESS_KEY_ID'],
        aws_secret_access_key=os.environ['AWS_SECRET_ACCESS_KEY']
    )

    file_list = os.listdir(datapath)

    for filenm in file_list:
        _BUCKET_NAME = os.environ['AMAZON_SFTP_BUCKET']
        upload_path = 'dataload_{}/uploads'.format(os.environ['INSTANCE_TYPE'].lower())
        source_path = '{}/{}'.format(datapath, filenm)
        dest_path = '{}/Archive/logs/{}'.format(upload_path, filenm)
        log_hndlr.info(f"Moving file: {filenm} to {dest_path}")

        try:
            response = s3_client.upload_file(source_path, _BUCKET_NAME, dest_path)
        except ClientError as e:
            log_hndlr.error(e)

        if erase is True:
           os.unlink(source_path)
    # end loop
# end function
