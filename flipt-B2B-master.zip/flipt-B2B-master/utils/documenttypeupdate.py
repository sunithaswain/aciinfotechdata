import argparse
from couchbase.n1ql import N1QLQuery, N1QLRequest
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Cluster
from couchbase import FMT_JSON
import os
import time

parser = argparse.ArgumentParser(description='commandline file processing...')
parser.add_argument("-t", "--filetype",
                    help="pass in doc type", required=False)
parser.add_argument("-a", "--action",
                    help="pass in function", required=False)
parser.add_argument("-m", "--processing_type",
                    help="final/draft mode", required=True)
args = parser.parse_args()
filetype, mode, action = args.filetype, args.processing_type, args.action

cluster = Cluster(os.environ['CB_URL'])
auth = PasswordAuthenticator(
    os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(auth)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
bucket_name = os.environ['CB_INSTANCE']


def copy_pricing():

    query = N1QLQuery('Select * from `' + bucket_name +
                      '` where type="cp_drug_price"')
    query.timeout = 3600
    for result in cb.n1ql_query(query):
        result = result[bucket_name]
        result['type'] = 'cp_drug_price_stg'
        rv1 = cb.counter('docid', delta=1)
        result['drug_price_id'] = str(rv1.value)

        cb.upsert(str(result['drug_price_id']), result)


def update_pricing():

    query = N1QLQuery('Update `' + bucket_name +
                      '` set type="cp_drug_price_bkp" where type="cp_drug_price"')
    query.timeout = 3600
    cb.n1ql_query(query).execute()
    update_record_count = -1
    query = N1QLQuery('Select count(*) count from `'+bucket_name +
                      '` where type="cp_drug_price"')
    for result in cb.n1ql_query(query):
        update_record_count = result['count']
    if update_record_count == -1:
        print('Error updating cp_drug_price to cp_drug_price_bkp')
    print("Records updated from cp_drug_price to cp_drug_price_bkp")
    time.sleep(10)
    query = N1QLQuery('Update `' + bucket_name +
                      '` set type="cp_drug_price" where type="cp_drug_price_stg"')
    query.timeout = 3600
    cb.n1ql_query(query).execute()
    update_record_count = 0
    query = N1QLQuery('Select count(*) count from `'+bucket_name +
                      '` where type="cp_drug_price"')
    for result in cb.n1ql_query(query):
        update_record_count = result['count']
    if not update_record_count > 0:
        print('Error updating cp_drug_price_stg to cp_drug_price')
    print("Records updated from cp_drug_price_stg to cp_drug_price")


def update_pharmacy():

    query = N1QLQuery('Update `' + bucket_name +
                      '` set type="cp_pharmacy_bkp" where type="cp_pharmacy"')
    query.timeout = 3600
    cb.n1ql_query(query).execute()
    update_record_count = -1
    query = N1QLQuery('Select count(*) count from `'+bucket_name +
                      '` where type="cp_pharmacy"')
    for result in cb.n1ql_query(query):
        update_record_count = result['count']
    if update_record_count == -1:
        print('Error updating cp_pharmacy to cp_pharmacy_bkp')
    print("Records updated from cp_pharmacy to cp_pharmacy_bkp")
    time.sleep(10)
    query = N1QLQuery('Update `' + bucket_name +
                      '` set type="cp_pharmacy" where type="cp_pharmacy_stg"')
    query.timeout = 3600
    cb.n1ql_query(query).execute()

    update_record_count = 0
    query = N1QLQuery('Select count(*) count from `'+bucket_name +
                      '` where type="cp_pharmacy"')
    for result in cb.n1ql_query(query):
        update_record_count = result['count']
    if not update_record_count > 0:
        print('Error updating cp_pharmacy_stg to cp_pharmacy')
    print("Records updated from cp_pharmacy_stg to cp_pharmacy")


if filetype == 'cp_drug_price':
    if action == 'SWITCH':
        update_pricing()
    if action == 'COPY':
        copy_pricing()
elif filetype == 'cp_pharmacy':
    update_pharmacy()
