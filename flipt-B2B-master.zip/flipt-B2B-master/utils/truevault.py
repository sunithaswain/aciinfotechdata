import sys
import os
import base64
import copy
import json
import traceback

import couchbase.subdocument as SD
import dateutil.parser as parser
import pandas as pd
import requests

from datetime import datetime
from couchbase import FMT_JSON
from couchbase.n1ql import N1QLQuery
from requests.auth import HTTPBasicAuth

try:
    from .helper_functions import *
    from .user_util_functions import new_user_communication
    from .user_util_functions import terminated_dependent_communication
    from .user_util_functions import user_changes_communication
except:
    from utils.helper_functions import *
    from utils.user_util_functions import new_user_communication
    from utils.user_util_functions import terminated_dependent_communication
    from utils.user_util_functions import user_changes_communication


'''
# B2B-880
By Deepthi
Changes to eligibility TV structure
#Changes in update_user() and update_active_status : Removing coverage_effective_date and 
coverage_termination_date from empcols and hpcols and added eligibility attribute 
'''


class User_Class(object):
    # initialize User_Class object with username,password,attributes,group and status;initialization is optional
    def __init__(self, username=None, password=None, attributes=None, group_ids=None,
                 status=None, dom_map=None, cb_handle=None, maxplans=5):
        self.api_key = os.environ['TV_API_KEY']
        self.current_time = datetime.strptime(
            str(datetime.now()), "%Y-%m-%d %H:%M:%S.%f").isoformat()

        if cb_handle is None:
            self.cb_handle = cb_authenticate()
        else:
            self.cb_handle = cb_handle

        self.username = username
        self.password = password
        self.attributes = attributes
        self.group_ids = group_ids
        self.status = status
        self.maxplans = maxplans

        if dom_map is not None:
            self.domain_mappings = dom_map
    # end constructor

    # create a user using initialized username,password,attributes,etc in func __init__

    def create_user(self):
        self.password = str(
            self.attributes['zip']) + str(self.attributes['employee_ssn'])[-4:]
        self.attributes['active'] = True
        self.attributes['tmp_password'] = self.password
        attributes = base64.b64encode(str.encode(json.dumps(self.attributes)))

        if not self.username:
            self.username = self.attributes['flipt_person_id']

        data = {'username': self.username,
                'password': self.password,
                'attributes': attributes,
                'group_ids': self.group_ids}

        r = requests.post('https://api.truevault.com/v1/users',
                          auth=HTTPBasicAuth(self.api_key, ''),
                          data=data)

        if r.status_code == 400 or r.status_code == 404:
            return None

        response = r.json()
        return response['user']['user_id']
        # userid = response['user']['user_id']
    # end method

    # using userid, read the user attributes
    def read_user(self, userid):

        data = {'full': True}
        r = requests.get('https://api.truevault.com/v2/users/%s' % str(userid),
                         auth=HTTPBasicAuth(self.api_key, ''),
                         data=data)
        return r.json()
    # end method

    # using search option provided (values used to search user), one user is returned fromm the result
    def search_tvuser(self, search_option):

        search_opt = base64.b64encode(str.encode(json.dumps(search_option)))
        data = {'search_option': search_opt}
        r = requests.post('https://api.truevault.com/v1/users/search',
                          auth=HTTPBasicAuth(self.api_key, ''),
                          data=data)
        response = r.json()
        # print(response)
        if 'data' not in response:
            return None, None

        if len(response['data']['documents']) == 0 and r.status_code == 200:
            return None, None

        att = json.loads(str(base64.b64decode(
            response['data']['documents'][0]['attributes']), 'utf-8'))
        userid = response['data']['documents'][0]['user_id']
        return att, userid
    # end method

    # using search option provided (values used to search user), all users are returned

    def search_user_id(self, search_option):
        search_opt = base64.b64encode(str.encode(json.dumps(search_option)))
        data = {'search_option': search_opt}
        r = requests.post('https://api.truevault.com/v1/users/search',
                          auth=HTTPBasicAuth(self.api_key, ''),
                          data=data)
        response = r.json()
        attlist = []
        useridlist = []
        if 'data' not in response:
            return [], []

        if len(response['data']['documents']) == 0 and r.status_code == 200:
            return [], []

        for i in range(0, len(response['data']['documents'])):
            attlist.append(json.loads(str(base64.b64decode(
                response['data']['documents'][i]['attributes']), 'utf-8')))
            useridlist.append(response['data']['documents'][i]['user_id'])
        return attlist, useridlist
    # end method

    def search_user(self, search_option):
        search_opt = base64.b64encode(str.encode(json.dumps(search_option)))
        data = {'search_option': search_opt}
        r = requests.post('https://api.truevault.com/v1/users/search',
                          auth=HTTPBasicAuth(self.api_key, ''),
                          data=data)
        response = r.json()
        # print(response)
        if 'data' not in response:
            return None, None

        if len(response['data']['documents']) == 0 and r.status_code == 200:
            return None, None

        att = json.loads(str(base64.b64decode(
            response['data']['documents'][0]['attributes']), 'utf-8'))
        userid = response['data']['documents'][0]['user_id']

        if att.get('coverage_effective_date') is None:
            now = datetime.now().strftime("%Y-%m-%d 00:00:00")
            valid_eligibility = list(
                filter(lambda x: x['coverage_effective_date'] <= now <= x['coverage_termination_date'],
                       att['eligibility']))
            if valid_eligibility:
                att.update(valid_eligibility[0])
            if 'dependents' in att:
                for dep in att['dependents']:
                    dep_eligibility = list(
                        filter(lambda x: x['coverage_effective_date'] <= now <= x['coverage_termination_date'],
                               dep['eligibility']))
                    if dep_eligibility:
                        dep.update(dep_eligibility[0])

        if att.get('cobra_effective_date') is None:
            now = datetime.now().strftime("%Y-%m-%d 00:00:00")
            valid_eligibility = list(
                filter(lambda x: x['cobra_effective_date'] <= now <= x['cobra_termination_date'],
                       att['eligibility']))
            if valid_eligibility:
                att.update(valid_eligibility[0])
            if 'dependents' in att:
                for dep in att['dependents']:
                    dep_eligibility = list(
                        filter(lambda x: x['cobra_effective_date'] <= now <= x['cobra_termination_date'],
                               dep['eligibility']))
                    if dep_eligibility:
                        dep.update(dep_eligibility[0])

        return att, userid
    # end method

    def set_search_option(self, usertype, user_attributes, log_hndl=None, search_param=''):
        ssn, email, first_name, last_name, date_of_birth = '', '', '', '', ''

        if usertype == 'employee':
            try:
                ssn = str(self.attributes.get('employee_ssn', ''))
                email = self.attributes['work_email']
                first_name = self.attributes['first_name']
                last_name = self.attributes['last_name']
                date_of_birth = self.attributes['date_of_birth']
            except:
                pass

        elif usertype == 'dependent':
            try:
                ssn = str(user_attributes.get('dependent_ssn', ''))
                email = user_attributes['email']
                first_name = user_attributes['first_name']
                last_name = user_attributes['last_name']
                date_of_birth = user_attributes['date_of_birth']
            except:
                pass

        if search_param == 'name_dob':
            search_option = {
                'full_document': True,
                'filter':
                    {
                        'first_name':
                            {
                                'type': 'eq',
                                'value': first_name,
                                'case_sensitive': False
                            },
                        'last_name':
                            {
                                'type': 'eq',
                                'value': last_name,
                                'case_sensitive': False
                            },
                        'date_of_birth':
                            {
                                'type': 'eq',
                                'value': date_of_birth,
                                'case_sensitive': False
                            },
                        '$tv.status':
                            {
                                'type': 'eq',
                                'value': 'ACTIVATED'
                            }
                    },
                'filter_type': 'and'
            }
            print('******Searching user based on First Name,Last Name,DOB******')
            if log_hndl is not None:
                log_hndl.info(
                    'Searching user based on First Name,Last Name,DOB')
            return search_option

        elif not (ssn.isdigit() and len(ssn) == 9) or search_param == 'email':
            search_option = {'full_document': True,
                             'filter':
                                 {
                                     '$tv.username':
                                         {
                                             'type': 'eq',
                                             'value': email,
                                             'case_sensitive': False
                                         },
                                     'domain_name':
                                         {
                                             'type': 'eq',
                                             'value': self.attributes['domain_name'],
                                             'case_sensitive': False
                                         },
                                     '$tv.status':
                                         {
                                             'type': 'eq',
                                             'value': 'ACTIVATED'
                                         }
                                 },
                             'filter_type': 'and'
                             }
            print('******Searching user based on Email******')
            if log_hndl is not None:
                log_hndl.info('Searching user based on Email')
            return search_option

        elif search_param == 'ssn' or (ssn.isdigit() and len(ssn) == 9):
            if (ssn.isdigit() and len(ssn) == 9):
                search_option = {
                    'full_document': True,
                    'filter':
                        {
                            usertype + '_ssn':
                                {
                                    'type': 'eq',
                                    'value': ssn,
                                    'case_sensitive': False
                                },
                            'domain_name':
                                {
                                    'type': 'eq',
                                    'value': self.attributes['domain_name'],
                                    'case_sensitive': False
                                },
                            '$tv.status':
                                {
                                    'type': 'eq',
                                    'value': 'ACTIVATED'
                                }
                        },
                    'filter_type': 'and'
                }
                print('******Searching user based on SSN******')
                if log_hndl is not None:
                    log_hndl.info('Searching user based on SSN')
                return search_option
    # end method

    def check_planyear_exists(self, in_dict, master_list):
        # loop thru to compare if in_dict['plan_year'] is already present in the master dictionary
        # if present, dont create duplicates
        for elig_recs in master_list:
            if in_dict['plan_year'] == elig_recs['plan_year']:
                return True
        # end loop

        # not found in list
        return False
    # end function

    # update user attributes; used during employee-dependent update

    def update_user(self, sendgrid_usrlist, mode='final', log_hndl=None, hr_email=None,
                    notify_user=None, createfile=False, fileComp=None):
        from pprint import pformat

        errlog = pd.DataFrame()
        emperrlog = pd.DataFrame()
        flipt_person_id_map = {}

        if notify_user is None:
            notify_user = 'N'

        try:
            # search a user to check if present or not
            search_option = self.set_search_option('employee', {}, log_hndl)
            att, userid = self.search_tvuser(search_option)
            if userid is None and search_option is not None and 'employee_ssn' in search_option['filter']:
                search_option = self.set_search_option(
                    'employee', {}, log_hndl, search_param='ssn')
                att, userid = self.search_tvuser(search_option)
            elif userid is None:
                search_option = self.set_search_option(
                    'employee', {}, log_hndl, search_param='name_dob')
                att, userid = self.search_tvuser(search_option)

            try:
                tier_name = self.attributes['coverage_tier_name']
            except KeyError:
                tier_name = self.attributes['eligibility'][-1]['coverage_tier_name']

            if userid is None:

                # user was not found, hence creating a new user and inserting record
                # into flipt_person_hierarchy document type
                if fileComp is not None:
                    fileComp.append({
                        'record': "not present"
                    }, 'pre')

                rec = dict()
                try:
                    rv = self.cb_handle.counter('counterid', delta=1)
                except:
                    # retry
                    rv = self.cb_handle.counter('counterid', delta=1)

                self.attributes['flipt_person_id'] = str(rv.value)
                self.attributes['created_at'] = self.current_time
                self.attributes['updated_at'] = self.current_time

                # CARYNHEALTH related requirement
                if 'CARYN' in self.attributes['domain_name']:
                    self.attributes['UID'] = self.attributes['employee_id']

                # New code Date 27thJuly By Deepthi
                self.attributes['eligibility'] = []
                eligibile_plan_year = str(parser.parse(
                    self.attributes['coverage_effective_date']).year)
                tier_name = self.attributes['coverage_tier_name']

                # For new user only one eligibility for that curent plan year will be there
                # Cobra effective and termination date is null
                primary_eligibility_dict = {'plan_year': eligibile_plan_year,
                                            'coverage_termination_date': self.attributes['coverage_termination_date'],
                                            'coverage_effective_date': self.attributes['coverage_effective_date'],
                                            'benefit_plan_name': self.attributes['benefit_plan_name'],
                                            'coverage_tier_name': self.attributes['coverage_tier_name'],
                                            'cobra_effective_date': self.attributes.get('cobra_effective_date', ''),
                                            'cobra_termination_date': self.attributes.get('cobra_termination_date', '')}

                # 'display_plan_name' related requirements
                if 'display_plan_name' in self.attributes:
                    primary_eligibility_dict['display_plan_name'] = self.attributes['display_plan_name']

                self.attributes['eligibility'].append(primary_eligibility_dict)

                recs = []
                testacc = False
                if 'TEST' in self.attributes['employee_id'].upper():
                    testacc = True

                rec = {}
                rec['emp_flipt_person_id'] = str(rv.value)
                rec['dep_flipt_person_id'] = str(rv.value)
                rec['is_2fa_required'] = True
                rec['domain_name'] = self.attributes['domain_name']
                rec['created_at'] = self.current_time
                rec['updated_at'] = self.current_time
                rec['hp_eligibility_updated'] = 'Y'
                rec['sc_extracted_date'] = ''
                rec['type'] = 'flipt_person_hierarchy'
                recs.append(rec)

                for i in range(len(self.attributes['dependents'])):
                    atr_key = 'dependents'
                    rec = dict()
                    self.attributes[atr_key][i]['eligibility'] = []
                    rec['emp_flipt_person_id'] = str(rv.value)
                    inc = self.cb_handle.counter('counterid', delta=1)
                    self.attributes[atr_key][i]['flipt_person_id'] = str(
                        inc.value)
                    self.attributes[atr_key][i]['created_at'] = self.current_time
                    self.attributes[atr_key][i]['updated_at'] = self.current_time
                    self.attributes[atr_key][i]['account_type'] = 'dependent'
                    self.attributes[atr_key][i]['is_2fa_required'] = True

                    dep_eligibility_dict = {
                        'plan_year': eligibile_plan_year,
                        'coverage_termination_date': self.attributes[atr_key][i]['coverage_termination_date'],
                        'coverage_effective_date': self.attributes[atr_key][i]['coverage_effective_date'],
                        'benefit_plan_name': self.attributes['benefit_plan_name'],
                        'coverage_tier_name': tier_name,
                        'cobra_effective_date': self.attributes[atr_key][i].get('cobra_effective_date', ''),
                        'cobra_termination_date': self.attributes[atr_key][i].get('cobra_termination_date', '')
                    }

                    # 'display_plan_name' related requirements - made non-specific
                    if 'display_plan_name' in self.attributes['eligibility'][-1]:
                        dep_eligibility_dict['display_plan_name'] = self.attributes['eligibility'][
                            -1]['display_plan_name']

                    self.attributes[atr_key][i]['eligibility'].append(
                        dep_eligibility_dict)

                    rec['dep_flipt_person_id'] = str(inc.value)
                    rec['domain_name'] = self.attributes['domain_name']
                    rec['created_at'] = self.current_time
                    rec['updated_at'] = self.current_time
                    rec['hp_eligibility_updated'] = 'Y'
                    rec['sc_extracted_date'] = ''
                    rec['type'] = 'flipt_person_hierarchy'
                    recs.append(rec)

                # insert into flipt_person_hierarchy
                if testacc is False:
                    for row in recs:
                        if mode.lower() == 'final':
                            self.cb_handle.upsert(str(self.cb_handle.counter('docid', delta=1).value),
                                                  row,
                                                  format=FMT_JSON)
                        else:
                            if log_hndl is not None:
                                log_hndl.info(
                                    f"mock add of record into flipt_person_hierarchy: \n{row}")
                            print(
                                f"mock add of record into flipt_person_hierarchy: \n{row}")
                else:
                    if log_hndl is not None:
                        log_hndl.info(f"Not adding test account [< {self.attributes['flipt_person_id']} >] " +
                                      "to flipt_person_hierarchy")
                    print(f"Not adding test account [< {self.attributes['flipt_person_id']} >] " +
                          "to flipt_person_hierarchy")

                self.username = self.attributes['work_email'].lower()
                self.attributes = self.remove_attributes(self.attributes)

                # create user in Truevault
                # print('Atrributes for New user',self.attributes)
                if mode.lower() == 'final':
                    ret_data = self.create_user()
                    # ret_data = ''

                    if ret_data is not None:
                        if log_hndl is not None:
                            log_hndl.info(
                                f"Added record {self.attributes} to truevault in mode: {mode}.")

                        if fileComp is not None:
                            fileComp.append(self.attributes, 'post')

                        sendgrid_params = new_user_communication(self.domain_mappings, self.attributes,
                                                                 logger=log_hndl, createfl=createfile)
                        flipt_person_id_map.update(
                            {self.attributes.get('employee_ssn', ''): self.attributes['flipt_person_id']})
                        for dep in self.attributes['dependents']:
                            flipt_person_id_map.update(
                                {dep.get('dependent_ssn', ''): dep['flipt_person_id']})

                        if sendgrid_params is not None:
                            sendgrid_usrlist.append(sendgrid_params)

                        user_created = {'Domain Name': self.attributes['domain_name'],
                                        'First Name': self.attributes['first_name'],
                                        'Last Name': self.attributes['last_name'],
                                        'Flipt Person ID': self.attributes['flipt_person_id'],
                                        'Record Message': "User created"}

                        if 'UID' in self.attributes:
                            user_created['UID'] = self.attributes['employee_id']
                        else:
                            user_created['Employee ID'] = self.attributes['employee_id']

                        emperrlog = emperrlog.append(
                            user_created, ignore_index=True)
                    else:  # ret_data was a 404 or 404
                        if log_hndl is not None:
                            log_hndl.error(
                                "ERROR: unable to create user on truevault")
                        user_created = {'Domain Name': self.attributes['domain_name'],
                                        'First Name': self.attributes['first_name'],
                                        'Last Name': self.attributes['last_name'],
                                        'Flipt Person ID': self.attributes['flipt_person_id'],
                                        'Record Message': "User creation error"}
                        emperrlog = emperrlog.append(
                            user_created, ignore_index=True)

                else:  # mode is draft
                    if log_hndl is not None:
                        log_hndl.info(
                            f'Mock create truevault record: \n{pformat(self.attributes)}')
                    print(f'Mock create truevault record: \n{self.attributes}')

                return (errlog, emperrlog, sendgrid_usrlist, flipt_person_id_map)

        except Exception as e:
            type, value, etraceback = sys.exc_info()
            error = ''
            x = traceback.format_exception(type, value, etraceback)
            for i in x:
                error += i
            print(
                'Error while sending data to Truevault for new user. Error is :: ' + error)
            if log_hndl is not None:
                log_hndl.info(
                    'Error while sending data to Truevault for new user. Error is :: ' + error)

            uname = ''
            if 'work_email' in self.attributes:
                uname = self.attributes['work_email'].lower()

            emperrlog = emperrlog.append({'Domain Name': self.attributes['domain_name'],
                                          'Username': uname, 'Employee ID': '',
                                          'Record Message': error},
                                         ignore_index=True)
            return errlog, emperrlog, sendgrid_usrlist, flipt_person_id_map

        # ---------- logic for updating existing record ----------------------
        try:

            new_dependents = False

            dep_id = []
            updatedependent = pd.DataFrame()
            testacc = False

            if fileComp is not None:
                fileComp.append(att, 'pre')

            if mode.lower() == 'draft':
                print("Original record: \n" + pformat(att))
                if log_hndl is not None:
                    log_hndl.info(
                        'Original record before change:\n ' + pformat(att))

            # check if it is a test account
            if 'TEST' in self.attributes['employee_id'].upper():
                testacc = True

            # check if user is registered
            # if 'claimed' not in att:
            #    self.attributes['active'] = False

            att1 = ''
            att['active'] = True
            #print('Att TV',att)
            if 'active' in att and att['active'] is True:

                #att1 = att.copy(deep=True)
                att1 = copy.deepcopy(att)
                # Moving the eligibility param outside eligibility
                if att1.get('coverage_effective_date') is None:
                    now = datetime.now().strftime("%Y-%m-%d 00:00:00")
                    valid_eligibility = list(filter(
                        lambda x: x['coverage_effective_date'] <= now <= x['coverage_termination_date'],
                        att1['eligibility']))
                    if valid_eligibility:
                        att1.update(valid_eligibility[0])
                    if 'dependents' in att1:
                        for dep in att1['dependents']:
                            dep_eligibility = list(filter(
                                lambda x: x['coverage_effective_date'] <= now <= x['coverage_termination_date'],
                                att1['eligibility']))

                            if dep_eligibility:
                                dep.update(dep_eligibility[0])

                (errlog, emperrlog, param_values) = user_changes_communication(self.domain_mappings,
                                                                               errlog, emperrlog,
                                                                               att1, self.attributes,
                                                                               hr_email=hr_email,
                                                                               notify_user=notify_user,
                                                                               mode=mode,
                                                                               createfl=createfile)
                if param_values is not None:
                    sendgrid_usrlist.append(param_values)

            self.attributes['updated_at'] = datetime.strptime(
                str(datetime.now()), "%Y-%m-%d %H:%M:%S.%f").isoformat()

            # Changing the self.attributes structure to have employee eligibility attribute.B2B-880.
            # So that comparison of TV and self attributes is equal.
            # print('Attributes self',self.attributes)
            # print('Attributes TV',att)
            if self.attributes['employment_status'].lower().strip() == 'terminated':
                eligibile_plan_year = str(parser.parse(
                    self.attributes['termination_date']).year)
                primary_eligibility_dict = {'plan_year': eligibile_plan_year,
                                            'coverage_termination_date': self.attributes['coverage_termination_date'],
                                            'coverage_effective_date': self.attributes['coverage_effective_date'],
                                            'benefit_plan_name': self.attributes['benefit_plan_name'],
                                            'coverage_tier_name': self.attributes['coverage_tier_name'],
                                            'cobra_effective_date': '',
                                            'cobra_termination_date': ''}

                for e in att['eligibility']:
                    if e['plan_year'] == eligibile_plan_year:
                        tier_name = e['coverage_tier_name']
                self.attributes['eligibility'] = []
                self.attributes['eligibility'].append(
                    copy.deepcopy(primary_eligibility_dict))
            else:
                eligibile_plan_year = str(parser.parse(
                    self.attributes['coverage_effective_date']).year)
                tier_name = self.attributes['coverage_tier_name']
                self.attributes['eligibility'] = []
                orig_elig_py = None
                for e in att['eligibility']:
                    # Appending self .attributes with all the truevault plan years.
                    if e['plan_year'] != eligibile_plan_year:
                        # step to make sure we don't create duplicate entries
                        if self.check_planyear_exists(e, self.attributes['eligibility']) is False:
                            self.attributes['eligibility'].append(e)
                    elif e['plan_year'] == eligibile_plan_year:
                        orig_elig_planyear = copy.deepcopy(e)

                # Appending the new values for the current year  and checking for cobra user
                primary_eligibility_dict = {'plan_year': eligibile_plan_year,
                                            'coverage_termination_date': self.attributes['coverage_termination_date'],
                                            'coverage_effective_date': self.attributes['coverage_effective_date'],
                                            'benefit_plan_name': self.attributes['benefit_plan_name'],
                                            'coverage_tier_name': self.attributes['coverage_tier_name'],
                                            'cobra_effective_date': '',
                                            'cobra_termination_date': ''}

                try:
                    if 'display_plan_name' in self.attributes:
                        primary_eligibility_dict['display_plan_name'] = self.attributes['display_plan_name']
                except KeyError:
                    pass

                if self.attributes['employment_status'].lower().strip() == 'cobra':
                    primary_eligibility_dict['cobra_effective_date'] = self.attributes['cobra_effective_date']
                    primary_eligibility_dict['cobra_termination_date'] = self.attributes['cobra_termination_date']

                if orig_elig_py is not None:
                    set_a = set(orig_elig_planyear.keys())
                    set_b = set(primary_eligibility_dict.keys())
                    diff_set = set_b - set_a

                    if len(list(diff_set)) != 0:
                        # copy missing elements
                        for elem in list(diff_set):
                            primary_eligibility_dict[elem] = orig_elig_planyear[elem]
                        del orig_elig_planyear
                # check if any attribs are missing

                # step to ensure we do't create duplicates for the same year
                if self.check_planyear_exists(primary_eligibility_dict, self.attributes['eligibility']) is False:
                    self.attributes['eligibility'].append(
                        copy.deepcopy(primary_eligibility_dict))

                # check number of plan years present. remove the oldest plan
                if (len(self.attributes['eligibility']) > self.maxplans):
                    # delete first item from eligibility
                    del(self.attributes['eligibility'][0])

            # update eligibility in att dictionary
            att['eligibility'] = copy.deepcopy(self.attributes['eligibility'])

            # list of fields to be checked if updated for humana incremental eligibility
            hpcols = {'person_code': False, 'last_name': False, 'first_name': False, 'gender': False,
                      'date_of_birth': False, 'home_address_1': False, 'home_address_2': False, 'city': False,
                      'state': False, 'zip': False, 'employment_status': False, 'eligibility': False}
            # if a field from the list of columns changed then update flag for dependent as well

            empcols = ['home_address_1', 'home_address_2', 'city',
                       'state', 'zip', 'employment_status', 'eligibility']
            updatedependentflag = False
            # go through current user attributes and assign them to Truevault's user attributes
            # in case of extra attributes in Truevault, the extra ones are maintained
            # while only updating the information which is received in the employee dependent file

            for v in list(self.attributes.keys()):
                try:
                    # checks if user is registered, then does not update the default options
                    if 'claimed' in att and v in ['reward_option', 'payment_option', 'communication_option']:
                        continue

                    if v == 'personal_phones':
                        att = self.update_phone_numbers(att)
                        continue

                    # check humana field update
                    try:
                        if v in empcols and self.attributes[v] != att[v]:
                            updatedependentflag = True
                    except KeyError:
                        continue

                    if v in hpcols.keys() and self.attributes[v] != att[v] and True not in hpcols.keys():
                        fliptquery = N1QLQuery("select meta().id id from `" +
                                               os.environ['CB_INSTANCE'] +
                                               "` where type='flipt_person_hierarchy' and dep_flipt_person_id=$dfid",
                                               dfid=att['flipt_person_id'])
                        fliptquery.timeout = 3200
                        for fliptqueryrow in self.cb_handle.n1ql_query(fliptquery):
                            empdocid = fliptqueryrow['id']
                            self.cb_handle.mutate_in(
                                empdocid, SD.upsert('hp_eligibility_updated', "Y"))
                            hpcols[v] = True

                    # checks if attribute is dependents
                    if v == 'dependents':
                        # check if currently no dependent and new file has no dependent either
                        if len(self.attributes[v]) == 0 and len(att[v]) == 0:
                            continue

                        # check if currently no dependent but new file has a new dependent
                        elif len(att[v]) == 0 and len(self.attributes[v]) > 0:
                            for dep in self.attributes[v]:
                                print('new dependent added')
                                dep['flipt_person_id'] = str(
                                    self.cb_handle.counter('counterid', delta=1).value)
                                dep['created_at'] = self.current_time
                                dep['updated_at'] = self.current_time

                                if 'account_type' not in dep:  # prep for FD-286/FD-288
                                    dep['account_type'] = 'dependent'

                                # New dependent eligibility updation B2B-880
                                dep['eligibility'] = []
                                dep_eligibility_dict = {'plan_year': eligibile_plan_year,
                                                        'coverage_termination_date': dep['coverage_termination_date'],
                                                        'coverage_effective_date': dep['coverage_effective_date'],
                                                        'benefit_plan_name': self.attributes['benefit_plan_name'],
                                                        'coverage_tier_name': tier_name,
                                                        'cobra_effective_date': '',
                                                        'cobra_termination_date': ''}

                                if 'display_plan_name' in self.attributes['eligibility'][-1]:
                                    dep_eligibility_dict['display_plan_name'] = self.attributes['eligibility'][
                                        -1]['display_plan_name']
                                    dep_eligibility_dict['benefit_plan_name'] = self.attributes['benefit_plan_name']

                                dep['eligibility'].append(dep_eligibility_dict)

                                # Append to attribute
                                att[v].append(dep)
                                new_dependents = True
                                dep_id.append(dep['flipt_person_id'])
                                #print('New Dependents',att[v])
                            continue

                        # new dependent was added in dependent file - update dependents in att
                        elif len(att[v]) < len(self.attributes[v]):
                            dependents = []
                            dep_attrs = ['deductible_remaining', 'out_of_pocket_remaining', 'domain_name',
                                         'individual_out_of_pocket_remaining', 'family_deductible_remaining',
                                         'parent_id', 'parent_user_id', 'home_address_1', 'home_address_2',
                                         'location', 'city', 'state', 'zip', 'locations']

                            for dep in att[v]:
                                dependents.append(dep)

                            # add the new dependent
                            for dep in self.attributes[v]:
                                skip_dep = False
                                for old_deps in dependents:
                                    if (old_deps['last_name'] == dep['last_name'] and
                                            old_deps['first_name'] == dep['first_name']):
                                        skip_dep = True
                                        break

                                if skip_dep is True:
                                    continue

                                if 'account_type' not in dep:  # prep for FD-286/FD-288
                                    dep['account_type'] = 'dependent'

                                dep['flipt_person_id'] = str(
                                    self.cb_handle.counter('counterid', delta=1).value)
                                dep['created_at'] = self.current_time
                                dep['updated_at'] = self.current_time
                                for keys in dep_attrs:
                                    if keys in dependents[-1]:
                                        dep[keys] = dependents[-1][keys]
                                    else:
                                        try:
                                            dep[keys] = self.attributes[keys]
                                        except KeyError:
                                            dep[keys] = ''

                                # New dependent eligibility updation B2B-880
                                dep['eligibility'] = []
                                dep_eligibility_dict = {'plan_year': eligibile_plan_year,
                                                        'coverage_termination_date': dep['coverage_termination_date'],
                                                        'coverage_effective_date': dep['coverage_effective_date'],
                                                        'benefit_plan_name': self.attributes['benefit_plan_name'],
                                                        'coverage_tier_name': tier_name,
                                                        'cobra_effective_date': '',
                                                        'cobra_termination_date': ''}

                                if 'display_plan_name' in self.attributes['eligibility'][-1]:
                                    dep_eligibility_dict['display_plan_name'] = self.attributes['eligibility'][
                                        -1]['display_plan_name']
                                    dep_eligibility_dict['benefit_plan_name'] = self.attributes['benefit_plan_name']

                                dep['eligibility'].append(dep_eligibility_dict)
                                dependents.append(dep)
                                dep_id.append(dep['flipt_person_id'])
                            # end loop

                            att[v] = dependents
                            new_dependents = True

                        # update dependent attributes
                        else:
                            deps_info = pd.DataFrame()
                            deps_info_list = []
                            currentdeps = pd.DataFrame()

                            new_changes = []
                            for dep in self.attributes[v]:
                                temp_dict = {'first_name': dep['first_name'],
                                             'last_name': dep['last_name'],
                                             'dep_ssn': dep['dependent_ssn']}
                                currentdeps = currentdeps.append(
                                    temp_dict, ignore_index=True)
                                new_changes.append(temp_dict)
                            # end loop

                            for idx in range(len(att[v])):
                                record_dict = None
                                dep = att[v][idx]

                                deps_struct = {'index_no': idx,
                                               'fname': dep['first_name'],
                                               'lname': dep['last_name'],
                                               'dob': dep['date_of_birth'],
                                               'person_code': int(dep['person_code'])}

                                # check if the 'email' attribute in dependents are malformed, ie: contains 'mailto:'
                                if 'email' in dep:
                                    import re
                                    if ('mailto:' in dep['email'] or 'mailto: ' in dep['email']):
                                        dep['email'] = re.sub(
                                            'mailto:', '', dep['email'])
                                        dep['email'] = re.sub(
                                            ' ', '', dep['email'])

                                # FD-431: attribute values that are lists should remain as lists
                                if 'humana_health_conditions' in dep:
                                    if isinstance(dep['humana_health_conditions'], str):
                                        # convert json representation to actual type
                                        dep['humana_health_conditions'] = eval(
                                            dep['humana_health_conditions'])

                                # FD-431: attribute values that are lists should remain as lists
                                if 'humana_allergies' in dep:
                                    if isinstance(dep['humana_allergies'], str):
                                        # convert json representation to actual type
                                        dep['humana_allergies'] = eval(
                                            dep['humana_allergies'])

                                # FD-431: attribute values that are lists should remain as lists
                                if 'locations' in dep:
                                    if isinstance(dep['locations'], str):
                                        # convert json representation to actual type
                                        dep['locations'] = eval(
                                            dep['locations'])

                                # FD-431: attribute values that are lists should remain as lists
                                if 'personal_email' in dep:
                                    if isinstance(dep['personal_email'], str):
                                        # convert json representation to actual type
                                        dep['personal_email'] = eval(
                                            dep['personal_email'])

                                # FD-431: attribute values that are lists should remain as lists
                                if 'personal_phones' in dep:
                                    if isinstance(dep['personal_phones'], str):
                                        # convert json representation back to actual type
                                        dep['personal_phones'] = eval(
                                            dep['personal_phones'])

                                if self.attributes['employment_status'].lower().strip() == 'active' and \
                                        'email' in dep:
                                    pln_years = []

                                    for e in range(len(dep['eligibility'])):
                                        pln_years.append(
                                            dep['eligibility'][e]['plan_year'])
                                    # If new year to be appended in dependent user account in Truevault
                                    atr_key = 'eligibility'

                                    # if eligibile_plan_year not in pln_years:
                                    if True:
                                        record_dict = {'domain_name': att['domain_name'],
                                                       'email': dep['email'],
                                                       'flipt_person_id': dep['flipt_person_id'],
                                                       'coverage_tier_name': self.attributes['coverage_tier_name'],
                                                       'benefit_plan_name': self.attributes['benefit_plan_name'],
                                                       'tdate': self.attributes['coverage_termination_date'],
                                                       'cdate': self.attributes['coverage_effective_date'],
                                                       'ctdate': '',
                                                       'cedate': '',
                                                       'emp_status': self.attributes['employment_status'],
                                                       'dependent_ssn': dep.get('dependent_ssn', ''),
                                                       'first_name': dep.get('first_name', ''),
                                                       'last_name': dep.get('last_name', ''),
                                                       'new_firstname': new_changes[idx]['first_name'],
                                                       'new_lastname': new_changes[idx]['last_name'],
                                                       'change_indicator': False,
                                                       'date_of_birth': dep.get('date_of_birth', '')}

                                        try:
                                            if self.attributes['display_plan_name']:
                                                record_dict['display_plan_name'] = self.attributes['display_plan_name']

                                        except KeyError:
                                            pass

                                if self.attributes['employment_status'].lower().strip() in ['terminated', 'cobra'] and \
                                        'email' in dep:
                                    atr_key = 'eligibility'
                                    # Added for eligibility changes B2B-880
                                    if self.attributes['employment_status'].lower().strip() == 'terminated':
                                        # print('Eligibility',self.attributes['eligibility'])
                                        record_dict = {'domain_name': att['domain_name'],
                                                       'email': dep['email'],
                                                       'flipt_person_id': dep['flipt_person_id'],
                                                       'coverage_tier_name': self.attributes['coverage_tier_name'],
                                                       'benefit_plan_name': self.attributes['benefit_plan_name'],
                                                       'tdate': self.attributes['coverage_termination_date'],
                                                       'cdate': self.attributes['coverage_effective_date'],
                                                       'ctdate': '',
                                                       'cedate': '',
                                                       'emp_status': self.attributes['employment_status'],
                                                       'dependent_ssn': dep.get('dependent_ssn', ''),
                                                       'first_name': dep.get('first_name', ''),
                                                       'last_name': dep.get('last_name', ''),
                                                       'new_firstname': '',
                                                       'new_lastname': '',
                                                       'change_indicator': False,
                                                       'date_of_birth': dep.get('date_of_birth', '')}

                                        try:
                                            if self.attributes['display_plan_name']:
                                                record_dict['display_plan_name'] = self.attributes['display_plan_name']
                                        except KeyError:
                                            pass

                                    if self.attributes['employment_status'].lower().strip() == 'cobra':
                                        record_dict = {'domain_name': att['domain_name'],
                                                       'email': dep['email'], 'flipt_person_id': dep['flipt_person_id'],
                                                       'coverage_tier_name': self.attributes['coverage_tier_name'],
                                                       'benefit_plan_name': self.attributes['benefit_plan_name'],
                                                       'tdate': self.attributes['coverage_termination_date'],
                                                       'ctdate': self.attributes['cobra_termination_date'],
                                                       'cdate': self.attributes['coverage_effective_date'],
                                                       'cedate': self.attributes['cobra_effective_date'],
                                                       'emp_status': self.attributes['employment_status'],
                                                       'dependent_ssn': dep.get('dependent_ssn', ''),
                                                       'first_name': dep.get('first_name', ''),
                                                       'last_name': dep.get('last_name', ''),
                                                       'new_firstname': '',
                                                       'new_lastname': '',
                                                       'change_indicator': False,
                                                       'date_of_birth': dep.get('date_of_birth', '')}

                                        try:
                                            if dep['eligibility'][-1]['display_plan_name']:
                                                record_dict['display_plan_name'] = dep['eligibility'][-1][
                                                    'display_plan_name']

                                        except KeyError:
                                            pass

                                    errlog = errlog.\
                                        append({'Domain Name': att['domain_name'],
                                                'Employee ID': att['employee_id'],
                                                'First Name': dep['first_name'],
                                                'Last Name': dep['last_name'],
                                                'Coverage Tier Name': self.attributes[atr_key][-1]['coverage_tier_name'],
                                                'Dependent-Relationship': '',
                                                'Plan Name': self.attributes['benefit_plan_name'],
                                                'Record Message': 'Dependent Coverage Termination ' +
                                                                  'Date Updated (Employee terminated)'},
                                               ignore_index=True)

                                else:  # no email set for the dependents
                                    if ((len(att[v]) == len(currentdeps)) and
                                            (dep['dependent_ssn'] == currentdeps['dep_ssn']).any() == True):
                                        if ((dep['first_name'] != currentdeps['first_name']).any() or
                                                (dep['last_name'] != currentdeps['last_name']).any()):
                                            rec_info = currentdeps.loc[(dep['dependent_ssn'] ==
                                                                        currentdeps['dep_ssn'])]

                                            dep['first_name'] = rec_info['first_name'].values[0]
                                            dep['last_name'] = rec_info['last_name'].values[0]
                                            deps_struct['fname'] = dep['first_name']
                                            deps_struct['lname'] = dep['last_name']

                                            if record_dict is not None:
                                                record_dict['change_indicator'] = True
                                # end - email not set for dependents

                                # if a dependent is no longer present in the new dependent file,
                                # update dependent's coverage termination date to current date
                                # Removed and and added or condition for last name check B2b-880 change
                                if currentdeps.empty or not ((dep['first_name'] == currentdeps['first_name']) &
                                                             (dep['last_name'] == currentdeps['last_name'])).any():
                                    for e in att[v][idx]['eligibility']:
                                        dep_info = att[v][idx]

                                        if ((len(att[v]) == len(currentdeps)) and
                                                (dep['dependent_ssn'] == currentdeps['dep_ssn']).any() == True):
                                            if ((dep['first_name'] != currentdeps['first_name']).any() or
                                                    (dep['last_name'] != currentdeps['last_name']).any()):
                                                rec_info = currentdeps.loc[(dep['dependent_ssn'] ==
                                                                            currentdeps['dep_ssn'])]
                                                # index_val = int(rec_info.index[0])
                                                dep['first_name'] = rec_info['first_name'].values[0]
                                                dep['last_name'] = rec_info['last_name'].values[0]
                                                deps_struct['fname'] = dep['first_name']
                                                deps_struct['lname'] = dep['last_name']

                                                record_dict['change_indicator'] = True
                                                deps_info_list.append(
                                                    deps_struct)
                                                continue
                                        else:
                                            deps_info_list.append(deps_struct)

                                        if e['plan_year'] in [eligibile_plan_year, str(datetime.now().year)]:
                                            if e['coverage_termination_date'] > \
                                                    datetime.strptime(str(datetime.now()),
                                                                      "%Y-%m-%d %H:%M:%S.%f").isoformat():
                                                e['coverage_termination_date'] = \
                                                    datetime.strptime(str(datetime.now()),
                                                                      "%Y-%m-%d %H:%M:%S.%f").isoformat()

                                                if 'email' in dep_info:
                                                    if (record_dict['email'] == dep_info['email']):
                                                        record_dict['emp_status'] = 'Terminated'
                                                        record_dict['tdate'] = e['coverage_termination_date']

                                                        if att['employment_status'].lower().strip() != 'cobra':
                                                            record_dict['ctdate'] = ''
                                                            record_dict['cedate'] = ''
                                                        else:
                                                            record_dict['ctdate'] = e['coverage_termination_date']
                                                            e['cobra_termination_date'] = e['coverage_termination_date']
                                                            att[v][idx]['cobra_termination_date'] = e[
                                                                'coverage_termination_date']
                                                        att[v][idx]['status'] = 'Terminated'
                                                        record_dict['change_indicator'] = False

                                                errlog = errlog.\
                                                    append({'Domain Name': att['domain_name'],
                                                            'Employee ID': att['employee_id'],
                                                            'First Name': dep['first_name'],
                                                            'Last Name': dep['last_name'],
                                                            'Coverage Tier Name': '',
                                                            'Dependent-Relationship': '',
                                                            'Plan Name': '',
                                                            'Record Message': 'Dependent not found in Latest File, ' +
                                                                              'Coverage Termination Date Updated'},
                                                           ignore_index=True)
                                                param_values = terminated_dependent_communication(self.domain_mappings,
                                                                                                  att, dep,
                                                                                                  mode=mode,
                                                                                                  createfl=createfile)
                                                if param_values is not None:
                                                    sendgrid_usrlist.append(
                                                        param_values)
                                    # end loop
                                else:
                                    deps_info_list.append(deps_struct)
                                # end - dep not present or name correction

                                if record_dict is not None:
                                    updatedependent = updatedependent.append(
                                        record_dict, ignore_index=True)
                            # end loop

                            # create pandas frame
                            deps_info = deps_info.append(
                                deps_info_list, ignore_index=True)

                            inc = 1
                            counter = 0
                            atr_key = 'eligibility'
                            for dep in self.attributes[v]:
                                # Modifying the dependent attributes in self.attributes structure B2B-880
                                dep_eligibility_dict = {'plan_year': eligibile_plan_year,
                                                        'coverage_termination_date': dep['coverage_termination_date'],
                                                        'coverage_effective_date': dep['coverage_effective_date'],
                                                        'benefit_plan_name': self.attributes['benefit_plan_name'],
                                                        'coverage_tier_name': tier_name,
                                                        'cobra_effective_date': '',
                                                        'cobra_termination_date': ''}

                                try:
                                    if 'display_plan_name' in self.attributes:
                                        dep_eligibility_dict['display_plan_name'] = self.attributes['display_plan_name']
                                except KeyError:
                                    pass

                                if self.attributes['employment_status'].lower().strip() == 'terminated':
                                    if dep.get('eligibility', []):
                                        dep['eligibility'].append(
                                            copy.deepcopy(dep_eligibility_dict))
                                    else:
                                        dep['eligibility'] = []
                                        dep['eligibility'].append(
                                            copy.deepcopy(dep_eligibility_dict))

                                else:
                                    dep['eligibility'] = []

                                    if self.attributes['employment_status'].lower().strip() == 'cobra':
                                        dep_eligibility_dict['cobra_effective_date'] = dep['cobra_effective_date']
                                        dep_eligibility_dict['cobra_termination_date'] = dep['cobra_termination_date']

                                    else:
                                        dep_eligibility_dict['coverage_effective_date'] = dep['coverage_effective_date']
                                        dep_eligibility_dict['coverage_termination_date'] = dep['coverage_termination_date']

                                    # Remove below fields from dependent list B2B-880
                                    for e in att[v][counter]['eligibility']:
                                        # Appending self .attributes with all the truevault plan years.
                                        if e['plan_year'] != eligibile_plan_year:
                                            # step to make sure we don't create duplicate entries
                                            if self.check_planyear_exists(e, self.attributes[v][counter][
                                                    'eligibility']) is False:
                                                dep['eligibility'].append(e)

                                    dep['eligibility'].append(
                                        copy.deepcopy(dep_eligibility_dict))

                                if ((deps_info['fname'] == dep['first_name']) &
                                    (deps_info['lname'] == dep['last_name']) &
                                        (deps_info['dob'] == dep['date_of_birth'])).any():
                                    index = int(deps_info[(deps_info['fname'] == dep['first_name']) &
                                                          (deps_info['lname'] == dep['last_name']) &
                                                          (deps_info['dob'] == dep['date_of_birth'])][
                                        'index_no'].values[0])

                                    try:
                                        updatedepindex = updatedependent[(updatedependent['first_name'] ==
                                                                          dep['first_name']) &
                                                                         (updatedependent['last_name'] ==
                                                                          dep['last_name']) &
                                                                         (updatedependent['date_of_birth'] ==
                                                                          dep['date_of_birth'])].index[0]
                                    except:
                                        updatedepindex = -1

                                    # list of fields to be checked if updated for humana incremental eligibility
                                    hpcols1 = {'person_code': False,
                                               'last_name': False,
                                               'first_name': False,
                                               'gender': False,
                                               'date_of_birth': False,
                                               'eligibility': False}

                                    update_eligibility = False
                                    pln_years = []
                                    for dep_v in dep:
                                        try:
                                            orig_value = att[v][index][dep_v]
                                        except KeyError:
                                            try:
                                                orig_value = self.attributes[dep_v]
                                            except KeyError:
                                                pass
                                                continue

                                        if dep_v == 'eligibility':
                                            for i in range(len(orig_value)):
                                                pln_years.append(
                                                    orig_value[i]['plan_year'])
                                                if orig_value[i]['plan_year'] == eligibile_plan_year:
                                                    orig_value[i] = dep[dep_v][i]
                                            # If new year
                                            if eligibile_plan_year not in pln_years:
                                                orig_value.append(
                                                    dep[dep_v][i+1])

                                            # remove oldest plan year
                                            if (len(orig_value) > self.maxplans):
                                                del(orig_value[0])

                                            att[v][index][dep_v] = orig_value
                                            e = list(filter(lambda x: x['plan_year'] == eligibile_plan_year,
                                                            att[v][index][dep_v]))
                                            if e and updatedepindex >= 0:
                                                e = e[0]
                                                updatedependent.loc[updatedepindex,
                                                                    'cdate'] = e['coverage_effective_date']
                                                updatedependent.loc[updatedepindex,
                                                                    'tdate'] = e['coverage_termination_date']
                                                updatedependent.loc[updatedepindex,
                                                                    'cedate'] = e['cobra_effective_date']
                                                updatedependent.loc[updatedepindex,
                                                                    'ctdate'] = e['cobra_termination_date']
                                        else:
                                            if isinstance(dep[dep_v], str):
                                                att[v][index][dep_v] = str(
                                                    dep[dep_v])
                                            else:
                                                att[v][index][dep_v] = dep[dep_v]

                                        # check humana field update for dependent
                                        if (dep_v in hpcols and orig_value != str(
                                                dep[dep_v]) and False not in hpcols1) or updatedependentflag is True:
                                            fliptquery = N1QLQuery("select meta().id id from `" +
                                                                   os.environ['CB_INSTANCE'] +
                                                                   "` where type='flipt_person_hierarchy' " +
                                                                   "and dep_flipt_person_id=$dfid",
                                                                   dfid=att[v][index]['flipt_person_id'])
                                            fliptquery.timeout = 3200
                                            for fliptqueryrow in self.cb_handle.n1ql_query(fliptquery):
                                                depdocid = fliptqueryrow['id']
                                                self.cb_handle.mutate_in(depdocid,
                                                                         SD.upsert('hp_eligibility_updated', "Y"))
                                                hpcols1[dep_v] = True

                                    att[v][index]['updated_at'] = datetime.strptime(
                                        str(datetime.now()), "%Y-%m-%d %H:%M:%S.%f").isoformat()

                                else:
                                    pc = max(
                                        list(deps_info['person_code'])) + inc
                                    dep['person_code'] = str(int(pc)).zfill(2)
                                    inc = inc + 1
                                    att[v].append(dep)
                                    dep['flipt_person_id'] = str(
                                        self.cb_handle.counter('counterid', delta=1).value)
                                    dep['created_at'] = self.current_time
                                    dep['updated_at'] = self.current_time
                                    new_dependents = True
                                    dep_id.append(dep['flipt_person_id'])

                                # dependents index counter
                                counter += 1
                                continue
                        continue

                    # if v is 'locations'
                    if v == 'locations':
                        if len(att[v]) != 0:
                            continue

                    att[v] = self.attributes[v]
                except Exception as e:
                    type, value, etraceback = sys.exc_info()
                    error = ''
                    x = traceback.format_exception(type, value, etraceback)
                    print(f"Record not updated for: {att}")
                    for i in x:
                        error = error + i
                    print('Error while looping through self.attributes :: ', error)

                    continue

            att = self.remove_attributes(att)
            if fileComp is not None:
                fileComp.append(att, 'post')

            try:
                # pdb.set_trace()
                if mode.lower() == 'final':
                    new_att = base64.b64encode(str.encode(json.dumps(att)))
                    print(f"Updating to TrueVault in {mode} mode")
                    if log_hndl is not None:
                        log_hndl.debug(
                            f"Updating truevault in {mode} mode: {pformat(att)}")

                    data = {'attributes': new_att,
                            'username': self.attributes['work_email']}
                    # update user attributes to truevault

                    user_updated = {'Domain Name': att['domain_name'],
                                    'First Name': att['first_name'],
                                    'Last Name': att['last_name'],
                                    'Flipt Person ID': att['flipt_person_id'],
                                    'Record Message': "User updated"}

                    if 'UID' in self.attributes:
                        user_updated['UID'] = att['employee_id']
                    else:
                        user_updated['Employee ID'] = att['employee_id']

                    r = requests.put('https://api.truevault.com/v1/users/%s' % str(userid),
                                     auth=HTTPBasicAuth(self.api_key, ''),
                                     data=data)
                    emperrlog = emperrlog.append(
                        user_updated, ignore_index=True)
                    # Novartis changes
                    flipt_person_id_map.update(
                        {att.get('employee_ssn', ''): att['flipt_person_id']})
                    for dep in att['dependents']:
                        flipt_person_id_map.update(
                            {dep.get('dependent_ssn', ''): dep['flipt_person_id']})
                else:
                    print(
                        f"Updated user attribute {mode} mode: {pformat(att)}")
                    if log_hndl is not None:
                        log_hndl.debug(
                            f"Mock update of user attributes in {mode} mode:\n {pformat(att)}")
            except Exception as e:
                type, value, etraceback = sys.exc_info()
                error = ''
                x = traceback.format_exception(type, value, etraceback)
                for i in x:
                    error += i
                print(
                    f'Error while sending data to Truevault for user id {str(userid)}. Error is {error}')
                if log_hndl is not None:
                    log_hndl.debug(f"Error updating truevault in {mode} mode.")
                Empid = ''
                uname = ''
                if 'work_email' in self.attributes:
                    uname = self.attributes['work_email'].lower()

                if 'employee_id' in att:
                    Empid = att['employee_id']

                emperrlog = emperrlog.\
                    append({'Domain Name': att['domain_name'],
                            'Username': uname,
                            'Employee ID': Empid,
                            'Record Message': error},
                           ignore_index=True)
                return (errlog, emperrlog, sendgrid_usrlist, flipt_person_id_map)

            try:
                # insert record into flipt_person_hierarchy for a new dependent
                if new_dependents is True and testacc is False:
                    flipt_ids = {}
                    if mode.lower() == 'final':
                        for dep in dep_id:
                            x = {}
                            x['emp_flipt_person_id'] = att['flipt_person_id']
                            x['dep_flipt_person_id'] = dep
                            x['domain_name'] = att['domain_name']
                            x['created_at'] = self.current_time
                            x['updated_at'] = self.current_time
                            x['hp_eligibility_updated'] = 'Y'
                            x['sc_extracted_date'] = ''
                            x['type'] = 'flipt_person_hierarchy'
                            self.cb_handle.upsert(str(self.cb_handle.counter('docid', delta=1).value),
                                                  x,
                                                  format=FMT_JSON)

                # update independent registered dependent accounts with coverage termination date
                del att1
                if not updatedependent.empty:
                   
                    for i, update_row in updatedependent.iterrows():
                        # print(r)
                        search_option = self.set_search_option('dependent', dict(update_row), log_hndl)
                        dep_att, userid = self.search_tvuser(search_option)
                        if userid is None:
                            search_option = self.set_search_option('dependent', dict(update_row),
                                                                   log_hndl, search_param='name_dob')
                            dep_att, userid = self.search_tvuser(search_option)

                        eligibile_plan_year = str(parser.parse(update_row['tdate']).year)
                        plan_years = []
                        # print('Attribute dep',att)
                        # print('userid',userid)

                        if dep_att is not None:
                            if fileComp is not None:
                                fileComp.append(dep_att, 'pre')

                            if mode.lower() == 'draft':
                                print("Original dep record: \n" +
                                      pformat(dep_att))
                                if log_hndl is not None:
                                    log_hndl.info(
                                        'Original dep record before change:\n ' + pformat(dep_att))

                            for e in range(len(dep_att['eligibility'])):
                                # Append all plan years
                                plan_years.append(
                                    dep_att['eligibility'][e]['plan_year'])

                            if eligibile_plan_year not in plan_years:
                                # New plan year has to be added in case of cobra or Active
                                if r['emp_status'].lower().strip() == 'active':
                                    dep_update = {'plan_year': eligibile_plan_year,
                                                  'coverage_termination_date': update_row['tdate'],
                                                  'coverage_effective_date': update_row['cdate'],
                                                  'coverage_tier_name': update_row['coverage_tier_name'],
                                                  'benefit_plan_name': self.attributes['benefit_plan_name'],
                                                  'cobra_effective_date': '',
                                                  'cobra_termination_date': ''}

                                    try:
                                        if update_row['display_plan_name']:
                                            dep_update['display_plan_name'] = update_row['display_plan_name']
                                    except KeyError:
                                        pass

                                    dep_att['eligibility'].append(dep_update)

                                    # check if we are with maxplans in the dependent
                                    if (len(dep_att['eligibility']) > self.maxplans):
                                        # remove oldest plan year
                                        del (dep_att['eligibility'][0])

                                else:
                                    # Cobra
                                    if update_row['ctdate'] > datetime.strptime(str(datetime.now()),
                                                                       "%Y-%m-%d %H:%M:%S.%f").isoformat():
                                        dep_att['active'] = True
                                        dep_update = {'plan_year': eligibile_plan_year,
                                                      'coverage_termination_date': update_row['tdate'],
                                                      'coverage_effective_date': update_row['cdate'],
                                                      'coverage_tier_name': update_row['coverage_tier_name'],
                                                      'benefit_plan_name': self.attributes['benefit_plan_name'],
                                                      'cobra_effective_date': update_row['cedate'],
                                                      'cobra_termination_date': update_row['ctdate']}
                                        try:
                                            if update_row['display_plan_name']:
                                                dep_update['display_plan_name'] = update_row['display_plan_name']
                                        except KeyError:
                                            pass

                                        dep_att['eligibility'].append(
                                            dep_update)

                                        # check if we are with maxplans in the dependent
                                        if (len(dep_att['eligibility']) > self.maxplans):
                                            # remove oldest plan year
                                            del (dep_att['eligibility'][0])
                                # end cobra decision
                            else:
                                for idx, e in enumerate(dep_att['eligibility']):
                                    if e['plan_year'] == eligibile_plan_year:
                                        if update_row['emp_status'].lower().strip() == 'terminated':
                                            dep_att['eligibility'][idx]['coverage_termination_date'] = update_row['tdate']

                                        elif update_row['emp_status'].lower().strip() == 'cobra':
                                            dep_att['eligibility'][idx]['coverage_effective_date'] = update_row['cdate']
                                            dep_att['eligibility'][idx]['coverage_termination_date'] = update_row['tdate']
                                            dep_att['eligibility'][idx]['benefit_plan_name'] = self.attributes[
                                                'benefit_plan_name']
                                            dep_att['eligibility'][idx]['cobra_effective_date'] = update_row['cedate']
                                            dep_att['eligibility'][idx]['cobra_termination_date'] = update_row['ctdate']
                                            if update_row['ctdate'] > datetime.strptime(str(datetime.now()),
                                                                               "%Y-%m-%d %H:%M:%S.%f").isoformat():
                                                dep_att['active'] = True
                                        else:
                                            dep_att['eligibility'][idx]['benefit_plan_name'] = self.attributes[
                                                'benefit_plan_name']
                                            dep_att['eligibility'][idx]['coverage_effective_date'] = update_row['cdate']
                                            dep_att['eligibility'][idx]['coverage_termination_date'] = update_row['tdate']
                                            dep_att['eligibility'][idx]['coverage_tier_name'] = update_row['coverage_tier_name']

                            # if the change indicator is set
                            if update_row['change_indicator'] is True:
                                if dep_att['first_name'] != update_row['new_firstname']:
                                    dep_att['first_name'] = update_row['new_firstname']

                                if dep_att['last_name'] != update_row['new_lastname']:
                                    dep_att['last_name'] = update_row['new_lastname']

                                if dep_att['dependent_ssn'] != update_row['dependent_ssn']:
                                    dep_att['dependent_ssn'] = update_row['dependent_ssn']

                            dep_att = self.remove_attributes(dep_att)

                            new_dep_att = base64.b64encode(
                                str.encode(json.dumps(dep_att)))
                            data = {'attributes': new_dep_att}
                            if fileComp is not None:
                                fileComp.append(dep_att, 'post')

                            if mode.lower() == 'final':
                                print('Dependent Attributes', dep_att)
                                if log_hndl is not None:
                                    log_hndl.debug(
                                        f"Dependent truevault in {mode} mode:\n {pformat(dep_att)}")
                                response = requests.put('https://api.truevault.com/v1/users/%s' % str(userid),
                                                        auth=HTTPBasicAuth(
                                                            self.api_key, ''),
                                                        data=data)
                            else:
                                print('Dependent attribute change - Draft mode')
                                print(pformat(dep_att))
                                if log_hndl is not None:
                                    log_hndl.debug(
                                        f"Dependent truevault in {mode} mode:\n {pformat(dep_att)}")
                        else:
                            if log_hndl is not None:
                                log_hndl.error(
                                    f"Dependent record for email < {r['email']} > no longer present in TrueVault.")
                            print(
                                f"Dependent record: {r['email']} not updated because it doesnt exist!!")
                        # dependent record doesnt exist
            except Exception as e:
                type, value, etraceback = sys.exc_info()
                error = ''
                x = traceback.format_exception(type, value, etraceback)
                for i in x:
                    error = error + i

                print(
                    'Error while updating dep/cobra termination date. Error is: ' + error)
                Empid = ''
                uname = ''
                if 'work_email' in self.attributes:
                    uname = self.attributes['work_email'].lower()

                if 'employee_id' in att:
                    Empid = att['employee_id']

                emperrlog = emperrlog.\
                    append({'Domain Name': att['domain_name'],
                            'Username': uname,
                            'Employee ID': Empid,
                            'Record Message': error},
                           ignore_index=True)
                return (errlog, emperrlog, sendgrid_usrlist, flipt_person_id_map)

            print('Insert/Update Completed')
            return (errlog, emperrlog, sendgrid_usrlist, flipt_person_id_map)
        except Exception as e:
            type, value, etraceback = sys.exc_info()
            error = ''
            x = traceback.format_exception(type, value, etraceback)
            for i in x:
                error = error + i
            print(
                'Error while sending data to Truevault for new user. Error is :: ' + error)
            Empid = ''
            uname = ''
            if 'work_email' in self.attributes:
                uname = self.attributes['work_email'].lower()
            if 'employee_id' in att:
                Empid = att['employee_id']

            emperrlog = emperrlog.\
                append({'Domain Name': att['domain_name'],
                        'Username': uname,
                        'Employee ID': Empid,
                        'Record Message': error},
                       ignore_index=True)
            return (errlog, emperrlog, sendgrid_usrlist, flipt_person_id_map)
    # end method

    def remove_attributes(self, attr_set):
        remove_list = ['coverage_termination_date', 'coverage_effective_date',
                       'benefit_plan_name', 'coverage_tier_name', 'status',
                       'cobra_effective_date', 'cobra_termination_date', 'plan_year']

        if 'display_plan_name' in self.attributes:
            remove_list.append('display_plan_name')

        for key in remove_list:
            try:
                attr_set.pop(key, '')
            except:
                pass

        for index, dep in enumerate(attr_set.get('dependents', [])):
            for key in remove_list:
                try:
                    attr_set['dependents'][index].pop(key, '')
                except:
                    pass

        return attr_set
    # end function

    # updates active status on terminated employee and returns entire list of users in truevault with their attributes

    def update_active_status(self, plan_year):
        try:
            r = requests.get('https://api.truevault.com/v1/users',
                             auth=HTTPBasicAuth(self.api_key, ''))
            df = pd.DataFrame()
            response = r.json()
            # test_user =[{'access_key': None, 'account_id': 'ea9f55e2-56d8-4afa-96be-48c990ba680c',
            # 'id': 'f71ecfd1-48e5-464a-8970-462a11000ada', 'status': 'ACTIVATED',
            # 'user_id': 'f71ecfd1-48e5-464a-8970-462a11000ada', 'username': 'scotttiger@fliptrx.com'}]
            for i in response['users']:
                # for i in test_user:
                search_option = {'full_document': True,
                                 'filter':
                                     {'$tv.username':
                                      {'type': 'eq',
                                       'value': i['username'],
                                       'case_sensitive': False
                                       },
                                      '$tv.status':
                                          {'type': 'eq',
                                           'value': 'ACTIVATED'
                                           }
                                      },
                                 'filter_type': 'and'}
                att, uid = self.search_tvuser(search_option)
                if att is not None:
                    # B2B-880 change
                    # print('Attributes',att)
                    if 'eligibility' in att:
                        for e in att['eligibility']:
                            #e_plan_year = datetime.now().year
                            e_plan_year = plan_year

                            if e['plan_year'] == e_plan_year:
                                print('elig plan yr', e['plan_year'])
                                if e['coverage_termination_date'] < datetime.strptime(str(datetime.now()),
                                                                                      "%Y-%m-%d %H:%M:%S.%f").isoformat():
                                    # print(e['coverage_termination_date'])
                                    att['active'] = False
                                    #print('Active changed to false')
                                    data = {'attributes': att}
                                    r = requests.put('https://api.truevault.com/v1/users/%s' % str(uid),
                                                     auth=HTTPBasicAuth(
                                                         self.api_key, ''),
                                                     data=data)
                                    break
                                else:
                                    att['active'] = True
                                    # print('Active changed to true')
                                    data = {'attributes': att}
                                    r = requests.put('https://api.truevault.com/v1/users/%s' % str(uid),
                                                     auth=HTTPBasicAuth(
                                                         self.api_key, ''),
                                                     data=data)
                        ud = ''
                        if 'updated_at' in att:
                            ud = att['updated_at']
                        df = df.append({'Username': i['username'],
                                        'Attributes': att,
                                        'Update Date': ud},
                                       ignore_index=True)
                        # print('Active status',df)
                        # break
            df.sort_values(by=['Update Date'], inplace=True)
            return df
        except Exception as e:
            type, value, etraceback = sys.exc_info()
            error = ''
            x = traceback.format_exception(type, value, etraceback)
            for i in x:
                error = error+i
            print('Error in update active status function.Error is: ' + error)
            return df
    # end method

    def update_phone_numbers(self, att):

        stored_phones = [i['phone_number'] for i in att['personal_phones']]
        phone_numbers_received = [(index, i['phone_number'])
                                  for index, i in enumerate(self.attributes['personal_phones'])]

        for i in phone_numbers_received:
            if i[1] not in stored_phones:
                att['personal_phones'].append(
                    self.attributes['personal_phones'][i[0]])

        return att
# end function

    def send_email(self, userid):
        user_id = userid
        headers = {'Content-Type': 'application/json'}
        data = {
            "provider": "SENDGRID",
            "auth": {"sendgrid_api_key": os.environ['SENDGRID_API_KEY']},
            "template_id": "f21152e7-3b48-4e76-8173-beb033e14f54",
            "from_email_address": {"literal_value": "care@fliptrx.com"},
            "to_email_address": {"user_attribute": "work_email"},
            "substitutions": {
                ":username": {"user_attribute": "first_name"},
                ":password": {"literal_value": self.password},
            }
        }
        r = requests.post('https://api.truevault.com/v1/users/%s/message/email' % user_id,
                          headers=headers,
                          auth=HTTPBasicAuth(self.api_key, ''),
                          data=json.dumps(data))
        # print(r.status_code)
        return r.status_code
    # end method

    def create_user_schema(self):
        userschema = {"name": "userschema",
                      "fields": [
                          {
                              "name": "domain_name",
                              "index": True,
                              "type": "string"
                          },
                          {
                              "name": "first_name",
                              "index": True,
                              "type": "string"
                          },
                          {
                              "name": "last_name",
                              "index": True,
                              "type": "string"
                          },
                          {
                              "name": "date_of_birth",
                              "index": True,
                              "type": "string"
                          },
                          {
                              "name": "employee_id",
                              "index": True,
                              "type": "string"
                          },
                          {
                              "name": "employee_ssn",
                              "index": True,
                              "type": "string"
                          },
                          {
                              "name": "dependents.dependent_ssn",
                              "index": True,
                              "type": "string"
                          },
                          {
                              "name": "dependents.first_name",
                              "index": True,
                              "type": "string"
                          },
                          {
                              "name": "dependents.last_name",
                              "index": True,
                              "type": "string"
                          },
                          {
                              "name": "flipt_person_id",
                              "index": True,
                              "type": "string"
                          },
                          {
                              "name": "coverage_termination_date",
                              "index": True,
                              "type": "string"
                          },
                          {
                              "name": "active",
                              "index": True,
                              "type": "boolean"
                          },
                          {
                              "name": "fliptapikey",
                              "index": True,
                              "type": "string"
                          },
                          {
                              "name": "dependent_ssn",
                              "index": True,
                              "type": "string"
                          },
                          {
                              "name": "tpa_member_id",
                              "index": True,
                              "type": "string"
                          },
                          {
                              "name": "family_tpa_member_id",
                              "index": True,
                              "type": "string"}
                      ]
                      }

        uschema = base64.b64encode(str.encode(json.dumps(userschema)))
        data = {'schema': uschema}
        acc_id = '98a031fd-049e-4388-831a-982cf1838d1f'
        r = requests.put('https://api.truevault.com/v1/accounts/%s/user_schema' % acc_id,
                         auth=HTTPBasicAuth(self.api_key, ''),
                         data=data)
    # end method

    def update_user_schema(self, field, datatype):

        # acc_id='ea9f55e2-56d8-4afa-96be-48c990ba680c'
        acc_id = '98a031fd-049e-4388-831a-982cf1838d1f'

        r = requests.get('https://api.truevault.com/v1/accounts/%s/user_schema' % acc_id,
                         auth=HTTPBasicAuth(self.api_key, ''))
        userschema = r.json().get('user_schema', {})
        if not userschema:
            print('user schema not found')
            exit()
        for i in userschema['fields']:
            if i['name'] == field:
                print('field already present in schema')
                exit()

        userschema['fields'].append({"name": field,
                                     "index": True,
                                     "type": datatype})
        userschema['name'] = 'userschema'
        uschema = base64.b64encode(str.encode(json.dumps(userschema)))
        data = {'schema': uschema}
        r = requests.put('https://api.truevault.com/v1/accounts/%s/user_schema' % acc_id,
                         auth=HTTPBasicAuth(self.api_key, ''),
                         data=data)

    def delete_user(self):
        df = pd.DataFrame()
        r = requests.get('https://api.truevault.com/v1/users',
                         auth=HTTPBasicAuth(self.api_key, ''))
        response = r.json()
        for i in response['users']:
            if i['user_id'] == 'f6a6144c-1552-4849-b99d-afe4175ec6f8':
                print(i['username'])
        '''
        response=r.json()
        df=pd.read_excel('del_users.xlsx')
        for i in response['users']:
            if i['username'] in list(df['TrueVault User namer']):
                er_id=i['user_id']
                att=base64.b64encode(str.encode(json.dumps({})))
                data={'username':i['username']+'change','attributes':att}
                print(data['username'])
                r1=requests.put('https://api.truevault.com/v1/users/%s' % er_id, 
                                auth=HTTPBasicAuth(self.api_key, ''),
                                data=data)
                r2=requests.delete('https://api.truevault.com/v1/users/%s' %er_id, 
                                auth=HTTPBasicAuth(self.api_key, ''))
        '''
