
import pandas as pd
import os
import sys
import traceback
from datetime import datetime
from couchbase.n1ql import N1QLQuery
import couchbase.subdocument as SD
from utils.helper_functions import *
from utils.sendgridemail import email_log
from utils.truevault import User_Class

def update_ins_carrier_details(cb_handle, empdata, mode='FINAL'):
    
    path = os.environ['CB_DATA']
    bucket_name = os.environ['CB_INSTANCE']
    obj = User_Class(None, None, cb_handle=cb_handle)
    current_time = datetime.strptime(str(datetime.now()), "%Y-%m-%d %H:%M:%S.%f").isoformat()
    currentdate = datetime.now().strftime("%m%d%y%H%M%S")
    #print('Input ',empdata)
    log = f"{path}/{empdata['domain_name']}/employee/log/Ins_member_update {currentdate}.txt"
    logfile = open(log, "w")
    try:
        #Truevault call
        search_option = {'full_document': True,
                         'filter': {'$tv.username':
                                        {'type': 'eq',
                                         'value': empdata['work_email'],
                                         'case_sensitive': False},
                                    'domain_name':
                                        {'type': 'eq',
                                         'value': empdata['domain_name'],
                                         'case_sensitive': False},
                                    '$tv.status':
                                        {'type': 'eq',
                                         'value': 'ACTIVATED'}
                                    },
                         'filter_type': 'and'}
        att, uid = obj.search_user(search_option)

        if att is not None:
            emp_flipt_person_id = att['flipt_person_id']
            carrier = [{'ins_carrier_name': empdata['domain_name'],
                        'ins_carrier_member_id': str(empdata['employee_id']),
                        'ins_relationship_code': '01',
                        'coverage_tier_name': str(att['eligibility'][-1]['coverage_tier_name']),
                        'benefit_plan_name': str(att['eligibility'][-1]['benefit_plan_name']),
                        'group_number':'865944'}]

            if mode.lower() == 'final':
                query = N1QLQuery('Select meta().id,dep_flipt_person_id from `' +
                                  bucket_name + '`where type="flipt_person_hierarchy" ' +
                                  'and dep_flipt_person_id=$fid',
                                  fid=str(emp_flipt_person_id))

                #Updating ins_carrier details of employee
                for qres in cb_handle.n1ql_query(query):
                    cb_handle.mutate_in(qres['id'], SD.upsert('ins_carrier', carrier))
                    cb_handle.mutate_in(qres['id'], SD.upsert('updated_at', current_time))
                    logfile.write(str(carrier) + '\n')

                    #Loop through dependents in Truevault
                    deps_info = pd.DataFrame()
                    for i in range(len(att['dependents'])):
                        dep = att['dependents'][i]

                        deps_info = deps_info.append(
                            {'index_no': i, 'fname': dep['first_name'], 'lname': dep['last_name'],
                            'dob': dep['date_of_birth'], 'person_code': int(dep['person_code'])}, ignore_index=True)

                    for dep_file in empdata['dependents']:

                        if ((deps_info['fname'] == dep_file['first_name']) &
                            (deps_info['lname'] == dep_file['last_name']) &
                            (deps_info['dob'] == dep_file['date_of_birth'])).any():
                            index = int(deps_info[(deps_info['fname'] == dep_file['first_name'])
                                                      & (deps_info['lname'] == dep_file['last_name'])
                                                      & (deps_info['dob'] == dep_file['date_of_birth'])][
                                                'index_no'].values[0])
                            print('Index',index)
                            print('UID', empdata['dependents'][index]['UID'])

                            carrier = [{'ins_carrier_name': empdata['domain_name'],
                                      'ins_carrier_member_id': str(empdata['dependents'][index]['UID']),
                                      'ins_relationship_code': empdata['dependents'][index]['person_code'],
                                      'coverage_tier_name': str(att['eligibility'][0]['coverage_tier_name']),
                                      'benefit_plan_name':str(att['eligibility'][0]['benefit_plan_name']),
                                      'group_number':'865944'}]

                            fliptquery = N1QLQuery("select meta().id id from `" +
                                                   os.environ['CB_INSTANCE'] +
                                                   "` where type='flipt_person_hierarchy' " +
                                                   "and dep_flipt_person_id=$dfid",
                                                   dfid=att['dependents'][index]['flipt_person_id'])
                            fliptquery.timeout = 3200
                            for fliptqueryrow in cb_handle.n1ql_query(fliptquery):
                                cb_handle.mutate_in(fliptqueryrow['id'], SD.upsert('ins_carrier', carrier))
                                cb_handle.mutate_in(fliptqueryrow['id'], SD.upsert('updated_at', current_time))
                                logfile.write(str(carrier) + '\n')

            print('INS Carrier member id update completed')
            status = "Success"
        else:
            status = "Update Failed.TrueVault Attributes not available for this member"
            print('TrueVault Attributes not available for this member')
            logfile.write('Truevault Details Not Available for user %s. \n' %str(empdata['work_email']))
        
        email_log('noreply@fliptrx.com', 'FliptIntegration@fliptrx.com',
                  None,
                  'INS Member ID Update Process Completed',
                  ['Processing of Employee-Dependent files for INS Carrier Update ',
                   'Ins Carrier Update Exception'], log, True)
        logfile.close()
        return status
    except Exception as e:
        type, value, etraceback = sys.exc_info()
        error = ''
        x = traceback.format_exception(type, value, etraceback)
        for i in x:
            error = error + i
        print('Error while sending data to Truevault for new user. Error is :: ' + error)
        return error
# end function
