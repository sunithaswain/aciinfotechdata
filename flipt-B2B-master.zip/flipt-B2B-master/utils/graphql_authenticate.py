
def graphql_connect(userid, log_hndl=None):
    import base64
    import json
    import os
    import socket
    from types import SimpleNamespace as Namespace

    import requests

    url = os.environ['GRAPHQL_URL']
    host = socket.gethostname()
    mheaders = {'User-Agent': 'FliptIntegration'}

    try:
        if log_hndl is not None:
            log_hndl.debug("Logging into GRAPH QL as a Bot User")
        mutation = """mutation {signIn(email: """ + '"' + os.environ['BOTUSERID'] + '"' + """, password: """ + '"' + \
                   os.environ['BOTPWD'] + '"' + """) {access_token}}"""

        signInrequest = requests.post(url, json={'query': mutation}, headers=mheaders)
        decoded = json.loads(signInrequest.text, object_hook=lambda d: Namespace(**d))
        token = decoded.data.signIn.access_token
        token = token + ':'
        b64Val = base64.b64encode(bytes(token, 'utf-8'))
        header = "Basic " + str(b64Val).lstrip('b')
        headers = {'Authorization': header,
                   'User-Agent': 'FliptIntegration'}

        user_id = '"' + userid + '"'
        if log_hndl is not None:
            log_hndl.debug("Getting the user token after logging as bot")

        query = 'query {getUserToken(user_id: ' + user_id + ')}'
        tokenrequest = requests.post(url, json={'query': query}, headers=headers)
        decoded = json.loads(tokenrequest.text, object_hook=lambda d: Namespace(**d))
        token = decoded.data.getUserToken
        token = token + ':'
        b64Val = base64.b64encode(bytes(token, 'utf-8'))
        header = "Basic " + str(b64Val).lstrip('b')
        headers = {'Authorization': header,
                   'User-Agent': 'FliptIntegration'}
    except:
        if log_hndl is not None:
            log_hndl.debug("Error connecting with graphql")
        return None
    return headers
# end function