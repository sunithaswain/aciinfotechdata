# using SendGrid's Python Library
# https://github.com/sendgrid/sendgrid-python
import sendgrid
import os
from sendgrid.helpers.mail import Email, Content, Attachment, Substitution, Mail, Personalization
import urllib.request as urllib
import base64
from datetime import datetime

import ssl
try:
	# to avoid SSL verification. do a pip3 install certifi and comment out lines (10-18)
    _create_unverified_https_context = ssl._create_unverified_context
except AttributeError:
    # Legacy Python that doesn’t verify HTTPS certificates by default
    pass
else:
    # Handle target environment that doesn’t support HTTPS verification
    ssl._create_default_https_context = _create_unverified_https_context

def setdefault_maillist(recipient, recipient_lst, override_check=None):
    hostname = os.environ['INSTANCE_TYPE']

    if (override_check is not None and override_check == 'Y'):
       return hostname, recipient, recipient_lst

    if hostname not in ('PROD'):
        recipient = 'fliptintegration@fliptrx.com'
        recipient_lst = 'developers@fliptrx.com'
    return hostname, recipient, recipient_lst
# end function


def email_log(sender, receiver1, receivers, subject_, body, file_path, type=None,
              errors=None, attached=True):
	sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))
	hostname, receiver1, receivers = setdefault_maillist(receiver1, receivers)

	sender = 'noreply@fliptrx.com'
	from_email = Email(sender)
	to_email = Email(receiver1)
	subject = hostname + ':' + subject_

	if len(body) == 1:
		content_ = 'Dear Admin Team,<br><br> ' + body[0] + ' has started at ' + str(datetime.now()) +\
                    '. We will send you a log file as soon as processing is completed. ' +\
                    'Please review the log file as soon as you receive them for exceptions and ' +\
               				 'take appropriate actions.\n \n Best regards,\n FLIPT Integration Team'
	else:
		content_ = 'Dear Admin Team,<br><br> ' + body[0] + ' is completed at ' + str(datetime.now()) +\
                    '.<br><br> Please review the attached log file for exceptions and take appropriate actions.<br><br>'

	if errors is not None:
		content_ += errors + "<br>"

	if errors is not None:
		content_ += "\n\n" + errors + "\n\n"

	if type is None:
		content_ += '<br>Also run Couchbase ' + body[1] + ' SQL to find more information.<br><br>' +\
                    'Best regards,<br> FLIPT Integration Team'
	elif type == 'eligibility':
		content_ += "<br>Best regards,<br><strong>FLIPT Integration Team</strong>"

	content = Content("text/html charset=UTF-8", content_)
	mail = Mail(from_email, subject, to_email, content)
	p = Personalization()
	p.add_to(to_email)

	if attached is True:
		with open(file_path, 'rb') as f:
			data = f.read()
			f.close()
			encoded = base64.b64encode(data).decode()
			attachment = Attachment()
			attachment.content = encoded
			attachment.type = "application/pdf"
			attachment.filename = file_path.split('/')[-1]
			attachment.disposition = "attachment"
			attachment.content_id = "Example Content ID"
			mail.add_attachment(attachment)

	mail.add_personalization(p)
	if receivers is not None:
		receiver2 = receivers.split(',')
		for i in receiver2:        
			mail.personalizations[0].add_bcc(Email(i))

	try:
		req = sg.client.mail.send.post(request_body=mail.get())
		if req.status_code == 202:
			stat_msg = 'Accepted'
		return stat_msg
	except:
		print("could not send email")
		pass
# end function


def email_log_custom(sender, receiver1, receivers, subject_, body, file_path, attached=True):


	hostname, receiver1, receivers = setdefault_maillist(receiver1, receivers)

	sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))

	sender = 'noreply@fliptrx.com'
	from_email = Email(sender)
	to_email = Email(receiver1)
	subject = hostname+':'+subject_

	content_ = 'Dear Admin Team,<br><br> ' + body[0] + \
            ' <br><br>Best regards,<br><strong>FLIPT Integration Team</strong'

	content = Content("text/html charset=UTF-8", content_)
	mail = Mail(from_email, subject, to_email, content)
	p = Personalization()
	p.add_to(to_email)

	if attached is True:
		with open(file_path, 'rb') as f:
			data = f.read()
			f.close()
			encoded = base64.b64encode(data).decode()
			attachment = Attachment()
			attachment.content = encoded
			attachment.type = "application/pdf"
			attachment.filename = file_path.split('/')[-1]
			attachment.disposition = "attachment"
			attachment.content_id = "Example Content ID"
			mail.add_attachment(attachment)

	mail.add_personalization(p)
	if receivers is not None:
		receiver2 = receivers.split(',')
		for i in receiver2:        
			mail.personalizations[0].add_bcc(Email(i))

	try:
		req = sg.client.mail.send.post(request_body=mail.get())
		if req.status_code == 202:
			stat_msg = 'Accepted'
		return stat_msg
	except:
		print("could not send email")
		pass
# end function


def email_log_custombody(sender, receiver1, receivers, subject_, body,
						 file_path, attached=True, override=None):

	hostname, receiver1, receivers = setdefault_maillist(receiver1, receivers,
														 override_check=override)

	sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))

	sender = 'noreply@fliptrx.com'
	from_email = Email(sender)
	to_email = Email(receiver1)
	subject = hostname + ':' + subject_

	content_ = body

	content = Content("text/html charset=UTF-8", content_)
	mail = Mail(from_email, subject, to_email, content)
	p = Personalization()
	p.add_to(to_email)

	if attached is True:
		with open(file_path, 'rb') as f:
			data = f.read()
			f.close()
			encoded = base64.b64encode(data).decode()
			attachment = Attachment()
			attachment.content = encoded
			attachment.type = "application/pdf"
			attachment.filename = file_path.split('/')[-1]
			attachment.disposition = "attachment"
			attachment.content_id = "Example Content ID"
			mail.add_attachment(attachment)

	p = Personalization()
	p.add_to(to_email)

	mail.add_personalization(p)
	if receivers is not None:
		receiver2 = receivers.split(',')
		for i in receiver2:        
			mail.personalizations[0].add_bcc(Email(i))

	try:
		ret = sg.client.mail.send.post(request_body=mail.get())
		if ret.status_code == 202:
			stat_msg = 'Accepted'
		return stat_msg
	except:
		pass
		print("could not send email")
# end function


def email_log_zip(sender, receiver1, receivers, subject_, body, file_path, attached=True):
	hostname, receiver1, receivers = setdefault_maillist(receiver1, receivers)

	sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))

	sender = 'noreply@fliptrx.com'
	from_email = Email(sender)
	to_email = Email(receiver1)
	subject = hostname+':'+subject_
	content_ = body

	content = Content("text/html charset=UTF-8", content_)
	mail = Mail(from_email, subject, to_email, content)
	p = Personalization()
	p.add_to(to_email)

	if attached is True:
		with open(file_path, 'rb') as f:
			data = f.read()
			f.close()
			encoded = base64.b64encode(data).decode()
			attachment = Attachment()
			attachment.content = encoded
			attachment.type = "application/zip"
			attachment.filename = file_path.split('/')[-1]
			attachment.disposition = "attachment"
			attachment.content_id = "Example Content ID"
			mail.add_attachment(attachment)

	p = Personalization()
	p.add_to(to_email)

	mail.add_personalization(p)
	if receivers is not None:
		receiver2 = receivers.split(',')
		for i in receiver2:        
			mail.personalizations[0].add_bcc(Email(i))

	try:
		ret = sg.client.mail.send.post(request_body=mail.get())
		if req.status_code == 202:
			stat_msg = 'Accepted'
	except:
		print("could not send email")
# end function


def email_template_alternate(sender, receiver1, receivers, subject_, templateid,
							 params, file_path, attached=True, loghndl=None):
	from time import sleep
	import json
	param_obj = dict()

	curr_instance = os.environ['INSTANCE_TYPE']
	site_url = ''

	if curr_instance == 'DEV':
		site_url = 'https://app.dev.fliptrx.com'
	elif curr_instance == 'STAGE':
		site_url = 'https://app.staging.fliptrx.com'
	elif curr_instance == 'QA':
		site_url = 'https://app.qa.fliptrx.com'
	else:
		site_url = 'https://app.fliptrx.com'

	if curr_instance in ['DEV', 'STAGE', 'QA']:
		cc_emails = 'developers@fliptrx.com,fliptintegration@fliptrx.com'
	else:
		cc_emails = 'fliptintegration@fliptrx.com'

	hostname, receiver1, receivers = setdefault_maillist(receiver1, cc_emails)

	if 'flipt_company_url' not in params:
		params['flipt_company_url'] = site_url

	if attached is True:
		with open(file_path, 'rb') as f:
			data = f.read()
			encoded_data = base64.b64encode(data).decode()
			param_obj['attachments'] = [{'content': encoded_data,
										 'type': 'application/pdf',
										 'filename': os.path.basename(file_path),
										 'disposition': 'attachment',
										 'content_id': 'ContentID'}]

	to_value = {'email': receiver1,
				'name': params['first_name']}
	bcc_value = {'email': cc_emails,
				'name': 'BCC_LIST'}
	param_obj['personalizations'] = [{'to': to_value,
									  'bcc': bcc_value,
									  'subject': subject_,
									  'dynamic_template_data': params
									 }]

	param_obj['from'] = {'email': sender,
                      'name': sender}
	param_obj['template_id'] = templateid

	return param_obj
# end function


def email_template(sender, receiver1, receivers, subject_, templateid,
                   params, file_path, attached=True, loghndl=None):
	from time import sleep
	import json

	curr_instance = os.environ['INSTANCE_TYPE']
	site_url = ''

	if curr_instance == 'DEV':
		site_url = 'https://app.dev.fliptrx.com'
	elif curr_instance == 'STAGE':
		site_url = 'https://app.staging.fliptrx.com'
	elif curr_instance == 'QA':
		site_url = 'https://app.qa.fliptrx.com'
	else:
		site_url = 'https://app.fliptrx.com'

	try:
		sg = sendgrid.SendGridAPIClient(apikey=os.environ.get('SENDGRID_API_KEY'))
		#import pdb; pdb.set_trace()

		if curr_instance in ['DEV', 'STAGE', 'QA']:
			cc_emails = 'developers@fliptrx.com,fliptintegration@fliptrx.com'
		else:
			cc_emails = 'fliptintegration@fliptrx.com'
		hostname, receiver1, receivers = setdefault_maillist(receiver1, cc_emails)

		from_email = Email(sender)
		to_email = Email(receiver1)

		if hostname in ['DEV', 'QA', 'STAGE']:
			subject = hostname + '-' + subject_
		else:
			subject = subject_

		if curr_instance in ['DEV', 'QA', 'STAGE']:
			content_ = 'Test'
		else:
			content_ = 'Prod'

		content = Content("text/html charset=UTF-8", content_)

		if 'flipt_company_url' not in params:
			params['flipt_company_url'] = site_url

		mail = Mail(from_email, subject, to_email, content)
		mail.template_id = templateid
		p = Personalization()
		# p.substitutions = json.loads(json.dumps(params))
		p.dynamic_template_data = params
		#print('P',p.dynamic_template_data)

		print(
		    f"Updated param list to be sent to sendgrid: {json.loads(json.dumps(params))}")
		if loghndl is not None:
			loghndl.info(
			    f"Updated param list to be sent to sendgrid: {json.loads(json.dumps(params))}")

		if attached is True:
			with open(file_path, 'rb') as f:
				data = f.read()
				f.close()
				encoded = base64.b64encode(data).decode()
				attachment = Attachment()
				attachment.content = encoded
				attachment.type = "application/pdf"
				attachment.filename = file_path.split('/')[-1]
				attachment.disposition = "attachment"
				attachment.content_id = "Example Content ID"
				mail.add_attachment(attachment)

		if receivers is not None:
			receiver2 = receivers.split(',')
			for i in receiver2:
				p.add_bcc(Email(i))

		p.add_to(to_email)
		mail.add_personalization(p)

		# sleep(20)
		req = sg.client.mail.send.post(request_body=mail.get())

		stat_msg = ''
		if req.status_code == 202:
			stat_msg = 'Accepted'

		if loghndl is not None:
			loghndl.info(f"sendgrid client result: {req.status_code}")
	except Exception as e:
		print('Error while attempting to send email : %s for user %s' % (e, receiver1))
# end function


# email_template('noreply@fliptrx.com', 'DWagle@fliptrx.com', 'dgollapudi@fliptrx.com', 'TestEmail',
# 'd-98faa3d7844249ddb4ef9cb500e20915', {'company name': 'G&W LABORATORIES INC.',
# 'first name': 'GOLLAPUDI'}, None, False)
if __name__ == "__main__":
	print('test email')
	email_log('noreply@fliptrx.com', 'fliptintegration@fliptrx.com', None,
			  'Test email log', ['test email ', "test"], "", attached=False)

	email_log('noreply@fliptrx.com', 'FliptIntegration@fliptrx.com',
			  None, 'INS Member ID Update Process Completed',
			  ['Processing of Employee-Dependent files for INS Carrier Update.',
			   'Ins Carrier Update Exception'], "", attached=False)

    # email_template('noreply@fliptrx.com', 'fliptintegration@fliptrx.com', None, 'TestEmail',
    #                'd-98faa3d7844249ddb4ef9cb500e20915', {'company name': 'G&W LABORATORIES INC.',
    #                                                       'first name': 'GOLLAPUDI'}, None, False)
    #print('Emailcompleted')
