########################################
# !/usr/bin/env python  
# description   : User update in truevault for eligibility structure
# author        : Deepthi
# date created  : 20190806
# date last modified    : 
# version       : 0.1
# maintainer    : 
# email         : -
# status        : Development
# Python Version: 3.7.1
# usage         : python update_tv_structure.py -d GWLABS001 -t employee -m final
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#  
# #######################################


if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')


path = os.environ['CB_DATA']
import base64
import os
import json
import sys
from datetime import datetime
import requests
from requests.auth import HTTPBasicAuth
import pandas as pd
from utils import commandline
from utils.truevault import User_Class
import dateutil.parser as parser
from utils.sendgridemail import email_log

count_of_users = 0
domain_name,file_type,file_name,mode=commandline.main(sys.argv[1:])

def update_eligibility():
    errlog = pd.DataFrame()
    global count_of_users
    api_key = os.environ['TV_API_KEY']
    r = requests.get('https://api.truevault.com/v1/users', auth=HTTPBasicAuth(api_key, ''))
    #df = pd.DataFrame()
    response = r.json()
    obj=User_Class(None,None)
    #print('Response from TV',response['users'])
    #sys.exit()
    #test_users = [{'access_key': None, 'account_id': 'ea9f55e2-56d8-4afa-96be-48c990ba680c', 'id': '3c34b73e-2804-419c-bc57-fdcb0c6425b2', 'status': 'ACTIVATED', 'user_id': '3c34b73e-2804-419c-bc57-fdcb0c6425b2', 'username': 'demodepstacy@fliptrx.com'},{'access_key': None, 'account_id': 'ea9f55e2-56d8-4afa-96be-48c990ba680c', 'id': 'a7e7b205-b9ce-49b1-90b9-e1bce2def600', 'status': 'ACTIVATED', 'user_id': 'a7e7b205-b9ce-49b1-90b9-e1bce2def600', 'username': 'cpuser_10'},{'access_key': None, 'account_id': 'ea9f55e2-56d8-4afa-96be-48c990ba680c', 'id': 'bdefb3a9-d58b-4dc6-8d38-5142a4fb5b8d', 'status': 'ACTIVATED', 'user_id': 'bdefb3a9-d58b-4dc6-8d38-5142a4fb5b8d', 'username': 'demostacy2@fliptrx.com'}, {'access_key': None, 'account_id': 'ea9f55e2-56d8-4afa-96be-48c990ba680c', 'id': 'd3207898-b76e-42c8-b3d7-0e81a2a224de', 'status': 'ACTIVATED', 'user_id': 'd3207898-b76e-42c8-b3d7-0e81a2a224de', 'username': 'demostacy1@fliptrx.com'}]
    #test_users = [{'access_key': None, 'account_id': 'ea9f55e2-56d8-4afa-96be-48c990ba680c', 'id': '5a78a5e1-6752-476a-8f70-9e69df7676ec', 'status': 'ACTIVATED', 'user_id': '5a78a5e1-6752-476a-8f70-9e69df7676ec', 'username': 'spal@gwlabs.com'}]
    


    for i in response['users']:
    #for i in test_users:
        search_option = {'full_document': True,'filter': {'$tv.username': {'type': 'eq', 'value': i['username'], 'case_sensitive': False},'$tv.status': {'type': 'eq', 'value': 'ACTIVATED'}}, 'filter_type': 'and'}
        att, uid = obj.search_tvuser(search_option)
        #print('Attrbutes',att)
        if att != None and 'eligibility' not in att:
            try:
                if 'parent_id' not in att:
                    #print('Employee Attributes',att)
                    #Employee
                    att['eligibility'] = []
                    eligibile_plan_year = str(parser.parse(att['coverage_effective_date']).year)
                    tier_name = att['coverage_tier_name']
                    if att['employment_status'].lower() !='cobra':
                        att['eligibility'].append({'plan_year': eligibile_plan_year,'coverage_termination_date' :att['coverage_termination_date'],'coverage_effective_date':att['coverage_effective_date'],'benefit_plan_name':att['benefit_plan_name'],'coverage_tier_name':att['coverage_tier_name'],'cobra_effective_date':'','cobra_termination_date':''})
                    else:
                        #If cobra
                        att['eligibility'].append({'plan_year': eligibile_plan_year,'coverage_termination_date' :att['coverage_termination_date'],'coverage_effective_date':att['coverage_effective_date'],'benefit_plan_name':att['benefit_plan_name'],'coverage_tier_name':att['coverage_tier_name'],'cobra_effective_date':att['coverage_effective_date'],'cobra_termination_date':att['coverage_termination_date']})
                    #print('Attributes',att)
                    #Delete the above values from TV attributes.
                    try:
                        for key in ('coverage_termination_date', 'coverage_effective_date', 'benefit_plan_name', 'coverage_tier_name'):
                            del att[key]
                    except Exception as e:
                        print('Key Error',e)
                        if 'username' in att:
                            errlog = errlog.append({'Username': att['username'],'Flipt Person ID': '','Truevault attributes':'','Record Message': e},ignore_index=True)
                        elif 'flipt_person_id' in att :
                            errlog = errlog.append({'Username': '','Flipt Person ID': att['flipt_person_id'],'Truevault attributes':'','Record Message': e},ignore_index=True)
                        else:
                            errlog = errlog.append({'Username': '','Flipt Person ID': '','Truevault attributes':att,'Record Message': e},ignore_index=True)

                        #errlog = errlog.append({'Domain Name': att['domain_name'], 'Employee ID': att['employee_id'],'Flipt Person ID': att['flipt_person_id'],'Dep Flipt ID': '','Record Message': e},ignore_index=True)
                        continue
                    #Dependents eligibility
                    for dep in att['dependents']:
                        try:
                            if 'eligibility' not in dep:
                                dep['eligibility'] = []
                                if att['employment_status'].lower() !='cobra':
                                    dep['eligibility'].append({'plan_year': eligibile_plan_year,'coverage_termination_date' :dep['coverage_termination_date'],'coverage_effective_date':dep['coverage_effective_date'],'coverage_tier_name':tier_name,'cobra_effective_date':'','cobra_termination_date':''})
                                else:
                                    dep['eligibility'].append({'plan_year': eligibile_plan_year,'coverage_termination_date' :dep['coverage_termination_date'],'coverage_effective_date':dep['coverage_effective_date'],'coverage_tier_name':tier_name,'cobra_effective_date':dep['coverage_effective_date'],'cobra_termination_date':dep['coverage_termination_date']})
                                
                                for key in ('coverage_termination_date', 'coverage_effective_date'):
                                    del dep[key]
                            

                        except Exception as e:
                            print('Error in Dependent Section',e)
                            if 'username' in att:
                                errlog = errlog.append({'Username': att['username'],'Flipt Person ID': '','Truevault attributes':'','Record Message': e},ignore_index=True)
                            elif 'flipt_person_id' in att :
                                errlog = errlog.append({'Username': '','Flipt Person ID': att['flipt_person_id'],'Truevault attributes':'','Record Message': e},ignore_index=True)
                            else:
                                errlog = errlog.append({'Username': '','Flipt Person ID': '','Truevault attributes':att,'Record Message': e},ignore_index=True)

                            #errlog = errlog.append({'Domain Name': att['domain_name'], 'Employee ID': att['employee_id'],'Flipt Person ID': att['flipt_person_id'],'Dep Flipt ID': dep['flipt_person_id'],'Record Message': e},ignore_index=True)
                            
                            continue
                else:
                    #Dependent Account
                    #Get employee Status rom Truevault
                    #Truevault Call for Employee Details
                    search_option={'full_document':True,'filter':{'domain_name':{'type':'eq','value':att['domain_name'],'case_sensitive':False},'flipt_person_id':{'type':'eq','value':str(att['parent_id']),'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
                    att1,userid=obj.search_tvuser(search_option)
                    if att1 != None:
                        #print('Dep Attributes',att1)
                        eligibile_plan_year = str(parser.parse(att['coverage_effective_date']).year)
                        tier_name = att['coverage_tier_name']
                        att['eligibility'] = []
                        if att1['employment_status'].lower().strip() !='cobra':
                            att['eligibility'].append({'plan_year': eligibile_plan_year,'coverage_termination_date' :att['coverage_termination_date'],'coverage_effective_date':att['coverage_effective_date'],'benefit_plan_name':att['benefit_plan_name'],'coverage_tier_name':att['coverage_tier_name'],'cobra_effective_date':'','cobra_termination_date':''})
                        else:
                            att['eligibility'].append({'plan_year': eligibile_plan_year,'coverage_termination_date' :att['coverage_termination_date'],'coverage_effective_date':att['coverage_effective_date'],'benefit_plan_name':att['benefit_plan_name'],'coverage_tier_name':att['coverage_tier_name'],'cobra_effective_date':att['coverage_effective_date'],'cobra_termination_date':att['coverage_termination_date']})
                        
                        #Delete the above values from TV attributes.
                        try:
                            for key in ('coverage_termination_date', 'coverage_effective_date', 'benefit_plan_name', 'coverage_tier_name'):
                                del att[key]
                        except Exception as e:
                            print('Key Error',e)
                            if 'username' in att:
                                errlog = errlog.append({'Username': att['username'],'Flipt Person ID': '','Truevault attributes':'','Record Message': e},ignore_index=True)
                            elif 'flipt_person_id' in att :
                                errlog = errlog.append({'Username': '','Flipt Person ID': att['flipt_person_id'],'Truevault attributes':'','Record Message': e},ignore_index=True)
                            else:
                                errlog = errlog.append({'Username': '','Flipt Person ID': '','Truevault attributes':att,'Record Message': e},ignore_index=True)

                            #errlog = errlog.append({'Domain Name': att['domain_name'], 'Employee ID': att['employee_id'],'Flipt Person ID': att['flipt_person_id'],'Dep Flipt ID': '','Record Message': e},ignore_index=True)
                            continue


                    
                    
                new_att = base64.b64encode(str.encode(json.dumps(att)))
                data = {'attributes': new_att}
                if mode.lower().strip() =='final':
                    
                    response = requests.put('https://api.truevault.com/v1/users/%s' % str(uid),auth=HTTPBasicAuth(api_key, ''), data=data)
                    count_of_users =count_of_users + 1
                    
                else:
                    print('Program ran in draft mode')
                    count_of_users =count_of_users + 1
                    #print('New Attributes',json.dumps(att))
                
            except Exception as e:
                print('Error',e)
                if 'username' in att:
                    errlog = errlog.append({'Username': att['username'],'Flipt Person ID': '','Truevault attributes':'','Record Message': e},ignore_index=True)
                elif 'flipt_person_id' in att :
                    errlog = errlog.append({'Username': '','Flipt Person ID': att['flipt_person_id'],'Truevault attributes':'','Record Message': e},ignore_index=True)
                else:
                    errlog = errlog.append({'Username': '','Flipt Person ID': '','Truevault attributes':att,'Record Message': e},ignore_index=True)

                
                #errlog = errlog.append({'Domain Name': att['domain_name'], 'Employee ID': att['employee_id'],'Flipt Person ID': att['flipt_person_id'],'Dep Flipt ID': '','Record Message': e},ignore_index=True)
                continue
                

        else:
            continue
    return errlog 
        
tvlog=pd.DataFrame()
writer=pd.ExcelWriter(path+'/'+domain_name+'/'+file_type+'/log/eligibilityupdatelog.xlsx',engine='xlsxwriter')
tvlog = update_eligibility()
print('Count of users updated in Truevault',count_of_users)
print('Error Log',tvlog)
tvlog.to_excel(writer,index=False,sheet_name='Errors')
writer.save()
email_log('noreply@fliptrx.com','FliptIntegration@fliptrx.com','deepthi.gollapudi@nttdata.com,dwagle@fliptrx.com','Updation of Truevault Data Completed in %s' %mode,['Update script of truevault structure completed','Update Truevault Structure Exception'],path+'/'+domain_name+'/'+file_type+'/log/eligibilityupdatelog.xlsx') 
print('Update True vault with  eligibility script completed')
 