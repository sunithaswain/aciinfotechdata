from utils.truevault import User_Class

obj = User_Class()
obj.update_user_schema('tpa_member_id', 'string')
