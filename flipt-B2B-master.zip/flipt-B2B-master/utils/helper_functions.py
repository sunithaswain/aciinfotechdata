
import os
from datetime import datetime


def cb_authenticate():
    """
    This function returns an handle object to Couchbase bucket for
    a database instance (dev/staging/prod)
    :return: cluster handle to the bucket
    """
    from couchbase.cluster import PasswordAuthenticator
    from couchbase.cluster import Cluster

    try:
        cluster = Cluster(os.environ['CB_URL'])
        auth = PasswordAuthenticator(
            os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
        cluster.authenticate(auth)
        return cluster.open_bucket(os.environ['CB_INSTANCE'])
    except:
        print("Unable to connect to specified couchbase DB server!!")
        return None
# end function


def print_memusage(rec_type, dataframe, loghandle=None):
    import sys
    import pandas as pd

    data_rows = 0
    if dataframe is None:
        return

    if isinstance(dataframe, pd.DataFrame):
        calc = (dataframe.memory_usage(deep=True).sum()).real
        data_rows = dataframe.shape[0]
    else:
        calc = sys.getsizeof(dataframe)

    kb_amount = calc / 1000
    out_string = f"Memory usage for < {rec_type} >: {data_rows} rows | {calc} bytes | {kb_amount} KB"
    print(out_string + "\n")
    if loghandle is not None:
        loghandle.info(out_string)
# end function


def process_alt_cmdline(additional=None):
    import argparse

    parser = argparse.ArgumentParser(
        description='commandline file processing...')
    parser.add_argument("-m", "--operation_mode",
                        help="final/draft mode", required=True)

    # include other parameters for parsing
    if additional is not None:
        for row in additional:
            parser.add_argument(row[0], row[1], help=row[2], required=row[3])

    args = vars(parser.parse_args())
    cmd_line = {
        'mode': str(args['operation_mode'])
    }

    # add the additional values to the return dictionary
    if additional is not None:
        for row in additional:
            keyval = row[1].replace('--', '')
            cmd_line[keyval] = args[keyval]
    return cmd_line
# end function


def process_cmdline(additional=None):
    import argparse

    parser = argparse.ArgumentParser(
        description='commandline file processing...')
    parser.add_argument(
        "-d", "--domain", help="pass in domain (company)", required=False),
    parser.add_argument("-t", "--file_type",
                        help="pass in doc type", required=False)
    parser.add_argument("-f", "--file_name",
                        help="pass in file name", required=False)
    parser.add_argument("-m", "--operation_mode",
                        help="final/draft mode", required=True)

    # include other parameters for parsing
    if additional is not None:
        for row in additional:
            parser.add_argument(row[0], row[1], help=row[2], required=row[3])

    args = vars(parser.parse_args())
    cmd_line = {
        'domain': str(args['domain']),
        'file_type': str(args['file_type']),
        'file_name': str(args['file_name']),
        'mode': str(args['operation_mode'])
    }

    # add the additional values to the return dictionary
    if additional is not None:
        for row in additional:
            keyval = row[1].replace('--', '')
            cmd_line[keyval] = args[keyval]
    return cmd_line
# end function


def get_domain_mapping(cb_hndl):
    from couchbase.n1ql import N1QLQuery
    domainname_mapping = dict()

    query = N1QLQuery('Select domain, companylegalname, send_digitalcard_link, phone, ' +
                      'flipt_bin, flipt_pcn, emp_registration_reminder2, ' +
                      'emp_registration_reminder3, emp_registration_reminder_final ' +
                      'from `' + os.environ['CB_INSTANCE'] +
                      '` where type="domain"')

    for result in cb_hndl.n1ql_query(query):
        if result['send_digitalcard_link'] in (None, ''):
            result['send_digitalcard_link'] = 'N'

        domainname_mapping[result['domain']] = {'cmpny_legalname': result['companylegalname'],
                                                'digital_link': result['send_digitalcard_link'],
                                                'phone': result['phone'],
                                                'PCN': result['flipt_pcn'],
                                                'BIN': result['flipt_bin']}

        try:
            domainname_mapping[result['domain']]['emp_register_reminder2'] = result['emp_registration_reminder2']
        except KeyError:
            domainname_mapping[result['domain']]['emp_register_reminder2'] = ''

        try:
            domainname_mapping[result['domain']]['emp_register_reminder3'] = result['emp_registration_reminder3']
        except KeyError:
            domainname_mapping[result['domain']]['emp_register_reminder3'] = ''

        try:
            domainname_mapping[result['domain']]['emp_register_final'] = result['emp_registration_reminder_final']
        except KeyError:
            domainname_mapping[result['domain']]['emp_register_final'] = ''

    return domainname_mapping
# end function


def check_doc_exists(cb_handle, doc_name, loghndl=None):
    from couchbase.n1ql import N1QLQuery
    query = N1QLQuery("select * from `" + os.environ['CB_INSTANCE'] +
            "` where type='" + doc_name + "' limit 1")
    query.timeout = 30

    ret_data = cb_handle.n1ql_query(query).get_single_result()
    if ret_data is not None:
        if loghndl is not None:
            loghndl.info(f"\nDocument < {doc_name} > exists!!")

        print(f"\nDocument < {doc_name} > exists!!\n")
        return True
    else:
        if loghndl is not None:
            loghndl.info(f"Document < {doc_name} > not present.")

        print(f"Document < {doc_name} > not present.\n")
        return False
# end function


def read_couchbase_source(cb_handle, doc_name, key_cols=None, extra_query=None, loghndl=None):
    import pandas as pd
    from couchbase.n1ql import N1QLQuery
    from datetime import datetime

    # read the source document into the pandas frame
    query_str = f"SELECT META().id as id,* FROM `{os.environ['CB_INSTANCE']}` " + \
                f"WHERE type='{doc_name}' "

    if extra_query is not None:
        query_str += extra_query

    query = N1QLQuery(query_str)
    query.timeout = 7200
    souce_details = pd.DataFrame()

    starttime = datetime.now()
    source_rows = []
    if loghndl is not None:
        loghndl.info(f"Reading data from < {doc_name} > ...")

    print(f"\nReading rows from < {doc_name} > ...", end='', flush=True)
    for row in cb_handle.n1ql_query(query):
        datarow = {'id': row['id'],
                   'data_row': row[os.environ['CB_INSTANCE']]
                   }

        if key_cols is not None:
            for key in key_cols:
                datarow[key] = row[os.environ['CB_INSTANCE']][key]

        source_rows.append(datarow)
    # end for-loop

    if len(source_rows) > 0:
        souce_details = souce_details.append(source_rows, ignore_index=True)
   
    finishtime = datetime.now() - starttime
    print("Done\n")

    if loghndl is not None:
        loghndl.info("Done reading rows.")

    print(f"Elapsed time: {finishtime}s\n")
    return souce_details
# end function


def couchbase_batch_update(cb_handle, doc_name, updated_info, log_handle=None):
    """
    This function performs bulk update for the document specified
    this funtion is taken from online at following URL
    https://docs.couchbase.com/python-sdk/2.5/batching-operations.html
    :param cb_handle:
    :param updated_info:
    :param log_handle:
    :return:
    """
    from couchbase.exceptions import CouchbaseTransientError

    # import pdb; pdb.set_trace()
    BYTES_PER_BATCH = 1024 * 32
    total_records = len(updated_info)

    batches = []
    cur_batch = {}
    cur_size = 0

    print(f"Chunking {total_records} to sub-batches ...")
    if log_handle is not None:
        log_handle.info(f"Chunking {total_records} to sub-batches ...")

    for dict_key, dict_value in updated_info.items():
        cur_batch[dict_key] = dict_value
        cur_size += len(dict_key) + len(dict_value) + 24
        if cur_size > BYTES_PER_BATCH:
            batches.append(cur_batch)
            cur_batch = {}
            cur_size = 0

    # end loop
    batches.append(cur_batch)  # add final batch
    batch_size = len(batches)
    print(f"There are {batch_size} batch(es) to save/update")
    if log_handle is not None:
        log_handle.info(f"There are {batch_size} batch(es) to save/update")

    print (f"Start processing of {batch_size} chunk(s) @{datetime.now()}")
    if log_handle is not None:
        log_handle.info(f"Start processing of {batch_size} chunk(s) @{datetime.now()}")

    num_completed = 0
    while batches:
        current_batch = batches[-1]
        try:
            cb_handle.upsert_multi(current_batch)
            num_completed += len(current_batch)
            batches.pop()

        except CouchbaseTransientError as e:
            (success_entry, failed_entry) = e.split_results()
            new_batch = {}
            for failed_key in failed_entry:
                new_batch[failed_key] = updated_info[failed_key]
            batches.pop()
            batches.append(new_batch)
            num_completed += len(success_entry)

            new_batch_size = len(new_batch)
            success_count = len(current_batch)

            print(f"Retrying {new_batch_size} of {success_count} items.")
            if log_handle is not None:
                log_handle.info(f"Retrying {new_batch_size} of {success_count} items.")

    print(f"Completed {num_completed} of {total_records} items.")
    if log_handle is not None:
        log_handle.info(f"Completed {num_completed} of {total_records} items.")
    # end while-loop
    print("\nDone saving/updating " + f"{batch_size} chunks to < {doc_name} > document.")
# end function


def setup_logging_path(log_dir, logfile_name, logger_name):
    import logging
    import logging.handlers as lh

    log_path = os.environ['LOGDIR']
    log_handle = logging.getLogger(logger_name)
    log_handle.setLevel(logging.DEBUG)

    try:
        os.chdir(log_path)
    except FileNotFoundError:
        os.mkdir(log_path)

    try:
        os.chdir(log_path + "/" + log_dir)
    except FileNotFoundError:
        os.mkdir(log_path + "/" + log_dir)

    return_name = f'{log_path}/{log_dir}/{logfile_name}.log'
    fh = lh.RotatingFileHandler(
        return_name, maxBytes=1024000000, backupCount=4)
    fh.setLevel(logging.DEBUG)

    formatter = logging.Formatter(
        '%(name)s - %(asctime)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)

    log_handle.addHandler(fh)
    return log_handle
# end function


def compress_files(log_hndl, outfile_name, in_list):
    import subprocess

    filedate = datetime.now().strftime("%m%d%Y")
    outfile = f"/tmp/{outfile_name}_{filedate}.zip"

    log_hndl.info("creating compressed file for transmission ...")
    for file in in_list:
        log_hndl.info(f"\tadding: {file} to {outfile}")
        try:
            run_res = subprocess.call(
                ['zip', '-u9q', outfile, file], shell=True)
        except:
            runcmd = f"zip -u9q {outfile} {file}"
            run_res = subprocess.run(runcmd, shell=True)
        # log_hndl.debug(run_res.stdout)
    return outfile
# end function


def convertstr(instr):
    # do conversion
    import re
    instr = re.sub(r"\'", "", instr)
    instr = re.sub('\[{', '', instr)
    instr = re.sub('}\]', '', instr)
    instr = re.sub('\s', '', instr)

    cp_lst = instr.split(",")
    instr = []
    subdict = 0
    temp = dict()
    for rows in cp_lst:
        (key, val) = rows.split(':')
        if key == 'claim_processor':
            if subdict == 0:
                subdict = 1
                temp[key] = val
        if subdict == 1:
            if key != 'unitprice':
                temp[key] = val
            else:
                temp[key] = val
                instr.append(temp)
                temp = dict()
                subdict = 0
    return instr
# end function


def populate_dict(pandas_obj, row_obj):
    """
    Generic function to retrieve columns from pandas table and populate into a dictionary.
    Then pass the dictionary back to caller
    :param pandas_obj:
    :param row_obj:
    :return: dictionary
    """
    data = dict()
    for col in list(pandas_obj):
        col_new = col.lower().replace(' ', '_').replace('/', '_').replace('+', '_')
        data[col_new] = str(row_obj[col]).encode('utf-8').decode('utf-8')
    return data
# end function


def populate_dict2(pandas_obj):
    data = dict()
    for col in list(pandas_obj):
        data[col] = col.strip().lower().replace(
            ' ', '_').replace('/', '_').replace('+', '_')
    return data
# end function


def split_file_withheaders(infile, log_hndlr, lines=100):
    """
    take the name of the input file.  Then create a subdirectory
    based on the name of the file + split (ie: DRUG_DATABASE_DDMMMYYYY_SPLIT
    :param infile:
    :param logger:
    :return:
    """
    infile_basename = os.path.basename(infile).split('.csv')[0]
    infile_dirname = os.path.dirname(infile)

    split_dirname = infile_dirname + '/' + infile_basename + '_SPLITFILES'

    try:
        os.chdir(split_dirname)
    except FileNotFoundError:
        log_hndlr.warn("Split directory not present. Creating it")
        os.mkdir(split_dirname)
        os.chdir(split_dirname)

    # read header line to use for each split file
    readfile = open(infile)
    header = readfile.readline()
    readfile.close()

    pathnm, filenm = os.path.split(
        split_dirname + '/' + os.path.basename(infile))
    basenm, ext = os.path.splitext(filenm)

    file_list = []
    number_of_files = 0
    # ----------------------------------------------------------------------------------
    # original author for below code: Andrew Yurisich (author), 2012
    # enhanced/modified: Rogier Steehouder, 2012
    #
    with open(infile, 'r') as f_in:
        try:
            # open the first output file
            outfile_name = os.path.join(
                pathnm, '{}_{}{}'.format(basenm, 1, ext))
            f_out = open(outfile_name, 'w')
            # loop over all lines in the input file, and number them
            for i, line in enumerate(f_in):
                # every time the current line number can be divided by the
                # wanted number of lines, close the output file and open a
                # new one
                if i % lines == 0:
                    number_of_files += 1
                    f_out.close()
                    outfile_name = os.path.join(
                        pathnm, '{}_{}{}'.format(basenm, number_of_files, ext))
                    file_list.append(outfile_name)
                    f_out = open(outfile_name, 'w')
                    if line != header:
                        f_out.write(header)
                # write the line to the output file
                f_out.write(line)
        finally:
            # close the last output file
            f_out.close()

    log_hndlr.info(
        f"Split file to {number_of_files} segments for quicker processing.")
    return file_list
# end function
