# Usage python
# SCRIPT: eligibility_communication.py
try:
    from .helper_functions import *
    from .sendgridemail import email_template, email_template_alternate
except:
    from utils.helper_functions import *
    from utils.sendgridemail import email_template, email_template_alternate


def getmember_list(attributes):
    dep_list = attributes['dependents']
    memberList = ''

    for rec in dep_list:
        memberList += '<div class="card-row">'
        memberList += '<div class="card-column-title2">' + \
            rec['first_name'] + ' ' + rec['last_name'] + "</div>"
        memberList += '<div class="card-column-information2">' + \
            attributes['flipt_person_id']
        memberList += rec['person_code'] + "</div></div>"

    return memberList
# end function


def draw_digitalcard(attr, dom_details):
    from weasyprint import HTML, CSS
    from weasyprint.fonts import FontConfiguration

    members = getmember_list(attr)
    font_cfg = FontConfiguration()
    card_file_name = f"{attr['first_name']}_{attr['last_name']}_digitalcard.pdf"
    card_file_path = f'/tmp/{card_file_name}'

    contact_phone = dom_details['phone']
    styles = '''
        .card {
            width: 480px;
            height: auto;
            border-top-left-radius: 20px;
            border-top-right-radius: 20px;
            border: 1px solid #ccc;
            padding: 20px 30px;
            border-bottom-color: #fff;
            padding-bottom: 0;
            }
        .card-logo-header {
            display: flex;
            }
        .card-logo-icon {
            width: 78px;
            padding-right: 25px;
            height: 61px;
            }
        .card-logo-header-text {
            font-size: 15px;
            border-left: solid 1px #ccc;
            padding-left: 26px;
            margin-top: 10px;
            height: 35px;
            }
        .card-main-information {
            padding-top: 20px;
            }
        .card-main-prescription-text {
            font-size: 21px;
            font-weight: 500;
            padding-bottom: 10px;
            }
        .card-row {
            display: flex;
            padding-bottom: 5px;
          }
        .card-row:last-child {
          padding: 0;
        }
        .card-row  .card-column-title,
        .card-row  .card-column-title2 {
            width: 250px;
            font-size: 14px;
            font-weight: bold;
          }
        .card-column-information,
        .card-column-information2 {
            font-size: 13px;
          }
        .card-footer-container {
            width: 480px;
            height: 40px;
            background: red;
            padding: 20px 30px;
            position: relative;
            overflow: hidden;
            border-bottom-left-radius: 20px;
            border-bottom-right-radius: 20px;
            border-style: solid;
            border-color: #ccc;
            border-width: 0 1px 1px 1px;
            }
        .magic {
            width: 600px;
            height: 95px;
            background: white;
            border-radius: 386px / 51px;
            position: absolute;
            top: -64px;
            left: -24px;
            border: 1px solid #ccc;
            }
        .card-footer-row {
            display: flex;
            }
        .card-footer-column-title {
            width: 300px;
            }
        .card-footer-column-separator {
            padding-right: 16px;
            }
        .card-footer-phone-container {
            padding-top: 20px;
            display: flex;
            color: white;
            font-size: 16px;
            font-weight: 100;
            }
        .card-footer-url-container {
            padding-left: 17px;
            border-left: solid 1px;
            margin-left: 45px;
            }
        #root {
            padding: 80px;
            font-family: Arial
            }
    '''

    css_styles = CSS(string=styles)
    digital_card_html = '''
        <!DOCTYPE html>
          <html>
          <body>
            <div id="root">
              <div data-reactroot="" class="card">
                <div class="card-logo-header">
                  <img
                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMwAAACgCAYAAABAFIPTAAAACXBIWXMAAAsSAAALEgHS3X78AAAQZUlEQVR42u2dCZAcZRXHX9JvBA9AEQRUBAORcCkgCptEQNTiEBRQRCGFgCCXUbSkhHCtnIolGKvkMFxyEwnEg3AJEVBApdQQQCDEiCEHOQhJNsnsbIi+f28nbMLMTnd/X/f0Tv//VV/tcux099fvN9/1DhGKoigqP80TeVdNZLfuIDi8FgTHodnvh3WL7DxDZH32EEWZFopsWKtUvlVTfaJHdWlPpfK/tZrqImsPGUBHExyq1LIRZVcD5Y9vgaRRU51YFRnCnqNaoqdEKjbl2QFTH/uWP8naKfZNfnxVdb8VIh/K8tpm/CPsei/HhiVq9jdT7J6H8e1RuWmayHoGyVfNaO+1Nr/ON/kbZpj/sXa9/T7c9/UNxq3ss19MCssaaFQfXyyyMd8klbnMWD9sENwFKGJOg5Z0q144V+SdPq7fKTLYYLkxLSyrm93TJXybVNZrho+ZsU5N9a1eqdz+mshGzvdQqexpEFZdgbHPWMD1DJXlyIJp0DMuRmp/f8OzIm9zuQ8bGX7iDMub9zOab5byrskiasZ1hycjPcXpPlQf8wjM7Xy7lHdVg+AAm8Ks9GSkL3eJbJbmPuaLbOCy2K+z+H8UayK+Ycrv2sXT6LLGUIPghDT3gTWQ3ct0j8A8MV4k4BumvAmjgY0us30CY593t8MI84JHYB6xjx3Et0x5Ew4IfU3H+kzL/gXfr6T3gtEg0cl+8/u4hW+Y8r1+Ocjr6NI7wrySdh3TrXqxR2BO5humfAPzhQyAmb1M5P2p1lMiu9nfd3m4hzlZu+9QZQRG9XNmXKs8T8lmuLim2N+P8wDMeb76CK5C8ITmBgIlVZGPwL3FKzCqj7kY13KRD8CJ0gGWPyAswHEzZHNM6XCWY8/zZ/in2edOsinj+fCipuWUVDiZD2NNPALjw4/LDPXjac5k7FmetKnY1i7Xjryzp/YD5EJ7xs7ZIu+gBZVzp+x7Htcvy83YdvdxX90i2+NbPeZ1V9p1b8Xo5ARqEJyAZ4g59byR0JRQS0U29XX+ASMSj2cfMEiEI5sRT7b22lpe1NgOR/gBpkpB8GXE7zh+cYxIPD31uFaiBtpumeoKR1ied50O9bfwthFnR7vPgw2OI619zX4/EGsw+KC5fj5gs+e/L8WIuggjIS2onFOz0631pJyKzbL2qYH67NF2djXls59J6ymp4G2MRW3CkeUZTGcG9HMHwbEO67YJtJxyjzQd1n5jbVkTQ3m1pnq5LbQ/2Baja3pgHqLVlFxYF5gh7NWtegGcKXG2grMI+HrBR8vaae00d8fzOABzPy2m4IKvFkKK7WXtvUL105gSYQGcxukxhgbhpHumyNux+G7TTY+DHDY7rqZFFlCAAdunOG/AjpRBsthaLWpVa3NxcGejwo9w8MceS/QFtLn138xUB7VBcBh7sGCyUeQziCCM7felusj+/7HLRLZg78Vex5yXJkgto1GdSjsdirZ7l6ScLvzd2h7sxuZCxCcW8AnWLvOyyMtGOcACnyVXb+Iwg6RqB7uzubDjZ331QJw+RS4E9lixdm5O9uV6D9cXJOljr8YeaX6AyNFwfbj2qDLX/v01TEdbMNkL2alumlY3aO5gTEeijYDNwrVjEBwTldc4pCoylD1TwKmYGfdNGURCrqyq7s/uLaFBhecQlconjPpDkeHQjOFsa+f2aWfBbR1JtTHXrInsgh2jtI56nSKD8e2Mn2lbgtFlmO+grj7Q3CnMpFIO2XC4TTSvn2A/p8U2KqwDsM1aqbyEBR3SkWLv3BZ4W8YxZBzYhWGzqhNx6p2iTbS/v26RyLtjrl1GZwJLtLOD56Y1tTcoQ2uqP0M2Eo+Gswqx53AZb3Z97LOH3rhu15sfN5MKwmIzA8Yap2VtqjBPVRCcYAb03wy/cYfHAQZwuaYeWiryvljPrPpklsAw/VAbKpwGBcEVvjOa1CkMtGeRgIGvll3r6SyBwUEoLayNBEc/M5prMzWacgPzfVpZGwmpbDKHpaDAYBPCZ8kHn8nCqQJqheq+rrHlAxmYaNH/qwyfeRUO42hp9YUdxLAQrsiwlG17X+UL403F4JGbByxFBsYlXDbDvMdlEKqoRZlo5jm0fPz24HqQGywFBgY5gcOOz2aH7Hpi0VjhuZm7Xe2VyxayXegeAhN906mOzeB5l9NruSkwE1ynvLlkz8HhpF1oKYF5c5RxvuZbg53GEok2AcaM48RcYSk4MOGXiOp+3jyWVe+L65pDYAYGMDcRmLrrui8lzRNW59qT09ZrITAFBCY6rPsngWk80tj1n0v5fDchwQNRaCNgkHHd566QGcm/4R0cRc2dhpNthPpiyzA8FFSd2+cBO4oOTLSm2QpJ82IVcEUme9W/1YLg664JuglMAYFBeQS7SLcnWMZVRYY0uhayweNwKcwIX6mMj1McpwjArJmiiewQJZ0bbz//gZAFlOpGCLJB8id7rl9gGrdE5L00/zYFJkxE56lqbpJEc9jKRkGhgQRMHw16XeQ9OJnGjhrWKKxVUhJgvBQmVV2AzI9Z3F9BgaHKCgxqfXgAZlJW90dgCEzbAYOk2QSGIjDx1y+jCQxFYOIDcwqBGRhC5p4lIpt0i+yMEHHkGAhbEBwAx0VUA8NRQys2MZBVxwMwHVkDc3iRg6JaBMwg7H5VRbZN25Dpsr+0UkiLCh8+h2sMiZu2CjEi1gcjrY0J6830Vi2bH2b+6a08UA2PFlS7ogw/08NaNL3b5KOQMUg8pIfqFBncT78OsWvf6wqM3e8R+KyEfTl0vsgGfcntsA64zNYal67TLgnTF3lwW8eNWjsqZhuF4qLYmi0iMGFOA9VHwoPK3vqRSdtsu+cpjVxiEHsUGofqnJSfPwuprprtTOI8CH6C0bN0OfTfTPuc25CHbqHIhmmBwagVJhyv36+vxC05HiNJ+SsJ+3MOzs/W3GiYTyxv15c4riMiuxQWGNdS4PYN3qicHjL6py6CGiM/AEYeTLUNlL96fmc1eGvgSy/NlC0sY47RrWi22FtnZlTfF/TNAgLTgypeBQbmOcdrzm0EDMKUvbxkmyHUmeptGUUurszyyw5HCUnXCxEwUwoKzFFFB6ZWYmD29QTMReuOXHDZyfEdLrR2BqaYBIbADChgqkFwsHOG0PRr2FvjhDAQGAJTCGDCoqqucTvuEaWPNquBQ2AITEuBQV3Iqsh2aQuqZgDNk9g2JjAEppDA2D3+MtwyLtB7xf00CpojMASm1SNMVxGNDxUQ6oV6EBgC01pgitxUzyAwBIbAxH/+Jeue0xAYAkNgmuyc9c11TGAIDIFpvp45aSACc2IBgVlJYHLt72WoJmftWdTAsfZ8mMFHtSdjYF5YnRQkAmZq8X3JguAbYRkLpINduy3xUt7CRovos5YmaIsQk0FgMh7FUZFBdQySnawQ2XqxyMbwEo9iYnZAEnqksXV2Nu0fmlPXAKP6F8DbwBZ7fHwxpLDF5aj4veYFYV88iofo6NtQOjwsGe5+k7+PPqsjSYtTy4PApL7+w4AB/RfnmeHaYs/8HeSVywCYKYg3QTwMPNTt3kbUsUV4cD/sodjwiSlscaTZx6b5BZBVKte1UwDZgAamt0rA2XFBWVeR58Cdnu8JgV2HxIi4/LUHYPaULOUpRPkGAlMAYFQX4n269jlGfkRbeh5lbmZMP4EpDjDrzsMdhSSLXqFRnWXTvi0IDIEpCjBjfPd9FFI8yeNO1GEEhsC0HhjVB3HPmdiHyLC1Esi7JUv5OYEhMK0Fpve4YGSWNgK/MF/u//1luiEwBCaPEWa8eEiB1CT7zCZetptV5zXqEwJDYPJw738DCfgkB3Wr/tiHd4e1vQkMgWlVANnzLnnCkig6DKx6WMccS2AITMsiLiUnRX3iXNrRRqoLCQyBaVUSjAskR4WlGN1t5WoCQ2AKkZcsB2C+7WEdcy+BITClAMZs5YsetpYfIzAEphTARJ69PY7APNEpMpjAEJj2H2FEPhrGmxAYAkNgYgGzs2tqJwJDYMqz6O8N/lpOYAgMgYm3htk7LHXhCEwjVx4CQ2DabZfsCB+pZLlLRmDKMsKc4+Ec5i4CQ2DKAsydHkaYsQSGwLTKW/nuvGBBeiZPLv5jCAyBaRUwr6KmZR7AVIPg864L/ihM+SsEhsC0LICsbyrWTLeUK5WbPQBetc/ZncAQmFYC81SchIiOB5bbI1OpB2Bmrk4bS2AITMuSYCDbY8ajy/WeppAPSD/h1J6AGUlgCEyz/p/RrCCrg30cYs/S7WlX74dNduEmuF6jqro/gSEwca430ffUrCoy1PrhJV/VGuy598kamFoQHE1gCEzc93Atku/56HdUQ66pPu7x3prmH/ABDJJ1EBgCk+hdoJyF4yJ/p7Ashd9qZJfHOBid4OH5n31NZKOkZ0yxR2cC017ARNeenGa3KHxum9J4L3mBNZDq8DyAieD8KXJDN7se3g+q86GGTpxaRQSmXYHpvf4iM/4rYajNpmlhcaUgOBTx9mHuMP/3cv9TIpUYu3G3+crXhs/CBgCKSGErG89oa7Jtw1o0QXCs/fdx1qZF/38PRlUCw5J9YTVjeAjb3P5SM5TjYUTWPhtWHustoDQuLKOXVem+3towh8bavraRwfO1cVD6srVnMFWDHVhbXLfyAYEhMP2UV6xlMpI0cOefIbJ+nH63ezq9RX1CYAhMMSplJ0lli3IYBIbAlBYYrKEkQaJ0FKl1zRlAYAjMwITF1gwoRpzkXUdlyZ8mMASmXMCoLsXGQiq/NezsERgCUxpgerd0R6d2x1Hdz0fcDYEhMHX9x+w+XywSMN2qneJQ4Cmclnn2MiAwBGb1Nc6xtpe1BQUYWVYhx0Bng5xjebtrERgC0zAJRhQ+PLeV28fWzhovEvh459NE1rPPu4fAEJhMgIkO/UbAI7gFsMw2GzrS93uvimznLbQgRmFdAlPCNEuRr9Rvc4Tld7GdFtPsmFUqn/TuCNrAOdSeY0cCU8K8ZNG9n2bXn5XlGUstCI7D1EkyVk1kV59xOXWeZbq1U+O67wCYUR4uemuWwNjLn+NovAu6RDZLCMx0x2u+3igFUh6J/MIpjepl3sBRXYmEG9a+m/RA0lXwNrbrnwdHSl8bFOEBqerZCJRLOuztYd8WV1m7ImW7qr/KuD4WgDAMHGilvL8r7e8vmS+yQdxrIpbCOvNcx2te2iiQK8/MlwbONmGpPdUHkMcs6QEkDAvPVA2CA5MGZvkWXPXhYR09y5xE5zXw2q5Uplq7Bj5r/WWvoQqmVqSKxZcARp3QwVH1TIQz289JkfE9ZO1Ba/dhtmCfe75BcgxKjbtGb2YhxNZgvQbHTgCE4rhhwVrVu8IgNPtp/3wLwpXt9zOQRB350BBZSesjMC4aNFlEYYD46eMMhaLaGRiKIjAURWAIDEVgCAxFERiKIjAURWAoisBQFIEhMBSBITAURWAoisBQFIGhKAJDUQSGwFAEhsBQFIGhKAJDUQSGoggMRREYAkMRGAJDUQSGoggMRREYiiIwFEVgCAxFYAgMRREYiiIwFEVgKIrAUBSBITAUgXEG5mL2JlUGYPbpUe2ytiz6maYtN2A62ZtU22uhyIZh9WqHZsAMb1TWnKIoKhf9H8sHarAXwCyVAAAAAElFTkSuQmCC"
                    alt="Logo" class="card-logo-icon" />
                  <div class="card-logo-header-text">Innovative Pharmacy Benefit Manager designed to minimize 
                  prescription cost for plan members</div>
                </div>
                <div class="card-main-information">
                  <div class="card-main-prescription-text">Prescription ID Card</div>
                  <div class="card-main-table">
                    <div class="card-row">
                      <div class="card-column-title">Rx Group</div>
                      <div class="card-column-information">GROUP_VALUE</div>
                    </div>
                    <div class="card-row">
                      <div class="card-column-title">Rx Bin</div>
                      <div class="card-column-information">FLIPT_BIN</div>
                    </div>
                    <div class="card-row">
                      <div class="card-column-title">Rx PCN</div>
                      <div class="card-column-information">FLIPT_PCN</div>
                    </div>
                    <div class="card-row">
                      <div class="card-column-title">FIRSTNAME LASTNAME</div>
                      <div class="card-column-information">FLIPT_PERSONIDPERSONCODE</div>
                    </div>
                    DEP_MEMBERS
                  </div>
                </div>
              </div>
              <div class="card-footer-container">
                <div class="magic"></div>
                <div class="card-footer-phone-container">
                  <div>
                    <div class="card-footer-row">
                      <div class="card-footer-column-title">Member Customer Service</div>
                      <div class="card-footer-column-separator">:</div>
                      <div class="card-footer-column-phone">CONTACT_PHONE</div>
                    </div>
                  </div>
                  <div class="card-footer-url-container">www.fliptrx.com</div>
                </div>
              </div>
            </div>
          </body>
          </html>
    '''

    digital_card_html = digital_card_html.replace(
        'CONTACT_PHONE', contact_phone)
    digital_card_html = digital_card_html.replace(
        'FLIPT_PCN', dom_details['PCN'])
    digital_card_html = digital_card_html.replace(
        'FLIPT_BIN', dom_details['BIN'])
    digital_card_html = digital_card_html.replace('GROUP_VALUE', attr['group'])
    digital_card_html = digital_card_html.replace(
        'FIRSTNAME', attr['first_name'])
    digital_card_html = digital_card_html.replace(
        'LASTNAME', attr['last_name'])
    digital_card_html = digital_card_html.replace(
        'FLIPT_PERSONID', attr['flipt_person_id'])
    digital_card_html = digital_card_html.replace(
        'PERSONCODE', attr['person_code'])
    digital_card_html = digital_card_html.replace('DEP_MEMBERS', members)

    html = HTML(string=digital_card_html)

    html.write_pdf(card_file_path,
                   stylesheets=[css_styles],
                   font_config=font_cfg)

    return card_file_path
# end function


def new_user_communication(dom_mapping, attributes, mode='final', logger=None, createfl=False):
    # send new user communication
    import os
    sender = 'wecare@fliptrx.com'
    receiver = attributes['work_email']
    attachment_file = None
    incl_attachment = False
    param_dict = None

    subject = f"Register Your Flipt App for Prescription Benefits"
    templateid = os.environ['EMPLOYEE_REGISTRATION_INSTRUCTIONS']

    if (dom_mapping[attributes['domain_name']]['digital_link'] == 'Y'):
        attachment_file = draw_digitalcard(
            attributes, dom_mapping[attributes['domain_name']])
        incl_attachment = True

    params = {'company_name': dom_mapping[attributes['domain_name']]['cmpny_legalname'],
              'first_name': attributes['first_name'],
              'concierge_phone_number': dom_mapping[attributes['domain_name']]['phone']}

    if logger is not None:
        logger.info(params)
        # print(f"in new_user_communication: params= {params}")

    if mode.lower() == 'final':
        if createfl is False:
            email_template(sender, receiver, None, subject,
                           templateid, params, attachment_file,
                           attached=incl_attachment,
                           loghndl=logger)
        else:
            param_dict = email_template_alternate(sender, receiver, None, subject,
                                                  templateid, params, attachment_file,
                                                  attached=incl_attachment,
                                                  loghndl=logger)

    if attachment_file is not None:
        # remove the generated card from system
        os.unlink(attachment_file)

    return param_dict
# end function


def terminated_dependent_communication(dom_mapping, attributes, depattributes,
                                       mode='draft', createfl=False):
    # send employee/dependent termination communication
    sender = 'wecare@fliptrx.com'
    param_dict = None

    if 'personal_email' in attributes:
        receiver = attributes['personal_email']
    elif 'communication_option_email' in attributes:
        receiver = attributes['communication_option_email']
    else:
        receiver = attributes['work_email']
    #print('Terminated Dependent')
    subject = 'Information About Your Dependents'

    templateid = os.environ['DEPENDENT_TERMINATION']
    params = {'company_name': dom_mapping[attributes['domain_name']]['cmpny_legalname'],
              'employee_name': attributes['first_name'],
              'first_name': attributes['first_name'],
              'dependent_name': depattributes['first_name'],
              'concierge_phone_number': dom_mapping[attributes['domain_name']]['phone']}

    if mode.lower() == 'final':
        if createfl is True:
            param_dict = email_template_alternate(sender, receiver, None, subject,
                                                  templateid, params,
                                                  None,
                                                  attached=False)
        else:
            email_template(sender, receiver, None, subject,
                           templateid, params,
                           None,
                           attached=False)
    return param_dict
# end function


def user_changes_communication(dom_mapping, term_log, eligibility_log, old_attributes,
                               new_attributes, hr_email=None, notify_user=None,
                               mode='final', createfl=False):
    # send info change communication
    templateid = ''
    receiver = old_attributes['work_email']
    sender = 'wecare@fliptrx.com'
    param_dict = None
    params = {}

    params = {'company_name': dom_mapping[old_attributes['domain_name']]['cmpny_legalname'],
              'employee_name': old_attributes['first_name'],
              'first_name': old_attributes['first_name'],
              'concierge_phone_number': dom_mapping[new_attributes['domain_name']]['phone']}

    if (old_attributes['employment_status'].lower().strip() != new_attributes['employment_status'].lower().strip() and
            new_attributes['employment_status'].lower().strip() == 'terminated'):
        # employee terminated
        templateid = os.environ['TERMINATION']

        subject = 'Termination Confirmation'
        if 'personal_email' in old_attributes:
            receiver = old_attributes['personal_email']
        elif 'communication_option_email' in old_attributes:
            receiver = old_attributes['communication_option_email']

        if mode.lower() == 'final':
            if createfl is False:
                if notify_user is not None and notify_user.lower() == 'y':
                    email_template(sender, receiver, None, subject,
                                   templateid, params,
                                   None,
                                   attached=False)
            else:
                if notify_user is not None and notify_user.lower() == 'y':
                    param_dict = email_template_alternate(sender, receiver, None, subject,
                                                          templateid, params,
                                                          None,
                                                          attached=False)
        term_log = term_log.\
            append({'Domain Name': new_attributes['domain_name'],
                    'Last Name': new_attributes['last_name'],
                    'First Name': new_attributes['first_name'],
                    'Email': new_attributes['work_email'],
                    'Person ID': old_attributes['flipt_person_id'],
                    'Status': new_attributes['employment_status']},
                   ignore_index=True)
        return (term_log, eligibility_log, param_dict)

    try:
        if (old_attributes['eligibility'][-1]['benefit_plan_name'].lower().strip() !=
                new_attributes['benefit_plan_name'].lower().strip()):
            # benefit plan changed
            templateid = os.environ['BENEFIT_PLAN_CHANGE']

            subject = 'Change in Benefits'
            if 'personal_email' in old_attributes:
                receiver = old_attributes['personal_email']
            elif 'communication_option_email' in old_attributes:
                receiver = old_attributes['communication_option_email']
            else:
                receiver = new_attributes['work_email']
            params['original_plan'] = old_attributes['eligibility'][-1]['benefit_plan_name']
            params['new_plan'] = new_attributes['benefit_plan_name']

            if mode.lower() == 'final':
                if createfl is True:
                    if (notify_user is not None and notify_user == 'Y'):
                        param_dict = email_template_alternate(sender, receiver, None, subject,
                                                              templateid, params,
                                                              None,
                                                              attached=False)
                else:
                    if (notify_user is not None and notify_user == 'Y'):
                        param_dict = email_template(sender, receiver, None, subject,
                                                    templateid, params,
                                                    None,
                                                    attached=False)

            eligibility_log = eligibility_log.\
                append({'Domain Name': new_attributes['domain_name'],
                        'Last Name': new_attributes['last_name'],
                        'First Name': new_attributes['first_name'],
                        'Email': new_attributes['work_email'],
                        'Person ID': old_attributes['flipt_person_id'],
                        'Status': new_attributes['employment_status'],
                        'Old Plan': old_attributes['eligibility'][-1]['benefit_plan_name'],
                        'New Plan': new_attributes['benefit_plan_name']},
                       ignore_index=True)
            return (term_log, eligibility_log, param_dict)
    except KeyError:
        pass

    home_field = ['home_address_1', 'home_address_2', 'city', 'state', 'zip']
    for field in home_field:
        if old_attributes[field].lower().strip() != new_attributes[field].lower().strip():
            # home address changed
            templateid = os.environ['HOME_ADDRESS_CHANGE']

            subject = 'Address Change Notification'

            if hr_email is not None:
                receiver = hr_email

                if mode.lower() == 'final':
                    email_template(sender, 'FliptIntegration@fliptrx.com',
                                   hr_email, subject,
                                   templateid, params, None, False)
                    # send email only to HR if address change is triggered.

            eligibility_log = eligibility_log. \
                append({'Domain Name': new_attributes['domain_name'],
                        'Last Name': new_attributes['last_name'],
                        'First Name': new_attributes['first_name'],
                        'Email': new_attributes['work_email'],
                        'Person ID': old_attributes['flipt_person_id'],
                        'Status': new_attributes['employment_status'],
                        f'Old {field}': old_attributes[field],
                        f'New {field}': new_attributes[field]},
                       ignore_index=True)
            return (term_log, eligibility_log, param_dict)

    if (old_attributes['employment_status'].lower().strip() != new_attributes['employment_status'].lower().strip() and
            new_attributes['employment_status'].lower().strip() == 'cobra'):
        # plan change to Cobra
        templateid = os.environ['COBRA_PLAN_CHANGE']

        subject = 'Plan Change to Cobra'
        if 'personal_email' in old_attributes:
            receiver = old_attributes['personal_email']
        elif 'communication_option_email' in old_attributes:
            receiver = old_attributes['communication_option_email']
        else:
            receiver = new_attributes['work_email']

        params['cobra_start_date'] = new_attributes['cobra_effective_date']
        params['cobra_end_date'] = new_attributes['cobra_termination_date']

        if mode.lower() == 'final':
            if createfl is False:
                if notify_user is not None and notify_user.lower() == 'y':
                    email_template(sender, receiver, None, subject,
                                   templateid, params, None, False)
            else:
                if notify_user is not None and notify_user.lower() == 'y':
                    param_dict = email_template_alternate(sender, receiver, None, subject,
                                                          templateid, params,
                                                          None,
                                                          attached=False)

        eligibility_log = eligibility_log. \
            append({'Domain Name': new_attributes['domain_name'],
                    'Last Name': new_attributes['last_name'],
                    'First Name': new_attributes['first_name'],
                    'Email': new_attributes['work_email'],
                    'Person ID': old_attributes['flipt_person_id'],
                    'Cobra Start Date': new_attributes['coverage_effective_date'],
                    'Cobra End Date': new_attributes['coverage_termination_date'],
                    'Status': new_attributes['employment_status']},
                   ignore_index=True)
        return (term_log, eligibility_log, param_dict)

    if (old_attributes['work_email'].lower().strip() != new_attributes['work_email'].lower().strip()):
        # email change
        subject = ''
        templateid_oldemail = os.environ['EMPLOYEE_OLD_EMAIL_CHANGE']
        templateid_newemail = os.environ['EMPLOYEE_NEW_EMAIL_CHANGE']

        old_email = old_attributes['work_email'].lower().strip()
        new_email = new_attributes['work_email'].lower().strip()

        params['first_name'] = old_attributes['first_name']
        params['new_email'] = new_email
        if mode.lower() == 'final':
            if createfl is False:
                if notify_user is not None and notify_user.lower() == 'y':
                    email_template(sender, old_email, None, subject,
                                   templateid_oldemail, params, None, False)
                    email_template(sender, new_email, None, subject,
                                   templateid_newemail, params, None, False)
            else:
                if notify_user is not None and notify_user.lower() == 'y':
                    param_dict = email_template_alternate(sender, old_email, None, subject,
                                                          templateid_oldemail, params,
                                                          None,
                                                          attached=False)
                    param_dict = email_template_alternate(sender, new_email, None, subject,
                                                          templateid_newemail, params,
                                                          None,
                                                          attached=False)
        eligibility_log = eligibility_log. \
            append({'Domain Name': new_attributes['domain_name'],
                    'Last Name': new_attributes['last_name'],
                    'First Name': new_attributes['first_name'],
                    'Email': new_attributes['work_email'],
                    'Person ID': old_attributes['flipt_person_id'],
                    'Cobra Start Date': new_attributes['coverage_effective_date'],
                    'Cobra End Date': new_attributes['coverage_termination_date'],
                    'Status': new_attributes['employment_status']},
                   ignore_index=True)
        
        return (term_log, eligibility_log, param_dict)

    return (term_log, eligibility_log, param_dict)
# end function

