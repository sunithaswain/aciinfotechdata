import json
import copy
from datetime import datetime


class FileComp():
    def __init__(self, fl_path, domain_nm, filetype):
        self.beforeList = []
        self.afterList = []
        self.todaydate = datetime.now()
        self.flpath = fl_path
        self.domain_nm = domain_nm
        self.datestamp = datetime.strftime(self.todaydate, "%Y_%m_%d-%H%M%S")
        self.out_presnap_file = f"{fl_path}{domain_nm}_{filetype}_presnap_{self.datestamp}.json"
        self.out_postsnap_file = f"{fl_path}{domain_nm}_{filetype}_postsnap_{self.datestamp}.json"
    # end constructor

    def sort_attributes(self, record):
        from collections import OrderedDict
        temp = OrderedDict()

        for attrib in sorted(record):
            temp[attrib] = copy.deepcopy(record[attrib])

        return(dict(temp))
    # end method

    def append(self, rec, type):
        temp_record = copy.deepcopy(rec)
        if 'dependents' in temp_record:
            for dep_recs in range(len(temp_record['dependents'])):
                temp_record['dependents'][dep_recs] = self.sort_attributes(
                    temp_record['dependents'][dep_recs])
        temp_record = self.sort_attributes(temp_record)

        if type.lower() == 'pre':
            self.beforeList.append(temp_record)
        else:
            self.afterList.append(temp_record)
    # end method

    def write(self, f_mode):
        outfile = ""
        listFile = None

        if f_mode == 'pre':
            outfile = self.out_presnap_file
            listFile = copy.deepcopy(self.beforeList)
        else:
            outfile = self.out_postsnap_file
            listFile = copy.deepcopy(self.afterList)

        if len(listFile) > 0:
            fp = open(outfile, "w")
            json.dump(listFile, fp, indent=True)
            fp.close()
    # end method

    def readin_files(self, infile_name):
        file_hndl = open(infile_name)

        file_lines = file_hndl.readlines()
        file_hndl.close()
        return file_lines
    # end method

    def compare_files(self):
        import os
        file_check = None

        # check if files required for generating differences exist
        try:
            file_check = os.stat(self.out_presnap_file)
        except FileNotFoundError:
            self.filecompared = False
            return False

        try:
            file_check = os.stat(self.out_postsnap_file)
        except FileNotFoundError:
            self.filecompared = False
            return False

        del self.beforeList
        del self.afterList

        self.comp_file = f"{self.flpath}{self.domain_nm}_compares_{self.datestamp}.json"
        # read all the lines from each JSON file into independent lists
        orig_file_lines = self.readin_files(self.out_presnap_file)
        altered_file_lines = self.readin_files(self.out_postsnap_file)

        orig_file_index = 0
        altered_file_index = 0
        origfl_row_lines = []
        alteredfl_row_lines = []
        origfl_numlines = len(orig_file_lines)
        alteredfl_numlines = len(altered_file_lines)
        main_idx = 0

        if alteredfl_numlines > origfl_numlines:
            main_idx = alteredfl_numlines
        elif alteredfl_numlines == origfl_numlines:
            main_idx = origfl_numlines
        elif origfl_numlines > alteredfl_numlines:
            main_idx = origfl_numlines

        while (orig_file_index < main_idx or altered_file_index < main_idx):
            try:
                orig_fileline = orig_file_lines[orig_file_index].replace(
                    "\n", '')
            except IndexError:
                orig_fileline = ''

            try:
                altered_fileline = altered_file_lines[altered_file_index].replace(
                    "\n", '')
            except IndexError:
                altered_fileline = ''

            if ((altered_file_index > main_idx) or (orig_file_index > main_idx)):
                break

            if orig_fileline == altered_fileline:
                origfl_row_lines.append(orig_fileline)
                alteredfl_row_lines.append(altered_fileline)
                orig_file_index += 1
                altered_file_index += 1
                continue

            elif orig_fileline < altered_fileline:
                if len(orig_fileline) == len(altered_fileline):
                    origfl_row_lines.append(orig_fileline)
                    alteredfl_row_lines.append(altered_fileline)
                    orig_file_index += 1
                    altered_file_index += 1
                    continue

                else:
                    if orig_fileline == altered_fileline[:-1]:
                        origfl_row_lines.append(orig_fileline)
                        alteredfl_row_lines.append(altered_fileline)
                        orig_file_index += 1
                        altered_file_index += 1
                        continue

                    else:
                        alteredfl_row_lines.append('')
                        origfl_row_lines.append(orig_fileline)
                        orig_file_index += 1
                        continue

            elif orig_fileline > altered_fileline:
                if (len(orig_fileline) == len(altered_fileline) and orig_fileline == altered_fileline):
                    origfl_row_lines.append(orig_fileline)
                    alteredfl_row_lines.append(altered_fileline)
                    orig_file_index += 1
                    altered_file_index += 1
                    continue

                else:
                    alteredfl_row_lines.append(altered_fileline)
                    origfl_row_lines.append('')
                    altered_file_index += 1
                    continue
        # end while

        
        with open(self.comp_file, 'w') as outfile:
            for orig_fileline, compare_fileline in zip(origfl_row_lines, alteredfl_row_lines):
                orig_fileline = orig_fileline.replace('\n', '')
                compare_fileline = compare_fileline.replace('\n', '')

                if orig_fileline == compare_fileline:
                    print(f"{orig_fileline.ljust(70)}        {compare_fileline}", file=outfile)
                elif compare_fileline > orig_fileline:
                    print(f"{orig_fileline.ljust(70)}   >>   {compare_fileline}", file=outfile)
                else:
                    print(f"{orig_fileline.ljust(70)}   <<   {compare_fileline}", file=outfile)
            # end for-loop
        # end context
        self.filecompared = True

        # delete the source files after compare
        os.unlink(self.out_presnap_file)
        os.unlink(self.out_postsnap_file)

        del origfl_row_lines
        del alteredfl_row_lines

        return self.filecompared
    # end method
# end class
