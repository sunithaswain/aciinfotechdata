if __name__ == '__main__':
   import os
   import sys
   rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
   sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# it will changed based on OS
# rootdir = rootdir.replace('\\', '/')
path = os.environ['CB_DATA']
 
import xlsxwriter
import os
from utils import opccmdline
import sys
import dateutil.parser as parser
import socket
import datetime as dt
from datetime import datetime

from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.cluster import Bucket
from couchbase.n1ql import N1QLQuery
from utils.sendgridemail import email_log
from utils.truevault import User_Class
from utils.FliptConcurrent import concurrent
from rewards.rewardredemptionpayroll import rewardpayroll

cluster = Cluster(os.environ['CB_URL'])
authenticator = PasswordAuthenticator(os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
cluster.authenticate(authenticator)
cb = cluster.open_bucket(os.environ['CB_INSTANCE'])
# path = os.environ['CB_DATA']
domain, file_type, file_name, commandmode, start_text, end_text = opccmdline.main(sys.argv[1:])
req=concurrent(sys.argv[0],sys.argv[1:],2)
currentdate = datetime.now().isoformat()
filepath = path+'/'+domain+'/'+file_type+'/'+file_name+str(currentdate)+'.xlsx'
image_path = path+'/'+domain+'/'+file_type+'/gnw.PNG'
host = socket.gethostname()
ename = ''
fname = ''
lname = ''
subject = ''
empid = ''
# Create a workbook and add a worksheet.

sdate=''
edate=''

# Different Formats for Rows and Columns
def generatereport(mode,start_date,end_date,pay_date):
	workbook = xlsxwriter.Workbook(filepath)
	worksheet = workbook.add_worksheet()
	header_format = workbook.add_format({
		'bold': True,
		'text_wrap': True,
		'valign': 'top',
		'fg_color': '#FF0000',
		'border': 1})
	header_format.set_font_color('#FFFFFF')
	header_format.set_border_color('#FF0000')
		
	parameter_format = workbook.add_format({
		'bold': True,
		'text_wrap': True,
		'valign': 'top',
		'fg_color': '#FF0000',
		'border': 1})
	parameter_format.set_font_color('#FFFFFF')	
	parameter_format.set_border_color('#FF0000')

	row_format = workbook.add_format({
		'bold': False,
		'text_wrap': True,
		'valign': 'top',
		'fg_color': '#FFFFFF',
		'border': 1})	
	row_format.set_border_color('#FF0000')
	
	merge_format = workbook.add_format({
		'bold': True,
		'text_wrap': True,
		'align': 'center',
		'valign': 'vcenter',
		'fg_color': '#FF0000',
		'border': 1})	
	merge_format.set_font_size(30)
	merge_format.set_font_color('#FFFFFF')

	if mode == 'DETAIL':	
		# Start from the first cell. Rows and columns are zero indexed.
		row = 0
		col = 0
		subject = 'OPC Detail Report - '+host
		worksheet.insert_image('A1', image_path, {'x_scale': 0.5, 'y_scale': 0.5})
		cancel_date = ''
		emp_refund = 0
		# Set column Width
		worksheet.set_column('A:A',22)
		worksheet.set_column('B:B',18)
		worksheet.set_column('C:C',23)
		worksheet.set_column('D:D',25)
		worksheet.set_column('E:E',25)
		worksheet.set_column('F:F',25)
		worksheet.set_column('G:G',25)
		worksheet.set_column('H:H',14)
		worksheet.set_column('I:I',14)
		worksheet.set_column('J:J',15)
		worksheet.set_column('K:K',17)
		worksheet.set_column('L:L',17)
		worksheet.set_column('M:M',17)

		# Report Header
		worksheet.merge_range('C1:F2', 'Employee Out of Pocket Cost Report', merge_format)

		# Report parameters
		worksheet.write(3, 0, "Statement Date Range",parameter_format)
		worksheet.write(4, 0, "Domain",parameter_format)
		worksheet.write(3, 1, start_date,row_format)
		worksheet.write(3, 2, end_date,row_format)
		worksheet.write(4, 1, domain,row_format)
		worksheet.write(3, 4, "Report Generated at ",parameter_format)
		worksheet.write(3, 5, currentdate, row_format)

		# write it out row by row.
		worksheet.write(6, 0, "RX Number",header_format)
		worksheet.write(6, 1, "Employee Number",header_format)
		worksheet.write(6, 2, "Employee Name",header_format)
		worksheet.write(6, 3, "Pharmacy",header_format)
		worksheet.write(6, 4, "Location",header_format)
		worksheet.write(6, 5, "Routed Date",header_format)
		worksheet.write(6, 6, "Cancelled Date",header_format)	
		worksheet.write(6, 7, "Drug Cost",header_format)
		worksheet.write(6, 8, "Employer cost",header_format)
		worksheet.write(6, 9, "Employee opc",header_format)
		worksheet.write(6, 10, "Employee Refund",header_format)
		worksheet.write(6, 11, "Payroll Deduction",header_format)
		worksheet.write(6, 12, "Payment Option",header_format)

		paymenttab = N1QLQuery('select prescription_id,flipt_person_id,pharmacy,location,routed_date,filled_date,drug_cost,employee_opc,employer_cost,rx_status,cancelled_date,payment_option from `'+os.environ['CB_INSTANCE']+'` t Where type = "prescription" and payment_option = "Pay via Payroll Deduction" and pharmacy != "nan" and ((filled_date >= $screate_date and filled_date <= $ecreate_date) or (cancelled_date >= $screate_date and cancelled_date <= $ecreate_date)) and rx_status in ["Filled","Cancelled"] and tonumber(employee_opc)>0 and filled_date is valued and t.flipt_person_id in (select raw dep_flipt_person_id from `'+os.environ['CB_INSTANCE']+'` where type = "flipt_person_hierarchy")', screate_date = start_date, ecreate_date = end_date)
		paymenttab.adhoc = False
		paymenttab.timeout = 100
		row = 7
		for paymentrow in cb.n1ql_query(paymenttab):
			flipt_person_id = paymentrow['flipt_person_id']
			flipt_person_id = flipt_person_id.strip()
			prescription_id = paymentrow['prescription_id']
			pharmacy = paymentrow['pharmacy']
			location = paymentrow['location']
			routed_date = paymentrow['routed_date']
			filled_date = paymentrow['filled_date']
			drug_cost = paymentrow['drug_cost']
			employee_opc = paymentrow['employee_opc']
			rx_status = paymentrow['rx_status']
			payment_option = paymentrow['payment_option']
			
			# Manuplate data , if status is Cancelled
			if rx_status == 'Cancelled':
				# Cancelled Date is not in Range - Hide Cancel Date and Employee Refund
				if paymentrow['cancelled_date'] >= start_date and paymentrow['cancelled_date'] <= end_date:
					cancel_date = paymentrow['cancelled_date']
					emp_refund = paymentrow['employee_opc']
				else:
					cancel_date = ''
					emp_refund = 0
				
				# Routed Date is not in Range - Hide employee_opc
				if filled_date >= start_date and filled_date <= end_date:
					employee_opc = paymentrow['employee_opc']
				else:
					employee_opc = '0.0'
			else:
				cancel_date = ''
				emp_refund = 0
				#employee_opc = paymentrow['employee_opc']
			# Get Employee Name from True Vault for a Flipt Person id
			obj=User_Class(None,None)
			search_option={'full_document':True,'filter':{'domain_name':{'type':'eq','value':domain,'case_sensitive':False},'flipt_person_id':{'type':'eq','value':flipt_person_id,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
			att,userid = obj.search_user(search_option)
			if att!=None:
				fn = att['first_name']
				ln = att['last_name']
				if att['flipt_person_id'].strip() == flipt_person_id.strip():
					fname = fn
					lname = ln
					empid = att['employee_id']
					ename = lname+', '+fname
			
			else:
				ename = 'Not Found'
				empid = 'Not Found'
				
			if ename == 'Not Found':
				continue
			
			if employee_opc is None or len(employee_opc) == 0:
				employee_opc = '0.0'
			employer_cost = paymentrow['employer_cost']
			if employer_cost is None or len(employer_cost) == 0:
				employer_cost = '0.0'
			
			payroll_deduction = float(employee_opc) - float(emp_refund)
			
			worksheet.write(row, 0, prescription_id,row_format)
			worksheet.write(row, 1, empid,row_format)
			worksheet.write(row, 2, ename,row_format)
			worksheet.write(row, 3, pharmacy,row_format)
			worksheet.write(row, 4, location,row_format)
			worksheet.write(row, 5, routed_date,row_format)
			worksheet.write(row, 6, str(cancel_date),row_format)		
			worksheet.write(row, 7, float(drug_cost),row_format)
			worksheet.write(row, 8, float(employer_cost),row_format)
			worksheet.write(row, 9, float(employee_opc),row_format)
			worksheet.write(row, 10, float(emp_refund),row_format)
			worksheet.write(row, 11, float(payroll_deduction),row_format)
			worksheet.write(row, 12, payment_option,row_format)
			row = row + 1
		worksheet.write(row, 6, "Total : ",header_format)
		worksheet.write(row, 7, '=SUM(H7:H'+str(row)+')',row_format)
		worksheet.write(row, 8, '=SUM(I7:I'+str(row)+')',row_format)
		worksheet.write(row, 9, '=SUM(J7:J'+str(row)+')',row_format)
		worksheet.write(row, 10, '=SUM(K7:K'+str(row)+')',row_format)
		worksheet.write(row, 11, '=SUM(L7:L'+str(row)+')',row_format)

	elif mode == 'SUMMARY':

		# Start from the first cell. Rows and columns are zero indexed.
		row = 0
		col = 0
		location = ''
		subject = 'OPC Summary Report - '+host
		worksheet.insert_image('A1', image_path, {'x_scale': 0.5, 'y_scale': 0.5})

		# Set column Width
		worksheet.set_column('A:A',22)
		worksheet.set_column('B:B',18)
		worksheet.set_column('C:C',23)
		worksheet.set_column('D:D',25)
		worksheet.set_column('E:E',25)
		worksheet.set_column('F:F',25)
		worksheet.set_column('G:G',12)
		worksheet.set_column('H:H',14)
		worksheet.set_column('I:I',40)
		worksheet.set_column('J:J',30)

		# Report Header
		worksheet.merge_range('C1:F2', 'Employee Out of Pocket Cost Report', merge_format)

		# Report parameters
		worksheet.write(3, 0, "Statement Date Range",parameter_format)
		worksheet.write(3, 1, start_date,row_format)
		worksheet.write(3, 2, end_date,row_format)	
		worksheet.write(4, 0, "Domain",parameter_format)
		worksheet.write(4, 1, domain,row_format)
		worksheet.write(3, 4, "Report Generated at ",parameter_format)
		worksheet.write(3, 5, currentdate, row_format)
		worksheet.write(5, 0, "Payroll Date",parameter_format)
		worksheet.write(5, 1, pay_date,row_format)

		# write it out row by row.
		worksheet.write(7, 0, "Employee Number",header_format)
		worksheet.write(7, 1, "Employee Name",header_format)
		worksheet.write(7, 2, "Employee Location",header_format)
		worksheet.write(7, 3, "Drug Cost",header_format)
		worksheet.write(7, 4, "Employer cost",header_format)
		worksheet.write(7, 5, "Employee opc",header_format)
		worksheet.write(7, 6, "Employee Refund",header_format)
		worksheet.write(7, 7, "Payroll Deduction",header_format)
		worksheet.write(7, 8, "Rx Created By",header_format)

		paymenttab = N1QLQuery('select flipt_person_id, SUM(TONUMBER(drug_cost)) as drug_cost,SUM(TONUMBER(CASE WHEN rx_status = "Cancelled" and filled_date >= $screate_date and filled_date <= $ecreate_date THEN employee_opc WHEN rx_status = "Filled" THEN employee_opc ELSE 0 END)) as employee_opc,SUM(TONUMBER(employer_cost)) as employer_cost, SUM(TONUMBER(CASE WHEN rx_status = "Cancelled" and cancelled_date >= $screate_date and cancelled_date <= $ecreate_date THEN employee_opc ELSE 0 END)) as employee_refund from `'+os.environ['CB_INSTANCE']+'` t Where type = "prescription" and pharmacy != "nan" and ((filled_date >= $screate_date and filled_date <= $ecreate_date) or (cancelled_date >= $screate_date and cancelled_date <= $ecreate_date)) and payment_option = "Pay via Payroll Deduction" and rx_status in ["Filled","Cancelled"] and tonumber(employee_opc)>0 and filled_date is valued and t.flipt_person_id in (select raw dep_flipt_person_id from `'+os.environ['CB_INSTANCE']+'` where type = "flipt_person_hierarchy") GROUP BY flipt_person_id order by flipt_person_id',screate_date = start_date, ecreate_date = end_date)
		paymenttab.adhoc = False
		paymenttab.timeout = 100
		row = 8
		for paymentrow in cb.n1ql_query(paymenttab):
			flipt_person_id = paymentrow['flipt_person_id']
			flipt_person_id = flipt_person_id.strip()
			drug_cost = paymentrow['drug_cost']
			employee_opc = paymentrow['employee_opc']
			employer_cost = paymentrow['employer_cost']
			employee_refund = paymentrow['employee_refund']
			payroll_deduction = employee_opc - employee_refund
			payroll_deduction = abs(payroll_deduction)
			
			#Get Employee Flipt Person ID
			emp_flipt_person_id = ''
			emptab = N1QLQuery('select distinct emp_flipt_person_id from `'+os.environ['CB_INSTANCE']+'` Where type = "flipt_person_hierarchy" and dep_flipt_person_id = $person_id',person_id = str(flipt_person_id).strip())
			emptab.adhoc = False
			emptab.timeout = 100
			for emprow in cb.n1ql_query(emptab):
				emp_flipt_person_id = emprow['emp_flipt_person_id']	
				
			# Get Employee Name from True Vault for a Flipt Person id
			obj=User_Class(None,None)
			search_option={'full_document':True,'filter':{'domain_name':{'type':'eq','value':domain,'case_sensitive':False},'flipt_person_id':{'type':'eq','value':emp_flipt_person_id,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
			att,userid = obj.search_user(search_option)
			if att!=None:
				fn = att['first_name']
				ln = att['last_name']
				if att['flipt_person_id'].strip() == emp_flipt_person_id.strip():
					fname = fn
					lname = ln
					empid = att['employee_id']
					ename = lname+', '+fname
					location = att['location']
			
			else:
				ename = 'Not Found'
				empid = 'Not Found'

			if ename == 'Not Found':
				continue

			edname = ''
			# Get Flipt Name from True Vault for a Flipt Person id
			obj=User_Class(None,None)
			search_option={'full_document':True,'filter':{'domain_name':{'type':'eq','value':domain,'case_sensitive':False},'flipt_person_id':{'type':'eq','value':flipt_person_id,'case_sensitive':False},'$tv.status':{'type':'eq','value':'ACTIVATED'}},'filter_type':'and'}
			att,userid = obj.search_user(search_option)
			if att!=None:
				firstd = att['first_name']
				lastd = att['last_name']
				if att['flipt_person_id'].strip() == flipt_person_id.strip():
					fdname = firstd
					ldname = lastd
					edname = ldname+', '+fdname
					
				
			if employee_opc is None or len(str(employee_opc)) == 0:
				employee_opc = '0.0'
				
			if employer_cost is None or len(str(employer_cost)) == 0:
				employer_cost = '0.0'
				
			worksheet.write(row, 0, empid,row_format)
			worksheet.write(row, 1, ename,row_format)
			worksheet.write(row, 2, location,row_format)
			worksheet.write(row, 3, float(drug_cost),row_format)
			worksheet.write(row, 4, float(employer_cost),row_format)
			worksheet.write(row, 5, float(employee_opc),row_format)
			worksheet.write(row, 6, float(employee_refund),row_format)
			worksheet.write(row, 7, float(payroll_deduction),row_format)
			worksheet.write(row, 8, edname,row_format)
			row = row + 1
			
		worksheet.write(row, 2, "Total : ",header_format)
		worksheet.write(row, 3, '=SUM(D7:D'+str(row)+')',row_format)
		worksheet.write(row, 4, '=SUM(E7:E'+str(row)+')',row_format)
		worksheet.write(row, 5, '=SUM(F7:F'+str(row)+')',row_format)
		worksheet.write(row, 6, '=SUM(G7:G'+str(row)+')',row_format)
		worksheet.write(row, 7, '=SUM(H7:H'+str(row)+')',row_format)
		req.no_rec_received=row
	workbook.close()
	
	# Call Reward Redemption Via Payroll
	rewardpayroll(domain,'rewardtransaction','SUMMARY','final',pay_date)
	
	send_to='FliptIntegration@fliptrx.com'
	if os.environ['INSTANCE_TYPE']=='PROD':	
		send_to='DAlberto@GWLabs.com,LPeysekhman@fliptrx.com,CNg@GWLabs.com,FliptIntegration@fliptrx.com,Rjuhring@fliptrx.com,deepthi.gollapudi@nttdata.com,hrpayroll@gwlabs.com,SPal@fliptrx.com'
	#send_to='DWagle@GWLabs.com'
	email_log('ASriperambuduru@GWLabs.com','DWagle@fliptrx.com',send_to,subject,['Processing of OPC Report '+str(file_name),'Payment Exception'],filepath,True)
	#os.remove(filepath)
	
def autoreportrun():
		sysdate=dt.datetime.strptime(str(dt.datetime.today().replace(hour=0,minute=0,second=0,microsecond=0)),'%Y-%m-%d 00:00:00').isoformat()
		
		query=N1QLQuery('Select rx_from_date,rx_to_date,payroll_date from `'+os.environ['CB_INSTANCE']+'` where type="payroll_deductions" and report_run_date=$rrd',rrd=str(sysdate))
		query.timeout=3600
		query.adhoc=False
		for r in cb.n1ql_query(query):
			if 'rx_from_date' in r:
				rx_from_date=r['rx_from_date']
				rx_to_date=r['rx_to_date']
				payroll_date=r['payroll_date']
				generatereport('SUMMARY',rx_from_date,rx_to_date,payroll_date)
				nextrun={}
				nextrun['report_run_date']=dt.datetime.strptime(str(dt.datetime.today().replace(hour=0,minute=0,second=0,microsecond=0)+dt.timedelta(28)),'%Y-%m-%d 00:00:00').isoformat()
				nextrun['payroll_date']=dt.datetime.strptime(str(dt.datetime.today().replace(hour=0,minute=0,second=0,microsecond=0)+dt.timedelta(35)),'%Y-%m-%d 00:00:00').isoformat()
				nextrun['rx_from_date']=dt.datetime.strptime(str(dt.datetime.today().replace(hour=0,minute=0,second=0,microsecond=0)-dt.timedelta(6)),'%Y-%m-%d 00:00:00').isoformat()
				nextrun['rx_to_date']=dt.datetime.strptime(str(dt.datetime.today().replace(hour=23,minute=59,second=59,microsecond=0)+dt.timedelta(21)),'%Y-%m-%d %H:%M:%S').isoformat()
				nextrun['type']='payroll_deductions'
				cb.upsert(str(cb.counter('docid',delta=1).value),nextrun)		

if commandmode=='DETAIL':
	sdate = parser.parse(start_text)
	sdate = sdate.isoformat()
	end_text = end_text+' 23:59:59'
	edate = parser.parse(end_text)
	edate = edate.isoformat()
	print(sdate)
	print(edate)
	generatereport(commandmode,sdate,edate,edate)
	
else:
	autoreportrun()
req.close()