get_domain_information = lambda query_params: "SELECT pepm_pmpm, pepm_rate, pmpm_rate FROM `{bucket}` WHERE domain='{domain}' AND type='domain'".format(
    bucket=query_params["bucket"], domain=query_params["domain"]
)
