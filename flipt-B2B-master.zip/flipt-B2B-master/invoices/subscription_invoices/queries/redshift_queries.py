get_users = (
    lambda query_params: "SELECT flipt_person_id, benefit_plan_name, coverage_effective_date, coverage_termination_date, person_code,"
    "domain_name FROM {workspace}.dw_users WHERE domain_name='{domain_name}' AND '{coverage_effective_date}' "
    ">= "
    "coverage_effective_date AND '{coverage_termination_date}' <= coverage_termination_date".format(
        workspace=query_params["workspace"],
        domain_name=query_params["domain_name"],
        coverage_effective_date=query_params["coverage_effective_date"],
        coverage_termination_date=query_params["coverage_termination_date"],
    )
)

get_invoice_ids = lambda query_params: "SELECT invoice_id FROM {workspace}.dw_users_invoice ORDER BY invoice_id DESC LIMIT 1".format(
    workspace=query_params["workspace"]
)

insert_dw_users_invoices = lambda query_params: """
    COPY {workspace}.{table_name} FROM '{s3_path}'
    CREDENTIALS 'aws_access_key_id={aws_access_key_id};aws_secret_access_key={aws_secret_access_key}'
    CSV DELIMITER ',' ACCEPTINVCHARS ACCEPTANYDATE;
""".format(
    workspace=query_params["workspace"],
    table_name=query_params["table_name"],
    s3_path=query_params["s3_path"],
    aws_access_key_id=query_params["aws_access_key_id"],
    aws_secret_access_key=query_params["aws_secret_access_key"],
)


get_pervious_invoice_date = lambda query_params: """
    SELECT DISTINCT(invoice_start_date), invoice_end_date
    FROM {workspace}.{table_name}
    WHERE invoice_start_date != '{current_invoice_date}'
    ORDER BY invoice_start_date DESC
""".format(
    workspace=query_params["workspace"],
    table_name=query_params["table_name"],
    current_invoice_date=query_params["current_invoice_date"],
)

get_recently_added_users = lambda query_params: """
    SELECT * 
    FROM {workspace}.{table_name}
    WHERE invoice_start_date = '{current_invoice_start_date}' AND flipt_person_id NOT IN (
        SELECT flipt_person_id
        FROM {workspace}.{table_name}
        WHERE invoice_start_date = '{previous_invoice_start_date}'
    )
    """.format(
    workspace=query_params["workspace"],
    table_name=query_params["table_name"],
    current_invoice_start_date=query_params["current_invoice_start_date"],
    previous_invoice_start_date=query_params["previous_invoice_start_date"],
)

insert_into_dw_users_invoice_summary = lambda query_params: """
    INSERT INTO {workspace}.{table} ({columns}) VALUES ({values})
""".format(
    workspace=query_params["workspace"],
    columns=query_params["columns"],
    values=query_params["values"],
    table=query_params["table"],
)
