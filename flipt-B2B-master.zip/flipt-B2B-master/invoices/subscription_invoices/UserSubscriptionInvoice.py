from argparse import ArgumentParser
from csv import DictWriter
from os import getenv
from datetime import datetime
from boto3 import client
from tempfile import NamedTemporaryFile

from couchbase.cluster import Cluster, PasswordAuthenticator
from couchbase.n1ql import N1QLQuery
from psycopg2 import connect

import queries.couchbase_queries as cb_query
import queries.redshift_queries as rds_query


subscription_invoice_arguments = ArgumentParser()
subscription_invoice_arguments.add_argument("-start_date", "--start_date")
subscription_invoice_arguments.add_argument("-end_date", "--end_date")
subscription_invoice_arguments.add_argument("-d", "--domain_name")
subscription_invoice_arguments.add_argument("-f", "--frequency")

subscrion_arguments = subscription_invoice_arguments.parse_args().__dict__

START_DATE = subscrion_arguments.get("start_date")
END_DATE = subscrion_arguments.get("end_date")
DOMAIN_NAME = subscrion_arguments.get("domain_name")
FREQUENCY = subscrion_arguments.get("frequency")


__FILE_NAME__ = f"users_invoices_{datetime.now().date()}.csv"


__SCHEMAS__ = {
    "dw_users_invoice": {
        "columns": (
            "domain",
            "flipt_person_id",
            "plan_name",
            "plan_start_date",
            "plan_end_date",
            "invoice_start_date",
            "invoice_end_date",
            "invoice_id",
            "invoice_date",
            "create_date",
            "person_code",
        )
    },
    "dw_users_invoice_summary": {
        "columns": (
            "domain",
            "invoice_date",
            "count_of_people_added_last_month",
            "count_of_active_members",
            "pepm_pmpm_rate",
            "invoice_id",
            "invoice_month",
            "plan_start_date",
            "plan_end_date",
            "total_amount",
            "update_date",
            "create_date",
        )
    },
}


class SubscriptionInvoice(object):
    def __init__(self):
        self.__RDS_DBNAME = getenv("RDS_DBNAME")
        self.__RDS_USER_ID = getenv("RDS_USER_ID")
        self.__RDS_PASSWORD = getenv("RDS_PASSWORD")
        self.__RDS_HOST = getenv("RDS_HOST")
        self.__RDS_PORT = getenv("RDS_PORT")
        self.__rds_connection = connect(
            f"dbname={self.__RDS_DBNAME} user={self.__RDS_USER_ID} password={self.__RDS_PASSWORD} host="
            f"{self.__RDS_HOST} port={self.__RDS_PORT}"
        )

        self.__START_DATE = START_DATE + " 00:00:00"
        self.__END_DATE = END_DATE + " 23:59:59"

        self.__CB_HOST = getenv("CB_HOST")
        self.__CB_USER = getenv("CB_USER")
        self.__CB_PASSWORD = getenv("CB_PASSWORD")
        self.__CB_BUCKET = getenv("CB_BUCKET")

        self.__cb_cluster = Cluster(self.__CB_HOST)
        self.__cb_authenticator = PasswordAuthenticator(
            self.__CB_USER, self.__CB_PASSWORD
        )
        self.__cb_cluster.authenticate(self.__cb_authenticator)
        self.__cb_cursor = self.__cb_cluster.open_bucket(self.__CB_BUCKET)

        self.__AWS_ACCESS_KEY_ID = getenv("AWS_ACCESS_KEY_ID")
        self.__AWS_SECRET_ACCESS_KEY = getenv("AWS_SECRET_ACCESS_KEY")
        self.__REGION_NAME = getenv("S3_REGION_NAME")
        self.__BUCKET_NAME = getenv("S3_BUCKET_NAME")
        self.__S3_URL = getenv("S3_URL")
        self.__s3 = client(
            "s3",
            aws_access_key_id=self.__AWS_ACCESS_KEY_ID,
            aws_secret_access_key=self.__AWS_SECRET_ACCESS_KEY,
            region_name=self.__REGION_NAME,
        )

        self.user_rows = []
        self.rate = 0
        self.invoice_id = 0
        self.__invoice_date = datetime.now().date()

    def get_users_rds(self, is_pepm):
        with self.__rds_connection.cursor() as cursor:
            query = rds_query.get_users(
                {
                    "domain_name": DOMAIN_NAME,
                    "coverage_effective_date": self.__START_DATE,
                    "coverage_termination_date": self.__END_DATE,
                    "workspace": "flipt_dw",
                }
            )

            if is_pepm:
                query = query + " AND relationship='Self'"

            cursor.execute(query)

            results = cursor.fetchall()

            columns = [
                "flipt_person_id",
                "benefit_plan_name",
                "coverage_effective_date",
                "coverage_termination_date",
                "person_code",
                "domain_name",
            ]

            mapped_results = [dict(zip(columns, result)) for result in results]

            return mapped_results

    def get_domain_information(self):
        query = N1QLQuery(
            cb_query.get_domain_information(
                {"domain": DOMAIN_NAME, "bucket": self.__CB_BUCKET}
            )
        )

        query_results = self.__cb_cursor.n1ql_query(query)

        if query_results:
            return query_results.get_single_result()

        return None

    def get_recent_invoice_id(self):
        with self.__rds_connection.cursor() as cursor:
            query = rds_query.get_invoice_ids({"workspace": "flipt_dw"})

            cursor.execute(query)
            results = cursor.fetchone()

            next_invoice_id = int(results[0]) + 1
            return str(next_invoice_id)

    def _prepare_rows(self, user_rows, invoice_id):
        rows = []
        for user in user_rows:
            rows.append(
                {
                    "domain": user["domain_name"],
                    "flipt_person_id": user["flipt_person_id"],
                    "invoice_date": self.__invoice_date.isoformat(),
                    "invoice_end_date": self.__END_DATE,
                    "invoice_start_date": self.__START_DATE,
                    "invoice_id": self.invoice_id,
                    "person_code": user["person_code"],
                    "plan_name": user["benefit_plan_name"],
                    "plan_end_date": user["coverage_termination_date"],
                    "plan_start_date": user["coverage_effective_date"],
                }
            )
        return rows

    def __set_shared_attributes(self):
        is_pepm = False

        domain_information = self.get_domain_information()
        if not domain_information:
            return None

        if domain_information["pepm_pmpm"] == "PEPM":
            self.rate = domain_information["pepm_rate"]
            is_pepm = True
        else:
            self.rate = domain_information["pmpm_rate"]

        rds_users = self.get_users_rds(is_pepm)
        if not rds_users:
            return None

        self.invoice_id = self.get_recent_invoice_id()

        self.user_rows = self._prepare_rows(rds_users, self.invoice_id)

    def generate_dw_invoice(self):
        self.__set_shared_attributes()

        rows_being_written = []

        user_invoice_file = NamedTemporaryFile(mode="ab")

        with open(user_invoice_file.name, mode="w") as csvfile:
            dict_writer = DictWriter(
                csvfile, __SCHEMAS__["dw_users_invoice"]["columns"]
            )
            dict_writer.writerows(self.user_rows)

        self.__s3.upload_file(
            user_invoice_file.name, self.__BUCKET_NAME, __FILE_NAME__
        )

        query_to_insert = rds_query.insert_dw_users_invoices(
            {
                "workspace": "flipt_dw",
                "table_name": "dw_users_invoice",
                "s3_path": f"{self.__S3_URL}/{__FILE_NAME__}",
                "aws_access_key_id": self.__AWS_ACCESS_KEY_ID,
                "aws_secret_access_key": self.__AWS_SECRET_ACCESS_KEY,
            }
        )

        with self.__rds_connection.cursor() as cursor:
            cursor.execute(query_to_insert)
            self.__rds_connection.commit()

        user_invoice_file.close()

    def generate_dw_invoice_summary(self):
        summary_invoice_row = {}
        total_amount = 0.0

        for user in self.user_rows:
            total_amount += float(self.rate)

        month = self.__invoice_date.month
        year = str(self.__invoice_date.year)

        if month < 10:
            month = "0" + str(month)
        else:
            month = str(month)

        summary_invoice_row.update(
            {
                "domain": DOMAIN_NAME,
                "invoice_date": self.__invoice_date.isoformat(),
                "count_of_people_added_last_month": 0,
                "count_of_active_members": len(self.user_rows) + 1,
                "pepm_pmpm_rate": self.rate,
                "invoice_id": self.invoice_id,
                "invoice_month": month + str(year),
                "plan_start_date": self.user_rows[0]["plan_start_date"],
                "plan_end_date": self.user_rows[0]["plan_end_date"],
                "total_amount": str(total_amount),
            }
        )

        values = ""

        number_of_added_users = 0
        recently_added_users = []
        previous_invoice_start_date = ""
        previous_invoice_end_date = ""
        with self.__rds_connection.cursor() as cursor:

            query = rds_query.get_pervious_invoice_date(
                {
                    "workspace": "flipt_dw",
                    "table_name": "dw_users_invoice",
                    "current_invoice_date": self.__START_DATE,
                }
            )
            cursor.execute(query)

            result = cursor.fetchone()
            if result:
                previous_invoice_start_date, previous_invoice_end_date = result

                with self.__rds_connection.cursor() as cursor:
                    query = rds_query.get_recently_added_users(
                        {
                            "workspace": "flipt_dw",
                            "table_name": "dw_users_invoice",
                            "current_invoice_start_date": self.__START_DATE,
                            "previous_invoice_start_date": previous_invoice_start_date,
                        }
                    )

                    cursor.execute(query)

                    recently_added_users_result = cursor.fetchall()

                    recently_added_users = list(
                        filter(
                            lambda user: user[5] >= previous_invoice_start_date,
                            recently_added_users_result,
                        )
                    )

                    if recently_added_users:
                        number_of_added_users = len(recently_added_users) + 1

        additional_balance = 0

        if number_of_added_users:
            additional_balance += number_of_added_users * float(self.rate)
            summary_invoice_row[
                "count_of_people_added_last_month"
            ] = number_of_added_users
            summary_invoice_row["total_amount"] = (
                total_amount + additional_balance
            )
            with self.__rds_connection.cursor() as cursor:
                for user in recently_added_users:
                    user = list(user)
                    user[5] = previous_invoice_start_date
                    user[6] = previous_invoice_end_date
                    previous_user_invoice = ",".join(
                        [f"{value!r}" for value in user]
                    )

                    query = rds_query.insert_into_dw_users_invoice_summary(
                        {
                            "workspace": "flipt_dw",
                            "table": "dw_users_invoice",
                            "columns": ",".join(
                                __SCHEMAS__["dw_users_invoice"]["columns"]
                            ),
                            "values": previous_user_invoice,
                        }
                    )
                    # import pdb;pdb.set_trace()
                    cursor.execute(query)
                    self.__rds_connection.commit()

        summary_invoice_row["create_date"] = self.__invoice_date.isoformat()
        summary_invoice_row["update_date"] = self.__invoice_date.isoformat()
        for value in __SCHEMAS__["dw_users_invoice_summary"]["columns"]:
            values += f"'{summary_invoice_row[value]}',"

        values = values[:-1]

        with self.__rds_connection.cursor() as cursor:
            query = rds_query.insert_into_dw_users_invoice_summary(
                {
                    "workspace": "flipt_dw",
                    "table": "dw_users_invoicesummary",
                    "columns": ",".join(
                        __SCHEMAS__["dw_users_invoice_summary"]["columns"]
                    ),
                    "values": values,
                }
            )
            # import pdb;pdb.set_trace()
            cursor.execute(query)
            self.__rds_connection.commit()


invoices = SubscriptionInvoice()
invoices.generate_dw_invoice()
invoices.generate_dw_invoice_summary()
