#!/usr/bin/env bash
export RDS_DBNAME=flipt_dw_dev
export RDS_USER_ID=admin
export RDS_PASSWORD=A123456a
export RDS_HOST=dwdev.cdbj5aqvbczt.us-east-1.redshift.amazonaws.com
export RDS_PORT=5439
export CB_HOST=couchbase://10.51.2.254
export CB_USER=dev-backend.python-scripts
export CB_PASSWORD=D08pzWmXY630
export CB_BUCKET=dev-fliptrx-app
export AWS_ACCESS_KEY_ID=AKIAJQLYSOVF2LGIUMAQ
export AWS_SECRET_ACCESS_KEY=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
export S3_REGION_NAME=us-east-1
export S3_BUCKET_NAME=flipt-dwdev
export S3_URL=s3://flipt-dwdev
python3 UserSubscriptionInvoice.py -d=$1 -start_date=$2 -end_date=$3
