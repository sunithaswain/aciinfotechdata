########################################
# !/usr/bin/env python
# title                 : exclusion_update.py
# description           : Update exclusion document from file data
# author                : Rajesh Acharya
# date created          : 20190607
# date last modified    : 20190118 12:16
# version               : 0.1
# maintainer            :
# email                 :
# status                :
# Python Version: 3.5.2
# usage                 : python exclusion_update.py -t exclusions -f exclusions_MMDDYYYY.xlsx -m DRAFT
# Revisions:
# Version        RevisedBy    Date        Change description
# -------        ---------    --------    ------------------
#
# #######################################

import os
import sys
if __name__ == '__main__':
    rootdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


import sys
from datetime import datetime
from utils import commandline
from utils.helper_functions import cb_authenticate, populate_dict

path = os.environ['CB_DATA']
dn, filetype, filename, mode = commandline.main(sys.argv[1:])

cb = cb_authenticate()

logpath = path + '/' + filetype + '/log/log' + datetime.now().strftime("%Y%m%d%H%M") + '.txt'
logfile = open(logpath, "w")
logfile.write("=" * 62 + "\r\n")
logfile.write("=============== exclusions document Update Log =================" + "\r\n")
logfile.write("Start time is " + str(datetime.now()) + "\r\n")

def exclusions(cb_handle, lf, base_path, ftype, fname, wr_mode):
    import pprint
    import pandas as pd
    from couchbase import FMT_JSON
    from couchbase.n1ql import N1QLQuery

    doc_count = 0
    rx = pd.read_excel(base_path + '/' + ftype + '/' + fname)
    print("Running update/insert ... ")
    lf.write("No. of records in file: " + str(rx.shape[0]) + "\r\n")

    for idx, row in rx.iterrows():
        metaid = ''
        created_date = None

        data_dict = populate_dict(rx, row)

        print("processing domain: %s" %(data_dict['domain_name']))
        lf.write("Inserting/Updating domain: %s\r\n" %(data_dict['domain_name']))
        data_dict['excluded_drug_name'] = data_dict['excluded_drug_name'].split(',')
        data_dict['excluded_pharmacy'] = data_dict['excluded_pharmacy'].split(',')
        data_dict['type'] = 'exclusions'

        doc_count += 1

        query = N1QLQuery('SELECT META().id as id, created_date ' +
                          'FROM `' + os.environ['CB_INSTANCE']+'` ' +
                          'WHERE type="exclusions" and domain_name=$dname ' +
                          'and plan_name=$pname and plan_year=$pyr',
                          dname=data_dict['domain_name'],
                          pname=data_dict['plan_name'],
                          pyr=data_dict['plan_year'])
        query.timeout = 7200
        result = cb_handle.n1ql_query(query)

        for p in result:
            metaid = p['id']
            created_date = p['created_date']

        if wr_mode.upper().strip() == 'FINAL':
            if metaid != '':
                data_dict['created_date'] = created_date
                data_dict['update_date'] = str(datetime.strptime(str(datetime.now()),
                                                                 "%Y-%m-%d %H:%M:%S.%f").isoformat())
                cb_handle.upsert(str(metaid), data_dict, format=FMT_JSON)
            else:
                curr_time = str(datetime.strptime(str(datetime.now()), "%Y-%m-%d %H:%M:%S.%f").isoformat())
                data_dict['created_date'] = curr_time
                data_dict['update_date'] = curr_time
                cb_handle.upsert(str(cb_handle.counter('docid', delta=1).value), data_dict, format=FMT_JSON)
        pprint.pprint(data_dict, stream=lf)
        lf.write("-"*50 + "\r\n")
    return doc_count


total_records_update = exclusions(cb, logfile, path, filetype, filename, mode)

logfile.write('%s records are updated \r\n' % total_records_update)
logfile.write("End time is " + str(datetime.now()) + "\r\n")

logfile.write("="*62 + "\r\n")
logfile.close()

print("Done with Inserts/Updates for exclusions")
