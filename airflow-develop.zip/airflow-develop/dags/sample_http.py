# from datetime import datetime, timedelta, time
# from base64 import b64encode
# from airflow import DAG
# from airflow.operators.http_operator import SimpleHttpOperator
# from airflow.operators.python_operator import PythonOperator


# default_args = {
#     "owner": "airflow",
#     "depends_on_past": False,
#     "start_date": datetime(2015, 6, 1),
#     "email": ["airflow@airflow.com"],
#     "email_on_failure": False,
#     "email_on_retry": False,
#     "retries": 1,
#     "retry_delay": timedelta(minutes=5),
# }

# dag =  DAG("sample_http_load", default_args=default_args, schedule_interval=timedelta(1))


# """
#  task_id='get_labrador',
#     method='GET',
#     http_conn_id='http_default',
#     endpoint='api/breed/labrador/images',
#     headers={"Content-Type": "application/json"},
# """

# def puller(**kwargs):
#     value = kwargs
#     print(value)

# truevault_user_call = SimpleHttpOperator(
#     conn_id='sample_vault',
#     task_id='sample_truevault_user_fetch',
#     http_conn_id='sample_truevault_user_load',
#     endpoint='',
#     method='GET',
#     xcom_push=True,
#     headers={'Authorization': f"Basic  {b64encode('8defa0cd-b297-4dce-a1fe-22d4a5281975:'.encode('utf-8')).decode(
#     'ascii')}"},
#     dag=dag,

# )

# python_operator = PythonOperator(
#     task_id =  'truevault_user_fetch',
#     provide_context=True,
#     python_callable=puller,
#     dag = dag
# )

# python_operator << truevault_user_call
