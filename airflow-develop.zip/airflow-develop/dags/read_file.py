#!/usr/bin/env python3
import sys
from ast import literal_eval
from base64 import b64decode
from copy import deepcopy
from csv import DictReader
from datetime import datetime
from json import loads

from pandas import DataFrame

df = DataFrame()


def _set_flipt_member_id(user, primary):
    if primary:
        return primary['flipt_person_id'] + user['person_code']

    return user['flipt_person_id'] + user['person_code']


def fetch_claimed_date_dependend(dependents):
    dependent_claimed = []
    for dependent in dependents:
        if dependent.get("claimed") and dependent.get('flipt_person_id'):
            dependent_claimed.append({
                'flipt_person_id': dependent['flipt_person_id'],
                'claimed': _get_datetime_from_epoch(dependent['claimed'])
            })

    return dependent_claimed


def _set_eligibility(eligibility):
    return {
        'coverage_termination_date': eligibility.get('coverage_termination_date', ''),
        'coverage_effective_date': eligibility.get('coverage_effective_date', ''),
        'benefit_plan_name': eligibility.get('benefit_plan_name', ''),
        'plan_year': eligibility.get('plan_year', ''),
        'coverage_tier_name': eligibility.get('coverage_tier_name', ''),
        'cobra_effective_date': eligibility.get('cobra_effective_date', ''),
        'cobra_termination_date': eligibility.get('cobra_termination_date', '')
    }


def _convert_to_datetime(date_string):
    if 'T' in date_string:
        try:
            return datetime.strptime(date_string, "%Y-%m-%dT%H:%M:%S")
        except ValueError as _:
            return datetime.strptime(date_string, "%Y-%m-%dT%H:%M:%S.%f")
    elif len(date_string.split(' ')) == 1:
        return datetime.strptime(date_string, "%Y-%m-%d")
    try:
        return datetime.strptime(date_string, "%Y-%m-%d %H:%M:%S")
    except ValueError as _:
        return datetime.strptime(date_string, "%Y-%m-%d %H:%M:%S.%f")


def _get_eligibility(user, eligibility, primary):
    if primary:
        dependent_eligibility = eligibility
        if not eligibility.get('benefit_plan_name'):
            dependent_primary_eligibility = list(filter(
                lambda primary_eligibility:
                _convert_to_datetime(eligibility['coverage_effective_date']) >= _convert_to_datetime(
                    primary_eligibility['coverage_effective_date']) and _convert_to_datetime(
                    eligibility['coverage_effective_date']) <= _convert_to_datetime(
                    primary_eligibility['coverage_termination_date']), primary['eligibility']))

            if dependent_primary_eligibility:
                dependent_eligibility = dependent_primary_eligibility[0]
                dependent_eligibility['coverage_effective_date'] = eligibility['coverage_effective_date']
                dependent_eligibility['coverage_termination_date'] = eligibility['coverage_termination_date']
                dependent_eligibility['cobra_effective_date'] = eligibility['cobra_effective_date']
                dependent_eligibility['cobra_termination_date'] = eligibility['cobra_termination_date']
                dependent_eligibility['plan_year'] = eligibility['plan_year']

            user.update({
                **_set_eligibility(dependent_eligibility)
            })
            return user

    user.update({**_set_eligibility(eligibility)})
    return user


def _get_personal_phone(personal_phones):
    try:
        personal_phone = list(filter(lambda phone: phone['preferred'], personal_phones))
    except Exception as ex:
        personal_phone = list(filter(lambda phone: phone['preferred'], literal_eval(personal_phones)))

    if personal_phone:
        return personal_phone[0]['phone_number']
    else:
        try:
            verified_personal_phone = list(filter(lambda phone: phone['verified'], personal_phones))
        except Exception as ex:
            verified_personal_phone = list(filter(lambda phone: phone['verified'], literal_eval(personal_phones)))
        if verified_personal_phone:
            return verified_personal_phone[0]['phone_number']

        return ""


def _get_datetime_from_epoch(epoch_time):
    try:
        time_miliseconds = int(epoch_time) / 1000.0
        claimed_time = datetime.fromtimestamp(time_miliseconds)

        return "-".join([str(claimed_time.year), str(claimed_time.month), str(claimed_time.day)])
    except Exception as ex:
        return ""


def _set_user_attributes(user, primary=None):
    user_by_eligibility = []

    group = user.get('group')
    domain = user.get('domain_name')

    user_attributes = {
        'relationship': user.get('relationship').capitalize() if user.get('relationship', False) else 'Self',
        'user_type': user.get('type', ''),
        'flipt_person_id': user.get('flipt_person_id', ''),
        'flipt_member_id': _set_flipt_member_id(user, primary),
        'employee_id': user.get('employee_id', ''),
        'person_code': user.get('person_code', ''),
        'group': group if group else primary.get('group', ''),
        'parent_id': user.get('parent_id', ''),
        'terms_compliance_accepted_date': user.get('terms_compliance_accepted_date', ''),
        'terms_hipaa_accepted_date': user.get('terms_hipaa_accepted_date', ''),
        'domain_name': domain if domain else primary.get('domain_name'),
        'create_date': user.get('created_at', ''),
        'update_date': user.get('updated_at', ''),
        'tpa_member_id': user.get('tpa_member_id', ''),
        'uid': user.get('UID', ''),
        'employment_status': user.get('employment_status', '').capitalize(),
        'claimed': _get_datetime_from_epoch(user.get('claimed')),
        'personal_phones': _get_personal_phone(user.get('personal_phones', []))
    }

    for eligibility in user.get('eligibility', []):
        user = deepcopy(user_attributes)

        user_eligibility = _get_eligibility(user, eligibility, primary)
        user_by_eligibility.append(user_eligibility)

    return user_by_eligibility


dependents = []
with open(sys.argv[1], 'r') as csvfile:
    reader = DictReader(csvfile, ['attribute'])
    for row in reader:
        user_document = loads(b64decode(row['attribute']).decode('utf-8'))

        if user_document.get('person_code', '') == '01':
            primary_user = _set_user_attributes(user_document, None)

            primary_user_frame = DataFrame(primary_user)
            if primary_user and primary_user[0]:
                df = df.append(primary_user_frame, ignore_index=True)

            for dependent in user_document.get('dependents', []):
                if not dependent.get('eligibility'):
                    continue
                dependent_user_frame = _set_user_attributes(dependent, user_document)
                df = df.append(dependent_user_frame, ignore_index=True)

        else:
            dependents.append(user_document)

dependend_claimed = fetch_claimed_date_dependend(dependents)

for dependent in dependend_claimed:
    df.loc[df['flipt_person_id'] == dependent['flipt_person_id'], 'claimed'] = dependent['claimed']

df = df[['relationship', 'user_type', 'flipt_person_id', 'flipt_member_id', 'personal_phones',
         'employee_id', 'claimed', 'coverage_termination_date', 'coverage_effective_date', 'benefit_plan_name',
         'plan_year', 'coverage_tier_name', 'domain_name', 'employment_status',
         'cobra_effective_date', 'cobra_termination_date', 'person_code', 'group', 'parent_id',
         'terms_hipaa_accepted_date', 'terms_compliance_accepted_date', 'create_date', 'update_date',
         'tpa_member_id', 'uid']]

# df.to_csv('sample.csv', header=False, index=False, encoding='utf-8')
with open(sys.argv[2], 'w') as file:
    df.to_csv(file, header=False, index=False, encoding='utf-8')
# print(sys.argv)
