from datetime import datetime, timedelta
from uuid import uuid4

from airflow import DAG
from airflow.operators.s3_file_transform_operator import S3FileTransformOperator
from operators.RedshiftUpsertOperator import RedshiftUpsertOperator
from operators.TruevaultOperator import TruevaultOperator
from utils.error_handler import error_handler
from utils.success_handler import success_handler

import os

default_args = {
    'depend_on_past': False,
    'email': '',
    'email_on_failure': False,
    'email_on_retry': False,
    'on_failure_callback': error_handler,
    'on_success_callback': success_handler,
    'on_success_cleanup': True,
    'owner': "airflow",
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
    'start_date': datetime(2020, 2, 2),
}

dag = DAG('dw_users_upload', default_args=default_args)

__TRANSFORMED_DW_USERS_FILE_NAME__ = f'truevault_transformed_{uuid4().hex}'


truevault_user_call = TruevaultOperator(task_id="fetch_truevault_users",
                                        action="READ",
                                        query={
                                            "filter": {
                                                "flipt_person_id": {
                                                    "type": "wildcard",
                                                    "value": "*"
                                                },
                                                "$tv.status": {
                                                    "type": "eq",
                                                    "value": "ACTIVATED"
                                                }
                                            },
                                            "full_document": True,
                                        },
                                        dag=dag)

transform_users = S3FileTransformOperator(
    task_id='fetch_users_from_s3',
    source_aws_conn_id='s3_destination',
    dest_aws_conn_id='s3_destination',
    dest_s3_key=f's3://flipt-airflow/truevault_transformed_2',
    source_s3_key='s3://flipt-airflow/initial_load',
    transform_script=f'{os.getcwd()}/dags/read_file.py',
    dag=dag
)

redshift_upser = RedshiftUpsertOperator(
    task_id='redshift_upsert',
    source_s3_key=f's3://flipt-airflow/truevault_transformed_2',
    source_aws_conn_id='s3_destination',
    src_table='flipt_dw.dw_users',
    source_aws_connection_id='s3_destination',
    dag=dag,
    src_redshift_connection_id='redshift_connection'
)

truevault_user_call >> transform_users >> redshift_upser
