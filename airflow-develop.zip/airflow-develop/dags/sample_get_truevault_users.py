from datetime import timedelta

from airflow import DAG
from airflow.utils.dates import days_ago

from operators.TruevaultOperator import TruevaultOperator
from utils.error_handler import error_handler
from utils.success_handler import success_handler

default_args = {
    'depend_on_past': False,
    'email': '',
    'email_on_failure': False,
    'email_on_retry': False,
    'on_failure_callback': error_handler,
    'on_success_callback': success_handler,
    'on_success_cleanup': True,
    'owner': "sample_airflow",
    'retries': 0,
    'retry_delay': timedelta(minutes=5),
    'start_date': days_ago(1),
}

query = {
    "filter": {
        "flipt_person_id": {
            "type": 'wildcard',
            "value": '*'
        },
        "$tv.status": {
            "type": 'eq',
            "value": 'ACTIVATED'
        },
    },
    "filter_type": 'and',
    "full_document": True,
}

dag = DAG("sample_get_truevault_users", default_args=default_args)

truevault_user_call = TruevaultOperator(dag=dag,
                                        action="READ",
                                        query=query,
                                        task_id="fetch_truevault_users",
                                        )

truevault_user_call
