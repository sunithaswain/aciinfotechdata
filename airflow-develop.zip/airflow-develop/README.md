# WELCOME TO FLIPT AIRFLOW #

## What is Airflow ##
https://airflow.apache.org/

## Requirements ##
- **Docker** - https://www.docker.com/ (Dockerhub account requried. Coordinate with David Graves.)
- **Flask8 Linter** - https://code.visualstudio.com/docs/python/linting

## Code Development ##
- Unless specified all feature/bugfix branches **WILL** branch off the develop branch.
- Upon development completion **ALL** feature/bugfix branches should require a pull request.

### Development Branches ###
- ***New Feature Development*** - `git checkout -b feature/{JIRA-ID}`
- ***Bug Fixes*** - `git checkout -b bugfix/{JIRA-ID}`
- ***Enhancement*** - `git checkout -b enhancements/{JIRA-ID}`

## Getting Started ##
- `git clone FliptRx/airflow`
- `docker-compose up`

`http://localhost:8080`


**Take Pride in your work. Excellence Only.**
