from base64 import b64encode
from json import dumps

from airflow.hooks.http_hook import HttpHook

class TruevaultHook(HttpHook):
    def __init__(self, context, *args, **kwargs):
        self.context = context
        self.http_conn_id = "truevault_connection"

    def search(self, query, *args, **kwargs):
        endpoint = "/users/search"
        self.method = "POST"

        encoded_query = b64encode(dumps(query).encode("utf-8"))
        data = {"search_option": encoded_query}

        response = self.__http_run(endpoint, data=data)
        attributes = []
        docs = response.json()["data"]["documents"]

        for doc in docs:
            attributes.append({'attribute': doc.get('attributes', "")})

        return attributes

    def list_all(self):
        endpoint = "/v1/users"
        self.method = "GET"

    def read_user(self, uids, *args, **kwargs):
        endpoint = "/v2/users"
        self.method = "GET"

    def upsert(self, query, *args, **kwargs):
        pass

    def delete(self, query, *args, **kwargs):
        endpoint = "/v1/users"
        self.method = "DELETE"

    def __http_run(self, endpoint, data, *args, **kwargs):
        tv_key = self.get_connection(self.http_conn_id).password
        api_key = b64encode(f"{tv_key}:".encode("utf-8")).decode("utf-8")

        return self.run(endpoint,
                        data=data,
                        headers={
                            "Authorization": f"Basic {api_key}",
                        })

    def __create_user(self):
        endpoint = "v1/users"
        self.method = "POST"

    def __update_user(self):
        endpoint = "/v1/users"
        self.method = "PUT"
