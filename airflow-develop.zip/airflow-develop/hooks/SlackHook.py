from airflow.contrib.operators.slack_webhook_operator \
    import SlackWebhookOperator
from airflow.hooks.base_hook import BaseHook
from airflow.models import Variable

SLACK_CONN_ID = "slack_default"
SLACK_CHANNEL = Variable.get("SLACK_CHANNEL")
SLACK_USERNAME = Variable.get("SLACK_USERNAME")

class SlackHook(SlackWebhookOperator):
    def __init__(self, message, attachments=None, *args, **kwargs):
        #TODO: GO through object to get password.
        SLACK_PASSWORD = BaseHook.get_connection(SLACK_CONN_ID).password

        super(SlackHook, self).__init__(attachments=attachments,
                                        channel=SLACK_CHANNEL,
                                        message=message,
                                        http_conn_id=SLACK_CONN_ID,
                                        task_id=SLACK_CONN_ID,
                                        username=SLACK_USERNAME,
                                        webhook_token=SLACK_PASSWORD,
                                        *args, **kwargs)
