from airflow.exceptions import AirflowException
from airflow.hooks.dbapi_hook import DbApiHook
from couchbase.cluster import Cluster, PasswordAuthenticator

class CouchbaseHook(DbApiHook):
    conn_name_attr = 'couchbase_dev'
    default_conn_name = conn_name_attr

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.__connection = kwargs.pop('connection')
        self.__schema = kwargs.pop('schema')
        if not self.__connection or not self.__schema:
            raise AirflowException('Missing either connection or  bucket from the connection')

    def get_conn(self):
        conn_att = self.get_connection(getattr(self, self.conn_name_attr))
        cluster = Cluster(
            conn_att.host
        )

        authenticator = PasswordAuthenticator(conn_att.login, conn_att.password)
        cluster.authenticate(authenticator)

        cb = cluster.open_bucket(conn_att.schema)

        return cb
