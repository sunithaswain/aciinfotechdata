from tempfile import NamedTemporaryFile

from airflow.hooks.S3_hook import S3Hook
from airflow.models import Variable

class FliptS3Hook(S3Hook):
    def __init__(self, context, bucket_name=Variable.get("AWS_BUCKET_NAME"),
                 *args, **kwargs):
        super().__init__(*args, **kwargs)

        task_instance = context.get('task_instance')

        self.bucket_name = bucket_name
        self.context = context
        self.directory = task_instance.dag_id or "misc"
        self.file_name = f"{self.directory}/{self.context.get('run_id')}"

        self.log.info(f">>>>>>> filename: {self.file_name}")

    def upload_file(self, temp_file_name, *args, **kwargs):
        self.log.info(f">>>> Uploading file ({self.file_name})...")
        self.load_file(
            bucket_name=self.bucket_name,
            key=self.file_name,
            filename=temp_file_name,
            replace=True,)

    def clean_up(self, clear_all=False):
        keys = (
            self.list_keys(bucket_name=self.bucket_name,
                           prefix=self.directory)
            if clear_all else [self.file_name])

        self.delete_objects(bucket=self.bucket_name, keys=keys)
        self.log.info(f">>>> Deleting {keys}")

    def file_download(self):
        source_s3_key_object = self.get_key(self.file_name, self.bucket_name)

        with NamedTemporaryFile('wb') as source_file:
            source_s3_key_object.download_fileobj(Fileobj=source_file)
            source_file.flush()

        results = source_s3_key_object.get()['Body'].read() \
                                                    .decode('utf-8') \
                                                    .split("\n")

        return results
