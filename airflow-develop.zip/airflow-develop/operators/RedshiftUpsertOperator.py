from datetime import datetime
from tempfile import NamedTemporaryFile
from uuid import uuid4

from airflow.hooks.S3_hook import S3Hook
from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import Variable
from airflow.operators import BaseOperator
from airflow.utils.decorators import apply_defaults
from pandas import DataFrame, concat

get_flipt_person_id_phone = lambda \
        query_params: f"SELECT flipt_member_id, phone, employee_id, cobra_effective_date, cobra_termination_date FROM " \
                      f"" \
                      f"" \
                      f"{query_params['table_name']} WHERE " \
                      f"plan_year='" \
                      f"{query_params['plan_year']}';"

upsert_dw_users = lambda query_params: """\
    COPY flipt_dw.dw_users FROM '{s3_path}'
    CREDENTIALS 'aws_access_key_id={aws_access_key_id};aws_secret_access_key={aws_secret_access_key}'
    CSV DELIMITER ',' ACCEPTINVCHARS ACCEPTANYDATE FILLRECORD;
    
   
    """.format(s3_path=query_params['s3_path'], aws_access_key_id=query_params['aws_access_key_id'],
               aws_secret_access_key=query_params['aws_secret_access_key'], workspace=query_params['workspace'])

__SCHEMA__ = (
'relationship', 'user_type', 'flipt_person_id', 'flipt_member_id', 'personal_phones', 'employee_id', 'claimed',
'coverage_termination_date', 'coverage_effective_date', 'benefit_plan_name', 'plan_year', 'coverage_tier_name',
'domain_name', 'employment_status', 'cobra_effective_date', 'cobra_termination_date', 'person_code', 'group',
'parent_id', 'terms_hipaa_accepted_date', 'terms_compliance_accepted_date', 'create_date',
'update_date', 'tpa_member_id', 'uid')


class RedshiftUpsertOperator(BaseOperator):

    @apply_defaults
    def __init__(self, src_table, src_redshift_connection_id, source_s3_key, source_aws_connection_id, *args, **kwargs):
        self.src_table = src_table
        self.src_redshift_connection_id = src_redshift_connection_id
        self.source_s3_key = source_s3_key
        self.source_aws_connection_id = source_aws_connection_id
        self.__current_year = datetime.now().year
        super(RedshiftUpsertOperator, self).__init__(*args, **kwargs)

    def _get_upsert_rows(self, df, cursor):
        current_year = df

        query = get_flipt_person_id_phone({
            'plan_year': self.__current_year,
            'table_name': 'flipt_dw.dw_users'
        })

        upsert_rows = []

        cursor.execute(query)
        redshift_query_logger = ''

        new_users = []

        results = cursor.fetchall()
        cursor.close()

        flipt_member_ids = []

        for result in results:

            flipt_member_ids.append(result[0])
            row = current_year.loc[
                (current_year['flipt_member_id'] == result[0]) & ((current_year['personal_phones'] != result[1]) | (
                        current_year['cobra_effective_date'] != result[3])) & (
                        current_year['employee_id'] == result[2])]

            if not row.empty:
                updated_record = deepcopy(row)
                updated_record.personal_phones = row.iloc[0].personal_phones,
                updated_record.cobra_effective_date = row.iloc[0].cobra_effective_date
                updated_record.cobra_termination_date = row.iloc[0].cobra_termination_date

                upsert_rows.append({
                    'flipt_member_id': result[0],
                    'employee_id': result[2],
                    'record': updated_record
                })

        new_users_flipt_ids = list(set(current_year['flipt_member_id'].tolist()).difference(set(flipt_member_ids)))

        for user_id in new_users_flipt_ids:
            new_users.append(current_year.loc[current_year['flipt_member_id'] == user_id])

        return {
            'rows_to_upsert': upsert_rows,
            'new_users': new_users
        }

    def execute(self, context):
        self.hook = PostgresHook(postgres_conn_id=self.src_redshift_connection_id)
        conn = self.hook.get_conn()
        cursor = conn.cursor()

        source_s3 = S3Hook(aws_conn_id=self.source_aws_connection_id, verify=None)
        source_s3_key_object = source_s3.get_key(self.source_s3_key)

        with NamedTemporaryFile('wb') as source_file:
            content = source_s3.select_key(key=self.source_s3_key)
            source_s3_key_object.download_fileobj(Fileobj=source_file)

        mapped_result = []
        results = source_s3_key_object.get()['Body'].read().decode('utf-8').split("\n")
        for result in results:
            mapped_result.append(dict(zip(__SCHEMA__, result.split(","))))

        df = DataFrame(mapped_result)

        rows_to_update = self._get_upsert_rows(df, cursor)

        frames = []

        for row in rows_to_update['rows_to_upsert']:
            frames.append(row['record'])

        frames.extend(rows_to_update['new_users'])

        result = concat(frames)
        
        file_name = str(uuid4().hex)
        
        with NamedTemporaryFile() as fil:
            result.to_csv(fil.name, header=False, index=False, encoding='utf-8')
            source_s3.load_file(
                filename=fil.name,
                key=f"s3://flipt-airflow/{file_name}",
                replace=True
            )
            query = upsert_dw_users({
                's3_path': f"s3://flipt-airflow/{file_name}",
                'aws_access_key_id': Variable.get('AWS_ACCESS_KEY_ID'),
                'aws_secret_access_key': Variable.get('AWS_SECRET_ACCESS_KEY'),
                'workspace': 'flipt_dw'
            })
            
            cursor.execute(query)
            cursor.commit()
            
