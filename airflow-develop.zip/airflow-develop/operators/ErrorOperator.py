from airflow.operators import BaseOperator

from hooks.SlackHook import SlackHook

SLACK_CONN_ID = 'slack_default'

class ErrorOperator(BaseOperator):
    def __init__(self, context, *args, **kwargs):
        super(ErrorOperator, self).__init__(*args, *kwargs)
        error_message = """
            :red_circle: Task Failed.
            *Task*: {task}
            *Dag*: {dag}
            *Execution Time*: {exec_date}
            *Log Url*: {log_url}
            """.format(
            task=context.get('task_instance').task_id,
            dag=context.get('task_instance').dag_id,
            exec_date=context.get('execution_date'),
            log_url=context.get('task_instance').log_url)

        self.slack_hook = SlackHook(message=error_message)
