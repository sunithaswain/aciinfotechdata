from base64 import b64encode
from json import dumps
from tempfile import NamedTemporaryFile
from airflow.operators import BaseOperator
from airflow.hooks.S3_hook import S3Hook
from airflow.utils.decorators import apply_defaults
from couchbase.n1ql import N1QLQuery
from hooks.CouchBaseHook import CouchbaseHook

class CouchbaseOperator(BaseOperator):

    @apply_defaults
    def __init__(self, cb_connection_id, cb_bucket, query, s3_dest_source, dest_s3_key, *args, **kwargs):
        super(CouchbaseOperator, self).__init__(*args, **kwargs)
        self._query = query
        self._cb_connection_id = cb_connection_id
        self._cb_bucket = cb_bucket
        self._s3_dest_source = s3_dest_source
        self._dest_s3_key = dest_s3_key

    def execute(self, context):
        cb_chook = CouchbaseHook(connection=self._cb_connection_id,
                                 schema=self._cb_bucket)
        connection = cb_chook.get_conn()

        query = N1QLQuery(self._query)
        query_result = connection.n1ql_query(query)

        results = []
        for result in query_result:
            if self._cb_bucket in result:
                results.append(b64encode(dumps(result[self._cb_bucket])
                                         .encode('utf-8')))
            else:
                results.append(b64encode(dumps(result).encode('utf-8')))

        dest_s3 = S3Hook(aws_conn_id=self._s3_dest_source)

        with NamedTemporaryFile(mode='w') as temp_file:
            for row in results:
                temp_file.write(row.decode('utf-8'))
                temp_file.write("\n")

            dest_s3.load_file(
                filename=temp_file.name,
                key=self._dest_s3_key
            )
            temp_file.flush()
