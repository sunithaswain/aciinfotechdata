from csv import DictWriter
from tempfile import NamedTemporaryFile

from hooks.FliptS3Hook import FliptS3Hook
from airflow.operators import BaseOperator
from airflow.utils.decorators import apply_defaults

from hooks.TruevaultHook import TruevaultHook

class TruevaultOperator(BaseOperator):
    @apply_defaults
    def __init__(self, action, query, task_id, *args, **kwargs):
        super(TruevaultOperator, self).__init__(action=action, query=query,
                                                task_id=task_id,
                                                *args, **kwargs)

        self.action = action.upper()
        self.query = query
        self.task_id = task_id

    def execute(self, context):
        self.context = context

        if self.action == "READ":
            self.__search()
            self.__write_to_s3()

        if self.action == "WRITE":
            self.__upsert()

        if self.action == "DELETE":
            self.__delete()

        if self.action == "GET_ALL":
            self.__get_all()

    def __get_all(self):
        self.data = TruevaultHook(context=self.context).list_all()

    def __search(self):
        self.data = TruevaultHook(context=self.context).search(query=self.query)

    def __upsert(self):
        self.data = TruevaultHook(context=self.context).upsert()

    def __delete(self):
        self.data = TruevaultHook(context=self.context).delete()

    def __write_to_s3(self):
        with NamedTemporaryFile(mode="w") as temp_file:
            dict_writer = DictWriter(temp_file, ["attribute"],
                                     extrasaction="ignore")
            dict_writer.writerows(self.data)

            FliptS3Hook(context=self.context) \
                .upload_file(temp_file_name=temp_file.name)

            temp_file.flush()

        self.log.info(f">>>> {len(self.data)} truevault users recorded.")
