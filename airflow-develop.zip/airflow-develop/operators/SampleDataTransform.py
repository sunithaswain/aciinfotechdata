from airflow.operators import BaseOperator
from airflow.utils.decorators import apply_defaults

from hooks.FliptS3Hook import FliptS3Hook

class SampleDataTransformerOperator(BaseOperator):
    @apply_defaults
    def __init__(self, task_id, *args, **kwargs):
        self.task_id = task_id

        super(SampleDataTransformerOperator,
              self,).__init__(task_id=self.task_id,
                              *args, **kwargs)

    def execute(self, context):
        results = FliptS3Hook(context=context).file_download()
        self.log.info(f"{results}")
