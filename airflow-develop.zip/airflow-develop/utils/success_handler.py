# import logging

# from hooks.S3Hook import AWSS3Hook

def success_handler(context):
    pass

    # This executes after every successful operation so we can't clean up yet
    # clean_up = context["dag"].__dict__["default_args"]["on_success_cleanup"]

    # if clean_up:
    #     logging.info('>>>> Cleaning up AWS Files...')
    #     AWSS3Hook(context=context).clean_up()
