import random
from hooks.SlackHook import SlackHook

def error_handler(context):
    image_lib = [
        "https://media.giphy.com/media/vX9WcCiWwUF7G/giphy-downsized.gif",
        "https://media.giphy.com/media/eP1fobjusSbu/giphy.gif",
        "https://media.giphy.com/media/WiRBjwK64r3s4/giphy.gif",
        "https://media.giphy.com/media/K1QnLV1caRpuw/giphy-downsized.gif",
        "https://media.giphy.com/media/4KF8Ezrk5hPh69VVsn/giphy-downsized.gif",
    ]
    slack_msg = """
        :red_circle: Task Failed.
        *Task*: {task}
        *Dag*: {dag}
        *Execution Time*: {exec_date}
        *Log Url*: {log_url}
        """.format(
                task=context.get('task_instance').task_id,
                dag=context.get('task_instance').dag_id,
                ti=context.get('task_instance'),
                exec_date=context.get('execution_date'),
                log_url=context.get('task_instance').log_url,
    )
    attachments = [{
        "title": ":see_no_evil:",
        "image_url": random.choice(image_lib),
    }]
    slack = SlackHook(message=slack_msg, attachments=attachments)

    return slack.execute(context)
