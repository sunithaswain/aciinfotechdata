from test_config.config import test_config_runner
from utils.Field import Field
from utils.config_runner import ConfigRunner


class NovartisTail(object):

    def __init__(self, count):
        self._count = count
        self._config_runner = ConfigRunner()
        self._config_fields = test_config_runner['tail']
        self._fields = self._config_runner.read(self._config_fields)

    def get_tail(self):
        count = str(self._count)

        count = ''.ljust(7 - len(count) + 1, '0') + count

        record_count = Field('record_count', {'start_end': [4, 12], 'field_length': 8, 'value': count})
        self._fields.update(
            **record_count.field()
        )
        return self._fields
