from datetime import datetime
from uuid import uuid4

from test_config.acknowledgment_config import test_config_acknowledgment
from utils.Couchbase import CouchbaseConnector


class NovartisAccumulator(object):

    def __init__(self, config, claim, user_data, claim_sequence_number, accumulator_type):
        self._claim = claim
        self._cursor = CouchbaseConnector()
        self._accumulator_type = accumulator_type
        self._accumulator_document = {
            'job_id': config['job_id'],
            'domain': config['domain'],
            'emp_flipt_person_id': user_data['emp_flipt_person_id'] if user_data else "",
            'dep_flipt_person_id': user_data['dep_flipt_person_id'] if user_data else "",
            'plan_name': user_data['plan_name'] if user_data else "",
            'plan_year': user_data['plan_year'] if user_data else "",
            'coverage_tier': user_data['coverage_tier'] if user_data else "",
            'sender_description': claim['sender_description']['value'],
            'routing_id': claim['routing_id']['value'],
            'message_id': claim['message_id']['value'],
            'record_timestamp': claim['record_timestamp']['value'],
            'claim_number': claim['claim_number']['value'],
            'claim_sequence': claim_sequence_number,
            'claim_status': claim['claim_status']['value'],
            'date_of_service': claim['date_of_service']['value'],
            'reason_code': claim['reason_code']['value'],
            'vendor_name': claim['vendor_name']['value'],

            'type': accumulator_type,
            'ack_processed_timestamp': datetime.now().isoformat(),
            'ack_result': 'PASS'
        }

    def insert_accumulator_data(self):
        self._accumulator_document.update({
            'accumulator': {
                'type': self._claim['accumulator_type_1']['value'],
                'code': self._claim['accum_code_1']['value'],
                'amount_applied': self._claim['amount_applied_1']['value']
            }
        })
        documents = [self._accumulator_document]
        # if self._claim['accumulator_type_2']['value']:
        #     accumulator_copy = deepcopy(self._accumulator_document)
        #     accumulator_copy['accumulator']['type'] = self._claim['accumulator_type_2']['value'] 
        #     accumulator_copy['accumulator']['code'] = self._claim['accum_code_2']['value']
        #     accumulator_copy['accumulator']['amount_applied'] = helper.float_to_right_justified(self._claim[
        #     'amount_applied_2']['value'])
        #     documents.append(accumulator_copy)

        for document in documents:
            self._cursor.get_cursor_object().upsert(uuid4().hex, document)

    def set_acknowledgment_fields(self, fields):
        self._accumulator_document.update(
            **fields
        )

    def map_accumulator_acknowledgment(self):
        for field in test_config_acknowledgment['fields'].keys():
            config_field = test_config_acknowledgment['fields'][field]
            if config_field['constant']:
                config_field.update({
                    'value': config_field['constant']
                })
            if config_field['mapped_field']:
                config_field.update({
                    'value': self._accumulator_document.get(config_field['mapped_field'], '')
                })

        return test_config_acknowledgment
