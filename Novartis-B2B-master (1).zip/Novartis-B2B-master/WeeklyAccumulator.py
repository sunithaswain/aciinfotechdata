from collections import defaultdict
from copy import deepcopy

from Novartis import Novartis
from NovartisTail import NovartisTail
from helpers import novartis_helpers as helper


class WeeklyAccumulator(Novartis):

    def __init__(self, conifg):
        super().__init__(conifg)

    def weekly_query(self):
        weekly_accumulator_query = f"SELECT * FROM {self._bucket_name} WHERE type='pharmacy_accumulator' OR " \
                                   f"type='medical_accumulator'"
        results = self.cursor.query(weekly_accumulator_query)
        grouped_accumulator_items = defaultdict(list)
        for result in results:
            grouped_accumulator_items[result['emp_flipt_person_id']].append(
                result)

        return grouped_accumulator_items

    def _get_truevault_weekly_accumulator_data(self, truevault_data, flipt_person_ids):
        weekly_truevault = {
            'member_id': flipt_person_ids['dep_flipt_person_id'] if flipt_person_ids['dep_flipt_person_id'] else
            flipt_person_ids['emp_flipt_person_id']
        }

        user_data = \
            list(filter(lambda user: user['flipt_person_id'] == flipt_person_ids['emp_flipt_person_id'],
                        truevault_data))[0]

        if flipt_person_ids['dep_flipt_person_id']:
            user_data = list(
                filter(lambda dependent: dependent['flipt_person_id'] == flipt_person_ids['dep_flipt_person_id'],
                       user_data['dependents']))[0]

        eligibility_data = helper.get_recent_user_eligibility_truevault(user_data['eligibility'])

        user_data_ssn = user_data['employee_ssn'] if 'employee_ssn' in user_data else user_data['dependent_ssn']
        formatted_ssn = "".join(user_data_ssn.split("-"))

        weekly_truevault.update({
            'coverage_date_start': helper.format_time(eligibility_data['coverage_effective_date'], "%Y%m%d"),
            'coverage_date_end': helper.format_time(eligibility_data['coverage_termination_date'], "%Y%m%d"),
            'date_of_birth': helper.format_time(user_data['date_of_birth'], "%Y%m%d"),
            'first_name': user_data['first_name'].upper(),
            'last_name': user_data['last_name'].upper(),
            'gender_code': user_data['gender'],
            'member_id': user_data['flipt_person_id'],
            'horizon_member_id': formatted_ssn,
            'medical_member_id': formatted_ssn
        })

        return weekly_truevault

    def group_accumulators_by_type(self, constant, accumulator_items, truevault_data):
        accumulated_accumulator_items = []
        is_deductible = True
        is_out_of_pocket = True

        for accumulator_item in accumulator_items:
            if len(accumulator_items) == 2:
                return accumulator_items

            if is_deductible and accumulator_item['accumulator']['type'] == 'D':
                is_deductible = False
                deductible_constant = deepcopy(constant)
                deductible_constant['accumulator_type'] = 'D'
                deductible_constant.update({
                    'begin_date': truevault_data['coverage_date_start'],
                    'period_end_date': truevault_data['coverage_date_end'],
                    'horizon_member_id': truevault_data['horizon_member_id']
                })
                accumulated_accumulator_items.append(deductible_constant)
                continue

            if is_out_of_pocket and accumulator_item['accumulator']['type'] == 'O':
                is_out_of_pocket = False
                out_of_pocket = deepcopy(constant)
                out_of_pocket.update({
                    'begin_date': truevault_data['coverage_date_start'],
                    'period_end_date': truevault_data['coverage_date_end'],
                    'horizon_member_id': truevault_data['horizon_member_id']
                })
                out_of_pocket['accumulator_type'] = 'O'
                accumulated_accumulator_items.append(out_of_pocket)
                continue

        return accumulated_accumulator_items

    def _format_accumulator_items(self, accumulator_items, truevault_user):
        records = []

        for accumulator_item in accumulator_items.values():
            pharmacy_accumulator_items = list(
                filter(lambda record: record['type'] == 'pharmacy_accumulator', accumulator_item))
            medical_accumulator_items = list(
                filter(lambda record: record['type'] == 'medical_accumulator', accumulator_item))

            individual_pharmacy_balance = sum(list(
                map(lambda record: helper.right_justfied_to_float(record['accumulator']['amount_applied']),
                    pharmacy_accumulator_items)))
            individual_medical_balance = sum(list(
                map(lambda record: helper.right_justfied_to_float(record['accumulator']['amount_applied']),
                    medical_accumulator_items)))
            individual_total_balance = helper.float_to_right_justified(
                str((individual_pharmacy_balance + individual_medical_balance)))

            individual_pharmacy_balance = helper.float_to_right_justified(str(individual_pharmacy_balance))
            individual_medical_balance = helper.float_to_right_justified(str(individual_medical_balance))

            dep_flipt_person_id = accumulator_item[0]['dep_flipt_person_id']
            emp_flipt_person_id = accumulator_item[0]['emp_flipt_person_id']

            weekly_constant_fields = {
                'record_type': 'ACM',
                'accum_code': 'BOTH',
                'vendor_name': 'FLIPT',
                'individual_pharmacy_balance': f"{individual_pharmacy_balance}",
                'individual_medical_balance': f"{individual_medical_balance}",
                'individual_total_balance': f"{individual_total_balance}",
                'period_begin_date': '',
                'period_end_date': '',
                'accumulator_type': ''
            }

            truevault_data = self._get_truevault_weekly_accumulator_data(truevault_user,
                                                                         {'dep_flipt_person_id': dep_flipt_person_id,
                                                                          'emp_flipt_person_id': emp_flipt_person_id})

            grouped_pharmacies_by_type = self.group_accumulators_by_type(weekly_constant_fields,
                                                                         pharmacy_accumulator_items,
                                                                         truevault_data)
            grouped_medicals_by_type = self.group_accumulators_by_type(weekly_constant_fields,
                                                                       medical_accumulator_items,
                                                                       truevault_data)

            accum_record = {
                'record_type': 'MBR',
                'member_id': truevault_data['member_id'],
                'medical_member_id': truevault_data['medical_member_id'],
                'first_name': truevault_data['first_name'],
                'last_name': truevault_data['last_name'],
                'gender_code': truevault_data['gender_code'],
                'date_of_birth': truevault_data['date_of_birth'],
                'accum_records': [
                    *grouped_pharmacies_by_type, *grouped_medicals_by_type
                ]
            }
            records.append(accum_record)

        return records

    def _map_weekly_rows(self, record, mapped_fields):
        rows = []
        accum_records = record.pop('accum_records')

        mapped_copy = deepcopy(mapped_fields)
        for key in record.keys():
            if key in mapped_copy:
                mapped_copy[key].update({
                    'value': record[key]
                })
        rows.append(mapped_copy)

        for accum_record in accum_records:
            # print(record['record_type'])
            mapped_accum_record = deepcopy(mapped_fields)
            # print(accum_record.keys())
            for key in accum_record.keys():
                if key in mapped_accum_record:
                    mapped_accum_record[key].update({
                        'value': accum_record[key]
                    })
            rows.append(mapped_accum_record)
        return rows

    def weekly_accumulator(self):
        weekly_accumulator_query_results = self.weekly_query()
        emp_flipt_person_ids = list(weekly_accumulator_query_results.keys())

        truevault_data = self.true_vault.get_documents('flipt_person_id', emp_flipt_person_ids)
        truevault_users = truevault_data[0]

        records = []

        for accumulator_items in weekly_accumulator_query_results.values():
            grouped_accumulators_ids = defaultdict(list)
            for accumulator in accumulator_items:
                if accumulator['dep_flipt_person_id']:
                    grouped_accumulators_ids[accumulator['dep_flipt_person_id']].append(accumulator)
                    continue
                else:
                    grouped_accumulators_ids[accumulator['emp_flipt_person_id']].append(accumulator)
                    continue

            records.extend(self._format_accumulator_items(grouped_accumulators_ids, truevault_users))

        mapped_weekly_fields = []
        file = open('weekly.txt', 'w')

        header = super().get_novartis_header().get_header(self._config['job_start_date'], self._config['job_end_date'])
        # print(header)
        header_row = self.write_rows([header])
        file.write(header_row)
        file.write("\n")
        count = 0
        for record in records:
            rows = self._map_weekly_rows(record, self._config['fields'])
            # for row in rows:
            #     print(row)
            count += len(rows)
            file.write(super().write_rows(rows))
            file.write("\n")
        trail = NovartisTail(count)
        file.write(self.write_rows([trail.get_tail()]))
        file.close()
