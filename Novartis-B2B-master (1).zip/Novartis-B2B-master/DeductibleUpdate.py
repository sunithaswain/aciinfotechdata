import logging
import os
from datetime import datetime

import couchbase.subdocument as SD
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.n1ql import N1QLQuery

logging.basicConfig(format='%(message)s',
                    filename=os.environ['CB_DATA'] + '//deductible//log//novartisdductibleupdate.log',
                    filemode='a', level=logging.DEBUG)
log = logging.getLogger(__name__)


class NovartisDeductible:

    def __init__(self):

        self.cluster = Cluster(os.environ['CB_URL'])
        self.authenticator = PasswordAuthenticator(
            os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
        self.cluster.authenticate(self.authenticator)
        self.cb = self.cluster.open_bucket(os.environ['CB_INSTANCE'])
        self.path = os.environ['CB_DATA']

    def update_deductible(self, medical_claim):

        log_info = {"event_type": 'ENTRY', "start_time": datetime.now().isoformat(), "end_time": '', "resp_time": '',
                    "source": 'B2B', "operation": '', "transaction_id": medical_claim.get('job_id', ''),
                    "transaction_type": medical_claim.get('type', ''), "seq_num": medical_claim.get(
                'claim_sequence', ''), "destination": '', "flow": '', "http_method": '', "http_status_code": '',
                    "http_status_msg": '', "backend_url": '', "auth_id": '', "domain": medical_claim.get('domain', ''),
                    "reject_cd": '', "reject_msg": '',
                    "message": 'Claim received for {}'.format(medical_claim.get('dep_flipt_person_id', ''))}
        log.debug(msg=', '.join(
            key + '=' + str(value) for key, value in log_info.items()))

        deductibleinfo = self.find_individual_deductible(
            medical_claim.get('dep_flipt_person_id', ''), medical_claim.get(
                'plan_year', ''), medical_claim.get('domain', ''), log_info)

        familydeductibleinfo = self.find_family_deductible(
            medical_claim['emp_flipt_person_id'], medical_claim['plan_year'], medical_claim['domain'], log_info)

        status = self.accumulate_deductible(
            medical_claim, deductibleinfo, familydeductibleinfo, log_info)
        if status:
            return True

        return False

    def find_individual_deductible(self, flipt_person_id, plan_year, domain, log_info):

        query = N1QLQuery(
            'Select meta().id id, tonumber(deductible_accrued) deductible_accrued,tonumber(out_of_pocket_accrued) '
            'out_of_pocket_accrued,tonumber(carrier_deductible_accrued) carrier_deductible_accrued,'
            'tonumber(carrier_out_of_pocket_accrued) carrier_out_of_pocket_accrued, tonumber('
            'family_out_of_pocket_accrued) family_out_of_pocket_accrued, tonumber(family_deductible_accrued) '
            'family_deductible_accrued from `' +
            os.environ[
                'CB_INSTANCE'] + '` where type="deductible" and dep_flipt_person_id=$fid and domain_name=$domain and '
                                 'plan_year=$planyr',
            fid=flipt_person_id, planyr=plan_year, domain=domain)

        start_time = datetime.now()
        log_info["start_time"] = start_time.isoformat()
        log_info["event_type"] = 'INFO'
        log_info["operation"] = 'Individual Deductible Search'
        log_info["destination"] = 'Couchbase'

        for result in self.cb.n1ql_query(query):
            end_time = datetime.now()
            log_info["end_time"] = end_time.isoformat()
            log_info["resp_time"] = (end_time - start_time).total_seconds() * 1000
            log_info["message"] = 'Individual Deductible Search-Success'
            log.debug(msg=', '.join(
                key + '=' + str(value) for key, value in log_info.items()))
            return result

        end_time = datetime.now()
        log_info["end_time"] = end_time.isoformat()
        log_info["resp_time"] = (end_time - start_time).total_seconds() * 1000
        log_info["message"] = 'Individual Deductible Search-Not Found'
        log.debug(msg=', '.join(
            key + '=' + str(value) for key, value in log_info.items()))

        return {}

    def find_family_deductible(self, flipt_person_id, plan_year, domain, log_info):

        query = N1QLQuery(
            'Select ifnull(sum(tonumber(deductible_accrued)),0) deductible_accrued, ifnull(sum(tonumber('
            'out_of_pocket_accrued)),0) out_of_pocket_accrued from `' +
            os.environ[
                'CB_INSTANCE'] + '` where type="deductible" and emp_flipt_person_id=$fid and domain_name=$domain and '
                                 'plan_year=$planyr',
            fid=flipt_person_id, planyr=plan_year, domain=domain)
        start_time = datetime.now()
        log_info["start_time"] = start_time.isoformat()
        log_info["event_type"] = 'INFO'
        log_info["operation"] = 'Family Deductible Search'
        log_info["destination"] = 'Couchbase'

        for result in self.cb.n1ql_query(query):
            end_time = datetime.now()
            log_info["end_time"] = end_time.isoformat()
            log_info["resp_time"] = (end_time - start_time).total_seconds() * 1000
            log_info["message"] = 'Family Deductible Search-Success'
            if result.get('out_of_pocket_accrued', 0) == 0:
                log_info["message"] = 'Family Deductible Search-Not Found'
            log.debug(msg=', '.join(
                key + '=' + str(value) for key, value in log_info.items()))
            return result

        return {}

    def update_family_deductible(self, flipt_person_id, deductible_accrued, out_of_pocket_accrued, plan_year, domain,
                                 log_info):

        query = N1QLQuery('Update `' + os.environ['CB_INSTANCE'] +
                          '` set family_deductible_accrued=$deductible, family_out_of_pocket_accrued=$outofpocket, '
                          'updated_date=$date where type="deductible" and emp_flipt_person_id=$fliptid and '
                          'plan_year=$planyr and domain_name=$domain returning meta().id',
                          fliptid=flipt_person_id, planyr=plan_year, domain=domain, deductible=str(deductible_accrued),
                          outofpocket=str(out_of_pocket_accrued), date=datetime.now().isoformat())
        start_time = datetime.now()
        log_info["start_time"] = start_time.isoformat()
        log_info["event_type"] = 'INFO'
        response = self.cb.n1ql_query(query).execute()

        end_time = datetime.now()
        log_info["end_time"] = end_time.isoformat()
        log_info["resp_time"] = (end_time - start_time).total_seconds() * 1000
        log_info["operation"] = 'Family Deductible Update'
        log_info["destination"] = 'Couchbase'
        log_info["message"] = 'Family Deductible Updated-Success'
        log.debug(msg=', '.join(
            key + '=' + str(value) for key, value in log_info.items()))

    def accumulate_deductible(self, medical_claim, individual_deductible, family_deductible, log_info):

        deductible_amount = 0
        if medical_claim['accumulator']['type'] == 'D':
            deductible_amount = round(float(
                medical_claim['accumulator']['amount_applied']), 2)
        out_of_pocket_amount = round(float(
            medical_claim['accumulator']['amount_applied']), 2)
        family_deductible_accrued = round(family_deductible.get(
            'deductible_accrued', 0) + deductible_amount, 2)
        family_out_of_pocket_accrued = round(family_deductible.get(
            'out_of_pocket_accrued', 0) + out_of_pocket_amount, 2)

        if individual_deductible:

            update_fields = ['deductible_accrued',
                             'out_of_pocket_accrued', 'carrier_deductible_accrued', 'carrier_out_of_pocket_accrued']
            start_time = datetime.now()
            log_info["start_time"] = start_time.isoformat()
            log_info["event_type"] = 'INFO'

            for field in update_fields:

                if 'deductible' in field:
                    individual_deductible[field] += deductible_amount
                elif 'out_of_pocket' in field:
                    individual_deductible[field] += out_of_pocket_amount
                self.cb.mutate_in(individual_deductible['id'], SD.upsert(
                    field, str(round(individual_deductible[field], 2))))

            end_time = datetime.now()
            log_info["end_time"] = end_time.isoformat()
            log_info["resp_time"] = (end_time - start_time).total_seconds() * 1000
            log_info["operation"] = 'Individual Deductible Update'
            log_info["destination"] = 'Couchbase'
            log_info["message"] = 'Individual Deductible Updated-Success'
            log.debug(msg=', '.join(
                key + '=' + str(value) for key, value in log_info.items()))

            self.cb.mutate_in(individual_deductible['id'], SD.upsert(
                'data_extracted_date', datetime.now().isoformat()))
            self.cb.mutate_in(individual_deductible['id'], SD.upsert(
                'updated_date', datetime.now().isoformat()))

        else:

            new_record = {'carrier_deductible_accrued': str(deductible_amount),
                          'carrier_out_of_pocket_accrued': str(out_of_pocket_amount),
                          'created_date': datetime.now().isoformat(),
                          'coverage_tier': medical_claim['coverage_tier'],
                          'data_extracted_date': datetime.now().isoformat(),
                          'deductible_accrued': str(deductible_amount),
                          'dep_flipt_person_id': medical_claim['dep_flipt_person_id'],
                          'domain_name': medical_claim['domain'],
                          'emp_flipt_person_id': medical_claim['emp_flipt_person_id'],
                          'out_of_pocket_accrued': str(out_of_pocket_amount),
                          'plan_name': medical_claim['plan_name'],
                          'plan_year': medical_claim['plan_year'],
                          'type': 'deductible',
                          'updated_date': datetime.now().isoformat(),
                          'fliptrx_deductible_accrued': '0',
                          'fliptrx_out_of_pocket_accrued': '0',
                          'family_deductible_accrued': str(family_deductible_accrued),
                          'family_out_of_pocket_accrued': str(family_out_of_pocket_accrued)}

            start_time = datetime.now()
            log_info["start_time"] = start_time.isoformat()
            log_info["event_type"] = 'INFO'

            self.cb.upsert(
                str(self.cb.counter('docid', delta=1).value), new_record)

            end_time = datetime.now()
            log_info["end_time"] = end_time.isoformat()
            log_info["resp_time"] = (end_time - start_time).total_seconds() * 1000
            log_info["operation"] = 'Individual Deductible Insert'
            log_info["destination"] = 'Couchbase'
            log_info["message"] = 'Individual Deductible Inserted-Success'
            log.debug(msg=', '.join(
                key + '=' + str(value) for key, value in log_info.items()))

        self.update_family_deductible(
            medical_claim['emp_flipt_person_id'], family_deductible_accrued, family_out_of_pocket_accrued,
            medical_claim['plan_year'], medical_claim['domain'], log_info)


'''
input = {
    'job_id': '',
    'domain': 'FLIPT001',
    'dep_flipt_person_id': '1002890',
    'emp_flipt_person_id': '1002890',
    'plan_name': 'HSA Value Plan',
    'plan_year': '2019',
    'coverage_tier': 'Employee and Spouse',
    'sender_description': '',
    'routing_id': '',
    'message_id': '',
    'record_timestamp': '',
    'sender_description': '',
    'claim_number': '',
    'claim_sequence': '',
    'claim_status': '',
    'date_of_service': '',
    'reason_code': '',
    'vendor_name': '',
    'accumulator': {
        'type': 'O',
        'code': 'BOTH',
        'amount_applied': '1000'
    },
    'type': 'Medical'
}
obj = NovartisDeductible()
obj.update_deductible(input)
'''
