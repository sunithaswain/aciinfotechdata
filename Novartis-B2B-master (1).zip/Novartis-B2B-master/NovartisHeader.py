# -*-coding: latin-1

from helpers import novartis_helpers as helpers
from utils.Field import Field
from utils.config_runner import ConfigRunner


class NovartisHeader(object):

    def __init__(self, document_count, config):
        self._config_runner = ConfigRunner()
        self._config_fields = config['header']
        print(self._config_fields)
        self._fields = self._config_runner.read(self._config_fields)
        self._count = document_count
        self._job_type = ' '.join(config['job_name'].split("_")).upper()

    def get_timestamps(self, start_date, end_date):
        start_date = helpers.format_time(start_date, '%Y-%m-%d-%H.%M.%S.%f', '%Y-%m-%dT%H:%M:%S.%f')
        end_date = helpers.format_time(end_date, '%Y-%m-%d-%H.%M.%S.%f', '%Y-%m-%dT%H:%M:%S.%f')

        start_field = Field('date_begin_timestamp', {'value': str(start_date), 'start_end': [60, 86]})
        end_field = Field('date_end_timestamp', {'value': str(end_date), 'start_end': [86, 112]})

        return start_field.field(), end_field.field()

    def get_count(self):
        count = str(self._count + 1)

        formatted_count = ''.ljust(5 - len(count), '0') + count

        unique_batch_indicator = Field('unique_batch_file_identifier',
                                       {'field_length': 8, 'start_end': [4, 9], 'value': formatted_count})
        return unique_batch_indicator.field()

    def get_sender_description(self):
        field = Field('file_description', {'field_length': 30, 'start_end': [9, 39], 'value': self._job_type})
        return field.field()

    def get_header(self, start_date, end_date):
        start_time, end_time = self.get_timestamps(start_date, end_date)
        record_type = Field('record_type', {'field_length': 3, 'constant': 'HDR', 'value': 'HDR', 'start_end': [1, 4]})

        self._fields.update(
            **record_type.field(),
            **start_time,
            **end_time,
            **self.get_sender_description(),
            **self.get_count()
        )
        # self._fields['file_description']['value'] = 'BALANCE FILE'
        return self._fields
