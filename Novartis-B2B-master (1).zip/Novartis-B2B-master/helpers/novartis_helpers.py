from datetime import datetime
from functools import reduce


def get_user_from_truevault(flip_person_id, users):
    cardholder_id = flip_person_id[:-2]
    return list(filter(lambda user: user['flipt_person_id'] == cardholder_id, users))


def get_recent_user_eligibility_truevault(user):
    return sorted(user,
                  key=lambda x: datetime.strptime(x["coverage_termination_date"], "%Y-%m-%d %H:%M:%S"),
                  reverse=True)[0]


def get_key(dictionary, keys):
    keys = keys.split(".")
    return reduce(lambda val, key: val.get(key, {}), keys, dictionary)


def get_user_data_member_id(user, member_id):
    emp_flipt_person_id = user['flipt_person_id']
    dep_flipt_person_id = ""
    person_code = member_id[-2:]

    if person_code != '01':
        dependant_user = list(filter(lambda dependant: dependant['member_id'] == member_id, user['dependents']))[0]
        dep_flipt_person_id = dependant_user['flipt_person_id']

    eligibility = get_recent_user_eligibility_truevault(user['eligibility'])

    return {
        'emp_flipt_person_id': emp_flipt_person_id,
        'dep_flipt_person_id': dep_flipt_person_id,
        'plan_name': eligibility['benefit_plan_name'],
        'plan_year': eligibility['plan_year'],
        'coverage_tier': eligibility['coverage_tier_name']
    }


def stringified_ids(ids):
    ids_array = ""

    for id in ids:
        ids_array += f"'{id}',"

    return ids_array[:-1]


def format_time(timestamp, to_format, from_format="%Y-%m-%d %H:%M:%S"):
    timestamp_datetime = datetime.strptime(timestamp, from_format)
    return datetime.strftime(timestamp_datetime, to_format)


def right_justfied_to_float(number):
    return float(number[4:][:3] + "." + number[4:][:3])


def float_to_right_justified(amount_applied):
    amount_applied_value = ''.ljust(9, '0')
    if amount_applied != '0':
        amount_applied = amount_applied + '0'
        amount_applied_cents = amount_applied.split('.')[1][:2]
        amount_applied_dollars = amount_applied.split('.')[0]
        amount_applied_width = len(amount_applied_dollars) + len(amount_applied_cents)

        amount_applied_value = ''.ljust(9 - amount_applied_width,
                                        '0') + amount_applied_dollars + amount_applied_cents

    return amount_applied_value
