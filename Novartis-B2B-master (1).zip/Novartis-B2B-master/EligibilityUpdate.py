import base64
import os
from datetime import datetime

from cerberus import Validator
from couchbase.cluster import Cluster, PasswordAuthenticator
from couchbase.n1ql import N1QLQuery



class EligibilityUpdate:

    def __init__(self, cb_handle, cb_bucket):
        self.record = {}
        self.current_user_info = {}
        self.tv_api_key = os.environ['TV_API_KEY']
        self.cb_bucket = cb_bucket
        self.cb = cb_handle

    def read(self):
        self.record = configrunner.read()


def validate_data(self):
    self.read()
    v = Validator(allow_unknown=True)
    v.schema = {"employee_id": {"type": "string", "regex": "^[a-zA-Z0-9]+$", "maxlength": 15, "minlength": 15},
                "employee_ssn": {"type": "string", "regex": "^[0-9]+$", "maxlength": 9, "minlength": 9},
                "last_name": {"required": True},
                "first_name": {"required": True},
                "date_of_birth": {"type": "datetime", "coerce": lambda s: datetime.strptime(s, '%Y%m%d')},
                "personal_phone": {"type": "string", "regex": "^[0-9]+$", "maxlength": 10, "minlength": 10},
                "gender": {"allowed": ["F", "M"]},
                "home_address_1": {"required": True},
                "city": {"required": True},
                "state": {"required": True},
                "zip": {"required": True, "minlength": 5, "maxlength": 9},
                "employment_status": {"allowed": ["active", "cobra"], "coerce": lambda s: s.lower()},
                "dependents": {"type": "dict",
                               "schema": {
                                   "employee_id": {"type": "string", "regex": "^[a-zA-Z0-9]+$", "maxlength": 15,
                                                   "minlength": 15},
                                   "dependent_ssn": {"type": "string", "regex": "^[0-9]+$", "maxlength": 9,
                                                     "minlength": 9},
                                   "relationship": {"max": 23, "min": 0, "coerce": lambda s: int(s)},
                                   "last_name": {"required": True},
                                   "first_name": {"required": True},
                                   "gender": {"allowed": ["F", "M"]},
                                   "date_of_birth": {"type": "datetime",
                                                     "coerce": lambda s: datetime.strptime(s, '%Y%m%d')},
                                   "person_code": {"max": 99, "min": 1, "coerce": lambda s: int(s)},
                                   "eligibility": {"type": "dict",
                                                   "schema": {
                                                       "coverage_termination_date": {"type": "datetime",
                                                                                     "coerce": lambda
                                                                                         s: datetime.strptime(s,
                                                                                                              '%Y%m%d'),
                                                                                     "dependencies": {
                                                                                         "employment_status": [
                                                                                             "active"]}},
                                                       "coverage_effective_date": {"type": "datetime", "coerce": lambda
                                                           s: datetime.strptime(s, '%Y%m%d'), "dependencies": {
                                                           "employment_status": ["active"]}},
                                                       "coverage_tier_name": {"type": "string", "max": "A", "min": "X",
                                                                              "forbidden": ["V", "W"]},
                                                       "cobra_effective_date": {"type": "datetime",
                                                                                "coerce": lambda s: datetime.strptime(s,
                                                                                                                      '%Y%m%d'),
                                                                                "dependencies": {
                                                                                    "employment_status": ["cobra"]}},
                                                       "cobra_termination_date": {"type": "datetime",
                                                                                  "coerce": lambda s: datetime.strptime(
                                                                                      s, '%Y%m%d'), "dependencies": {
                                                               "employment_status": ["cobra"]}},
                                                   }}
                               }}
                "eligibility": {"type": "dict",
                                "schema": {
                                    "coverage_termination_date": {"type": "datetime",
                                                                  "coerce": lambda s: datetime.strptime(s, '%Y%m%d'),
                                                                  "dependencies": {"employment_status": ["active"]}},
                                    "coverage_effective_date": {"type": "datetime",
                                                                "coerce": lambda s: datetime.strptime(s, '%Y%m%d'),
                                                                "dependencies": {"employment_status": ["active"]}},
                                    "coverage_tier_name": {"type": "string", "max": "A", "min": "X",
                                                           "forbidden": ["V", "W"]},
                                    "cobra_effective_date": {"type": "datetime",
                                                             "coerce": lambda s: datetime.strptime(s, '%Y%m%d'),
                                                             "dependencies": {"employment_status": ["cobra"]}},
                                    "cobra_termination_date": {"type": "datetime",
                                                               "coerce": lambda s: datetime.strptime(s, '%Y%m%d'),
                                                               "dependencies": {"employment_status": ["cobra"]}}
                                }}
                }
    validation_response = v.validate()
    if not validation_response:
        print(v.errors)
    return validation_response


def lookup_user(self):
    validation_response = self.validate_data()
    if validation_response:
        tv = TrueVault()
        search_result, userids = tv.get_documents('employee_ssn', [self.record['employee_ssn']])
        if len(search_result) > 1:
            # log multiple user found
            return
        self.current_user_info, userid = search_result[0], userids[0]
        if self.current_user_info:
            data = self.update_record()
            response = update_document(data, userid)
        else:
            data = self.insert_record()
            response = create_new_document(data)


def update_record(self):
    eligibility_updated = {}

    # updating new information with existing info not received from file
    for attribute, value in self.current_user_info.items():
        if value in ["dependents", "eligibility"]:
            continue
        if not self.record.get(attribute, ""):
            self.record[attribute] = value
            continue
        if self.record[attribute] != self.current_user_info[attribute]:
            eligibility_updated[self.current_user_info['flipt_person_id']] = True

    # updating eligiblity
    found_current_eligibility = False
    for idx, element in enumerate(self.current_user_info['eligibility'])
        if element['plan_year'] == self.record['eligibility']['plan_year'] and element['benefit_plan_name'] == \
                self.record['eligibility']['benefit_plan_name']:
            found_current_eligibility = True
            for attribute, value in element.items():
                if element['attribute_value'] != self.record['eligibility'][attribute]:
                    eligibility_updated[self.current_user_info['flipt_person_id']] = True
                self.current_user_info['eligibility'][idx][attribute_value] = self.record['eligibility'][
                    attribute_value]
            self.record['eligibility'] = self.current_user_info['eligibility']

    if not found_current_eligibility:
        if self.current_user_info.get('eligibility', []):
            self.current_user_info['eligibility'].append(self.record['eligibility'])
        self.current_user_info['eligibility'] = [self.record['eligibility']]
        eligibility_updated[self.current_user_info['flipt_person_id']] = True

    # updating dependents
    eligibility_updated = self.update_dependents(eligibility_updated)
    if eligibility_updated.keys():
        self.update_flipt_hierarchy(eligibility_updated.keys())

    attributes = base64.b64encode(str.encode(json.dumps(self.current_user_info)))
    data = {'attributes': attributes}
    return data


def update_dependents(self, eligibility_updated):
    dependents_added = []
    dependents_removed = []
    dependents_covered = []

    current_dependents = {}
    current_dependents_covered = []
    for idx, dependent in enumerate(self.current_user_info['dependents']):
        current_dependents[dependent['dependent_ssn']] = idx
        current_dependents_covered.append(dependent['flipt_person_id'])

    for idx, dependent in enumerate(self.record['dependents']):
        if dependent['dependent_ssn'] in current_dependents.keys():
            current_dependent_info = self.current_user_info['dependents'][
                current_dependents[dependent['dependent_ssn']]]
            dependents_covered.append(current_dependent_info['flipt_person_id'])
            for attribute, value in dependent.items():
                if attribute == 'eligibility':
                    found_current_eligibility = False
                    for idx1, element in enumerate(current_dependent_info['eligibility']):
                        if element['plan_year'] == dependent['eligibility']['plan_year']:
                            found_current_eligibility = True
                            for elig_attribute, elig_value in dependent['eligiblity'].items():
                                if elig_value != element[elig_attribute]:
                                    eligibility_updated[current_dependent_info['flipt_person_id']] = True
                                current_dependent_info['eligibility'][idx1][elig_attribute] = elig_value
                    if not found_current_eligibility:
                        eligibility_updated[current_dependent_info['flipt_person_id']] = True
                        if current_dependent_info.get('eligibility', []):
                            current_dependent_info['eligibility'].append(
                                dependent['eligibility'])
                        else:
                            current_dependent_info['eligibility'] = [dependent['eligibility']]
                else:
                    if value != current_dependent_info[attribute]:
                        eligibility_updated[current_dependent_info['flipt_person_id']] = True
                    current_dependent_info[attribute] = value
            current_dependent_info['updated_at'] = datetime.now().isoformat()
            self.current_user_info['dependents'][
                current_dependents[dependent['dependent_ssn']]] = current_dependent_info
        else:
            dependent['flipt_person_id'] = str(self.cb.counter('counterid', delta=1).value)
            dependent['created_at'] = dependent['updated_at'] = datetime.now().isoformat()
            self.insert_flipt_hierarchy(dependent['flipt_person_id'])
            dependents_added.append(dependent['flipt_person_id'])

    current_dependents_covered - dependents_covered.extend(dependents_added)
    return eligibility_updated


def insert_record(self):
    self.record['eligibility'] = [self.record['eligibility']]
    self.record['active'] = False
    password = str(self.record['zip'][:5]) + str(self.record['employee_ssn'])[-4:]
    self.record['tmp_password'] = password
    attributes = base64.b64encode(str.encode(json.dumps(self.record)))
    data = {'username': self.record['work_email'], 'password': password,
            'attributes': attributes,
            'group_ids': os.environ['CB_GROUP_ID']}
    return data


def insert_flipt_hierarchy(self, flipt_person_id):
    document = {
        "created_at": datetime.now().isoformat(),
        "dep_flipt_person_id": flipt_person_id,
        "domain_name": self.record['domain_name'],
        "emp_flipt_person_id": self.record['flipt_person_id'],
        "hp_eligibility_updated": "Y",
        "hp_extracted_date": "",
        "sc_extracted_date": "",
        "type": "flipt_person_hierarchy",
        "updated_at": datetime.now().isoformat()}

    self.cb.upsert(str(self.cb.counter('docid', delta=1).value), r)


def update_flipt_hierarchy(self, flipt_person_ids):
    query = N1QLQuery(
        "UPDATE `" + self.cb_bucket + "` SET hp_eligibility_updated='Y',updated_at=$update_date where type='flipt_person_hierarchy' and dep_flipt_person_id in $flipt_ids ",
        update_date=datetime.now().isoformat(), flipt_ids=flipt_person_ids)

    self.cb.n1ql_query(query).execute()

    def validate_data(self, data):

        self.record = data

        v = Validator(allow_unknown=True)
        schema = {"employee_id": {"type": "string", "regex": "^[a-zA-Z0-9]+$", "maxlength": 15, "minlength": 1},
                  "employee_ssn": {"type": "string", "regex": "^[0-9]+$", "maxlength": 9, "minlength": 9},
                  "last_name": {"required": True},
                  "first_name": {"required": True},
                  "date_of_birth": {"type": "datetime", "coerce": lambda s: datetime.strptime(s, '%Y-%m-%d %H:%M:%S')},
                  "personal_phone": {"type": "list", "schema": {"regex": "^[0-9]+$", "maxlength": 10, "minlength": 10}},
                  "gender": {"allowed": ["F", "M"]},
                  "home_address_1": {"required": True},
                  "city": {"required": True},
                  "state": {"required": True},
                  "zip": {"required": True, "minlength": 5, "maxlength": 9},
                  "employment_status": {"allowed": ["Active", "Cobra"]},
                  "eligibility": {"type": "dict",
                                  "schema": {
                                      "benefit_plan_name": {"required": True},
                                      "plan_year": {"required": True},
                                      "coverage_tier_name": {"type": "string"}}
                                  }}

        active_eligibility_schema = {"coverage_termination_date": {"type": "datetime", "coerce": lambda s: datetime.strptime(s, '%Y-%m-%d %H:%M:%S')},
                                     "coverage_effective_date": {"type": "datetime", "coerce": lambda s: datetime.strptime(s, '%Y-%m-%d %H:%M:%S')}}
        cobra_eligibility_schema = {"cobra_termination_date": {"type": "datetime", "coerce": lambda s: datetime.strptime(s, '%Y-%m-%d %H:%M:%S')},
                                    "cobra_effective_date": {"type": "datetime", "coerce": lambda s: datetime.strptime(s, '%Y-%m-%d %H:%M:%S')}}

        schema1 = schema.copy()
        schema1.update(active_eligibility_schema)
        schema2 = schema.copy()
        schema2.update(cobra_eligibility_schema)
        employee_validation_response = v.validate(
            self.record, schema1) or v.validate(self.record, schema2)
        if not employee_validation_response:
            print(v.errors)

        schema = {"dependent_ssn": {"type": "string", "regex": "^[0-9]+$", "maxlength": 9, "minlength": 9},
                  "relationship_code": {"max": 23, "min": 0, "coerce": lambda s: int(s)},
                  "last_name": {"required": True},
                  "first_name": {"required": True},
                  "gender": {"allowed": ["F", "M"]},
                  "date_of_birth": {"type": "datetime", "coerce": lambda s: datetime.strptime(s, '%Y-%m-%d %H:%M:%S')},
                  "person_code": {"max": 99, "min": 1,  "coerce": lambda s: int(s)},
                  "eligibility": {"type": "dict",
                                  "schema": {
                                      "benefit_plan_name": {"required": True},
                                      "plan_year": {"required": True},
                                      "coverage_tier_name": {"required": True},
                                  }}}

        validation_response = [employee_validation_response]
        schema1 = schema.copy()
        schema1.update(active_eligibility_schema)
        schema2 = schema.copy()
        schema2.update(cobra_eligibility_schema)
        for dependent in self.record['dependents']:

            dep_validation_response = v.validate(
                dependent, schema1) or v.validate(dependent, schema2)
            validation_response.append(dep_validation_response)
            if not dep_validation_response:
                print(v.errors)
        if False in validation_response:
            return False
        self.lookup_user(validation_response)

    def lookup_user(self, validation_response):

        if validation_response:
            tv = TrueVault(self.tv_api_key)
            search_result, userids = tv.get_documents(
                'employee_ssn', [self.record['employee_ssn']])

            if len(search_result) > 1:
                # log multiple user found
                return

            if len(search_result) == 1:
                self.current_user_info, userid = search_result[0], userids[0]
                data, flipt_person_ids = self.update_record()
                #response = tv.update_document(data,userid)
                for id in flipt_person_ids:
                    self.insert_flipt_hierarchy(id)

            else:
                data, flipt_person_ids = self.insert_record()
                response = tv.create_document(data)
                for id in flipt_person_ids:
                    self.insert_flipt_hierarchy(id)

    def update_record(self):

        eligibility_updated = {}

        # updating new information with existing info not received from file
        for attribute, value in self.current_user_info.items():
            if value in ["dependents", "eligibility"]:
                continue
            if not self.record.get(attribute, ""):
                self.record[attribute] = value
                continue
            if self.record[attribute] != self.current_user_info[attribute]:
                eligibility_updated[self.current_user_info['flipt_person_id']] = True

        # updating eligiblity
        found_current_eligibility = False
        for idx, element in enumerate(self.current_user_info['eligibility']):
            if element['plan_year'] == self.record['eligibility']['plan_year']:
                found_current_eligibility = True
                for attribute, value in element.items():
                    if element[attribute] != self.record['eligibility'][attribute]:
                        eligibility_updated[self.current_user_info['flipt_person_id']] = True
                    self.current_user_info['eligibility'][idx][attribute] = self.record['eligibility'][attribute]
                self.record['eligibility'] = self.current_user_info['eligibility']

        if not found_current_eligibility:
            if self.current_user_info.get('eligibility', []):
                self.current_user_info['eligibility'].append(
                    self.record['eligibility'])
            self.current_user_info['eligibility'] = [
                self.record['eligibility']]
            eligibility_updated[self.current_user_info['flipt_person_id']] = True

        # updating dependents
        eligibility_updated, dependents_added = self.update_dependents(
            eligibility_updated)
        if eligibility_updated.keys():
            self.update_flipt_hierarchy(eligibility_updated.keys())

        attributes = base64.b64encode(
            str.encode(json.dumps(self.current_user_info)))
        data = {'attributes': attributes}
        return data, dependents_added

    def update_dependents(self, eligibility_updated):

        dependents_added = []
        dependents_removed = []
        dependents_covered = []

        current_dependents = {}
        current_dependents_covered = []
        for idx, dependent in enumerate(self.current_user_info['dependents']):
            current_dependents[dependent['dependent_ssn']] = idx
            current_dependents_covered.append(dependent['flipt_person_id'])

        for idx, dependent in enumerate(self.record['dependents']):
            if dependent['dependent_ssn'] in current_dependents.keys():
                current_dependent_info = self.current_user_info['dependents'][
                    current_dependents[dependent['dependent_ssn']]]
                dependents_covered.append(
                    current_dependent_info['flipt_person_id'])
                for attribute, value in dependent.items():
                    if attribute == 'eligibility':
                        found_current_eligibility = False
                        for idx1, element in enumerate(current_dependent_info['eligibility']):
                            if element['plan_year'] == dependent['eligibility']['plan_year']:
                                found_current_eligibility = True
                                for elig_attribute, elig_value in dependent['eligiblity'].items():
                                    if elig_value != element[elig_attribute]:
                                        eligibility_updated[current_dependent_info['flipt_person_id']] = True
                                    current_dependent_info['eligibility'][idx1][elig_attribute] = elig_value
                        if not found_current_eligibility:
                            eligibility_updated[current_dependent_info['flipt_person_id']] = True
                            if current_dependent_info.get('eligibility', []):
                                current_dependent_info['eligibility'].append(
                                    dependent['eligibility'])
                            else:
                                current_dependent_info['eligibility'] = [
                                    dependent['eligibility']]
                    else:
                        if value != current_dependent_info[attribute]:
                            eligibility_updated[current_dependent_info['flipt_person_id']] = True
                        current_dependent_info[attribute] = value
                current_dependent_info['updated_at'] = datetime.now(
                ).isoformat()
                self.current_user_info['dependents'][
                    current_dependents[dependent['dependent_ssn']]] = current_dependent_info
                tv = TrueVault(self.tv_api_key)
                search_results, userids = tv.get_documents(
                    'dependent_ssn', [dependent['dependent_ssn']])
                if userids:
                    search_result, userid = search_results[0], userids[0]
                    search_result['eligibility'] = current_dependent_info['eligibility']
                    attributes = base64.b64encode(
                        str.encode(json.dumps(search_result)))
                    data = {'attributes': attributes}
                    # tv.update_document(data, userid)

            else:
                dependent['flipt_person_id'] = str(
                    self.cb.counter('counterid', delta=1).value)
                dependent['created_at'] = dependent['updated_at'] = datetime.now(
                ).isoformat()
                self.insert_flipt_hierarchy(dependent['flipt_person_id'])
                dependents_added.append(dependent['flipt_person_id'])

        dependents_removed = current_dependents_covered - \
            dependents_covered.extend(dependents_added)
        return eligibility_updated, dependents_added

    def insert_record(self):

        flipt_person_ids = []

        self.record['flipt_person_id'] = str(
            self.cb.counter('counterid', delta=1).value)
        flipt_person_ids.append(self.record['flipt_person_id'])
        self.record['eligibility'] = [self.record['eligibility']]
        self.record['active'] = True
        self.record['group'] = 'ACSALL'

        self.record['created_at'] = self.record['updated_at'] = datetime.now(
        ).isoformat()

        fields_removed = {
            'employee': ['record_type', 'individual_action_code', 'overall_action_code', 'dependent_ssn', 'prev_employee_ssn', 'employee_ssn_change_indicator', 'relationship_code_indicator', 'participant_type', 'missing_dependents'],
            'dependents': ['employee_id', 'record_type', 'employee_ssn', 'individual_action_code', 'overall_action_code', 'prev_employee_ssn', 'employee_ssn_change_indicator', 'relationship_code_indicator', 'participant_type', 'missing_dependents']}
        for field in fields_removed['employee']:
            self.record.pop(field, '')
        for field in fields_removed['dependents']:
            for idx, _ in enumerate(self.record['dependents']):
                self.record['dependents'][idx].pop(field, '')
                if not self.record['dependents'][idx].get('flipt_person_id', ''):
                    self.record['dependents'][idx]['flipt_person_id'] = str(
                        self.cb.counter('counterid', delta=1).value)
                    flipt_person_ids.append(
                        self.record['dependents'][idx]['flipt_person_id'])

        password = str(self.record['zip'][:5]) + \
            str(self.record['employee_ssn'])[-4:]
        self.record['tmp_password'] = password
        attributes = base64.b64encode(str.encode(json.dumps(self.record)))
        data = {'username': self.record['work_email'], 'password': password,
                'attributes': attributes,
                'group_ids': '18ea364a-b672-459e-b390-c1071585fc5d,cacda7c1-28cb-4c51-9717-76e24b8e9a87'}
        return data, flipt_person_ids

    def insert_flipt_hierarchy(self, flipt_person_id):

        document = {
            "created_at": datetime.now().isoformat(),
            "dep_flipt_person_id": flipt_person_id,
            "domain_name": self.record['domain_name'],
            "emp_flipt_person_id": self.record['flipt_person_id'],
            "hp_eligibility_updated": "Y",
            "hp_extracted_date": "",
            "sc_extracted_date": "",
            "type": "flipt_person_hierarchy",
            "updated_at": datetime.now().isoformat()}

        self.cb.upsert(str(self.cb.counter('docid', delta=1).value), document)

    def update_flipt_hierarchy(self, flipt_person_ids):

        query = N1QLQuery("UPDATE `" + self.cb_bucket + "` SET hp_eligibility_updated='Y',updated_at=$update_date where type='flipt_person_hierarchy' and dep_flipt_person_id in $flipt_ids ",
                          update_date=datetime.now().isoformat(), flipt_ids=flipt_person_ids)

        # self.cb.n1ql_query(query).execute()
