from datetime import datetime
from json import load
from uuid import uuid4
from os import getenv
from csv import DictReader
from copy import deepcopy
from mimetypes import guess_type
from couchbase.cluster import Cluster, PasswordAuthenticator
from helpers import novartis_helpers as helper
from utils.Logging import Logging
from utils.TrueVault import TrueVault


class CarynHealthAccumulator(object):

    def __init__(self, file_name, config):
        cluster = Cluster(getenv('CB_HOST'))
        authenticator = PasswordAuthenticator(getenv('CB_USER'), getenv('CB_PASSWORD'))
        cluster.authenticate(authenticator)
        
    
        self._bucket = getenv('CB_BUCKET')
        self._cb = cluster.open_bucket(self._bucket)
        
        self._file_name = file_name
        self.__file_type = guess_type(file_name)[0]
        self._config = config
        self.true_vault = TrueVault('8defa0cd-b297-4dce-a1fe-22d4a5281975')

    def _read_file(self):

        data = None
        
        if self.__file_type == 'application/json':
            with open(self._file_name) as json_file:
                data = load(json_file)
            return data
        
        if self.__file_type == 'text/csv':
            data = {
                'recordList': []
            }
            with open(self._file_name, newline='') as csvfile:
                reader = DictReader(csvfile)
                for row in reader:
                    data['recordList'].append(dict(row))
                
        return data

    def _get_truevault_data(self, formatted_data):

        documents = self.true_vault.get_documents('employee_ssn', list(map(lambda x: x['emp_ssn'], formatted_data)))

    
      
        user_documents = documents[0]

        if not user_documents:
            return []

        truevault_data = []

        for record in formatted_data:
            user_data = {
                'dep_flipt_person_id': '',
                'emp_flipt_person_id': '',
                'plan_name': '',
                'plan_year': '',
                'coverage_tier': '',
            }

            document = \
                list(filter(lambda document_ssn: record['emp_ssn'] == document_ssn['employee_ssn'], user_documents))[0]

            eligibility = helper.get_recent_user_eligibility_truevault(document['eligibility'])

            if record['emp_ssn'] != record['patient_ssn']:
              
                dep_flipt_person_id = \
                    list(filter(lambda dep: dep['dependent_ssn'] == record['patient_ssn'], document['dependents']))
                if not dep_flipt_person_id:
                    continue
                dep_flipt_person_id = dep_flipt_person_id[0]
                user_data['dep_flipt_person_id'] = dep_flipt_person_id['flipt_person_id']

                eligibility = helper.get_recent_user_eligibility_truevault(dep_flipt_person_id['eligibility'])

            user_data['emp_flipt_person_id'] = document['flipt_person_id']
            user_data['plan_name'] = eligibility['benefit_plan_name']
            user_data['plan_year'] = eligibility['plan_year']
            user_data['coverage_tier'] = eligibility['coverage_tier_name']
            user_data['dep_flipt_person_id'] = user_data['dep_flipt_person_id'] if user_data['dep_flipt_person_id'] \
                else \
                user_data['emp_flipt_person_id']

            record.pop('emp_ssn')
            record.pop('patient_ssn')
            record.update(
                **user_data
            )

            truevault_data.append(record)

        return truevault_data

    def prepare_fields(self):

        records = self._read_file()['recordList']

        formatted_records = []
        date = datetime.now().isoformat()

        for record in records:
            formatted_records.append({
                'emp_ssn': record['subscriberSSN'],
                'patient_ssn': record['patientSSN'],
                'carrier_deductible_accrued': record['patientDEDAmtPaid'],
                'carrier_out_of_pocket_accrued': record['patientOOPAmtPaid'],
                'out_of_pocket_accrued': record['patientOOPAmtPaid'],
                'deductible_accrued': record['patientDEDAmtPaid'],
                'domain_name': self._config['domain_name'],
                'type': 'deductible',
                'message': "Person Found Successfully",
                'created_date': date,
                'data_extracted_date': date,
                'updated_date': date
            })

        deductible_data = self._get_truevault_data(formatted_records)
        
        for data in deductible_data:
            self._cb.upsert(uuid4().hex, data)
