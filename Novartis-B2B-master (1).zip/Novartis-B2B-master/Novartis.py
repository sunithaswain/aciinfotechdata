# -*-coding: latin-1
from collections import defaultdict
from copy import deepcopy
from datetime import datetime, timedelta
from os import getenv

from couchbase.n1ql import N1QLQuery

from NovartisAccumulator import NovartisAccumulator as Accumulator
from NovartisHeader import NovartisHeader
from NovartisTail import NovartisTail
from helpers import novartis_helpers as helper
from utils.Couchbase import CouchbaseConnector
from utils.Field import Field
from utils.TrueVault import TrueVault
from utils.config_runner import ConfigRunner


class Novartis(object):
    """Horizon class to abstract the Horizon import files."""

    def __init__(self, config):
        self.job_id = config['job_id']
        self.job_name = config['job_name']

        self.cursor = CouchbaseConnector()
        self._bucket_name = getenv('CB_BUCKET')

        self._config = config
        self.config_runner = ConfigRunner()
        self.config_fields = self._config['fields']
        self._claim_sequence_number = 999
        self.novartis_header = NovartisHeader(10, self._config)
        self._novartis_accumulator_documents = []
        self._file_name = config['file_name']
        self.true_vault = TrueVault('8defa0cd-b297-4dce-a1fe-22d4a5281975', job_id=self.job_id)

    def get_novartis_header(self):
        return self.novartis_header

    def query(self):
        """Query will make couchbase query and returns a result."""
        end_date = self._config['job_end_date']
        start_date = self._config['job_start_date']

        # start_date = start_date.strftime('%Y-%m-%dT%H:%m:%S.%f')
        # end_date = end_date.strftime('%Y-%m-%dT%H:%m:%S.%f')

        # make sure that p from b1 and b2 rejection
        query_string = f"SELECT * FROM `{self._bucket_name}` WHERE type='claim' AND " \
                       f"updateDate > DATE_FORMAT_STR('{start_date}', '1111-11-11T00:00:00.Z') AND " \
                       f"updateDate <= DATE_FORMAT_STR('{end_date}', '1111-11-11T00:00:00.Z') AND " \
                       f"claim_response.transaction_response_status IN ['P', 'A'] ORDER BY auth_id"
        return self.cursor.query(query_string)

    def map_from_truevault(self, claim, user, field_config):
        """map_from_truevault will map claim to values from truevault"""
        cardholder_id = helper.get_key(claim, 'claim_request.cardholder_id')[:-2]
        person_code = helper.get_key(claim, 'claim_request.cardholder_id')[-2:]
        field_name = field_config['mapped_field'].split('.')[1]

        if field_config['auto']:
            if person_code != '01':
                try:
                    dependable = list(filter(lambda dependant:
                                             dependant['member_id'] == cardholder_id + person_code
                                             and dependant['person_code'] == person_code,
                                             user['dependents']))[0]
                except KeyError:
                    # There is a user with no member id
                    return ''

                return dependable[field_name]
        return user[field_name]

    def set_fillers(self, amount_applied, accumulator_field):
        fields = []
        start, end = 430, 438
        for i in range(1, 8):
            fields.append(
                Field(f"filler_{i}", {'start_end': [start, end], 'field_length': 9, 'value': ''.ljust(9, '0')}).field()
            )
            start += 21
            end += 21

        return fields

    def map_fields(self, claims, fields, users, formulary_data, ndc_drugs):
        """map_fields will map config values to claims."""
        mapped_claims = []

        for claim in claims:
            cardholder_id = helper.get_key(claim, 'claim_request.cardholder_id')

            user_data = helper.get_user_from_truevault(cardholder_id, users)[0]
            if 'eligibility' not in user_data:
                continue
            eligibility = helper.get_recent_user_eligibility_truevault(user_data['eligibility'])

            for field_config in fields.values():
                if field_config['mapped_field'] and \
                        not field_config['mapped_field'].startswith('true_vault'):
                    field_name = '.'.join(field_config['mapped_field'].split('.')[1:])
                    field_config['value'] = helper.get_key(claim, field_name)

                if field_config['mapped_field'].startswith('true_vault'):
                    field_config['value'] = self.map_from_truevault(claim, user_data, field_config)
                    if field_config['auto']:
                        if field_config['auto'].get('format'):
                            field_config['value'] = "".join(field_config['value'].split(" ")[0].split("-"))
                    if 'ssn' in field_config['mapped_field']:
                        field_config['value'] = ''.join(field_config['value'].split('-'))[:9]

            # Change that. You are doing it twice
            amount_applied_value = helper.float_to_right_justified(
                helper.get_key(claim, 'claim_response.patient_pay_amount'))
            amount_applied_field = Field('amount_applied_1',
                                         {'start_end': [409, 418], 'field_length': 9, 'value': amount_applied_value})

            accumulator_value = self._get_accumulator_type(user_data, claim, formulary_data, ndc_drugs, eligibility)
            accumulator_field = Field('accumulator_type_1',
                                      {'start_end': [398, 399], 'field_length': 1, 'value': accumulator_value})

            fields.update(
                **amount_applied_field.field(),
                **accumulator_field.field()
            )
            accumulator_user_data = helper.get_user_data_member_id(user_data, cardholder_id)
            accumulator = Accumulator(self._config, fields, accumulator_user_data, self._claim_sequence_number,
                                      'pharmacy_accumulator')

            self._novartis_accumulator_documents.append(accumulator)
            fields['claim_number']['value'] = ''.ljust(
                fields['claim_number']['field_length'] - len(fields['claim_number']['value']) + 1, '0') + \
                                              fields['claim_number']['value']

            fields['claim_status']['value'] = 'X' if fields['claim_status']['value'] == 'A' else 'P'

            fillers = self.set_fillers(amount_applied_field.field(), accumulator_field.field())

            for filler in fillers:
                fields.update(
                    **filler
                )

            fields['record_timestamp']['value'] = helper.format_time(fields['record_timestamp']['value'],
                                                                     '%Y-%m-%d-%H.%M.%S.%f', '%Y-%m-%dT%H:%M:%S.%f')

            fields['reason_code']['value'] = 'ADJUSTMENT' if fields['claim_status']['value'] == 'X' else 'CLAIM'
            mapped_claims.append(fields)

        return mapped_claims

    def _get_accumulator_type(self, user_data, claim, formulary_data, ndc_drugs, eligibility):
        plan_name = eligibility['benefit_plan_name']
        plan_year = eligibility['plan_year']
        company = user_data['domain_name']

        ndc_drug = list(filter(lambda drug: drug["ndc"] == claim["claim_request"]["product_id"], ndc_drugs))[0]
        formulary_data = list(filter(lambda formulary:
                                     formulary["ddid"] == ndc_drug["ddid"] and
                                     formulary["gpi"] == ndc_drug["gpi"] and
                                     formulary["drug_name"] == ndc_drug["drug_name"], formulary_data))[0]
        deductable_exempt = ""

        for value in formulary_data["company_formulary"]:
            if value["company"] == company and value["plan_name"] == plan_name and value["plan_year"] == plan_year:
                deductable_exempt = value["deductibleexempted"]

        if deductable_exempt == "1":
            return "O"
        return "D"

    def _get_ndc_data_by_product_id(self, products_id):
        ndc_drugs_query = f'SELECT type, brand_generic, ddid, drug_name, gpi, ndc FROM `{self._bucket_name}`' \
                          f"WHERE type='ndc_drugs' AND ndc IN [{helper.stringified_ids(products_id)}]"

        query_result = self.cursor.query(ndc_drugs_query, "")

        unique_ids = {
            'ddids': set(),
            'gpis': set(),
            'drug_name': set()
        }

        results = []
        for result in query_result:
            unique_ids['ddids'].add(result['ddid'])
            unique_ids['gpis'].add(result['gpi'])
            unique_ids['drug_name'].add(result['drug_name'])
            results.append(result)

        return unique_ids, results

    def _get_formulary_data(self, product_ids):
        ndc_result, ndc_drugs = self._get_ndc_data_by_product_id(list(product_ids))

        formulary_query = f'SELECT type, ddid, company_formulary, gpi, drug_name' \
                          f' FROM `{self._bucket_name}` WHERE type="formulary"' \
                          f' AND ddid IN [{helper.stringified_ids(list(ndc_result["ddids"]))}]' \
                          f' AND gpi IN [{helper.stringified_ids(list(ndc_result["gpis"]))}]' \
                          f' AND drug_name IN [{helper.stringified_ids(list(ndc_result["drug_name"]))}]'

        query_result = self.cursor.query(formulary_query, "")

        return query_result, ndc_drugs

    def set_sequence_number(self, auth_id, claims):
        # old_claims = self._test_get_old_claims(auth_id)
        # # Assume that the query would always return P or X statuses
        # if old_claims:
        #     for index in range(0, len(claims)):
        #         claims[index]['claim_sequence_number']['value'] = str(old_claims[0]['claim_sequence_number'])
        #     return claims

        for index in range(0, len(claims)):
            claims[index]['claim_sequence_number']['value'] = str(self._claim_sequence_number)
        self._claim_sequence_number -= 1

        return claims

    def upate_accumulator_field(self, field_name, field_value, meesage_id):
        update_query = f"UPDATE `{self._bucket_name}` SET {field_name} = '{field_value}' WHERE type='pharmacy' AND " \
                       f"message_id='{meesage_id}'"

        query = N1QLQuery(update_query)
        self.cursor.get_cursor_object().n1ql_query(query).execute()

    def _get_previous_accumulator_documents(self):
        # Timedelta to use previous days
        previous_days = self._config['job_start_date'] - timedelta(days=1)
        accumulator_document_query = f"SELECT claim_status, claim_number, claim_sequence, message_id FROM `" \
                                     f"{self._bucket_name}` " \
                                     f"WHERE " \
                                     f"record_timestamp>=DATE_FORMAT_STR('{previous_days}', '1111-11-11T00:00:00.Z') " \
                                     f"and type='pharmacy'"
        return self.curosr.query(accumulator_document_query)

    def _get_previous_claims(self):
        previous_days = self._config['job_start_date'] - timedelta(days=1)
        claim_document_query = f"SELECT * FROM `{self._bucket_name}` WHERE type='claim' AND updateDate >= " \
                               f"DATE_FORMAT_STR('{previous_days}', '1111-11-11T00:00:00.Z') AND " \
                               f"claim_response.transaction_response_status IN ['X', 'A']"

        return self.cursor.query(claim_document_query)

    def get_reconsoliation_claims(self, users, formulary_data, ndc_drugs):
        # fetch accumulator documents for previous day
        accumulator_documents = self._get_previous_accumulator_documents()
        if not accumulator_documents:
            return

        claim_documents = self._get_previous_claims()
        if not claim_documents:
            return

        config = ConfigRunner()

        claims = []

        for accumulator_dcoument in accumulator_documents:
            claim = list(map(lambda x: x, filter(
                lambda x: x['auth_id'] == accumulator_dcoument['claim_number'] and
                          x['claim_response']['transaction_response_status'] == 'A' and
                          accumulator_dcoument['claim_status'] == 'P', claim_documents)))
            if claim:
                fields = config.read(self.config_fields)
                mapped_claims = {
                    accumulator_dcoument['claim_number']: self.map_fields(claim, fields, users, formulary_data,
                                                                          ndc_drugs)
                }
                claim_sequence_field = Field('claim_sequence_number',
                                             {'start_end': [355, 358], 'value': accumulator_dcoument['claim_number']})
                for i, mapped_claim in enumerate(mapped_claims[accumulator_dcoument['claim_number']]):
                    mapped_claims[accumulator_dcoument['claim_number']][i].update(**claim_sequence_field.field())
                self.upate_accumulator_field('claim_status', 'X', accumulator_dcoument['message_id'])
                claims.append(mapped_claims)


    def _get_old_claims(self, claims):
        pass

    def _format_claims_data(self, grouped_claims):
        formatted_results = []
        # Claims whose sequence is not completed

        for auth_id, claims in grouped_claims.items():
            if len(claims) > 2:
                sub_claims = [[claims[0]]]

                for i in range(1, len(claims)):
                    if len(sub_claims[-1]) == 1 and sub_claims[-1][0]['claim_response']['transaction_code'] != \
                            claims[i]['claim_response']['transaction_code']:
                        sub_claims[-1].append(claims[i])
                    else:
                        sub_claims.append([claims[i]])

                for claim in sub_claims:
                    formatted_results.append({
                        auth_id: claim
                    })
            else:
                formatted_results.append({
                    auth_id: claims
                })

        # self._get_old_claims(not_finished_sequence_claim_ids)

        return formatted_results

    def prepare_fields(self):
        config = ConfigRunner()
        result = self.query()

        groupped_claims_auth_id = defaultdict(list)
        cardholder_ids = []
        distinct_prod_ids = set()

        for claim in result:
            cardholder_id = helper.get_key(claim, f'claim_request.cardholder_id')[:-2]
            auth_id = helper.get_key(claim, f'auth_id')
            claim_value = claim
            product_id = helper.get_key(claim, f'claim_request.product_id')

            cardholder_ids.append(cardholder_id)
            groupped_claims_auth_id[auth_id].append(claim_value)
            distinct_prod_ids.add(product_id)

        formatted_claims = self._format_claims_data(groupped_claims_auth_id)

        formulary_data, ndc_drugs = self._get_formulary_data(distinct_prod_ids)

        claims = []

        truevault_users = self.true_vault.get_documents('flipt_person_id', cardholder_ids, job_id=self.job_id,
                                                        job_name=self.job_name, domain=self._config['domain'])[0]
        # self.get_reconsoliation_claims(truevault_users, formulary_data, ndc_drugs)

        for value in formatted_claims:
            fields = config.read(self.config_fields)

            claim = {
                auth_id: self.map_fields(*value.values(), fields, truevault_users, formulary_data, ndc_drugs)
            }

            claim[auth_id] = self.set_sequence_number(auth_id, claim[auth_id])

            _claim = deepcopy(claim)

            claims.append(_claim)

        # for accumulator_document in self._novartis_accumulator_documents:
        #     accumulator_document.insert_accumulator_data()

        return claims

    def write_file(self, claims, file_name):

        file = open(file_name, "w")
        # Hardcoded values
        header = self.novartis_header.get_header(self._config['job_start_date'], self._config['job_end_date'])
        header_row = self.write_rows([header])
        file.write(header_row)
        file.write("\n")
        # End of hardcoded values
        row_count = 0
        for claim in claims:
            for auth_id, values in claim.items():
                values = sorted(values, key=lambda claim: claim['claim_status']['value'])
                row_count += len(values)
                rows = self.write_rows(values)
                file.write(rows)
                file.write("\n")

        tail = NovartisTail(row_count)
        tail_rows = self.write_rows([tail.get_tail()])
        file.write(tail_rows)
        file.close()

    def write_rows(self, claims):

        records = []
        for claim in claims:
            record = list(''.ljust(self._config['file_record_size']))
            for field_name in claim.keys():
                start = claim[field_name]['start_end'][0]
                value = claim[field_name].get('value', '')

                counter = 0
                for i in range(start - 1, len(value) + start - 1):
                    record[i] = value[counter]
                    counter += 1

            records.append(''.join(record))

        return "\n".join(records)


    def map_member_id_claim(self, claim, truevault_data):
        member_id = claim['member_id']['value']
        first_name = claim['first_name']['value']
        last_name = claim['last_name']['value']
        date_of_birthday = str(datetime.strptime(claim['date_of_birth']['value'], '%Y%m%d'))

        employee_ssn = "-".join([member_id[:3], member_id[3:5], member_id[-4:]])

        user = list(filter(lambda x: x["employee_ssn"] == employee_ssn, truevault_data))
        processed_timestamp = helper.format_time(str(datetime.now()), "%Y-%m-%d-%H.%M.%S.%f", "%Y-%m-%d %H:%M:%S.%f")
        if not user:
            claim.update({
                "ack_processed_timestamp": processed_timestamp,
                "ack_result": "FAIL",
                "ack_result_message": "Member not found in the system"
            })
            return claim, None
        eligibility = helper.get_recent_user_eligibility_truevault(user['eligibility'])

        dep_flipt_person_id_field = user['flipt_person_id']
        for dependant in user['dependents']:
            if first_name == dependant['first_name'] and last_name == dependant['last_name'] and date_of_birthday == \
                    dependant['date_of_birth']:
                dep_flipt_person_id_field = dependant["flipt_person_id"]
                break

        user_data = {
            'emp_flipt_person_id': user['flipt_person_id'],
            'dep_flipt_person_id': dep_flipt_person_id_field,
            'plan_name': eligibility['benefit_plan_name'],
            'plan_year': eligibility['plan_year'],
            'coverage_tier': eligibility['coverage_tier_name'],
        }
        claim.update({
            "ack_processed_timestamp": processed_timestamp,
            "ack_result": "PASS",
        })
        return claim, user_data
    

    def add_accumulator_data(self):
        for document in self._novartis_accumulator_documents:
            document.insert_accumulator_data()
