from utils.ConfigReader import ConfigReader
from EligibilityUpdate import EligibilityUpdate
import struct
import os
from couchbase.cluster import Cluster, PasswordAuthenticator
from couchbase.n1ql import N1QLQuery


class EligibilityFileReader():

    def __init__(self):

        cluster = Cluster(os.environ['CB_URL'])
        authenticator = PasswordAuthenticator(
            os.environ['CB_APPS_USER'], os.environ['CB_APPS_PASSWORD'])
        cluster.authenticate(authenticator)
        self.cb_bucket = os.environ['CB_INSTANCE']
        self.cb = cluster.open_bucket(self.cb_bucket)
        self.coverage_tier_map = {}
        self.plans = []
        self.relationship_codes = {}

    def read_file(self):

        # read data configuration
        config = ConfigReader('EligibilityConfig.xlsx', sheet_name='Header')
        header_config = config.get_config()
        config = ConfigReader('EligibilityConfig.xlsx', sheet_name='Detail')
        detail_config = config.get_config()
        config = ConfigReader('EligibilityConfig.xlsx', sheet_name='Trailer')
        trailer_config = config.get_config()
        header_field_widths = tuple(
            [field_info['field_length'] for field, field_info in header_config.items()])
        detail_field_widths = tuple(
            [field_info['field_length'] for field, field_info in detail_config.items()])
        trailer_field_widths = tuple(
            [field_info['field_length'] for field, field_info in trailer_config.items()])

        header_format_string = ' '.join('{}{}'.format(abs(fw), 'x' if fw < 0 else 's')
                                        for fw in header_field_widths)
        detail_format_string = ' '.join('{}{}'.format(abs(fw), 'x' if fw < 0 else 's')
                                        for fw in detail_field_widths)
        trailer_format_string = ' '.join('{}{}'.format(abs(fw), 'x' if fw < 0 else 's')
                                         for fw in trailer_field_widths)
        header_struct = struct.Struct(header_format_string)
        detail_struct = struct.Struct(detail_format_string)
        trailer_struct = struct.Struct(trailer_format_string)
        header_parse = header_struct.unpack_from
        detail_parse = detail_struct.unpack_from
        trailer_parse = trailer_struct.unpack_from

        # map fields
        detail_config = self.map_fields(detail_config)
        employee_record = {}
        dependent_records = []
        self.get_data()

        # read data in file and process each record
        f = open('EligibilitySample.txt', 'r')
        for line in f.read():
            if line and line[0] == '2':
                if employee_record:
                    self.process_record(employee_record, dependent_records)
                employee_record = detail_config.copy()
                dependent_records = []
                tuple_index = 0
                constants = detail_parse(line)
                for field, _ in employee_record.items():
                    employee_record[field]['constant'] = constants[tuple_index]
                    tuple_index += 1
            elif line and line[0] == '3':
                dependent_record = detail_config.copy()
                tuple_index = 0
                constants = detail_parse(line)
                for field, _ in dependent_record.items():
                    dependent_record[field]['constant'] = constants[tuple_index]
                    tuple_index += 1
                dependent_records.append(dependent_record)

        if employee_record:
            self.process_record(employee_record, dependent_records)

    def map_fields(self, detail_config):

        field_map = {'record_type': 'record_type',
                     'participant_ssn/taxpayer_id': 'employee_ssn',
                     'dependent_number': 'person_code',
                     'dependent_ssn/_taxpayer_id': 'dependent_ssn',
                     'individual_action_code': 'individual_action_code',
                     'overall_action_code': 'overall_action_code',
                     'previous_participant_ssn/taxpayer_id': 'prev_employee_ssn',
                     'data_element_206_change_indicator': 'employee_ssn_change_indicator',
                     'relationship_code': 'relationship_code',
                     'data_element_208_change_indicator': 'relationship_code_indicator',
                     'first_name': 'first_name',
                     'last_name': 'last_name',
                     'employee_id': 'employee_id',
                     'birth_date': 'date_of_birth',
                     'hire_date': 'hire_date',
                     'gender_code': 'gender',
                     'mailing_address_line_1': 'home_address_1',
                     'mailing_address_line_2': 'home_address_2',
                     'mailing_address_line_3': 'home_address_3',
                     'mailing_city': 'city',
                     'mailing_state/province': 'state',
                     'mailing_zip_code/postal_code': 'zip',
                     'telephone_number_1': 'personal_phone',
                     'telephone_number_2': 'phone_2',
                     'participant_type': 'participant_type',
                     'missing_dependents': 'missing_dependents',
                     'coverage_tier': 'coverage_tier_name',
                     'coverage_type': 'employment_status',
                     'coverage_end_date': 'coverage_termination_date',
                     'coverage_effective_date': 'coverage_effective_date',
                     'e-mail_address': 'work_email'
                     }
        for key, value in field_map.items():
            if detail_config.get(key, {}):
                detail_config[value] = detail_config[key]
                detail_config.pop(key)
        return detail_config

    def get_data(self):

        query = N1QLQuery('select employee_interface,flipt_coverage_tier from `' +
                          self.cb_bucket + '` where type="coverage_tier" and domain_name="NOVARTIS001"')
        for result in self.cb.n1ql_query(query):
            self.coverage_tier_map[result['employee_interface']
                                   ] = result['flipt_coverage_tier']

        query = N1QLQuery('select plan_name,plan_year from `' +
                          self.cb_bucket + '` where type="rxplan_master" and domain_name="NOVARTIS001" ')
        for result in self.cb.n1ql_query(query):
            if result['plan_year'] not in self.plans:
                self.plans[result['plan_year']] = [result['plan_name']]
            else:
                self.plans[result['plan_year']].append(result['plan_name'])

    def process_record(self, employee_record, dependent_records):

        record = self.format_data(employee_record, dependent_records)

        obj = EligibilityUpdate(self.cb, self.cb_bucket)
        obj.validate_data(record)

    def format_data(self, employee_record, dependent_records):
        

        def customized_format(original, record, key):

            if key == 'coverage_effective_date' and len(original[key]['constant']) == 8:
                record['eligibility'][key] = original[key]['constant'][:4] + \
                    '-'+original[key]['constant'][4:6] + \
                    '-' + original[key]['constant'][6:] + ' 00:00:00'
                record['eligibility']['benefit_plan_name']= self.plans[original[key]['constant'][:4]][0]
                record['eligibility']['plan_year']= original[key]['constant'][: 4]
                if original['employment_status']['constant'].lower() == 'cobra':
                    record['eligibility']['cobra_effective_date']= record['eligibility'][key]
                    record['eligibility'][key]= ''
            elif key == 'coverage_termination_date':
                if original['coverage_termination_date']['constant'][:4] != original['coverage_effective_date']['constant'][:4]:
                    original['coverage_termination_date']['constant'] = original['coverage_effective_date']['constant'][: 4]+'-12-31 23:59:59'
                record['eligibility'][key]= original[key]['constant'][: 4] + '-'+original[key]['constant'][4:6] +'-' + original[key]['constant'][6:] + ' 23:59:59'
                if original.lower() == 'cobra':
                    record['eligibility']['cobra_termination_date']= record['eligibility'][key]
                    record['eligibility'][key]= ''
            elif key == 'date_of_birth':
                record[key]= original[key]['constant'][: 4] +'-'+original[key]['constant'][4: 6] +'-' + original[key]['constant'][6:] + ' 00:00:00'
            elif key == 'hire_date' and original[key]['constant']:
                record[key] = original[key]['constant'][: 4] +'-'+original[key]['constant'][4: 6] +'-' + original[key]['constant'][6:] + ' 00:00:00'
            elif key == 'employment_status':
                record[key] = original[key]['constant'].title()
            elif key in ['first_name','last_name']:
                record[key] = original[key]['constant'].upper()
            elif key == 'coverage_tier_name':
                record['eligibility'][key] = self.coverage_tier_map.get(original[key]['constant'], '')
            elif key == 'home_address_3' and original[key]['constant']:
                record['home_address_2'].append(',' + original[key]['constant'])
            elif key == 'personal_phone' and original[key]['constant']:
                record[key].append(original[key]['constant'])
            elif key == 'relationship_code':
                record[key] = original[key]['constant']
                record['relationship'] = self.relationship_codes.get(original['relationship_code']['constant'],'')
            else:
                record[key]= original[key]['constant']

            return record


        record= {"employee_id": '',
                  "employee_ssn": '',
                  "last_name": '',
                  "first_name": '',
                  "date_of_birth": '',
                  "personal_phone": [],
                  "gender": '',
                  "home_address_1": '',
                  "home_address_2": '',
                  "city": '',
                  "state": '',
                  "zip": '',
                  "employment_status": '',
                  "dependents": [],
                  "eligibility": {"benefit_plan_name": "",
                                  "plan_year": "",
                                  "coverage_termination_date": "",
                                  "coverage_effective_date": "",
                                  "coverage_tier_name": "",
                                  "cobra_effective_date": "",
                                  "cobra_termination_date": ""
                                  }}

        dependents= {"employee_id": "",
                      "dependent_ssn": "",
                      "relationship": "",
                      "last_name": "",
                      "first_name": "",
                      "gender": "",
                      "date_of_birth": "",
                      "person_code": "",
                      "personal_phone":[],
                      "eligibility": {"coverage_termination_date": "",
                                      "coverage_effective_date": "",
                                      "coverage_tier_name": "",
                                      "cobra_effective_date": "",
                                      "cobra_termination_date": "",
                                      "benefit_plan_name": "",
                                      "plan_year": "",
                                      }}


        for key, _ in employee_record.items():
            try:
                record = customized_format(employee_record, record, key)
            except:
                continue
        record['domain_name'] = 'NOVARTIS001'

        for dependent in dependent_records:
            deprecord= dependents.copy()
            deprecord['employment_status']= record.get('employment_status', '')
            for key, _ in dependent.items():
                try:
                    deprecord= customized_format(dependent, deprecord, key)
                except:
                    continue
            deprecord.pop('employment_status')
            record['dependents'].append(deprecord)


        return record

employee_record = {'record_type': {'constant':'2'},
                   'employee_ssn': {'constant': '334543653'},
                    'person_code': {'constant': '00'},
                    'dependent_ssn': {'constant': ''},
                    'individual_action_code': {'constant': 'Changes'},
                   'overall_action_code': {'constant': 'Changes'},
                   'prev_employee_ssn': {'constant': ''},
                   'employee_ssn_change_indicator': {'constant': 'N'},
                   'relationship_code': {'constant': ''},
                   'relationship_code_indicator': {'constant': 'N'},
                   'first_name': {'constant': 'Employee'},
                   'last_name': {'constant': 'TEST'},
                   'employee_id': {'constant': '1010101'},
                   'date_of_birth': {'constant': '19800101'},
                   'hire_date': {'constant': '20110202'},
                   'gender': {'constant': 'M'},
                   'home_address_1': {'constant': '111 Coolidge Street'},
                   'home_address_2': {'constant': 'Apt 101-B'},
                   'home_address_3': {'constant': '23'},
                   'city': {'constant': 'South Plainfield'},
                   'state': {'constant': 'NJ'},
                   'zip': {'constant': '07080'},
                   'personal_phone': {'constant': '1111111111'},
                   'participant_type': {'constant': 'Active'},
                   'missing_dependents': {'constant': 'N'},
                   'coverage_tier_name': {'constant': 'D'},
                   'employment_status': {'constant': 'Active'},
                   'coverage_termination_date': {'constant': '20191230'},
                   'coverage_effective_date': {'constant': '20191212'},
                   'work_email': {'constant': 'testacct1@novartis.com'}
}
dependent_records = [{'record_type': {'constant':'3'},
                    'employee_ssn':  {'constant': '334543653'},
                    'person_code': {'constant': '01'},
                    'dependent_ssn': {'constant': '334543655'},
                    'individual_action_code': {'constant': 'Changes'},
                   'overall_action_code': {'constant': 'Changes'},
                   'prev_employee_ssn': {'constant': ''},
                   'employee_ssn_change_indicator': {'constant': 'N'},
                   'relationship_code': {'constant': '01'},
                   'relationship_code_indicator': {'constant': 'N'},
                     'first_name': {'constant': 'SPOUSE'},
                   'last_name': {'constant': 'TEST'},
                   'employee_id': {'constant': '1010101'},
                   'date_of_birth': {'constant': '19820606'},
                   'hire_date': {'constant': ''},
                   'gender': {'constant': 'F'},
                   'home_address_1': {'constant': '111 Coolidge Street'},
                   'home_address_2': {'constant': 'Apt 101-B'},
                   'home_address_3': {'constant': '23'},
                   'city': {'constant': 'South Plainfield'},
                   'state': {'constant': 'NJ'},
                   'zip': {'constant': '07080'},
                   'personal_phone': {'constant': '1212121212'},
                   'participant_type': {'constant': 'Active'},
                   'missing_dependents': {'constant': 'N'},
                   'coverage_tier_name': {'constant': 'D'},
                   'employment_status': {'constant': 'Active'},
                   'coverage_termination_date': {'constant': '20191230'},
                   'coverage_effective_date': {'constant': '20191212'},
                   'work_email': {'constant': 'testacctspouse@novartis.com'}
},
{'record_type': {'constant':'3'},
 'employee_ssn':  {'constant': '334543653'},
                    'person_code': {'constant': '03'},
                    'dependent_ssn': {'constant': '334543656'},
                    'individual_action_code': {'constant': 'Changes'},
                   'overall_action_code': {'constant': 'Changes'},
                   'prev_employee_ssn': {'constant': ''},
                   'employee_ssn_change_indicator': {'constant': 'N'},
                   'relationship_code': {'constant': '03'},
                   'relationship_code_indicator': {'constant': 'N'},
                   'first_name': {'constant': 'CHILD'},
                   'last_name': {'constant': 'TEST'},
                   'employee_id': {'constant': ''},
                   'date_of_birth': {'constant': '20100505'},
                   'hire_date': {'constant': ''},
                   'gender': {'constant': 'M'},
                   'home_address_1': {'constant': '111 Coolidge Street'},
                   'home_address_2': {'constant': 'Apt 101-B'},
                   'home_address_3': {'constant': '23'},
                   'city': {'constant': 'South Plainfield'},
                   'state': {'constant': 'NJ'},
                   'zip': {'constant': '07080'},
                   'personal_phone': {'constant': ''},
                   'participant_type': {'constant': 'Active'},
                   'missing_dependents': {'constant': 'N'},
                   'coverage_tier_name': {'constant': 'D'},
                   'employment_status': {'constant': 'Active'},
                   'coverage_termination_date': {'constant': '20191230'},
                   'coverage_effective_date': {'constant': '20191212'},
                   'work_email': {'constant': ''}
}]

obj1 = EligibilityFileReader()
obj1.plans = {'2019': ['HSA Value']}
obj1.coverage_tier_map = {'D': 'Employee and Family'}
obj1.relationship_codes = {'01':'Spouse','03':'Child'}
obj1.process_record(employee_record,dependent_records)
