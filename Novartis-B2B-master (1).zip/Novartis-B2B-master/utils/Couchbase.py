from os import getenv

from couchbase.cluster import Cluster, PasswordAuthenticator
from couchbase.n1ql import N1QLQuery


class CouchbaseConnector(object):

    def __init__(self):
        try:
            self._cluster = Cluster(getenv('CB_HOST'))
            self._bucket_name = getenv('CB_BUCKET')
            self._authentticator = PasswordAuthenticator(getenv('CB_USER'), getenv('CB_PASSWORD'))
            self._cluster.authenticate(self._authentticator)
            self._cb = self._cluster.open_bucket(self._bucket_name)
        except Exception as ex:
            raise Exception("Could not authenticate with couchbase or missing env variables")

    def query(self, query_string, bucket_name=getenv('CB_BUCKET')):
        """Query takes query string and returns list of objects."""
        query = N1QLQuery(query_string)

        results = []
        try:
            query_results = self._cb.n1ql_query(query)
        except Exception as ex:
            raise Exception("Could ")

        for result in query_results:
            if bucket_name:
                results.append(result[self._bucket_name])
            else:
                results.append(result)

        return results

    def get_cursor_object(self):
        return self._cb
