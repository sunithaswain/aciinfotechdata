class Field(object):

    def __init__(self, field_name, properties):
        self._field_name = field_name
        self._field = {
            'constant': '',
            'field_length': '',
            'mapped_field': '',
            'position': '',
            'start_end': '',
            'auto': {},
            'value': ''
        }
        for field_key in properties.keys():
            self._field[field_key] = properties[field_key]

    def set_field(self, field_name, value):
        self._field[field_name] = value

    def field(self):
        return {self._field_name: self._field}
