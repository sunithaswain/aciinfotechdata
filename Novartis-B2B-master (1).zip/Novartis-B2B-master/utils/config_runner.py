from datetime import datetime
from uuid import uuid4

class ConfigRunner(object):

    def __init__(self):
        pass

    def _auto_generate_field(self, config):
        field = ""
        if config["type"] == "string":
            field = str(uuid4().hex)[:config["size"]].upper()
        elif config["type"] == "Date":
            field = datetime.now().strftime(config["format"])
        return field

    def read(self, fields):
        for field_name, field_config in fields.items():
            if field_config["constant"]:
                field_config["value"] = field_config["constant"]
            if field_config["auto"] and not field_config["mapped_field"]:
                   field_config["value"] = self._auto_generate_field(field_config["auto"])
        return fields