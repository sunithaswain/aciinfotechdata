from datetime import datetime
from uuid import uuid4

from requests import post


class Logging(object):

    def __init__(self, source, job_id=uuid4().hex):
        self._api_url = 'https://http-intake.logs.datadoghq.com/v1/input/29b01460666691245a9051a4ce7df41d'
        self._logging = {
            'start_time': datetime.now(),
            'source': source,
            'transaction_id': hash(job_id),
            'job_id': job_id,
        }

    def set_logs(self, event):
        self._logging.update(**event)

    def send(self, is_api_call=True):
        end_time = datetime.now()
        resp_time = (end_time - self._logging['start_time']).microseconds / 1000
        self._logging.update({
            'end_time': end_time.isoformat(),
            'resp_time': resp_time,
            'start_time': self._logging['start_time'].isoformat()
        })
        if not is_api_call:
            return self._logging.__str__()
        else:
            post(self._api_url, json=self._logging)
