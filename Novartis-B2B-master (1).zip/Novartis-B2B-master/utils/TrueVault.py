from base64 import b64encode, b64decode
from json import dumps, loads

from requests import post
from requests import put
from requests.auth import HTTPBasicAuth

from utils.Logging import Logging


class TrueVault(object):

    def __init__(self, api_key, **kwargs):
        self._api_key = api_key
        self._url = "https://api.truevault.com/v1/users"
        self._true_vault_logging = Logging(source='TrueVault', **kwargs)

    # TODO: Change method name. Does not make sense. The method purpose is to do in query
    def get_documents(self, filter_attribute, values, **kwargs):
        """Gets the range of documents by making in call to truevault."""
        query = {
            "filter": {
                f"{filter_attribute}": {
                    "type": "in",
                    "value": values
                },
            },
            "full_document": True,
        }

        self._true_vault_logging.set_logs(
            {'event_type': 'ENTRY', 'operation': 'Calling get_documents in truevault', 'backend_url': self._url,
             **kwargs})

        encoded_query = b64encode(dumps(query).encode("utf-8"))
        true_vault = Logging(source='TrueVault')
        true_vault.set_logs({'event_type': 'INFO', 'http_method': '',
                             'operation': 'HTTP call to truevault', 'http_method': 'POST', **kwargs})
        request = post(self._url + '/search', auth=HTTPBasicAuth(
            self._api_key, ''), data={"search_option": encoded_query})
        true_vault.set_logs(({'http_status_code': request.status_code}))
        # decode results
        true_vault.send()

        results = []
        userids = []
        for document in request.json()['data']['documents']:
            decoded_document = b64decode(
                document['attributes'].encode('utf-8'))
            results.append(loads(decoded_document))
            userids.append(document['user_id'])
        self._true_vault_logging.send()
        get_true_vault_logging = Logging(source='TrueVault')
        get_true_vault_logging.set_logs(
            {'event_type': 'EXIT', 'operation': 'End of truevault call', **kwargs})
        get_true_vault_logging.send()
        return results, userids

    def get_custom_documents(self, predicate, filter_attribute, values):
        query = {
            'filter': {
                f"{filter_attribute}": {
                    "type": predicate,
                    "value": [values]
                }
            },
            'full_document': True
        }
        print(query)
        encoded_query = b64encode(dumps(query).encode('utf-8'))
        request = post(self._url + '/search', auth=HTTPBasicAuth(
            self._api_key, ''), data={'search_option': encoded_query})
        print(request.json())
        results = []

        for document in request.json()['data']['documents']:
            decoded_document = b64decode(
                document['attributes'].encode('utf-8'))
            results.append(loads(decoded_document))

        return results

    def update_documents(self, data, userid):

        # update user attributes to truevault
        r = put(f"{self._url}/{str(userid)}",
                auth=HTTPBasicAuth(self._api_key, ''),
                data=data)
        return r.status_code

    def create_document(self, data):

        r = post(self._url,
                 auth=HTTPBasicAuth(self._api_key, ''),
                 data=data)

        return r.status_code
