import pandas as pd


class ConfigReader(object):

    def __init__(self, file_name, sheet_name):
        self._data = pd.read_excel(file_name, sheet_name=sheet_name)

    def get_config(self):
        root_columns = []
        reader_dict = {}

        for index, value in self._data.iterrows():
            definition, field_name = str(value['Definition']), str(value['Field Name'])

            field_name = '_'.join(field_name.strip().lower().split(" "))

            if definition == "nan" and field_name != "nan":
                reader_dict.update({
                    field_name: {}
                })
                root_columns.append(field_name)

            if field_name not in reader_dict and value['Req/Opt'] == 'R':
                start, end = int(value['Start Pos'] - 1), int(value['End Pos'])
                width = end - start + 1

                reader_dict[root_columns[-1]].update({
                    field_name: {
                        'start_end': [start, end],
                        'field_length': width,
                        'constant': '',
                        'mapped_field': '',
                        'position': ''
                    }
                })

        return reader_dict


if __name__ == '__main__':
    config = ConfigReader("/Users/EKazitski/Downloads/HorizonCustomLayout.xlsx", sheet_name='Medical')
    print(config.get_config())
