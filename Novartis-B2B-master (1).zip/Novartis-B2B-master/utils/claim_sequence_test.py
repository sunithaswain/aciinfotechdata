from test_config.sample_claims import initial_claims
from random import sample
from copy import deepcopy
from pprint import pprint

if __name__ == '__main__':
    
    #Choose 5 random auth_ids

    random_claims = sample(initial_claims, 5)

    sequence_number = 999

    new_test_claims = []
    for claim in random_claims:
        _claim = deepcopy(claim)
        _claim["claim_response"]["transaction_response_status"] = "X" \
            if _claim["claim_response"]["transaction_response_status"] == "P"\
                else "P"
        _claim["claim_sequence_number"] = sequence_number
        sequence_number -= 1
        new_test_claims.append(_claim)
    
    pprint(new_test_claims)